# This program implements a simple "sleep" command because 
# for some reason MS Windows doesn't have this.
import time

time.sleep(2.0)

