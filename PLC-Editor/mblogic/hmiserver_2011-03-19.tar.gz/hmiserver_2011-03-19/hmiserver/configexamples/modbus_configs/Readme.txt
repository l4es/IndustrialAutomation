This is a sample config file for Modbus/TCP. 
