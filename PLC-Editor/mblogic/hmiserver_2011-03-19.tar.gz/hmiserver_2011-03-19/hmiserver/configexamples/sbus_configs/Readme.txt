This is a sample config file for SAIA Ether-SBus. 
