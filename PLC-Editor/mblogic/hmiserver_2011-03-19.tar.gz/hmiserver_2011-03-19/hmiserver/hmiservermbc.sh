#!/bin/bash
./hmiserver/hmiservermbc.py -p 8082 -h localhost -r 8600 -u 1 -t 30.0

