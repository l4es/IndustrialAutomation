#!/bin/bash
./hmiserver/hmiservermbs.py -r 8600 -p 8082

