#!/bin/bash
./hmiserver/hmiserversbc.py -p 8082 -h localhost -r 5050 -u 1 -t 30.0


