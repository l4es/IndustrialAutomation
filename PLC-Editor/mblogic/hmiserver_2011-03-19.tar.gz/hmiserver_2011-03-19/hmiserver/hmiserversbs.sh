#!/bin/bash
./hmiserver/hmiserversbs.py -r 5050 -p 8082

