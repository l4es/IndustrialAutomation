// The client ID string. Replace this with your own client id.
MBT_ClientID = "HMI Demo";

// HMI scan in milliseconds. The web browser will poll the server at the
// interval defined here.
MBT_ScanRate = 1500;

// This is the title of the page.
MBT_PageTitle = "Demo Page"

// This determines whether the page heading is visible or not.
MBT_HeaderVisible = true;

