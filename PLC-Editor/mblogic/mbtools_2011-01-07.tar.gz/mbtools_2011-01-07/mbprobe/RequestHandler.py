##############################################################################
# Project: 	MBProbe
# Module: 	RequestHandler.py
# Purpose: 	Handle web page requests for data.
# Language:	Python 2.5
# Date:		21-Jun-2009.
# Ver.:		34-Jul-2010.
# Copyright:	2009 - 2010 - Michael Griffin       <m.os.griffin@gmail.com>
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# 
# Important:	WHEN EDITING THIS FILE, USE TABS TO INDENT - NOT SPACES!
##############################################################################

"""Handle all web page requests for data. 
"""

import time
import cgi		# This will eventually be changed to urlparse.

from mbprotocols import ModbusTCPSimpleClient
from mbprotocols import ModbusDataStrLib

############################################################

# Error messages.
_ErrorMsgs = {'connectionerror' : 'Connection error.',
	'invalidaddress' : 'Invalid address.',
	'invalidfunction' : 'Invalid function.',
	'invaliddataformat' : 'Invalid data format.',

	'connnecterror' : 'Error - Could not establish contact with remote host.',
	'dataerr' : 'Invalid data.'

}

# Messages for Modbus exception codes.
_ExCode = {1 : 'Unsupported function.',
	2 : 'Invalid address.',
	3 : 'Too many data values.',
	4 : 'Undefined error.',
}

# Message to indicate when automatically reconnecting.
_AutoReconnectMsg = 'Auto reconnecting ...'

############################################################

def _ParseQueryString(postdata):
	"""Reformat the post data query string and return it as a dictionary.
	E.g. 'addrtype02=Discrete+Input&addr02=1&addrtype03=Holding+Register&addr03=55555'
	becomes: {'addr03': '55555', 'addr02': '1', 'addrtype02': 'Discrete Input', 
			'addrtype03': 'Holding Register'}
	Parameters: postdata (string) = The post data query string.
	Returns: (dict) = A dictionary with the post data query names as keys, and the
		individual data items as values.
	Note: This uses parse_qs from cgi instead of from urlparse for compatibility
		with Debian Stable 5.0, which still uses Python 2.5.
	"""

	# This will parse out the content data and turn it into a dictionary.
	# Any fields that were blank will be missing.
	postvalues = cgi.parse_qs(postdata)

	# Next, reformat the new data. The parse_qs routine uses lists as the
	# data elements. We need to change those to individual values.
	return dict(zip(postvalues.keys(), [postvalues[i][0] for i in postvalues.keys()]))


############################################################

class ReadData:
	"""Read data from Modbus.
	"""

	########################################################
	def __init__(self):
		"""
		"""
		# This is the default data used to populate an empty page.
		self._PageDefaultData = {
			'addrtype01' : 'None', 'data01' : '', 'addr01' : '', 'errors01' : '',
			'addrtype02' : 'None', 'data02' : '', 'addr02' : '', 'errors02' : '',
			'addrtype03' : 'None', 'data03' : '', 'addr03' : '', 'errors03' : '',
			'addrtype04' : 'None', 'data04' : '', 'addr04' : '', 'errors04' : '',
			'addrtype05' : 'None', 'data05' : '', 'addr05' : '', 'errors05' : '',
			'addrtype06' : 'None', 'data06' : '', 'addr06' : '', 'errors06' : '',
			'addrtype07' : 'None', 'data07' : '', 'addr07' : '', 'errors07' : '',
			'addrtype08' : 'None', 'data08' : '', 'addr08' : '', 'errors08' : '',
			'addrtype09' : 'None', 'data09' : '', 'addr09' : '', 'errors09' : '',
			'addrtype10' : 'None', 'data10' : '', 'addr10' : '', 'errors10' : '',
			'addrtype11' : 'None', 'data11' : '', 'addr11' : '', 'errors11' : '',
			'addrtype12' : 'None', 'data12' : '', 'addr12' : '', 'errors12' : '',
			'addrtype13' : 'None', 'data13' : '', 'addr13' : '', 'errors13' : '',
			'addrtype14' : 'None', 'data14' : '', 'addr14' : '', 'errors14' : '',
			'addrtype15' : 'None', 'data15' : '', 'addr15' : '', 'errors15' : '',
			'addrtype16' : 'None', 'data16' : '', 'addr16' : '', 'errors16' : '',
			'addrtype17' : 'None', 'data17' : '', 'addr17' : '', 'errors17' : '',
			'addrtype18' : 'None', 'data18' : '', 'addr18' : '', 'errors18' : '',
			'addrtype19' : 'None', 'data19' : '', 'addr19' : '', 'errors19' : '',
			'addrtype20' : 'None', 'data20' : '', 'addr20' : '', 'errors20' : ''
		}

		self._PageData = {}
		# This is the current page data.
		self._PageData.update(self._PageDefaultData)


		# List of keys for address type, address, and data. We need this as a list
		# of tuples so we know which ones are associated with each other.
		self._DataKeys = [('addrtype01', 'addr01', 'data01', 'errors01'),
			('addrtype02', 'addr02', 'data02', 'errors02'), 
			('addrtype03', 'addr03', 'data03', 'errors03'), 
			('addrtype04', 'addr04', 'data04', 'errors04'), 
			('addrtype05', 'addr05', 'data05', 'errors05'), 
			('addrtype06', 'addr06', 'data06', 'errors06'), 
			('addrtype07', 'addr07', 'data07', 'errors07'), 
			('addrtype08', 'addr08', 'data08', 'errors08'), 
			('addrtype09', 'addr09', 'data09', 'errors09'), 
			('addrtype10', 'addr10', 'data10', 'errors10'), 
			('addrtype11', 'addr11', 'data11', 'errors11'), 
			('addrtype12', 'addr12', 'data12', 'errors12'), 
			('addrtype13', 'addr13', 'data13', 'errors13'), 
			('addrtype14', 'addr14', 'data14', 'errors14'), 
			('addrtype15', 'addr15', 'data15', 'errors15'), 
			('addrtype16', 'addr16', 'data16', 'errors16'), 
			('addrtype17', 'addr17', 'data17', 'errors17'), 
			('addrtype18', 'addr18', 'data18', 'errors18'), 
			('addrtype19', 'addr19', 'data19', 'errors19'), 
			('addrtype20', 'addr20', 'data20', 'errors20')
			]


		# Function code translation for reading.
		self._ReadFuncCodes = {'Coil' : 1,
				'Discrete Input' : 2,
				'Holding Register' : 3,
				'Input Register' : 4
				}


	########################################################
	def GetPagedata(self):
		""" Return a dictionary with the page data for a read request.
		"""
		return self._PageData


	########################################################
	def _PreparePageData(self, postdata):
		"""Clear the old page data, and insert the new values from
		the page POST data.
		Parameters: postdata (string) - This is the parameter string from
			the HTML POST headers.
		Returns: Nothing. This updates the page data dictionary directly.
		"""

		# Update the current page data.
		# First, discard the old data.
		self._PageData = {}
		# Next populate it with defaults.
		self._PageData.update(self._PageDefaultData)

		# Parse out the content data and turn it into a dictionary.
		postvalues = _ParseQueryString(postdata)

		# Finally, add the new results.
		self._PageData.update(postvalues)

	########################################################
	def _ClearPage(self):
		"""Clear the page of existing data.
		"""
		# First, discard the old data.
		self._PageData = {}
		# Next populate it with defaults.
		self._PageData.update(self._PageDefaultData)



	########################################################
	def _ValidateReadParams(self, addrtype, addr):
		"""Validate the parameters entered by the user for a read operation.
		This checks for format only. It does not check to see if the values
		are within range.
		Parameters: addrtype (string) = The type of address (coil, etc.).
		addr (string) = The address to read from.
		Returns" (tuple) = (Modbus function code, Modbus address), both
			as integers.
		Returns" (tuple) = (Modbus function code, Modbus address, Error string). 
			Function code and address are integers if OK, or are None if either 
			an error occurred, or if no address type was selected.
			Error string will return an error message if an error was detected,
			or an empty string if not.
		"""

		funccode = None
		addrval = None

		# If no function is selected, skip the further checks.
		if (addrtype == 'None'):
			return funccode, addrval, ''


		# See if the address type is OK.
		try:
			funccode = self._ReadFuncCodes[addrtype]
		except:
			funccode = None
			return funccode, addr, _ErrorMsgs['invalidfunction']
		
		# Check the address to see if it is a number.
		try:
			# Convert to integer.
			addrval = int(addr)
		except:
			addrval = None
			return funccode, addr, _ErrorMsgs['invalidaddress']
			

		return funccode, addrval, ''



	########################################################
	def ReadData(self, postdata):
		"""Analyse the POST data content string, contact the field device 
		and read the data, and insert the new data into the page dictionary.
		Parameters: postdata (string) - This is the parameter string from
			the HTML POST headers.
		Returns: Nothing. This updates the page data dictionary directly.
		"""

		# Populate the page dictionary with the POST data.
		self._PreparePageData(postdata)

		# Check if the user has selected to just clear the page.
		if (self._PageData['read'] == 'reset'):
			self._ClearPage()
			return

		# Read the data from the field device.
		for addrtype, addr, data, errors in self._DataKeys:
			func, addrval, errmsg = self._ValidateReadParams(self._PageData[addrtype], self._PageData[addr])
			if ((func != None) and (addrval != None)):
				try:
					result, msgdata = ConnectionHandler.Request(func, addrval)

					if result:
						self._PageData[data] = msgdata
					else:
						self._PageData[errors] = msgdata

				except:
					self._PageData[errors] = _ErrorMsgs['connectionerror']

			elif (len(errmsg) > 0):
				self._PageData[errors] = errmsg


############################################################

ReadDataHandler = ReadData()


############################################################

class WriteData:
	"""Write data to Modbus.
	"""

	########################################################
	def __init__(self):
		"""
		"""
		# This is the default data used to populate an empty page.
		self._PageDefaultData = {
			'addrtype01' : 'None', 'data01' : '', 'addr01' : '', 'errors01' : '',
			'addrtype02' : 'None', 'data02' : '', 'addr02' : '', 'errors02' : '',
			'addrtype03' : 'None', 'data03' : '', 'addr03' : '', 'errors03' : '',
			'addrtype04' : 'None', 'data04' : '', 'addr04' : '', 'errors04' : '',
			'addrtype05' : 'None', 'data05' : '', 'addr05' : '', 'errors05' : '',
			'addrtype06' : 'None', 'data06' : '', 'addr06' : '', 'errors06' : '',
			'addrtype07' : 'None', 'data07' : '', 'addr07' : '', 'errors07' : '',
			'addrtype08' : 'None', 'data08' : '', 'addr08' : '', 'errors08' : '',
			'addrtype09' : 'None', 'data09' : '', 'addr09' : '', 'errors09' : '',
			'addrtype10' : 'None', 'data10' : '', 'addr10' : '', 'errors10' : '',
			'addrtype11' : 'None', 'data11' : '', 'addr11' : '', 'errors11' : '',
			'addrtype12' : 'None', 'data12' : '', 'addr12' : '', 'errors12' : '',
			'addrtype13' : 'None', 'data13' : '', 'addr13' : '', 'errors13' : '',
			'addrtype14' : 'None', 'data14' : '', 'addr14' : '', 'errors14' : '',
			'addrtype15' : 'None', 'data15' : '', 'addr15' : '', 'errors15' : '',
			'addrtype16' : 'None', 'data16' : '', 'addr16' : '', 'errors16' : '',
			'addrtype17' : 'None', 'data17' : '', 'addr17' : '', 'errors17' : '',
			'addrtype18' : 'None', 'data18' : '', 'addr18' : '', 'errors18' : '',
			'addrtype19' : 'None', 'data19' : '', 'addr19' : '', 'errors19' : '',
			'addrtype20' : 'None', 'data20' : '', 'addr20' : '', 'errors20' : ''
		}

		self._PageData = {}
		# This is the current page data.
		self._PageData.update(self._PageDefaultData)


		# List of keys for address type, address, and data. We need this as a list
		# of tuples so we know which ones are associated with each other.
		self._DataKeys = [('addrtype01', 'addr01', 'data01', 'errors01'),
			('addrtype02', 'addr02', 'data02', 'errors02'), 
			('addrtype03', 'addr03', 'data03', 'errors03'), 
			('addrtype04', 'addr04', 'data04', 'errors04'), 
			('addrtype05', 'addr05', 'data05', 'errors05'), 
			('addrtype06', 'addr06', 'data06', 'errors06'), 
			('addrtype07', 'addr07', 'data07', 'errors07'), 
			('addrtype08', 'addr08', 'data08', 'errors08'), 
			('addrtype09', 'addr09', 'data09', 'errors09'), 
			('addrtype10', 'addr10', 'data10', 'errors10'), 
			('addrtype11', 'addr11', 'data11', 'errors11'), 
			('addrtype12', 'addr12', 'data12', 'errors12'), 
			('addrtype13', 'addr13', 'data13', 'errors13'), 
			('addrtype14', 'addr14', 'data14', 'errors14'), 
			('addrtype15', 'addr15', 'data15', 'errors15'), 
			('addrtype16', 'addr16', 'data16', 'errors16'), 
			('addrtype17', 'addr17', 'data17', 'errors17'), 
			('addrtype18', 'addr18', 'data18', 'errors18'), 
			('addrtype19', 'addr19', 'data19', 'errors19'), 
			('addrtype20', 'addr20', 'data20', 'errors20')
			]


		# Function code translation for writing.
		self._WriteFuncCodes = {'Coil' : 5,
				'Holding Register' : 6,
				}



	########################################################
	def GetPagedata(self):
		""" Return a dictionary with the page data for a read request.
		"""
		return self._PageData


	########################################################
	def _PreparePageData(self, postdata):
		"""Clear the old page data, and insert the new values from
		the page POST data.
		Parameters: postdata (string) - This is the parameter string from
			the HTML POST headers.
		Returns: Nothing. This updates the page data dictionary directly.
		"""

		# Update the current page data.
		# First, discard the old data.
		self._PageData = {}
		# Next populate it with defaults.
		self._PageData.update(self._PageDefaultData)

		# Parse out the content data and turn it into a dictionary.
		postvalues = _ParseQueryString(postdata)

		# Finally, add the new results.
		self._PageData.update(postvalues)

	########################################################
	def _ClearPage(self):
		"""Clear the page of existing data.
		"""
		# First, discard the old data.
		self._PageData = {}
		# Next populate it with defaults.
		self._PageData.update(self._PageDefaultData)


	########################################################
	def _ValidateWriteParams(self, addrtype, addr, writedata):
		"""Validate the parameters entered by the user for a write operation.
		This checks for format only. It does not check to see if the values
		are within range.
		Parameters: addrtype (string) = The type of address (coil, etc.).
		addr (string) = The address to read from.
		writedata (string) = Register value to be checked.
		Returns" (tuple) = (Modbus function code, Modbus address, 
			Validated data value, Error string). Function code, address, and
			data value are integers if OK, or all are None if either an error 
			occurred, or if no address type was selected.
			Error string will return an error message if an error was detected,
			or an empty string if not.
		"""

		funccode = None
		addrval = None
		wval = None

		# If no function is selected, skip the further checks.
		if (addrtype == 'None'):
			return funccode, addrval, wval, ''

		# See if the address type is OK.
		try:
			funccode = self._WriteFuncCodes[addrtype]
		except:
			funccode = None
			return funccode, addrval, wval, _ErrorMsgs['invalidfunction']
		
		# Check the address to see if it is a number.
		try:
			# Convert to integer.
			addrval = int(addr)
		except:
			addr = None
			return funccode, addrval, wval, _ErrorMsgs['invalidaddress']

		# Check the value to see if it is a number.
		try:
			# Convert to integer.
			wval = int(writedata)
		except:
			wval = None
			return funccode, addrval, wval, _ErrorMsgs['invaliddataformat']

		return funccode, addrval, wval, ''


	########################################################
	def WriteData(self, postdata):
		"""Analyse the POST data content string, contact the field device 
		and write the data, and insert any errors into the page dictionary.
		Parameters: postdata (string) - This is the parameter string from
			the HTML POST headers.
		Returns: Nothing. This updates the page data dictionary directly.
		"""

		# Populate the page dictionary with the POST data.
		self._PreparePageData(postdata)

		# Check if the user has selected to just clear the page.
		if (self._PageData['write'] == 'reset'):
			self._ClearPage()
			return

		# Read the data from the field device.
		for addrtype, addr, data, errors in self._DataKeys:
			func, addrval, writevalue, errmsg = self._ValidateWriteParams(self._PageData[addrtype], 
				self._PageData[addr], self._PageData[data])
			if ((func != None) and (addrval != None) and (writevalue != None)):
				try:
					result, msgdata = ConnectionHandler.Request(func, addrval, writevalue)
					if not result:
						self._PageData[errors] = msgdata
				except:
					self._PageData[errors] = _ErrorMsgs['connectionerror']
			elif (len(errmsg) > 0):
				self._PageData[errors] = errmsg

		
############################################################

WriteDataHandler = WriteData()

############################################################


############################################################

class Modbus:
	"""Create a Modbus/TCP client to communcate with the source of the HMI data.
	"""


	########################################################
	def __init__(self, host, port, timeout, unitid=1):
		"""
		host (string) = IP address of server.
		port (integer) = Port for server.
		timeout (float) = Time out in seconds.
		unitid (integer) = The desired Modbus unit id.
		"""
		self._host = host
		self._port = port
		self._timeout = timeout
		self._uid = unitid
		self._transid = 1


		# Initialise the Modbus/TCP connection.
		try:
			self._msg = ModbusTCPSimpleClient.ModbusTCPSimpleClient(self._host,
				 self._port, self._timeout)
		except:
			self._msg = None
			print(_ErrorMsgs['connnecterror'])
			# Raise the exception again so the next layer can deal with it.
			raise


	########################################################
	def _IncTransID(self):
		"""Increment the transaction ID.
		"""
		self._transid +=1
		if self._transid > 32767:
			self._transid = 1

	########################################################
	def Request(self, func, addr, data=None):
		"""Read data from an address.
		Parameters: func (integer) = Modbus function code.
			addr (integer) = Modbus address.
			data (integer) = Data to be written (optional).
		Returns: (tuple) = If OK, returns True plus the received data.
			If error, returns False plus an error message.
		"""

		# Increment the transaction id.
		self._IncTransID()

		# Only request one at a time.
		qty = 1
		sendata = None

		# Only the following function codes are supported.
		if (func not in [1, 2, 3, 4, 5, 6, 15, 16]):
			return False, _ExCode[1]

		# Check if the Modbus address is legal. This does not guaranty though
		# that it will be supported in the field device.
		if (addr < 0) or (addr > 65535):
			return False, _ExCode[2]


		# If we are writing data, make sure it is valid.
		if func in [5, 6]:
			try:
				dataint = int(data)
			except:
				return False, _ErrorMsgs['dataerr']


		# For writing data, convert the data to a binary string, 
		# and check if it is within range for that function.
		if (func == 5):
			if (dataint in [0, 1]):
				sendata = ModbusDataStrLib.coilvalue(data)
			else:
				return False, _ErrorMsgs['dataerr']
		elif (func == 6):
			if ((dataint >= -32768) and (dataint <= 32767)):
				sendata = ModbusDataStrLib.SignedInt2BinStr(data)
			else:
				return False, _ErrorMsgs['dataerr']

		try:	
			self._msg.SendRequest(self._transid, self._uid, func, addr, qty, sendata)
			TransID, rfunct, MsgData = self._msg.ReceiveResponse()
		except:
			return False, _ErrorMsgs['connnecterror']

		if (rfunct != func):
			return False, _ExCode[MsgData]


		# Decode the data by function code.
		if (rfunct in [1, 2]):
			rdata = int(ModbusDataStrLib.bin2boollist(MsgData)[0])
		elif (rfunct in [3, 4]):
			rdata = ModbusDataStrLib.signedbin2intlist(MsgData)[0]
		elif (rfunct == 5):
			rdata = ModbusDataStrLib.signedbin2intlist(MsgData)[0]
		elif (rfunct == 6):
			rdata = ModbusDataStrLib.signedbin2intlist(MsgData)[0]
		elif (rfunct == 15):
			rdata = ModbusDataStrLib.bin2boollist(MsgData)[0]
		elif (rfunct == 16):
			rdata = ModbusDataStrLib.signedbin2intlist(MsgData)[0]


		return True, rdata


############################################################



############################################################

class ConnectionStat:
	"""Control the Modbus connection status.
	"""

	########################################################
	def __init__(self):
		"""
		"""
		self._rhost = 'localhost'
		self._rport = 502
		self._rtimeout = 5.0
		self._runitid = 1
		self._Connected = False
		self._AutoReconnect = True
		self._ConnectionError = False

		# This is the default data used to populate an empty page.
		self._PageDefaultData = {'host' : self._rhost, 
					'port' : self._rport, 
					'timeout' : self._rtimeout, 
					'unitid' : self._runitid,
					'connectedstat' : 'checked',
					'disconnectedstat' : '',
					'autoconnectstat' : 'checked',
					'connectionstat' : '',
					'currenthost' : '',
					'currentport' : '',
					'currenttimeout' : '',
					'currentunitid' : '',
					'connectionstyle' : 'statusdisconnected',
					'softversion' : ''
		}

		self._PageData = {}
		self._PageData.update(self._PageDefaultData)


	########################################################
	def SetVersionInfo(self, versioninfo):
		"""Set the package version name and number for display.
		Parameters: versioninfo (string) = The package name and version.
		"""
		self._PageDefaultData['softversion'] = versioninfo


	########################################################
	def _SetPageData(self):
		"""Set the page data dictionary with the updated data.
		"""

		self._PageDefaultData['host'] = self._rhost
		self._PageDefaultData['port'] = self._rport
		self._PageDefaultData['timeout'] = self._rtimeout
		self._PageDefaultData['unitid'] = self._runitid

		if self._Connected:
			self._PageDefaultData['connectionstat'] = 'Connected'
			self._PageDefaultData['currenthost'] = self._rhost
			self._PageDefaultData['currentport'] = self._rport
			self._PageDefaultData['currenttimeout'] = self._rtimeout
			self._PageDefaultData['currentunitid'] = self._runitid
			self._PageDefaultData['connectionstyle'] = 'statusconnected'
		else:
			self._PageDefaultData['connectionstat'] = 'Disconnected'
			self._PageDefaultData['currenthost'] = ''
			self._PageDefaultData['currentport'] = ''
			self._PageDefaultData['currenttimeout'] = ''
			self._PageDefaultData['currentunitid'] = ''
			self._PageDefaultData['connectionstyle'] = 'statusdisconnected'



		# This sets the correct status for the "radio button" input
		# for connected or disconnected.
		if self._Connected:
			self._PageDefaultData['connectedstat'] = 'checked="checked"'
			self._PageDefaultData['disconnectedstat'] = ''
		else:
			self._PageDefaultData['connectedstat'] = ''
			self._PageDefaultData['disconnectedstat'] = 'checked="checked"'

		# This sets the correct status for the "radio button" input
		# for auto-connect.
		if self._AutoReconnect:
			self._PageDefaultData['autoconnectstat'] = 'checked="checked"'
		else:
			self._PageDefaultData['autoconnectstat'] = ''


		# Check if there was a connection error.
		if self._ConnectionError:
			self._PageDefaultData['connecterror'] = _ErrorMsgs['connnecterror']
		else:
			self._PageDefaultData['connecterror'] = ''


		self._PageData = {}
		# This is the current page data.
		self._PageData.update(self._PageDefaultData)
		

	########################################################
	def SetConnectionParams(self, rhost, rport, rtimeout, runitid, autoreconnect):
		"""Set the remote Modbus server connection parameters.
		"""
		self._rhost = rhost
		self._rport = rport
		self._rtimeout = rtimeout
		self._runitid = runitid
		self._AutoReconnect = autoreconnect

		self._SetPageData()


	########################################################
	def GetPagedata(self):
		""" Return a dictionary with the page data for a read request.
		"""
		return self._PageData


	########################################################
	def _PreparePageData(self, postdata):
		"""Clear the old page data, and insert the new values from
		the page POST data.
		"""

		# Update the current page data.
		# First, discard the old data.
		self._PageData = {}
		# Next populate it with defaults.
		self._PageData.update(self._PageDefaultData)

		# Parse out the content data and turn it into a dictionary.
		postvalues = _ParseQueryString(postdata)

		# Finally, add the new results.
		self._PageData.update(postvalues)




	########################################################
	def ConnectData(self, postdata):
		"""Analyse the POST data content string.
		"""

		# Populate the page dictionary with the POST data.
		self._PreparePageData(postdata)


		try:
			rhost = self._PageData['host']
			if (len(rhost) <= 0):
				rhost = None
		except:
			rhost = None

		try: 
			rport = int(self._PageData['port'])
		except:
			rport = None
			
		try:
			rtimeout = float(self._PageData['timeout'])
		except:
			rtimeout = None

		try:
			runitid = int(self._PageData['unitid'])
		except:
			runitid = None

		try:
			connectreq = self._PageData['connect'] == 'connect'
		except:
			connectreq = None

		try:
			autoconnectreq = self._PageData['autoconnect'] == 'autoconnect'
		except:
			autoconnectreq = False

		# Check if the parameters were OK. We don't check for 'autoconnect',
		# because as a check box if it is off it will not be present.
		if (rhost != None) and (rport != None) and (rtimeout != None) and (runitid != None) and connectreq:
			# Save the new parameters.
			self._rhost = rhost
			self._rport = rport
			self._rtimeout = rtimeout
			self._runitid = runitid

			# If already connected, then disconnect and reconnect.
			self.Reconnect()

		# Disconnect.
		elif (not connectreq):
			self._ModbusConnect = None
			self._Connected = False
			self._SetPageData()

		# Auto reconnect doesn't depend on the current connection status.
		self._AutoReconnect = autoconnectreq

		# Update the page data.
		self._SetPageData()


	########################################################
	def Request(self, func, addr, data=None):
		""" Make a Modbus/TCP request to the field device. The parameters
		and data are the same as for the corresponding Modbus method.
		"""
		try:
			result, recvdata = self._ModbusConnect.Request(func, addr, data)
		except:
			result = False
			recvdata = _ErrorMsgs['connnecterror']


		# If an error occured and autoconnect is set, then automatically 
		# re-connect and try again.
		if not result and self._AutoReconnect:
			print(_AutoReconnectMsg)
			self.Reconnect()
			result, recvdata = self._ModbusConnect.Request(func, addr, data)
			
		return result, recvdata


	########################################################
	def Connect(self):
		""" Connect to the remote Modbus/TCP field device server.
		"""
		try:
			self._ModbusConnect = Modbus(self._rhost, self._rport, self._rtimeout, self._runitid)
			self._Connected = True
			self._ConnectionError = False
		except:
			self._Connected = False
			self._ModbusConnect = None
			self._ConnectionError = True
	
		# Update the page data.
		self._SetPageData()
			

	########################################################
	def Reconnect(self):
		""" Disconnect from the remote field device and then
		reconnect.
		"""
		# If already connected, then disconnect.
		self._ModbusConnect = None
		# Delay slightly before attempting a new connection.
		time.sleep(1.0)
		# Make the new connection.
		self.Connect()

		
############################################################

ConnectionHandler = ConnectionStat()


