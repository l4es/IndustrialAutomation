#!/bin/bash
../mbasync/mbasyncserver.py -p 8600

