#!/bin/bash
./mbprobe.py -p 8680 -h localhost -r 8600 -u 1 -t 30.0 -c y -a y

