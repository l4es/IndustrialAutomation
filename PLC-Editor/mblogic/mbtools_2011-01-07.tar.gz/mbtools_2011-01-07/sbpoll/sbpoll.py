#!/usr/bin/python
##############################################################################
# Project: 	pollsb
# Module: 	pollsb.py
# Purpose: 	Command line EtherSBus client (master).
# Language:	Python 2.6
# Date:		21-Nov-2009.
# Ver:		06-May-2010.
# Author:	M. Griffin.
# Copyright:	2009 - 2010 - Michael Griffin       <m.os.griffin@gmail.com>
#
# This file is part of pollsb.
# pollsb is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# pollsb is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with pollsb. If not, see <http://www.gnu.org/licenses/>.
#
# Important:	WHEN EDITING THIS FILE, USE TABS TO INDENT - NOT SPACES!
##############################################################################

import signal
import sys

import time

from mbprotocols import SBusSimpleClient
from mbprotocols import ModbusDataStrLib
from mbprotocols import SBusMsg

import sbpollcommon

############################################################

# Signal handler.
def SigHandler(signum, frame):
	print('Polling terminated from keyboard at %s' % time.ctime())
	sys.exit(3)


# Initialise the signal handler.
signal.signal(signal.SIGINT, SigHandler)


############################################################

# Get the command line parameter options.
CmdOpts = sbpollcommon.GetOptions()

host, port, timeout = CmdOpts.GetHost()

print('\nContacting EtherSBus host at %s port %d timeout %.01f sec.' % (host, port, timeout))

try:
	sbclient = SBusSimpleClient.SBusSimpleClient(host, port, timeout)
except:
	print('Failed to contact host.')
	sys.exit(5)



############################################################

# Get what data to send.
SendStation, SendCommand, SendAddr, SendQty, SendData = CmdOpts.GetSBRequest()

# Preset the message sequence.
SendMsgSeq = 0

# If this is a write function, convert the data to binary packed string format.
BinData = '\x00\x00'
try:
	# Read data.
	if SendCommand in (2, 3, 5, 6):
		BinData = ''	# No data to write.
	# Write bit data.
	elif SendCommand in (11, 13):
		BinData = ModbusDataStrLib.bininversor(SendData)
	# Write registers.
	elif SendCommand == 14:
		# Convert the string to a list of integers.
		SendConvert = map(int, SendData.split(','))
		# Trim the list to the requested quantity.
		SendConvert = SendConvert[:SendQty]
		# Convert this to a binary string.
		BinData = SBusMsg.signedint32list2bin(SendConvert)
	else:
		BinData = '\x00\x00'
except:
	print('Invalid data for SBus command %d.' % SendCommand)
	sys.exit(4)

# Construct the SBus request message.
try:
	RequestMsg = sbclient.MakeRawRequest(SendMsgSeq, SendStation, SendCommand, SendQty, SendAddr, BinData)
except:
	print('Invalid SBus parameters.')
	sys.exit(6)


############################################################

# Get the polling rate info.
PollRepeats, PollDelay = CmdOpts.GetPollRate()

# Get whether to use "silent" polling.
PollSilently = CmdOpts.GetIsSilent()

# Record the starting time for reporting statistics.
StartTime = time.time()


# Tell the user what the program is going to do.
if SendCommand in (2, 3, 5, 6):
	IntroStr = 'Sending SBus command: %d, addr: %d, qty: %d, for %d polls at %d msec'
	print(IntroStr % (SendCommand, SendAddr, SendQty, PollRepeats, int(PollDelay * 1000.0)))
else:
	IntroStr = 'Sending SBus command: %d, addr: %d, qty: %d, data: %s for %d polls at %d msec'
	print(IntroStr % (SendCommand, SendAddr, SendQty, SendData, PollRepeats, int(PollDelay * 1000.0)))


# Poll the server.
for i in xrange(PollRepeats):

	# Send the SBus request message to the server.
	try:
		sbclient.SendRawRequest(RequestMsg)
	except:
		print('Error sending request to host.')
		sys.exit(5)

	# Get the reply.
	try:
		Recv_TelegramAttr, Recv_MsgSequence, Recv_Data = sbclient.ReceiveResponse()
	except SBusMsg.MessageLengthError:
		print('Error receiving data from host - bad message response length.')
		sys.exit(5)
	except SBusMsg.CRCError:
		print('Error receiving data from host - bad CRC.')
		sys.exit(5)
	except:
		print('Error receiving data from host.')
		sys.exit(5)


	# Check what sort of response it was.
	# This was a response with data.
	if (Recv_TelegramAttr == 1):
		# Decode the reply.
		try:
			if SendCommand in (2, 3, 5):
				hexdata = ModbusDataStrLib.inversorbin(Recv_Data)
			elif SendCommand == 6:
				hexdata = SBusMsg.signedbin2int32list(Recv_Data)
			elif  SendCommand in (11, 13, 14):
				acknak = ModbusDataStrLib.BinStr2SignedInt(Recv_Data)
				if acknak == 0:
					hexdata = 'ack'
				else:
					hexdata = 'nak'
			else:
				hexdata = 'No Data'
		except:
			print('Bad data format received from host for command %d' % SendCommand)
			sys.exit(5)

	# This was an ACK or a NAK.
	elif (Recv_TelegramAttr == 2):
		# Decode the ack/nak response.
		try:
			acknak = ModbusDataStrLib.BinStr2SignedInt(Recv_Data)
		except:
			print('Bad ack/nak format received from host for command %d' % SendCommand)
			sys.exit(5)
		# The response was a simple "ack".
		if (acknak == 0):
			hexdata = 'ACK'
		else:
			print('Error: Recieved NAK response from host for command %d' % SendCommand)
			sys.exit(5)
	else:
		print('Error: Bad telegram attribute %s  from host for command %d' % (Recv_TelegramAttr, SendCommand))
		sys.exit(5)


	if not PollSilently:
		print('%d: Reply was: command: %d, data: %s' % (i + 1, SendCommand, hexdata))


	# Delay until the next scheduled polling time.
	if (PollDelay > 0.0) and (i < (PollRepeats - 1)):
		time.sleep(PollDelay)


############################################################

# Report polling information if multiple polls were made.
if (PollRepeats > 1):
	EndTime = time.time()
	ElapsedTime = EndTime - StartTime
	sbpollcommon.ReportStats(ElapsedTime, SendQty, PollRepeats, SendCommand)


############################################################


