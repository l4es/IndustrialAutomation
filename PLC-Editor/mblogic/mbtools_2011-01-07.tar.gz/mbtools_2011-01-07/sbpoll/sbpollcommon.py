##############################################################################
# Project: 	sbpoll
# Module: 	sbpollcommon.py
# Purpose: 	Command line EtherSBus client (master).
# Language:	Python 2.6
# Date:		21-Nov-2009.
# Ver:		21-Nov-2009.
# Author:	M. Griffin.
# Copyright:	2009 - Michael Griffin       <m.os.griffin@gmail.com>
#
# This file is part of pollsb.
# pollsb is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# pollsb is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with pollsb. If not, see <http://www.gnu.org/licenses/>.
#
# Important:	WHEN EDITING THIS FILE, USE TABS TO INDENT - NOT SPACES!
##############################################################################
"""
This library provides common functions to the pollsb programs.
"""

import getopt, sys

############################################################

_HelpIntroSBStr = """
This program provides a simple command line EtherSBus client. It can be 
used to read or write to EtherSBus servers. It can also be used to measure 
the performance of EtherSBus servers by repeated polling them and measuring 
the elaspsed time. It supports SBus functions 2, 3, 5, 6, 11, 13, and 14.

It has a variety of command line parameters. Any parameters which are not 
specified will use their default values. These include:

Ethernet address:
-h Host name of the EtherSBus server. The default is localhost.
-p Port number of the EtherSBus server. The default is 5050.
-t Receive time-out in seconds. The default is 60. The minimum is 1.
"""

_HelpMainStr = """

SBus parameters:
-c Command code. The default is 2.
-n Station address. The default is 1.
-a Address (SBus memory). The default is 0.
-q Quantity of addresses. The default is 1.

Polling parameters:
-r Repeats. Number of times to perform the poll. The default is 1.
-y Delay time between repeats in milliseconds. The default is 1.
-d Data to send to the server. Default is 0.
-s Silent mode. 'Y' or 'y' will suppress displaying data. Default is 'no'.

Data:
For commands 2, 3, 5, or 6, any data specified is ignored. For commands 
11, 13, or 14, data must be specified. For commands 11 or 13, data must 
be 0 and 1 characters, in multiples of 8 characters. E.g. 00111010.
For command 14 , data must be as a list of decimal integers separated
by commas. E.g. 1234,5678,99,999999
There must be *no* spaces in the list.

Supported commands:
2 = Read Flags
3 = Read Inputs
5 = Read Outputs
6 = Read Registers
11 = Write flags
13 = Write outputs
14 = Write Registers

Return Codes:
The following command line return codes are defined:
0 = No errors.
2 = Bad command line.
3 = Program was terminated from keyboard.
4 = Invalid data for SBus command.
5 = Error communicating with host.
6 = Invalid SBus parameters

Polling performance measurement:
When used to measure polling performance, silent mode should be enabled.
When more than one repeat is specified, extra information is displayed
after polling is completed. This includes elapsed time, number of
data elements transfered, and the data transfer rate. When trying to measure
maximum speed a large enough number of polls should be specified to allow
measurement over several (e.g. 5 to 10) seconds in order to get an accurate 
reading.

"""

_HelpExampleSBStr = """
Example (Linux):
./pollsb.py -p 5050 -c 2 -a 0 -q 125 -y 0 -r 30000 -s y

Example (MS Windows):
c:\python26\python pollsb.py -p 5050 -c 2 -a 0 -q 125 -y 0 -r 30000 -s y

Poll a server at port 5050 to read 125 flags starting at
address 0, and repeat 30000 times with a delay time of 0 while not displaying
the results of each poll.
"""


_HelpLicenseStr = """

Author: Michael Griffin
Copyright 2009 Michael Griffin. This is free software. You may 
redistribute copies of it under the terms of the GNU General Public License
<http://www.gnu.org/licenses/gpl.html>. There is NO WARRANTY, to the
extent permitted by law.

"""

############################################################

# Construct the help string for pollsb.
HelpStrSB = _HelpIntroSBStr + _HelpMainStr + _HelpExampleSBStr + _HelpLicenseStr


############################################################
# Get the command line options.
# These include the host and port numbers and the modbus
# function parameters. These may be set by the user on the command line. 
# If the user does not set any options, then default values are used.
#
class GetOptions:

	########################################################
	def __init__(self):
		"""
		"""
		self._port = 5050
		self._HelpStr = HelpStrSB

		self._host = 'localhost'
		self._timeout = 60.0
		self._command = 2
		self._station = 1
		self._addr = 0
		self._qty = 1
		self._repeats = 1
		self._delay = 0.001
		self._data = '00000000'
		self._silent = False

		# Read the command line options.
		try:
			opts, args = getopt.getopt(sys.argv[1:], 'p: h: t: c: n: a: q: u: r: y: d: s:', 
				['port', 'host', 'timeout', 'cmd', 'stn', 'addr', 'qty', 'uid', 'repeat', 'delay', 'data', 'silent'])
		except:
			print('Unrecognised options.')
			sys.exit(2)

		# Check if no parameters specified. If none, then print out the help message.
		if (opts == []):
			print(self._HelpStr)
			sys.exit(2)


		# Parse out the options.
		for o, a in opts:
			# Port.
			if o == '-p':
				try:
					self._port = int(a)
				except:
					print('Invalid port number.')
					sys.exit(2)
			# Host.
			elif o == '-h':
				self._host = a

			# Time out.
			elif o == '-t':
				try:
					self._timeout = float(a)
				except:
					print('Invalid time out value.')
					sys.exit(2)
				if (self._timeout < 1.0):
					print('Specified timeout is too small.')
					sys.exit(2)

			# Command.
			elif o == '-c':
				try:
					self._command = int(a)
				except:
					print('Invalid SBus command.')
					sys.exit(2)
				if (self._command not in (2, 3, 5, 6, 11, 13, 14)):
					print('SBus command is not supported by this program.')
					sys.exit(2)

			# Station.
			elif o == '-n':
				try:
					self._station = int(a)
				except:
					print('Invalid SBus station.')
					sys.exit(2)
				if ((self._station < 0) or (self._station > 255)):
					print('SBus station is out of range.')
					sys.exit(2)

			# Data table address.
			elif o == '-a':
				try:
					self._addr = int(a)
				except:
					print('Invalid SBus address.')
					sys.exit(2)
				if ((self._addr < 0) or (self._addr > 65535)):
					print('SBus address is out of range.')
					sys.exit(2)

			# Quantity.
			elif o == '-q':
				try:
					self._qty = int(a)
				except:
					print('Invalid SBus quantity.')
					sys.exit(2)
				if ((self._qty < 0) or (self._qty > 65536)):
					print('SBus quantity is out of range.')
					sys.exit(2)

			# Poll repeats.
			elif o == '-r':
				try:
					self._repeats = int(a)
				except:
					print('Invalid number of poll repeats.')
					sys.exit(2)

			# Poll repeat delay.
			elif o == '-y':
				try:
					self._delay = int(a)/1000.0
				except:
					print('Invalid repeat delay.')
					sys.exit(2)

			# Data to write.
			elif o == '-d':
				self._data = a

			# Poll silently.
			elif o == '-s':
				self._silent = (a in ('y', 'Y'))

			# We don't recognise this option.
			else:
				print('Unrecognised option %s %s' % (o, a))
				sys.exit(2)

	########################################################
	def GetHost(self):
		"""Return the host and port setting.
		"""
		return self._host, self._port, self._timeout

	########################################################
	def GetSBRequest(self):
		"""Return the SBus command info.
		"""
		return self._station, self._command, self._addr, self._qty, self._data

	########################################################
	def GetPollRate(self):
		"""Return the polling rate information.
		"""
		return self._repeats, self._delay

	########################################################
	def GetIsSilent(self):
		"""Return whether polling should be "silent" (do not report
		read or write results).
		"""
		return self._silent

############################################################


def ReportStats(ElapsedTime, SendQty, PollRepeats, SendCommand):
	"""Report polling information if multiple polls were made.
	Parameters:
	ElapsedTime (float) = Elapsed time in seconds.
	SendQty (integer) = Amount of data sent per poll.
	PollRepeats (integer) = Number of polling cycles.
	SendCommand (integer) = SBus command used.
	"""

	TotalSent = SendQty * PollRepeats
	AchievedRate =  TotalSent / ElapsedTime
	if (AchievedRate > 1000.0):
		AchievedRateStr = '%.0f' % AchievedRate
	else:
		AchievedRateStr = '%f' % AchievedRate

	if SendCommand in (2, 3, 5):
		PollType = 'Booleans'
	else:
		PollType = 'Registers'

	print('\nElapsed time was %f seconds.' % ElapsedTime)
	print('A total of %d %s were sent at a rate of %s %s per second.\n' % (TotalSent, PollType, AchievedRateStr, PollType))

############################################################


