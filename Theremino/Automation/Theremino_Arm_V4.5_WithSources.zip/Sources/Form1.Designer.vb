﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker3 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim CBlendItems3 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim CBlendItems4 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim DesignerRectTracker4 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim DesignerRectTracker5 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim CBlendItems5 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim CBlendItems6 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim DesignerRectTracker6 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim DesignerRectTracker7 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim CBlendItems7 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim CBlendItems8 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim DesignerRectTracker8 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim DesignerRectTracker9 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim CBlendItems9 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim CBlendItems10 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim DesignerRectTracker10 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim DesignerRectTracker1 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim CBlendItems2 As Theremino_Arm.cBlendItems = New Theremino_Arm.cBlendItems
        Dim DesignerRectTracker2 As Theremino_Arm.DesignerRectTracker = New Theremino_Arm.DesignerRectTracker
        Me.GroupBox_ArmProperties = New System.Windows.Forms.GroupBox
        Me.Label_Joint = New System.Windows.Forms.Label
        Me.Label_Rapp = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label_LenZ = New System.Windows.Forms.Label
        Me.Label_LenX = New System.Windows.Forms.Label
        Me.Label_LenY = New System.Windows.Forms.Label
        Me.chk_Invert3 = New System.Windows.Forms.CheckBox
        Me.chk_Invert2 = New System.Windows.Forms.CheckBox
        Me.chk_Invert1 = New System.Windows.Forms.CheckBox
        Me.Label_Delta = New System.Windows.Forms.Label
        Me.Label_Inv = New System.Windows.Forms.Label
        Me.chk_Invert0 = New System.Windows.Forms.CheckBox
        Me.Panel_Delta = New System.Windows.Forms.Panel
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.TrackBar7 = New System.Windows.Forms.TrackBar
        Me.TrackBar6 = New System.Windows.Forms.TrackBar
        Me.TrackBar5 = New System.Windows.Forms.TrackBar
        Me.TrackBar4 = New System.Windows.Forms.TrackBar
        Me.TrackBar3 = New System.Windows.Forms.TrackBar
        Me.TrackBar2 = New System.Windows.Forms.TrackBar
        Me.TrackBar1 = New System.Windows.Forms.TrackBar
        Me.TrackBar0 = New System.Windows.Forms.TrackBar
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pic_ArmGeometry = New System.Windows.Forms.PictureBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chk_AutoSleep = New System.Windows.Forms.CheckBox
        Me.chk_AutoParking = New System.Windows.Forms.CheckBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_LoadConfiguration = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SaveConfigurationAs = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_SaveImage = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.ToDoListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_LoadConfiguration = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_SaveConfiguration = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_SaveImage = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.txt_GcodeAutomation = New Theremino_Arm.MyTextBox
        Me.btn_OverrideZ = New Theremino_Arm.MyButton
        Me.txt_Zup = New Theremino_Arm.MyTextBox
        Me.txt_Zdown = New Theremino_Arm.MyTextBox
        Me.txt_GcodeFile = New Theremino_Arm.MyTextBox
        Me.txt_Ztrip = New Theremino_Arm.MyTextBox
        Me.btn_GcodeLoad = New Theremino_Arm.MyButton
        Me.txt_OriginX = New Theremino_Arm.MyTextBox
        Me.btn_GcodeRun = New Theremino_Arm.MyButton
        Me.btn_GcodeRewind = New Theremino_Arm.MyButton
        Me.txt_GcodeLine = New Theremino_Arm.MyTextBox
        Me.txt_OriginY = New Theremino_Arm.MyTextBox
        Me.txt_OriginZ = New Theremino_Arm.MyTextBox
        Me.txt_ScaleX = New Theremino_Arm.MyTextBox
        Me.txt_ScaleY = New Theremino_Arm.MyTextBox
        Me.txt_ScaleZ = New Theremino_Arm.MyTextBox
        Me.txt_MaxError = New Theremino_Arm.MyTextBox
        Me.txt_FeedWork = New Theremino_Arm.MyTextBox
        Me.txt_FeedRapid = New Theremino_Arm.MyTextBox
        Me.txt_Rapp3 = New Theremino_Arm.MyTextBox
        Me.txt_Rapp2 = New Theremino_Arm.MyTextBox
        Me.txt_Rapp1 = New Theremino_Arm.MyTextBox
        Me.txt_Rapp0 = New Theremino_Arm.MyTextBox
        Me.txt_Len2Z = New Theremino_Arm.MyTextBox
        Me.txt_Len2X = New Theremino_Arm.MyTextBox
        Me.cmb_Configurations = New Theremino_Arm.MyComboBox
        Me.txt_Len3X = New Theremino_Arm.MyTextBox
        Me.txt_Len3Z = New Theremino_Arm.MyTextBox
        Me.txt_Len0Z = New Theremino_Arm.MyTextBox
        Me.txt_Len3Y = New Theremino_Arm.MyTextBox
        Me.txt_Delta3 = New Theremino_Arm.MyTextBox
        Me.txt_Len2Y = New Theremino_Arm.MyTextBox
        Me.txt_Len0Y = New Theremino_Arm.MyTextBox
        Me.txt_Delta2 = New Theremino_Arm.MyTextBox
        Me.txt_Len1Y = New Theremino_Arm.MyTextBox
        Me.txt_Delta1 = New Theremino_Arm.MyTextBox
        Me.txt_Delta0 = New Theremino_Arm.MyTextBox
        Me.btn_Steppers = New Theremino_Arm.MyButton
        Me.txt_NumMotorSlots = New Theremino_Arm.MyTextBox
        Me.txt_FirstMotorSlot = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo7 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo6 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo5 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo4 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo3 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo2 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo1 = New Theremino_Arm.MyTextBox
        Me.txt_AngleServo0 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo7 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo6 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo5 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo4 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo3 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo2 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo1 = New Theremino_Arm.MyTextBox
        Me.txt_TimeServo0 = New Theremino_Arm.MyTextBox
        Me.txt_ParkingZ = New Theremino_Arm.MyTextBox
        Me.txt_ParkingY = New Theremino_Arm.MyTextBox
        Me.txt_ParkingX = New Theremino_Arm.MyTextBox
        Me.txt_DeltaVerticalDist = New Theremino_Arm.MyTextBox
        Me.txt_DeltaMotorArms = New Theremino_Arm.MyTextBox
        Me.txt_DeltaVerticalArms = New Theremino_Arm.MyTextBox
        Me.txt_DeltaMotorRadius = New Theremino_Arm.MyTextBox
        Me.txt_DeltaEndRadius = New Theremino_Arm.MyTextBox
        Me.txt_MinY = New Theremino_Arm.MyTextBox
        Me.txt_MaxAreaX = New Theremino_Arm.MyTextBox
        Me.txt_JogStep = New Theremino_Arm.MyTextBox
        Me.GroupBox_ArmProperties.SuspendLayout()
        Me.Panel_Delta.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.Pic_ArmGeometry, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox_ArmProperties
        '
        Me.GroupBox_ArmProperties.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_Joint)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Rapp3)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Rapp2)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Rapp1)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_Rapp)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Rapp0)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len2Z)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len2X)
        Me.GroupBox_ArmProperties.Controls.Add(Me.cmb_Configurations)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label3)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len3X)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_LenZ)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len3Z)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_LenX)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len0Z)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len3Y)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Delta3)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_LenY)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len2Y)
        Me.GroupBox_ArmProperties.Controls.Add(Me.chk_Invert3)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len0Y)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Delta2)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Len1Y)
        Me.GroupBox_ArmProperties.Controls.Add(Me.chk_Invert2)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Delta1)
        Me.GroupBox_ArmProperties.Controls.Add(Me.chk_Invert1)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_Delta)
        Me.GroupBox_ArmProperties.Controls.Add(Me.txt_Delta0)
        Me.GroupBox_ArmProperties.Controls.Add(Me.Label_Inv)
        Me.GroupBox_ArmProperties.Controls.Add(Me.chk_Invert0)
        Me.GroupBox_ArmProperties.Font = New System.Drawing.Font("Verdana", 9.75!)
        Me.GroupBox_ArmProperties.Location = New System.Drawing.Point(8, 56)
        Me.GroupBox_ArmProperties.Name = "GroupBox_ArmProperties"
        Me.GroupBox_ArmProperties.Size = New System.Drawing.Size(281, 175)
        Me.GroupBox_ArmProperties.TabIndex = 151
        Me.GroupBox_ArmProperties.TabStop = False
        Me.GroupBox_ArmProperties.Text = "Arm properties"
        '
        'Label_Joint
        '
        Me.Label_Joint.AutoSize = True
        Me.Label_Joint.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Joint.Location = New System.Drawing.Point(6, 71)
        Me.Label_Joint.Name = "Label_Joint"
        Me.Label_Joint.Size = New System.Drawing.Size(36, 14)
        Me.Label_Joint.TabIndex = 227
        Me.Label_Joint.Text = "Joint"
        '
        'Label_Rapp
        '
        Me.Label_Rapp.AutoSize = True
        Me.Label_Rapp.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Rapp.Location = New System.Drawing.Point(68, 71)
        Me.Label_Rapp.Name = "Label_Rapp"
        Me.Label_Rapp.Size = New System.Drawing.Size(43, 14)
        Me.Label_Rapp.TabIndex = 223
        Me.Label_Rapp.Text = "Rapp."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(47, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 14)
        Me.Label3.TabIndex = 218
        Me.Label3.Text = "Arm configuration"
        '
        'Label_LenZ
        '
        Me.Label_LenZ.AutoSize = True
        Me.Label_LenZ.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_LenZ.Location = New System.Drawing.Point(235, 71)
        Me.Label_LenZ.Name = "Label_LenZ"
        Me.Label_LenZ.Size = New System.Drawing.Size(38, 14)
        Me.Label_LenZ.TabIndex = 216
        Me.Label_LenZ.Text = "LenZ"
        '
        'Label_LenX
        '
        Me.Label_LenX.AutoSize = True
        Me.Label_LenX.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_LenX.Location = New System.Drawing.Point(149, 71)
        Me.Label_LenX.Name = "Label_LenX"
        Me.Label_LenX.Size = New System.Drawing.Size(38, 14)
        Me.Label_LenX.TabIndex = 212
        Me.Label_LenX.Text = "LenX"
        '
        'Label_LenY
        '
        Me.Label_LenY.AutoSize = True
        Me.Label_LenY.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_LenY.Location = New System.Drawing.Point(193, 71)
        Me.Label_LenY.Name = "Label_LenY"
        Me.Label_LenY.Size = New System.Drawing.Size(37, 14)
        Me.Label_LenY.TabIndex = 207
        Me.Label_LenY.Text = "LenY"
        '
        'chk_Invert3
        '
        Me.chk_Invert3.AutoSize = True
        Me.chk_Invert3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_Invert3.Location = New System.Drawing.Point(10, 144)
        Me.chk_Invert3.Name = "chk_Invert3"
        Me.chk_Invert3.Size = New System.Drawing.Size(50, 20)
        Me.chk_Invert3.TabIndex = 204
        Me.chk_Invert3.Text = " 3  "
        Me.chk_Invert3.UseVisualStyleBackColor = True
        '
        'chk_Invert2
        '
        Me.chk_Invert2.AutoSize = True
        Me.chk_Invert2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_Invert2.Location = New System.Drawing.Point(10, 125)
        Me.chk_Invert2.Name = "chk_Invert2"
        Me.chk_Invert2.Size = New System.Drawing.Size(50, 20)
        Me.chk_Invert2.TabIndex = 202
        Me.chk_Invert2.Text = " 2  "
        Me.chk_Invert2.UseVisualStyleBackColor = True
        '
        'chk_Invert1
        '
        Me.chk_Invert1.AutoSize = True
        Me.chk_Invert1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_Invert1.Location = New System.Drawing.Point(10, 106)
        Me.chk_Invert1.Name = "chk_Invert1"
        Me.chk_Invert1.Size = New System.Drawing.Size(50, 20)
        Me.chk_Invert1.TabIndex = 200
        Me.chk_Invert1.Text = " 1  "
        Me.chk_Invert1.UseVisualStyleBackColor = True
        '
        'Label_Delta
        '
        Me.Label_Delta.AutoSize = True
        Me.Label_Delta.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Delta.Location = New System.Drawing.Point(108, 71)
        Me.Label_Delta.Name = "Label_Delta"
        Me.Label_Delta.Size = New System.Drawing.Size(40, 14)
        Me.Label_Delta.TabIndex = 199
        Me.Label_Delta.Text = "Delta"
        '
        'Label_Inv
        '
        Me.Label_Inv.AutoSize = True
        Me.Label_Inv.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Inv.Location = New System.Drawing.Point(40, 71)
        Me.Label_Inv.Name = "Label_Inv"
        Me.Label_Inv.Size = New System.Drawing.Size(30, 14)
        Me.Label_Inv.TabIndex = 197
        Me.Label_Inv.Text = "Inv."
        '
        'chk_Invert0
        '
        Me.chk_Invert0.AutoSize = True
        Me.chk_Invert0.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_Invert0.Location = New System.Drawing.Point(10, 88)
        Me.chk_Invert0.Name = "chk_Invert0"
        Me.chk_Invert0.Size = New System.Drawing.Size(50, 20)
        Me.chk_Invert0.TabIndex = 196
        Me.chk_Invert0.Text = " 0  "
        Me.chk_Invert0.UseVisualStyleBackColor = True
        '
        'Panel_Delta
        '
        Me.Panel_Delta.Controls.Add(Me.txt_DeltaVerticalDist)
        Me.Panel_Delta.Controls.Add(Me.Label24)
        Me.Panel_Delta.Controls.Add(Me.txt_DeltaMotorArms)
        Me.Panel_Delta.Controls.Add(Me.Label23)
        Me.Panel_Delta.Controls.Add(Me.txt_DeltaVerticalArms)
        Me.Panel_Delta.Controls.Add(Me.Label22)
        Me.Panel_Delta.Controls.Add(Me.txt_DeltaMotorRadius)
        Me.Panel_Delta.Controls.Add(Me.Label21)
        Me.Panel_Delta.Controls.Add(Me.txt_DeltaEndRadius)
        Me.Panel_Delta.Controls.Add(Me.Label20)
        Me.Panel_Delta.Location = New System.Drawing.Point(25, 59)
        Me.Panel_Delta.Name = "Panel_Delta"
        Me.Panel_Delta.Size = New System.Drawing.Size(129, 102)
        Me.Panel_Delta.TabIndex = 215
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(4, 80)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(67, 14)
        Me.Label24.TabIndex = 219
        Me.Label24.Text = "Vert. dist."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(4, 61)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(78, 14)
        Me.Label23.TabIndex = 217
        Me.Label23.Text = "Motor arms"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(4, 42)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(71, 14)
        Me.Label22.TabIndex = 215
        Me.Label22.Text = "Vert. arms"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(4, 23)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(86, 14)
        Me.Label21.TabIndex = 213
        Me.Label21.Text = "Motor radius"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(4, 4)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 14)
        Me.Label20.TabIndex = 200
        Me.Label20.Text = "End radius"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(68, 56)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 14)
        Me.Label13.TabIndex = 193
        Me.Label13.Text = "Scale"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(232, 17)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(15, 14)
        Me.Label12.TabIndex = 191
        Me.Label12.Text = "Z"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(181, 17)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(14, 14)
        Me.Label11.TabIndex = 190
        Me.Label11.Text = "Y"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(130, 17)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(15, 14)
        Me.Label10.TabIndex = 189
        Me.Label10.Text = "X"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 14)
        Me.Label1.TabIndex = 186
        Me.Label1.Text = "Origin"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox4.Controls.Add(Me.btn_Steppers)
        Me.GroupBox4.Controls.Add(Me.txt_NumMotorSlots)
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Controls.Add(Me.txt_FirstMotorSlot)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo7)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo6)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo5)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo4)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo3)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo2)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo1)
        Me.GroupBox4.Controls.Add(Me.txt_AngleServo0)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo7)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo6)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo5)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo4)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo3)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo2)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo1)
        Me.GroupBox4.Controls.Add(Me.txt_TimeServo0)
        Me.GroupBox4.Controls.Add(Me.TrackBar7)
        Me.GroupBox4.Controls.Add(Me.TrackBar6)
        Me.GroupBox4.Controls.Add(Me.TrackBar5)
        Me.GroupBox4.Controls.Add(Me.TrackBar4)
        Me.GroupBox4.Controls.Add(Me.TrackBar3)
        Me.GroupBox4.Controls.Add(Me.TrackBar2)
        Me.GroupBox4.Controls.Add(Me.TrackBar1)
        Me.GroupBox4.Controls.Add(Me.TrackBar0)
        Me.GroupBox4.Font = New System.Drawing.Font("Verdana", 9.75!)
        Me.GroupBox4.Location = New System.Drawing.Point(296, 427)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(482, 150)
        Me.GroupBox4.TabIndex = 150
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Servo motors"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(12, 62)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(69, 14)
        Me.Label25.TabIndex = 236
        Me.Label25.Text = "Num slots"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 14)
        Me.Label4.TabIndex = 187
        Me.Label4.Text = "First slot"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(31, 125)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 14)
        Me.Label14.TabIndex = 233
        Me.Label14.Text = "Degree"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(47, 106)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 14)
        Me.Label6.TabIndex = 232
        Me.Label6.Text = "uSec"
        '
        'TrackBar7
        '
        Me.TrackBar7.LargeChange = 320
        Me.TrackBar7.Location = New System.Drawing.Point(428, 14)
        Me.TrackBar7.Maximum = 64000
        Me.TrackBar7.Name = "TrackBar7"
        Me.TrackBar7.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar7.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar7.SmallChange = 32
        Me.TrackBar7.TabIndex = 184
        Me.TrackBar7.TickFrequency = 16000
        Me.TrackBar7.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar6
        '
        Me.TrackBar6.LargeChange = 320
        Me.TrackBar6.Location = New System.Drawing.Point(380, 14)
        Me.TrackBar6.Maximum = 64000
        Me.TrackBar6.Name = "TrackBar6"
        Me.TrackBar6.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar6.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar6.SmallChange = 32
        Me.TrackBar6.TabIndex = 183
        Me.TrackBar6.TickFrequency = 16000
        Me.TrackBar6.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar5
        '
        Me.TrackBar5.LargeChange = 320
        Me.TrackBar5.Location = New System.Drawing.Point(332, 14)
        Me.TrackBar5.Maximum = 64000
        Me.TrackBar5.Name = "TrackBar5"
        Me.TrackBar5.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar5.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar5.SmallChange = 32
        Me.TrackBar5.TabIndex = 182
        Me.TrackBar5.TickFrequency = 16000
        Me.TrackBar5.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar4
        '
        Me.TrackBar4.LargeChange = 320
        Me.TrackBar4.Location = New System.Drawing.Point(284, 14)
        Me.TrackBar4.Maximum = 64000
        Me.TrackBar4.Name = "TrackBar4"
        Me.TrackBar4.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar4.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar4.SmallChange = 32
        Me.TrackBar4.TabIndex = 180
        Me.TrackBar4.TickFrequency = 16000
        Me.TrackBar4.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar3
        '
        Me.TrackBar3.LargeChange = 320
        Me.TrackBar3.Location = New System.Drawing.Point(236, 14)
        Me.TrackBar3.Maximum = 64000
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar3.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar3.SmallChange = 32
        Me.TrackBar3.TabIndex = 179
        Me.TrackBar3.TickFrequency = 16000
        Me.TrackBar3.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar3.Value = 32000
        '
        'TrackBar2
        '
        Me.TrackBar2.LargeChange = 320
        Me.TrackBar2.Location = New System.Drawing.Point(188, 14)
        Me.TrackBar2.Maximum = 64000
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar2.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar2.SmallChange = 32
        Me.TrackBar2.TabIndex = 178
        Me.TrackBar2.TickFrequency = 16000
        Me.TrackBar2.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar2.Value = 32000
        '
        'TrackBar1
        '
        Me.TrackBar1.LargeChange = 320
        Me.TrackBar1.Location = New System.Drawing.Point(140, 14)
        Me.TrackBar1.Maximum = 64000
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar1.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar1.SmallChange = 32
        Me.TrackBar1.TabIndex = 177
        Me.TrackBar1.TickFrequency = 16000
        Me.TrackBar1.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar1.Value = 32000
        '
        'TrackBar0
        '
        Me.TrackBar0.LargeChange = 320
        Me.TrackBar0.Location = New System.Drawing.Point(92, 14)
        Me.TrackBar0.Maximum = 64000
        Me.TrackBar0.Name = "TrackBar0"
        Me.TrackBar0.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar0.Size = New System.Drawing.Size(45, 90)
        Me.TrackBar0.SmallChange = 32
        Me.TrackBar0.TabIndex = 176
        Me.TrackBar0.TickFrequency = 16000
        Me.TrackBar0.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar0.Value = 32000
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox9.Controls.Add(Me.txt_ParkingZ)
        Me.GroupBox9.Controls.Add(Me.txt_ParkingY)
        Me.GroupBox9.Controls.Add(Me.txt_ParkingX)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Panel_Delta)
        Me.GroupBox9.Controls.Add(Me.txt_MinY)
        Me.GroupBox9.Controls.Add(Me.Label5)
        Me.GroupBox9.Controls.Add(Me.txt_MaxAreaX)
        Me.GroupBox9.Controls.Add(Me.Label17)
        Me.GroupBox9.Controls.Add(Me.txt_JogStep)
        Me.GroupBox9.Controls.Add(Me.Label2)
        Me.GroupBox9.Controls.Add(Me.Pic_ArmGeometry)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(296, 56)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(482, 365)
        Me.GroupBox9.TabIndex = 149
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Arm geometry"
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(12, 341)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(179, 14)
        Me.Label26.TabIndex = 216
        Me.Label26.Text = "Parking position (mm X Y Z)"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 319)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 14)
        Me.Label5.TabIndex = 213
        Me.Label5.Text = "MinY (mm)"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(298, 319)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(142, 14)
        Me.Label17.TabIndex = 209
        Me.Label17.Text = "Max view areaX (mm)"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(375, 341)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 14)
        Me.Label2.TabIndex = 208
        Me.Label2.Text = "Jog (mm)"
        '
        'Pic_ArmGeometry
        '
        Me.Pic_ArmGeometry.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pic_ArmGeometry.BackColor = System.Drawing.Color.AliceBlue
        Me.Pic_ArmGeometry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_ArmGeometry.Location = New System.Drawing.Point(12, 24)
        Me.Pic_ArmGeometry.Name = "Pic_ArmGeometry"
        Me.Pic_ArmGeometry.Size = New System.Drawing.Size(461, 288)
        Me.Pic_ArmGeometry.TabIndex = 153
        Me.Pic_ArmGeometry.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox2.Controls.Add(Me.chk_AutoSleep)
        Me.GroupBox2.Controls.Add(Me.chk_AutoParking)
        Me.GroupBox2.Controls.Add(Me.txt_GcodeAutomation)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.btn_OverrideZ)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txt_Zup)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txt_Zdown)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.txt_GcodeFile)
        Me.GroupBox2.Controls.Add(Me.txt_Ztrip)
        Me.GroupBox2.Controls.Add(Me.btn_GcodeLoad)
        Me.GroupBox2.Controls.Add(Me.txt_OriginX)
        Me.GroupBox2.Controls.Add(Me.btn_GcodeRun)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.btn_GcodeRewind)
        Me.GroupBox2.Controls.Add(Me.txt_GcodeLine)
        Me.GroupBox2.Controls.Add(Me.txt_OriginY)
        Me.GroupBox2.Controls.Add(Me.txt_OriginZ)
        Me.GroupBox2.Controls.Add(Me.txt_ScaleX)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txt_ScaleY)
        Me.GroupBox2.Controls.Add(Me.txt_ScaleZ)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(8, 319)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(281, 258)
        Me.GroupBox2.TabIndex = 210
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Gcode"
        '
        'chk_AutoSleep
        '
        Me.chk_AutoSleep.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AutoSleep.Checked = True
        Me.chk_AutoSleep.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_AutoSleep.Location = New System.Drawing.Point(48, 232)
        Me.chk_AutoSleep.Name = "chk_AutoSleep"
        Me.chk_AutoSleep.Size = New System.Drawing.Size(213, 19)
        Me.chk_AutoSleep.TabIndex = 236
        Me.chk_AutoSleep.Text = "Automatic motor sleep"
        Me.chk_AutoSleep.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AutoSleep.UseVisualStyleBackColor = True
        '
        'chk_AutoParking
        '
        Me.chk_AutoParking.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AutoParking.Checked = True
        Me.chk_AutoParking.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_AutoParking.Location = New System.Drawing.Point(48, 212)
        Me.chk_AutoParking.Name = "chk_AutoParking"
        Me.chk_AutoParking.Size = New System.Drawing.Size(213, 19)
        Me.chk_AutoParking.TabIndex = 235
        Me.chk_AutoParking.Text = "Automatic parking position"
        Me.chk_AutoParking.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AutoParking.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(73, 193)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(149, 14)
        Me.Label19.TabIndex = 226
        Me.Label19.Text = "Gcode automation slot"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(184, 86)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 14)
        Me.Label9.TabIndex = 222
        Me.Label9.Text = "Zup"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(165, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 14)
        Me.Label8.TabIndex = 220
        Me.Label8.Text = "Zdown"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(29, 110)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 14)
        Me.Label7.TabIndex = 218
        Me.Label7.Text = "Z trip level"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox3.Controls.Add(Me.txt_MaxError)
        Me.GroupBox3.Controls.Add(Me.txt_FeedWork)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txt_FeedRapid)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(8, 239)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(281, 74)
        Me.GroupBox3.TabIndex = 211
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Feed and precision"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(197, 25)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(67, 14)
        Me.Label18.TabIndex = 214
        Me.Label18.Text = "Max error"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(18, 47)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(102, 14)
        Me.Label16.TabIndex = 212
        Me.Label16.Text = "Work (mm/min)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(16, 26)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(105, 14)
        Me.Label15.TabIndex = 210
        Me.Label15.Text = "Rapid (mm/min)"
        '
        'Timer1
        '
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(786, 24)
        Me.MenuStrip1.TabIndex = 212
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_LoadConfiguration, Me.Menu_File_SaveConfigurationAs, Me.ToolStripSeparator6, Me.Menu_File_SaveImage, Me.ToolStripSeparator2, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_LoadConfiguration
        '
        Me.Menu_File_LoadConfiguration.Image = CType(resources.GetObject("Menu_File_LoadConfiguration.Image"), System.Drawing.Image)
        Me.Menu_File_LoadConfiguration.Name = "Menu_File_LoadConfiguration"
        Me.Menu_File_LoadConfiguration.Size = New System.Drawing.Size(187, 22)
        Me.Menu_File_LoadConfiguration.Text = "Load configuration"
        '
        'Menu_File_SaveConfigurationAs
        '
        Me.Menu_File_SaveConfigurationAs.Image = CType(resources.GetObject("Menu_File_SaveConfigurationAs.Image"), System.Drawing.Image)
        Me.Menu_File_SaveConfigurationAs.Name = "Menu_File_SaveConfigurationAs"
        Me.Menu_File_SaveConfigurationAs.Size = New System.Drawing.Size(187, 22)
        Me.Menu_File_SaveConfigurationAs.Text = "Save configuration as"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(184, 6)
        '
        'Menu_File_SaveImage
        '
        Me.Menu_File_SaveImage.Image = CType(resources.GetObject("Menu_File_SaveImage.Image"), System.Drawing.Image)
        Me.Menu_File_SaveImage.Name = "Menu_File_SaveImage"
        Me.Menu_File_SaveImage.Size = New System.Drawing.Size(187, 22)
        Me.Menu_File_SaveImage.Text = "Save image"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(184, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(187, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.ToDoListToolStripMenuItem})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(151, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program helps"
        '
        'ToDoListToolStripMenuItem
        '
        Me.ToDoListToolStripMenuItem.Name = "ToDoListToolStripMenuItem"
        Me.ToDoListToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.ToDoListToolStripMenuItem.Text = "ToDo list"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_LoadConfiguration, Me.ToolStripSeparator3, Me.ToolStripButton_SaveConfiguration, Me.ToolStripSeparator7, Me.ToolStripButton_SaveImage, Me.ToolStripSeparator5})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(786, 25)
        Me.ToolStrip1.TabIndex = 213
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_LoadConfiguration
        '
        Me.ToolStripButton_LoadConfiguration.Image = CType(resources.GetObject("ToolStripButton_LoadConfiguration.Image"), System.Drawing.Image)
        Me.ToolStripButton_LoadConfiguration.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_LoadConfiguration.Name = "ToolStripButton_LoadConfiguration"
        Me.ToolStripButton_LoadConfiguration.Size = New System.Drawing.Size(128, 22)
        Me.ToolStripButton_LoadConfiguration.Text = "Load configuration"
        Me.ToolStripButton_LoadConfiguration.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_SaveConfiguration
        '
        Me.ToolStripButton_SaveConfiguration.Image = CType(resources.GetObject("ToolStripButton_SaveConfiguration.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveConfiguration.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveConfiguration.Name = "ToolStripButton_SaveConfiguration"
        Me.ToolStripButton_SaveConfiguration.Size = New System.Drawing.Size(140, 22)
        Me.ToolStripButton_SaveConfiguration.Text = "Save configuration as"
        Me.ToolStripButton_SaveConfiguration.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_SaveImage
        '
        Me.ToolStripButton_SaveImage.Image = CType(resources.GetObject("ToolStripButton_SaveImage.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveImage.Name = "ToolStripButton_SaveImage"
        Me.ToolStripButton_SaveImage.Size = New System.Drawing.Size(87, 22)
        Me.ToolStripButton_SaveImage.Text = "Save image"
        Me.ToolStripButton_SaveImage.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 584)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(786, 22)
        Me.StatusStrip1.TabIndex = 214
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(700, 17)
        '
        'Timer2
        '
        '
        'txt_GcodeAutomation
        '
        Me.txt_GcodeAutomation.ArrowsIncrement = 1
        Me.txt_GcodeAutomation.BackColor = System.Drawing.Color.MintCream
        Me.txt_GcodeAutomation.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_GcodeAutomation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_GcodeAutomation.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_GcodeAutomation.ForeColor = System.Drawing.Color.Black
        Me.txt_GcodeAutomation.Increment = 0.2
        Me.txt_GcodeAutomation.Location = New System.Drawing.Point(226, 191)
        Me.txt_GcodeAutomation.MaxValue = 990
        Me.txt_GcodeAutomation.MinValue = 0
        Me.txt_GcodeAutomation.Multiline = True
        Me.txt_GcodeAutomation.Name = "txt_GcodeAutomation"
        Me.txt_GcodeAutomation.NumericValue = 1
        Me.txt_GcodeAutomation.NumericValueInteger = 1
        Me.txt_GcodeAutomation.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_GcodeAutomation.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_GcodeAutomation.RoundingStep = 0
        Me.txt_GcodeAutomation.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_GcodeAutomation.Size = New System.Drawing.Size(38, 17)
        Me.txt_GcodeAutomation.SuppressZeros = True
        Me.txt_GcodeAutomation.TabIndex = 225
        Me.txt_GcodeAutomation.Text = "1"
        Me.txt_GcodeAutomation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_OverrideZ
        '
        Me.btn_OverrideZ.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_OverrideZ.CenterPtTracker = DesignerRectTracker3
        Me.btn_OverrideZ.CheckButton = True
        Me.btn_OverrideZ.Checked = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_OverrideZ.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_OverrideZ.ColorFillBlendChecked = CBlendItems4
        Me.btn_OverrideZ.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_OverrideZ.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_OverrideZ.Corners.All = CType(6, Short)
        Me.btn_OverrideZ.Corners.LowerLeft = CType(6, Short)
        Me.btn_OverrideZ.Corners.LowerRight = CType(6, Short)
        Me.btn_OverrideZ.Corners.UpperLeft = CType(6, Short)
        Me.btn_OverrideZ.Corners.UpperRight = CType(6, Short)
        Me.btn_OverrideZ.DimFactorOver = 30
        Me.btn_OverrideZ.FillType = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_OverrideZ.FillTypeChecked = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_OverrideZ.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_OverrideZ.FocalPoints.CenterPtY = 1.0!
        Me.btn_OverrideZ.FocalPoints.FocusPtX = 0.0!
        Me.btn_OverrideZ.FocalPoints.FocusPtY = 0.0!
        Me.btn_OverrideZ.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_OverrideZ.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_OverrideZ.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_OverrideZ.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_OverrideZ.FocusPtTracker = DesignerRectTracker4
        Me.btn_OverrideZ.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_OverrideZ.Image = Nothing
        Me.btn_OverrideZ.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OverrideZ.ImageIndex = 0
        Me.btn_OverrideZ.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_OverrideZ.Location = New System.Drawing.Point(32, 85)
        Me.btn_OverrideZ.Name = "btn_OverrideZ"
        Me.btn_OverrideZ.Shape = Theremino_Arm.MyButton.eShape.Rectangle
        Me.btn_OverrideZ.SideImage = Nothing
        Me.btn_OverrideZ.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OverrideZ.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_OverrideZ.Size = New System.Drawing.Size(120, 19)
        Me.btn_OverrideZ.TabIndex = 224
        Me.btn_OverrideZ.Text = "Override Z"
        Me.btn_OverrideZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OverrideZ.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_OverrideZ.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_OverrideZ.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_Zup
        '
        Me.txt_Zup.ArrowsIncrement = 1
        Me.txt_Zup.BackColor = System.Drawing.Color.MintCream
        Me.txt_Zup.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Zup.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Zup.Decimals = 1
        Me.txt_Zup.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Zup.ForeColor = System.Drawing.Color.Black
        Me.txt_Zup.Increment = 0.05
        Me.txt_Zup.Location = New System.Drawing.Point(218, 85)
        Me.txt_Zup.MaxValue = 99
        Me.txt_Zup.MinValue = -99
        Me.txt_Zup.Multiline = True
        Me.txt_Zup.Name = "txt_Zup"
        Me.txt_Zup.NumericValue = 4
        Me.txt_Zup.NumericValueInteger = 4
        Me.txt_Zup.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Zup.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Zup.RoundingStep = 0
        Me.txt_Zup.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Zup.Size = New System.Drawing.Size(46, 17)
        Me.txt_Zup.SuppressZeros = True
        Me.txt_Zup.TabIndex = 223
        Me.txt_Zup.Text = "4"
        Me.txt_Zup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Zdown
        '
        Me.txt_Zdown.ArrowsIncrement = 1
        Me.txt_Zdown.BackColor = System.Drawing.Color.MintCream
        Me.txt_Zdown.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Zdown.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Zdown.Decimals = 1
        Me.txt_Zdown.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Zdown.ForeColor = System.Drawing.Color.Black
        Me.txt_Zdown.Increment = 0.05
        Me.txt_Zdown.Location = New System.Drawing.Point(218, 109)
        Me.txt_Zdown.MaxValue = 99
        Me.txt_Zdown.MinValue = -99
        Me.txt_Zdown.Multiline = True
        Me.txt_Zdown.Name = "txt_Zdown"
        Me.txt_Zdown.NumericValue = 0
        Me.txt_Zdown.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Zdown.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Zdown.RoundingStep = 0
        Me.txt_Zdown.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Zdown.Size = New System.Drawing.Size(46, 17)
        Me.txt_Zdown.SuppressZeros = True
        Me.txt_Zdown.TabIndex = 221
        Me.txt_Zdown.Text = "0"
        Me.txt_Zdown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_GcodeFile
        '
        Me.txt_GcodeFile.ArrowsIncrement = 0
        Me.txt_GcodeFile.BackColor = System.Drawing.Color.MintCream
        Me.txt_GcodeFile.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_GcodeFile.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_GcodeFile.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_GcodeFile.ForeColor = System.Drawing.Color.Black
        Me.txt_GcodeFile.Increment = 0
        Me.txt_GcodeFile.Location = New System.Drawing.Point(17, 166)
        Me.txt_GcodeFile.MaxValue = 0
        Me.txt_GcodeFile.MinValue = 0
        Me.txt_GcodeFile.Name = "txt_GcodeFile"
        Me.txt_GcodeFile.NumericValue = 0
        Me.txt_GcodeFile.ReadOnly = True
        Me.txt_GcodeFile.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_GcodeFile.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_GcodeFile.RoundingStep = 0
        Me.txt_GcodeFile.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_GcodeFile.Size = New System.Drawing.Size(247, 16)
        Me.txt_GcodeFile.TabIndex = 217
        Me.txt_GcodeFile.Text = "0"
        Me.txt_GcodeFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_GcodeFile.WordWrap = False
        '
        'txt_Ztrip
        '
        Me.txt_Ztrip.ArrowsIncrement = 1
        Me.txt_Ztrip.BackColor = System.Drawing.Color.MintCream
        Me.txt_Ztrip.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Ztrip.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Ztrip.Decimals = 1
        Me.txt_Ztrip.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Ztrip.ForeColor = System.Drawing.Color.Black
        Me.txt_Ztrip.Increment = 0.05
        Me.txt_Ztrip.Location = New System.Drawing.Point(106, 109)
        Me.txt_Ztrip.MaxValue = 99
        Me.txt_Ztrip.MinValue = -99
        Me.txt_Ztrip.Multiline = True
        Me.txt_Ztrip.Name = "txt_Ztrip"
        Me.txt_Ztrip.NumericValue = 0.5
        Me.txt_Ztrip.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Ztrip.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Ztrip.RoundingStep = 0
        Me.txt_Ztrip.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Ztrip.Size = New System.Drawing.Size(46, 17)
        Me.txt_Ztrip.SuppressZeros = True
        Me.txt_Ztrip.TabIndex = 219
        Me.txt_Ztrip.Text = "0.5"
        Me.txt_Ztrip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_GcodeLoad
        '
        Me.btn_GcodeLoad.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeLoad.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeLoad.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeLoad.ColorFillBlendChecked = CBlendItems6
        Me.btn_GcodeLoad.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GcodeLoad.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GcodeLoad.Corners.All = CType(6, Short)
        Me.btn_GcodeLoad.Corners.LowerLeft = CType(6, Short)
        Me.btn_GcodeLoad.Corners.LowerRight = CType(6, Short)
        Me.btn_GcodeLoad.Corners.UpperLeft = CType(6, Short)
        Me.btn_GcodeLoad.Corners.UpperRight = CType(6, Short)
        Me.btn_GcodeLoad.DimFactorOver = 30
        Me.btn_GcodeLoad.FillType = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeLoad.FillTypeChecked = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeLoad.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeLoad.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeLoad.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeLoad.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = True
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeLoad.FocusPtTracker = DesignerRectTracker6
        Me.btn_GcodeLoad.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeLoad.Image = Nothing
        Me.btn_GcodeLoad.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.ImageIndex = 0
        Me.btn_GcodeLoad.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeLoad.Location = New System.Drawing.Point(19, 142)
        Me.btn_GcodeLoad.Name = "btn_GcodeLoad"
        Me.btn_GcodeLoad.Shape = Theremino_Arm.MyButton.eShape.Rectangle
        Me.btn_GcodeLoad.SideImage = Nothing
        Me.btn_GcodeLoad.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeLoad.Size = New System.Drawing.Size(55, 19)
        Me.btn_GcodeLoad.TabIndex = 216
        Me.btn_GcodeLoad.Text = "Load"
        Me.btn_GcodeLoad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeLoad.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_GcodeLoad.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_OriginX
        '
        Me.txt_OriginX.ArrowsIncrement = 1
        Me.txt_OriginX.BackColor = System.Drawing.Color.MintCream
        Me.txt_OriginX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_OriginX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_OriginX.Decimals = 1
        Me.txt_OriginX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_OriginX.ForeColor = System.Drawing.Color.Black
        Me.txt_OriginX.Increment = 0.05
        Me.txt_OriginX.Location = New System.Drawing.Point(114, 34)
        Me.txt_OriginX.MaxValue = 9999
        Me.txt_OriginX.MinValue = -9999
        Me.txt_OriginX.Multiline = True
        Me.txt_OriginX.Name = "txt_OriginX"
        Me.txt_OriginX.NumericValue = 0
        Me.txt_OriginX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_OriginX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_OriginX.RoundingStep = 0
        Me.txt_OriginX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_OriginX.Size = New System.Drawing.Size(46, 17)
        Me.txt_OriginX.SuppressZeros = True
        Me.txt_OriginX.TabIndex = 185
        Me.txt_OriginX.Text = "0"
        Me.txt_OriginX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_GcodeRun
        '
        Me.btn_GcodeRun.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRun.CenterPtTracker = DesignerRectTracker7
        Me.btn_GcodeRun.CheckButton = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeRun.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeRun.ColorFillBlendChecked = CBlendItems8
        Me.btn_GcodeRun.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GcodeRun.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GcodeRun.Corners.All = CType(6, Short)
        Me.btn_GcodeRun.Corners.LowerLeft = CType(6, Short)
        Me.btn_GcodeRun.Corners.LowerRight = CType(6, Short)
        Me.btn_GcodeRun.Corners.UpperLeft = CType(6, Short)
        Me.btn_GcodeRun.Corners.UpperRight = CType(6, Short)
        Me.btn_GcodeRun.DimFactorOver = 30
        Me.btn_GcodeRun.FillType = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRun.FillTypeChecked = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRun.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeRun.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeRun.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeRun.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeRun.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GcodeRun.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GcodeRun.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeRun.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRun.FocusPtTracker = DesignerRectTracker8
        Me.btn_GcodeRun.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeRun.Image = Nothing
        Me.btn_GcodeRun.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRun.ImageIndex = 0
        Me.btn_GcodeRun.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeRun.Location = New System.Drawing.Point(144, 142)
        Me.btn_GcodeRun.Name = "btn_GcodeRun"
        Me.btn_GcodeRun.Shape = Theremino_Arm.MyButton.eShape.Rectangle
        Me.btn_GcodeRun.SideImage = Nothing
        Me.btn_GcodeRun.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRun.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeRun.Size = New System.Drawing.Size(55, 19)
        Me.btn_GcodeRun.TabIndex = 182
        Me.btn_GcodeRun.Text = "Run"
        Me.btn_GcodeRun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRun.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeRun.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_GcodeRun.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_GcodeRewind
        '
        Me.btn_GcodeRewind.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRewind.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeRewind.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeRewind.ColorFillBlendChecked = CBlendItems10
        Me.btn_GcodeRewind.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GcodeRewind.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GcodeRewind.Corners.All = CType(6, Short)
        Me.btn_GcodeRewind.Corners.LowerLeft = CType(6, Short)
        Me.btn_GcodeRewind.Corners.LowerRight = CType(6, Short)
        Me.btn_GcodeRewind.Corners.UpperLeft = CType(6, Short)
        Me.btn_GcodeRewind.Corners.UpperRight = CType(6, Short)
        Me.btn_GcodeRewind.DimFactorOver = 30
        Me.btn_GcodeRewind.FillType = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRewind.FillTypeChecked = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRewind.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeRewind.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeRewind.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeRewind.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeRewind.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GcodeRewind.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GcodeRewind.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeRewind.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRewind.FocusPtTracker = DesignerRectTracker10
        Me.btn_GcodeRewind.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeRewind.Image = Nothing
        Me.btn_GcodeRewind.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.ImageIndex = 0
        Me.btn_GcodeRewind.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeRewind.Location = New System.Drawing.Point(81, 142)
        Me.btn_GcodeRewind.Name = "btn_GcodeRewind"
        Me.btn_GcodeRewind.Shape = Theremino_Arm.MyButton.eShape.Rectangle
        Me.btn_GcodeRewind.SideImage = Nothing
        Me.btn_GcodeRewind.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeRewind.Size = New System.Drawing.Size(55, 19)
        Me.btn_GcodeRewind.TabIndex = 165
        Me.btn_GcodeRewind.Text = "Rewind"
        Me.btn_GcodeRewind.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeRewind.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_GcodeRewind.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_GcodeLine
        '
        Me.txt_GcodeLine.ArrowsIncrement = 1
        Me.txt_GcodeLine.BackColor = System.Drawing.Color.MintCream
        Me.txt_GcodeLine.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_GcodeLine.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_GcodeLine.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_GcodeLine.ForeColor = System.Drawing.Color.Black
        Me.txt_GcodeLine.Increment = 1
        Me.txt_GcodeLine.Location = New System.Drawing.Point(206, 144)
        Me.txt_GcodeLine.MaxValue = 999999999
        Me.txt_GcodeLine.MinValue = 0
        Me.txt_GcodeLine.Multiline = True
        Me.txt_GcodeLine.Name = "txt_GcodeLine"
        Me.txt_GcodeLine.NumericValue = 0
        Me.txt_GcodeLine.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_GcodeLine.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_GcodeLine.RoundingStep = 0
        Me.txt_GcodeLine.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_GcodeLine.Size = New System.Drawing.Size(57, 17)
        Me.txt_GcodeLine.SuppressZeros = True
        Me.txt_GcodeLine.TabIndex = 184
        Me.txt_GcodeLine.Text = "0"
        Me.txt_GcodeLine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_OriginY
        '
        Me.txt_OriginY.ArrowsIncrement = 1
        Me.txt_OriginY.BackColor = System.Drawing.Color.MintCream
        Me.txt_OriginY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_OriginY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_OriginY.Decimals = 1
        Me.txt_OriginY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_OriginY.ForeColor = System.Drawing.Color.Black
        Me.txt_OriginY.Increment = 0.05
        Me.txt_OriginY.Location = New System.Drawing.Point(166, 34)
        Me.txt_OriginY.MaxValue = 9999
        Me.txt_OriginY.MinValue = -9999
        Me.txt_OriginY.Multiline = True
        Me.txt_OriginY.Name = "txt_OriginY"
        Me.txt_OriginY.NumericValue = 0
        Me.txt_OriginY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_OriginY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_OriginY.RoundingStep = 0
        Me.txt_OriginY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_OriginY.Size = New System.Drawing.Size(46, 17)
        Me.txt_OriginY.SuppressZeros = True
        Me.txt_OriginY.TabIndex = 187
        Me.txt_OriginY.Text = "0"
        Me.txt_OriginY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_OriginZ
        '
        Me.txt_OriginZ.ArrowsIncrement = 1
        Me.txt_OriginZ.BackColor = System.Drawing.Color.MintCream
        Me.txt_OriginZ.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_OriginZ.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_OriginZ.Decimals = 1
        Me.txt_OriginZ.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_OriginZ.ForeColor = System.Drawing.Color.Black
        Me.txt_OriginZ.Increment = 0.05
        Me.txt_OriginZ.Location = New System.Drawing.Point(218, 34)
        Me.txt_OriginZ.MaxValue = 9999
        Me.txt_OriginZ.MinValue = -9999
        Me.txt_OriginZ.Multiline = True
        Me.txt_OriginZ.Name = "txt_OriginZ"
        Me.txt_OriginZ.NumericValue = 0
        Me.txt_OriginZ.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_OriginZ.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_OriginZ.RoundingStep = 0
        Me.txt_OriginZ.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_OriginZ.Size = New System.Drawing.Size(46, 17)
        Me.txt_OriginZ.SuppressZeros = True
        Me.txt_OriginZ.TabIndex = 188
        Me.txt_OriginZ.Text = "0"
        Me.txt_OriginZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ScaleX
        '
        Me.txt_ScaleX.ArrowsIncrement = 0.01
        Me.txt_ScaleX.BackColor = System.Drawing.Color.MintCream
        Me.txt_ScaleX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ScaleX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ScaleX.Decimals = 2
        Me.txt_ScaleX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ScaleX.ForeColor = System.Drawing.Color.Black
        Me.txt_ScaleX.Increment = 0.01
        Me.txt_ScaleX.Location = New System.Drawing.Point(114, 54)
        Me.txt_ScaleX.MaxValue = 9999
        Me.txt_ScaleX.MinValue = -9999
        Me.txt_ScaleX.Multiline = True
        Me.txt_ScaleX.Name = "txt_ScaleX"
        Me.txt_ScaleX.NumericValue = 1
        Me.txt_ScaleX.NumericValueInteger = 1
        Me.txt_ScaleX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ScaleX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ScaleX.RoundingStep = 0
        Me.txt_ScaleX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ScaleX.Size = New System.Drawing.Size(46, 17)
        Me.txt_ScaleX.SuppressZeros = True
        Me.txt_ScaleX.TabIndex = 192
        Me.txt_ScaleX.Text = "1"
        Me.txt_ScaleX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ScaleY
        '
        Me.txt_ScaleY.ArrowsIncrement = 0.01
        Me.txt_ScaleY.BackColor = System.Drawing.Color.MintCream
        Me.txt_ScaleY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ScaleY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ScaleY.Decimals = 2
        Me.txt_ScaleY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ScaleY.ForeColor = System.Drawing.Color.Black
        Me.txt_ScaleY.Increment = 0.01
        Me.txt_ScaleY.Location = New System.Drawing.Point(166, 54)
        Me.txt_ScaleY.MaxValue = 9999
        Me.txt_ScaleY.MinValue = -9999
        Me.txt_ScaleY.Multiline = True
        Me.txt_ScaleY.Name = "txt_ScaleY"
        Me.txt_ScaleY.NumericValue = 1
        Me.txt_ScaleY.NumericValueInteger = 1
        Me.txt_ScaleY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ScaleY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ScaleY.RoundingStep = 0
        Me.txt_ScaleY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ScaleY.Size = New System.Drawing.Size(46, 17)
        Me.txt_ScaleY.SuppressZeros = True
        Me.txt_ScaleY.TabIndex = 194
        Me.txt_ScaleY.Text = "1"
        Me.txt_ScaleY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ScaleZ
        '
        Me.txt_ScaleZ.ArrowsIncrement = 0.01
        Me.txt_ScaleZ.BackColor = System.Drawing.Color.MintCream
        Me.txt_ScaleZ.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ScaleZ.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ScaleZ.Decimals = 2
        Me.txt_ScaleZ.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ScaleZ.ForeColor = System.Drawing.Color.Black
        Me.txt_ScaleZ.Increment = 0.01
        Me.txt_ScaleZ.Location = New System.Drawing.Point(218, 54)
        Me.txt_ScaleZ.MaxValue = 9999
        Me.txt_ScaleZ.MinValue = -9999
        Me.txt_ScaleZ.Multiline = True
        Me.txt_ScaleZ.Name = "txt_ScaleZ"
        Me.txt_ScaleZ.NumericValue = 1
        Me.txt_ScaleZ.NumericValueInteger = 1
        Me.txt_ScaleZ.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ScaleZ.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ScaleZ.RoundingStep = 0
        Me.txt_ScaleZ.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ScaleZ.Size = New System.Drawing.Size(46, 17)
        Me.txt_ScaleZ.SuppressZeros = True
        Me.txt_ScaleZ.TabIndex = 195
        Me.txt_ScaleZ.Text = "1"
        Me.txt_ScaleZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_MaxError
        '
        Me.txt_MaxError.ArrowsIncrement = 0.1
        Me.txt_MaxError.BackColor = System.Drawing.Color.MintCream
        Me.txt_MaxError.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxError.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxError.Decimals = 1
        Me.txt_MaxError.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxError.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxError.Increment = 0.02
        Me.txt_MaxError.Location = New System.Drawing.Point(216, 44)
        Me.txt_MaxError.MaxValue = 5
        Me.txt_MaxError.MinValue = 0.1
        Me.txt_MaxError.Multiline = True
        Me.txt_MaxError.Name = "txt_MaxError"
        Me.txt_MaxError.NumericValue = 1
        Me.txt_MaxError.NumericValueInteger = 1
        Me.txt_MaxError.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxError.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxError.RoundingStep = 0
        Me.txt_MaxError.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxError.Size = New System.Drawing.Size(36, 17)
        Me.txt_MaxError.SuppressZeros = True
        Me.txt_MaxError.TabIndex = 213
        Me.txt_MaxError.Text = "1"
        Me.txt_MaxError.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_FeedWork
        '
        Me.txt_FeedWork.ArrowsIncrement = 1000
        Me.txt_FeedWork.BackColor = System.Drawing.Color.MintCream
        Me.txt_FeedWork.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FeedWork.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FeedWork.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FeedWork.ForeColor = System.Drawing.Color.Black
        Me.txt_FeedWork.Increment = 100
        Me.txt_FeedWork.Location = New System.Drawing.Point(119, 46)
        Me.txt_FeedWork.MaxValue = 50000
        Me.txt_FeedWork.MinValue = 1000
        Me.txt_FeedWork.Multiline = True
        Me.txt_FeedWork.Name = "txt_FeedWork"
        Me.txt_FeedWork.NumericValue = 5000
        Me.txt_FeedWork.NumericValueInteger = 5000
        Me.txt_FeedWork.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FeedWork.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FeedWork.RoundingStep = 1000
        Me.txt_FeedWork.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FeedWork.Size = New System.Drawing.Size(50, 17)
        Me.txt_FeedWork.SuppressZeros = True
        Me.txt_FeedWork.TabIndex = 211
        Me.txt_FeedWork.Text = "5000"
        Me.txt_FeedWork.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_FeedRapid
        '
        Me.txt_FeedRapid.ArrowsIncrement = 1000
        Me.txt_FeedRapid.BackColor = System.Drawing.Color.MintCream
        Me.txt_FeedRapid.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FeedRapid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FeedRapid.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FeedRapid.ForeColor = System.Drawing.Color.Black
        Me.txt_FeedRapid.Increment = 100
        Me.txt_FeedRapid.Location = New System.Drawing.Point(119, 25)
        Me.txt_FeedRapid.MaxValue = 50000
        Me.txt_FeedRapid.MinValue = 1000
        Me.txt_FeedRapid.Multiline = True
        Me.txt_FeedRapid.Name = "txt_FeedRapid"
        Me.txt_FeedRapid.NumericValue = 5000
        Me.txt_FeedRapid.NumericValueInteger = 5000
        Me.txt_FeedRapid.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FeedRapid.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FeedRapid.RoundingStep = 1000
        Me.txt_FeedRapid.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FeedRapid.Size = New System.Drawing.Size(50, 17)
        Me.txt_FeedRapid.SuppressZeros = True
        Me.txt_FeedRapid.TabIndex = 209
        Me.txt_FeedRapid.Text = "5000"
        Me.txt_FeedRapid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Rapp3
        '
        Me.txt_Rapp3.ArrowsIncrement = 0.1
        Me.txt_Rapp3.BackColor = System.Drawing.Color.MintCream
        Me.txt_Rapp3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Rapp3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapp3.Decimals = 1
        Me.txt_Rapp3.Enabled = False
        Me.txt_Rapp3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapp3.ForeColor = System.Drawing.Color.Black
        Me.txt_Rapp3.Increment = 0.05
        Me.txt_Rapp3.Location = New System.Drawing.Point(70, 144)
        Me.txt_Rapp3.MaxValue = 180
        Me.txt_Rapp3.MinValue = -180
        Me.txt_Rapp3.Multiline = True
        Me.txt_Rapp3.Name = "txt_Rapp3"
        Me.txt_Rapp3.NumericValue = 0
        Me.txt_Rapp3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Rapp3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Rapp3.RoundingStep = 0
        Me.txt_Rapp3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Rapp3.Size = New System.Drawing.Size(34, 17)
        Me.txt_Rapp3.SuppressZeros = True
        Me.txt_Rapp3.TabIndex = 226
        Me.txt_Rapp3.Text = "0"
        Me.txt_Rapp3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Rapp2
        '
        Me.txt_Rapp2.ArrowsIncrement = 0.1
        Me.txt_Rapp2.BackColor = System.Drawing.Color.MintCream
        Me.txt_Rapp2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Rapp2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapp2.Decimals = 1
        Me.txt_Rapp2.Enabled = False
        Me.txt_Rapp2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapp2.ForeColor = System.Drawing.Color.Black
        Me.txt_Rapp2.Increment = 0.05
        Me.txt_Rapp2.Location = New System.Drawing.Point(70, 125)
        Me.txt_Rapp2.MaxValue = 180
        Me.txt_Rapp2.MinValue = -180
        Me.txt_Rapp2.Multiline = True
        Me.txt_Rapp2.Name = "txt_Rapp2"
        Me.txt_Rapp2.NumericValue = 0
        Me.txt_Rapp2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Rapp2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Rapp2.RoundingStep = 0
        Me.txt_Rapp2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Rapp2.Size = New System.Drawing.Size(34, 17)
        Me.txt_Rapp2.SuppressZeros = True
        Me.txt_Rapp2.TabIndex = 225
        Me.txt_Rapp2.Text = "0"
        Me.txt_Rapp2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Rapp1
        '
        Me.txt_Rapp1.ArrowsIncrement = 0.1
        Me.txt_Rapp1.BackColor = System.Drawing.Color.MintCream
        Me.txt_Rapp1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Rapp1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapp1.Decimals = 1
        Me.txt_Rapp1.Enabled = False
        Me.txt_Rapp1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapp1.ForeColor = System.Drawing.Color.Black
        Me.txt_Rapp1.Increment = 0.05
        Me.txt_Rapp1.Location = New System.Drawing.Point(70, 106)
        Me.txt_Rapp1.MaxValue = 180
        Me.txt_Rapp1.MinValue = -180
        Me.txt_Rapp1.Multiline = True
        Me.txt_Rapp1.Name = "txt_Rapp1"
        Me.txt_Rapp1.NumericValue = 0
        Me.txt_Rapp1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Rapp1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Rapp1.RoundingStep = 0
        Me.txt_Rapp1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Rapp1.Size = New System.Drawing.Size(34, 17)
        Me.txt_Rapp1.SuppressZeros = True
        Me.txt_Rapp1.TabIndex = 224
        Me.txt_Rapp1.Text = "0"
        Me.txt_Rapp1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Rapp0
        '
        Me.txt_Rapp0.ArrowsIncrement = 0.1
        Me.txt_Rapp0.BackColor = System.Drawing.Color.MintCream
        Me.txt_Rapp0.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Rapp0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapp0.Decimals = 1
        Me.txt_Rapp0.Enabled = False
        Me.txt_Rapp0.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapp0.ForeColor = System.Drawing.Color.Black
        Me.txt_Rapp0.Increment = 0.05
        Me.txt_Rapp0.Location = New System.Drawing.Point(70, 88)
        Me.txt_Rapp0.MaxValue = 180
        Me.txt_Rapp0.MinValue = -180
        Me.txt_Rapp0.Multiline = True
        Me.txt_Rapp0.Name = "txt_Rapp0"
        Me.txt_Rapp0.NumericValue = 0
        Me.txt_Rapp0.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Rapp0.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Rapp0.RoundingStep = 0
        Me.txt_Rapp0.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Rapp0.Size = New System.Drawing.Size(34, 17)
        Me.txt_Rapp0.SuppressZeros = True
        Me.txt_Rapp0.TabIndex = 222
        Me.txt_Rapp0.Text = "0"
        Me.txt_Rapp0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len2Z
        '
        Me.txt_Len2Z.ArrowsIncrement = 0.1
        Me.txt_Len2Z.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len2Z.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len2Z.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len2Z.Decimals = 1
        Me.txt_Len2Z.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len2Z.ForeColor = System.Drawing.Color.Black
        Me.txt_Len2Z.Increment = 0.05
        Me.txt_Len2Z.Location = New System.Drawing.Point(234, 125)
        Me.txt_Len2Z.MaxValue = 999
        Me.txt_Len2Z.MinValue = -999
        Me.txt_Len2Z.Multiline = True
        Me.txt_Len2Z.Name = "txt_Len2Z"
        Me.txt_Len2Z.NumericValue = 1
        Me.txt_Len2Z.NumericValueInteger = 1
        Me.txt_Len2Z.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len2Z.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len2Z.RoundingStep = 0
        Me.txt_Len2Z.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len2Z.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len2Z.SuppressZeros = True
        Me.txt_Len2Z.TabIndex = 221
        Me.txt_Len2Z.Text = "1"
        Me.txt_Len2Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len2X
        '
        Me.txt_Len2X.ArrowsIncrement = 0.1
        Me.txt_Len2X.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len2X.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len2X.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len2X.Decimals = 1
        Me.txt_Len2X.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len2X.ForeColor = System.Drawing.Color.Black
        Me.txt_Len2X.Increment = 0.05
        Me.txt_Len2X.Location = New System.Drawing.Point(149, 125)
        Me.txt_Len2X.MaxValue = 999
        Me.txt_Len2X.MinValue = -999
        Me.txt_Len2X.Multiline = True
        Me.txt_Len2X.Name = "txt_Len2X"
        Me.txt_Len2X.NumericValue = 1
        Me.txt_Len2X.NumericValueInteger = 1
        Me.txt_Len2X.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len2X.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len2X.RoundingStep = 0
        Me.txt_Len2X.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len2X.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len2X.SuppressZeros = True
        Me.txt_Len2X.TabIndex = 220
        Me.txt_Len2X.Text = "1"
        Me.txt_Len2X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmb_Configurations
        '
        Me.cmb_Configurations.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Configurations.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Configurations.BackColor = System.Drawing.Color.MintCream
        Me.cmb_Configurations.BackColor_Focused = System.Drawing.Color.MintCream
        Me.cmb_Configurations.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_Configurations.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_Configurations.BorderSize = 1
        Me.cmb_Configurations.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Configurations.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Configurations.DropDown_BackSelected = System.Drawing.Color.LightBlue
        Me.cmb_Configurations.DropDown_BorderColor = System.Drawing.Color.Gainsboro
        Me.cmb_Configurations.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Configurations.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_Configurations.DropDownHeight = 400
        Me.cmb_Configurations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Configurations.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_Configurations.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Configurations.ForeColor = System.Drawing.Color.Black
        Me.cmb_Configurations.IntegralHeight = False
        Me.cmb_Configurations.ItemHeight = 14
        Me.cmb_Configurations.Items.AddRange(New Object() {"Articulated", "Scara", "Delta", "Cartesian"})
        Me.cmb_Configurations.Location = New System.Drawing.Point(170, 30)
        Me.cmb_Configurations.Name = "cmb_Configurations"
        Me.cmb_Configurations.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Configurations.Size = New System.Drawing.Size(94, 20)
        Me.cmb_Configurations.TabIndex = 219
        Me.cmb_Configurations.TextPosition = 4
        '
        'txt_Len3X
        '
        Me.txt_Len3X.ArrowsIncrement = 0.1
        Me.txt_Len3X.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len3X.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len3X.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len3X.Decimals = 1
        Me.txt_Len3X.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len3X.ForeColor = System.Drawing.Color.Black
        Me.txt_Len3X.Increment = 0.05
        Me.txt_Len3X.Location = New System.Drawing.Point(149, 144)
        Me.txt_Len3X.MaxValue = 999
        Me.txt_Len3X.MinValue = -999
        Me.txt_Len3X.Multiline = True
        Me.txt_Len3X.Name = "txt_Len3X"
        Me.txt_Len3X.NumericValue = 1
        Me.txt_Len3X.NumericValueInteger = 1
        Me.txt_Len3X.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len3X.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len3X.RoundingStep = 0
        Me.txt_Len3X.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len3X.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len3X.SuppressZeros = True
        Me.txt_Len3X.TabIndex = 217
        Me.txt_Len3X.Text = "1"
        Me.txt_Len3X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len3Z
        '
        Me.txt_Len3Z.ArrowsIncrement = 0.1
        Me.txt_Len3Z.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len3Z.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len3Z.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len3Z.Decimals = 1
        Me.txt_Len3Z.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len3Z.ForeColor = System.Drawing.Color.Black
        Me.txt_Len3Z.Increment = 0.05
        Me.txt_Len3Z.Location = New System.Drawing.Point(235, 144)
        Me.txt_Len3Z.MaxValue = 99
        Me.txt_Len3Z.MinValue = -99
        Me.txt_Len3Z.Multiline = True
        Me.txt_Len3Z.Name = "txt_Len3Z"
        Me.txt_Len3Z.NumericValue = 1
        Me.txt_Len3Z.NumericValueInteger = 1
        Me.txt_Len3Z.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len3Z.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len3Z.RoundingStep = 0
        Me.txt_Len3Z.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len3Z.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len3Z.SuppressZeros = True
        Me.txt_Len3Z.TabIndex = 215
        Me.txt_Len3Z.Text = "1"
        Me.txt_Len3Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len0Z
        '
        Me.txt_Len0Z.ArrowsIncrement = 0.1
        Me.txt_Len0Z.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len0Z.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len0Z.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len0Z.Decimals = 1
        Me.txt_Len0Z.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len0Z.ForeColor = System.Drawing.Color.Black
        Me.txt_Len0Z.Increment = 0.05
        Me.txt_Len0Z.Location = New System.Drawing.Point(235, 88)
        Me.txt_Len0Z.MaxValue = 99
        Me.txt_Len0Z.MinValue = -99
        Me.txt_Len0Z.Multiline = True
        Me.txt_Len0Z.Name = "txt_Len0Z"
        Me.txt_Len0Z.NumericValue = 1
        Me.txt_Len0Z.NumericValueInteger = 1
        Me.txt_Len0Z.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len0Z.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len0Z.RoundingStep = 0
        Me.txt_Len0Z.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len0Z.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len0Z.SuppressZeros = True
        Me.txt_Len0Z.TabIndex = 211
        Me.txt_Len0Z.Text = "1"
        Me.txt_Len0Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len3Y
        '
        Me.txt_Len3Y.ArrowsIncrement = 0.1
        Me.txt_Len3Y.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len3Y.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len3Y.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len3Y.Decimals = 1
        Me.txt_Len3Y.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len3Y.ForeColor = System.Drawing.Color.Black
        Me.txt_Len3Y.Increment = 0.05
        Me.txt_Len3Y.Location = New System.Drawing.Point(192, 144)
        Me.txt_Len3Y.MaxValue = 999
        Me.txt_Len3Y.MinValue = -999
        Me.txt_Len3Y.Multiline = True
        Me.txt_Len3Y.Name = "txt_Len3Y"
        Me.txt_Len3Y.NumericValue = 1
        Me.txt_Len3Y.NumericValueInteger = 1
        Me.txt_Len3Y.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len3Y.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len3Y.RoundingStep = 0
        Me.txt_Len3Y.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len3Y.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len3Y.SuppressZeros = True
        Me.txt_Len3Y.TabIndex = 210
        Me.txt_Len3Y.Text = "1"
        Me.txt_Len3Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Delta3
        '
        Me.txt_Delta3.ArrowsIncrement = 0.1
        Me.txt_Delta3.BackColor = System.Drawing.Color.MintCream
        Me.txt_Delta3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Delta3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Delta3.Decimals = 1
        Me.txt_Delta3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Delta3.ForeColor = System.Drawing.Color.Black
        Me.txt_Delta3.Increment = 0.05
        Me.txt_Delta3.Location = New System.Drawing.Point(110, 144)
        Me.txt_Delta3.MaxValue = 180
        Me.txt_Delta3.MinValue = -180
        Me.txt_Delta3.Multiline = True
        Me.txt_Delta3.Name = "txt_Delta3"
        Me.txt_Delta3.NumericValue = 0
        Me.txt_Delta3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Delta3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Delta3.RoundingStep = 0
        Me.txt_Delta3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Delta3.Size = New System.Drawing.Size(34, 17)
        Me.txt_Delta3.SuppressZeros = True
        Me.txt_Delta3.TabIndex = 205
        Me.txt_Delta3.Text = "0"
        Me.txt_Delta3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len2Y
        '
        Me.txt_Len2Y.ArrowsIncrement = 0.1
        Me.txt_Len2Y.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len2Y.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len2Y.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len2Y.Decimals = 1
        Me.txt_Len2Y.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len2Y.ForeColor = System.Drawing.Color.Black
        Me.txt_Len2Y.Increment = 0.05
        Me.txt_Len2Y.Location = New System.Drawing.Point(192, 125)
        Me.txt_Len2Y.MaxValue = 999
        Me.txt_Len2Y.MinValue = -999
        Me.txt_Len2Y.Multiline = True
        Me.txt_Len2Y.Name = "txt_Len2Y"
        Me.txt_Len2Y.NumericValue = 1
        Me.txt_Len2Y.NumericValueInteger = 1
        Me.txt_Len2Y.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len2Y.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len2Y.RoundingStep = 0
        Me.txt_Len2Y.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len2Y.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len2Y.SuppressZeros = True
        Me.txt_Len2Y.TabIndex = 209
        Me.txt_Len2Y.Text = "1"
        Me.txt_Len2Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len0Y
        '
        Me.txt_Len0Y.ArrowsIncrement = 0.1
        Me.txt_Len0Y.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len0Y.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len0Y.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len0Y.Decimals = 1
        Me.txt_Len0Y.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len0Y.ForeColor = System.Drawing.Color.Black
        Me.txt_Len0Y.Increment = 0.05
        Me.txt_Len0Y.Location = New System.Drawing.Point(192, 88)
        Me.txt_Len0Y.MaxValue = 999
        Me.txt_Len0Y.MinValue = -999
        Me.txt_Len0Y.Multiline = True
        Me.txt_Len0Y.Name = "txt_Len0Y"
        Me.txt_Len0Y.NumericValue = 1
        Me.txt_Len0Y.NumericValueInteger = 1
        Me.txt_Len0Y.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len0Y.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len0Y.RoundingStep = 0
        Me.txt_Len0Y.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len0Y.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len0Y.SuppressZeros = True
        Me.txt_Len0Y.TabIndex = 206
        Me.txt_Len0Y.Text = "1"
        Me.txt_Len0Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Delta2
        '
        Me.txt_Delta2.ArrowsIncrement = 0.1
        Me.txt_Delta2.BackColor = System.Drawing.Color.MintCream
        Me.txt_Delta2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Delta2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Delta2.Decimals = 1
        Me.txt_Delta2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Delta2.ForeColor = System.Drawing.Color.Black
        Me.txt_Delta2.Increment = 0.05
        Me.txt_Delta2.Location = New System.Drawing.Point(110, 125)
        Me.txt_Delta2.MaxValue = 180
        Me.txt_Delta2.MinValue = -180
        Me.txt_Delta2.Multiline = True
        Me.txt_Delta2.Name = "txt_Delta2"
        Me.txt_Delta2.NumericValue = 0
        Me.txt_Delta2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Delta2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Delta2.RoundingStep = 0
        Me.txt_Delta2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Delta2.Size = New System.Drawing.Size(34, 17)
        Me.txt_Delta2.SuppressZeros = True
        Me.txt_Delta2.TabIndex = 203
        Me.txt_Delta2.Text = "0"
        Me.txt_Delta2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Len1Y
        '
        Me.txt_Len1Y.ArrowsIncrement = 0.1
        Me.txt_Len1Y.BackColor = System.Drawing.Color.MintCream
        Me.txt_Len1Y.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Len1Y.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Len1Y.Decimals = 1
        Me.txt_Len1Y.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Len1Y.ForeColor = System.Drawing.Color.Black
        Me.txt_Len1Y.Increment = 0.05
        Me.txt_Len1Y.Location = New System.Drawing.Point(192, 106)
        Me.txt_Len1Y.MaxValue = 999
        Me.txt_Len1Y.MinValue = 1
        Me.txt_Len1Y.Multiline = True
        Me.txt_Len1Y.Name = "txt_Len1Y"
        Me.txt_Len1Y.NumericValue = 1
        Me.txt_Len1Y.NumericValueInteger = 1
        Me.txt_Len1Y.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Len1Y.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Len1Y.RoundingStep = 0
        Me.txt_Len1Y.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Len1Y.Size = New System.Drawing.Size(38, 17)
        Me.txt_Len1Y.SuppressZeros = True
        Me.txt_Len1Y.TabIndex = 208
        Me.txt_Len1Y.Text = "1"
        Me.txt_Len1Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Delta1
        '
        Me.txt_Delta1.ArrowsIncrement = 0.1
        Me.txt_Delta1.BackColor = System.Drawing.Color.MintCream
        Me.txt_Delta1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Delta1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Delta1.Decimals = 1
        Me.txt_Delta1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Delta1.ForeColor = System.Drawing.Color.Black
        Me.txt_Delta1.Increment = 0.05
        Me.txt_Delta1.Location = New System.Drawing.Point(110, 106)
        Me.txt_Delta1.MaxValue = 180
        Me.txt_Delta1.MinValue = -180
        Me.txt_Delta1.Multiline = True
        Me.txt_Delta1.Name = "txt_Delta1"
        Me.txt_Delta1.NumericValue = 0
        Me.txt_Delta1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Delta1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Delta1.RoundingStep = 0
        Me.txt_Delta1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Delta1.Size = New System.Drawing.Size(34, 17)
        Me.txt_Delta1.SuppressZeros = True
        Me.txt_Delta1.TabIndex = 201
        Me.txt_Delta1.Text = "0"
        Me.txt_Delta1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Delta0
        '
        Me.txt_Delta0.ArrowsIncrement = 0.1
        Me.txt_Delta0.BackColor = System.Drawing.Color.MintCream
        Me.txt_Delta0.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Delta0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Delta0.Decimals = 1
        Me.txt_Delta0.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Delta0.ForeColor = System.Drawing.Color.Black
        Me.txt_Delta0.Increment = 0.05
        Me.txt_Delta0.Location = New System.Drawing.Point(110, 88)
        Me.txt_Delta0.MaxValue = 180
        Me.txt_Delta0.MinValue = -180
        Me.txt_Delta0.Multiline = True
        Me.txt_Delta0.Name = "txt_Delta0"
        Me.txt_Delta0.NumericValue = 0
        Me.txt_Delta0.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Delta0.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Delta0.RoundingStep = 0
        Me.txt_Delta0.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Delta0.Size = New System.Drawing.Size(34, 17)
        Me.txt_Delta0.SuppressZeros = True
        Me.txt_Delta0.TabIndex = 198
        Me.txt_Delta0.Text = "0"
        Me.txt_Delta0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_Steppers
        '
        Me.btn_Steppers.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Steppers.CenterPtTracker = DesignerRectTracker1
        Me.btn_Steppers.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Steppers.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Steppers.ColorFillBlendChecked = CBlendItems2
        Me.btn_Steppers.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Steppers.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Steppers.Corners.All = CType(6, Short)
        Me.btn_Steppers.Corners.LowerLeft = CType(6, Short)
        Me.btn_Steppers.Corners.LowerRight = CType(6, Short)
        Me.btn_Steppers.Corners.UpperLeft = CType(6, Short)
        Me.btn_Steppers.Corners.UpperRight = CType(6, Short)
        Me.btn_Steppers.DimFactorOver = 30
        Me.btn_Steppers.FillType = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_Steppers.FillTypeChecked = Theremino_Arm.MyButton.eFillType.LinearVertical
        Me.btn_Steppers.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Steppers.FocalPoints.CenterPtY = 1.0!
        Me.btn_Steppers.FocalPoints.FocusPtX = 0.0!
        Me.btn_Steppers.FocalPoints.FocusPtY = 0.0!
        Me.btn_Steppers.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Steppers.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Steppers.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Steppers.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Steppers.FocusPtTracker = DesignerRectTracker2
        Me.btn_Steppers.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Steppers.Image = Nothing
        Me.btn_Steppers.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Steppers.ImageIndex = 0
        Me.btn_Steppers.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Steppers.Location = New System.Drawing.Point(412, 0)
        Me.btn_Steppers.Name = "btn_Steppers"
        Me.btn_Steppers.Shape = Theremino_Arm.MyButton.eShape.Rectangle
        Me.btn_Steppers.SideImage = Nothing
        Me.btn_Steppers.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Steppers.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Steppers.Size = New System.Drawing.Size(65, 16)
        Me.btn_Steppers.TabIndex = 237
        Me.btn_Steppers.Text = "Steppers"
        Me.btn_Steppers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Steppers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Steppers.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Steppers.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_NumMotorSlots
        '
        Me.txt_NumMotorSlots.ArrowsIncrement = 1
        Me.txt_NumMotorSlots.BackColor = System.Drawing.Color.MintCream
        Me.txt_NumMotorSlots.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_NumMotorSlots.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_NumMotorSlots.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NumMotorSlots.ForeColor = System.Drawing.Color.Black
        Me.txt_NumMotorSlots.Increment = 0.2
        Me.txt_NumMotorSlots.Location = New System.Drawing.Point(27, 79)
        Me.txt_NumMotorSlots.MaxValue = 8
        Me.txt_NumMotorSlots.MinValue = 3
        Me.txt_NumMotorSlots.Multiline = True
        Me.txt_NumMotorSlots.Name = "txt_NumMotorSlots"
        Me.txt_NumMotorSlots.NumericValue = 4
        Me.txt_NumMotorSlots.NumericValueInteger = 4
        Me.txt_NumMotorSlots.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_NumMotorSlots.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_NumMotorSlots.RoundingStep = 0
        Me.txt_NumMotorSlots.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_NumMotorSlots.Size = New System.Drawing.Size(38, 17)
        Me.txt_NumMotorSlots.SuppressZeros = True
        Me.txt_NumMotorSlots.TabIndex = 235
        Me.txt_NumMotorSlots.Text = "4"
        Me.txt_NumMotorSlots.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_FirstMotorSlot
        '
        Me.txt_FirstMotorSlot.ArrowsIncrement = 1
        Me.txt_FirstMotorSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_FirstMotorSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FirstMotorSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FirstMotorSlot.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FirstMotorSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_FirstMotorSlot.Increment = 0.2
        Me.txt_FirstMotorSlot.Location = New System.Drawing.Point(27, 41)
        Me.txt_FirstMotorSlot.MaxValue = 990
        Me.txt_FirstMotorSlot.MinValue = 0
        Me.txt_FirstMotorSlot.Multiline = True
        Me.txt_FirstMotorSlot.Name = "txt_FirstMotorSlot"
        Me.txt_FirstMotorSlot.NumericValue = 1
        Me.txt_FirstMotorSlot.NumericValueInteger = 1
        Me.txt_FirstMotorSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FirstMotorSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FirstMotorSlot.RoundingStep = 0
        Me.txt_FirstMotorSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FirstMotorSlot.Size = New System.Drawing.Size(38, 17)
        Me.txt_FirstMotorSlot.SuppressZeros = True
        Me.txt_FirstMotorSlot.TabIndex = 185
        Me.txt_FirstMotorSlot.Text = "1"
        Me.txt_FirstMotorSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo7
        '
        Me.txt_AngleServo7.ArrowsIncrement = 10
        Me.txt_AngleServo7.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo7.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo7.Decimals = 1
        Me.txt_AngleServo7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo7.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo7.Increment = 0.1
        Me.txt_AngleServo7.Location = New System.Drawing.Point(426, 124)
        Me.txt_AngleServo7.MaxValue = 180
        Me.txt_AngleServo7.MinValue = 0
        Me.txt_AngleServo7.Multiline = True
        Me.txt_AngleServo7.Name = "txt_AngleServo7"
        Me.txt_AngleServo7.NumericValue = 90
        Me.txt_AngleServo7.NumericValueInteger = 90
        Me.txt_AngleServo7.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo7.RoundingStep = 0
        Me.txt_AngleServo7.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo7.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo7.TabIndex = 231
        Me.txt_AngleServo7.Text = "90.0"
        Me.txt_AngleServo7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo6
        '
        Me.txt_AngleServo6.ArrowsIncrement = 10
        Me.txt_AngleServo6.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo6.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo6.Decimals = 1
        Me.txt_AngleServo6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo6.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo6.Increment = 0.1
        Me.txt_AngleServo6.Location = New System.Drawing.Point(378, 124)
        Me.txt_AngleServo6.MaxValue = 180
        Me.txt_AngleServo6.MinValue = 0
        Me.txt_AngleServo6.Multiline = True
        Me.txt_AngleServo6.Name = "txt_AngleServo6"
        Me.txt_AngleServo6.NumericValue = 90
        Me.txt_AngleServo6.NumericValueInteger = 90
        Me.txt_AngleServo6.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo6.RoundingStep = 0
        Me.txt_AngleServo6.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo6.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo6.TabIndex = 230
        Me.txt_AngleServo6.Text = "90.0"
        Me.txt_AngleServo6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo5
        '
        Me.txt_AngleServo5.ArrowsIncrement = 10
        Me.txt_AngleServo5.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo5.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo5.Decimals = 1
        Me.txt_AngleServo5.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo5.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo5.Increment = 0.1
        Me.txt_AngleServo5.Location = New System.Drawing.Point(330, 124)
        Me.txt_AngleServo5.MaxValue = 180
        Me.txt_AngleServo5.MinValue = 0
        Me.txt_AngleServo5.Multiline = True
        Me.txt_AngleServo5.Name = "txt_AngleServo5"
        Me.txt_AngleServo5.NumericValue = 90
        Me.txt_AngleServo5.NumericValueInteger = 90
        Me.txt_AngleServo5.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo5.RoundingStep = 0
        Me.txt_AngleServo5.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo5.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo5.TabIndex = 229
        Me.txt_AngleServo5.Text = "90.0"
        Me.txt_AngleServo5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo4
        '
        Me.txt_AngleServo4.ArrowsIncrement = 10
        Me.txt_AngleServo4.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo4.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo4.Decimals = 1
        Me.txt_AngleServo4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo4.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo4.Increment = 0.1
        Me.txt_AngleServo4.Location = New System.Drawing.Point(282, 124)
        Me.txt_AngleServo4.MaxValue = 180
        Me.txt_AngleServo4.MinValue = 0
        Me.txt_AngleServo4.Multiline = True
        Me.txt_AngleServo4.Name = "txt_AngleServo4"
        Me.txt_AngleServo4.NumericValue = 90
        Me.txt_AngleServo4.NumericValueInteger = 90
        Me.txt_AngleServo4.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo4.RoundingStep = 0
        Me.txt_AngleServo4.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo4.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo4.TabIndex = 228
        Me.txt_AngleServo4.Text = "90.0"
        Me.txt_AngleServo4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo3
        '
        Me.txt_AngleServo3.ArrowsIncrement = 10
        Me.txt_AngleServo3.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo3.Decimals = 1
        Me.txt_AngleServo3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo3.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo3.Increment = 0.1
        Me.txt_AngleServo3.Location = New System.Drawing.Point(234, 124)
        Me.txt_AngleServo3.MaxValue = 180
        Me.txt_AngleServo3.MinValue = 0
        Me.txt_AngleServo3.Multiline = True
        Me.txt_AngleServo3.Name = "txt_AngleServo3"
        Me.txt_AngleServo3.NumericValue = 90
        Me.txt_AngleServo3.NumericValueInteger = 90
        Me.txt_AngleServo3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo3.RoundingStep = 0
        Me.txt_AngleServo3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo3.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo3.TabIndex = 227
        Me.txt_AngleServo3.Text = "90.0"
        Me.txt_AngleServo3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo2
        '
        Me.txt_AngleServo2.ArrowsIncrement = 10
        Me.txt_AngleServo2.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo2.Decimals = 1
        Me.txt_AngleServo2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo2.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo2.Increment = 0.1
        Me.txt_AngleServo2.Location = New System.Drawing.Point(186, 124)
        Me.txt_AngleServo2.MaxValue = 180
        Me.txt_AngleServo2.MinValue = 0
        Me.txt_AngleServo2.Multiline = True
        Me.txt_AngleServo2.Name = "txt_AngleServo2"
        Me.txt_AngleServo2.NumericValue = 90
        Me.txt_AngleServo2.NumericValueInteger = 90
        Me.txt_AngleServo2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo2.RoundingStep = 0
        Me.txt_AngleServo2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo2.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo2.TabIndex = 226
        Me.txt_AngleServo2.Text = "90.0"
        Me.txt_AngleServo2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo1
        '
        Me.txt_AngleServo1.ArrowsIncrement = 10
        Me.txt_AngleServo1.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo1.Decimals = 1
        Me.txt_AngleServo1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo1.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo1.Increment = 0.1
        Me.txt_AngleServo1.Location = New System.Drawing.Point(138, 124)
        Me.txt_AngleServo1.MaxValue = 180
        Me.txt_AngleServo1.MinValue = 0
        Me.txt_AngleServo1.Multiline = True
        Me.txt_AngleServo1.Name = "txt_AngleServo1"
        Me.txt_AngleServo1.NumericValue = 90
        Me.txt_AngleServo1.NumericValueInteger = 90
        Me.txt_AngleServo1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo1.RoundingStep = 0
        Me.txt_AngleServo1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo1.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo1.TabIndex = 225
        Me.txt_AngleServo1.Text = "90.0"
        Me.txt_AngleServo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AngleServo0
        '
        Me.txt_AngleServo0.ArrowsIncrement = 10
        Me.txt_AngleServo0.BackColor = System.Drawing.Color.MintCream
        Me.txt_AngleServo0.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AngleServo0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AngleServo0.Decimals = 1
        Me.txt_AngleServo0.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AngleServo0.ForeColor = System.Drawing.Color.Black
        Me.txt_AngleServo0.Increment = 0.1
        Me.txt_AngleServo0.Location = New System.Drawing.Point(90, 124)
        Me.txt_AngleServo0.MaxValue = 180
        Me.txt_AngleServo0.MinValue = 0
        Me.txt_AngleServo0.Multiline = True
        Me.txt_AngleServo0.Name = "txt_AngleServo0"
        Me.txt_AngleServo0.NumericValue = 90
        Me.txt_AngleServo0.NumericValueInteger = 90
        Me.txt_AngleServo0.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AngleServo0.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AngleServo0.RoundingStep = 0
        Me.txt_AngleServo0.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AngleServo0.Size = New System.Drawing.Size(45, 17)
        Me.txt_AngleServo0.TabIndex = 224
        Me.txt_AngleServo0.Text = "90.0"
        Me.txt_AngleServo0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo7
        '
        Me.txt_TimeServo7.ArrowsIncrement = 0.1
        Me.txt_TimeServo7.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo7.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo7.Decimals = 1
        Me.txt_TimeServo7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo7.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo7.Increment = 0.1
        Me.txt_TimeServo7.Location = New System.Drawing.Point(426, 103)
        Me.txt_TimeServo7.MaxValue = 2500
        Me.txt_TimeServo7.MinValue = 500
        Me.txt_TimeServo7.Multiline = True
        Me.txt_TimeServo7.Name = "txt_TimeServo7"
        Me.txt_TimeServo7.NumericValue = 1500
        Me.txt_TimeServo7.NumericValueInteger = 1500
        Me.txt_TimeServo7.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo7.RoundingStep = 0
        Me.txt_TimeServo7.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo7.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo7.TabIndex = 223
        Me.txt_TimeServo7.Text = "1500.0"
        Me.txt_TimeServo7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo6
        '
        Me.txt_TimeServo6.ArrowsIncrement = 0.1
        Me.txt_TimeServo6.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo6.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo6.Decimals = 1
        Me.txt_TimeServo6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo6.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo6.Increment = 0.1
        Me.txt_TimeServo6.Location = New System.Drawing.Point(378, 103)
        Me.txt_TimeServo6.MaxValue = 2500
        Me.txt_TimeServo6.MinValue = 500
        Me.txt_TimeServo6.Multiline = True
        Me.txt_TimeServo6.Name = "txt_TimeServo6"
        Me.txt_TimeServo6.NumericValue = 1500
        Me.txt_TimeServo6.NumericValueInteger = 1500
        Me.txt_TimeServo6.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo6.RoundingStep = 0
        Me.txt_TimeServo6.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo6.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo6.TabIndex = 222
        Me.txt_TimeServo6.Text = "1500.0"
        Me.txt_TimeServo6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo5
        '
        Me.txt_TimeServo5.ArrowsIncrement = 0.1
        Me.txt_TimeServo5.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo5.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo5.Decimals = 1
        Me.txt_TimeServo5.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo5.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo5.Increment = 0.1
        Me.txt_TimeServo5.Location = New System.Drawing.Point(330, 103)
        Me.txt_TimeServo5.MaxValue = 2500
        Me.txt_TimeServo5.MinValue = 500
        Me.txt_TimeServo5.Multiline = True
        Me.txt_TimeServo5.Name = "txt_TimeServo5"
        Me.txt_TimeServo5.NumericValue = 1500
        Me.txt_TimeServo5.NumericValueInteger = 1500
        Me.txt_TimeServo5.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo5.RoundingStep = 0
        Me.txt_TimeServo5.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo5.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo5.TabIndex = 221
        Me.txt_TimeServo5.Text = "1500.0"
        Me.txt_TimeServo5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo4
        '
        Me.txt_TimeServo4.ArrowsIncrement = 0.1
        Me.txt_TimeServo4.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo4.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo4.Decimals = 1
        Me.txt_TimeServo4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo4.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo4.Increment = 0.1
        Me.txt_TimeServo4.Location = New System.Drawing.Point(282, 103)
        Me.txt_TimeServo4.MaxValue = 2500
        Me.txt_TimeServo4.MinValue = 500
        Me.txt_TimeServo4.Multiline = True
        Me.txt_TimeServo4.Name = "txt_TimeServo4"
        Me.txt_TimeServo4.NumericValue = 1500
        Me.txt_TimeServo4.NumericValueInteger = 1500
        Me.txt_TimeServo4.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo4.RoundingStep = 0
        Me.txt_TimeServo4.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo4.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo4.TabIndex = 220
        Me.txt_TimeServo4.Text = "1500.0"
        Me.txt_TimeServo4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo3
        '
        Me.txt_TimeServo3.ArrowsIncrement = 0.1
        Me.txt_TimeServo3.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo3.Decimals = 1
        Me.txt_TimeServo3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo3.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo3.Increment = 0.1
        Me.txt_TimeServo3.Location = New System.Drawing.Point(234, 103)
        Me.txt_TimeServo3.MaxValue = 2500
        Me.txt_TimeServo3.MinValue = 500
        Me.txt_TimeServo3.Multiline = True
        Me.txt_TimeServo3.Name = "txt_TimeServo3"
        Me.txt_TimeServo3.NumericValue = 1500
        Me.txt_TimeServo3.NumericValueInteger = 1500
        Me.txt_TimeServo3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo3.RoundingStep = 0
        Me.txt_TimeServo3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo3.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo3.TabIndex = 219
        Me.txt_TimeServo3.Text = "1500.0"
        Me.txt_TimeServo3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo2
        '
        Me.txt_TimeServo2.ArrowsIncrement = 0.1
        Me.txt_TimeServo2.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo2.Decimals = 1
        Me.txt_TimeServo2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo2.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo2.Increment = 0.1
        Me.txt_TimeServo2.Location = New System.Drawing.Point(186, 103)
        Me.txt_TimeServo2.MaxValue = 2500
        Me.txt_TimeServo2.MinValue = 500
        Me.txt_TimeServo2.Multiline = True
        Me.txt_TimeServo2.Name = "txt_TimeServo2"
        Me.txt_TimeServo2.NumericValue = 1500
        Me.txt_TimeServo2.NumericValueInteger = 1500
        Me.txt_TimeServo2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo2.RoundingStep = 0
        Me.txt_TimeServo2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo2.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo2.TabIndex = 218
        Me.txt_TimeServo2.Text = "1500.0"
        Me.txt_TimeServo2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo1
        '
        Me.txt_TimeServo1.ArrowsIncrement = 0.1
        Me.txt_TimeServo1.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo1.Decimals = 1
        Me.txt_TimeServo1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo1.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo1.Increment = 0.1
        Me.txt_TimeServo1.Location = New System.Drawing.Point(138, 103)
        Me.txt_TimeServo1.MaxValue = 2500
        Me.txt_TimeServo1.MinValue = 500
        Me.txt_TimeServo1.Multiline = True
        Me.txt_TimeServo1.Name = "txt_TimeServo1"
        Me.txt_TimeServo1.NumericValue = 1500
        Me.txt_TimeServo1.NumericValueInteger = 1500
        Me.txt_TimeServo1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo1.RoundingStep = 0
        Me.txt_TimeServo1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo1.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo1.TabIndex = 217
        Me.txt_TimeServo1.Text = "1500.0"
        Me.txt_TimeServo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_TimeServo0
        '
        Me.txt_TimeServo0.ArrowsIncrement = 0.1
        Me.txt_TimeServo0.BackColor = System.Drawing.Color.MintCream
        Me.txt_TimeServo0.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_TimeServo0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_TimeServo0.Decimals = 1
        Me.txt_TimeServo0.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_TimeServo0.ForeColor = System.Drawing.Color.Black
        Me.txt_TimeServo0.Increment = 0.1
        Me.txt_TimeServo0.Location = New System.Drawing.Point(90, 103)
        Me.txt_TimeServo0.MaxValue = 2500
        Me.txt_TimeServo0.MinValue = 500
        Me.txt_TimeServo0.Multiline = True
        Me.txt_TimeServo0.Name = "txt_TimeServo0"
        Me.txt_TimeServo0.NumericValue = 1500
        Me.txt_TimeServo0.NumericValueInteger = 1500
        Me.txt_TimeServo0.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_TimeServo0.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_TimeServo0.RoundingStep = 0
        Me.txt_TimeServo0.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_TimeServo0.Size = New System.Drawing.Size(45, 17)
        Me.txt_TimeServo0.TabIndex = 216
        Me.txt_TimeServo0.Text = "1500.0"
        Me.txt_TimeServo0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ParkingZ
        '
        Me.txt_ParkingZ.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_ParkingZ.ArrowsIncrement = 1
        Me.txt_ParkingZ.BackColor = System.Drawing.Color.MintCream
        Me.txt_ParkingZ.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ParkingZ.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ParkingZ.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ParkingZ.ForeColor = System.Drawing.Color.Black
        Me.txt_ParkingZ.Increment = 0.2
        Me.txt_ParkingZ.Location = New System.Drawing.Point(256, 340)
        Me.txt_ParkingZ.MaxValue = 9999
        Me.txt_ParkingZ.MinValue = -999
        Me.txt_ParkingZ.Multiline = True
        Me.txt_ParkingZ.Name = "txt_ParkingZ"
        Me.txt_ParkingZ.NumericValue = 30
        Me.txt_ParkingZ.NumericValueInteger = 30
        Me.txt_ParkingZ.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ParkingZ.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ParkingZ.RoundingStep = 0
        Me.txt_ParkingZ.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ParkingZ.Size = New System.Drawing.Size(34, 17)
        Me.txt_ParkingZ.TabIndex = 219
        Me.txt_ParkingZ.Text = "30"
        Me.txt_ParkingZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ParkingY
        '
        Me.txt_ParkingY.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_ParkingY.ArrowsIncrement = 1
        Me.txt_ParkingY.BackColor = System.Drawing.Color.MintCream
        Me.txt_ParkingY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ParkingY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ParkingY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ParkingY.ForeColor = System.Drawing.Color.Black
        Me.txt_ParkingY.Increment = 0.2
        Me.txt_ParkingY.Location = New System.Drawing.Point(223, 340)
        Me.txt_ParkingY.MaxValue = 9999
        Me.txt_ParkingY.MinValue = -999
        Me.txt_ParkingY.Multiline = True
        Me.txt_ParkingY.Name = "txt_ParkingY"
        Me.txt_ParkingY.NumericValue = 55
        Me.txt_ParkingY.NumericValueInteger = 55
        Me.txt_ParkingY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ParkingY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ParkingY.RoundingStep = 0
        Me.txt_ParkingY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ParkingY.Size = New System.Drawing.Size(34, 17)
        Me.txt_ParkingY.TabIndex = 218
        Me.txt_ParkingY.Text = "55"
        Me.txt_ParkingY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ParkingX
        '
        Me.txt_ParkingX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_ParkingX.ArrowsIncrement = 1
        Me.txt_ParkingX.BackColor = System.Drawing.Color.MintCream
        Me.txt_ParkingX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ParkingX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ParkingX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ParkingX.ForeColor = System.Drawing.Color.Black
        Me.txt_ParkingX.Increment = 0.2
        Me.txt_ParkingX.Location = New System.Drawing.Point(189, 340)
        Me.txt_ParkingX.MaxValue = 9999
        Me.txt_ParkingX.MinValue = -999
        Me.txt_ParkingX.Multiline = True
        Me.txt_ParkingX.Name = "txt_ParkingX"
        Me.txt_ParkingX.NumericValue = 0
        Me.txt_ParkingX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ParkingX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ParkingX.RoundingStep = 0
        Me.txt_ParkingX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ParkingX.Size = New System.Drawing.Size(34, 17)
        Me.txt_ParkingX.TabIndex = 217
        Me.txt_ParkingX.Text = "0"
        Me.txt_ParkingX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaVerticalDist
        '
        Me.txt_DeltaVerticalDist.ArrowsIncrement = 0.1
        Me.txt_DeltaVerticalDist.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeltaVerticalDist.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaVerticalDist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaVerticalDist.Decimals = 1
        Me.txt_DeltaVerticalDist.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaVerticalDist.ForeColor = System.Drawing.Color.Black
        Me.txt_DeltaVerticalDist.Increment = 0.05
        Me.txt_DeltaVerticalDist.Location = New System.Drawing.Point(89, 80)
        Me.txt_DeltaVerticalDist.MaxValue = 999
        Me.txt_DeltaVerticalDist.MinValue = 1
        Me.txt_DeltaVerticalDist.Multiline = True
        Me.txt_DeltaVerticalDist.Name = "txt_DeltaVerticalDist"
        Me.txt_DeltaVerticalDist.NumericValue = 1
        Me.txt_DeltaVerticalDist.NumericValueInteger = 1
        Me.txt_DeltaVerticalDist.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaVerticalDist.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaVerticalDist.RoundingStep = 0
        Me.txt_DeltaVerticalDist.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaVerticalDist.Size = New System.Drawing.Size(38, 17)
        Me.txt_DeltaVerticalDist.SuppressZeros = True
        Me.txt_DeltaVerticalDist.TabIndex = 220
        Me.txt_DeltaVerticalDist.Text = "1"
        Me.txt_DeltaVerticalDist.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaMotorArms
        '
        Me.txt_DeltaMotorArms.ArrowsIncrement = 0.1
        Me.txt_DeltaMotorArms.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeltaMotorArms.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaMotorArms.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaMotorArms.Decimals = 1
        Me.txt_DeltaMotorArms.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaMotorArms.ForeColor = System.Drawing.Color.Black
        Me.txt_DeltaMotorArms.Increment = 0.05
        Me.txt_DeltaMotorArms.Location = New System.Drawing.Point(89, 61)
        Me.txt_DeltaMotorArms.MaxValue = 999
        Me.txt_DeltaMotorArms.MinValue = 1
        Me.txt_DeltaMotorArms.Multiline = True
        Me.txt_DeltaMotorArms.Name = "txt_DeltaMotorArms"
        Me.txt_DeltaMotorArms.NumericValue = 1
        Me.txt_DeltaMotorArms.NumericValueInteger = 1
        Me.txt_DeltaMotorArms.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaMotorArms.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaMotorArms.RoundingStep = 0
        Me.txt_DeltaMotorArms.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaMotorArms.Size = New System.Drawing.Size(38, 17)
        Me.txt_DeltaMotorArms.SuppressZeros = True
        Me.txt_DeltaMotorArms.TabIndex = 218
        Me.txt_DeltaMotorArms.Text = "1"
        Me.txt_DeltaMotorArms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaVerticalArms
        '
        Me.txt_DeltaVerticalArms.ArrowsIncrement = 0.1
        Me.txt_DeltaVerticalArms.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeltaVerticalArms.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaVerticalArms.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaVerticalArms.Decimals = 1
        Me.txt_DeltaVerticalArms.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaVerticalArms.ForeColor = System.Drawing.Color.Black
        Me.txt_DeltaVerticalArms.Increment = 0.05
        Me.txt_DeltaVerticalArms.Location = New System.Drawing.Point(89, 42)
        Me.txt_DeltaVerticalArms.MaxValue = 999
        Me.txt_DeltaVerticalArms.MinValue = 1
        Me.txt_DeltaVerticalArms.Multiline = True
        Me.txt_DeltaVerticalArms.Name = "txt_DeltaVerticalArms"
        Me.txt_DeltaVerticalArms.NumericValue = 1
        Me.txt_DeltaVerticalArms.NumericValueInteger = 1
        Me.txt_DeltaVerticalArms.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaVerticalArms.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaVerticalArms.RoundingStep = 0
        Me.txt_DeltaVerticalArms.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaVerticalArms.Size = New System.Drawing.Size(38, 17)
        Me.txt_DeltaVerticalArms.SuppressZeros = True
        Me.txt_DeltaVerticalArms.TabIndex = 216
        Me.txt_DeltaVerticalArms.Text = "1"
        Me.txt_DeltaVerticalArms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaMotorRadius
        '
        Me.txt_DeltaMotorRadius.ArrowsIncrement = 0.1
        Me.txt_DeltaMotorRadius.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeltaMotorRadius.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaMotorRadius.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaMotorRadius.Decimals = 1
        Me.txt_DeltaMotorRadius.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaMotorRadius.ForeColor = System.Drawing.Color.Black
        Me.txt_DeltaMotorRadius.Increment = 0.05
        Me.txt_DeltaMotorRadius.Location = New System.Drawing.Point(89, 23)
        Me.txt_DeltaMotorRadius.MaxValue = 999
        Me.txt_DeltaMotorRadius.MinValue = 1
        Me.txt_DeltaMotorRadius.Multiline = True
        Me.txt_DeltaMotorRadius.Name = "txt_DeltaMotorRadius"
        Me.txt_DeltaMotorRadius.NumericValue = 1
        Me.txt_DeltaMotorRadius.NumericValueInteger = 1
        Me.txt_DeltaMotorRadius.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaMotorRadius.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaMotorRadius.RoundingStep = 0
        Me.txt_DeltaMotorRadius.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaMotorRadius.Size = New System.Drawing.Size(38, 17)
        Me.txt_DeltaMotorRadius.SuppressZeros = True
        Me.txt_DeltaMotorRadius.TabIndex = 214
        Me.txt_DeltaMotorRadius.Text = "1"
        Me.txt_DeltaMotorRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaEndRadius
        '
        Me.txt_DeltaEndRadius.ArrowsIncrement = 0.1
        Me.txt_DeltaEndRadius.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeltaEndRadius.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaEndRadius.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaEndRadius.Decimals = 1
        Me.txt_DeltaEndRadius.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaEndRadius.ForeColor = System.Drawing.Color.Black
        Me.txt_DeltaEndRadius.Increment = 0.05
        Me.txt_DeltaEndRadius.Location = New System.Drawing.Point(89, 4)
        Me.txt_DeltaEndRadius.MaxValue = 999
        Me.txt_DeltaEndRadius.MinValue = 1
        Me.txt_DeltaEndRadius.Multiline = True
        Me.txt_DeltaEndRadius.Name = "txt_DeltaEndRadius"
        Me.txt_DeltaEndRadius.NumericValue = 1
        Me.txt_DeltaEndRadius.NumericValueInteger = 1
        Me.txt_DeltaEndRadius.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaEndRadius.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaEndRadius.RoundingStep = 0
        Me.txt_DeltaEndRadius.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaEndRadius.Size = New System.Drawing.Size(38, 17)
        Me.txt_DeltaEndRadius.SuppressZeros = True
        Me.txt_DeltaEndRadius.TabIndex = 212
        Me.txt_DeltaEndRadius.Text = "1"
        Me.txt_DeltaEndRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_MinY
        '
        Me.txt_MinY.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_MinY.ArrowsIncrement = 1
        Me.txt_MinY.BackColor = System.Drawing.Color.MintCream
        Me.txt_MinY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinY.ForeColor = System.Drawing.Color.Black
        Me.txt_MinY.Increment = 0.2
        Me.txt_MinY.Location = New System.Drawing.Point(81, 318)
        Me.txt_MinY.MaxValue = 90
        Me.txt_MinY.MinValue = 5
        Me.txt_MinY.Multiline = True
        Me.txt_MinY.Name = "txt_MinY"
        Me.txt_MinY.NumericValue = 10
        Me.txt_MinY.NumericValueInteger = 10
        Me.txt_MinY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinY.RoundingStep = 0
        Me.txt_MinY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinY.Size = New System.Drawing.Size(34, 17)
        Me.txt_MinY.TabIndex = 214
        Me.txt_MinY.Text = "10"
        Me.txt_MinY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_MaxAreaX
        '
        Me.txt_MaxAreaX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_MaxAreaX.ArrowsIncrement = 20
        Me.txt_MaxAreaX.BackColor = System.Drawing.Color.MintCream
        Me.txt_MaxAreaX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxAreaX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxAreaX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxAreaX.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxAreaX.Increment = 5
        Me.txt_MaxAreaX.Location = New System.Drawing.Point(437, 318)
        Me.txt_MaxAreaX.MaxValue = 1000
        Me.txt_MaxAreaX.MinValue = 60
        Me.txt_MaxAreaX.Multiline = True
        Me.txt_MaxAreaX.Name = "txt_MaxAreaX"
        Me.txt_MaxAreaX.NumericValue = 140
        Me.txt_MaxAreaX.NumericValueInteger = 140
        Me.txt_MaxAreaX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxAreaX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxAreaX.RoundingStep = 20
        Me.txt_MaxAreaX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxAreaX.Size = New System.Drawing.Size(34, 17)
        Me.txt_MaxAreaX.TabIndex = 210
        Me.txt_MaxAreaX.Text = " 140"
        Me.txt_MaxAreaX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_JogStep
        '
        Me.txt_JogStep.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_JogStep.ArrowsIncrement = 0.1
        Me.txt_JogStep.BackColor = System.Drawing.Color.MintCream
        Me.txt_JogStep.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_JogStep.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_JogStep.Decimals = 1
        Me.txt_JogStep.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_JogStep.ForeColor = System.Drawing.Color.Black
        Me.txt_JogStep.Increment = 0.05
        Me.txt_JogStep.Location = New System.Drawing.Point(437, 340)
        Me.txt_JogStep.MaxValue = 100
        Me.txt_JogStep.MinValue = 0.1
        Me.txt_JogStep.Multiline = True
        Me.txt_JogStep.Name = "txt_JogStep"
        Me.txt_JogStep.NumericValue = 1
        Me.txt_JogStep.NumericValueInteger = 1
        Me.txt_JogStep.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_JogStep.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_JogStep.RoundingStep = 0
        Me.txt_JogStep.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_JogStep.Size = New System.Drawing.Size(36, 17)
        Me.txt_JogStep.SuppressZeros = True
        Me.txt_JogStep.TabIndex = 207
        Me.txt_JogStep.Text = "1"
        Me.txt_JogStep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(786, 606)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox_ArmProperties)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox9)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(802, 644)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Robotic Arm"
        Me.GroupBox_ArmProperties.ResumeLayout(False)
        Me.GroupBox_ArmProperties.PerformLayout()
        Me.Panel_Delta.ResumeLayout(False)
        Me.Panel_Delta.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar0, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.Pic_ArmGeometry, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox_ArmProperties As System.Windows.Forms.GroupBox
    Friend WithEvents txt_GcodeFile As MyTextBox
    Friend WithEvents btn_GcodeLoad As MyButton
    Friend WithEvents txt_Len3Z As MyTextBox
    Friend WithEvents Label_LenX As System.Windows.Forms.Label
    Friend WithEvents txt_Len0Z As MyTextBox
    Friend WithEvents txt_Len3Y As MyTextBox
    Friend WithEvents txt_Len2Y As MyTextBox
    Friend WithEvents txt_Len1Y As MyTextBox
    Friend WithEvents btn_GcodeRun As MyButton
    Friend WithEvents btn_GcodeRewind As MyButton
    Friend WithEvents Label_LenY As System.Windows.Forms.Label
    Friend WithEvents txt_GcodeLine As MyTextBox
    Friend WithEvents txt_Len0Y As MyTextBox
    Friend WithEvents txt_Delta3 As MyTextBox
    Friend WithEvents chk_Invert3 As System.Windows.Forms.CheckBox
    Friend WithEvents txt_Delta2 As MyTextBox
    Friend WithEvents chk_Invert2 As System.Windows.Forms.CheckBox
    Friend WithEvents txt_Delta1 As MyTextBox
    Friend WithEvents chk_Invert1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Delta As System.Windows.Forms.Label
    Friend WithEvents txt_Delta0 As MyTextBox
    Friend WithEvents Label_Inv As System.Windows.Forms.Label
    Friend WithEvents chk_Invert0 As System.Windows.Forms.CheckBox
    Friend WithEvents txt_ScaleZ As MyTextBox
    Friend WithEvents txt_ScaleY As MyTextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txt_ScaleX As MyTextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_OriginZ As MyTextBox
    Friend WithEvents txt_OriginY As MyTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_OriginX As MyTextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TrackBar0 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar3 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar4 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar2 As System.Windows.Forms.TrackBar
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Pic_ArmGeometry As System.Windows.Forms.PictureBox
    Friend WithEvents txt_TimeServo0 As MyTextBox
    Friend WithEvents TrackBar7 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar6 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar5 As System.Windows.Forms.TrackBar
    Friend WithEvents txt_JogStep As MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_TimeServo7 As MyTextBox
    Friend WithEvents txt_TimeServo6 As MyTextBox
    Friend WithEvents txt_TimeServo5 As MyTextBox
    Friend WithEvents txt_TimeServo4 As MyTextBox
    Friend WithEvents txt_TimeServo3 As MyTextBox
    Friend WithEvents txt_TimeServo2 As MyTextBox
    Friend WithEvents txt_TimeServo1 As MyTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label_LenZ As System.Windows.Forms.Label
    Friend WithEvents txt_Len3X As MyTextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_FirstMotorSlot As MyTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_Zup As MyTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_Zdown As MyTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_Ztrip As MyTextBox
    Friend WithEvents btn_OverrideZ As MyButton
    Friend WithEvents txt_MaxAreaX As MyTextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmb_Configurations As MyComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_MinY As MyTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_AngleServo7 As MyTextBox
    Friend WithEvents txt_AngleServo6 As MyTextBox
    Friend WithEvents txt_AngleServo5 As MyTextBox
    Friend WithEvents txt_AngleServo4 As MyTextBox
    Friend WithEvents txt_AngleServo3 As MyTextBox
    Friend WithEvents txt_AngleServo2 As MyTextBox
    Friend WithEvents txt_AngleServo1 As MyTextBox
    Friend WithEvents txt_AngleServo0 As MyTextBox
    Friend WithEvents txt_MaxError As MyTextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txt_FeedWork As MyTextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txt_FeedRapid As MyTextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel_Delta As System.Windows.Forms.Panel
    Friend WithEvents txt_DeltaMotorArms As MyTextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txt_DeltaVerticalArms As MyTextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txt_DeltaMotorRadius As MyTextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txt_DeltaEndRadius As MyTextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txt_DeltaVerticalDist As MyTextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txt_Len2Z As MyTextBox
    Friend WithEvents txt_Len2X As MyTextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_LoadConfiguration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SaveConfigurationAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_SaveImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_SaveImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton_LoadConfiguration As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton_SaveConfiguration As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToDoListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label_Joint As System.Windows.Forms.Label
    Friend WithEvents txt_Rapp3 As MyTextBox
    Friend WithEvents txt_Rapp2 As MyTextBox
    Friend WithEvents txt_Rapp1 As MyTextBox
    Friend WithEvents Label_Rapp As System.Windows.Forms.Label
    Friend WithEvents txt_Rapp0 As MyTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txt_GcodeAutomation As MyTextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents chk_AutoParking As System.Windows.Forms.CheckBox
    Friend WithEvents txt_NumMotorSlots As MyTextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents chk_AutoSleep As System.Windows.Forms.CheckBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txt_ParkingZ As MyTextBox
    Friend WithEvents txt_ParkingY As MyTextBox
    Friend WithEvents txt_ParkingX As MyTextBox
    Friend WithEvents btn_Steppers As Theremino_Arm.MyButton
End Class
