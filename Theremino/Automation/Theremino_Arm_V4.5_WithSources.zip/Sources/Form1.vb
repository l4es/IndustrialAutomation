﻿
' TODO - Main list
' ---------------------------------
' all done

' Version 4.5
' Slots 1/3/5/7 for stepper motors


Public Class Form1

    Friend WithEvents mtimer As MilliTimer = New MilliTimer()

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ' ---------------------------------------------------- panel delta position
        Panel_Delta.Parent = GroupBox_ArmProperties
        Panel_Delta.BringToFront()
        Panel_Delta.Left = 146
        Panel_Delta.Top = 67
        Panel_Delta.Visible = False
        ' ---------------------------------------------------- memory mapped files
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------- init and load
        ThereminoArm_Init()
        Load_INI()
        StartThereminoHAL()
        ' ---------------------------------------------------- 
        Steppers = btn_Steppers.Checked
        SetAllParams()
        ' ---------------------------------------------------- timers
        SetTimerSpeed()
        StartTimers()
        Timer1.Enabled = False
        mtimer.Start()
        Timer2.Enabled = True
        ThereminoArm.DisplayArmGeometry()
        ' ---------------------------------------------------- 
        Text = AppTitleAndVersion("Theremino Robotic Arm")
        ShowInTaskbar = False
        ShowInTaskbar = True
        Refresh()
        Me.Opacity = 1
    End Sub

    Private Sub SetAllParams()
        EventsAreEnabled = False
        ThereminoArm.SetConfiguration(ThereminoArm.ArmType)
        Combo_SetIndex_FromString(cmb_Configurations, ThereminoArm.ArmType)
        ThereminoArm.InitDefaultParams()
        ThereminoArm_SetArmGeometryParams()
        ThereminoArm_SetArmGeometryParams_Delta()
        ThereminoArm_SetGcodeParams()
        ThereminoArm_SetOverrideParams()
        SetPrecisionParams()
        ThereminoArm.SetMinY(txt_MinY.NumericValueInteger)
        ThereminoArm.SetMaxAreaX(txt_MaxAreaX.NumericValueInteger)
        ThereminoArm.SetParkingPosition(txt_ParkingX.NumericValueInteger, _
                                        txt_ParkingY.NumericValueInteger, _
                                        txt_ParkingZ.NumericValueInteger)
        ThereminoArm.CalcAreaLimits()
        ' ---------------------------------------------------- start
        EventsAreEnabled = True
        ThereminoArm.InvalidateBaseImage()
        ThereminoArm.DisplayArmGeometry()
        ThereminoArm.DrawGcodeToBaseImage()
        ' ---------------------------------------------------- 
        Pic_ArmGeometry.Focus()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ThereminoArm.GotoParkingPosition()
        ThereminoArm.DisableServoSignals()
        EventsAreEnabled = False
        If mtimer IsNot Nothing Then mtimer.Stop()
        Timer1.Enabled = False
        Save_INI()
        StopThereminoHAL()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Exit Sub
        ThereminoArm.CalcAreaLimits()
        ThereminoArm.InvalidateBaseImage()
        ThereminoArm.DisplayArmGeometry()
        'ThereminoArm.DrawGcodeToBaseImage()
        Save_INI()
    End Sub

    ' =========================================================================
    '   THEREMINO HAL - START STOP -
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        Dim path As String = Application.StartupPath & "\Theremino_HAL.exe"
        If Not My.Computer.FileSystem.FileExists(path) Then
            path = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
        End If
        If Not My.Computer.FileSystem.FileExists(path) Then Return
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(path)
        psi.FileName = path
        HalProcess = Process.Start(psi)
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing AndAlso Not HalProcess.HasExited Then
            Try
                HalProcess.CloseMainWindow()
            Finally
            End Try
        End If
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_LoadConfiguration_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_LoadConfiguration.Click
        EventsAreEnabled = False
        LoadConfiguration()
        SetAllParams()
        EventsAreEnabled = True
    End Sub
    Private Sub Menu_File_SaveConfigurationAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveConfigurationAs.Click
        SaveConfigurationAs()
    End Sub
    Private Sub Menu_File_SaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveImage.Click
        SaveImage("ThereminoARM_", Me)
    End Sub
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        Me.Close()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        Process.Start(Application.StartupPath & "\Docs")
    End Sub
    Private Sub ToDoListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToDoListToolStripMenuItem.Click
        Process.Start(Application.StartupPath & "\Docs\ToDo.txt")
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog()
    End Sub


    ' =======================================================================================
    '   TOOLBAR
    ' =======================================================================================
    Private Sub ToolStripButton_LoadConfiguration_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_LoadConfiguration.Click
        EventsAreEnabled = False
        LoadConfiguration()
        SetAllParams()
        EventsAreEnabled = True
    End Sub
    Private Sub ToolStripButton_SaveConfiguration_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_SaveConfiguration.Click
        SaveConfigurationAs()
    End Sub
    Private Sub ToolStripButton_SaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_SaveImage.Click
        ToolStripButton_SaveImage.Visible = False
        ToolStripButton_SaveImage.Visible = True
        Me.Refresh()
        SaveImage("ThereminoARM_", Me)
    End Sub


    ' ====================================================================================================
    '  MilliTimerElapsed  >> ThreadSafe <<
    ' ====================================================================================================
    Private Sub MilliTimerElapsed_ThreadSafe() Handles mtimer.MilliTimerElapsed
        Me.Invoke(New MilliTimerElapsed_Delegate(AddressOf MilliTimerElapsed))
    End Sub
    Private Delegate Sub MilliTimerElapsed_Delegate()
    Private Sub MilliTimerElapsed()
        If MtimerEnabled Then ThereminoArm.TimedUpdate()
    End Sub


    ' ====================================================================================================
    '  MilliTimerElapsed  >> NOT ThreadSafe <<
    ' ====================================================================================================
    'Private Sub MilliTimerElapsed() Handles mtimer.MilliTimerElapsed
    '    If MtimerEnabled Then ThereminoArm.TimedUpdate()
    'End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        'ThereminoArm.TimedUpdate()
        ThereminoArm.TimedDisplay()
    End Sub

    Private Sub SetTimerSpeed()
        mtimer.Interval = 16 'txt_Interval.NumericValueInteger
        mtimer.IgnoreEventIfLateBy = 32
        ThereminoArm.SetTimerSpeed(16)
        Timer1.Interval = 48 'with interval < 16 the timer is about 16.6mS (60 Hz)
        'ThereminoArm.SetTimerSpeed(17)
    End Sub


    Private MtimerEnabled As Boolean
    Friend Sub StopTimers()
        MtimerEnabled = False
        Timer1.Enabled = False
    End Sub
    Friend Sub StartTimers()
        MtimerEnabled = True
        Timer1.Enabled = True
    End Sub


    ' ====================================================================================================
    '  GCode Automation
    ' ====================================================================================================
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        GCodeAutomation()
    End Sub

    Private GcodeNames As Collections.ObjectModel.ReadOnlyCollection(Of String)

    Private Sub ReadFileNames()
        Try
            Dim wildcards() As String = {"*.gc"}
            Dim s As String
            s = Application.StartupPath & "\Media\AutomationFiles"
            GcodeNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchTopLevelOnly, wildcards)
        Catch
        End Try
    End Sub

    ' GcodeAutomation: -2=GcodeCompleted / -1=StopGcode / 0=PauseGcode / 1,2,3,...=LoadAndRunGcode 
    Private OldGcodeSlotValue As Int32
    Private NewGcodeSlotValue As Int32
    Private Sub GCodeAutomation()
        If GcodeAutomationSlot < 0 Then Return
        If GcodeNames Is Nothing Then Return
        NewGcodeSlotValue = CInt(Slots.ReadSlot_NoNan(GcodeAutomationSlot))
        If NewGcodeSlotValue <> OldGcodeSlotValue Then
            If NewGcodeSlotValue > 0 Then
                ReadFileNames()
                If NewGcodeSlotValue <= GcodeNames.Count Then
                    If GcodeNames(NewGcodeSlotValue - 1) <> GcodeFile Then
                        ' -------------------------------------------------- CHANGE AND START
                        StopTimers()
                        ThereminoArm.GcodeRunning = False
                        ThereminoArm.SetGcodeLine(0)
                        GcodeFile = GcodeNames(NewGcodeSlotValue - 1)
                        ThereminoArm.LoadGcodeFile()
                        Save_INI()
                        ThereminoArm.DrawGcodeToBaseImage()
                        ThereminoArm.InvalidateBaseImage()
                        StartTimers()
                    Else
                        ' -------------------------------------------------- PAUSE
                    End If
                    btn_GcodeRun.Checked = True
                    btn_GcodeRun_ClickButtonArea(Nothing, Nothing)
                End If
            Else
                If NewGcodeSlotValue < 0 Then
                    ' ------------------------------------------------------ STOP AND REWIND
                    ThereminoArm.GcodeRunning = False
                    If ThereminoArm.AutoParking Then ThereminoArm.GotoParkingPosition()
                    StopRunningState()
                    ThereminoArm.SetGcodeLine(0)
                Else
                    ' ------------------------------------------------------ PAUSE
                    StopRunningState()
                End If
            End If
            OldGcodeSlotValue = NewGcodeSlotValue
        End If
    End Sub


    ' ==============================================================================================================
    '   AUTO SAVE FOR ThereminoArm PARAMS - USING LostFocus
    ' ==============================================================================================================
    Private Sub ThereminoArmParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Invert0.LostFocus, _
                                                                                                            chk_Invert1.LostFocus, _
                                                                                                            chk_Invert2.LostFocus, _
                                                                                                            chk_Invert3.LostFocus, _
                                                                                                            txt_Rapp0.LostFocus, _
                                                                                                            txt_Rapp1.LostFocus, _
                                                                                                            txt_Rapp2.LostFocus, _
                                                                                                            txt_Rapp3.LostFocus, _
                                                                                                            txt_Delta0.LostFocus, _
                                                                                                            txt_Delta1.LostFocus, _
                                                                                                            txt_Delta2.LostFocus, _
                                                                                                            txt_Delta3.LostFocus, _
                                                                                                            txt_Len0Y.LostFocus, _
                                                                                                            txt_Len0Z.LostFocus, _
                                                                                                            txt_Len1Y.LostFocus, _
                                                                                                            txt_Len2X.LostFocus, _
                                                                                                            txt_Len2Y.LostFocus, _
                                                                                                            txt_Len2Z.LostFocus, _
                                                                                                            txt_Len3X.LostFocus, _
                                                                                                            txt_Len3Y.LostFocus, _
                                                                                                            txt_Len3Z.LostFocus, _
                                                                                                            txt_OriginX.LostFocus, _
                                                                                                            txt_OriginY.LostFocus, _
                                                                                                            txt_OriginZ.LostFocus, _
                                                                                                            txt_ScaleX.LostFocus, _
                                                                                                            txt_ScaleY.LostFocus, _
                                                                                                            txt_ScaleZ.LostFocus, _
                                                                                                            txt_Ztrip.LostFocus, _
                                                                                                            txt_Zdown.LostFocus, _
                                                                                                            txt_Zup.LostFocus, _
                                                                                                            txt_FirstMotorSlot.LostFocus, _
                                                                                                            txt_NumMotorSlots.LostFocus, _
                                                                                                            txt_GcodeAutomation.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub ThereminoArmParams_Delta_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_DeltaEndRadius.LostFocus, _
                                                                                                                txt_DeltaMotorRadius.LostFocus, _
                                                                                                                txt_DeltaVerticalArms.LostFocus, _
                                                                                                                txt_DeltaMotorArms.LostFocus, _
                                                                                                                txt_DeltaVerticalDist.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub ThereminoArmGcodeParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_OriginX.TextChanged, _
                                                                                                       txt_OriginY.LostFocus, _
                                                                                                       txt_OriginZ.LostFocus, _
                                                                                                       txt_ScaleX.LostFocus, _
                                                                                                       txt_ScaleY.LostFocus, _
                                                                                                       txt_ScaleZ.LostFocus, _
                                                                                                       btn_OverrideZ.LostFocus, _
                                                                                                       txt_Ztrip.LostFocus, _
                                                                                                       txt_Zdown.LostFocus, _
                                                                                                       txt_Zup.LostFocus, _
                                                                                                       chk_AutoParking.LostFocus, _
                                                                                                       chk_AutoSleep.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub


    ' ==============================================================================================================
    '   ThereminoArm and Gcode PARAMS
    ' ==============================================================================================================
    Private Sub ThereminoArmParams_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Invert0.CheckedChanged, _
                                                                                               chk_Invert1.CheckedChanged, _
                                                                                               chk_Invert2.CheckedChanged, _
                                                                                               chk_Invert3.CheckedChanged, _
                                                                                               txt_Rapp0.TextChanged, _
                                                                                               txt_Rapp1.TextChanged, _
                                                                                               txt_Rapp2.TextChanged, _
                                                                                               txt_Rapp3.TextChanged, _
                                                                                               txt_Delta0.TextChanged, _
                                                                                               txt_Delta1.TextChanged, _
                                                                                               txt_Delta2.TextChanged, _
                                                                                               txt_Delta3.TextChanged, _
                                                                                               txt_Len0Y.TextChanged, _
                                                                                               txt_Len0Z.TextChanged, _
                                                                                               txt_Len1Y.TextChanged, _
                                                                                               txt_Len2X.TextChanged, _
                                                                                               txt_Len2Y.TextChanged, _
                                                                                               txt_Len2Z.TextChanged, _
                                                                                               txt_Len3X.TextChanged, _
                                                                                               txt_Len3Y.TextChanged, _
                                                                                               txt_Len3Z.TextChanged, _
                                                                                               txt_FirstMotorSlot.TextChanged, _
                                                                                               txt_NumMotorSlots.TextChanged, _
                                                                                               txt_GcodeAutomation.TextChanged
        If Not EventsAreEnabled Then Return
        ThereminoArm_SetArmGeometryParams()
        ThereminoArm.CalcAreaLimits()
        ThereminoArm.InvalidateBaseImage()
        StartTimers()
    End Sub

    Private Sub ThereminoArmParams_Delta_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_DeltaEndRadius.TextChanged, _
                                                                                                              txt_DeltaMotorRadius.TextChanged, _
                                                                                                              txt_DeltaVerticalArms.TextChanged, _
                                                                                                              txt_DeltaMotorArms.TextChanged, _
                                                                                                              txt_DeltaVerticalDist.TextChanged
        If Not EventsAreEnabled Then Return
        ThereminoArm_SetArmGeometryParams_Delta()
        ThereminoArm.CalcAreaLimits()
        ThereminoArm.InvalidateBaseImage()
        StartTimers()
    End Sub

    Private Sub ThereminoArmGcodeParams_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_OriginX.TextChanged, _
                                                                                                             txt_OriginY.TextChanged, _
                                                                                                             txt_OriginZ.TextChanged, _
                                                                                                             txt_ScaleX.TextChanged, _
                                                                                                             txt_ScaleY.TextChanged, _
                                                                                                             txt_ScaleZ.TextChanged, _
                                                                                                             txt_Ztrip.TextChanged, _
                                                                                                             txt_Zdown.TextChanged, _
                                                                                                             txt_Zup.TextChanged, _
                                                                                                             chk_AutoParking.CheckedChanged, _
                                                                                                             chk_AutoSleep.CheckedChanged
        If Not EventsAreEnabled Then Return
        ThereminoArm_SetGcodeParams()
        StopTimers()
        ThereminoArm.DrawGcodeToBaseImage()
    End Sub

    Friend Sub ThereminoArm_SetGcodeParams()
        With ThereminoArm
            .Origin.x = txt_OriginX.NumericValue
            .Origin.y = txt_OriginY.NumericValue
            .Origin.z = txt_OriginZ.NumericValue
            .Scale.x = txt_ScaleX.NumericValue
            .Scale.y = txt_ScaleY.NumericValue
            .Scale.z = txt_ScaleZ.NumericValue
            .Zup = txt_Zup.NumericValue
            .Zdown = txt_Zdown.NumericValue
            .Ztrip = txt_Ztrip.NumericValue
            .AutoParking = chk_AutoParking.Checked
            .AutoSleep = chk_AutoSleep.Checked
        End With
    End Sub

    Friend Sub ThereminoArm_SetArmGeometryParams()
        With ThereminoArm
            .Joint(0).Invert = chk_Invert0.Checked
            .Joint(1).Invert = chk_Invert1.Checked
            .Joint(2).Invert = chk_Invert2.Checked
            .Joint(3).Invert = chk_Invert3.Checked

            .Joint(0).Rapport = txt_Rapp0.NumericValue
            .Joint(1).Rapport = txt_Rapp1.NumericValue
            .Joint(2).Rapport = txt_Rapp2.NumericValue
            .Joint(3).Rapport = txt_Rapp3.NumericValue

            .Joint(0).DeltaAngle = txt_Delta0.NumericValue
            .Joint(1).DeltaAngle = txt_Delta1.NumericValue
            .Joint(2).DeltaAngle = txt_Delta2.NumericValue
            .Joint(3).DeltaAngle = txt_Delta3.NumericValue

            .Link0y = txt_Len0Y.NumericValue
            .Link0z = txt_Len0Z.NumericValue
            .Link1y = txt_Len1Y.NumericValue
            .Link2x = txt_Len2X.NumericValue
            .Link2y = txt_Len2Y.NumericValue
            .Link2z = txt_Len2Z.NumericValue
            .Link3x = txt_Len3X.NumericValue
            .Link3y = txt_Len3Y.NumericValue
            .Link3z = txt_Len3Z.NumericValue

            .mFirstMotorSlot = txt_FirstMotorSlot.NumericValueInteger
            .NumMotorSlots = txt_NumMotorSlots.NumericValueInteger
            GcodeAutomationSlot = txt_GcodeAutomation.NumericValueInteger

            Dim en As Boolean = True
            If .NumMotorSlots = 3 Then en = False
            TrackBar3.Enabled = en
            txt_TimeServo3.Enabled = en
            txt_AngleServo3.Enabled = en
            If .NumMotorSlots = 4 Then en = False
            TrackBar4.Enabled = en
            txt_TimeServo4.Enabled = en
            txt_AngleServo4.Enabled = en
            If .NumMotorSlots = 5 Then en = False
            TrackBar5.Enabled = en
            txt_TimeServo5.Enabled = en
            txt_AngleServo5.Enabled = en
            If .NumMotorSlots = 6 Then en = False
            TrackBar6.Enabled = en
            txt_TimeServo6.Enabled = en
            txt_AngleServo6.Enabled = en
            If .NumMotorSlots = 7 Then en = False
            TrackBar7.Enabled = en
            txt_TimeServo7.Enabled = en
            txt_AngleServo7.Enabled = en
        End With
    End Sub

    Private Sub ThereminoArm_SetArmGeometryParams_Delta()
        ThereminoArm.SetDeltaParams(txt_DeltaEndRadius.NumericValue, _
                                    txt_DeltaMotorRadius.NumericValue, _
                                    txt_DeltaVerticalArms.NumericValue, _
                                    txt_DeltaMotorArms.NumericValue, _
                                    txt_DeltaVerticalDist.NumericValue)
    End Sub

    'Friend Sub ThereminoArm_ShowGcodeParams()
    '    Dim oldEnabled As Boolean = EventsAreEnabled
    '    EventsAreEnabled = False
    '    With ThereminoArm
    '        txt_OriginX.NumericValue = .Origin.x
    '        txt_OriginY.NumericValue = .Origin.y
    '        txt_OriginZ.NumericValue = .Origin.z
    '        txt_ScaleX.NumericValue = .Scale.x
    '        txt_ScaleY.NumericValue = .Scale.y
    '        txt_ScaleZ.NumericValue = .Scale.z
    '    End With
    '    EventsAreEnabled = oldEnabled
    'End Sub

    'Friend Sub ThereminoArm_ShowArmGeometryParams()
    '    Dim oldEnabled As Boolean = EventsAreEnabled
    '    EventsAreEnabled = False
    '    With ThereminoArm
    '        txt_Len0.NumericValue = .Link0
    '        txt_Len0H.NumericValue = .Link0H
    '        txt_Len1.NumericValue = .Link1
    '        txt_Len2.NumericValue = .Link2
    '        txt_Len3.NumericValue = .Link3
    '        txt_Len3H.NumericValue = .Link3H

    '        chk_Invert0.Checked = .Angle0_Invert
    '        chk_Invert1.Checked = .Angle1_Invert
    '        chk_Invert2.Checked = .Angle2_Invert
    '        chk_Invert3.Checked = .Angle3_Invert

    '        txt_Rapp0.NumericValue = .Rapport0
    '        txt_Rapp1.NumericValue = .Rapport1
    '        txt_Rapp2.NumericValue = .Rapport2
    '        txt_Rapp3.NumericValue = .Rapport3

    '        txt_Delta0.NumericValue = .DeltaAngle0
    '        txt_Delta1.NumericValue = .DeltaAngle1
    '        txt_Delta2.NumericValue = .DeltaAngle2
    '        txt_Delta3.NumericValue = .DeltaAngle3
    '    End With
    '    EventsAreEnabled = oldEnabled
    'End Sub



    ' ==============================================================================================================
    '   GCODE
    ' ==============================================================================================================
    Private Sub btn_GcodeLoad_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeLoad.ClickButtonArea
        ThereminoArm.OpenGcodeDialog()
        ThereminoArm.SetGcodeLine(0)
        txt_GcodeLine.NumericValueInteger = 0
        ThereminoArm.SetFeedMode_None()
        StopTimers()
        ThereminoArm.DrawGcodeToBaseImage()
    End Sub
    Private Sub txt_GcodeLine_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_GcodeLine.TextChanged
        If Not EventsAreEnabled Then Return
        ThereminoArm.SetGcodeLine(txt_GcodeLine.NumericValueInteger)
        txt_GcodeLine.NumericValueInteger = ThereminoArm.GetGcodeLine
        ThereminoArm.SetFeedMode_None()
    End Sub
    Private Sub btn_GcodeRewind_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeRewind.ClickButtonArea
        If Not EventsAreEnabled Then Return
        ThereminoArm.DrawGcodeToBaseImage_IfInvalid()
        StartTimers()
        ThereminoArm.SetGcodeLine(0)
        ThereminoArm.SetFeedMode_None()
    End Sub

    Private Sub btn_GcodeRun_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeRun.ClickButtonArea
        If Not EventsAreEnabled Then Return
        ThereminoArm.SetStatusBarError("")
        ExecRunningState()
    End Sub

    Private Sub ExecRunningState()
        ThereminoArm.GcodeRunning = False
        ThereminoArm.DrawGcodeToBaseImage_IfInvalid()
        StartTimers()
        If btn_GcodeRun.Checked Then
            ThereminoArm.GcodeRunning = True
        Else
            ThereminoArm.GcodeRunning = False
            If ThereminoArm.AutoParking Then ThereminoArm.GotoParkingPosition()
            ' GcodeAutomation: -2=GcodeCompleted / -1=StopGcode / 0=PauseGcode / 1,2...=LoadGcode 
            Slots.WriteSlot(GcodeAutomationSlot, -2)
        End If
    End Sub

    Friend Sub StopRunningState()
        btn_GcodeRun.Checked = False
        ThereminoArm.GcodeRunning = False
        StopTimers()
        For i As Int32 = 1 To 10000
            ThereminoArm.DisableServoSignals()
        Next
    End Sub

    Friend Sub SendJointValuesToMMF()
        ThereminoArm.SendAllValuesToSlots()
    End Sub


    ' ==============================================================================================================
    '   OverrideZ
    ' ==============================================================================================================
    Private Sub btn_OverrideZ_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_OverrideZ.ClickButtonArea
        If Not EventsAreEnabled Then Return
        ThereminoArm_SetOverrideParams()
    End Sub

    Private Sub ThereminoArm_SetOverrideParams()
        If btn_OverrideZ.Checked Then
            txt_Ztrip.Enabled = True
            txt_Zup.Enabled = True
            txt_Zdown.Enabled = True
            txt_OriginZ.Enabled = False
            txt_ScaleZ.Enabled = False
            ThereminoArm.OverrideZ = True
        Else
            txt_Ztrip.Enabled = False
            txt_Zup.Enabled = False
            txt_Zdown.Enabled = False
            txt_OriginZ.Enabled = True
            txt_ScaleZ.Enabled = True
            ThereminoArm.OverrideZ = False
        End If
    End Sub



    ' ==============================================================================================================
    '   TrackBars - TXT Angles - TXT Timings
    ' ==============================================================================================================
    Private Sub TrackBar_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar0.Scroll, _
                                                                                                    TrackBar1.Scroll, _
                                                                                                    TrackBar2.Scroll, _
                                                                                                    TrackBar3.Scroll, _
                                                                                                    TrackBar4.Scroll, _
                                                                                                    TrackBar5.Scroll, _
                                                                                                    TrackBar6.Scroll, _
                                                                                                    TrackBar7.Scroll
        If Not EventsAreEnabled Then Return
        StopTimers()
        If My.Computer.Keyboard.CtrlKeyDown Then
            Dim tb As TrackBar = CType(sender, TrackBar)
            Dim v As Int32 = CInt(tb.Value / 3556) * 3556
            If v > 64000 Then v = 64000
            If v < 0 Then v = 0
            tb.Value = v
        End If
        ThereminoArm.SetValuesFromTrackBars()
        ThereminoArm.DisplayServoAngles()
        ThereminoArm.DisplayServoTimes()
        SendJointValuesToMMF()
        ThereminoArm.ReflectAnglesToArmPosition()
    End Sub

    Private Sub TxtTiming_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_TimeServo0.TextChanged, _
                                                                                               txt_TimeServo1.TextChanged, _
                                                                                               txt_TimeServo2.TextChanged, _
                                                                                               txt_TimeServo3.TextChanged, _
                                                                                               txt_TimeServo4.TextChanged, _
                                                                                               txt_TimeServo5.TextChanged, _
                                                                                               txt_TimeServo6.TextChanged, _
                                                                                               txt_TimeServo7.TextChanged
        If Not EventsAreEnabled Then Return
        StopTimers()
        ThereminoArm.SetValuesFromServoTimings()
        ThereminoArm.DisplayServoTrackBars()
        ThereminoArm.DisplayServoAngles()
        SendJointValuesToMMF()
        ThereminoArm.ReflectAnglesToArmPosition()
    End Sub

    Private Sub TxtAngles_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_AngleServo0.TextChanged, _
                                                                                               txt_AngleServo1.TextChanged, _
                                                                                               txt_AngleServo2.TextChanged, _
                                                                                               txt_AngleServo3.TextChanged, _
                                                                                               txt_AngleServo4.TextChanged, _
                                                                                               txt_AngleServo5.TextChanged, _
                                                                                               txt_AngleServo6.TextChanged, _
                                                                                               txt_AngleServo7.TextChanged
        If Not EventsAreEnabled Then Return
        StopTimers()
        ThereminoArm.SetValuesFromServoAngles()
        ThereminoArm.DisplayServoTrackBars()
        ThereminoArm.DisplayServoTimes()
        SendJointValuesToMMF()
        ThereminoArm.ReflectAnglesToArmPosition()
    End Sub

    Private Sub btn_Steppers_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Steppers.ClickButtonArea
        If Not EventsAreEnabled Then Return
        Steppers = btn_Steppers.Checked
    End Sub


    ' ==============================================================================================================
    '   Mouse Jog
    ' ==============================================================================================================
    Private Sub PictureBox_Test_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_ArmGeometry.MouseDown
        If ThereminoArm.GcodeRunning Then Return
        If e.Button = Windows.Forms.MouseButtons.Left Then
            StartTimers()
            If e.X < Pic_ArmGeometry.ClientSize.Width - 90 Then
                ThereminoArm.SetPositionFromPboxXY(e.X, e.Y)
            End If
        Else
            StopTimers()
            ThereminoArm.DrawGcodeToBaseImage()
        End If
        Pic_ArmGeometry.Focus()
    End Sub
    Private Sub PictureBox_Test_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_ArmGeometry.MouseMove
        If ThereminoArm.GcodeRunning Then Return
        If e.Button = Windows.Forms.MouseButtons.Left Then
            If e.X < Pic_ArmGeometry.ClientSize.Width - 90 Then
                ThereminoArm.SetPositionFromPboxXY(e.X, e.Y)
            End If
        End If
    End Sub
    Private Sub PictureBox_Test_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_ArmGeometry.MouseWheel
        If ThereminoArm.GcodeRunning Then Return
        StartTimers()
        ThereminoArm.InvalidateBaseImage()
        ThereminoArm.JogZ(e.Delta / 120)
    End Sub



    ' ==============================================================================================================
    '   Keyboard Jog
    ' ==============================================================================================================
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, ByVal keyData As Keys) As Boolean
        If Not Pic_ArmGeometry.Focused Then Return False
        If ThereminoArm.GcodeRunning Then Return False
        StartTimers()
        Dim mm As Double = 1
        mm = txt_JogStep.NumericValue
        Dim handled As Boolean = False
        Select Case keyData
            Case Keys.Left
                ThereminoArm.JogX(mm)
                handled = True
            Case Keys.Right
                ThereminoArm.JogX(-mm)
                handled = True
            Case Keys.Up
                ThereminoArm.JogY(-mm)
                handled = True
            Case Keys.Down
                ThereminoArm.JogY(mm)
                handled = True
            Case Keys.PageUp
                ThereminoArm.JogZ(mm)
                handled = True
            Case Keys.PageDown
                ThereminoArm.JogZ(-mm)
                handled = True
        End Select
        Return handled
    End Function


    ' ==============================================================================================================
    '   MinY - MaxAreaX - ParkingPosition
    ' ==============================================================================================================
    Private Sub txt_MinY_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_MinY.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        ThereminoArm.SetMinY(txt_MinY.NumericValueInteger)
        ThereminoArm.CalcAreaLimits()
        ThereminoArm.DisplayArmGeometry()
        ThereminoArm.InvalidateBaseImage()
    End Sub
    Private Sub txt_MaxAreaX_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_MaxAreaX.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        ThereminoArm.SetMaxAreaX(txt_MaxAreaX.NumericValueInteger)
        ThereminoArm.CalcAreaLimits()
        ThereminoArm.DisplayArmGeometry()
        ThereminoArm.InvalidateBaseImage()
    End Sub
    Private Sub txt_ParkingPositions_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                                Handles txt_ParkingX.TextChanged, _
                                                                                        txt_ParkingY.TextChanged, _
                                                                                        txt_ParkingZ.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        ThereminoArm.SetParkingPosition(txt_ParkingX.NumericValueInteger, _
                                        txt_ParkingY.NumericValueInteger, _
                                        txt_ParkingZ.NumericValueInteger)
        Save_INI()
    End Sub


    ' ==============================================================================================================
    '   Speed
    ' ==============================================================================================================
    Private Sub SpeedParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_FeedRapid.LostFocus, _
                                                                            txt_FeedWork.LostFocus, _
                                                                            txt_MaxError.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub SpeedParams_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_FeedRapid.TextChanged, _
                                                                            txt_FeedWork.TextChanged, _
                                                                            txt_MaxError.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        SetPrecisionParams()
    End Sub
    Private Sub SetPrecisionParams()
        ThereminoArm.SetSpeed(txt_FeedRapid.NumericValueInteger, _
                              txt_FeedWork.NumericValueInteger, _
                              txt_MaxError.NumericValue)
    End Sub


    ' =======================================================================================
    '   COMBO CONFIGURATIONS
    ' =======================================================================================
    Private Sub cmb_Configurations_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_Configurations.DropDown
        Combo_SetIndex_FromString(cmb_Configurations, ThereminoArm.ArmType)
    End Sub
    Private Sub cmb_Configurations_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_Configurations.DropDownClosed
        StopTimers()

        ThereminoArm.SetConfiguration(cmb_Configurations.Text)
        ThereminoArm.SetConfigurationDefaultValues()
        ThereminoArm.InitDefaultParams()
        ThereminoArm_SetArmGeometryParams()
        ThereminoArm_SetArmGeometryParams_Delta()
        ThereminoArm_SetGcodeParams()
        ThereminoArm_SetOverrideParams()

        ThereminoArm.SetMinY(txt_MinY.NumericValueInteger)
        ThereminoArm.SetMaxAreaX(txt_MaxAreaX.NumericValueInteger)
        ThereminoArm.CalcAreaLimits()

        ThereminoArm.InvalidateBaseImage()
        ThereminoArm.DisplayArmGeometry()
        ThereminoArm.DrawGcodeToBaseImage()
        Save_INI()

        StartTimers()
        Pic_ArmGeometry.Focus()
    End Sub

End Class