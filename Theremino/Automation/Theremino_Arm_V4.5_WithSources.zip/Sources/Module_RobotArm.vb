﻿
Imports System.Math
Imports System.Collections.Generic


Module Module_RobotArm

    ' ==================================================================================================
    '   ThereminoArm
    ' ==================================================================================================

    Friend Steppers As Boolean
    Friend GcodeAutomationSlot As Int32
    Friend GcodeFile As String

    Friend ThereminoArm As Arm

    Friend Sub ThereminoArm_Init()
        ThereminoArm = New Arm(Form1.Pic_ArmGeometry, _
                               Form1.TrackBar0, _
                               Form1.TrackBar1, _
                               Form1.TrackBar2, _
                               Form1.TrackBar3, _
                               Form1.TrackBar4, _
                               Form1.TrackBar5, _
                               Form1.TrackBar6, _
                               Form1.TrackBar7, _
                               Form1.txt_TimeServo0, _
                               Form1.txt_TimeServo1, _
                               Form1.txt_TimeServo2, _
                               Form1.txt_TimeServo3, _
                               Form1.txt_TimeServo4, _
                               Form1.txt_TimeServo5, _
                               Form1.txt_TimeServo6, _
                               Form1.txt_TimeServo7, _
                               Form1.txt_AngleServo0, _
                               Form1.txt_AngleServo1, _
                               Form1.txt_AngleServo2, _
                               Form1.txt_AngleServo3, _
                               Form1.txt_AngleServo4, _
                               Form1.txt_AngleServo5, _
                               Form1.txt_AngleServo6, _
                               Form1.txt_AngleServo7)
    End Sub

    Friend Structure Joint
        ' ---------------------------------- User interface
        Dim TrkPos As TrackBar
        Dim TxtTime As MyTextBox
        Dim TxtAngle As MyTextBox
        ' ---------------------------------- 
        Dim Pos As Vec3
        Dim Angle As Double
        Dim OldAngle As Double
        Dim Rapport As Double
        Dim DeltaAngle As Double
        Dim Invert As Boolean
        Dim AngleMin As Double
        Dim AngleMax As Double
        Dim OutValue As Double
    End Structure

    Private Enum Feed_Modes As Int32
        None
        Rapid
        Work
    End Enum

    Const KRAD As Double = PI / 180
    Const KDEG As Double = 180 / PI


    ' ==================================================================================================
    '   CLASS ARM
    ' ==================================================================================================
    Friend Class Arm
        Private k_time As Double

        Private gSizeX As Int32
        Private gSizeY As Int32
        Private gMidX As Int32
        Private gMidY As Int32

        Private MaxArea_X As Int32
        Private MaxArea_Y As Int32
        Private gscale As Single

        Friend mFirstMotorSlot As Int32

        Private DrawSpeed As Int32

        Private MaxPath As Drawing2D.GraphicsPath = New Drawing2D.GraphicsPath

        Private ArmPic As PictureBox
        Private ArmPicGfx As Graphics

        Private OutOfRange As Boolean
        Private Ready As Boolean

        Private mFeedMode As Feed_Modes

        Private mFeedRapid As Double
        Private mFeedNormal As Double

        Private mMaxError As Double

        Private GcodeLines() As String = {""}

        Friend Origin As Vec3
        Friend Scale As Vec3

        Friend OverrideZ As Boolean
        Friend Zup As Double
        Friend Zdown As Double
        Friend Ztrip As Double

        Private ParkingPosition As Vec3

        ' ------------------------------------------ arm geometry
        Friend Link0y As Double
        Friend Link0z As Double
        Friend Link1y As Double
        Friend Link2x As Double
        Friend Link2y As Double
        Friend Link2z As Double
        Friend Link3x As Double
        Friend Link3y As Double
        Friend Link3z As Double

        Private BaseRadius As Single

        Friend Joint(7) As Joint

        Friend NumMotorSlots As Int32

        Friend AutoParking As Boolean = True
        Friend AutoSleep As Boolean = True

        ' ------------------------------------------ limits
        Friend Min_X As Double
        Friend Max_X As Double
        Friend Min_Y As Double
        Friend Max_Y As Double
        Friend Min_Z As Double
        Friend Max_Z As Double

        Dim MinScale_X As Int32
        Dim MaxScale_X As Int32
        Dim MinScale_Y As Int32
        Dim MaxScale_Y As Int32

        ' ------------------------------------------ working positions
        Friend Dest As Vec3
        Friend Tip As Vec3
        Friend Tip_Angle As Double

        Friend Sub New(ByRef _ArmPic As PictureBox, _
                       ByRef Track0 As TrackBar, _
                       ByRef Track1 As TrackBar, _
                       ByRef Track2 As TrackBar, _
                       ByRef Track3 As TrackBar, _
                       ByVal Track4 As TrackBar, _
                       ByRef Track5 As TrackBar, _
                       ByRef Track6 As TrackBar, _
                       ByRef Track7 As TrackBar, _
                       ByVal txt0 As MyTextBox, _
                       ByVal txt1 As MyTextBox, _
                       ByVal txt2 As MyTextBox, _
                       ByVal txt3 As MyTextBox, _
                       ByVal txt4 As MyTextBox, _
                       ByVal txt5 As MyTextBox, _
                       ByVal txt6 As MyTextBox, _
                       ByVal txt7 As MyTextBox, _
                       ByVal txta0 As MyTextBox, _
                       ByVal txta1 As MyTextBox, _
                       ByVal txta2 As MyTextBox, _
                       ByVal txta3 As MyTextBox, _
                       ByVal txta4 As MyTextBox, _
                       ByVal txta5 As MyTextBox, _
                       ByVal txta6 As MyTextBox, _
                       ByVal txta7 As MyTextBox)

            ArmPic = _ArmPic
            Joint(0).TrkPos = Track0
            Joint(1).TrkPos = Track1
            Joint(2).TrkPos = Track2
            Joint(3).TrkPos = Track3
            Joint(4).TrkPos = Track4
            Joint(5).TrkPos = Track5
            Joint(6).TrkPos = Track6
            Joint(7).TrkPos = Track7
            Joint(0).TxtTime = txt0
            Joint(1).TxtTime = txt1
            Joint(2).TxtTime = txt2
            Joint(3).TxtTime = txt3
            Joint(4).TxtTime = txt4
            Joint(5).TxtTime = txt5
            Joint(6).TxtTime = txt6
            Joint(7).TxtTime = txt7
            Joint(0).TxtAngle = txta0
            Joint(1).TxtAngle = txta1
            Joint(2).TxtAngle = txta2
            Joint(3).TxtAngle = txta3
            Joint(4).TxtAngle = txta4
            Joint(5).TxtAngle = txta5
            Joint(6).TxtAngle = txta6
            Joint(7).TxtAngle = txta7
            '
            mFeedMode = Feed_Modes.None
        End Sub


        Friend ArmType As String

        Friend Sub SetConfiguration(ByVal _ArmType As String)
            SetControlsVisibility(False)
            Select Case LCase(_ArmType)
                Case "articulated"
                    ArmType = "Articulated"
                    Form1.Panel_Delta.Visible = False
                    SetControlsVisibility(True)
                    Form1.txt_Len2X.Visible = False
                    Form1.txt_Len2Z.Visible = False
                Case "scara"
                    ArmType = "Scara"
                    Form1.Panel_Delta.Visible = False
                    Form1.Label_Joint.Visible = True
                    Form1.Label_Inv.Visible = True
                    Form1.Label_Rapp.Visible = True
                    Form1.Label_Delta.Visible = True
                    Form1.Label_LenX.Visible = True
                    Form1.Label_LenY.Visible = True
                    Form1.Label_LenZ.Visible = True
                    Form1.chk_Invert0.Visible = True
                    Form1.chk_Invert1.Visible = True
                    Form1.chk_Invert2.Visible = True
                    Form1.txt_Rapp0.Visible = True
                    Form1.txt_Rapp1.Visible = True
                    Form1.txt_Rapp2.Visible = True
                    Form1.txt_Delta0.Visible = True
                    Form1.txt_Delta1.Visible = True
                    Form1.txt_Delta2.Visible = True
                    Form1.txt_Len0Y.Visible = True
                    Form1.txt_Len1Y.Visible = True
                    Form1.txt_Len2X.Visible = True
                    Form1.txt_Len2Y.Visible = True
                    Form1.txt_Len2Z.Visible = True
                Case "delta"
                    ArmType = "Delta"
                    Form1.Panel_Delta.Visible = True
                    Form1.Label_Joint.Visible = True
                    Form1.Label_Inv.Visible = True
                    Form1.Label_Rapp.Visible = True
                    Form1.Label_Delta.Visible = True
                    Form1.chk_Invert0.Visible = True
                    Form1.chk_Invert1.Visible = True
                    Form1.chk_Invert2.Visible = True
                    Form1.txt_Rapp0.Visible = True
                    Form1.txt_Rapp1.Visible = True
                    Form1.txt_Rapp2.Visible = True
                    Form1.txt_Delta0.Visible = True
                    Form1.txt_Delta1.Visible = True
                    Form1.txt_Delta2.Visible = True
                Case "cartesian"
                    ArmType = "Cartesian"
                    Form1.Panel_Delta.Visible = False
                    SetControlsVisibility(False)
                Case Else
                    ArmType = ""
                    Form1.Panel_Delta.Visible = False
                    SetControlsVisibility(False)
            End Select
        End Sub

        Private Sub SetControlsVisibility(ByVal show As Boolean)
            Form1.Label_Joint.Visible = show
            Form1.Label_Inv.Visible = show
            Form1.Label_Rapp.Visible = show
            Form1.Label_Delta.Visible = show
            Form1.Label_LenX.Visible = show
            Form1.Label_LenY.Visible = show
            Form1.Label_LenZ.Visible = show
            Form1.chk_Invert0.Visible = show
            Form1.chk_Invert1.Visible = show
            Form1.chk_Invert2.Visible = show
            Form1.chk_Invert3.Visible = show
            Form1.txt_Rapp0.Visible = show
            Form1.txt_Rapp1.Visible = show
            Form1.txt_Rapp2.Visible = show
            Form1.txt_Rapp3.Visible = show
            Form1.txt_Delta0.Visible = show
            Form1.txt_Delta1.Visible = show
            Form1.txt_Delta2.Visible = show
            Form1.txt_Delta3.Visible = show
            Form1.txt_Len0Y.Visible = show
            Form1.txt_Len0Z.Visible = show
            Form1.txt_Len1Y.Visible = show
            Form1.txt_Len2X.Visible = show
            Form1.txt_Len2Y.Visible = show
            Form1.txt_Len2Z.Visible = show
            Form1.txt_Len3X.Visible = show
            Form1.txt_Len3Y.Visible = show
            Form1.txt_Len3Z.Visible = show
        End Sub

        Friend Sub SetConfigurationDefaultValues()
            ' ------------------------------------------ Gcode values
            Form1.txt_OriginX.NumericValue = 0
            Form1.txt_OriginY.NumericValue = 90
            Form1.txt_OriginZ.NumericValue = 0

            Form1.txt_ScaleX.NumericValue = 1
            Form1.txt_ScaleY.NumericValue = 1
            Form1.txt_ScaleZ.NumericValue = 1
            ' ------------------------------------------ arm geometry
            Select Case LCase(ArmType)
                Case "articulated"
                    Form1.chk_Invert0.Checked = False
                    Form1.chk_Invert1.Checked = True
                    Form1.chk_Invert2.Checked = False
                    Form1.chk_Invert3.Checked = False
                    '
                    Form1.txt_Delta0.NumericValue = 0
                    Form1.txt_Delta1.NumericValue = 35
                    Form1.txt_Delta2.NumericValue = 0
                    Form1.txt_Delta3.NumericValue = 30
                    '
                    Form1.txt_Len0Y.NumericValue = 24
                    Form1.txt_Len0Z.NumericValue = 48
                    '
                    Form1.txt_Len1Y.NumericValue = 60
                    Form1.txt_Len2Y.NumericValue = 60
                    '
                    Form1.txt_Len3X.NumericValue = 0
                    Form1.txt_Len3Y.NumericValue = 0
                    Form1.txt_Len3Z.NumericValue = 40

                Case "scara"
                    Form1.chk_Invert0.Checked = False
                    Form1.chk_Invert1.Checked = False
                    Form1.chk_Invert2.Checked = False
                    Form1.txt_Delta0.NumericValue = 0
                    Form1.txt_Delta1.NumericValue = 0
                    Form1.txt_Delta2.NumericValue = 0
                    Form1.txt_Len0Y.NumericValue = 60
                    Form1.txt_Len1Y.NumericValue = 60
                    Form1.txt_Len2X.NumericValue = 0
                    Form1.txt_Len2Y.NumericValue = 0
                    Form1.txt_Len2Z.NumericValue = 0

                Case "delta"
                    Form1.txt_OriginY.NumericValue = 0

                    Form1.chk_Invert0.Checked = False
                    Form1.chk_Invert1.Checked = False
                    Form1.chk_Invert2.Checked = False
                    Form1.txt_Delta0.NumericValue = 20
                    Form1.txt_Delta1.NumericValue = 20
                    Form1.txt_Delta2.NumericValue = 20

                    Form1.txt_DeltaEndRadius.NumericValue = 15
                    Form1.txt_DeltaMotorRadius.NumericValue = 30
                    Form1.txt_DeltaVerticalArms.NumericValue = 130
                    Form1.txt_DeltaMotorArms.NumericValue = 40
                    Form1.txt_DeltaVerticalDist.NumericValue = 140

                Case "cartesian"

            End Select
        End Sub

        Friend Sub InitDefaultParams()
            Select Case LCase(ArmType)
                Case "articulated", "scara"
                    Joint(0).Pos = NewVec3(0, 0, 0)
                    Joint(0).AngleMin = -85
                    Joint(0).AngleMax = 85
                    Joint(1).AngleMin = 20
                    Joint(1).AngleMax = 160
                    Joint(2).AngleMin = 20
                    Joint(2).AngleMax = 160
                    Joint(3).AngleMin = 20
                    Joint(3).AngleMax = 160
                Case "delta"
                    Joint(0).AngleMin = 20
                    Joint(0).AngleMax = 160
                    Joint(1).AngleMin = 20
                    Joint(1).AngleMax = 160
                    Joint(2).AngleMin = 20
                    Joint(2).AngleMax = 160
                    Joint(3).AngleMin = 20
                    Joint(3).AngleMax = 160
            End Select
        End Sub

        Friend Sub CalcAreaLimits()
            ' ------------------------------------------- default max area
            gSizeX = ArmPic.PreferredSize.Width - 130
            gSizeY = ArmPic.PreferredSize.Height
            gMidX = (ArmPic.PreferredSize.Width - 130) \ 2 + 10
            ' ------------------------------------------- default valid area
            Select Case LCase(ArmType)
                Case "articulated", "scara"
                    MaxArea_Y = (MaxArea_X * gSizeY) \ gSizeX
                    MaxArea_Y = 10 * (MaxArea_Y \ 10)
                    gscale = CSng(gSizeY / (MaxArea_Y + 10))

                    Max_Y = MaxArea_Y + 2
                    Min_Y = 0

                    gMidY = 5

                    MinScale_X = -MaxArea_X \ 2
                    MaxScale_X = MaxArea_X \ 2
                    MinScale_Y = 0
                    MaxScale_Y = MaxArea_Y

                    Max_Z = 200
                    Min_Z = -200

                Case "delta"
                    MaxArea_Y = (MaxArea_X * gSizeY) \ gSizeX
                    MaxArea_Y = 10 * (MaxArea_Y \ 10)
                    gscale = CSng(gSizeX / MaxArea_X)

                    Max_Y = MaxArea_Y \ 2 + 8
                    Min_Y = -(MaxArea_Y \ 2 + 8)

                    gMidY = ArmPic.Height \ 2

                    MinScale_X = -MaxArea_X \ 2
                    MaxScale_X = MaxArea_X \ 2
                    MinScale_Y = -MaxArea_Y \ 2
                    MaxScale_Y = MaxArea_Y \ 2

                    Max_Z = 10
                    Min_Z = 0

                Case Else
                    Min_Y = 5

            End Select

            Max_X = (MaxArea_X \ 2 + 4)
            Min_X = -Max_X

            FindMaxArea()
        End Sub

        Friend Sub SetMinY(ByVal _MinY As Int32)
            BaseRadius = _MinY
        End Sub

        Friend Sub SetMaxAreaX(ByVal _MaxAreaX As Int32)
            MaxArea_X = _MaxAreaX
            MaxArea_X = 20 * (MaxArea_X \ 20)
        End Sub

        Friend Sub SetParkingPosition(ByVal x As Int32, ByVal y As Int32, ByVal z As Int32)
            ParkingPosition.x = x
            ParkingPosition.y = y
            ParkingPosition.z = z
            ' ------------------------------------------- default tip setting
            Tip = ParkingPosition
            Tip_Angle = 0
            Dest = Tip
            ' -------------------------------------------
            Form1.StartTimers()
            DisplayArmGeometry()
        End Sub

        Friend Sub SetDrawSpeed(ByVal _DrawSpeed As Int32)
            DrawSpeed = _DrawSpeed
        End Sub

        Friend Sub SetTimerSpeed(ByVal TimerSpeedMillisec As Int32)
            ' ----------------------------------------------- correction  60 seconds per minute
            k_time = TimerSpeedMillisec / 1000 / 60
        End Sub

        ' ------------------------------------------- feed and acc
        ' feed ( mm/min )     ( proxxon = 250 )
        '  acc ( mm/sec/sec ) ( proxxon =  50 )
        ' --------------------------------------------------------
        ' max servo feed about 60000 mm/minute
        ' normal feed = 5000 to 10000
        ' --------------------------------------------------------
        Friend Sub SetSpeed(ByVal FeedRapid As Int32, ByVal FeedWork As Int32, ByVal MaxError As Double)
            mFeedRapid = FeedRapid
            mFeedNormal = FeedWork
            mMaxError = MaxError
        End Sub



        ' ==================================================================================================
        '   HELPER FUNCTIONS
        ' ==================================================================================================
        Friend Sub DisableServoSignals()
            If AutoSleep Then SleepToAllSlots()
        End Sub

        Private Sub SendServoValues()
            If Not OutOfRange Then
                SendAllValuesToSlots()
            End If
        End Sub

        Friend Sub SleepToAllSlots()
            Dim i As Int32 = ThereminoArm.mFirstMotorSlot
            If Steppers Then
            Else
                For j As Int32 = 0 To ThereminoArm.NumMotorSlots - 1
                    Slots.WriteSlot(i + j, NAN_Sleep)
                Next
            End If
        End Sub

        Friend Sub SendAllValuesToSlots()
            Dim i As Int32 = ThereminoArm.mFirstMotorSlot
            If Steppers Then
                For j As Int32 = 0 To ThereminoArm.NumMotorSlots - 1
                    Slots.WriteSlot(i + j * 2, CSng(ThereminoArm.Joint(j).OutValue))
                Next
            Else
                For j As Int32 = 0 To ThereminoArm.NumMotorSlots - 1
                    Slots.WriteSlot(i + j, CSng(ThereminoArm.Joint(j).OutValue))
                Next
            End If
        End Sub

        Friend Sub DisplayServoTrackBars()
            EventsAreEnabled = False
            Dim v As Int32
            For i As Int32 = 0 To 7
                v = CInt(Joint(i).OutValue * 64)
                If v > 64000 Then v = 64000
                If v < 0 Then v = 0
                Joint(i).TrkPos.Value = v
            Next
            EventsAreEnabled = True
        End Sub

        Friend Sub DisplayServoTimes()
            EventsAreEnabled = False
            For i As Int32 = 0 To 7
                Joint(i).TxtTime.NumericValue = Joint(i).OutValue * 2 + 500
            Next
            EventsAreEnabled = True
        End Sub

        Friend Sub DisplayServoAngles()
            EventsAreEnabled = False
            For i As Int32 = 0 To 7
                Joint(i).TxtAngle.NumericValue = 0.18 * Joint(i).OutValue
            Next
            EventsAreEnabled = True
        End Sub

        Friend Sub SetValuesFromTrackBars()
            For i As Int32 = 0 To 7
                Joint(i).OutValue = Joint(i).TrkPos.Value / 64
            Next
        End Sub

        Friend Sub SetValuesFromServoTimings()
            For i As Int32 = 0 To 7
                Joint(i).OutValue = (Joint(i).TxtTime.NumericValue - 500) / 2
            Next
        End Sub

        Friend Sub SetValuesFromServoAngles()
            For i As Int32 = 0 To 7
                Joint(i).OutValue = 1000 * Joint(i).TxtAngle.NumericValue / 180
            Next
        End Sub

        Friend Sub ReflectAnglesToArmPosition()
            Dim a0, a1, a2, a3 As Double
            a0 = Joint(0).TxtAngle.NumericValue
            a1 = Joint(1).TxtAngle.NumericValue
            a2 = Joint(2).TxtAngle.NumericValue
            a3 = Joint(3).TxtAngle.NumericValue
            If Joint(0).Invert Then a0 = 180 - a0
            If Joint(1).Invert Then a1 = 180 - a1
            If Joint(2).Invert Then a2 = 180 - a2
            If Joint(3).Invert Then a3 = 180 - a3
            Select Case LCase(ArmType)
                Case "articulated"
                    DirectKinematicCompute_Articulated(a0 - Joint(0).DeltaAngle - 90, _
                                                       a1 - Joint(1).DeltaAngle, _
                                                       a2 - Joint(2).DeltaAngle, _
                                                       a3 - Joint(3).DeltaAngle)
                Case "scara"
                    DirectKinematicCompute_Scara(a0 - Joint(0).DeltaAngle - 90 + 150, _
                                                 a1 - Joint(1).DeltaAngle)
                Case "delta"
                    DirectKinematicCompute_Delta(a0 - Joint(0).DeltaAngle, _
                                                 a1 - Joint(1).DeltaAngle, _
                                                 a2 - Joint(2).DeltaAngle)
                Case "cartesian"

            End Select
            SetDestination(Tip)
            DisplayArmGeometry()
            'InvalidateBaseImage()
        End Sub


        Private Sub SetDestination(ByVal v As Vec3)
            ' -------------------------------------------------------
            Dest = v
            ' ------------------------------------------------------- removed from Version 3.3
            'If Dest.z < Min_Z Then Dest.z = Min_Z
            'If Dest.z > Max_Z Then Dest.z = Max_Z
            ' ------------------------------------------------------- find max area only if changing Z
            Static oldDestZ As Double = -9999
            If Dest.z <> oldDestZ Then
                oldDestZ = Dest.z
                FindMaxArea()
                'If Not GcodeRunning Then
                '    InvalidateBaseImage()
                'End If
            End If
        End Sub

        Friend Sub GotoParkingPosition()
            SetStatusBarError("")
            mFeedMode = Feed_Modes.Rapid
            LaserControl(False)
            MillMotorControl(False)
            SetDestination(ParkingPosition)
            Do
                TimedUpdate(False)
                TimedDisplay()
                SleepMyThread(CInt(k_time * 60000))
            Loop Until Ready
            Form1.StopTimers()
        End Sub

        Friend Sub GotoSafeZ()
            mFeedMode = Feed_Modes.Rapid
            LaserControl(False)
            MillMotorControl(False)
            SetDestination(NewVec3(Tip.x, Tip.y, Zup))
            Do
                TimedUpdate(False)
                TimedDisplay()
                SleepMyThread(CInt(k_time * 60000))
            Loop Until Ready
            Form1.StopTimers()
        End Sub

        Private Sub LaserControl(ByVal LaserOn As Boolean)
            If NumMotorSlots > 6 Then
                Joint(6).OutValue = If(LaserOn, 1000, 0)
            End If
        End Sub

        Private Sub MillMotorControl(ByVal MotorOn As Boolean)
            If NumMotorSlots > 7 Then
                Joint(7).OutValue = If(MotorOn, 1000, 0)
            End If
        End Sub



        ' ==================================================================================================
        '   JOG
        ' ==================================================================================================
        Friend Sub SetPositionFromPboxXY(ByVal x As Int32, ByVal y As Int32)
            SetDestination(NewVec3(PixelToX(x), PixelToY(y), Dest.z))
            mFeedMode = Feed_Modes.Rapid
        End Sub
        Friend Sub JogX(ByVal delta As Double)
            SetDestination(NewVec3(Dest.x + delta, Dest.y, Dest.z))
            mFeedMode = Feed_Modes.Rapid
        End Sub
        Friend Sub JogY(ByVal delta As Double)
            SetDestination(NewVec3(Dest.x, Dest.y + delta, Dest.z))
            mFeedMode = Feed_Modes.Rapid
        End Sub
        Friend Sub JogZ(ByVal delta As Double)
            ' ------------------------------------------------------- added in Version 3.3
            Dim destz As Double = Dest.z + delta
            If destz < Min_Z Then destz = Min_Z
            If destz > Max_Z Then destz = Max_Z
            ' -------------------------------------------------------
            SetDestination(NewVec3(Dest.x, Dest.y, destz))
            mFeedMode = Feed_Modes.Rapid
        End Sub



        ' =================================================================================================
        '   INVERSE AND DIRECT KINEMATIC COMPUTE
        ' =================================================================================================

        Private Sub InverseKinematicCompute(ByVal tpx As Double, _
                                           ByVal tpy As Double, _
                                           ByVal tpz As Double)

            Select Case LCase(ArmType)
                Case "articulated"
                    InverseKinematicCompute_Articulated(tpx, tpy, tpz)
                Case "scara"
                    InverseKinematicCompute_Scara(tpx, tpy, tpz)
                Case "delta"
                    InverseKinematicCompute_Delta(tpx, tpy, tpz)
            End Select
        End Sub


        ' =================================================================================================
        '   INVERSE AND DIRECT KINEMATIC - ARTICULATED
        ' =================================================================================================

        Private Sub InverseKinematicCompute_Articulated(ByVal tpx As Double, _
                                                        ByVal tpy As Double, _
                                                        ByVal tpz As Double)

            Dim a0, a1a, a1b, a1, a2, a3 As Double
            Dim j1x, j1y, j1z As Double
            Dim j2x, j2y, j2z As Double
            Dim j3x, j3y, j3z As Double
            ' ------------------------------------------------------- Joint 3 position ( delta X )
            CalcVertexB_FromVertexA(tpx, tpy, Link3x, j3x, j3y)
            ' ------------------------------------------------------- Angle0 ( base motor )
            a0 = -Atan2(j3x, j3y)
            ' ------------------------------------------------------- Joint 3 position ( delta Y )
            j3x = j3x + Link3y * Sin(a0)    ' <<< TODO use Tip_angle
            j3y = j3y - Link3y * Cos(a0)    ' <<< TODO use Tip_angle
            ' ------------------------------------------------------- Joint 3 position ( delta Z )
            j3z = tpz + Link3z
            ' ------------------------------------------------------- Joint 1 position
            j1x = -Link0Y * Sin(a0)
            j1y = Link0Y * Cos(a0)
            j1z = Link0Z
            ' ------------------------------------------------------- Joint1 to Joint3 distance
            Dim dist As Double = Sqrt((j1x - j3x) ^ 2 + _
                                      (j1y - j3y) ^ 2 + _
                                      (j1z - j3z) ^ 2)
            ' ------------------------------------------------------- Angle2
            a2 = Acos((Link1Y ^ 2 + Link2Y ^ 2 - dist ^ 2) _
                                       / (2 * Link1Y * Link2Y))
            ' ------------------------------------------------------- calc a1a
            a1a = Asin(Link2Y * Sin(a2) / dist)
            ' ------------------------------------------------------- calc a1b
            a1b = Asin((j3z - j1z) / dist)
            ' ------------------------------------------------------- calc Angle1
            a1 = a1a + a1b
            ' ------------------------------------------------------- calc Angle3
            a3 = KRAD * 180 - a1 - a2
            ' ------------------------------------------------------- Joint2 position  - first method
            'Dim b1 As Double = Cos(a3) * Link2Y
            'Dim b2 As Double = dist - b1
            'j2x = j1x + (j3x - j1x) * b2 / dist
            'j2y = j1y + Cos(a1) * Link1Y
            'j2z = j1z + Sin(a1) * Link1Y
            ' ------------------------------------------------------- Joint2 position - second method (better)
            j2z = j1z + Link1Y * Sin(a1)
            dist = Link1Y * Cos(a1)
            j2x = j1x - dist * Sin(a0)
            j2y = j1y + dist * Cos(a0)
            ' ------------------------------------------------------- all angles in degree
            a0 *= KDEG
            a1 *= KDEG
            a2 *= KDEG
            a3 *= KDEG
            ' ------------------------------------------------------- add trimming values
            a0 += Joint(0).DeltaAngle
            a1 += Joint(1).DeltaAngle
            a2 += Joint(2).DeltaAngle
            a3 += Joint(3).DeltaAngle
            ' ------------------------------------------------------- 3 motors only
            If NumMotorSlots < 4 Then
                a3 = 0
            End If
            ' ------------------------------------------------------- test and assign
            If Double.IsNaN(a0) Or Double.IsNaN(a1) Or _
                                   Double.IsNaN(a2) Or _
                                   Double.IsNaN(a3) Or _
                                   Double.IsNaN(j1x) Or _
                                   Double.IsNaN(j1y) Or _
                                   Double.IsNaN(j1z) Or _
                                   Double.IsNaN(j2x) Or _
                                   Double.IsNaN(j2y) Or _
                                   Double.IsNaN(j2z) Or _
                                   Double.IsNaN(j3x) Or _
                                   Double.IsNaN(j3y) Or _
                                   Double.IsNaN(j3z) Then

                OutOfRange = True
            Else
                OutOfRange = False
                Joint(0).Angle = a0
                Joint(1).Angle = a1
                Joint(2).Angle = a2
                Joint(3).Angle = a3
                Joint(1).Pos.x = j1x
                Joint(1).Pos.y = j1y
                Joint(1).Pos.z = j1z
                Joint(2).Pos.x = j2x
                Joint(2).Pos.y = j2y
                Joint(2).Pos.z = j2z
                Joint(3).Pos.x = j3x
                Joint(3).Pos.y = j3y
                Joint(3).Pos.z = j3z
            End If
            ' ------------------------------------------------------- limit angles to valid range
            For i As Int32 = 0 To Min(3, NumMotorSlots - 1)
                With Joint(i)
                    If .Angle < .AngleMin Then .Angle = .AngleMin : OutOfRange = True
                    If .Angle > .AngleMax Then .Angle = .AngleMax : OutOfRange = True
                End With
            Next
            ' ------------------------------------------------------- limit to X and Y to Min-Max
            If tpx < Min_X Then OutOfRange = True
            If tpx > Max_X Then OutOfRange = True
            If tpy < Min_Y Then OutOfRange = True
            If tpy > Max_Y Then OutOfRange = True
            ' ------------------------------------------------------- limit to BaseRadius
            If Sqrt(tpx ^ 2 + tpy ^ 2) < BaseRadius + 1 Then
                OutOfRange = True
            End If
            ' ------------------------------------------------------- set output values ( 0 to 1000 )
            For j As Int32 = 0 To Min(3, NumMotorSlots - 1)
                a0 = 1000 * Joint(j).Angle / 180.0
                If j = 0 Then a0 += 500
                If Joint(j).Invert Then a0 = 1000 - a0
                Joint(j).OutValue = a0
            Next
            ' ------------------------------------------------------- test for direct kinematic
            'DirectKinematicCompute_Articulated(Joint(0).Angle - Joint(0).DeltaAngle, _
            '                                   Joint(1).Angle - Joint(1).DeltaAngle, _
            '                                   Joint(2).Angle - Joint(2).DeltaAngle, _
            '                                   Joint(3).Angle - Joint(3).DeltaAngle)
        End Sub

        Private Sub DirectKinematicCompute_Articulated(ByVal a0 As Double, _
                                                       ByVal a1 As Double, _
                                                       ByVal a2 As Double, _
                                                       ByVal a3 As Double)

            Dim j1x, j1y, j1z As Double
            Dim j2x, j2y, j2z As Double
            Dim j3x, j3y, j3z As Double
            Dim dist As Double
            ' ------------------------------------------------------- convert to radians
            a0 *= KRAD
            a1 *= KRAD
            a2 *= KRAD
            a3 *= KRAD
            ' ------------------------------------------------------- Joint 1 position
            j1x = -Link0y * Sin(a0)
            j1y = Link0y * Cos(a0)
            J1z = Link0z
            ' ------------------------------------------------------- Joint 2 position
            j2z = j1z + Link1y * Sin(a1)
            dist = Link1y * Cos(a1)
            j2x = j1x - dist * Sin(a0)
            j2y = j1y + dist * Cos(a0)
            ' ------------------------------------------------------- Joint 3 position
            j3z = j2z - Link2y * Sin(a2 + a1)
            dist = Link2y * Cos(-(a2 + a1))
            j3x = j2x + dist * Sin(a0)
            j3y = j2y - dist * Cos(a0)
            ' ------------------------------------------------------- Set Tip position
            Tip.x = j3x
            Tip.y = j3y
            Tip.z = j3z - Link3z
            ' ------------------------------------------------------- Set Joint positions
            Joint(1).Pos.x = j1x
            Joint(1).Pos.y = j1y
            Joint(1).Pos.z = j1z
            Joint(2).Pos.x = j2x
            Joint(2).Pos.y = j2y
            Joint(2).Pos.z = j2z
            Joint(3).Pos.x = j3x
            Joint(3).Pos.y = j3y
            Joint(3).Pos.z = j3z
            ' ------------------------------------------------------- all angles in degree
            a0 *= KDEG
            a1 *= KDEG
            a2 *= KDEG
            a3 *= KDEG
            ' ------------------------------------------------------- add trimming values
            a0 += Joint(0).DeltaAngle
            a1 += Joint(1).DeltaAngle
            a2 += Joint(2).DeltaAngle
            a3 += Joint(3).DeltaAngle
            ' ------------------------------------------------------- set joint angles
            Joint(0).Angle = a0
            Joint(1).Angle = a1
            Joint(2).Angle = a2
            Joint(3).Angle = a3
        End Sub




        ' =================================================================================================
        '   INVERSE AND DIRECT KINEMATIC - SCARA
        ' =================================================================================================

        Private Sub InverseKinematicCompute_Scara(ByVal tpx As Double, _
                                                  ByVal tpy As Double, _
                                                  ByVal tpz As Double)
            Dim a0, a0a, a0b, a1 As Double
            Dim a12, Link12y As Double
            Dim j1x, j1y As Double
            Dim j2x, j2y As Double
            Dim j3x, j3y As Double
            Dim dist As Double
            ' ------------------------------------------------------- Joint0 to Tip distance (SCARA)
            dist = Sqrt(tpx ^ 2 + tpy ^ 2)
            ' ------------------------------------------------------- calc the length of the virtual link (Link12) 
            Link12y = Sqrt((Link1y + Link2y) ^ 2 + Link2x ^ 2)
            ' ------------------------------------------------------- Angle12 (SCARA)
            a12 = Acos((Link0y ^ 2 + Link12y ^ 2 - dist ^ 2) _
                               / (2 * Link0y * Link12y))
            ' ------------------------------------------------------- calc a0a (SCARA)
            a0a = Asin(Link12y * Sin(a12) / dist)
            ' ------------------------------------------------------- calc a0b (SCARA)
            If tpx >= 0 Then
                a0b = Asin(tpy / dist)
            Else
                a0b = KRAD * 180 - Asin(tpy / dist)
                'a0b = KRAD * 90 + Asin(-tpx / dist)
            End If
            ' ------------------------------------------------------- calc Angle0 (SCARA)
            a0 = a0a + a0b
            ' ------------------------------------------------------- Joint1 position (SCARA)
            j1x = Cos(a0) * Link0y
            j1y = Sin(a0) * Link0y

            ' -----------------------------------------------------------------------------
            ' Joint3 is used to store the position of the Link2X-Link2Y intersection
            '  ( the 90 degree angle that joints Link2x and Link2y ) 
            ' -----------------------------------------------------------------------------
            ' ------------------------------------------------------- calc the position of the Joint3
            'CalcVertexB_FromVertsAC(tpx, tpy, _
            '                        j1x, j1y, _
            '                        Link2x, _
            '                        j3x, j3y)
            ' ------------------------------------------------------- calc the position of the Joint3 (faster)
            CalcVertexB_FromVertsAC(tpx, tpy, _
                                    j1x, j1y, _
                                    Link2y + Link1y, _
                                    Link12y, _
                                    Link2x, _
                                    j3x, j3y)
            ' ------------------------------------------------------- calc the position of the Joint2
            Dim k As Double = Link1y / (Link1y + Link2y)
            j2x = j1x + k * (j3x - j1x)
            j2y = j1y + k * (j3y - j1y)
            ' ------------------------------------------------------- Joint0 to Joint2 distance (SCARA)
            dist = Sqrt(j2x ^ 2 + j2y ^ 2)
            ' ------------------------------------------------------- Angle1 (SCARA)
            a1 = Acos((Link0y ^ 2 + Link1y ^ 2 - dist ^ 2) _
                               / (2 * Link0y * Link1y))
            ' ------------------------------------------------------- all angles in degree (SCARA)
            a0 *= KDEG
            a1 *= KDEG
            ' ------------------------------------------------------- add trimming values (SCARA)
            a0 += Joint(0).DeltaAngle - 150
            a1 += Joint(1).DeltaAngle

            ' ------------------------------------------------------- test and assign (SCARA)
            If Double.IsNaN(a0) Or Double.IsNaN(a1) Or _
                                   Double.IsNaN(j1x) Or _
                                   Double.IsNaN(j1y) Or _
                                   Double.IsNaN(j2x) Or _
                                   Double.IsNaN(j2y) Then
                OutOfRange = True
            Else
                OutOfRange = False
                Joint(0).Angle = a0
                Joint(1).Angle = a1
                Joint(1).Pos.x = j1x
                Joint(1).Pos.y = j1y
                Joint(2).Pos.x = j2x
                Joint(2).Pos.y = j2y
                Joint(3).Pos.x = j3x
                Joint(3).Pos.y = j3y
            End If
            ' ------------------------------------------------------- Joint2 angle (the pen-up pen-down angle)
            Joint(2).Angle = tpz + Link2z + Joint(2).DeltaAngle
            ' ------------------------------------------------------- limit angles to valid range
            For i As Int32 = 0 To 1
                With Joint(i)
                    If .Angle < .AngleMin Then .Angle = .AngleMin : OutOfRange = True
                    If .Angle > .AngleMax Then .Angle = .AngleMax : OutOfRange = True
                End With
            Next
            ' ------------------------------------------------------- limit tip X and Y to MIN MAX (SCARA)
            If tpx < Min_X Then OutOfRange = True
            If tpx > Max_X Then OutOfRange = True
            If tpy < Min_Y Then OutOfRange = True
            If tpy > Max_Y Then OutOfRange = True
            ' ------------------------------------------------------- limit tip to BaseRadius
            If Sqrt(tpx ^ 2 + tpy ^ 2) < BaseRadius + 1 Then
                OutOfRange = True
            End If
            ' ------------------------------------------------------- set output values ( 0 to 1000 ) (SCARA)
            For j As Int32 = 0 To 2
                a0 = 1000 * Joint(j).Angle / 180.0
                If j = 0 Then a0 += 500
                If Joint(j).Invert Then a0 = 1000 - a0
                Joint(j).OutValue = a0
            Next
            ' ------------------------------------------------------- test for direct kinematic
            'DirectKinematicCompute_Scara((Joint(0).Angle - Joint(0).DeltaAngle + 150), _
            '                             (Joint(1).Angle - Joint(1).DeltaAngle))
        End Sub

        Private Sub DirectKinematicCompute_Scara(ByVal a0 As Double, _
                                                 ByVal a1 As Double)
            Dim j1x, j1y As Double
            Dim j2x, j2y As Double
            Dim j3x, j3y As Double
            Dim tpx, tpy As Double
            ' -------------------------------------------------------
            a1 = a0 + a1
            ' ------------------------------------------------------- convert to radians
            a0 *= KRAD
            a1 *= KRAD
            ' ------------------------------------------------------- Joint 1 position
            j1x = Link0y * Cos(a0)
            j1y = Link0y * Sin(a0)
            ' ------------------------------------------------------- Joint 2 position
            j2x = j1x - Link1y * Cos(a1)
            j2y = j1y - Link1y * Sin(a1)
            ' -----------------------------------------------------------------------------
            ' Joint3 is used only to store the position of the Link2X-Link2Y intersection
            '  ( the 90 degree angle that joints Link2x and Link2y ) 
            ' -----------------------------------------------------------------------------
            ' ------------------------------------------------------- Joint 3 position
            Dim k As Double = (Link1y + Link2y) / Link1y
            j3x = j1x + k * (j2x - j1x)
            j3y = j1y + k * (j2y - j1y)
            ' ------------------------------------------------------- Tip position - method 1
            CalcVertexC_FromVertsAB(j1x, j1y, _
                                    j3x, j3y, _
                                    Link2x, Link1y + Link2y, _
                                    tpx, tpy)
            ' ------------------------------------------------------- Tip position - method 2
            'Dim k2 As Double = Link2x / (Link1y + Link2y)
            'tpx = j3x + k2 * (j3y - j1y)
            'tpy = j3y - k2 * (j3x - j1x)

            ' -----------------------------------------------------------------------------
            '  Enable following lines to test
            ' -----------------------------------------------------------------------------
            Tip.x = tpx
            Tip.y = tpy
            ' ------------------------------------------------------- joint positions
            Joint(1).Pos.x = j1x
            Joint(1).Pos.y = j1y
            Joint(2).Pos.x = j2x
            Joint(2).Pos.y = j2y
            Joint(3).Pos.x = j3x
            Joint(3).Pos.y = j3y
            ' ------------------------------------------------------- all angles in degree
            a0 *= KDEG
            a1 *= KDEG
            ' ------------------------------------------------------- add trimming values
            a0 += Joint(0).DeltaAngle - 150
            a1 += Joint(1).DeltaAngle
            ' ------------------------------------------------------- set joint angles
            Joint(0).Angle = a0
            Joint(1).Angle = a1
        End Sub




        ' =================================================================================================
        '   INVERSE AND DIRECT KINEMATIC - DELTA
        '   from: http://forums.trossenrobotics.com/tutorials/introduction-129/delta-robot-kinematics-3276/
        ' =================================================================================================

        Friend Sub SetDeltaParams(ByVal EndPivotsRadius As Double, _
                                  ByVal MotorPivotsRadius As Double, _
                                  ByVal VerticalArms As Double, _
                                  ByVal MotorArms As Double, _
                                  ByVal VerticalDistance As Double)

            ' ---------------------------------------- e and f are sides of the Base and EndEffector triangles 
            '                                          side lengths are radius multiplied by 2/tan(30) = 2*sqrt(3) 
            Delta_EndPivotsRadius = EndPivotsRadius
            Delta_MotorPivotsRadius = MotorPivotsRadius
            Delta_e = 2 * sqrt3 * EndPivotsRadius
            Delta_f = 2 * sqrt3 * MotorPivotsRadius
            Delta_re = VerticalArms
            Delta_rf = MotorArms
            Delta_Z = VerticalDistance
        End Sub

        Private Delta_EndPivotsRadius As Double
        Private Delta_MotorPivotsRadius As Double

        Private Delta_e As Double   ' EndEffector-Triangle sides 
        Private Delta_f As Double   ' Motor-Triangle sides
        Private Delta_re As Double  ' vertical arms length
        Private Delta_rf As Double  ' motor arms length
        Private Delta_Z As Double   ' distance top bottom

        Const sqrt3 As Double = 1.7320508075688772 'Sqrt(3)
        Const sin120 As Double = sqrt3 / 2.0
        Const cos120 As Double = -0.5
        Const tan60 As Double = sqrt3
        Const sin30 As Double = 0.5
        Const tan30 As Double = 1 / sqrt3

        Private Sub InverseKinematicCompute_Delta(ByVal tpx As Double, _
                                                  ByVal tpy As Double, _
                                                  ByVal tpz As Double)

            ' ------------------------------------------------------- 
            Dim a0, a1, a2 As Double
            Dim j0x, j0y, j0z As Double
            Dim j1x, j1y, j1z As Double
            Dim j2x, j2y, j2z As Double
            ' ------------------------------------------------------- remove height
            tpz -= Delta_Z
            ' ------------------------------------------------------- calc a0 a1 a2 (DELTA)
            Dim tipxc120 As Double = tpx * cos120
            Dim tipyc120 As Double = tpy * cos120
            Dim tipxs120 As Double = tpx * sin120
            Dim tipys120 As Double = tpy * sin120
            a0 = Delta_CalcAngle(tpx, tpy, tpz)
            a1 = Delta_CalcAngle(tipxc120 + tipys120, tipyc120 - tipxs120, tpz) ' rotate coords to +120 deg
            a2 = Delta_CalcAngle(tipxc120 - tipys120, tipyc120 + tipxs120, tpz) ' rotate coords to -120 deg
            ' ------------------------------------------------------- Joint positions (DELTA)
            Dim t As Double = (Delta_f - Delta_e) * tan30 / 2
            ' ---------------------------------------------------------------------------
            j0y = -(t + Delta_rf * Cos(a0))
            j0x = 0
            j0z = -Delta_rf * Sin(a0)
            ' ---------------------------------------------------------------------------
            j1y = (t + Delta_rf * Cos(a1)) * sin30
            j1x = j1y * tan60
            j1z = -Delta_rf * Sin(a1)
            ' ---------------------------------------------------------------------------
            j2y = (t + Delta_rf * Cos(a2)) * sin30
            j2x = -j2y * tan60
            j2z = -Delta_rf * Sin(a2)

            ' ------------------------------------------------------- all angles in degree (DELTA)
            a0 *= KDEG
            a1 *= KDEG
            a2 *= KDEG
            ' ------------------------------------------------------- add trimming values (DELTA)
            a0 += Joint(0).DeltaAngle
            a1 += Joint(1).DeltaAngle
            a2 += Joint(2).DeltaAngle

            ' ------------------------------------------------------- test and assign (DELTA)
            If Double.IsNaN(a0) Or Double.IsNaN(a1) Or _
                                   Double.IsNaN(a2) Then
                OutOfRange = True
            Else
                OutOfRange = False
                Joint(0).Angle = a0
                Joint(1).Angle = a1
                Joint(2).Angle = a2
                Joint(0).Pos.x = j0x
                Joint(0).Pos.y = j0y
                Joint(0).Pos.z = j0z
                Joint(1).Pos.x = j1x
                Joint(1).Pos.y = j1y
                Joint(1).Pos.z = j1z
                Joint(2).Pos.x = j2x
                Joint(2).Pos.y = j2y
                Joint(2).Pos.z = j2z
            End If

            ' ------------------------------------------------------- limit angles to valid range
            For i As Int32 = 0 To 2
                With Joint(i)
                    If .Angle < .AngleMin Then .Angle = .AngleMin : OutOfRange = True
                    If .Angle > .AngleMax Then .Angle = .AngleMax : OutOfRange = True
                End With
            Next

            ' ------------------------------------------------------- limit tip to MIN MAX (DELTA)
            If tpx < Min_X Then OutOfRange = True
            If tpx > Max_X Then OutOfRange = True
            If tpy < Min_Y Then OutOfRange = True
            If tpy > Max_Y Then OutOfRange = True

            ' ------------------------------------------------------- set output values ( 0 to 1000 ) (DELTA)
            For j As Int32 = 0 To 2
                a0 = 1000 * Joint(j).Angle / 180.0
                If Joint(j).Invert Then a0 = 1000 - a0
                Joint(j).OutValue = a0
            Next

            ' ------------------------------------------------------- test for direct kinematic
            'DirectKinematicCompute_Delta(Joint(0).Angle - Joint(0).DeltaAngle, _
            '                             Joint(1).Angle - Joint(1).DeltaAngle, _
            '                             Joint(2).Angle - Joint(2).DeltaAngle)
        End Sub

        Private Function Delta_CalcAngle(ByVal x As Double, ByVal y As Double, ByVal z As Double) As Double
            ' --------------------------------------------------------- 
            Dim y1 As Double = -Delta_f * 0.5 * tan30
            ' --------------------------------------------------------- shift center to edge
            y -= 0.5 * tan30 * Delta_e
            ' --------------------------------------------------------- z = a + b*y
            Dim a As Double = (x * x + y * y + z * z + _
                               Delta_rf * Delta_rf - _
                               Delta_re * Delta_re - y1 * y1) / (2 * z)
            Dim b As Double = (y1 - y) / z
            ' --------------------------------------------------------- discriminant
            Dim d As Double = -(a + b * y1) * (a + b * y1) + _
                              Delta_rf * (b * b * Delta_rf + Delta_rf)
            ' --------------------------------------------------------- non-existing point ?
            If (d < 0) Then OutOfRange = True
            ' --------------------------------------------------------- choosing outer point
            Dim yj As Double = (y1 - a * b - Sqrt(d)) / (b * b + 1)
            Dim zj As Double = a + b * yj
            Return KRAD * 180.0 * Atan(-zj / (y1 - yj)) / PI + If(yj > y1, 180.0, 0.0)
        End Function

        Private Sub DirectKinematicCompute_Delta(ByVal a0 As Double, _
                                                 ByVal a1 As Double, _
                                                 ByVal a2 As Double)
            '
            ' --------------------------------------------------------------------------- convert to radians
            a0 *= KRAD
            a1 *= KRAD
            a2 *= KRAD
            ' ---------------------------------------------------------------------------
            Dim t As Double = (Delta_f - Delta_e) * tan30 / 2
            ' --------------------------------------------------------------------------- Joint 0 position
            Dim y1 As Double = -(t + Delta_rf * Cos(a0))
            Dim x1 As Double = 0
            Dim z1 As Double = -Delta_rf * Sin(a0)
            ' --------------------------------------------------------------------------- Joint 1 position
            Dim y2 As Double = (t + Delta_rf * Cos(a1)) * sin30
            Dim x2 As Double = y2 * tan60
            Dim z2 As Double = -Delta_rf * Sin(a1)
            ' --------------------------------------------------------------------------- Joint 2 position
            Dim y3 As Double = (t + Delta_rf * Cos(a2)) * sin30
            Dim x3 As Double = -y3 * tan60
            Dim z3 As Double = -Delta_rf * Sin(a2)
            ' ---------------------------------------------------------------------------
            Dim dnm As Double = (y2 - y1) * x3 - (y3 - y1) * x2
            ' ---------------------------------------------------------------------------
            Dim w1 As Double = y1 * y1 + z1 * z1
            Dim w2 As Double = x2 * x2 + y2 * y2 + z2 * z2
            Dim w3 As Double = x3 * x3 + y3 * y3 + z3 * z3
            ' --------------------------------------------------------------------------- x = (a1*z + b1)/dnm
            Dim aa1 As Double = (z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)
            Dim bb1 As Double = -((w2 - w1) * (y3 - y1) - (w3 - w1) * (y2 - y1)) / 2.0
            ' --------------------------------------------------------------------------- y = (a2*z + b2)/dnm;
            Dim aa2 As Double = -(z2 - z1) * x3 + (z3 - z1) * x2
            Dim bb2 As Double = ((w2 - w1) * x3 - (w3 - w1) * x2) / 2.0
            ' --------------------------------------------------------------------------- a*z^2 + b*z + c = 0
            Dim a As Double = aa1 * aa1 + aa2 * aa2 + dnm * dnm
            Dim b As Double = 2 * (aa1 * bb1 + aa2 * (bb2 - y1 * dnm) - z1 * dnm * dnm)
            Dim c As Double = (bb2 - y1 * dnm) * (bb2 - y1 * dnm) + _
                               bb1 * bb1 + dnm * dnm * (z1 * z1 - Delta_re * Delta_re)
            ' --------------------------------------------------------------------------- discriminant
            Dim d As Double = b * b - 4.0 * a * c
            'If (d < 0) Then Return ' non-existing point

            ' -----------------------------------------------------------------------------
            '  Working OK - Enable following lines to test
            ' -----------------------------------------------------------------------------
            ' ------------------------------------------------------- Tip position
            Dim z As Double = -0.5 * (b + Sqrt(d)) / a
            Tip.x = (aa1 * z + bb1) / dnm
            Tip.y = (aa2 * z + bb2) / dnm
            Tip.z = z + Delta_Z
            ' ------------------------------------------------------- all angles in degree
            a0 *= KDEG
            a1 *= KDEG
            a2 *= KDEG
            ' ------------------------------------------------------- add trimming values
            a0 += Joint(0).DeltaAngle
            a1 += Joint(1).DeltaAngle
            a2 += Joint(2).DeltaAngle
            ' ------------------------------------------------------- set joint angles
            Joint(0).Angle = a0
            Joint(1).Angle = a1
            Joint(2).Angle = a2
        End Sub




        ' ==================================================================================================
        '   DISPLAY ARM GEOMETRY
        ' ==================================================================================================
        Private Function XtoPixel(ByVal x As Double) As Int32
            If Double.IsNaN(x) Then x = 0
            Return CInt(gMidX - x * gscale)
        End Function
        Private Function YtoPixel(ByVal y As Double) As Int32
            If Double.IsNaN(y) Then y = 0
            Return CInt(gMidY + y * gscale)
        End Function
        Private Function PixelToX(ByVal px As Int32) As Double
            Return (gMidX - px) / gscale
        End Function
        Private Function PixelToY(ByVal py As Int32) As Double
            Return (py - gMidY) / gscale
        End Function

        Friend Sub DisplayArmGeometry()
            If ArmPic.ClientSize.Width < 1 Then Return

            InitPboxImageAndGraphics()
            '
            If BaseImage IsNot Nothing Then
                ArmPicGfx.DrawImage(BaseImage, 0, 0)
            Else
                DrawBaseRadius()
                DrawMaxPath()
                DrawScale()
            End If
            '
            Select Case LCase(ArmType)
                Case "articulated"
                    DisplayArmGeometry_Articulated()
                Case "scara"
                    DisplayArmGeometry_Scara()
                Case "delta"
                    DisplayArmGeometry_Delta()
            End Select
        End Sub

        Private Sub InitPboxImageAndGraphics()
            ' ------------------------------------------------------------------------ using a bitmap for best performance
            If ArmPic.Image Is Nothing OrElse _
               ArmPic.Image.Width <> ArmPic.ClientSize.Width OrElse _
               ArmPic.Image.Height <> ArmPic.ClientSize.Height Then
                InitPictureboxImage(ArmPic)
            End If
            ' ------------------------------------------------------------------------ "Graphics.FromImage" for best performance
            ArmPicGfx = Graphics.FromImage(ArmPic.Image)
            ArmPicGfx.Clear(Color.FromArgb(255, 255, 230))
        End Sub

        Private Sub DrawMaxPath()
            Dim ScaledPath As Drawing2D.GraphicsPath
            ScaledPath = CType(MaxPath.Clone, Drawing2D.GraphicsPath)
            Dim m As Drawing2D.Matrix = New Drawing2D.Matrix()
            m.Translate(CSng(gMidX), CSng(gMidY))
            m.Scale(-gscale, gscale)
            ScaledPath.Transform(m)
            ArmPicGfx.DrawPath(New Pen(Color.FromArgb(255, 255, 0, 0), 2), ScaledPath)
            If OutOfRange Then
                ArmPicGfx.FillPath(Brushes.Red, ScaledPath)
            Else
                ArmPicGfx.FillPath(Brushes.Yellow, ScaledPath)
            End If
        End Sub

        Private Sub DrawBaseRadius()
            Dim r As Single = BaseRadius * gscale
            Dim d As Single = r * 2
            ArmPicGfx.FillEllipse(Brushes.PaleGoldenrod, gMidX - r, gMidY - r, d, d)
            ArmPicGfx.DrawEllipse(New Pen(Color.Gray, 1), gMidX - r, gMidY - r, d, d)
        End Sub

        Private Sub DrawScale()
            Dim p1 As Pen = New Pen(Color.Gray, 1)
            Dim p2 As Pen = New Pen(Color.Gray, 2)
            For x As Int32 = MinScale_X To MaxScale_X Step 10
                ArmPicGfx.DrawLine(p1, XtoPixel(x), YtoPixel(MinScale_Y), XtoPixel(x), YtoPixel(MaxScale_Y))
            Next
            For y As Int32 = MinScale_Y To MaxScale_Y Step 10
                ArmPicGfx.DrawLine(p1, XtoPixel(MinScale_X), YtoPixel(y), XtoPixel(MaxScale_X), YtoPixel(y))
            Next
            ArmPicGfx.DrawLine(p2, XtoPixel(0), YtoPixel(MinScale_Y), XtoPixel(0), YtoPixel(MaxScale_Y))
            ArmPicGfx.DrawLine(p2, XtoPixel(MinScale_X), YtoPixel(0), XtoPixel(MaxScale_X), YtoPixel(0))
        End Sub

        Private Sub DisplayArmGeometry_Articulated()
            ' ------------------------------------------------------------------------ joints
            DrawJoint_Articulated(Joint(1).Pos, Color.Black, 1)
            DrawJoint_Articulated(Joint(2).Pos, Color.Blue, 2)
            DrawJoint_Articulated(Joint(3).Pos, Color.Green, 3)
            If Tip.z <= 0 Then
                DrawJoint_Articulated(Tip, Color.Black, 4)
            Else
                DrawJoint_Articulated(Tip, Color.Red, 4)
            End If
            ' ------------------------------------------------------------------------ text values
            Dim px As Int32 = ArmPic.ClientSize.Width - 88
            Dim f As Font = New Font("Courier new", 10, FontStyle.Bold)
            ArmPicGfx.DrawString(" a0 = " & (Joint(0).Angle + 90).ToString("00"), f, Brushes.Black, px, 5)
            ArmPicGfx.DrawString(" a1 = " & Joint(1).Angle.ToString("00"), f, Brushes.Black, px, 20)
            ArmPicGfx.DrawString(" a2 = " & Joint(2).Angle.ToString("00"), f, Brushes.Black, px, 35)
            ArmPicGfx.DrawString(" a3 = " & Joint(3).Angle.ToString("00"), f, Brushes.Black, px, 50)
            ArmPicGfx.DrawString("j1x = " & Joint(1).Pos.x.ToString("00"), f, Brushes.Black, px, 75)
            ArmPicGfx.DrawString("j1y = " & Joint(1).Pos.y.ToString("00"), f, Brushes.Black, px, 90)
            ArmPicGfx.DrawString("j1z = " & Joint(1).Pos.z.ToString("00"), f, Brushes.Black, px, 105)
            ArmPicGfx.DrawString("j2x = " & Joint(2).Pos.x.ToString("00"), f, Brushes.Black, px, 125)
            ArmPicGfx.DrawString("j2y = " & Joint(2).Pos.y.ToString("00"), f, Brushes.Black, px, 140)
            ArmPicGfx.DrawString("j2z = " & Joint(2).Pos.z.ToString("00"), f, Brushes.Black, px, 155)
            ArmPicGfx.DrawString("j3x = " & Joint(3).Pos.x.ToString("00"), f, Brushes.Black, px, 175)
            ArmPicGfx.DrawString("j3y = " & Joint(3).Pos.y.ToString("00"), f, Brushes.Black, px, 190)
            ArmPicGfx.DrawString("j3z = " & Joint(3).Pos.z.ToString("00"), f, Brushes.Black, px, 205)
            ArmPicGfx.DrawString("TipX = " & Tip.x.ToString("00"), f, Brushes.Black, px, 240)
            ArmPicGfx.DrawString("TipY = " & Tip.y.ToString("00"), f, Brushes.Black, px, 255)
            ArmPicGfx.DrawString("TipZ = " & Tip.z.ToString("00"), f, Brushes.Black, px, 270)
            ' ------------------------------------------------------------------------
            ArmPic.Refresh()
        End Sub

        Private Sub DrawJoint_Articulated(ByVal pos As Vec3, _
                                          ByVal col As Color, _
                                          ByVal JointIndex As Int32)
            Dim j1x As Int32 = XtoPixel(pos.x)
            Dim j1y As Int32 = YtoPixel(pos.y)
            Dim j2x As Int32 = XtoPixel(-pos.z)
            Dim j2y As Int32 = YtoPixel(pos.y)
            Static oldj2x As Int32
            Static oldj2y As Int32
            If JointIndex = 1 Then
                oldj2x = j2x
                oldj2y = j2y
            End If
            Dim p1 As Pen = New Pen(Color.LightGray, 5)
            If JointIndex = 4 Then
                ArmPicGfx.DrawLine(p1, oldj2x, oldj2y, oldj2x, j2y)
                ArmPicGfx.DrawLine(p1, oldj2x, j2y, j2x, j2y)
            Else
                ArmPicGfx.DrawLine(p1, oldj2x, oldj2y, j2x, j2y)
            End If
            ArmPicGfx.FillEllipse(New SolidBrush(col), j1x - 5, j1y - 5, 10, 10)
            ArmPicGfx.DrawEllipse(New Pen(col, 2), j2x - 5, j2y - 5, 10, 10)
            oldj2x = j2x
            oldj2y = j2y
        End Sub

        Private Sub DisplayArmGeometry_Scara()
            ' ------------------------------------------------------------------------ joints
            DrawJoint_Scara(Joint(0).Pos, Color.Black, 0)
            DrawJoint_Scara(Joint(1).Pos, Color.Blue, 1)
            DrawJoint_Scara(Joint(2).Pos, Color.Green, 2)
            DrawJoint_Scara(Joint(3).Pos, Color.Gray, 3)
            If Tip.z <= 0 Then
                DrawJoint_Scara(Tip, Color.Black, 3)
            Else
                DrawJoint_Scara(Tip, Color.Red, 3)
            End If
            ' ------------------------------------------------------------------------ text values
            Dim px As Int32 = ArmPic.ClientSize.Width - 88
            Dim f As Font = New Font("Courier new", 10, FontStyle.Bold)
            ArmPicGfx.DrawString(" a0 = " & (Joint(0).Angle + 90).ToString("00"), f, Brushes.Black, px, 5)
            ArmPicGfx.DrawString(" a1 = " & Joint(1).Angle.ToString("00"), f, Brushes.Black, px, 20)
            ArmPicGfx.DrawString("j1x = " & Joint(1).Pos.x.ToString("00"), f, Brushes.Black, px, 50)
            ArmPicGfx.DrawString("j1y = " & Joint(1).Pos.y.ToString("00"), f, Brushes.Black, px, 65)
            ArmPicGfx.DrawString("j2x = " & Joint(2).Pos.x.ToString("00"), f, Brushes.Black, px, 90)
            ArmPicGfx.DrawString("j2y = " & Joint(2).Pos.y.ToString("00"), f, Brushes.Black, px, 105)
            ArmPicGfx.DrawString("TipX = " & Tip.x.ToString("00"), f, Brushes.Black, px, 140)
            ArmPicGfx.DrawString("TipY = " & Tip.y.ToString("00"), f, Brushes.Black, px, 155)
            ArmPicGfx.DrawString("TipZ = " & Tip.z.ToString("00"), f, Brushes.Black, px, 170)
            ' ------------------------------------------------------------------------
            ArmPic.Refresh()
        End Sub

        Private Sub DrawJoint_Scara(ByVal pos As Vec3, ByVal col As Color, ByVal JointIndex As Int32)
            Dim j1x As Int32 = XtoPixel(pos.x)
            Dim j1y As Int32 = YtoPixel(pos.y)
            Static oldj1x As Int32
            Static oldj1y As Int32
            If JointIndex = 0 Then
                oldj1x = j1x
                oldj1y = j1y
            End If
            Dim p1 As Pen = New Pen(Color.LightGray, 8)
            ArmPicGfx.DrawLine(p1, oldj1x, oldj1y, j1x, j1y)
            ArmPicGfx.DrawEllipse(New Pen(col, 2), j1x - 5, j1y - 5, 10, 10)
            oldj1x = j1x
            oldj1y = j1y
        End Sub

        Private Sub DisplayArmGeometry_Delta()

            Dim tx As Int32 = XtoPixel(Tip.x)
            Dim ty As Int32 = YtoPixel(Tip.y)
            If Tip.z <= 0 Then
                ArmPicGfx.FillEllipse(New SolidBrush(Color.Black), tx - 5, ty - 5, 10, 10)
            Else
                ArmPicGfx.FillEllipse(New SolidBrush(Color.Red), tx - 5, ty - 5, 10, 10)
            End If

            Dim e1x As Int32 = XtoPixel(Tip.x)
            Dim e1y As Int32 = YtoPixel(Tip.y - Delta_EndPivotsRadius)
            Dim e2x As Int32 = XtoPixel(Tip.x + Delta_e / 4)
            Dim e2y As Int32 = YtoPixel(Tip.y + Delta_EndPivotsRadius / 2)
            Dim e3x As Int32 = XtoPixel(Tip.x - Delta_e / 4)
            Dim e3y As Int32 = YtoPixel(Tip.y + Delta_EndPivotsRadius / 2)

            Dim j1x As Int32 = XtoPixel(Joint(0).Pos.x)
            Dim j1y As Int32 = YtoPixel(Joint(0).Pos.y)
            Dim j2x As Int32 = XtoPixel(Joint(1).Pos.x)
            Dim j2y As Int32 = YtoPixel(Joint(1).Pos.y)
            Dim j3x As Int32 = XtoPixel(Joint(2).Pos.x)
            Dim j3y As Int32 = YtoPixel(Joint(2).Pos.y)

            Dim m1x As Int32 = XtoPixel(0)
            Dim m1y As Int32 = YtoPixel(0 - Delta_MotorPivotsRadius)
            Dim m2x As Int32 = XtoPixel(0 + Delta_f / 4)
            Dim m2y As Int32 = YtoPixel(0 + Delta_MotorPivotsRadius / 2)
            Dim m3x As Int32 = XtoPixel(0 - Delta_f / 4)
            Dim m3y As Int32 = YtoPixel(0 + Delta_MotorPivotsRadius / 2)

            Dim p1 As Pen = New Pen(Color.Black, 1)
            Dim p2 As Pen = New Pen(Color.Green, 2)
            Dim p3 As Pen = New Pen(Color.Red, 4)

            ArmPicGfx.DrawLine(p1, e1x, e1y, e2x, e2y)
            ArmPicGfx.DrawLine(p1, e2x, e2y, e3x, e3y)
            ArmPicGfx.DrawLine(p1, e3x, e3y, e1x, e1y)

            ArmPicGfx.DrawLine(p2, e1x, e1y, j1x, j1y)
            ArmPicGfx.DrawLine(p2, e2x, e2y, j2x, j2y)
            ArmPicGfx.DrawLine(p2, e3x, e3y, j3x, j3y)

            ArmPicGfx.DrawLine(p3, j1x, j1y, m1x, m1y)
            ArmPicGfx.DrawLine(p3, j2x, j2y, m2x, m2y)
            ArmPicGfx.DrawLine(p3, j3x, j3y, m3x, m3y)

            ArmPicGfx.DrawLine(p1, m1x, m1y, m2x, m2y)
            ArmPicGfx.DrawLine(p1, m2x, m2y, m3x, m3y)
            ArmPicGfx.DrawLine(p1, m3x, m3y, m1x, m1y)

            ' ------------------------------------------------------------------------ text values
            Dim px As Int32 = ArmPic.ClientSize.Width - 88
            Dim f As Font = New Font("Courier new", 10, FontStyle.Bold)
            ArmPicGfx.DrawString(" a0 = " & Joint(0).Angle.ToString("00"), f, Brushes.Black, px, 5)
            ArmPicGfx.DrawString(" a1 = " & Joint(1).Angle.ToString("00"), f, Brushes.Black, px, 20)
            ArmPicGfx.DrawString(" a2 = " & Joint(2).Angle.ToString("00"), f, Brushes.Black, px, 35)
            ArmPicGfx.DrawString("j0x = " & Joint(0).Pos.x.ToString("00"), f, Brushes.Black, px, 60)
            ArmPicGfx.DrawString("j0y = " & Joint(0).Pos.y.ToString("00"), f, Brushes.Black, px, 75)
            ArmPicGfx.DrawString("j0z = " & Joint(0).Pos.z.ToString("00"), f, Brushes.Black, px, 90)
            ArmPicGfx.DrawString("j1x = " & Joint(1).Pos.x.ToString("00"), f, Brushes.Black, px, 115)
            ArmPicGfx.DrawString("j1y = " & Joint(1).Pos.y.ToString("00"), f, Brushes.Black, px, 130)
            ArmPicGfx.DrawString("j1z = " & Joint(1).Pos.z.ToString("00"), f, Brushes.Black, px, 145)
            ArmPicGfx.DrawString("j2x = " & Joint(2).Pos.x.ToString("00"), f, Brushes.Black, px, 170)
            ArmPicGfx.DrawString("j2y = " & Joint(2).Pos.y.ToString("00"), f, Brushes.Black, px, 185)
            ArmPicGfx.DrawString("j2z = " & Joint(2).Pos.z.ToString("00"), f, Brushes.Black, px, 200)
            ArmPicGfx.DrawString("TipX = " & Dest.x.ToString("00"), f, Brushes.Black, px, 240)
            ArmPicGfx.DrawString("TipY = " & Dest.y.ToString("00"), f, Brushes.Black, px, 255)
            ArmPicGfx.DrawString("TipZ = " & Dest.z.ToString("00"), f, Brushes.Black, px, 270)
            ' ------------------------------------------------------------------------
            ArmPic.Refresh()
        End Sub




        ' ==============================================================================================
        '   MAX AREA - FOLLOW BORDER
        ' ==============================================================================================
        Private Const FIND_EPSILON As Single = 0.9

        Private Sub FindMaxArea()

            'Dim t As PrecisionTimer = New PrecisionTimer

            Dim Pos As PointF
            Dim PosStart As PointF
            Dim PosTest As PointF
            Dim oldPoint As PointF
            oldPoint.X = -99999999

            If LCase(ArmType) = "delta" Then
                ' --------------------------------------------------------------- find a not-valid start point
                PosTest.X = 0
                For py As Single = 0 To 1000 Step FIND_EPSILON
                    PosTest.Y = py
                    InverseKinematicCompute(PosTest.X, PosTest.Y, Dest.z)
                    If OutOfRange Then Exit For
                Next
                ' --------------------------------------------------------------- use the last valid point
                PosTest.Y -= FIND_EPSILON
                OutOfRange = False
            Else
                ' --------------------------------------------------------------- find a valid start point
                PosTest.X = 0
                For py As Single = BaseRadius - 10 To 1000 Step FIND_EPSILON
                    PosTest.Y = py
                    InverseKinematicCompute(PosTest.X, PosTest.Y, Dest.z)
                    If Not OutOfRange Then Exit For
                Next
                ' --------------------------------------------------------------- return if start point is not valid
                If OutOfRange Then Return
            End If

            ' --------------------------------------------------------------- 
            PosStart = PosTest
            Pos = PosStart

            ' --------------------------------------------------------------- find valid area external path ( 2800 uS )
            MaxPath.Reset()
            MaxPath.StartFigure()
            Dim startDirection As Int32 = 4
            Dim Direction As Int32 = startDirection
            Dim newDirection As Int32 = startDirection

            Do
                PosTest = MoveByDirection(Pos, Direction)
                InverseKinematicCompute(PosTest.X, PosTest.Y, Dest.z)

                newDirection = Direction
                If OutOfRange Then
                    Do
                        newDirection = (newDirection + 7) Mod 8
                        PosTest = MoveByDirection(Pos, newDirection)
                        InverseKinematicCompute(PosTest.X, PosTest.Y, Dest.z)

                        If Not OutOfRange Or newDirection = Direction Then
                            Direction = newDirection
                            Pos = PosTest
                            Exit Do
                        End If
                    Loop
                Else
                    Dim lastValidPos As PointF = Pos
                    Do
                        newDirection = (newDirection + 1) Mod 8
                        PosTest = MoveByDirection(Pos, newDirection)
                        InverseKinematicCompute(PosTest.X, PosTest.Y, Dest.z)

                        If OutOfRange Or newDirection = Direction Then
                            Direction = newDirection
                            Pos = lastValidPos
                            Exit Do
                        Else
                            lastValidPos = PosTest
                        End If
                    Loop
                End If

                ' --------------------------------------------------------------- found a point "in range"
                If oldPoint.X > -99999999 Then
                    MaxPath.AddLine(oldPoint.X, oldPoint.Y, Pos.X, Pos.Y)
                End If
                oldPoint = Pos

                'Debug.Print(direction.ToString)
                'Debug.Print(pos.x.ToString & "  " & pos.y.ToString)

                If MaxPath.PointCount > 100 AndAlso _
                   Abs(Pos.X - PosStart.X) < FIND_EPSILON AndAlso _
                   Abs(Pos.Y - PosStart.Y) < FIND_EPSILON Then Exit Do

                'If Abs(Pos.X - PosStart.X) < FIND_EPSILON And _
                '   Abs(Pos.Y - PosStart.Y) < FIND_EPSILON And _
                '   Direction = startDirection Then Exit Do

                If MaxPath.PointCount > 3000 Then Exit Do
            Loop

            MaxPath.CloseFigure()
            'If MaxPath.PointCount < 10 Then MaxPath.Reset()

            ' ----------------------------------------------------------- restore valid values
            InverseKinematicCompute(Dest.x, Dest.y, Dest.z)

            't.DebugPrintMicrosec()
            'frmMain.Text = t.GetTimeMicrosec.ToString
        End Sub

        Private Function MoveByDirection(ByVal pos As PointF, ByVal dir As Int32) As PointF
            Dim p As PointF
            Select Case dir
                Case 0 : p.X = pos.X + FIND_EPSILON : p.Y = pos.Y
                Case 1 : p.X = pos.X + FIND_EPSILON : p.Y = pos.Y + FIND_EPSILON
                Case 2 : p.X = pos.X : p.Y = pos.Y + FIND_EPSILON
                Case 3 : p.X = pos.X - FIND_EPSILON : p.Y = pos.Y + FIND_EPSILON
                Case 4 : p.X = pos.X - FIND_EPSILON : p.Y = pos.Y
                Case 5 : p.X = pos.X - FIND_EPSILON : p.Y = pos.Y - FIND_EPSILON
                Case 6 : p.X = pos.X : p.Y = pos.Y - FIND_EPSILON
                Case 7 : p.X = pos.X + FIND_EPSILON : p.Y = pos.Y - FIND_EPSILON
            End Select
            Return p
        End Function

        ' ==============================================================================================
        '   MAX AREA - FindNearestPathPoint
        ' ==============================================================================================
        Private Function FindNearestPathPoint(ByRef _path As Drawing2D.GraphicsPath, ByVal pt As PointF) As PointF
            Dim mindist As Single = Single.MaxValue
            Dim NearestPoint As PointF = pt
            If _path.PointCount > 0 Then
                For Each p As PointF In _path.PathPoints
                    Dim dist As Single = CSng(Sqrt((pt.X - p.X) ^ 2 + (pt.Y - p.Y) ^ 2))
                    If dist < mindist Then
                        NearestPoint.X = p.X
                        NearestPoint.Y = p.Y
                        mindist = dist
                    End If
                Next
            End If
            Return NearestPoint
        End Function



        ' ==================================================================================================
        '   GCODE LOAD
        ' ==================================================================================================
        Friend Sub OpenGcodeDialog()
            '
            GcodeFile = PlatformAdjustedFileName(GcodeFile, Application.StartupPath & "/media/cross.tap")
            '
            Dim ofd As OpenFileDialog = New OpenFileDialog
            If IO.File.Exists(GcodeFile) Then
                ofd.InitialDirectory = IO.Path.GetDirectoryName(GcodeFile)
                ofd.FileName = GcodeFile
            Else
                ofd.InitialDirectory = PlatformAdjustedFileName(Application.StartupPath & "\media")
                ofd.FileName = ""
            End If
            GcodeFile = PlatformAdjustedFileName(GcodeFile)
            ofd.Filter = "Gcode files (*.gc;*.tap;*.nc)|*.gc;*.tap;*.nc|All files (*.*)|*.*"
            ofd.ShowDialog()
            GcodeFile = ofd.FileName
            LoadGcodeFile()
            Save_INI()
            ' ------------------------------------------- suppress collateral events
            Form1.Enabled = False
            Form1.Pic_ArmGeometry.Enabled = False
            Do
                Application.DoEvents()
            Loop Until Control.MouseButtons = MouseButtons.None
            Form1.Pic_ArmGeometry.Enabled = True
            Form1.Enabled = True
        End Sub

        Friend Sub LoadGcodeFile()
            '
            GcodeFile = PlatformAdjustedFileName(GcodeFile)
            If Not IO.File.Exists(GcodeFile) Then
                GcodeFile = PlatformAdjustedFileName(Application.StartupPath & "\media\" & "cross.tap")
            End If
            '
            GcodeFile = PlatformAdjustedFileName(GcodeFile)
            If IO.File.Exists(GcodeFile) Then
                Form1.txt_GcodeFile.Text = IO.Path.GetFileName(GcodeFile)
                GcodeLines = IO.File.ReadAllLines(GcodeFile)
                SetGcodeLine(0)
            End If
            '
            mFeedMode = Feed_Modes.None
        End Sub



        ' ==================================================================================================
        '   DRAW GCODE TO BASE IMAGE
        ' ==================================================================================================
        Private BaseImage As Image

        Friend Sub DrawGcodeToBaseImage()
            '
            If Form1.WindowState = FormWindowState.Minimized Then Return
            If GcodeRunning Then Exit Sub
            If GcodeLines Is Nothing Then Exit Sub
            ' -------------------------------------------- CLEAR image and prepare background
            ArmPicGfx.Clear(Color.FromArgb(255, 255, 230))
            DrawBaseRadius()
            DrawMaxPath()
            DrawScale()
            ' -------------------------------------------- init vars
            Dim p1 As Pen = New Pen(Color.Red, 1)
            Dim p2 As Pen = New Pen(Color.Green, 2)
            Dim x As Int32
            Dim y As Int32
            Dim oldx As Int32
            Dim oldy As Int32
            ' -------------------------------------------- init gcode params
            Dim PrivateGcodeParams As GCODE_PARAMS
            PrivateGcodeParams.Line = 0
            PrivateGcodeParams.FeedMode = Feed_Modes.Rapid
            PrivateGcodeParams.Coord.x = Tip.x
            PrivateGcodeParams.Coord.y = Tip.y
            PrivateGcodeParams.Coord.z = Tip.z
            ' -------------------------------------------- invalidate old position
            oldx = -99999
            While PrivateGcodeParams.Line < GcodeLines.Length
                ' ---------------------------------------- 
                ReadGcodeLine(False, PrivateGcodeParams)
                mFeedMode = PrivateGcodeParams.FeedMode
                x = XtoPixel(PrivateGcodeParams.Coord.x)
                y = YtoPixel(PrivateGcodeParams.Coord.y)
                ' ---------------------------------------- 
                If x <> oldx OrElse y <> oldy Then
                    If oldx > -99999 Then
                        If mFeedMode = Feed_Modes.Rapid Then
                            ArmPicGfx.DrawLine(p1, oldx, oldy, x, y)
                        Else
                            ArmPicGfx.DrawLine(p2, oldx, oldy, x, y)
                        End If
                    End If
                    oldx = x
                    oldy = y
                End If
            End While
            'ArmPicGfx.DrawLine(p1, oldx, oldy, x, y)
            ' -------------------------------------------- 
            ArmPic.Refresh()
            BaseImage = CType(ArmPic.Image.Clone, Image)
        End Sub

        Friend Sub InvalidateBaseImage()
            BaseImage = Nothing
            'DrawBaseImage()
        End Sub

        Friend Sub DrawGcodeToBaseImage_IfInvalid()
            If BaseImage Is Nothing Then
                DrawGcodeToBaseImage()
            End If
        End Sub



        ' ==================================================================================================
        '   ReadGcodeLine
        ' ==================================================================================================
        Private LastToken As String = ""
        Private Sub ReadGcodeLine(ByVal HardwareEnabled As Boolean, ByRef GcParams As GCODE_PARAMS)
            Dim l As List(Of String) = SplitTokens(GcodeLines(GcParams.Line))
            GcParams.Line += 1
            If l(0) = "{" Then Return
            Dim v As Double
            For Each s As String In l
                If s <> "" Then
                    Select Case s.Substring(0, 1)
                        Case "G"
                            Select Case s
                                Case "G0", "G00"
                                    GcParams.FeedMode = Feed_Modes.Rapid
                                Case "G1", "G01"
                                    GcParams.FeedMode = Feed_Modes.Work
                                Case "G2", "G02", "G3", "G03", "G17" ' interpolations
                                    GcParams.FeedMode = Feed_Modes.Work
                                    SetStatusBarError("Unrecognized command " & s)
                                Case "G21" ' interpolations
                                    GcParams.FeedMode = Feed_Modes.Work
                                Case "G04" ' pause with "F"
                                    ' required to not change FeedMode
                                Case Else
                                    GcParams.FeedMode = Feed_Modes.None
                            End Select
                        Case "F"
                            If HardwareEnabled Then
                                If LastToken = "G04" Then
                                    Dim TimeSeconds As Double = Val(Mid(s, 2))
                                    Dim sw As Stopwatch = New Stopwatch
                                    sw.Start()
                                    Do
                                        Application.DoEvents()
                                        SleepMyThread(10)
                                    Loop Until sw.Elapsed.TotalSeconds > TimeSeconds Or Not GcodeRunning
                                Else
                                    Dim newFeed As Double = Val(Mid(s, 2))
                                    If newFeed >= 10 Then mFeedNormal = newFeed
                                End If
                            End If
                        Case "X"
                                If mFeedMode <> Feed_Modes.None Then
                                    GcParams.Coord.x = Val(Mid(s, 2)) * Scale.x + Origin.x
                                End If
                        Case "Y"
                                If mFeedMode <> Feed_Modes.None Then
                                    GcParams.Coord.y = Val(Mid(s, 2)) * Scale.y + Origin.y
                                End If
                        Case "Z"
                                If mFeedMode <> Feed_Modes.None Then
                                    v = Val(Mid(s, 2))
                                    If OverrideZ Then
                                        If v > Ztrip Then
                                            v = Zup
                                            If HardwareEnabled Then LaserControl(False)
                                        Else
                                            v = Zdown
                                            If HardwareEnabled Then LaserControl(True)
                                        End If
                                        GcParams.Coord.z = v
                                    Else
                                        GcParams.Coord.z = v * Scale.z + Origin.z
                                    End If
                                End If
                        Case "("
                                ' ----------------------- comments
                                Exit For
                        Case "N"
                                ' ----------------------- line numbers
                        Case Else
                                ' ----------------------- unknown codes
                    End Select
                    LastToken = s
                End If
            Next
        End Sub

        Private Function SplitTokens(ByVal l As String) As List(Of String)
            SplitTokens = New List(Of String)
            l = l.ToUpper
            l = l.Replace(",", ".")
            ' ---------------------------------------------------- test chars for GCode tokenizing
            Dim testChars As String = "+-. 0123456789" & vbTab
            Dim i As Int32 = 1
            Dim j As Int32 = 2
            Do
                If j > l.Length OrElse Not testChars.Contains(Mid(l, j, 1)) Then
                    SplitTokens.Add(Mid(l, i, j - i).Trim)
                    If j > l.Length Then Exit Do
                    i = j
                    j = i + 1
                Else
                    j += 1
                End If
            Loop
        End Function

        Friend Sub SetGcodeLine(ByVal line As Int32)
            If line > GcodeLines.Length Then line = GcodeLines.Length
            GcodeParams.Line = line
            SetStatusBarError("")
        End Sub

        Friend Function GetGcodeLine() As Int32
            Return GcodeParams.Line
        End Function

        Friend Sub SetFeedMode_None()
            mFeedMode = Feed_Modes.None
        End Sub



        ' ==================================================================================================
        '   GCODE ADVANCEMENT
        ' ==================================================================================================
        Private Structure GCODE_PARAMS
            Dim Line As Int32
            Dim Coord As Vec3
            Dim FeedMode As Feed_Modes
        End Structure
        Private GcodeParams As GCODE_PARAMS

        Friend GcodeRunning As Boolean = False
        Private oldGcodeCoord As Vec3
        Private oldFeedMode As Feed_Modes
        Private oldDirection As Vec3

        Friend Sub InitGcodeParams()
            GcodeParams.FeedMode = Feed_Modes.None
            GcodeParams.Coord.x = Tip.x
            GcodeParams.Coord.y = Tip.y
            GcodeParams.Coord.z = Tip.z
        End Sub

        Private Sub GcodeAdvancement()
            If Ready Then
                If GcodeRunning Then
                    ' ----------------------------------------------------------------- Panic button 
                    'If Control.ModifierKeys = Keys.Control Then
                    'If My.Computer.Keyboard.CtrlKeyDown Then
                    If Key(Keys.Space) Then
                        Form1.StopRunningState()
                        SetStatusBarError("PANIC button pressed")
                        Exit Sub
                    End If
                    ' ----------------------------------------------------------------- 
                    Do
                        ' ------------------------------------------------------------- gcode start ?
                        If GcodeParams.Line = 0 Then
                            InitGcodeParams()
                        End If
                        ' ------------------------------------------------------------- gcode end ?
                        If GcodeParams.Line >= GcodeLines.Length Then
                            'Beep()
                            GcodeRunning = False
                            GcodeParams.Line = 0
                            If AutoParking Then
                                GotoSafeZ()
                                GotoParkingPosition()
                            End If
                            ' GcodeAutomation: -2=GcodeCompleted / -1=StopGcode / 0=PauseGcode / 1,2...=LoadGcode 
                            Slots.WriteSlot(GcodeAutomationSlot, -2)
                            Exit Sub
                        End If

                        ' ------------------------------------------------------------- save the old values
                        oldDirection = GcodeParams.Coord.Subtract(oldGcodeCoord)
                        oldGcodeCoord = GcodeParams.Coord
                        oldFeedMode = GcodeParams.FeedMode

                        ' ------------------------------------------------------------- read line
                        ReadGcodeLine(True, GcodeParams)


                        ' ***********************************
                        '  TESTING ZONE
                        ' ***********************************

                        ' ------------------------------------------------------------- test changed XY and changed Z
                        'Dim ChangedXY As Boolean = False
                        'Dim ChangedZ As Boolean = False
                        'If GcodeParams.Coord.x <> oldGcodeCoord.x Or _
                        '    GcodeParams.Coord.y <> oldGcodeCoord.y Then
                        '    ChangedXY = True
                        'End If
                        'If GcodeParams.Coord.z <> oldGcodeCoord.z Then
                        '    ChangedZ = True
                        'End If

                        'If ChangedXY And ChangedZ Then
                        '    Beep()
                        'End If

                        'If Not ChangedXY And Not ChangedZ And GcodeParams.FeedMode = oldFeedMode Then
                        '    'SetDestination(oldGcodeCoord)
                        '    'mFeedMode = oldFeedMode
                        '    'mFeedMode = GcodeParams.FeedMode
                        '    Continue Do
                        'End If

                        'If GcodeParams.Coord.x = 6.419 Then
                        '    Beep()
                        'End If
                        'If GcodeParams.Coord.z = 0 Then
                        '    Beep()
                        'End If

                        ''If oldFeedMode <> Feed_Modes.Work Or GcodeParams.FeedMode <> Feed_Modes.Work Then
                        'If oldFeedMode <> Feed_Modes.Work Then
                        '    SetDestination(GcodeParams.Coord)
                        '    'oldFeedMode = GcodeParams.FeedMode
                        '    'mFeedMode = GcodeParams.FeedMode
                        '    Exit Do
                        'End If

                        ' ***********************************
                        '  TESTING ZONE - END
                        ' ***********************************


                        Dim TheNewCoordIsValid As Boolean = True
                        ' ------------------------------------------------------------- test direction similitude
                        Dim newDirection As Vec3 = GcodeParams.Coord.Subtract(Dest)
                        If oldDirection.IsValidVector AndAlso newDirection.IsValidVector Then
                            Dim directionSimilitude As Double
                            directionSimilitude = Vec3.DotProductNormalized(oldDirection, newDirection)
                            If Abs(directionSimilitude) < 0.6 Then
                                TheNewCoordIsValid = False
                                'Debug.Print(directionSimilitude.ToString)
                                'Beep()
                            End If
                        End If

                        ' ------------------------------------------------------------- test if changed feed mode
                        If GcodeParams.FeedMode <> oldFeedMode Then
                            TheNewCoordIsValid = False
                        End If

                        ' ------------------------------------------------------------- test maxError
                        If GcodeParams.Coord.Subtract(Dest).Length > mMaxError Then
                            TheNewCoordIsValid = False
                        End If

                        ' ------------------------------------------------------------- if invalid then terminate segment
                        If Not TheNewCoordIsValid Then

                            SetDestination(oldGcodeCoord)

                            mFeedMode = oldFeedMode

                            If GcodeParams.Line > 1 Then GcodeParams.Line -= 1

                            Exit Do

                        End If

                    Loop

                End If
            End If
        End Sub


        ' ==================================================================================================
        '   CALC NEW POSITION
        ' ==================================================================================================
        Private Sub CalcNewPosition()
            ' ----------------------------------------------- Dist3D and DeltaLen
            Dim Dist3D As Vec3 = Dest.Subtract(Tip)
            Dim deltaLen As Double = Dist3D.Length
            ' ----------------------------------------------- feed
            Dim feed As Double
            If mFeedMode = Feed_Modes.Rapid Then
                feed = mFeedRapid * k_time
            Else
                feed = mFeedNormal * k_time
            End If
            ' ----------------------------------------------- test if the destination is reached
            Ready = False
            If feed >= deltaLen Then
                ' -------------------------------------------
                ' TODO - reduce feed
                '  to the max sub-multiple of deltalen
                ' ------------------------------------------- limit the last step
                feed = deltaLen
                Ready = True
            End If
            ' ----------------------------------------------- move to the new tip position
            Tip = Tip.Add(Dist3D.Normalized.Mul(feed))
        End Sub


        ' ==============================================================================================
        '   CorrectOutOfRange
        ' ==============================================================================================
        Private Sub CorrectOutOfRange()
            If OutOfRange Then
                Dim p As PointF
                p.X = CSng(Tip.x)
                p.Y = CSng(Tip.y)
                p = FindNearestPathPoint(MaxPath, p)
                InverseKinematicCompute(p.X, p.Y, Tip.z + 3)
                'Tip.x = p.X
                'Tip.y = p.Y
            End If
        End Sub



        ' =================================================================================================
        '   TIMED UPDATE
        ' =================================================================================================
        Friend Sub TimedUpdate(Optional ByVal ReadGcode As Boolean = True)
            If ReadGcode Then GcodeAdvancement()

            CalcNewPosition()

            InverseKinematicCompute(Tip.x, Tip.y, Tip.z)

            CorrectOutOfRange()

            SendServoValues()
        End Sub

        Friend Sub TimedDisplay()
            EventsAreEnabled = False
            Form1.txt_FeedWork.Text = mFeedNormal.ToString
            Form1.txt_GcodeLine.Text = GcodeParams.Line.ToString
            Form1.btn_GcodeRun.Checked = GcodeRunning
            EventsAreEnabled = True
            '
            DisplayServoTrackBars()
            DisplayServoTimes()
            DisplayServoAngles()
            '
            DisplayArmGeometry()
        End Sub


        Friend Sub SetStatusBarError(ByVal s As String)
            Form1.ToolStripStatusLabel1.BackColor = Color.AliceBlue
            Form1.ToolStripStatusLabel1.ForeColor = Color.Red
            Form1.ToolStripStatusLabel1.Text = s
        End Sub

    End Class

   
End Module
