﻿
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False


    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   Files
    ' =======================================================================================================

    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function

    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function

    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function

    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function





    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function



    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub SaveConfigurationAs()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.DefaultExt = ".txt"
        sfd.Filter = "Configuration file (*.txt)|*txt"
        'sfd.FileName = AssemblyName() & "_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
        sfd.FileName = "ARM_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Save_INI(sfd.FileName)
        End If
    End Sub

    Friend Sub LoadConfiguration()
        Dim ofd As OpenFileDialog = New OpenFileDialog
        ofd.Filter = "Configuration file (*.txt)|*txt"
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Load_INI(ofd.FileName)
        End If
    End Sub

    Friend Sub Save_INI(Optional ByVal iniFileName As String = "")
        '
        If iniFileName = "" Then
            iniFileName = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        End If
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" ArmGeometry"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("ArmType", ThereminoArm.ArmType))
            '
            f.WriteLine(TabString("Invert0", Form1.chk_Invert0.Checked))
            f.WriteLine(TabString("Invert1", Form1.chk_Invert1.Checked))
            f.WriteLine(TabString("Invert2", Form1.chk_Invert2.Checked))
            f.WriteLine(TabString("Invert3", Form1.chk_Invert3.Checked))
            '
            f.WriteLine(TabString("Delta0", Form1.txt_Delta0.NumericValue, "0.0"))
            f.WriteLine(TabString("Delta1", Form1.txt_Delta1.NumericValue, "0.0"))
            f.WriteLine(TabString("Delta2", Form1.txt_Delta2.NumericValue, "0.0"))
            f.WriteLine(TabString("Delta3", Form1.txt_Delta3.NumericValue, "0.0"))
            '
            f.WriteLine(TabString("Len0Y", Form1.txt_Len0Y.NumericValue, "0.0"))
            f.WriteLine(TabString("Len0Z", Form1.txt_Len0Z.NumericValue, "0.0"))
            f.WriteLine(TabString("Len1Y", Form1.txt_Len1Y.NumericValue, "0.0"))
            f.WriteLine(TabString("Len2X", Form1.txt_Len2X.NumericValue, "0.0"))
            f.WriteLine(TabString("Len2Y", Form1.txt_Len2Y.NumericValue, "0.0"))
            f.WriteLine(TabString("Len2Z", Form1.txt_Len2Z.NumericValue, "0.0"))
            f.WriteLine(TabString("Len3X", Form1.txt_Len3X.NumericValue, "0.0"))
            f.WriteLine(TabString("Len3Y", Form1.txt_Len3Y.NumericValue, "0.0"))
            f.WriteLine(TabString("Len3Z", Form1.txt_Len3Z.NumericValue, "0.0"))
            '
            f.WriteLine(TabString("NumMotorSlots", Form1.txt_NumMotorSlots.NumericValueInteger))
            '
            f.WriteLine(TabString("DeltaEndRadius", Form1.txt_DeltaEndRadius.NumericValue, "0.0"))
            f.WriteLine(TabString("DeltaMotorRadius", Form1.txt_DeltaMotorRadius.NumericValue, "0.0"))
            f.WriteLine(TabString("DeltaVerticalArms", Form1.txt_DeltaVerticalArms.NumericValue, "0.0"))
            f.WriteLine(TabString("DeltaMotorArms", Form1.txt_DeltaMotorArms.NumericValue, "0.0"))
            f.WriteLine(TabString("DeltaVerticalDist", Form1.txt_DeltaVerticalDist.NumericValue, "0.0"))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Precision"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("FeedRapid", Form1.txt_FeedRapid.NumericValueInteger))
            f.WriteLine(TabString("FeedNormal", Form1.txt_FeedWork.NumericValueInteger))
            f.WriteLine(TabString("MaxError", Form1.txt_MaxError.NumericValue, "0.00"))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Gcode"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("GcodeFile", GcodeFile))
            f.WriteLine(TabString("OriginX", Form1.txt_OriginX.NumericValue, "0.0"))
            f.WriteLine(TabString("OriginY", Form1.txt_OriginY.NumericValue, "0.0"))
            f.WriteLine(TabString("OriginZ", Form1.txt_OriginZ.NumericValue, "0.0"))
            f.WriteLine(TabString("ScaleX", Form1.txt_ScaleX.NumericValue, "0.0"))
            f.WriteLine(TabString("ScaleY", Form1.txt_ScaleY.NumericValue, "0.0"))
            f.WriteLine(TabString("ScaleZ", Form1.txt_ScaleZ.NumericValue, "0.0"))
            f.WriteLine(TabString("OverrideZ", Form1.btn_OverrideZ.Checked))
            f.WriteLine(TabString("Ztrip", Form1.txt_Ztrip.NumericValue, "0.0"))
            f.WriteLine(TabString("Zdown", Form1.txt_Zdown.NumericValue, "0.0"))
            f.WriteLine(TabString("Zup", Form1.txt_Zup.NumericValue, "0.0"))
            f.WriteLine(TabString("AutoParking", Form1.chk_AutoParking.Checked))
            f.WriteLine(TabString("AutoSleep", Form1.chk_AutoSleep.Checked))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Slots"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("FirstMotorSlot", Form1.txt_FirstMotorSlot.NumericValueInteger))
            f.WriteLine(TabString("GcodeAutomation", Form1.txt_GcodeAutomation.NumericValueInteger))
            f.WriteLine(TabString("Steppers", Form1.btn_Steppers.Checked))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Graphic area"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("MinY", Form1.txt_MinY.NumericValueInteger))
            f.WriteLine(TabString("MaxAreaX", Form1.txt_MaxAreaX.NumericValueInteger))
            f.WriteLine(TabString("ParkingX", Form1.txt_ParkingX.NumericValueInteger))
            f.WriteLine(TabString("ParkingY", Form1.txt_ParkingY.NumericValueInteger))
            f.WriteLine(TabString("ParkingZ", Form1.txt_ParkingZ.NumericValueInteger))
            f.WriteLine(TabString("JogStep", Form1.txt_JogStep.NumericValue, "0.0"))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI(Optional ByVal iniFileName As String = "")
        ' ------------------------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim LoadAll As Boolean = False
        If iniFileName = "" Then
            iniFileName = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
            LoadAll = True
        End If

        If My.Computer.FileSystem.FileExists(iniFileName) Then

            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : If LoadAll Then Form1.Top = Val_Int(l)
                    Case "Form1_Left" : If LoadAll Then Form1.Left = Val_Int(l)
                    Case "Form1_Width" : If LoadAll Then Form1.Width = Val_Int(l)
                    Case "Form1_Height" : If LoadAll Then Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : If LoadAll Then Form1.WindowState = CType((Val(l)), FormWindowState)
                        ' --------------------------------------------------------------- Geometry
                    Case "ArmType" : ThereminoArm.ArmType = l
                        '
                    Case "Invert0" : Form1.chk_Invert0.Checked = l = "True"
                    Case "Invert1" : Form1.chk_Invert1.Checked = l = "True"
                    Case "Invert2" : Form1.chk_Invert2.Checked = l = "True"
                    Case "Invert3" : Form1.chk_Invert3.Checked = l = "True"

                    Case "Delta0" : Form1.txt_Delta0.NumericValue = Val_Double(l)
                    Case "Delta1" : Form1.txt_Delta1.NumericValue = Val_Double(l)
                    Case "Delta2" : Form1.txt_Delta2.NumericValue = Val_Double(l)
                    Case "Delta3" : Form1.txt_Delta3.NumericValue = Val_Double(l)

                    Case "Len0Y" : Form1.txt_Len0Y.NumericValue = Val_Double(l)
                    Case "Len0Z" : Form1.txt_Len0Z.NumericValue = Val_Double(l)
                    Case "Len1Y" : Form1.txt_Len1Y.NumericValue = Val_Double(l)
                    Case "Len2X" : Form1.txt_Len2X.NumericValue = Val_Double(l)
                    Case "Len2Y" : Form1.txt_Len2Y.NumericValue = Val_Double(l)
                    Case "Len2Z" : Form1.txt_Len2Z.NumericValue = Val_Double(l)
                    Case "Len3X" : Form1.txt_Len3X.NumericValue = Val_Double(l)
                    Case "Len3Y" : Form1.txt_Len3Y.NumericValue = Val_Double(l)
                    Case "Len3Z" : Form1.txt_Len3Z.NumericValue = Val_Double(l)
                        '
                    Case "NumMotorSlots" : Form1.txt_NumMotorSlots.NumericValueInteger = Val_Int(l)
                        '
                    Case "DeltaEndRadius" : Form1.txt_DeltaEndRadius.NumericValue = Val_Double(l)
                    Case "DeltaMotorRadius" : Form1.txt_DeltaMotorRadius.NumericValue = Val_Double(l)
                    Case "DeltaVerticalArms" : Form1.txt_DeltaVerticalArms.NumericValue = Val_Double(l)
                    Case "DeltaMotorArms" : Form1.txt_DeltaMotorArms.NumericValue = Val_Double(l)
                    Case "DeltaVerticalDist" : Form1.txt_DeltaVerticalDist.NumericValue = Val_Double(l)
                        ' --------------------------------------------------------------- Speed
                    Case "FeedRapid" : Form1.txt_FeedRapid.NumericValueInteger = Val_Int(l)
                    Case "FeedNormal" : Form1.txt_FeedWork.NumericValueInteger = Val_Int(l)
                    Case "MaxError" : Form1.txt_MaxError.NumericValue = Val_Double(l)
                        ' --------------------------------------------------------------- Gcodes
                    Case "GcodeFile" : GcodeFile = l
                    Case "OriginX" : Form1.txt_OriginX.NumericValue = Val_Double(l)
                    Case "OriginY" : Form1.txt_OriginY.NumericValue = Val_Double(l)
                    Case "OriginZ" : Form1.txt_OriginZ.NumericValue = Val_Double(l)
                    Case "ScaleX" : Form1.txt_ScaleX.NumericValue = Val_Double(l)
                    Case "ScaleY" : Form1.txt_ScaleY.NumericValue = Val_Double(l)
                    Case "ScaleZ" : Form1.txt_ScaleZ.NumericValue = Val_Double(l)
                    Case "OverrideZ" : Form1.btn_OverrideZ.Checked = l = "True"
                    Case "Ztrip" : Form1.txt_Ztrip.NumericValue = Val_Double(l)
                    Case "Zdown" : Form1.txt_Zdown.NumericValue = Val_Double(l)
                    Case "Zup" : Form1.txt_Zup.NumericValue = Val_Double(l)
                    Case "AutoParking" : Form1.chk_AutoParking.Checked = l = "True"
                    Case "AutoSleep" : Form1.chk_AutoSleep.Checked = l = "True"
                        ' --------------------------------------------------------------- Slots
                    Case "FirstMotorSlot" : Form1.txt_FirstMotorSlot.NumericValueInteger = Val_Int(l)
                    Case "GcodeAutomation" : Form1.txt_GcodeAutomation.NumericValueInteger = Val_Int(l)
                    Case "Steppers" : Form1.btn_Steppers.Checked = l = "True"
                        ' --------------------------------------------------------------- Graphic area
                    Case "MinY" : Form1.txt_MinY.NumericValueInteger = Val_Int(l)
                    Case "MaxAreaX" : Form1.txt_MaxAreaX.NumericValueInteger = Val_Int(l)
                    Case "ParkingX" : Form1.txt_ParkingX.NumericValueInteger = Val_Int(l)
                    Case "ParkingY" : Form1.txt_ParkingY.NumericValueInteger = Val_Int(l)
                    Case "ParkingZ" : Form1.txt_ParkingZ.NumericValueInteger = Val_Int(l)
                    Case "JogStep" : Form1.txt_JogStep.NumericValue = Val_Double(l)
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
        ' -------------------------------------------------------------- load gcode
        ThereminoArm.LoadGcodeFile()
    End Sub


    ' ==================================================================================================
    '  SAVE IMAGE
    ' ==================================================================================================
    Public Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)

        extension = LCase(extension)
        filename = RemoveExtension(filename)
        filename += "." & extension
        '
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, Quality)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function

    Friend Sub File_Kill(ByVal filename As String)
        If My.Computer.FileSystem.FileExists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
        End If
    End Sub

    Friend Sub SaveImage(ByVal Prefix As String, ByVal cnt As Control)
        Dim img As Image = GetImage(cnt)
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.Filter = "Portable network graphics (*.png)|*png|JPEG image (*.jpg)|*.jpg"
        sfd.FileName = Prefix & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            SaveImage(img, sfd.FileName, If(sfd.FilterIndex = 2, "jpg", "png"), 100)
        End If
    End Sub

    Friend Function GetImage(ByVal cnt As Control) As Bitmap
        Dim s As Size = cnt.Size
        Dim bmp As Bitmap = New Bitmap(s.Width, s.Height)
        cnt.DrawToBitmap(bmp, New Rectangle(0, 0, s.Width, s.Height))
        Return bmp
    End Function

End Module
