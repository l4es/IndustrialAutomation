
Imports System.Math

Module Module_Utils


    ' =======================================================================================
    '  OpenDirectShowGraph
    ' =======================================================================================

    'Friend Sub OpenDirectShowGraph()
    '    '
    '    Dim GraphEditPath As String = PlatformAdjustedFileNameApplication.StartupPath & "/Graphedit/GraphEdit.exe")
    '    If Not IO.File.Exists(GraphEditPath) Then
    '        MsgBox("GraphEdit not found in the ""GraphEdit"" folder:" & vbCr & vbCr & GraphEditPath, MsgBoxStyle.Information)
    '        Exit Sub
    '    End If

    '    Dim ProcID As Int32
    '    ProcID = Shell_NormalFocus("""" & GraphEditPath & """")

    '    SleepMyThread(800)
    '    Application.DoEvents()

    '    ' -------------------------------------------------- not working
    '    'AppActivate(ProcID)
    '    ' -------------------------------------------------- working but only with MONOGRAM GraphStudio
    '    AppActivate("Untitled - MONOGRAM GraphStudio")

    '    'If TV_IsOpen Then
    '    'SleepMyThread(800)
    '    'Application.DoEvents()
    '    '
    '    SleepMyThread(100)
    '    'Application.DoEvents()
    '    '
    '    'AppActivate(ProcID)
    '    My.Computer.Keyboard.SendKeys("^g", True)           ' CTRL + g
    '    My.Computer.Keyboard.SendKeys("{ENTER}", True)
    '    My.Computer.Keyboard.SendKeys("{ENTER}", True)
    '    '
    '    ' maybe some GraphEdit needs a different opening method... 
    '    'AppActivate(ProcID)
    '    'My.Computer.Keyboard.SendKeys("%fc", True)         ' ALT + f + c
    '    'My.Computer.Keyboard.SendKeys("{ENTER}", True)
    '    'My.Computer.Keyboard.SendKeys("{ENTER}", True)
    '    '
    '    SleepMyThread(500)
    '    My.Computer.Keyboard.SendKeys("^{F5}", True)        ' CTRL + F5
    '    My.Computer.Keyboard.SendKeys("{ENTER}", True)
    '    'End If

    'End Sub


    ' =======================================================================================
    '  Utils
    ' =======================================================================================

    Friend Sub SleepMyThread(ByVal TimeMillisec As Int32)
        System.Threading.Thread.Sleep(TimeMillisec)
    End Sub

    'Friend Function Shell_NormalFocus(ByVal path As String) As Int32
    '    Try
    '        Return Shell(path, AppWinStyle.NormalFocus)
    '    Catch
    '        MsgBox("Cannot open the path: " & vbCr & path, MsgBoxStyle.Information)
    '        Return 0
    '    End Try
    'End Function

    Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
        With pbox
            If .ClientSize.Width < 1 Then Return
            .Image = New Bitmap(.ClientSize.Width, .ClientSize.Height)
        End With
    End Sub

    'Public Function FileExists(ByVal fileName As String) As Boolean
    '    Return My.Computer.FileSystem.FileExists(fileName)
    'End Function


    ' ==============================================================================================================
    '   COMBO FUNCTIONS
    ' ==============================================================================================================

    Friend Sub Combo_Init(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            .Items.Clear()
            .Items.Add(str)
            .SelectedIndex = 0
        End With
        EventsAreEnabled = old
    End Sub

    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub

    Friend Function Combo_GetValue(ByVal combo As ComboBox) As String
        If combo.SelectedIndex < 0 Then Return ""
        Return combo.Items(combo.SelectedIndex).ToString()
    End Function

    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByVal index As Int32)
        If combo.Items.Count < 1 Then Exit Sub
        If index < 0 Then index = 0
        If index > combo.Items.Count - 1 Then index = combo.Items.Count - 1
        combo.SelectedIndex = index
    End Sub



    ' =============================================================================================
    '  ASYNC KEY and MOUSE STATE
    ' =============================================================================================

    Private Const PRESSED_NOW As Int32 = &H8000
    Private Const PRESSED_AFTER_PREVIOUS_CALL As Int32 = &H1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Int32) As Int16
    'Friend Function KeyFromPreviousCall(ByVal k As Int32) As Boolean
    '    KeyPrevious = (GetAsyncKeyState(k) And PRESSED_AFTER_PREVIOUS_CALL) <> 0
    'End Function
    Friend Function Key(ByVal k As Keys) As Boolean
        Key = (GetAsyncKeyState(k) And PRESSED_NOW) <> 0
    End Function
    'Friend Sub WaitMouseOff()
    '    While Key(Keys.LButton) Or Key(Keys.MButton) Or Key(Keys.RButton)
    '        SleepMyThread(1)
    '    End While
    'End Sub
    'Friend Sub WaitKeyOff(ByVal WaitKey As Long)
    '    Do
    '        SleepMyThread(1)
    '    Loop Until Not Key(WaitKey)
    'End Sub



    ' =============================================================================================
    '  CRC
    ' =============================================================================================

    Friend Function ByteArrayFromUint16(ByVal n As Int32) As Byte()
        Dim b(1) As Byte
        b(0) = CByte(n \ 256)
        b(1) = CByte(n Mod 256)
        Return b
    End Function

    'Friend Function CalcCrc(ByRef bytes() As Byte, ByVal nbytes As Int32) As Byte
    '    CalcCrc = 0
    '    For i As Int32 = 0 To nbytes - 1
    '        CalcCrc = CalcCrc Xor bytes(i)
    '        CalcCrc = CByte((CalcCrc + 1) And 255)
    '    Next
    'End Function

    Friend Function ByteArray_From_Uint16Array(ByVal n() As UInt16) As Byte()
        Dim b(n.Length * 2 - 1) As Byte
        For i As Int32 = 0 To n.Length - 1
            b(i * 2) = CByte(n(i) \ 256)
            b(i * 2 + 1) = CByte(n(i) Mod 256)
        Next
        Return b
    End Function



   


    '90 degree rotations in a right-handed coordinate system
    ' ( for left-handed coordinate system switch 'CW' with 'CCW' )
    ' ====================================================================
    '90 degrees CW about x-axis: (x, y, z) -> (x, -z, y)
    '90 degrees CCW about x-axis: (x, y, z) -> (x, z, -y)
    ' --------------------------------------------------------------------
    '90 degrees CW about y-axis: (x, y, z) -> (-z, y, x)
    '90 degrees CCW about y-axis: (x, y, z) -> (z, y, -x)
    ' --------------------------------------------------------------------
    '90 degrees CW about z-axis: (x, y, z) -> (y, -x, z)
    '90 degrees CCW about z-axis: (x, y, z) -> (-y, x, z)
    ' --------------------------------------------------------------------




    ' =================================================================================================
    '   >>> RIGHT TRIANGLE <<< HELPERS  ---  WORKING ALSO IF AA and CC ARE NOT PARALLEL TO X-Y AXES
    ' =================================================================================================

    '    c    ( eventually c = 0,0 )
    '    |\
    ' AA | \ BB
    '    |  \
    '    |___\
    '   b  CC  a


    ' -----------------------------------------------------------------------------
    '  Calc vertex "c" from vertexes "a" and b and distances "AA" and "CC" 
    '  WORKING ALSO IF AA and CC ARE NOT PARALLEL TO X-Y AXES
    ' -----------------------------------------------------------------------------
    Friend Sub CalcVertexC_FromVertsAB(ByVal ax As Double, _
                                       ByVal ay As Double, _
                                       ByVal bx As Double, _
                                       ByVal by As Double, _
                                       ByVal AA As Double, _
                                       ByVal CC As Double, _
                                       ByRef cx As Double, _
                                       ByRef cy As Double)
        Dim k As Double = AA / CC
        cx = bx + k * (by - ay)
        cy = by - k * (bx - ax)
    End Sub

    ' -----------------------------------------------------------------------------
    '  Calc vertex "b" from vertexes "a" and "c" and distances "AA", "BB" and "CC" 
    '  WORKING ALSO IF AA and CC ARE NOT PARALLEL TO X-Y AXES
    ' -----------------------------------------------------------------------------
    Friend Sub CalcVertexB_FromVertsAC(ByVal ax As Double, _
                                       ByVal ay As Double, _
                                       ByVal cx As Double, _
                                       ByVal cy As Double, _
                                       ByVal AA As Double, _
                                       ByVal BB As Double, _
                                       ByVal CC As Double, _
                                       ByRef bx As Double, _
                                       ByRef by As Double)

        bx = (AA * AA * ax - CC * (AA * ay - CC * cx - AA * cy)) / (BB * BB)
        by = ay - CC / AA * (cx - bx)
    End Sub

    ' -----------------------------------------------------------------------------
    '  Calc vertex "b" from vertexes "a" and "c" and distance "CC"
    '  WORKING ALSO IF AA and CC ARE NOT PARALLEL TO X-Y AXES
    ' -----------------------------------------------------------------------------
    Friend Sub CalcVertexB_FromVertsAC(ByVal ax As Double, _
                                       ByVal ay As Double, _
                                       ByVal cx As Double, _
                                       ByVal cy As Double, _
                                       ByVal CC As Double, _
                                       ByRef bx As Double, _
                                       ByRef by As Double)

        Dim BB As Double = Sqrt((ax - cx) ^ 2 + (ay - cy) ^ 2)
        Dim AA As Double = Sqrt(BB ^ 2 - CC ^ 2)

        bx = (AA * AA * ax - CC * (AA * ay - CC * cx - AA * cy)) / (BB * BB)
        by = (AA * CC * ax + AA * AA * ay - AA * CC * cx + CC * CC * cy) / (BB * BB)
    End Sub


    ' -----------------------------------------------------------------------------
    '  Calc vertex "b" from vertex "a"  and distance "CC" ( with c at 0,0 )
    '  WORKING ALSO IF AA and CC ARE NOT PARALLEL TO X-Y AXES
    ' -----------------------------------------------------------------------------
    Friend Sub CalcVertexB_FromVertexA(ByVal ax As Double, _
                                       ByVal ay As Double, _
                                       ByVal CC As Double, _
                                       ByRef bx As Double, _
                                       ByRef by As Double)

        Dim BB2 As Double = ax ^ 2 + ay ^ 2
        Dim AA As Double = Sqrt(BB2 - CC ^ 2)

        bx = AA * (AA * ax - CC * ay) / BB2
        by = AA * (AA * ay + CC * ax) / BB2
    End Sub

End Module



Friend Class ReverseIterator
    Implements IEnumerable
    ' ------------------------------------------ a low-overhead ArrayList to store references
    Dim items As New ArrayList()

    Sub New(ByVal collection As IEnumerable)
        ' -------------------------------------- load all the items in the ArrayList, but in reverse order
        Dim o As Object
        For Each o In collection
            items.Insert(0, o)
        Next
    End Sub
    '
    Public Function GetEnumerator() As System.Collections.IEnumerator _
        Implements System.Collections.IEnumerable.GetEnumerator
        ' ------------------------------------- return the enumerator of the inner ArrayList
        Return items.GetEnumerator()
    End Function
End Class

