﻿Module Module_Vector3D

    ' ==================================================================================================
    '   Vector 3D
    ' ==================================================================================================
    Friend Structure Vec3
        Dim x As Double
        Dim y As Double
        Dim z As Double
        Function Dist(ByVal other As Vec3) As Double
            Dist = Math.Sqrt((other.x - x) ^ 2 + (other.y - y) ^ 2 + (other.z - z) ^ 2)
        End Function
        Function Add(ByVal other As Vec3) As Vec3
            Add.x = x + other.x
            Add.y = y + other.y
            Add.z = z + other.z
        End Function
        Function Subtract(ByVal other As Vec3) As Vec3
            Subtract.x = x - other.x
            Subtract.y = y - other.y
            Subtract.z = z - other.z
        End Function
        Function Mul(ByVal factor As Double) As Vec3
            Mul.x = x * factor
            Mul.y = y * factor
            Mul.z = z * factor
        End Function
        Function Length() As Double
            Return Math.Sqrt(x ^ 2 + y ^ 2 + z ^ 2)
        End Function
        Function LengthXY() As Double
            Return Math.Sqrt(x ^ 2 + y ^ 2)
        End Function
        Function OrthoZ() As Vec3
            OrthoZ.x = y
            OrthoZ.y = -x
            OrthoZ.z = z
        End Function
        Function Normalized() As Vec3
            Dim l As Double = Me.Length()
            If l > 0 Then
                Normalized = Me.Mul(1 / l)
            End If
        End Function
        Function IsValidVector() As Boolean
            If x <> 0 OrElse y <> 0 OrElse z <> 0 Then
                Return True
            Else
                Return False
            End If
        End Function
        ' --------------------------------------------------------------------------------
        ' DotProductNormalized return values are from 1 to -1
        ' --------------------------------------------------------------------------------
        ' return value = 1  : the two input vectors are pointing in the same direction 
        ' return value = 0  : the two input vectors are at right angles 
        ' return value = -1 : the two input vectors are pointing in opposite directions 
        ' --------------------------------------------------------------------------------
        Shared Function DotProductNormalized(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
            Return (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z) / (v1.Length * v2.Length)
        End Function
        Shared Function DotProduct(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
            Return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
        End Function
    End Structure

    Friend Function NewVec3(ByVal x As Double, ByVal y As Double, ByVal z As Double) As Vec3
        Dim v As Vec3
        v.x = x
        v.y = y
        v.z = z
        Return v
    End Function

    Friend Function NewVec3() As Vec3
        Dim v As Vec3
        ' no need to set each member to zero because the
        ' default value for all the numeric types is zero
        Return v
    End Function

End Module






'' ==================================================================================================
''   CLASS - Vector 3D - NOT WORKING
'' ==================================================================================================
'Friend Class Vec3
'    Friend x As Double
'    Friend y As Double
'    Friend z As Double
'    Sub New()
'        x = 0
'        y = 0
'        z = 0
'    End Sub
'    Function Dist(ByVal other As Vec3) As Double
'        Dist = Sqrt((other.x - x) ^ 2 + (other.y - y) ^ 2 + (other.z - z) ^ 2)
'    End Function
'    Function Add(ByVal other As Vec3) As Vec3
'        x += other.x
'        y += other.y
'        z += other.z
'        Return Me
'    End Function
'    Function Subtract(ByVal other As Vec3) As Vec3
'        x -= other.x
'        y -= other.y
'        z -= other.z
'        Return Me
'    End Function
'    Function Mul(ByVal factor As Double) As Vec3
'        x *= factor
'        y *= factor
'        z *= factor
'        Return Me
'    End Function
'    Function Length() As Double
'        Return Sqrt(x ^ 2 + y ^ 2 + z ^ 2)
'    End Function
'    Function LengthXY() As Double
'        Return Sqrt(x ^ 2 + y ^ 2)
'    End Function
'    Function OrthoZ() As Vec3
'        x = y
'        y = -x
'        z = z
'        Return Me
'    End Function
'    Function Normalized() As Vec3
'        Dim l As Double = Me.Length()
'        If l > 0 Then
'            Return Me.Mul(1 / l)
'        Else
'            Return Me
'        End If
'    End Function
'    Function IsValidVector() As Boolean
'        If x <> 0 OrElse y <> 0 OrElse z <> 0 Then
'            Return True
'        Else
'            Return False
'        End If
'    End Function
'    ' --------------------------------------------------------------------------------
'    ' DotProductNormalized return values are from 1 to -1
'    ' --------------------------------------------------------------------------------
'    ' return value = 1  : the two input vectors are pointing in the same direction 
'    ' return value = 0  : the two input vectors are at right angles 
'    ' return value = -1 : the two input vectors are pointing in opposite directions 
'    ' --------------------------------------------------------------------------------
'    Shared Function DotProductNormalized(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
'        Return (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z) / (v1.Length * v2.Length)
'    End Function
'    Shared Function DotProduct(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
'        Return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
'    End Function
'End Class
