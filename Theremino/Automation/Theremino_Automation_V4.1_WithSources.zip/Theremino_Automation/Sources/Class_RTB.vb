
Imports System.Collections.Generic

Public Class SyntaxRichTextBox
    Inherits System.Windows.Forms.RichTextBox

    Friend TextMustBeIndented As Boolean = False
    Friend TextModified As Boolean = False
    Friend TooLongToAutoindent As Boolean


    ' ===============================================================================================
    '  DISABLE MOUSE SELECTION WHEN NOT EDITING
    ' ===============================================================================================
    'Private Sub RTB_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseLeave
    '    If Not Running Then Enabled = True
    'End Sub
    'Private Sub RTB_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
    '    If Not Running Then Enabled = False
    'End Sub

    ' ===============================================================================================
    '  ENABLE DISABLE PAINT
    ' ===============================================================================================
    Friend PaintEventEnabled As Boolean = True
    <DebuggerStepThrough()> _
    Protected Overrides Sub WndProc(ByRef m As Message)
        Const WM_PAINT As Int32 = &HF
        If m.Msg = WM_PAINT AndAlso Not PaintEventEnabled Then
            m.Result = IntPtr.Zero
        Else
            MyBase.WndProc(m)
        End If
    End Sub



    ' ===============================================================================================================
    '   RTB - SAVE and RESTORE selection and scroll ( scroll aligned with the first text line )
    ' ===============================================================================================================
    Friend Structure ScrollData
        Dim OldSelectionStart As Int32
        Dim OldSelectionLength As Int32
        Dim OldSelectionFirstChar As Int32
        Dim OldSelectionLastChar As Int32
    End Structure

    Friend Sub SaveSelectionAndScroll(ByRef sd As ScrollData)
        sd.OldSelectionStart = Me.SelectionStart
        sd.OldSelectionLength = Me.SelectionLength
        sd.OldSelectionFirstChar = Me.GetCharIndexFromPosition(New Point(1, 1))
        sd.OldSelectionLastChar = Me.GetCharIndexFromPosition(New Point(1, Me.ClientSize.Height))
    End Sub
    Friend Sub RestoreSelectionAndScroll(ByRef sd As ScrollData)
        Me.Select(sd.OldSelectionFirstChar, 0)
        Me.ScrollToCaret()
        If sd.OldSelectionStart >= sd.OldSelectionFirstChar And _
           sd.OldSelectionStart <= sd.OldSelectionLastChar + 1 Then
            Me.Select(sd.OldSelectionStart, sd.OldSelectionLength)
        End If
    End Sub


    ' ===============================================================================================
    '  LINES COLORS
    ' ===============================================================================================
    Friend Sub ColorAllLines()
        PaintEventEnabled = False
        Enabled = False
        ' ---------------------------------------------------------- save position 
        Dim sd As ScrollData
        SaveSelectionAndScroll(sd)
        ' ---------------------------------------------------------- 
        For i As Integer = 0 To Lines.Length - 1
            SelectLine(i)
            SelectionColor = Color_Text
            SelectionBackColor = Color_ActiveBack
            ' ------------------------------------------------------ AutomationLanguageColors
            AutomationLanguageColors(i, False)
        Next
        ' ---------------------------------------------------------- restore
        RestoreSelectionAndScroll(sd)
        ' ---------------------------------------------------------- 
        Enabled = True
        PaintEventEnabled = True
        Me.Focus()
    End Sub

    Friend Sub ColorVisibleLines()
        ' ---------------------------------------------------------- color visible lines
        PaintEventEnabled = False
        Enabled = False
        ' ---------------------------------------------------------- save position
        Dim sd As ScrollData
        SaveSelectionAndScroll(sd)
        ' ---------------------------------------------------------- 
        For i As Integer = GetFirstVisibleLine() To GetLastVisibleLine()
            SelectLine(i)
            SelectionColor = Color_Text
            SelectionBackColor = Color_ActiveBack
            ' ------------------------------------------------------ AutomationLanguageColors
            AutomationLanguageColors(i, True)
        Next
        ' ---------------------------------------------------------- restore
        RestoreSelectionAndScroll(sd)
        ' ---------------------------------------------------------- 
        Enabled = True
        PaintEventEnabled = True
        Me.Focus()
    End Sub

    Friend Sub ColorAllOrVisibleLines()
        If Lines.Length < 500 Then
            ColorAllLines()
            Form1.chk_ColorLines.Visible = False
        Else
            ColorVisibleLines()
            Form1.chk_ColorLines.Visible = True
        End If
    End Sub

    Private Sub ColorLines(ByVal startline As Int32, ByVal endline As Int32)
        For i As Int32 = startline To endline
            ColorSingleLine(i)
        Next
    End Sub

    Private Sub ColorSingleLine(ByVal i As Int32)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        ' ---------------------------------------------------------- save position 
        Dim OldCursorPosition As Integer = SelectionStart
        ' ---------------------------------------------------------- set the whole line to default colors
        SelectLine(i)
        SelectionColor = Color_Text
        SelectionBackColor = Color_ActiveBack
        ' ---------------------------------------------------------- AutomationLanguageColors
        AutomationLanguageColors(i, False)
        ' ---------------------------------------------------------- restore
        SelectionStart = OldCursorPosition
        SelectionLength = 0
        ' ---------------------------------------------------------- 
        EventsAreEnabled = old
    End Sub

    Private Sub ColorSelectedLine()
        ColorSingleLine(GetLineFromCharIndex(SelectionStart))
    End Sub

    Private LastEditedLine As Int32 = -1
    Protected Overrides Sub OnTextChanged(ByVal e As EventArgs)
        If Not PaintEventEnabled Then Return
        Dim line As Int32 = GetLineFromCharIndex(SelectionStart)
        ' ------------------------------------------------------- stop Paint
        PaintEventEnabled = False
        ' ------------------------------------------------------- process the line
        ColorSingleLine(line)
        ' ------------------------------------------------------- restart Paint
        PaintEventEnabled = True
        ' ------------------------------------------------------- 
        TextModified = True
        TextMustBeIndented = True
        ' -------------------------------------------------------
        If line <> LastEditedLine Then
            Undo_AddEntry()
            LastEditedLine = line
        End If
    End Sub


    ' ===============================================================================================
    '  AUTOMATION LANGUAGE COLORS
    ' ===============================================================================================
    Private Color_Text As Color = Color.FromArgb(0, 0, 30)
    Private Color_ActiveBack As Color = Color.FromArgb(255, 255, 190)
    Private Color_CommentBack As Color = Color.FromArgb(240, 255, 240)
    Private Color_ErrorBack As Color = Color.FromArgb(255, 200, 180)
    Private Color_UnusedBack As Color = Color.FromArgb(60, 60, 80)

    Private Sub AutomationLanguageColors(ByVal i As Int32, ByVal fast As Boolean)
        If i < 0 Or i > Lines.Length - 1 Then Return
        ' --------------------------------------------------------------- 
        Dim line As String = Lines(i)
        ' --------------------------------------------------------------- comment position
        Dim CommentPosition As Int32 = RemoveComments(line)
        If CommentPosition = 0 Then
            MarkCommentLine(i, 0)
            Return
        End If
        ' --------------------------------------------------------------- 
        If line <> "" Then
            ' ----------------------------------------------------------- replace keywords
            'Dim sw As Stopwatch = New Stopwatch
            'sw.Start()
            If Not fast Then ReplaceKeywords(i, line)
            'Form1.Text = sw.Elapsed.TotalMilliseconds.ToString
            ' ----------------------------------------------------------- Tokenize to array of keywords
            Dim l() As String = Tokenize(line.Trim.ToLowerInvariant)
            ' ----------------------------------------------------------- 
            Select Case l.Length
                Case 0
                Case 1
                    Select Case l(0)
                        Case "beep", "case", "caseelse", "else", "endif", "endselect", "return", "select", "stop", "end"
                        Case Else : MarkErrorLine(i)
                    End Select
                Case 2
                    Select Case l(0)
                        Case "case"
                            If Not IsValidBooleanStringOrDouble(l(1)) Then MarkErrorLine(i)
                        Case "if", "wait"
                            If Not IsValidBoolean(l(1)) Then MarkErrorLine(i)
                        Case "label", "gosub", "goto"
                        Case "load"
                            If l(1) <> "slots" AndAlso _
                               l(1) <> "vars" AndAlso _
                               l(1) <> "stop" AndAlso _
                               l(1) <> "hide" Then
                                If l(1).ToLower.Trim.StartsWith("slots") Then
                                    Dim n() As Double = ExtractNumericParams(l(1), 3)
                                    If n.Length <> 2 Then MarkErrorLine(i)
                                Else
                                    ' try to load any string (if exists) 
                                End If
                            End If
                        Case "print"
                            If Not IsValidBooleanStringOrDouble(l(1)) Then
                                MarkErrorLine(i)
                            End If
                        Case "save"
                            If l(1) <> "slots" AndAlso _
                               l(1) <> "vars" Then
                                MarkErrorLine(i)
                            End If
                        Case "select"
                            If Not IsValidBooleanStringOrDouble(l(1)) Then MarkErrorLine(i)
                        Case "speed"
                            If Not IsValidDouble(l(1)) Then MarkErrorLine(i)
                        Case "window"
                            If l(1) <> "sizable" AndAlso _
                               l(1) <> "maximized" AndAlso _
                               l(1) <> "fullscreen" Then
                                MarkErrorLine(i)
                            End If
                        Case Else : MarkErrorLine(i)
                    End Select
                Case 3
                    Select Case l(0)
                        Case "button"
                            If Not IsNumeric(l(1)) Then MarkErrorLine(i)
                            Select Case l(2)
                                Case "enabled", "disabled"
                                Case Else : MarkErrorLine(i)
                            End Select
                        Case "wait"
                            Select Case l(1)
                                Case "button"
                                Case "seconds"
                                    If Not IsValidDouble(l(2)) Then MarkErrorLine(i)
                                Case Else : MarkErrorLine(i)
                            End Select
                        Case Else
                            If l(1) = "=" Then
                                If IsValidNumericVarName(l(0)) AndAlso IsValidDouble(l(2)) Then
                                ElseIf IsValidStringVarName(l(0)) Then ' AndAlso IsValidString(l(2)) Then
                                Else
                                    MarkErrorLine(i)
                                End If
                            Else
                                MarkErrorLine(i)
                            End If
                    End Select
                Case 4
                    Select Case l(0)
                        Case "button"
                            If Not IsNumeric(l(1)) Then MarkErrorLine(i)
                            Select Case l(2)
                                Case "text", "slot"
                                Case Else : MarkErrorLine(i)
                            End Select
                        Case "key"
                            If Not IsValidKey(l(1)) OrElse (l(2) <> "goto" AndAlso l(2) <> "gosub") Then
                                MarkErrorLine(i)
                            End If
                        Case "slot"
                            If IsValidDouble(l(1)) And l(2) = "=" And IsValidDouble(l(3)) Then
                            Else
                                Select Case l(3)
                                    Case "reset", "sleep"
                                    Case Else : MarkErrorLine(i)
                                End Select
                            End If
                        Case Else
                            Select Case l(2)
                                Case "input"
                                Case Else
                                    MarkErrorLine(i)
                            End Select
                    End Select
                Case Else
                    MarkErrorLine(i)
            End Select
        End If
        ' ----------------------------------------------------------- color the comment section
        If CommentPosition > -1 Then
            MarkCommentLine(i, CommentPosition)
        End If
    End Sub
    Private Sub MarkErrorLine(ByVal i As Int32)
        SelectLine(i)
        SelectionBackColor = Color_ErrorBack
    End Sub
    Private Sub MarkCommentLine(ByVal i As Int32, Optional ByVal FirstCommentedChar As Int32 = -1)
        SelectLine(i)
        If FirstCommentedChar > 0 Then
            SelectionLength -= FirstCommentedChar ' lenght must be changed before start
            SelectionStart += FirstCommentedChar  ' otherwise at the end of the file the lenght is shortened 
        End If
        SelectionBackColor = Color_CommentBack
    End Sub

    ' ===============================================================================================
    '  MIXED FUNCTIONS
    ' ===============================================================================================
    Friend Function IsValidKey(ByVal KeyString As String) As Boolean
        Select Case KeyString
            Case "left", "right", "up", "down", "pageup", "pagedown", "space", "esc", "home", "end"
                Return True
            Case Else
                If KeyString.Length = 1 Then
                    If "0123456789abcdefghijklmnopqrstuvwxyz".Contains(KeyString) Then Return True
                ElseIf KeyString.Length = 2 Then
                    If "f1f2f3f4f5f6f7f8f9".Contains(KeyString) Then Return True
                ElseIf KeyString.Length = 3 Then
                    If "f10f11f12".Contains(KeyString) Then Return True
                End If
        End Select
        Return False
    End Function
    Friend Function IsValidNumericVarName(ByVal VarName As String) As Boolean
        If VarName Is Nothing Then Return False
        If VarName.Length <> 2 Then Return False
        If Not VarName.StartsWith("v", StringComparison.InvariantCultureIgnoreCase) Then Return False
        If Not "123456789".Contains(VarName(1)) Then Return False
        Return True
    End Function
    Friend Function IsValidStringVarName(ByVal VarName As String) As Boolean
        If VarName Is Nothing Then Return False
        If VarName.Length <> 2 Then Return False
        If Not VarName.StartsWith("s", StringComparison.InvariantCultureIgnoreCase) Then Return False
        If Not "123456789".Contains(VarName(1)) Then Return False
        Return True
    End Function
    Friend Function VarNameToIndex(ByVal VarName As String) As Int32
        If VarName.Length <> 2 Then Return 0
        Return CInt(Val(VarName(1)))
    End Function
    Friend Function ExtractFirstWord(ByVal s As String) As String
        If s = Nothing Then Return ""
        s = s.Replace(vbTab, "").Trim
        Dim i As Int32 = s.IndexOf(" ")
        If i < 0 Then Return s
        Return s.Substring(0, i)
    End Function
    Friend Function RemoveComments(ByRef s As String) As Int32
        Dim i As Int32 = s.IndexOf("'")
        If i > 0 Then s = s.Remove(i).TrimEnd
        If i = 0 Then s = ""
        Return i
    End Function
    Friend Sub SelectLine(ByVal line As Int32)
        If line >= 0 AndAlso line < Lines.Length AndAlso Lines.Length > 0 Then
            Dim lineStart As Int32 = GetFirstCharIndexFromLine(line)
            Dim lineLength As Int32 = Lines(line).Length
            Me.Select(lineStart, lineLength)
        Else
            Me.Select(0, 0)
        End If
    End Sub
    Friend Sub SelectLines(ByVal FirstLine As Int32, ByVal LastLine As Int32)
        Dim FirstChar As Int32 = Me.GetFirstCharIndexFromLine(FirstLine)
        Dim LastChar As Int32 = Me.GetFirstCharIndexFromLine(LastLine) + Me.Lines(LastLine).Length '- 1
        Me.Select(FirstChar, LastChar - FirstChar)
    End Sub
    Friend Function GetFirstSelectedLine() As Int32
        Return Me.GetLineFromCharIndex(Me.SelectionStart)
    End Function
    Private Function GetLastSelectedLine() As Int32
        Return Me.GetLineFromCharIndex(Me.SelectionStart + Me.SelectionLength)
    End Function
    Friend Function GetFirstVisibleLine() As Int32
        Return Me.GetLineFromCharIndex(Me.GetCharIndexFromPosition(New Point(1, 1)))
    End Function
    Friend Function GetLastVisibleLine() As Int32
        Dim p As Point = New Point(1, Me.ClientSize.Height)
        Return Me.GetLineFromCharIndex(Me.GetCharIndexFromPosition(p))
    End Function
    Friend Sub ShowLinesCount()
        Dim nline As Int32 = GetLineFromCharIndex(SelectionStart)
        Dim nCol As Int32 = SelectionStart - GetFirstCharIndexFromLine(nline)
        Form1.Label_Lines.Text = "Lines: " + Me.Lines.Length.ToString + _
                                 "  Line: " + (nline + 1).ToString + _
                                 "  Col: " + nCol.ToString
    End Sub

    Friend Sub ScrollToCenterSelectedLine(ByVal line As Int32)
        Dim VisibleLinesCount As Int32 = GetLastVisibleLine() - GetFirstVisibleLine()
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        PaintEventEnabled = False
        Dim delta As Int32 = VisibleLinesCount \ 2 - 1
        ScrollToLine(line + delta)
        ScrollToLine(line - delta)
        PaintEventEnabled = True
        EventsAreEnabled = old
    End Sub

    Friend Sub ScrollToLine(ByVal nline As Int32)
        If nline < 0 Then nline = 0
        If nline > Lines.Length - 1 Then nline = Lines.Length - 1
        Me.Select(GetFirstCharIndexFromLine(nline), 1)
        Me.ScrollToCaret()
    End Sub


    Private Function TestEndif(ByVal lnum As Int32) As Boolean
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = lnum + 1 To Me.Lines.Length - 1
            line = Me.Lines(i).Trim.ToLower
            If line.StartsWith("endif") Then
                If counter <= 0 Then
                    Return True
                End If
                counter -= 1
            ElseIf line.StartsWith("if") Then
                counter += 1
            End If
        Next
        Return False
    End Function
    Private Function TestElseOrEndif(ByVal lnum As Int32) As Boolean
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = lnum + 1 To Me.Lines.Length - 1
            line = Me.Lines(i).Trim.ToLower
            If line.StartsWith("else") Then
                If counter <= 0 Then
                    Return True
                End If
            ElseIf line.StartsWith("endif") Then
                If counter <= 0 Then
                    Return True
                End If
                counter -= 1
            ElseIf line.StartsWith("if") Then
                counter += 1
            End If
        Next
        Return False
    End Function
    Private Function TestEndselect(ByVal lnum As Int32) As Boolean
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = lnum + 1 To Me.Lines.Length - 1
            line = Me.Lines(i).Trim.ToLower
            If line.StartsWith("endselect") Then
                If counter <= 0 Then
                    Return True
                End If
                counter -= 1
            ElseIf line.StartsWith("select") Then
                counter += 1
            End If
        Next
        Return False
    End Function

    ' ===============================================================================================
    '  TOKENIZER
    ' ===============================================================================================
    Enum TokenizerStatus As Int32
        Normal = 0
        InsideToken = 1
        InsideString = 2
    End Enum
    Friend Function Tokenize(ByVal line As String) As String()
        Dim status As TokenizerStatus
        Dim l(-1) As String
        For i As Int32 = 0 To line.Length - 1
            Select Case status
                Case TokenizerStatus.Normal
                    Select Case line(i)
                        Case " "c, Chr(9), "("c, ")"c
                        Case "'"c
                            Exit For ' comments are completely skipped 
                        Case """"c
                            status = TokenizerStatus.InsideString
                            ReDim Preserve l(l.Length)
                        Case Else
                            status = TokenizerStatus.InsideToken
                            ReDim Preserve l(l.Length)
                            l(l.Length - 1) += line(i)
                    End Select
                Case TokenizerStatus.InsideToken
                    Select Case line(i)
                        Case " "c, Chr(9), "("c, ")"c
                            ' ------------------------------------------ end of token - eval right side ?  
                            status = TokenizerStatus.Normal
                            Select Case l.Length
                                Case 1
                                    Select Case l(0).ToLower
                                        Case "load", "save", "print", "speed"
                                            ' -------------------------- isolate right side formula (trimmed) and exit
                                            ReDim Preserve l(1)
                                            l(1) = line.Substring(i + 1)
                                            RemoveComments(l(1))
                                            l(1) = l(1).Trim
                                            Exit For
                                        Case "label", "goto", "gosub"
                                            ' -------------------------- isolate right side formula (without "") and exit
                                            ReDim Preserve l(1)
                                            l(1) = line.Substring(i + 1).Replace("""", "")
                                            RemoveComments(l(1))
                                            Exit For
                                        Case "if", "select", "case"
                                            ' -------------------------- isolate right side formula and exit
                                            ReDim Preserve l(1)
                                            l(1) = line.Substring(i + 1)
                                            RemoveComments(l(1))
                                            Exit For
                                        Case "slot"
                                            ' -------------------------- isolate left side formula and continue
                                            Dim eq As Int32 = InStr(line, "=")
                                            If eq > i Then
                                                ReDim Preserve l(1)
                                                l(1) = line.Substring(i, eq - i - 2)
                                                i = eq - 2
                                            End If
                                    End Select
                                Case 2
                                    Select Case l(0).ToLower
                                        Case "wait"
                                            If l(1).ToLower <> "seconds" And l(1).ToLower <> "button" Then
                                                ' -------------------------- isolate right side formula and exit
                                                ReDim Preserve l(1)
                                                l(1) = line.Substring(5)
                                                RemoveComments(l(1))
                                                Exit For
                                            End If
                                        Case "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", _
                                             "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9"
                                            If l(1) = "=" Then
                                                If line.Substring(5).ToLower.StartsWith("input") Then
                                                    ' -------------------------- isolate input prompt
                                                    ReDim Preserve l(3)
                                                    l(2) = "input"
                                                    If line.Length > 10 Then
                                                        l(3) = line.Substring(11)
                                                    Else
                                                        l(3) = ""
                                                    End If
                                                    RemoveComments(l(3))
                                                Else
                                                    ' -------------------------- isolate right side formula
                                                    ReDim Preserve l(2)
                                                    l(2) = line.Substring(5)
                                                    RemoveComments(l(2))
                                                End If
                                                ' ----------------------------- and exit
                                                Exit For
                                            End If
                                    End Select
                                Case 3
                                    Select Case l(0).ToLower
                                        Case "slot"
                                            If l(2) = "=" Then
                                                ' ----------------------- isolate right side formula and exit
                                                ReDim Preserve l(3)
                                                l(3) = line.Substring(i + 1)
                                                RemoveComments(l(3))
                                                Exit For
                                            End If
                                        Case "wait"
                                            If l(1).ToLower = "seconds" Then
                                                ' -------------------------- isolate right side formula and exit
                                                ReDim Preserve l(2)
                                                l(2) = line.Substring(13)
                                                RemoveComments(l(2))
                                                Exit For
                                            End If
                                        Case "button"
                                            If l(2).ToLower = "text" Then
                                                ' ----------------------- isolate right side formula and exit
                                                ReDim Preserve l(3)
                                                l(3) = line.Substring(l(0).Length + l(1).Length + l(2).Length + 3)
                                                RemoveComments(l(3))
                                                Exit For
                                            End If
                                        Case "key"
                                            If l(2).ToLower = "goto" OrElse l(2).ToLower = "gosub" Then
                                                ' ----------------------- isolate right side formula and exit
                                                ReDim Preserve l(3)
                                                l(3) = line.Substring(l(0).Length + l(1).Length + l(2).Length + 3)
                                                RemoveComments(l(3))
                                                Exit For
                                            End If
                                    End Select
                            End Select
                        Case "'"c
                            Exit For ' comments are completely skipped 
                        Case Else
                            l(l.Length - 1) += line(i)
                    End Select
                Case TokenizerStatus.InsideString
                    Select Case line(i)
                        Case """"c
                            If i >= line.Length - 2 OrElse line(i + 1) <> """"c Then
                                status = TokenizerStatus.Normal
                            Else
                                l(l.Length - 1) += line(i)
                                i += 1
                            End If
                        Case Else
                            l(l.Length - 1) += line(i)
                    End Select
            End Select
        Next
        Return l
    End Function


    ' ===============================================================================================
    '  REPLACE KEYWORDS
    ' ===============================================================================================
    ' Short keywords are listed before
    Private Keywords() As String = {"PI", "Int", "And", "Or", "If", "Else", "EndIf", _
                                    "Sin", "Cos", "Asin", "Acos", "Tan", "Atan", "Atan2", "Pow", "Sqrt", _
                                    "Round", "Mid", "Len", "Abs", "Sign", "Rnd", _
                                    "Beep", "Disabled", "Enabled", "Input", "True", "False", _
                                    "Print", "Return", "Seconds", "Sleep", "Slot", _
                                    "Speed", "Stop", "End", "Text", "Hide", "Home", _
                                    "Left", "Right", "Up", "Down", "Pageup", "Pagedown", "Space", "Esc", _
                                    "Trim", "Format", "UCase", "LCase", "WCase", _
                                    "Date", "Now", "Today", "Reset", "Select", "Case", "CaseElse", _
                                    "EndSelect", "Sleep", "ElapsedTime"}

    Friend Sub ReplaceKeywords(ByVal lineNumber As Int32, ByRef line As String)
        Dim LineStart As Int32
        If lineNumber >= 0 Then LineStart = GetFirstCharIndexFromLine(lineNumber)
        ' --------------------------------------------------------------- SPECIAL LINES
        Dim line2 As String = line.Trim.ToLower
        If line2.StartsWith("button") Then
            ReplaceKeywords(New String() {"Button", "Slot", "Text", "Enabled", "Disabled"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("goto") Then
            ReplaceKeywords(New String() {"Goto"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("gosub") Then
            ReplaceKeywords(New String() {"Gosub"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("key") Then
            ReplaceKeywords(New String() {"Key", "Goto", "Gosub"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("label") Then
            ReplaceKeywords(New String() {"Label"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("load") Then
            ReplaceKeywords(New String() {"Load", "Stop", "Hide", "Slots", "Vars"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("save") Then
            ReplaceKeywords(New String() {"Save", "Slots", "Vars"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("wait") Then
            ReplaceKeywords(New String() {"Wait", "Seconds", "Button", "Condition"}, lineNumber, LineStart, line)
            Return
        End If
        If line2.StartsWith("window") Then
            ReplaceKeywords(New String() {"Window", "Sizable", "Maximized", "FullScreen"}, lineNumber, LineStart, line)
            Return
        End If
        ' --------------------------------------------------------------- REPLACE ALL KEYWORDS
        ReplaceKeywords(Keywords, lineNumber, LineStart, line)
    End Sub

    Private Sub ReplaceKeywords(ByVal Keywords As String(), ByVal lineNumber As Int32, ByVal lineStart As Int32, ByRef line As String)
        Dim position As Int32
        For Each kw As String In Keywords
            position = 0
            Do
                position = line.IndexOf(kw, position, StringComparison.InvariantCultureIgnoreCase)
                If position >= 0 Then
                    If Not InsideQuotes(position, line) Then
                        If lineNumber >= 0 Then
                            Me.Select(lineStart + position, kw.Length)
                            If kw <> Me.SelectedText Then
                                Me.SelectedText = kw
                            End If
                        Else
                            Mid(line, position + 1, kw.Length) = kw
                        End If
                    End If
                    position += kw.Length
                End If
            Loop Until position < 0
        Next
    End Sub

    Private Function InsideQuotes(ByVal index As Int32, ByVal text As String) As Boolean
        InsideQuotes = False
        If index >= text.Length Then Return False
        For Counter As Int32 = 0 To index - 1
            If text(Counter) = """"c Then
                InsideQuotes = Not InsideQuotes
            End If
        Next
    End Function


    ' ===============================================================================================
    '  AUTO INDENT
    ' ===============================================================================================
    Friend Sub AutoIndent()

        If TooLongToAutoindent Then Return

        If Lines.Length > 500 Then
            MessageBox.Show("Program too long, can not autoindent.", _
                            "Message from Theremino Automation", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Information)
            TooLongToAutoindent = True
            Return
        End If

        If Not PaintEventEnabled Then Exit Sub ' <-- important
        PaintEventEnabled = False ' <-- important
        'Visible = False
        'Enabled = False
        ' ---------------------------------------------------------- save position
        Dim sd As ScrollData
        SaveSelectionAndScroll(sd)
        Dim SelectionModified As Boolean = False
        ' ---------------------------------------------------------- 
        Dim indent As Int32 = 0
        For i As Integer = 0 To Lines.Length - 1

            Dim l() As String = Me.Lines(i).Replace(vbTab, " ").Trim.ToLower.Split(" "c)

            If l(0).StartsWith("'") Then Continue For

            ' ----------------------------------------------------------- 
            Select Case l(0)
                Case "endif", "case", "caseelse", "else" : indent -= 1
                Case "endselect" : indent -= 2
                Case "label" : If LineIsEmptyOrCommentOrTerminator(i - 1) Then indent = 0
                Case "goto", "return", "stop", "end" : If LineIsEmptyOrCommentOrInitiator(i + 1) Then indent -= 1
            End Select

            Dim ntabs As Int32 = indent
            If ntabs < 0 Then ntabs = 0

            Dim lineText As String = Me.Lines(i)
            Dim InitialTabs As Int32 = CountInitialTabs(lineText, 4)
            If ntabs <> InitialTabs Then
                Dim start As Int32 = Me.GetFirstCharIndexFromLine(i)
                Me.Select(start, CountInitialChars(lineText))
                Me.SelectedText = StrDup(ntabs, vbTab)
                SelectionModified = True
            End If

            Select Case l(0)
                Case "if", "label", "case", "caseelse", "else" : indent += 1
                Case "select" : indent += 2
            End Select

            If indent < 0 Then indent = 0
        Next
        ' ---------------------------------------------------------- restore
        If SelectionModified Then
            RestoreSelectionAndScroll(sd)
            TextModified = True
        End If
        ' ---------------------------------------------------------- 
        PaintEventEnabled = True ' <-- important
        'Enabled = True
        'Visible = True
        'Me.Focus()
        TextMustBeIndented = False
    End Sub

    Private Function LineIsEmptyOrCommentOrInitiator(ByVal index As Int32) As Boolean
        If index < 0 Then Return True
        If index >= Lines.Length Then Return True
        Dim l As String = Me.Lines(index).Trim.ToLower
        If l = "" OrElse l.StartsWith("'") _
            OrElse l.StartsWith("label") Then Return True
        Return False
    End Function

    Private Function LineIsEmptyOrCommentOrTerminator(ByVal index As Int32) As Boolean
        If index < 0 Then Return True
        If index >= Lines.Length Then Return True
        Dim l As String = Me.Lines(index).Trim.ToLower
        If l = "" OrElse l.StartsWith("'") _
            OrElse l.StartsWith("goto") _
            OrElse l.StartsWith("return") _
            OrElse l.StartsWith("stop") _
            OrElse l.StartsWith("end") Then Return True
        Return False
    End Function

    ' ===============================================================================================
    '  SUGGESTIONS AND AUTOINDENT
    ' ===============================================================================================
    Private OldCursorLine As Int32 = -1

    Private Sub RTB_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SelectionChanged
        If Not EventsAreEnabled Then Exit Sub
        If Form1.Running Then Return
        ' ----------------------------------------------------------------- SUGGESTIONS
        ShowSuggestions()
        ' ----------------------------------------------------------------- AUTO INDENT
        Dim line As Int32 = GetLineFromCharIndex(SelectionStart)
        If line <> OldCursorLine Then
            OldCursorLine = line
            If TextMustBeIndented Then
                Dim old As Boolean = EventsAreEnabled
                EventsAreEnabled = False
                AutoIndent()
                EventsAreEnabled = old
            End If
        End If
    End Sub

    ' ===============================================================================================
    '  SUGGESTIONS
    ' ===============================================================================================
    Private AllKeywords As String = "Beep  Button  GoSub  GoTo  If  Else  EndIf  Key  Label  Load  Print  Return  Save  Select  Case  CaseElse  EndSelect  Slot  Speed  Stop  End  Wait  Window"
    Private LoadKeywords As String = "Slots Vars Stop Hide or FILENAME(.txt, .jpg, .bmp, .png, .gif, .avi, .wmv, .mpg, .mp4, .mov, .mp3, .wav) or HTTP or s1..s9"
    Friend Sub ShowSuggestions()
        Dim nline As Int32 = GetLineFromCharIndex(SelectionStart)
        ShowLinesCount()
        If Lines.Length = 0 Then
            Form1.StatusLabel1.BackColor = Color.FromArgb(220, 255, 200)
            Form1.StatusLabel1.Text = "Keywords:  " & AllKeywords
            Return
        End If
        ' ----------------------------------------------------------- 
        ShowSuggestions(Lines(nline), nline, GetCompleteWord(Me.Text, Me.SelectionStart))
    End Sub

    Friend Sub ShowSuggestions(ByVal line As String, ByVal nline As Int32, ByVal SelectedWord As String)
        LastError = ""
        line = line.Replace(vbTab, " ").Trim.ToLower
        RemoveComments(line)
        ' ----------------------------------------------------------- Tokenize to array of keywords 
        Dim l() As String = Tokenize(line)
        Dim s As String = ""
        Select Case l.Length
            Case 0
                s = AllKeywords
            Case 1
                Select Case l(0)
                    Case "beep" : s = "OK: A system Beep will be emitted here (repetition is limited to 10 per second)"
                    Case "button" : s = "BUTTON-NUMBER"
                    Case "gosub" : s = "LABEL-NAME  (enclosing the text in double quotes is possible, but not necessary)"
                    Case "goto" : s = "LABEL-NAME  (enclosing the text in double quotes is possible, but not necessary)"
                    Case "if" : s = "EXPRESSION"
                    Case "else"
                        If TestEndif(nline) Then
                            s = "OK: Following instructions are executed when the preceding IF is FALSE"
                        Else
                            s = "WARNING: This line has no effect without a corresponding EndIf"
                        End If
                    Case "endif" : s = "OK: This is the end of the conditional execution."
                    Case "endselect" : s = "OK: This is the end of the Select/Case conditional execution."
                    Case "key" : s = "0..9 / a..z / F1..F12 / Left / Right / Up / Down / Pageup / Pagedown / Space / Esc / Home / End"
                    Case "label" : s = "LABEL-NAME (use "" to include spaces in the text)"
                    Case "load" : s = LoadKeywords
                    Case "print" : s = "OK: ""TEXT TO PRINT"" (also complex expressions - use "" to include spaces in the text)"
                    Case "return" : s = "OK: The program will return to the line after ""GoSub"" or ""Button"" events"
                    Case "save" : s = "Slots / Vars"
                    Case "select" : s = "EXPRESSION"
                    Case "case" : s = "Please write ""CaseElse"" or an EXPRESSION"
                    Case "caseelse" : s = "OK: Following instructions are executed if no precedent ""Case"" has matched the ""Select"" value"
                    Case "slot" : s = "EXPRESSION"
                    Case "speed" : s = "1 to 9 - Normal values are: 5(slow execution) 7(fast execution) 9(only for short loops)"
                    Case "stop" : s = "OK: The program will stop here (execution paused)"
                    Case "end" : s = "OK: The program will stop here (execution terminated)"
                    Case "wait" : s = "Seconds / Button / Condition"
                    Case "window" : s = "Sizable / Maximized / FullScreen"
                    Case Else
                        If IsValidNumericVarName(l(0)) OrElse IsValidStringVarName(l(0)) Then
                            s = "="
                        Else
                            s = AllKeywords
                        End If
                End Select
            Case 2
                Select Case l(0)
                    Case "button"
                        If IsNumeric(l(1)) Then
                            s = "Slot / Text / Enabled / Disabled"
                        Else
                            s = "ERROR: Invalid button number"
                        End If
                    Case "gosub"
                        s = "OK: The program will call the subprogram starting with the label """ + l(1) + """ (if exists)"
                    Case "goto"
                        s = "OK: The program will jump to the label """ + l(1) + """ (if exists)"
                    Case "if"
                        If IsValidBoolean(l(1)) Then
                            If TestElseOrEndif(nline) Then
                                s = "OK: the expression """ + l(1) + """ will be evalued"
                            Else
                                s = "WARNING: This line has no effect without a corresponding Else or EndIf"
                            End If
                        Else
                            s = "ERROR: " + LastError
                        End If
                    Case "key"
                        If IsValidKey(l(1)) Then
                            s = "Goto / Gosub"
                        Else
                            s = "Please use a valid Key: 0..9 / a..z / F1..F12 / Left / Right / Up / Down / Pageup / Pagedown / Space / Esc / Home / End"
                        End If
                    Case "label"
                        s = "OK: This label will be called by ""GoSub"", ""GoTo"" and by ""Buttons"" with text """ + l(1) + """"
                    Case "load"
                        If l(1) = "slots" Then
                            s = "OK: All the slots (0 to 999) will be loaded from the ""_Slots.txt"" file."
                        ElseIf l(1) = "vars" Then
                            s = "OK: All the vars will be loaded from the ""_Vars.txt"" file."
                        ElseIf l(1) = "stop" Then
                            s = "OK: Sounds and video will be stopped here"
                        ElseIf l(1) = "hide" Then
                            s = "OK: The running program will be visualized until a new image or video will be loaded"
                        ElseIf l(1).StartsWith("slot") Then
                            Dim n() As Double = ExtractNumericParams(l(1), 3)
                            If n.Length > 0 Then
                                If n.Length = 2 Then
                                    s = "OK: Slots in the range will be loaded."
                                Else
                                    s = "ERROR: Please write two numbers from 0 to 999, or two expressions without spaces." + vbCrLf + _
                                        "               The first and second values are the first and last Slots to be loaded."
                                End If
                            Else
                                s = "ERROR: Too many parameters."
                            End If
                        Else
                            Dim str As String = EvalString(l(1))
                            Select Case Strings.Right(str, 4).ToLower
                                Case ".txt" : s = "OK: The program will be loaded from ""Programs"" folder"
                                Case ".jpg", ".bmp", ".png", ".gif" : s = "OK: The image will be loaded from ""Media"" folder"
                                Case ".avi", ".wmv", ".mpg", ".mp4", ".mov" : s = "OK: The video will be loaded from ""Media"" folder"
                                Case ".mp3", ".wav" : s = "OK: The audio file will be played (with the video player)"
                                Case ".exe" : s = "OK: The application will be started (if exists near to file 'Automation.exe' or in the 'Full-Path' specified)"
                                Case Else
                                    Select Case l(1)
                                        Case "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9" : s = "OK: The image, video or program, will be loaded from ""Media"" or ""Programs"" folder"
                                        Case Else
                                            If str.StartsWith("http") Then
                                                s = "OK: The site will be opened (if exists)"
                                            Else
                                                s = "OK: Will try to load the """ + str + """ (if exists)"
                                            End If
                                    End Select
                            End Select
                        End If
                    Case "print"
                        If IsValidBooleanStringOrDouble(l(1)) Then
                            s = "OK: The expression """ + l(1) + """ will be evalued and printed"
                        Else
                            s = "ERROR: " + LastError
                        End If
                    Case "save"
                        If l(1) = "slots" Then
                            s = "OK: All the slots (0 to 999) will be saved to the ""_Slots.txt"" file."
                        ElseIf l(1) = "vars" Then
                            s = "OK: All the vars will be saved to the ""_Vars.txt"" file."
                        Else
                            s = "Slots Vars"
                        End If
                    Case "select"
                        If TestEndselect(nline) Then
                            If IsValidBooleanStringOrDouble(l(1)) Then
                                s = "OK: The expression """ + l(1) + """ will be compared with ""Case"" expressions"
                            Else
                                s = "Please write a valid expression"
                            End If
                        Else
                            s = "WARNING: This line has no effect without a corresponding EndSelect"
                        End If
                    Case "case"
                        If IsValidBooleanStringOrDouble(l(1)) Then
                            s = "OK: Following instructions are executed when the ""Case"" value equals the ""Select"" value"
                        Else
                            s = "Please write a valid expression"
                        End If
                    Case "slot"
                        If IsValidDouble(l(1)) Then
                            s = "Please write ""="""
                        Else
                            s = "Please write a valid numerical expression"
                        End If
                    Case "speed"
                        If IsValidDouble(l(1)) Then
                            s = "OK: The speed will be set to """ + l(1) + """"
                        Else
                            s = "Please write 1 to 9 or a valid numeric expression"
                        End If
                    Case "wait"
                        Select Case l(1)
                            Case "seconds" : s = "SECONDS (also with decimals)"
                            Case "button" : s = "BUTTON-NAME"
                            Case Else
                                If IsValidBoolean(l(1)) Then
                                    s = "OK: This line waits until the expression """ + l(1) + """ will be TRUE"
                                Else
                                    s = "Seconds / Button / Condition"
                                End If
                        End Select
                    Case "window"
                        If l(1) = "sizable" OrElse _
                           l(1) = "maximized" OrElse _
                           l(1) = "fullscreen" Then
                            s = "OK: The window will be set to " + l(1)
                        Else
                            s = "Sizable / Maximized / FullScreen"
                        End If
                    Case Else
                        If l(1) = "=" Then
                            If IsValidNumericVarName(l(0)) Then
                                s = "Please write a valid numerical expression, or the keyword: Input"
                            ElseIf IsValidStringVarName(l(0)) Then
                                s = "Please write a valid string (with "" initial and final), or the keyword: Input"
                            Else
                                s = "ERROR: " + LastError
                            End If
                        Else
                            s = "ERROR: Incomplete or wrong instruction. " + LastError
                        End If
                End Select
            Case 3
                Select Case l(0)
                    Case "button"
                        If IsNumeric(l(1)) Then
                            Select Case l(2)
                                Case "enabled", "disabled"
                                    s = "OK: Button will be " + l(2)
                                Case "slot" : s = "SLOT-NUMBER"
                                Case "text" : s = "BUTTON-TEXT  (enclosing the text in double quotes is possible, but not necessary)"
                                Case Else : s = "Slot / Text / Enabled / Disabled"
                            End Select
                        Else
                            s = "ERROR: Invalid button number"
                        End If
                    Case "key"
                        If IsValidKey(l(1)) Then
                            If l(2) = "goto" OrElse l(2) = "gosub" Then
                                s = "Please write a Label name   (enclosing the text in double quotes is possible, but not necessary)"
                            Else
                                s = "Goto / Gosub"
                            End If
                        Else
                            s = "ERROR: The key is not valid"
                        End If
                    Case "slot"
                        If IsValidDouble(l(1)) Then
                            If l(2) = "=" Then
                                s = "Please write RESET, SLEEP or a valid numerical expression"
                            Else
                                s = "Please write a ""="""
                            End If
                        Else
                            s = "ERROR: The slot number is not valid"
                        End If
                    Case "wait"
                        Select Case l(1)
                            Case "seconds"
                                If IsValidDouble(l(2)) Then
                                    s = "OK: The program will be paused for """ + l(2) + """ seconds"
                                Else
                                    s = "ERROR: " + LastError
                                End If
                            Case "button"
                                s = "OK: The program will wait the button """ + l(2) + """ (for buttons with long names the first word is used)"
                            Case Else
                                s = "OK: The expression """ + l(2) + """ will be evaluated."
                        End Select
                    Case Else
                        If l(1) = "=" Then
                            If IsValidNumericVarName(l(0)) Then
                                If IsValidDouble(l(2)) Then
                                    s = "OK: Numeric variable """ + l(0) + """ = " + l(2)
                                ElseIf l(2) = "input" Then
                                    s = "OK: Numeric variable """ + l(0) + """ will be manually entered."
                                ElseIf l(2).StartsWith("i") Then
                                    s = "Input"
                                Else
                                    s = "ERROR: " + LastError
                                End If
                            ElseIf IsValidStringVarName(l(0)) Then
                                If IsValidString(l(2)) Then
                                    s = "OK: String variable """ + l(0) + """ = " + l(2)
                                ElseIf l(2) = "input" Then
                                    s = "OK: String variable """ + l(0) + """ will be manually entered."
                                ElseIf l(2).StartsWith("i") Then
                                    s = "Input"
                                Else
                                    s = "ERROR: Invalid string. " + LastError
                                End If
                            End If
                        Else
                            s = "ERROR: " + LastError
                        End If
                End Select
            Case 4
                Select Case l(0)
                    Case "button"
                        If Not IsNumeric(l(1)) Then
                            s = "ERROR"
                        Else
                            Select Case l(2)
                                Case "slot"
                                    s = "OK: Button """ + l(1) + """ will be pressed by slot """ + l(3) + """ (when value exceeds 500)"
                                Case "text"
                                    s = "OK: Button """ + l(1) + """ text is """ + l(3) + """" + vbCrLf + "        (the first word """ + ExtractFirstWord(l(3)) + """ will be used for ""Gosub Labels"" and ""Wait Button"")"
                                Case Else : s = "ERROR"
                            End Select
                        End If
                    Case "key"
                        If IsValidKey(l(1)) Then
                            If l(2) = "goto" Then
                                s = "OK: Pressing the key """ + l(1) + """ the Label """ + l(3) + """ will be called by a GoTo"
                            ElseIf l(2) = "gosub" Then
                                s = "OK: Pressing the key """ + l(1) + """ the Label """ + l(3) + """ will be called by a GoSub (remember to use a Return)"
                            Else
                                s = "Goto / Gosub"
                            End If
                        Else
                            s = "ERROR: The key is not valid"
                        End If
                    Case "load"
                        If IsValidDouble(l(2)) And IsValidDouble(l(3)) Then
                            s = "OK: This statement will load Slots from " + l(2).Trim + " to " + l(3).Trim
                        Else
                            s = "ERROR: Please write two simple numeric values from 0 to 999, or variables V1 to V9 " + vbCrLf + _
                                "                (the first value is first Slot and the second value is the last Slot to load)"
                        End If
                    Case "slot"
                        If IsValidDouble(l(1)) And l(2) = "=" And IsValidDouble(l(3)) Then
                            s = "OK: Slot """ + l(1).Trim + """ = expression: """ + l(3).Trim + """"
                        Else
                            Select Case l(3)
                                Case "reset", "sleep"
                                    s = "OK: Slot """ + l(1).Trim + """ will be set with the special value: NAN+" + l(3)
                                Case Else
                                    s = "ERROR: Please write RESET , SLEEP or a valid numeric expression"
                            End Select
                        End If
                End Select
                Select Case l(2)
                    Case "input"
                        s = "OK: The variable """ + l(0) + """ will be manually entered." + vbCrLf + _
                            "         (after the keyword ""Input"" you could also write a prompt for the user)"
                End Select
            Case Else
                s = "ERROR"
        End Select
        ' -----------------------------------------------------------
        With Form1.StatusLabel1
            If s.StartsWith("OK") Then
                .BackColor = Color.FromArgb(250, 255, 200)
                .Text = s
            ElseIf s.StartsWith("ERROR") Then
                .BackColor = Color.FromArgb(255, 160, 150)
                .Text = s
            ElseIf s.StartsWith("WARNING") Then
                .BackColor = Color.FromArgb(255, 200, 100)
                .Text = s
            ElseIf s = "" Then
                .BackColor = Color.AliceBlue
                .Text = ""
            Else
                If l.Length > 0 Then
                    ' ------------------------------------------------------ Keyword auto selection
                    Dim s2 As String = ExtractKeywords(s, SelectedWord)
                    If s2 <> "" Then
                        s = s2
                    Else
                        .BackColor = Color.FromArgb(255, 160, 150)
                        .Text = "Error:  Incomplete or wrong instruction"
                        Return
                    End If
                End If
                ' ---------------------------------------------------------- Keyword suggestion
                .BackColor = Color.FromArgb(220, 255, 200)
                .Text = "Keywords:  " & s
            End If
        End With
    End Sub

    ' ===============================================================================================
    '  AUTOMATIC COMPLETION
    ' ===============================================================================================
    Private Function ExtractKeywords(ByVal s1 As String, ByVal s2 As String) As String
        If s2 = "" Then Return s1
        ExtractKeywords = s1
        Dim MatchesCount As Int32 = 0
        Dim s() As String = Split(s1.Replace(" / ", " "), " ")
        s1 = ""
        For Each word As String In s
            If word.StartsWith(s2, StringComparison.InvariantCultureIgnoreCase) Then
                If s1 <> "" Then s1 += " / "
                s1 += word
            End If
        Next
        Return s1
    End Function


    Private Sub CompleteKeyword(ByVal keyword As String)
        ' --------------------------------------------------------------- save
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        PaintEventEnabled = False
        Dim OldCursorPosition As Integer = SelectionStart
        ' --------------------------------------------------------------- change
        Dim start, length As Int32
        FindWordPointers(Me.Text, Me.SelectionStart, start, length)
        SelectionStart = start
        SelectionLength = length
        SelectedText = keyword & " "
        ' --------------------------------------------------------------- restore
        SelectionLength = 0
        EventsAreEnabled = old
        PaintEventEnabled = True
        ' --------------------------------------------------------------- update suggestions
        SelectionStart = SelectionStart - 1
        SelectionStart = SelectionStart + 1
    End Sub

    Friend Sub CompleteKeyword()
        Dim sa() As String
        sa = Form1.StatusLabel1.Text.Split(" "c)
        If sa.Length > 1 Then
            CompleteKeyword(sa(sa.Length - 1).Trim)
            ColorSelectedLine()
        End If
    End Sub

    ' ===============================================================================================
    '  CUT COPY and PASTE
    ' ===============================================================================================
    Friend Sub ExecCut()
        If Me.SelectionLength > 0 Then
            SendTextToClipboard()
            If UndoTextReady Then Undo_AddEntry()
            Me.SelectedText = ""
            'Undo_AddEntry()
        End If
    End Sub
    Friend Sub ExecCopy()
        If Me.SelectionLength > 0 Then
            SendTextToClipboard()
        End If
    End Sub
    Private Sub SendTextToClipboard()
        Dim data As IDataObject
        data = New DataObject(DataFormats.Text, Me.SelectedText.Replace(vbLf, vbCrLf))
        Clipboard.SetDataObject(data, True)
    End Sub
    Friend Sub ExecPaste()
        If Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) Then
            If UndoTextReady Then Undo_AddEntry()
            Me.Enabled = False
            PaintEventEnabled = False
            ' ------------------------------------------------------------ extract only the text from clipbbard
            Dim startline As Int32 = GetLineFromCharIndex(SelectionStart)
            Me.SelectedText = Clipboard.GetText
            Dim endline As Int32 = GetLineFromCharIndex(SelectionStart + SelectionLength)
            ' ------------------------------------------------------------ color lines
            ColorLines(startline, endline)
            ' ------------------------------------------------------------
            PaintEventEnabled = True
            Me.Enabled = True
            Me.Focus()
            Undo_AddEntry()
        End If
    End Sub
    Friend Sub ExecDelete()
        If Me.SelectionLength > 0 Then
            If UndoTextReady Then Undo_AddEntry()
            Me.SelectedText = ""
            'Undo_AddEntry()
        End If
    End Sub
    'Friend Function Editor_CanPaste() As Boolean
    '    Return Clipboard.GetDataObject().GetDataPresent(DataFormats.Text)
    'End Function

    ' ===============================================================================================
    '  BREAKPOINTS and WATCHES
    ' ===============================================================================================
    Friend Sub ToggleBreakPoint(ByVal mousepos As Point)
        Dim charindex As Int32 = Me.GetCharIndexFromPosition(mousepos)
        Dim i As Int32 = GetLineFromCharIndex(charindex)
        Dim lineText As String = Me.Lines(i).Trim
        If lineText.EndsWith("'Breakpoint") Then
            DeleteBreakpointFromLine(i)
        Else
            Dim endpos As Int32 = Me.GetFirstCharIndexFromLine(i) + Me.Lines(i).Length
            Me.Select(endpos, 0)
            If endpos > 0 AndAlso endpos < Me.Text.Length AndAlso Me.Text(endpos - 1) = vbTab Then
                Me.SelectedText = "'Breakpoint"
            Else
                Me.SelectedText = vbTab + "'Breakpoint"
            End If
        End If
    End Sub

    Friend Sub DeleteAllBreakPoints()
        Dim i As Int32 = Me.Lines.Length - 1
        While i >= 0
            Dim lineText As String = Me.Lines(i).Trim
            If lineText.EndsWith("'Breakpoint") Then
                DeleteBreakpointFromLine(i)
            Else
                i = i - 1
            End If
        End While
    End Sub

    Private Sub DeleteBreakpointFromLine(ByVal i As Int32)
        Dim endpos As Int32 = Me.GetFirstCharIndexFromLine(i) + Me.Lines(i).Length
        Dim startpos As Int32 = Me.GetFirstCharIndexFromLine(i) + Me.Lines(i).IndexOf("'Breakpoint")
        Me.Select(startpos, endpos - startpos)
        Me.SelectedText = ""
    End Sub

    Friend Sub LoadFileTrimmed(ByVal fname As String)
        Dim s As String() = IO.File.ReadAllLines(fname, System.Text.Encoding.ASCII)
        For i As Int32 = 0 To s.Length - 1
            s(i) = s(i).Trim
        Next
        Me.Lines = s
        Me.Text += vbCrLf
    End Sub

    Friend Sub ExtractWatches()
        Dim startline As Int32 = 0
        ' ------------------------------------------- a maximum of 100 watches to increase the loading speed
        If Me.Lines.Length > 101 Then
            startline = Me.Lines.Length - 100
        End If
        ' -------------------------------------------
        Form_Debug.DeleteAllWatches()
        Form_Debug.txt_Exec.Text = ""
        Dim i As Int32 = startline
        While i < Me.Lines.Length - 1
            Dim lineText As String = Me.Lines(i)
            If lineText.StartsWith("'WATCH") Then
                Form_Debug.AddWatchLine(Mid(lineText, 7).Trim)
                DeleteLine(i)
                i -= 1
            End If
            If lineText.StartsWith("'EXEC") Then
                Form_Debug.txt_Exec.Text = Mid(lineText, 6).Trim
                DeleteLine(i)
                i -= 1
            End If
            i += 1
        End While
        Form_Debug.ResizeListViewColumns()
    End Sub

    Friend Sub DeleteFinalEmptyLines()
        For i As Int32 = Me.Lines.Length - 1 To 0 Step -1
            If Me.Lines(i).Trim = "" Then
                DeleteLine(i)
            Else
                Return
            End If
        Next
    End Sub

    Friend Sub DeleteLine(ByVal line As Int32)
        Dim startpos As Int32 = GetFirstCharIndexFromLine(line)
        Dim count As Int32 = Lines(line).Length + 1
        If startpos + count > Me.Text.Length Then Return
        Me.Text = Me.Text.Remove(startpos, count)
    End Sub

    ' ===============================================================================================
    '  INDENT-UNINDENT
    ' ===============================================================================================
    Friend Sub IndentSelectedLines(ByVal increment As Int32)
        If UndoTextReady Then Undo_AddEntry()
        Me.Enabled = False
        PaintEventEnabled = False
        ' ----------------------------------------------------------------
        Dim FirstSelectedLine As Int32 = GetFirstSelectedLine()
        Dim LastSelectedLine As Int32 = GetLastSelectedLine()
        ' ----------------------------------------------------------------
        For i As Int32 = FirstSelectedLine To LastSelectedLine
            Dim lineText As String = Me.Lines(i)
            Dim ntabs As Int32 = CountInitialTabs(lineText, 4) + increment
            If ntabs >= 0 Then
                Dim start As Int32 = Me.GetFirstCharIndexFromLine(i)
                Me.Select(start, CountInitialChars(lineText))
                Me.SelectedText = StrDup(ntabs, vbTab)
            End If
        Next
        ' ----------------------------------------------------------------
        SelectLines(FirstSelectedLine, LastSelectedLine)
        ' ----------------------------------------------------------------
        Me.Enabled = True
        PaintEventEnabled = True
        Me.Focus()
        Undo_AddEntry()
    End Sub

    ' ===============================================================================================
    '  COMMENT UN-COMMENT
    ' ===============================================================================================
    Friend Sub CommentSelectedLines(ByVal comment As Boolean)
        If UndoTextReady Then Undo_AddEntry()
        Me.Enabled = False
        PaintEventEnabled = False
        ' ----------------------------------------------------------------
        Dim CommentColumn As Int32 = -1
        ' ----------------------------------------------------------------
        Dim FirstSelectedLine As Int32 = GetFirstSelectedLine()
        Dim LastSelectedLine As Int32 = GetLastSelectedLine()
        ' ----------------------------------------------------------------
        For i As Int32 = FirstSelectedLine To LastSelectedLine
            Dim lineText As String = Me.Lines(i)
            Dim firstch As Int32 = CountInitialChars(lineText)
            If firstch >= 0 Then
                If CommentColumn < 0 Then CommentColumn = firstch
                Dim start As Int32 = Me.GetFirstCharIndexFromLine(i)

                If comment Then
                    Me.Select(start + CommentColumn, 0)
                    Me.SelectedText = "'"
                Else
                    Me.Select(start + firstch, 1)
                    If Me.SelectedText = "'" Then
                        Me.SelectedText = ""
                    End If
                End If
            End If
        Next
        ' ----------------------------------------------------------------
        ColorLines(FirstSelectedLine, LastSelectedLine)
        ' ----------------------------------------------------------------
        Me.Enabled = True
        PaintEventEnabled = True
        Me.Focus()
        Undo_AddEntry()
    End Sub

    Private Function CountInitialChars(ByVal s As String) As Int32
        Dim CharCount As Int32 = 0
        For i As Int32 = 0 To s.Length - 1
            Select Case s.Substring(i, 1)
                Case vbTab : CharCount += 1
                Case " " : CharCount += 1
                Case Else : Exit For
            End Select
        Next
        Return CharCount
    End Function

    'Private Function CountInitialTabs(ByVal s As String, ByVal TabSize As Int32) As Int32
    '    Dim SpaceCount As Int32 = 0
    '    Dim TabCount As Int32 = 0
    '    For i As Int32 = 0 To s.Length - 1
    '        Select Case s.Substring(i, 1)
    '            Case vbTab : TabCount += 1
    '            Case " " : SpaceCount += 1
    '            Case Else : Exit For
    '        End Select
    '    Next
    '    Return TabCount + SpaceCount \ TabSize
    'End Function

    Private Function CountInitialTabs(ByVal s As String, ByVal TabSize As Int32) As Int32
        Dim TabCount As Int32 = 0
        For i As Int32 = 0 To s.Length - 1
            Select Case s.Substring(i, 1)
                Case vbTab : TabCount += 1
                Case " " : Return 999 ' Spaces are not allowed
                Case Else : Exit For
            End Select
        Next
        Return TabCount
    End Function


    ' ===============================================================================================
    '  UNDO - Undo entries are saved only after important text changes
    ' ===============================================================================================
    Private LastKeyPressed As Keys
    Private UndoTextReady As Boolean = False
    Private Sub SyntaxRichTextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case Keys.Enter, Keys.Cancel, Keys.Delete
                If UndoTextReady Then Undo_AddEntry()
            Case Keys.Tab
                If SelectedText.Length > 0 Then
                    IndentSelectedLines(If(e.Shift, -1, 1))
                    e.Handled = True
                    e.SuppressKeyPress = True
                End If
        End Select
        LastKeyPressed = e.KeyCode
    End Sub
    Private Sub SyntaxRichTextBox_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyCode
            Case Keys.Enter, Keys.Cancel, Keys.Delete
                'Undo_AddEntry()
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.PageUp, Keys.PageDown, Keys.Home, Keys.End
            Case Else
                UndoTextReady = True
        End Select
    End Sub
    Private Sub SyntaxRichTextBox_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LostFocus
        If UndoTextReady Then
            Undo_AddEntry()
        End If
    End Sub

    ' ------------------------------------------------------------------- private undo functions
    Private Structure UndoEntry
        Dim ActionName As String
        Dim RTF_Text As String
        Dim FirstVisibleChar As Int32
        Dim SelectionStart As Int32
        'Dim SelectionLength As Int32
    End Structure
    Private UndoBuffer As List(Of UndoEntry) = New List(Of UndoEntry)
    Private Undo_Index As Int32
    Friend Sub Undo_Clear()
        UndoBuffer.Clear()
        Undo_Index = 0
        Undo_AddEntry()
        TextModified = False
    End Sub
    Friend Sub Undo_AddEntry()
        If Not PaintEventEnabled Then Exit Sub
        ' ----------------------------------------------------------------
        Dim newentry As UndoEntry
        newentry.FirstVisibleChar = Me.GetCharIndexFromPosition(New Point(1, 1))
        newentry.SelectionStart = Me.SelectionStart
        'newentry.SelectionLength = Me.SelectionLength
        newentry.ActionName = ""
        newentry.RTF_Text = Me.Rtf
        ' ----------------------------------------------------------------
        While UndoBuffer.Count > Undo_Index
            UndoBuffer.RemoveAt(UndoBuffer.Count - 1)
        End While
        ' ----------------------------------------------------------------
        UndoBuffer.Add(newentry)
        Undo_Index += 1
        'Debug.Print(UndoBuffer.Count.ToString)
        ' ----------------------------------------------------------------
        UndoTextReady = False
        TextModified = True
        TextMustBeIndented = True
    End Sub

    ' ===============================================================================================
    '  UNDO and REDO commands
    ' ===============================================================================================
    Friend Sub ExecUndo()
        ' ---------------------------------------------------------------- 
        Me.Enabled = False
        PaintEventEnabled = False
        ' ---------------------------------------------------------------- undo the RTF text
        Undo_Index -= 1
        If Undo_Index < 1 Then Undo_Index = 1
        Dim undo As UndoEntry
        undo = UndoBuffer(Undo_Index - 1)
        Me.Rtf = undo.RTF_Text
        ' ---------------------------------------------------------------- update scroll and selection
        Me.Select(undo.FirstVisibleChar, 0)
        Me.ScrollToCaret()
        Me.Select(undo.SelectionStart, 0) 'undo.SelectionLength)
        ' ----------------------------------------------------------------
        Form1.ApplyEditorProps(True)
        Me.Enabled = True
        PaintEventEnabled = True
        ' ----------------------------------------------------------------  mark as not-modified
        If Undo_Index < 2 Then TextModified = False
    End Sub
    Friend Sub ExecRedo()
        ' ---------------------------------------------------------------- 
        Me.Enabled = False
        PaintEventEnabled = False
        ' ---------------------------------------------------------------- undo the RTF text
        If Undo_Index > UndoBuffer.Count - 1 Then Undo_Index = UndoBuffer.Count - 1
        Dim undo As UndoEntry = UndoBuffer(Undo_Index)
        Me.Rtf = undo.RTF_Text
        Undo_Index += 1
        ' ---------------------------------------------------------------- update scroll and selection
        Me.Select(undo.FirstVisibleChar, 0)
        Me.ScrollToCaret()
        Me.Select(undo.SelectionStart, 0)
        ' ---------------------------------------------------------------- 
        Form1.ApplyEditorProps(True)
        Me.Enabled = True
        PaintEventEnabled = True
        ' ---------------------------------------------------------------- mark as modified
        TextModified = True
        TextMustBeIndented = True
    End Sub
    Friend Function Editor_CanUndo() As Boolean
        Return Undo_Index >= 2
    End Function
    Friend Function Editor_CanRedo() As Boolean
        Return Undo_Index <= UndoBuffer.Count - 1
    End Function

End Class
