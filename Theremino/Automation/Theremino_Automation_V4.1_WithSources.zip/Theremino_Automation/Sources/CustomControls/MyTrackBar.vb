
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Text
Imports System.Windows.Forms
Imports System.IO
Imports System.Configuration
Imports System.Drawing.Imaging


<ToolboxBitmap(GetType(TrackBar))> _
<DefaultEvent("ValueChanged"), DefaultProperty("BarInnerColor")> _
Partial Public Class MyTrackBar
    Inherits Control
    ' ========================================================================
    '  Events
    ' ========================================================================
    <Description("Event fires when the Value property changes")> _
    <Category("Action")> _
    Public Event ValueChanged As EventHandler

    'public event ScrollEventHandler Scroll;
    <Description("Event fires when the Slider position is changed")> _
    <Category("Behavior")> _
    Public Event Scroll As System.EventHandler

    ' ========================================================================
    '  Properties
    ' ========================================================================
    Private _thumbRect As Rectangle     'bounding rectangle of thumb area
    Private _barRect As Rectangle       'bounding rectangle of bar area
    Private rect_HalfBar As Rectangle
    Private _thumbHalfRect As Rectangle

    ' ========================================================================
    '  Properties
    ' ========================================================================
    Private _thumbSize As Integer = 14
    <Description("Set slider-thumb size")> _
    <Category("Slider")> _
    <DefaultValue(14)> _
    Public Property ThumbSize() As Integer
        Get
            Return _thumbSize
        End Get
        Set(ByVal value As Integer)
            If value > 0 And value < (If(_barOrientation = Orientation.Horizontal, ClientRectangle.Width, ClientRectangle.Height)) Then
                _thumbSize = value
            Else
                Throw New ArgumentOutOfRangeException("TrackSize has to be greather than zero and lower than half of Slider width")
            End If
            Invalidate()
        End Set
    End Property

    Private _thumbRoundRectSize As New Size(12, 12)
    <Description("Set slider-thumb round rect size")> _
    <Category("Slider")> _
    <DefaultValue(GetType(Size), "12; 12")> _
    Public Property ThumbRoundRectSize() As Size
        Get
            Return _thumbRoundRectSize
        End Get
        Set(ByVal value As Size)
            Dim h As Integer = value.Height, w As Integer = value.Width
            If h <= 0 Then
                h = 1
            End If
            If w <= 0 Then
                w = 1
            End If
            _thumbRoundRectSize = New Size(w, h)
            Invalidate()
        End Set
    End Property

    Private _borderRoundRectSize As New Size(8, 8)
    <Description("Set external border round rect size")> _
    <Category("Slider")> _
    <DefaultValue(GetType(Size), "8; 8")> _
    Public Property BorderRoundRectSize() As Size
        Get
            Return _borderRoundRectSize
        End Get
        Set(ByVal value As Size)
            Dim h As Integer = Value.Height, w As Integer = Value.Width
            If h <= 0 Then
                h = 1
            End If
            If w <= 0 Then
                w = 1
            End If
            _borderRoundRectSize = New Size(w, h)
            Invalidate()
        End Set
    End Property

    Private _barOrientation As Orientation = Orientation.Horizontal
    <Description("Set orientation")> _
    <Category("Slider")> _
    <DefaultValue(Orientation.Horizontal)> _
    Public Property Orientation() As Orientation
        Get
            Return _barOrientation
        End Get
        Set(ByVal value As Orientation)
            _barOrientation = Value
            Dim temp As Integer = Width
            Width = Height
            Height = temp
            Invalidate()
        End Set
    End Property

    Private _tickCount As Integer = 10
    <Description("Set the number of Ticks")> _
    <Category("")> _
    <DefaultValue(10)> _
    Public Property TickCount() As Integer
        Get
            Return _tickCount
        End Get
        Set(ByVal value As Integer)
            _tickCount = Value
            Invalidate()
        End Set
    End Property

    Private _tickStyle As System.Windows.Forms.TickStyle = System.Windows.Forms.TickStyle.TopLeft
    <Description("Set Tick Style")> _
    <Category("")> _
    <DefaultValue(System.Windows.Forms.TickStyle.TopLeft)> _
    Public Property TickStyle() As System.Windows.Forms.TickStyle
        Get
            Return _tickStyle
        End Get
        Set(ByVal value As System.Windows.Forms.TickStyle)
            _tickStyle = Value
            Invalidate()
        End Set
    End Property

    Private _logaritmicity As Single = 1
    <Description("Logaritmicity (1 = linear)")> _
    <Category("")> _
    <DefaultValue(1)> _
    Public Property Logaritmicity() As Single
        Get
            Return _logaritmicity
        End Get
        Set(ByVal value As Single)
            If Value < 1 Then
                Value = 1
            End If
            _logaritmicity = Value
            RaiseEvent ValueChanged(Me, New EventArgs())
            Invalidate()
        End Set
    End Property

    Private _smartResolutionFigures As Integer = 0
    <Description("0 = disabled / 1 to 9 = number of significant figures")> _
    <Category("")> _
    <DefaultValue(0)> _
    Public Property SmartResolutionFigures() As Integer
        Get
            Return _smartResolutionFigures
        End Get
        Set(ByVal value As Integer)
            If Value < 0 Then
                Value = 0
            End If
            If Value > 9 Then
                Value = 9
            End If
            _smartResolutionFigures = Value
            RaiseEvent ValueChanged(Me, New EventArgs())
            Invalidate()
        End Set
    End Property

    Private _value As Integer = 0
    <Description("Set the slider value")> _
    <Category("")> _
    <DefaultValue(50)> _
    Public Property Value() As Integer
        Get
            Dim v As Double = _value
            If _logaritmicity > 1 Then
                v = (v - _barMinimum) / CDbl(_barMaximum - _barMinimum)
				If v < 0 Then v = 0
                v = Math.Pow(v, _logaritmicity)
                v = v * (_barMaximum - _barMinimum) + _barMinimum
                v = CInt(Math.Truncate(v + 0.5))
            End If
            If _smartResolutionFigures > 0 Then
                v = SmartResolution(v, _smartResolutionFigures)
            End If
            Return CInt(Math.Truncate(v))
        End Get
        Set(ByVal value As Integer)
            Dim v As Double = Value
            If _logaritmicity > 1 Then
                v = v + 0.5
                v = (v - _barMinimum) / CDbl(_barMaximum - _barMinimum)
				If v < 0 Then v = 0
                v = Math.Pow(v, 1 / _logaritmicity)
                v = v * (_barMaximum - _barMinimum) + _barMinimum
                v = CInt(Math.Truncate(v + 0.5))
            End If
            If v < _barMinimum Then
                v = _barMinimum
            End If
            If v > _barMaximum Then
                v = _barMaximum
            End If
            _value = CInt(Math.Truncate(v))
            RaiseEvent ValueChanged(Me, New EventArgs())
            Invalidate()
        End Set
    End Property

    Private _barMinimum As Integer = 0
    <Description("Set the minimal value")> _
    <Category("")> _
    <DefaultValue(0)> _
    Public Property Minimum() As Integer
        Get
            Return _barMinimum
        End Get
        Set(ByVal value As Integer)
            ' Calling the property "Value" the value is limited to MinMax 
            ' and is corrected for logarithmic bars
            ' and the event "ValueChanged" is called
            ' and the function "Invalidate()" is called
            Dim oldValue As Integer = Value
            _barMinimum = Value
            Value = oldValue
        End Set
    End Property

    Private _barMaximum As Integer = 100
    <Description("Set the maximal value")> _
    <Category("")> _
    <DefaultValue(100)> _
    Public Property Maximum() As Integer
        Get
            Return _barMaximum
        End Get
        Set(ByVal value As Integer)
            ' Calling the property "Value" the value is limited to MinMax 
            ' and is corrected for logarithmic bars
            ' and the event "ValueChanged" is called
            ' and the function "Invalidate()" is called
            Dim oldValue As Integer = Value
            _barMaximum = Value
            Value = oldValue
        End Set
    End Property

    Private _defaultValue As Integer = 50
    <Description("Set the default value (for mouse right button)")> _
    <Category("")> _
    <DefaultValue(50)> _
    Public Property DefaultValue() As Integer
        Get
            Return _defaultValue
        End Get
        Set(ByVal value As Integer)
            _defaultValue = Value
        End Set
    End Property

    Private _smallChange As UInteger = 1
    <Description("Set trackbar small change")> _
    <Category("")> _
    <DefaultValue(1)> _
    Public Property SmallChange() As UInteger
        Get
            Return _smallChange
        End Get
        Set(ByVal value As UInteger)
            _smallChange = Value
        End Set
    End Property

    Private _largeChange As UInteger = 5
    <Description("Set trackbar large change")> _
    <Category("")> _
    <DefaultValue(5)> _
    Public Property LargeChange() As UInteger
        Get
            Return _largeChange
        End Get
        Set(ByVal value As UInteger)
            _largeChange = Value
        End Set
    End Property

    Private _mouseEffects As Boolean = True
    <Description("Set whether mouse entry and exit actions have impact on how control look")> _
    <Category("Behavior")> _
    <DefaultValue(True)> _
    Public Property MouseEffects() As Boolean
        Get
            Return _mouseEffects
        End Get
        Set(ByVal value As Boolean)
            _mouseEffects = Value
            Invalidate()
        End Set
    End Property

    Private _mouseWheelSpeed As Integer = 1
    <Description("Set to 1 for slowest speed. Set to 0 to disable mouse wheel.")> _
    <Category("")> _
    <DefaultValue(1)> _
    Public Property MouseWheelSpeed() As Integer
        Get
            Return _mouseWheelSpeed
        End Get
        Set(ByVal value As Integer)
            _mouseWheelSpeed = Value
        End Set
    End Property

    Private _showTextAlways As Boolean = False
    <Description("True to show the text also when mouse not hovering")> _
    <Category("Behavior")> _
    <DefaultValue(False)> _
    Public Property ShowTextAlways() As Boolean
        Get
            Return _showTextAlways
        End Get
        Set(ByVal value As Boolean)
            _showTextAlways = Value
            Invalidate()
        End Set
    End Property

    Private _textColor As Color = Color.FromArgb(60, 60, 60)
    Private _brushTextColor As Brush = New SolidBrush(Color.FromArgb(60, 60, 60))
    <Description("Set the text color - Transparent to hide it")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "Silver")> _
    Public Property TextColor() As Color
        Get
            Return _textColor
        End Get
        Set(ByVal value As Color)
            _textColor = Value
            _brushTextColor = New SolidBrush(_textColor)
            Invalidate()
        End Set
    End Property

    Private __roundRectBorderColor As Color = Color.DarkGray
    Private __roundRectBorderPen As New Pen(Color.FromArgb(200, Color.DarkGray))
    <Description("Set the color of the border - Transparent to hide it")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "DarkGray")> _
    Public Property ColorRectangleBorder() As Color
        Get
            Return __roundRectBorderColor
        End Get
        Set(ByVal value As Color)
            __roundRectBorderColor = value
            __roundRectBorderPen = New Pen(__roundRectBorderColor)
            __roundRectBorderPen.DashStyle = DashStyle.Dot
            Invalidate()
        End Set
    End Property

    Private _thumbOuterColor As Color = Color.Gray
    <Description("Set Slider thumb outer color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "Gray")> _
    Public Property ThumbOuterColor() As Color
        Get
            Return _thumbOuterColor
        End Get
        Set(ByVal value As Color)
            _thumbOuterColor = value
            Invalidate()
        End Set
    End Property

    Private _thumbInnerColor As Color = Color.WhiteSmoke
    <Description("Set Slider thumb inner color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "WhiteSmoke")> _
    Public Property ThumbInnerColor() As Color
        Get
            Return _thumbInnerColor
        End Get
        Set(ByVal value As Color)
            _thumbInnerColor = Value
            Invalidate()
        End Set
    End Property

    Private _thumbPenColor As Color = Color.DimGray
    <Description("Set Slider thumb pen color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "DimGray")> _
    Public Property ThumbPenColor() As Color
        Get
            Return _thumbPenColor
        End Get
        Set(ByVal value As Color)
            _thumbPenColor = value
            Invalidate()
        End Set
    End Property

    Private _barOuterColor As Color = Color.DarkGray
    <Description("Set Slider bar outer color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "DarkGray")> _
    Public Property BarOuterColor() As Color
        Get
            Return _barOuterColor
        End Get
        Set(ByVal value As Color)
            _barOuterColor = value
            Invalidate()
        End Set
    End Property

    Private _barInnerColor As Color = Color.WhiteSmoke
    <Description("Set Slider bar inner color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "WhiteSmoke")> _
    Public Property BarInnerColor() As Color
        Get
            Return _barInnerColor
        End Get
        Set(ByVal value As Color)
            _barInnerColor = Value
            Invalidate()
        End Set
    End Property

    Private _barPenColor As Color = Color.Transparent
    <Description("Set Slider bar pen color")> _
    <Category("Colors")> _
    <DefaultValue(GetType(Color), "Transparent")> _
    Public Property BarPenColor() As Color
        Get
            Return _barPenColor
        End Get
        Set(ByVal value As Color)
            _barPenColor = Value
            Invalidate()
        End Set
    End Property


    ' ========================================================================
    ' Constructors
    ' ========================================================================
    Public Sub New(ByVal min As Integer, ByVal max As Integer, ByVal value__1 As Integer)
        'InitializeComponent();
        SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.OptimizedDoubleBuffer Or ControlStyles.ResizeRedraw Or ControlStyles.Selectable Or ControlStyles.SupportsTransparentBackColor Or ControlStyles.UserMouse Or ControlStyles.UserPaint, True)
        BackColor = Color.Transparent

        Minimum = min
        Maximum = max
        Value = value__1
    End Sub

    ' Initializes a new instance of the <see cref="MyTrackBar"/> class.
    Public Sub New()
        Me.New(0, 100, 50)
    End Sub


    ' ========================================================================
    '  Overrided events
    ' ========================================================================
    Private _mouseInRegion As Boolean = False
    Protected Overrides Sub OnEnabledChanged(ByVal e As EventArgs)
        MyBase.OnEnabledChanged(e)
        Invalidate()
    End Sub

    Protected Overrides Sub OnMouseEnter(ByVal e As EventArgs)
        MyBase.OnMouseEnter(e)
        _mouseInRegion = True
        Invalidate()
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As EventArgs)
        MyBase.OnMouseLeave(e)
        _mouseInRegion = False
        _mouseInThumbRegion = False
        Invalidate()
    End Sub

    Private deltaX As Single
    Private deltaY As Single
    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        MyBase.OnMouseDown(e)
        If e.Button = MouseButtons.Left Then
            deltaX = e.Location.X - (_thumbRect.Left + _thumbRect.Right) \ 2 - 1
            deltaY = e.Location.Y - (_thumbRect.Bottom + _thumbRect.Top) \ 2 - 1
            Capture = True
            RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.ThumbTrack, Value))
            RaiseEvent ValueChanged(Me, New EventArgs())
            OnMouseMove(e)
        End If
        If e.Button = MouseButtons.Right Then
            Value = _defaultValue
        End If
    End Sub

    Private _mouseInThumbRegion As Boolean = False
    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        MyBase.OnMouseMove(e)
        _mouseInThumbRegion = IsPointInRect(e.Location, _thumbRect)
        If Capture And e.Button = MouseButtons.Left Then
            Dim [set] As ScrollEventType = ScrollEventType.ThumbPosition
            Dim margin As Integer = _thumbSize >> 1
            If _barOrientation = Orientation.Horizontal Then
                Dim p As Integer = e.Location.X - margin - CInt(Math.Truncate(deltaX))
                deltaX *= 0.8F
                Dim coef As Single = CSng(_barMaximum - _barMinimum) / CSng(ClientSize.Width - 2 * margin)
                _value = CInt(Math.Truncate(p * coef + _barMinimum + 0.5))
            Else
                Dim p As Integer = ClientSize.Height - (e.Location.Y + margin - CInt(Math.Truncate(deltaY)))
                deltaY *= 0.8F
                Dim coef As Single = CSng(_barMaximum - _barMinimum) / CSng(ClientSize.Height - 2 * margin)
                _value = CInt(Math.Truncate(p * coef + _barMinimum + 0.5))
            End If

            If _value <= _barMinimum Then
                _value = _barMinimum
                [set] = ScrollEventType.First
            ElseIf _value >= _barMaximum Then
                _value = _barMaximum
                [set] = ScrollEventType.Last
            End If

            RaiseEvent Scroll(Me, New ScrollEventArgs([set], Value))
            RaiseEvent ValueChanged(Me, New EventArgs())
        End If
        Invalidate()
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
        MyBase.OnMouseUp(e)
        Capture = False
        _mouseInThumbRegion = IsPointInRect(e.Location, _thumbRect)
        RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.EndScroll, Value))
        RaiseEvent ValueChanged(Me, New EventArgs())
        Invalidate()
    End Sub

    Protected Overrides Sub OnMouseWheel(ByVal e As MouseEventArgs)
        MyBase.OnMouseWheel(e)
        If _mouseWheelSpeed = 0 Then
            Return
        End If
        ' -------------- this method works also with micrometric mouses like Microsoft Mouse
        Dim v As Double
        v = _mouseWheelSpeed * e.Delta / 120.0F
        If v > 0 And v < 1 Then v = 1
        If v < 0 And v > -1 Then v = -1
        OffsetValueBy(CInt(v))
        Me.Focus()
    End Sub

    Protected Overrides Sub OnGotFocus(ByVal e As EventArgs)
        MyBase.OnGotFocus(e)
        Invalidate()
    End Sub

    Protected Overrides Sub OnLostFocus(ByVal e As EventArgs)
        MyBase.OnLostFocus(e)
        Invalidate()
    End Sub

    Protected Overrides Sub OnKeyDown(ByVal e As KeyEventArgs)
        MyBase.OnKeyDown(e)
        Select Case e.KeyCode
            Case Keys.Down, Keys.Left
                OffsetValueBy(-CInt(_smallChange))
                RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.SmallDecrement, Value))
                Exit Select
            Case Keys.Up, Keys.Right
                OffsetValueBy(CInt(_smallChange))
                RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.SmallIncrement, Value))
                Exit Select
            Case Keys.Home
                Value = _barMinimum
                Exit Select
            Case Keys.[End]
                Value = _barMaximum
                Exit Select
            Case Keys.PageDown
                OffsetValueBy(-CInt(_largeChange))
                RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.LargeDecrement, Value))
                Exit Select
            Case Keys.PageUp
                OffsetValueBy(+CInt(_largeChange))
                RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.LargeIncrement, Value))
                Exit Select
        End Select
        If Value = _barMinimum Then
            RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.First, Value))
        End If
        If Value = _barMaximum Then
            RaiseEvent Scroll(Me, New ScrollEventArgs(ScrollEventType.Last, Value))
        End If
        Dim pt As Point = PointToClient(Cursor.Position)
        OnMouseMove(New MouseEventArgs(MouseButtons.None, 0, pt.X, pt.Y, 0))
    End Sub


    Protected Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        If keyData = Keys.Tab Or ModifierKeys = Keys.Shift Then
            Return MyBase.ProcessDialogKey(keyData)
        Else
            OnKeyDown(New KeyEventArgs(keyData))
            Return True
        End If
    End Function

    ' ========================================================================
    '  Help functions
    ' ========================================================================
    Public Shared Function CreateRoundRectPath(ByVal rect As Rectangle, ByVal size As Size) As GraphicsPath
        Dim gp As New GraphicsPath()
        gp.AddLine(rect.Left + size.Width \ 2, rect.Top, rect.Right - size.Width \ 2, rect.Top)
        gp.AddArc(rect.Right - size.Width, rect.Top, size.Width, size.Height, 270, 90)

        gp.AddLine(rect.Right, rect.Top + size.Height \ 2, rect.Right, rect.Bottom - size.Width \ 2)
        gp.AddArc(rect.Right - size.Width, rect.Bottom - size.Height, size.Width, size.Height, 0, 90)

        gp.AddLine(rect.Right - size.Width \ 2, rect.Bottom, rect.Left + size.Width \ 2, rect.Bottom)
        gp.AddArc(rect.Left, rect.Bottom - size.Height, size.Width, size.Height, 90, 90)

        gp.AddLine(rect.Left, rect.Bottom - size.Height \ 2, rect.Left, rect.Top + size.Height \ 2)
        gp.AddArc(rect.Left, rect.Top, size.Width, size.Height, 180, 90)
        Return gp
    End Function

    Public Shared Function TransparentColors(ByVal alpha As Integer, ByVal ParamArray colors As Color()) As Color()
        Dim colorsToReturn As Color() = New Color(colors.Length - 1) {}
        For i As Integer = 0 To colors.Length - 1
            colorsToReturn(i) = Color.FromArgb(alpha, colors(i).R, colors(i).G, colors(i).B)
        Next
        Return colorsToReturn
    End Function

    Public Shared Function DesaturateColors(ByVal ParamArray colors As Color()) As Color()
        Dim colorsToReturn As Color() = New Color(colors.Length - 1) {}
        For i As Integer = 0 To colors.Length - 1
            Dim gray As Integer = CInt(Math.Truncate(colors(i).R * 0.3 + colors(i).G * 0.6 + colors(i).B * 0.1))
            colorsToReturn(i) = Color.FromArgb(-&H10101 * (255 - gray) - 1)
        Next
        Return colorsToReturn
    End Function

    Public Shared Function LightenColors(ByVal ParamArray colors As Color()) As Color()
        Dim colorsToReturn As Color() = New Color(colors.Length - 1) {}
        For i As Integer = 0 To colors.Length - 1
            colorsToReturn(i) = ControlPaint.Light(colors(i), 0.1F)
        Next
        Return colorsToReturn
    End Function

    Public Shared Function DarkenColors(ByVal ParamArray colors As Color()) As Color()
        Dim colorsToReturn As Color() = New Color(colors.Length - 1) {}
        For i As Integer = 0 To colors.Length - 1
            colorsToReturn(i) = ControlPaint.Dark(colors(i), 0)
        Next
        Return colorsToReturn
    End Function

    Private Sub OffsetValueBy(ByVal offset As Integer)
        Dim v As Integer = _value + offset
        If v < _barMinimum Then
            v = _barMinimum
        End If
        If v > _barMaximum Then
            v = _barMaximum
        End If
        _value = v
        RaiseEvent ValueChanged(Me, New EventArgs())
        Invalidate()
    End Sub

    Private Shared Function IsPointInRect(ByVal pt As Point, ByVal rect As Rectangle) As Boolean
        If pt.X > rect.Left And pt.X < rect.Right And pt.Y > rect.Top And pt.Y < rect.Bottom Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function SmartResolution(ByVal n As Double, ByVal precision As Integer) As Integer
        Dim order As Integer = CInt(Math.Truncate(Math.Log10(n))) - precision + 1
        If order < 1 Then
            Return CInt(Math.Truncate(n))
        End If
        order = CInt(Math.Truncate(Math.Pow(10, order)))
        Return order * CInt(Math.Truncate(n / order))
    End Function


    ' ========================================================================
    '  Paint
    ' ========================================================================
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Enabled Then
            If _mouseEffects AndAlso _mouseInRegion Then
                Dim lightenedColors As Color() = LightenColors(_thumbOuterColor, _thumbInnerColor, _thumbPenColor, _barOuterColor, _barInnerColor, _barPenColor)
                DrawSlider(e, lightenedColors(0), lightenedColors(1), lightenedColors(2), lightenedColors(3), lightenedColors(4), _
                 lightenedColors(5))
            Else
                DrawSlider(e, _thumbOuterColor, _thumbInnerColor, _thumbPenColor, _barOuterColor, _barInnerColor, _
                 _barPenColor)
            End If
        Else
            Dim disabledColors As Color() = TransparentColors(100, _thumbOuterColor, _thumbInnerColor, _thumbPenColor, _barOuterColor, _barInnerColor, _
             _barPenColor)

            DrawSlider(e, disabledColors(0), disabledColors(1), disabledColors(2), disabledColors(3), disabledColors(4), _
             disabledColors(5))
        End If
    End Sub


    Private Sub DrawSlider(ByVal e As PaintEventArgs, ByVal thumbOuterColorPaint As Color, ByVal thumbInnerColorPaint As Color, ByVal thumbPenColorPaint As Color, ByVal barOuterColorPaint As Color, ByVal barInnerColorPaint As Color, _
     ByVal barPenColorPaint As Color)
        If _barMaximum = _barMinimum Then
            Return
        End If
        ' ---------------------------------------------------------------- set up thumbRect aproprietly
        Dim thumbPosition As Integer = 1
        If _tickStyle = TickStyle.TopLeft Then
            thumbPosition = 2
        End If
        If _tickStyle = TickStyle.BottomRight Then
            thumbPosition = 0
        End If
        If _barOrientation = Orientation.Horizontal Then
            Dim TrackX As Integer = (_value - _barMinimum) * (ClientRectangle.Width - _thumbSize) \ (_barMaximum - _barMinimum)
            _thumbRect = New Rectangle(TrackX, thumbPosition, _thumbSize - 1, ClientRectangle.Height - 3)
        Else
            Dim TrackY As Integer = ClientRectangle.Height - _thumbSize - (_value - _barMinimum) * (ClientRectangle.Height - _thumbSize) \ (_barMaximum - _barMinimum)
            _thumbRect = New Rectangle(thumbPosition, TrackY, ClientRectangle.Width - 3, _thumbSize - 1)
        End If

        ' ----------------------------------------------------------------- adjust drawing rects
        _barRect = ClientRectangle
        _thumbHalfRect = _thumbRect
        Dim gradientOrientation As LinearGradientMode
        If _barOrientation = Orientation.Horizontal Then
            _barRect.Inflate(-6, CInt(Math.Truncate(-_barRect.Height / 2.5)))
            If _tickStyle = TickStyle.TopLeft Then
                _barRect.Offset(0, 1)
            End If
            If _tickStyle = TickStyle.BottomRight Then
                _barRect.Offset(0, -1)
            End If
            rect_HalfBar = _barRect
            rect_HalfBar.Height \= 2
            gradientOrientation = LinearGradientMode.Vertical
            _thumbHalfRect.Height \= 2
        Else
            _barRect.Inflate(CInt(Math.Truncate(-_barRect.Width / 2.5)), -6)
            If _tickStyle = TickStyle.TopLeft Then
                _barRect.Offset(1, 0)
            End If
            If _tickStyle = TickStyle.BottomRight Then
                _barRect.Offset(-1, 0)
            End If
            rect_HalfBar = _barRect
            rect_HalfBar.Width \= 2
            gradientOrientation = LinearGradientMode.Horizontal
            _thumbHalfRect.Width \= 2
        End If
        ' ----------------------------------------------------------------------- get thumb shape path 
        Dim thumbPath As GraphicsPath
        thumbPath = CreateRoundRectPath(_thumbRect, _thumbRoundRectSize)

        ' ----------------------------------------------------------------------- draw bar
        Using lgbBar As New LinearGradientBrush(rect_HalfBar, barOuterColorPaint, barInnerColorPaint, gradientOrientation)
            ' ----------------------------------------------------------- draw bar
            lgbBar.WrapMode = WrapMode.TileFlipXY
            e.Graphics.FillRectangle(lgbBar, _barRect)

            ' ----------------------------------------------------------- draw bar hilight                  
            Using barPen As New Pen(barPenColorPaint, 0.5F)
                e.Graphics.DrawRectangle(barPen, _barRect)
            End Using

            ' ----------------------------------------------------------- draw ticks
            If _tickStyle <> TickStyle.None Then
                Dim tickPen As New Pen(ForeColor)
                If _barOrientation = Orientation.Horizontal Then
                    For n As Integer = 0 To _tickCount
                        Dim x As Single = 3 + _thumbSize / 2.0F + n * (_barRect.Width - 6) / CSng(_tickCount)
                        If _tickStyle = TickStyle.TopLeft OrElse _tickStyle = TickStyle.Both Then
                            e.Graphics.DrawLine(tickPen, x, 1, x, 6)
                        End If
                        If _tickStyle = TickStyle.BottomRight OrElse _tickStyle = TickStyle.Both Then
                            e.Graphics.DrawLine(tickPen, x, Height - 2, x, Height - 7)
                        End If
                    Next
                Else
                    For n As Integer = 0 To _tickCount
                        Dim y As Single = 3 + _thumbSize / 2.0F + n * (_barRect.Height - 6) / CSng(_tickCount)
                        If _tickStyle = TickStyle.TopLeft OrElse _tickStyle = TickStyle.Both Then
                            e.Graphics.DrawLine(tickPen, 1, y, 6, y)
                        End If
                        If _tickStyle = TickStyle.BottomRight OrElse _tickStyle = TickStyle.Both Then
                            e.Graphics.DrawLine(tickPen, Width - 2, y, Width - 7, y)
                        End If
                    Next
                End If
            End If
        End Using
		
		' ------------------------------------------------------ draw external rectangle
        If __roundRectBorderColor.A <> 0 Then
            Dim r As Rectangle = ClientRectangle
            r.Width -= 2
            r.Height -= 2
            Using gpBorder As GraphicsPath = CreateRoundRectPath(r, _borderRoundRectSize)
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
                e.Graphics.DrawPath(__roundRectBorderPen, gpBorder)
            End Using
        End If

        ' ------------------------------------------------------ draw value as text
        If (_showTextAlways OrElse _mouseInRegion) AndAlso _textColor.A <> 0 AndAlso Enabled Then
            Dim s As String = Value.ToString()

            If _barOrientation = Orientation.Horizontal Then
                Dim textWidth As Integer = CInt(Math.Truncate(e.Graphics.MeasureString(s, Font).Width))
                Dim x As Integer = _thumbRect.Right + 3
                If _thumbRect.Right > ClientSize.Width - textWidth - 2 Then
                    x = _thumbRect.Left - textWidth - 2
                End If
                e.Graphics.DrawString(s, Me.Font, _brushTextColor, x, -2)
            Else
                Dim y As Integer = _thumbRect.Top - Me.Font.Height - 2
                If _thumbRect.Top < Me.Font.Height Then
                    y = _thumbRect.Bottom + 4
                End If
                e.Graphics.DrawString(s, Me.Font, _brushTextColor, -1, y)
            End If
        End If

        ' ------------------------------------------------------ draw title text
        If (_showTextAlways OrElse _mouseInRegion) AndAlso _textColor.A <> 0 AndAlso Text <> "" AndAlso Enabled Then
            Dim textWidth As Integer = CInt(Math.Truncate(e.Graphics.MeasureString(Text, Font).Width))

            If _barOrientation = Orientation.Horizontal Then
                Dim x As Integer = ClientSize.Width - textWidth - 2
                Dim y As Integer = ClientSize.Height - Font.Height + 2
                If _thumbRect.Right > ClientSize.Width - textWidth - 2 Then
                    'x = _thumbRect.Left - textWidth - 2 ' <-- Moving
                    x = 2 ' <-- Fixed to the left
                End If
                If x < -2 Then
                    x = -2
                End If
                'ClientSize.Width - textWidth - 2;
                e.Graphics.DrawString(Text, Font, _brushTextColor, x, y)
            Else
                Dim x As Integer = ClientSize.Width - Font.Height + 2
                Dim y As Integer = textWidth + 2
                If _thumbRect.Top < textWidth + 2 Then
                    y = ClientSize.Height - 2
                End If
                e.Graphics.RotateTransform(-90)
                e.Graphics.DrawString(Text, Font, _brushTextColor, -y, x, StringFormat.GenericDefault)
                e.Graphics.RotateTransform(90)
            End If
        End If

        ' --------------------------------------------------------------- draw thumb
        Dim newthumbOuterColorPaint As Color = thumbOuterColorPaint
        Dim newthumbInnerColorPaint As Color = thumbInnerColorPaint
        If Capture Then
            newthumbOuterColorPaint = ControlPaint.Light(thumbOuterColorPaint)
        End If
        Using lgbThumb As New LinearGradientBrush(_thumbHalfRect, newthumbOuterColorPaint, newthumbInnerColorPaint, gradientOrientation)
            lgbThumb.WrapMode = WrapMode.TileFlipXY
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
            e.Graphics.FillPath(lgbThumb, thumbPath)
            ' ----------------------------------------------------------- draw thumb band
            Dim newThumbPenColor As Color = thumbPenColorPaint
            If _mouseEffects AndAlso (Capture OrElse _mouseInThumbRegion) Then
                newThumbPenColor = ControlPaint.Dark(newThumbPenColor, 0.3F)
            End If
            Using thumbPen As New Pen(newThumbPenColor)
                e.Graphics.DrawPath(thumbPen, thumbPath)
            End Using
        End Using
    End Sub

End Class

