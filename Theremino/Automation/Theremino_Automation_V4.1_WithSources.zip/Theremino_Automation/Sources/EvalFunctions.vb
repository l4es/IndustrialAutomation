Public Class EvalFunctions

    Function slot(ByVal value As Double) As Double
        Return Slots.ReadSlot_NoNan(CInt(value))
    End Function

    Function pi() As Double
        Return Math.PI
    End Function
    Function sin(ByVal v As Double) As Double
        Return Math.Sin(v)
    End Function
    Function cos(ByVal v As Double) As Double
        Return Math.Cos(v)
    End Function
    Function asin(ByVal v As Double) As Double
        Return Math.Asin(v)
    End Function
    Function acos(ByVal v As Double) As Double
        Return Math.Acos(v)
    End Function
    Function tan(ByVal v As Double) As Double
        Return Math.Tan(v)
    End Function
    Function atan(ByVal v As Double) As Double
        Return Math.Atan(v)
    End Function
    Function atan2(ByVal v1 As Double, ByVal v2 As Double) As Double
        Return Math.Atan2(v1, v2)
    End Function
    Function pow(ByVal v1 As Double, ByVal v2 As Double) As Double
        Return Math.Pow(v1, v2)
    End Function
    Function sqrt(ByVal v1 As Double) As Double
        Return Math.Sqrt(v1)
    End Function
    Function abs(ByVal v1 As Double) As Double
        Return Math.Abs(v1)
    End Function
    Function sign(ByVal v1 As Double) As Double
        Return Math.Sign(v1)
    End Function

    Function int(ByVal value As Double) As Double
        Return Microsoft.VisualBasic.Int(value)
    End Function
    Function round(ByVal value As Double) As Double
        Return Math.Round(value)
    End Function
    Function mid(ByVal str As String, ByVal index As Double, ByVal len As Double) As String
        If str = "" Or str Is Nothing Or index = 0 Then Return ""
        Return Microsoft.VisualBasic.Mid(str, CInt(index), CInt(len))
    End Function
    Function len(ByVal str As String) As Double
        Return Microsoft.VisualBasic.Len(str)
    End Function
    Function trim(ByVal str As String) As String
        Return Microsoft.VisualBasic.Trim(str)
    End Function

    Function format(ByVal value As Object, ByVal style As String) As String
        Return Microsoft.VisualBasic.Format(value, style).Replace(",", ".")
    End Function
    Function ucase(ByVal value As String) As String
        Return Microsoft.VisualBasic.UCase(value)
    End Function
    Function lcase(ByVal value As String) As String
        Return Microsoft.VisualBasic.LCase(value)
    End Function
    Function wcase(ByVal value As String) As String
        If len(value) = 0 Then Return ""
        Return Microsoft.VisualBasic.UCase(value.Substring(0, 1)) & _
              Microsoft.VisualBasic.LCase(value.Substring(1))
    End Function

    Function [date](ByVal year As Double, ByVal month As Double, ByVal day As Double) As DateTime
        Return New Date(CInt(year), CInt(month), CInt(day))
    End Function
    Function now() As DateTime
        Return Microsoft.VisualBasic.Now
    End Function
    Function today() As DateTime
        Return Microsoft.VisualBasic.Today
    End Function

    Function elapsedtime() As Double
        Return Microsoft.VisualBasic.Now.Subtract(StartTime).TotalSeconds
    End Function

    Function rnd() As Double
        Microsoft.VisualBasic.Randomize()
        Return Microsoft.VisualBasic.Rnd()
    End Function

End Class

