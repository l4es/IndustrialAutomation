﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chk_ColorLines = New System.Windows.Forms.CheckBox
        Me.Panel_EditCommands = New System.Windows.Forms.Panel
        Me.tkbar_Speed = New Theremino_Automation.MyTrackBar
        Me.tkbar_Zoom = New Theremino_Automation.MyTrackBar
        Me.Label_Lines = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.WMP = New AxWMPLib.AxWindowsMediaPlayer
        Me.RTB = New Theremino_Automation.SyntaxRichTextBox
        Me.MenuStrip_Edit = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip_Edit_Debug = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_ToggleBreakpoint = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_DeleteAllBreakpoints = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Edit_Cut = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Copy = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Paste = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Delete = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Edit_SelectAll = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Edit_Comment = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Uncomment = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Edit_Indent = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Unindent = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Edit_Find = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Edit_Replace = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chk_Redo = New System.Windows.Forms.CheckBox
        Me.chk_Undo = New System.Windows.Forms.CheckBox
        Me.chk_Save = New System.Windows.Forms.CheckBox
        Me.chk_Run = New System.Windows.Forms.CheckBox
        Me.chk_Load = New System.Windows.Forms.CheckBox
        Me.Button_8 = New System.Windows.Forms.CheckBox
        Me.Button_7 = New System.Windows.Forms.CheckBox
        Me.Button_6 = New System.Windows.Forms.CheckBox
        Me.Button_5 = New System.Windows.Forms.CheckBox
        Me.Button_4 = New System.Windows.Forms.CheckBox
        Me.Button_3 = New System.Windows.Forms.CheckBox
        Me.Button_2 = New System.Windows.Forms.CheckBox
        Me.Button_1 = New System.Windows.Forms.CheckBox
        Me.TimerSlow = New System.Windows.Forms.Timer(Me.components)
        Me.StatusLabel1 = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.MenuStrip_Exit = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip_Exit_Debug = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Exit_ViewMode_Sizable = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Exit_ViewMode_Maximized = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip_Exit_ViewMode_FullScreen = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Exit_StopRunning = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_Exit_TerminateApp = New System.Windows.Forms.ToolStripMenuItem
        Me.TimerFast = New System.Windows.Forms.Timer(Me.components)
        Me.txt_WebBrowserURL = New System.Windows.Forms.TextBox
        Me.btnGoForward = New System.Windows.Forms.Button
        Me.btnGoBack = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        Me.Panel_EditCommands.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WMP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip_Edit.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip_Exit.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.Cornsilk
        Me.GroupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox2.Controls.Add(Me.chk_ColorLines)
        Me.GroupBox2.Controls.Add(Me.Panel_EditCommands)
        Me.GroupBox2.Controls.Add(Me.PictureBox1)
        Me.GroupBox2.Controls.Add(Me.WMP)
        Me.GroupBox2.Controls.Add(Me.RTB)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(191, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(458, 442)
        Me.GroupBox2.TabIndex = 150
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Program"
        '
        'chk_ColorLines
        '
        Me.chk_ColorLines.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chk_ColorLines.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_ColorLines.BackColor = System.Drawing.Color.OldLace
        Me.chk_ColorLines.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_ColorLines.FlatAppearance.BorderSize = 0
        Me.chk_ColorLines.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_ColorLines.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_ColorLines.Font = New System.Drawing.Font("Tahoma", 7.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ColorLines.ForeColor = System.Drawing.Color.Black
        Me.chk_ColorLines.Location = New System.Drawing.Point(360, -2)
        Me.chk_ColorLines.Name = "chk_ColorLines"
        Me.chk_ColorLines.Size = New System.Drawing.Size(85, 20)
        Me.chk_ColorLines.TabIndex = 12
        Me.chk_ColorLines.Text = "COLOR LINES"
        Me.chk_ColorLines.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ColorLines.UseVisualStyleBackColor = False
        '
        'Panel_EditCommands
        '
        Me.Panel_EditCommands.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_EditCommands.Controls.Add(Me.tkbar_Speed)
        Me.Panel_EditCommands.Controls.Add(Me.tkbar_Zoom)
        Me.Panel_EditCommands.Controls.Add(Me.Label_Lines)
        Me.Panel_EditCommands.Location = New System.Drawing.Point(6, 412)
        Me.Panel_EditCommands.Name = "Panel_EditCommands"
        Me.Panel_EditCommands.Size = New System.Drawing.Size(450, 28)
        Me.Panel_EditCommands.TabIndex = 10
        '
        'tkbar_Speed
        '
        Me.tkbar_Speed.BackColor = System.Drawing.Color.Transparent
        Me.tkbar_Speed.BorderRoundRectSize = New System.Drawing.Size(8, 8)
        Me.tkbar_Speed.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tkbar_Speed.LargeChange = CType(1UI, UInteger)
        Me.tkbar_Speed.Location = New System.Drawing.Point(1, 2)
        Me.tkbar_Speed.Logaritmicity = 1.0!
        Me.tkbar_Speed.Maximum = 9
        Me.tkbar_Speed.Minimum = 1
        Me.tkbar_Speed.Name = "tkbar_Speed"
        Me.tkbar_Speed.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.tkbar_Speed.ShowTextAlways = True
        Me.tkbar_Speed.Size = New System.Drawing.Size(118, 25)
        Me.tkbar_Speed.SmallChange = CType(1UI, UInteger)
        Me.tkbar_Speed.TabIndex = 13
        Me.tkbar_Speed.Text = "Speed"
        Me.tkbar_Speed.TextColor = System.Drawing.Color.Black
        Me.tkbar_Speed.ThumbRoundRectSize = New System.Drawing.Size(12, 12)
        Me.tkbar_Speed.TickStyle = System.Windows.Forms.TickStyle.None
        Me.tkbar_Speed.Value = 5
        '
        'tkbar_Zoom
        '
        Me.tkbar_Zoom.BackColor = System.Drawing.Color.Transparent
        Me.tkbar_Zoom.BorderRoundRectSize = New System.Drawing.Size(8, 8)
        Me.tkbar_Zoom.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tkbar_Zoom.LargeChange = CType(1UI, UInteger)
        Me.tkbar_Zoom.Location = New System.Drawing.Point(126, 2)
        Me.tkbar_Zoom.Logaritmicity = 1.0!
        Me.tkbar_Zoom.Maximum = 9
        Me.tkbar_Zoom.Minimum = 1
        Me.tkbar_Zoom.Name = "tkbar_Zoom"
        Me.tkbar_Zoom.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.tkbar_Zoom.ShowTextAlways = True
        Me.tkbar_Zoom.Size = New System.Drawing.Size(118, 25)
        Me.tkbar_Zoom.SmallChange = CType(1UI, UInteger)
        Me.tkbar_Zoom.TabIndex = 11
        Me.tkbar_Zoom.Text = "Zoom"
        Me.tkbar_Zoom.TextColor = System.Drawing.Color.Black
        Me.tkbar_Zoom.ThumbRoundRectSize = New System.Drawing.Size(12, 12)
        Me.tkbar_Zoom.TickStyle = System.Windows.Forms.TickStyle.None
        Me.tkbar_Zoom.Value = 5
        '
        'Label_Lines
        '
        Me.Label_Lines.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Lines.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Lines.Location = New System.Drawing.Point(250, 8)
        Me.Label_Lines.Name = "Label_Lines"
        Me.Label_Lines.Size = New System.Drawing.Size(198, 16)
        Me.Label_Lines.TabIndex = 8
        Me.Label_Lines.Text = "Lines:"
        Me.Label_Lines.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Location = New System.Drawing.Point(313, 40)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 162)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'WMP
        '
        Me.WMP.Enabled = True
        Me.WMP.Location = New System.Drawing.Point(54, 39)
        Me.WMP.Name = "WMP"
        Me.WMP.OcxState = CType(resources.GetObject("WMP.OcxState"), System.Windows.Forms.AxHost.State)
        Me.WMP.Size = New System.Drawing.Size(220, 161)
        Me.WMP.TabIndex = 7
        Me.WMP.Visible = False
        '
        'RTB
        '
        Me.RTB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RTB.ContextMenuStrip = Me.MenuStrip_Edit
        Me.RTB.Location = New System.Drawing.Point(11, 18)
        Me.RTB.Name = "RTB"
        Me.RTB.Size = New System.Drawing.Size(439, 393)
        Me.RTB.TabIndex = 6
        Me.RTB.Text = ""
        '
        'MenuStrip_Edit
        '
        Me.MenuStrip_Edit.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuStrip_Edit_Debug, Me.MenuStrip_Edit_ToggleBreakpoint, Me.MenuStrip_Edit_DeleteAllBreakpoints, Me.ToolStripSeparator8, Me.MenuStrip_Edit_Cut, Me.MenuStrip_Edit_Copy, Me.MenuStrip_Edit_Paste, Me.MenuStrip_Edit_Delete, Me.ToolStripSeparator1, Me.MenuStrip_Edit_SelectAll, Me.ToolStripSeparator2, Me.MenuStrip_Edit_Comment, Me.MenuStrip_Edit_Uncomment, Me.ToolStripSeparator3, Me.MenuStrip_Edit_Indent, Me.MenuStrip_Edit_Unindent, Me.ToolStripSeparator4, Me.MenuStrip_Edit_Find, Me.MenuStrip_Edit_Replace})
        Me.MenuStrip_Edit.Name = "ContextMenuStrip1"
        Me.MenuStrip_Edit.Size = New System.Drawing.Size(188, 342)
        '
        'MenuStrip_Edit_Debug
        '
        Me.MenuStrip_Edit_Debug.Image = CType(resources.GetObject("MenuStrip_Edit_Debug.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Debug.Name = "MenuStrip_Edit_Debug"
        Me.MenuStrip_Edit_Debug.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Debug.Text = "Debug"
        '
        'MenuStrip_Edit_ToggleBreakpoint
        '
        Me.MenuStrip_Edit_ToggleBreakpoint.Image = CType(resources.GetObject("MenuStrip_Edit_ToggleBreakpoint.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_ToggleBreakpoint.Name = "MenuStrip_Edit_ToggleBreakpoint"
        Me.MenuStrip_Edit_ToggleBreakpoint.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_ToggleBreakpoint.Text = "Toggle breakpoint"
        '
        'MenuStrip_Edit_DeleteAllBreakpoints
        '
        Me.MenuStrip_Edit_DeleteAllBreakpoints.Image = CType(resources.GetObject("MenuStrip_Edit_DeleteAllBreakpoints.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_DeleteAllBreakpoints.Name = "MenuStrip_Edit_DeleteAllBreakpoints"
        Me.MenuStrip_Edit_DeleteAllBreakpoints.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_DeleteAllBreakpoints.Text = "Delete all breakpoints"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(184, 6)
        '
        'MenuStrip_Edit_Cut
        '
        Me.MenuStrip_Edit_Cut.Image = CType(resources.GetObject("MenuStrip_Edit_Cut.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Cut.Name = "MenuStrip_Edit_Cut"
        Me.MenuStrip_Edit_Cut.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Cut.Text = "Cut"
        '
        'MenuStrip_Edit_Copy
        '
        Me.MenuStrip_Edit_Copy.Image = CType(resources.GetObject("MenuStrip_Edit_Copy.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Copy.Name = "MenuStrip_Edit_Copy"
        Me.MenuStrip_Edit_Copy.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Copy.Text = "Copy"
        '
        'MenuStrip_Edit_Paste
        '
        Me.MenuStrip_Edit_Paste.Image = CType(resources.GetObject("MenuStrip_Edit_Paste.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Paste.Name = "MenuStrip_Edit_Paste"
        Me.MenuStrip_Edit_Paste.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Paste.Text = "Paste"
        '
        'MenuStrip_Edit_Delete
        '
        Me.MenuStrip_Edit_Delete.Image = CType(resources.GetObject("MenuStrip_Edit_Delete.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Delete.Name = "MenuStrip_Edit_Delete"
        Me.MenuStrip_Edit_Delete.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Delete.Text = "Delete"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(184, 6)
        '
        'MenuStrip_Edit_SelectAll
        '
        Me.MenuStrip_Edit_SelectAll.Name = "MenuStrip_Edit_SelectAll"
        Me.MenuStrip_Edit_SelectAll.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_SelectAll.Text = "Select all"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(184, 6)
        '
        'MenuStrip_Edit_Comment
        '
        Me.MenuStrip_Edit_Comment.Image = CType(resources.GetObject("MenuStrip_Edit_Comment.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Comment.Name = "MenuStrip_Edit_Comment"
        Me.MenuStrip_Edit_Comment.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Comment.Text = "Comment"
        '
        'MenuStrip_Edit_Uncomment
        '
        Me.MenuStrip_Edit_Uncomment.Image = CType(resources.GetObject("MenuStrip_Edit_Uncomment.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Uncomment.Name = "MenuStrip_Edit_Uncomment"
        Me.MenuStrip_Edit_Uncomment.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Uncomment.Text = "Un-comment"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(184, 6)
        '
        'MenuStrip_Edit_Indent
        '
        Me.MenuStrip_Edit_Indent.Image = CType(resources.GetObject("MenuStrip_Edit_Indent.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Indent.Name = "MenuStrip_Edit_Indent"
        Me.MenuStrip_Edit_Indent.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Indent.Text = "Indent"
        '
        'MenuStrip_Edit_Unindent
        '
        Me.MenuStrip_Edit_Unindent.Image = CType(resources.GetObject("MenuStrip_Edit_Unindent.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Unindent.Name = "MenuStrip_Edit_Unindent"
        Me.MenuStrip_Edit_Unindent.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Unindent.Text = "Un-indent"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(184, 6)
        '
        'MenuStrip_Edit_Find
        '
        Me.MenuStrip_Edit_Find.Image = CType(resources.GetObject("MenuStrip_Edit_Find.Image"), System.Drawing.Image)
        Me.MenuStrip_Edit_Find.Name = "MenuStrip_Edit_Find"
        Me.MenuStrip_Edit_Find.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Find.Text = "Find"
        '
        'MenuStrip_Edit_Replace
        '
        Me.MenuStrip_Edit_Replace.Name = "MenuStrip_Edit_Replace"
        Me.MenuStrip_Edit_Replace.Size = New System.Drawing.Size(187, 22)
        Me.MenuStrip_Edit_Replace.Text = "Replace"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.Cornsilk
        Me.GroupBox1.Controls.Add(Me.chk_Redo)
        Me.GroupBox1.Controls.Add(Me.chk_Undo)
        Me.GroupBox1.Controls.Add(Me.chk_Save)
        Me.GroupBox1.Controls.Add(Me.chk_Run)
        Me.GroupBox1.Controls.Add(Me.chk_Load)
        Me.GroupBox1.Controls.Add(Me.Button_8)
        Me.GroupBox1.Controls.Add(Me.Button_7)
        Me.GroupBox1.Controls.Add(Me.Button_6)
        Me.GroupBox1.Controls.Add(Me.Button_5)
        Me.GroupBox1.Controls.Add(Me.Button_4)
        Me.GroupBox1.Controls.Add(Me.Button_3)
        Me.GroupBox1.Controls.Add(Me.Button_2)
        Me.GroupBox1.Controls.Add(Me.Button_1)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(179, 442)
        Me.GroupBox1.TabIndex = 210
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Controls"
        '
        'chk_Redo
        '
        Me.chk_Redo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Redo.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Redo.BackColor = System.Drawing.Color.Moccasin
        Me.chk_Redo.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Redo.FlatAppearance.BorderSize = 3
        Me.chk_Redo.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Redo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Redo.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Redo.ForeColor = System.Drawing.Color.Black
        Me.chk_Redo.Location = New System.Drawing.Point(91, 333)
        Me.chk_Redo.Name = "chk_Redo"
        Me.chk_Redo.Size = New System.Drawing.Size(78, 30)
        Me.chk_Redo.TabIndex = 9
        Me.chk_Redo.Text = "REDO"
        Me.chk_Redo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Redo.UseVisualStyleBackColor = False
        '
        'chk_Undo
        '
        Me.chk_Undo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Undo.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Undo.BackColor = System.Drawing.Color.Moccasin
        Me.chk_Undo.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Undo.FlatAppearance.BorderSize = 3
        Me.chk_Undo.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Undo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Undo.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Undo.ForeColor = System.Drawing.Color.Black
        Me.chk_Undo.Location = New System.Drawing.Point(9, 333)
        Me.chk_Undo.Name = "chk_Undo"
        Me.chk_Undo.Size = New System.Drawing.Size(78, 30)
        Me.chk_Undo.TabIndex = 8
        Me.chk_Undo.Text = "UNDO"
        Me.chk_Undo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Undo.UseVisualStyleBackColor = False
        '
        'chk_Save
        '
        Me.chk_Save.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Save.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Save.BackColor = System.Drawing.Color.Moccasin
        Me.chk_Save.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Save.FlatAppearance.BorderSize = 3
        Me.chk_Save.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Save.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Save.ForeColor = System.Drawing.Color.Black
        Me.chk_Save.Location = New System.Drawing.Point(91, 367)
        Me.chk_Save.Name = "chk_Save"
        Me.chk_Save.Size = New System.Drawing.Size(78, 30)
        Me.chk_Save.TabIndex = 6
        Me.chk_Save.Text = "SAVE AS"
        Me.chk_Save.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Save.UseVisualStyleBackColor = False
        '
        'chk_Run
        '
        Me.chk_Run.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Run.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Run.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.chk_Run.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Run.FlatAppearance.BorderSize = 3
        Me.chk_Run.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Run.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Run.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Run.ForeColor = System.Drawing.Color.Black
        Me.chk_Run.Location = New System.Drawing.Point(9, 401)
        Me.chk_Run.Name = "chk_Run"
        Me.chk_Run.Size = New System.Drawing.Size(160, 32)
        Me.chk_Run.TabIndex = 4
        Me.chk_Run.Text = "STOP"
        Me.chk_Run.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Run.UseVisualStyleBackColor = False
        '
        'chk_Load
        '
        Me.chk_Load.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Load.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Load.BackColor = System.Drawing.Color.Moccasin
        Me.chk_Load.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Load.FlatAppearance.BorderSize = 3
        Me.chk_Load.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Load.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Load.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Load.ForeColor = System.Drawing.Color.Black
        Me.chk_Load.Location = New System.Drawing.Point(9, 367)
        Me.chk_Load.Name = "chk_Load"
        Me.chk_Load.Size = New System.Drawing.Size(78, 30)
        Me.chk_Load.TabIndex = 7
        Me.chk_Load.Text = "LOAD"
        Me.chk_Load.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Load.UseVisualStyleBackColor = False
        '
        'Button_8
        '
        Me.Button_8.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_8.BackColor = System.Drawing.Color.OldLace
        Me.Button_8.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_8.FlatAppearance.BorderSize = 2
        Me.Button_8.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_8.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_8.ForeColor = System.Drawing.Color.Black
        Me.Button_8.Location = New System.Drawing.Point(9, 362)
        Me.Button_8.Name = "Button_8"
        Me.Button_8.Size = New System.Drawing.Size(160, 46)
        Me.Button_8.TabIndex = 15
        Me.Button_8.Text = "Button 8"
        Me.Button_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_8.UseVisualStyleBackColor = False
        '
        'Button_7
        '
        Me.Button_7.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_7.BackColor = System.Drawing.Color.OldLace
        Me.Button_7.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_7.FlatAppearance.BorderSize = 2
        Me.Button_7.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_7.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_7.ForeColor = System.Drawing.Color.Black
        Me.Button_7.Location = New System.Drawing.Point(9, 313)
        Me.Button_7.Name = "Button_7"
        Me.Button_7.Size = New System.Drawing.Size(160, 46)
        Me.Button_7.TabIndex = 14
        Me.Button_7.Text = "Button 7"
        Me.Button_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_7.UseVisualStyleBackColor = False
        '
        'Button_6
        '
        Me.Button_6.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_6.BackColor = System.Drawing.Color.OldLace
        Me.Button_6.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_6.FlatAppearance.BorderSize = 2
        Me.Button_6.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_6.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_6.ForeColor = System.Drawing.Color.Black
        Me.Button_6.Location = New System.Drawing.Point(9, 264)
        Me.Button_6.Name = "Button_6"
        Me.Button_6.Size = New System.Drawing.Size(160, 46)
        Me.Button_6.TabIndex = 13
        Me.Button_6.Text = "Button 6"
        Me.Button_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_6.UseVisualStyleBackColor = False
        '
        'Button_5
        '
        Me.Button_5.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_5.BackColor = System.Drawing.Color.OldLace
        Me.Button_5.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_5.FlatAppearance.BorderSize = 2
        Me.Button_5.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_5.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_5.ForeColor = System.Drawing.Color.Black
        Me.Button_5.Location = New System.Drawing.Point(9, 215)
        Me.Button_5.Name = "Button_5"
        Me.Button_5.Size = New System.Drawing.Size(160, 46)
        Me.Button_5.TabIndex = 12
        Me.Button_5.Text = "Button 5"
        Me.Button_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_5.UseVisualStyleBackColor = False
        '
        'Button_4
        '
        Me.Button_4.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_4.BackColor = System.Drawing.Color.OldLace
        Me.Button_4.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_4.FlatAppearance.BorderSize = 2
        Me.Button_4.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_4.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_4.ForeColor = System.Drawing.Color.Black
        Me.Button_4.Location = New System.Drawing.Point(9, 166)
        Me.Button_4.Name = "Button_4"
        Me.Button_4.Size = New System.Drawing.Size(160, 46)
        Me.Button_4.TabIndex = 11
        Me.Button_4.Text = "Button 4"
        Me.Button_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_4.UseVisualStyleBackColor = False
        '
        'Button_3
        '
        Me.Button_3.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_3.BackColor = System.Drawing.Color.OldLace
        Me.Button_3.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_3.FlatAppearance.BorderSize = 2
        Me.Button_3.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_3.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_3.ForeColor = System.Drawing.Color.Black
        Me.Button_3.Location = New System.Drawing.Point(9, 117)
        Me.Button_3.Name = "Button_3"
        Me.Button_3.Size = New System.Drawing.Size(160, 46)
        Me.Button_3.TabIndex = 10
        Me.Button_3.Text = "Button 3"
        Me.Button_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_3.UseVisualStyleBackColor = False
        '
        'Button_2
        '
        Me.Button_2.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_2.BackColor = System.Drawing.Color.OldLace
        Me.Button_2.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_2.FlatAppearance.BorderSize = 2
        Me.Button_2.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_2.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_2.ForeColor = System.Drawing.Color.Black
        Me.Button_2.Location = New System.Drawing.Point(9, 68)
        Me.Button_2.Name = "Button_2"
        Me.Button_2.Size = New System.Drawing.Size(160, 46)
        Me.Button_2.TabIndex = 2
        Me.Button_2.Text = "Button 2"
        Me.Button_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_2.UseVisualStyleBackColor = False
        '
        'Button_1
        '
        Me.Button_1.Appearance = System.Windows.Forms.Appearance.Button
        Me.Button_1.BackColor = System.Drawing.Color.OldLace
        Me.Button_1.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.Button_1.FlatAppearance.BorderSize = 2
        Me.Button_1.FlatAppearance.CheckedBackColor = System.Drawing.Color.OldLace
        Me.Button_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_1.ForeColor = System.Drawing.Color.Black
        Me.Button_1.Location = New System.Drawing.Point(9, 19)
        Me.Button_1.Name = "Button_1"
        Me.Button_1.Size = New System.Drawing.Size(160, 46)
        Me.Button_1.TabIndex = 1
        Me.Button_1.Text = "Button 1"
        Me.Button_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_1.UseVisualStyleBackColor = False
        '
        'TimerSlow
        '
        '
        'StatusLabel1
        '
        Me.StatusLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StatusLabel1.BackColor = System.Drawing.Color.AliceBlue
        Me.StatusLabel1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.StatusLabel1.Location = New System.Drawing.Point(5, 451)
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(632, 42)
        Me.StatusLabel1.TabIndex = 212
        Me.StatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.BackColor = System.Drawing.Color.AliceBlue
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 447)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(654, 50)
        Me.StatusStrip1.TabIndex = 211
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'MenuStrip_Exit
        '
        Me.MenuStrip_Exit.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip_Exit.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuStrip_Exit_Debug, Me.ToolStripSeparator7, Me.MenuStrip_Exit_ViewMode_Sizable, Me.MenuStrip_Exit_ViewMode_Maximized, Me.MenuStrip_Exit_ViewMode_FullScreen, Me.ToolStripSeparator6, Me.MenuStrip_Exit_StopRunning, Me.ToolStripSeparator5, Me.MenuStrip_Exit_TerminateApp})
        Me.MenuStrip_Exit.Name = "ContextMenuStrip1"
        Me.MenuStrip_Exit.Size = New System.Drawing.Size(267, 202)
        '
        'MenuStrip_Exit_Debug
        '
        Me.MenuStrip_Exit_Debug.Image = CType(resources.GetObject("MenuStrip_Exit_Debug.Image"), System.Drawing.Image)
        Me.MenuStrip_Exit_Debug.Name = "MenuStrip_Exit_Debug"
        Me.MenuStrip_Exit_Debug.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_Debug.Text = "Debug"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(263, 6)
        '
        'MenuStrip_Exit_ViewMode_Sizable
        '
        Me.MenuStrip_Exit_ViewMode_Sizable.Name = "MenuStrip_Exit_ViewMode_Sizable"
        Me.MenuStrip_Exit_ViewMode_Sizable.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_ViewMode_Sizable.Text = "Sizable"
        '
        'MenuStrip_Exit_ViewMode_Maximized
        '
        Me.MenuStrip_Exit_ViewMode_Maximized.Name = "MenuStrip_Exit_ViewMode_Maximized"
        Me.MenuStrip_Exit_ViewMode_Maximized.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_ViewMode_Maximized.Text = "Maximized"
        '
        'MenuStrip_Exit_ViewMode_FullScreen
        '
        Me.MenuStrip_Exit_ViewMode_FullScreen.Name = "MenuStrip_Exit_ViewMode_FullScreen"
        Me.MenuStrip_Exit_ViewMode_FullScreen.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_ViewMode_FullScreen.Text = "Full Screen"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(263, 6)
        '
        'MenuStrip_Exit_StopRunning
        '
        Me.MenuStrip_Exit_StopRunning.Image = CType(resources.GetObject("MenuStrip_Exit_StopRunning.Image"), System.Drawing.Image)
        Me.MenuStrip_Exit_StopRunning.Name = "MenuStrip_Exit_StopRunning"
        Me.MenuStrip_Exit_StopRunning.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_StopRunning.Text = "Stop running"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(263, 6)
        '
        'MenuStrip_Exit_TerminateApp
        '
        Me.MenuStrip_Exit_TerminateApp.Image = CType(resources.GetObject("MenuStrip_Exit_TerminateApp.Image"), System.Drawing.Image)
        Me.MenuStrip_Exit_TerminateApp.Name = "MenuStrip_Exit_TerminateApp"
        Me.MenuStrip_Exit_TerminateApp.Size = New System.Drawing.Size(266, 30)
        Me.MenuStrip_Exit_TerminateApp.Text = "Terminate application"
        '
        'TimerFast
        '
        '
        'txt_WebBrowserURL
        '
        Me.txt_WebBrowserURL.AcceptsReturn = True
        Me.txt_WebBrowserURL.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_WebBrowserURL.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_WebBrowserURL.Location = New System.Drawing.Point(83, 461)
        Me.txt_WebBrowserURL.Multiline = True
        Me.txt_WebBrowserURL.Name = "txt_WebBrowserURL"
        Me.txt_WebBrowserURL.Size = New System.Drawing.Size(123, 24)
        Me.txt_WebBrowserURL.TabIndex = 213
        Me.txt_WebBrowserURL.Visible = False
        '
        'btnGoForward
        '
        Me.btnGoForward.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnGoForward.Enabled = False
        Me.btnGoForward.Image = CType(resources.GetObject("btnGoForward.Image"), System.Drawing.Image)
        Me.btnGoForward.Location = New System.Drawing.Point(43, 457)
        Me.btnGoForward.Name = "btnGoForward"
        Me.btnGoForward.Size = New System.Drawing.Size(34, 30)
        Me.btnGoForward.TabIndex = 215
        Me.btnGoForward.UseVisualStyleBackColor = True
        Me.btnGoForward.Visible = False
        '
        'btnGoBack
        '
        Me.btnGoBack.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnGoBack.Enabled = False
        Me.btnGoBack.Image = CType(resources.GetObject("btnGoBack.Image"), System.Drawing.Image)
        Me.btnGoBack.Location = New System.Drawing.Point(8, 457)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(34, 30)
        Me.btnGoBack.TabIndex = 214
        Me.btnGoBack.UseVisualStyleBackColor = True
        Me.btnGoBack.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(654, 497)
        Me.Controls.Add(Me.txt_WebBrowserURL)
        Me.Controls.Add(Me.btnGoForward)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.StatusLabel1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(670, 420)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Automation"
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel_EditCommands.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WMP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip_Edit.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.MenuStrip_Exit.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button_1 As System.Windows.Forms.CheckBox
    Friend WithEvents Button_2 As System.Windows.Forms.CheckBox
    Friend WithEvents TimerSlow As System.Windows.Forms.Timer
    Friend WithEvents chk_Run As System.Windows.Forms.CheckBox
    Friend WithEvents chk_Save As System.Windows.Forms.CheckBox
    Friend WithEvents chk_Redo As System.Windows.Forms.CheckBox
    Friend WithEvents chk_Undo As System.Windows.Forms.CheckBox
    Friend WithEvents chk_Load As System.Windows.Forms.CheckBox
    Friend WithEvents Button_3 As System.Windows.Forms.CheckBox
    Friend WithEvents Button_4 As System.Windows.Forms.CheckBox
    Friend WithEvents Button_5 As System.Windows.Forms.CheckBox
    Friend WithEvents StatusLabel1 As System.Windows.Forms.Label
    Friend WithEvents RTB As Theremino_Automation.SyntaxRichTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip_Edit As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MenuStrip_Edit_Cut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Copy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Paste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Delete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Edit_SelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Edit_Find As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Replace As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Edit_Comment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Uncomment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Indent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Unindent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents WMP As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Label_Lines As System.Windows.Forms.Label
    Friend WithEvents Panel_EditCommands As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents chk_ColorLines As System.Windows.Forms.CheckBox
    Friend WithEvents MenuStrip_Exit As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MenuStrip_Exit_StopRunning As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Exit_TerminateApp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Exit_ViewMode_Sizable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Exit_ViewMode_Maximized As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Exit_ViewMode_FullScreen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button_6 As System.Windows.Forms.CheckBox
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Exit_Debug As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_Debug As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_Edit_ToggleBreakpoint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip_Edit_DeleteAllBreakpoints As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tkbar_Zoom As Theremino_Automation.MyTrackBar
    Friend WithEvents tkbar_Speed As Theremino_Automation.MyTrackBar
    Friend WithEvents TimerFast As System.Windows.Forms.Timer
    Friend WithEvents Button_8 As System.Windows.Forms.CheckBox
    Friend WithEvents Button_7 As System.Windows.Forms.CheckBox
    Friend WithEvents txt_WebBrowserURL As System.Windows.Forms.TextBox
    Friend WithEvents btnGoForward As System.Windows.Forms.Button
    Friend WithEvents btnGoBack As System.Windows.Forms.Button
End Class
