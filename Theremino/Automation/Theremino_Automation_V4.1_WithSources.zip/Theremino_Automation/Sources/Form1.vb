﻿
Imports System.Collections.Generic

Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ShowWindowTitle()
        Form_Debug.Show()
        RTB_Init()
        Load_INI()
        Load_Program()
        ApplyEditorProps()
        EventsAreEnabled = True
        SetViewMode()
        Me.BackColor = Color_Form
        GroupBox1.BackColor = Color_Panels
        GroupBox2.BackColor = Color_Panels
        PreparePanelsForProgram()
        ShowInTaskbar = False
        ShowInTaskbar = True
        If Running Then
            StartRunning(True, 0)
        Else
            StopRunning(False)
            'RTB.ShowSuggestions(StatusLabel1, Label_Lines)
            StatusLabel1.BackColor = Color.FromArgb(220, 255, 200)
        End If
        RTB.AutoIndent()
        Me.Hide()
        Me.Show()
        WMP_Init()
        RTB.Focus()
        ' ---------------------------------- show all
        Refresh()
        Form_Debug.Refresh()
        Application.DoEvents()
        Me.Opacity = 1
        Form_Debug.Opacity = 1
        ' ---------------------------------- start all
        SchedulerMaxPrecision()
        TimerSlow.Interval = 200
        TimerSlow.Start()
        TimerFast.Interval = 15
        TimerFast.Start()
    End Sub

    Friend Sub ShowWindowTitle()
        Text = AppTitleAndVersion() + "  -  Program :  " + IO.Path.GetFileName(ProgramFile_PathAndName)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = False
        CloseAll()
    End Sub

    Private Sub CloseAll()
        ' --------------------------------- Event ClosingApp (dangerous if the user does not terminate with End)
        'CopyRtbLines()
        'ExecTheLine(0, "Goto ClosingApp")
        'Do
        '    Application.DoEvents()
        'Loop Until Running = False
        ' --------------------------------- stop all
        TimerSlow.Stop()
        TimerFast.Stop()
        ExecutionThread_Stop()
        ' --------------------------------- save slots and vars
        SaveSlots()
        SaveVars()
        ' ---------------------------------
        EventsAreEnabled = False
        Form_Input.Close()
        WMP.URL = Nothing
        SaveProgram_IfChanged()
        Save_INI()
        'ShowTrayWnd()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private OldWindowState As FormWindowState
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        SetVisibleButtons()

        If Not EventsAreEnabled Then Exit Sub
        If Me.WindowState <> OldWindowState Then
            Select Case Me.WindowState
                Case FormWindowState.Maximized : ViewMode = ViewModes.Maximized
                Case FormWindowState.Normal : ViewMode = ViewModes.Sizable
            End Select
            RedrawRtbUnscrolled()
        End If
    End Sub

    Private Sub RedrawRtbUnscrolled()
        ' ------- Force the RTB window to show all the text un-scrolled
        ' ------- otherwise some part of the text could be not visible
        Dim oldzoom As Single = RTB.ZoomFactor
        RTB.ZoomFactor = 0.1
        RTB.ZoomFactor = oldzoom
    End Sub

    ' =============================================================================================
    '  MenuStrip, ToolStrip and RichTextBox accepting the first click
    '  If the form is not focused and receives a WM_PARENTNOTIFY (528) message
    '  then the form is activated before to exec the message
    ' =============================================================================================
    <DebuggerStepThrough()> _
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub

    ' -----------------------------------------------------------------------------------------------------
    '  CONTEXTUAL MENU - EDITOR
    ' -----------------------------------------------------------------------------------------------------
    Private RTB_MousePos As Point
    Private Sub MenuStrip_Edit_Opening(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MenuStrip_Edit.Opening
        RTB_MousePos = RTB.PointToClient(MousePosition)
    End Sub
    Private Sub MenuStrip_Edit_Debug_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Debug.Click
        Form_Debug.Show()
    End Sub
    Private Sub MenuStrip_Edit_ToggleBreakpoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_ToggleBreakpoint.Click
        RTB.ToggleBreakPoint(RTB_MousePos)
    End Sub
    Private Sub MenuStrip_Edit_DeleteAllBreakpoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_DeleteAllBreakpoints.Click
        RTB.DeleteAllBreakPoints()
    End Sub
    Private Sub MenuStrip_Edit_Cut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Cut.Click
        RTB.ExecCut()
    End Sub
    Private Sub MenuStrip_Edit_Copy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Copy.Click
        RTB.ExecCopy()
    End Sub
    Private Sub MenuStrip_Edit_Paste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Paste.Click
        RTB.ExecPaste()
    End Sub
    Private Sub MenuStrip_Edit_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Delete.Click
        RTB.ExecDelete()
    End Sub
    Private Sub MenuStrip_Edit_SelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_SelectAll.Click
        RTB.SelectAll()
    End Sub
    Private Sub MenuStrip_Edit_Comment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Comment.Click
        RTB.CommentSelectedLines(True)
    End Sub
    Private Sub MenuStrip_Edit_Uncomment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Uncomment.Click
        RTB.CommentSelectedLines(False)
    End Sub
    Private Sub MenuStrip_Edit_Indent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Indent.Click
        RTB.IndentSelectedLines(+1)
    End Sub
    Private Sub MenuStrip_Edit_Unindent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Unindent.Click
        RTB.IndentSelectedLines(-1)
    End Sub
    Private Sub MenuStrip_Edit_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Find.Click
        Editor_Find()
    End Sub
    Private Sub MenuStrip_Edit_Replace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Edit_Replace.Click
        Editor_FindReplace()
    End Sub

    ' ===============================================================================================================
    '  FIND - REPLACE and Options
    ' ===============================================================================================================
    Friend Sub Editor_Find()
        With Form_Replace
            .TopMost = True
            .DialogType = Form_Replace.DialogTypeValue.Find
            .OwnerCodeBox = RTB
            .Show()
            .txtFind.Focus()
        End With
    End Sub
    Friend Sub Editor_FindReplace()
        With Form_Replace
            .TopMost = True
            .DialogType = Form_Replace.DialogTypeValue.Replace
            .OwnerCodeBox = RTB
            .Show()
            .txtFind.Focus()
        End With
    End Sub

    ' =============================================================================================
    '  APPLICATION BUTTONS
    ' ============================================================================================= 
    Private Sub chk_Undo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Undo.Click
        RTB.ExecUndo()
        RTB.Focus()
        chk_Undo.Checked = False
    End Sub
    Private Sub chk_Redo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Redo.Click
        RTB.ExecRedo()
        RTB.Focus()
        chk_Redo.Checked = False
    End Sub
    Private Sub chk_Load_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Load.Click
        LoadProgramDialog()
        RTB.Focus()
        chk_Load.Checked = False
    End Sub
    Private Sub chk_Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Save.Click
        SaveProgramDialog()
        RTB.Focus()
        chk_Save.Checked = False
    End Sub
    Private Sub chk_Run_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Run.Click
        If chk_Run.Checked Then
            StopRunning()
        Else
            StartRunning(True, 0)
        End If
    End Sub

    Private Sub chk_ColorLines_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_ColorLines.CheckedChanged
        If Not EventsAreEnabled Then Return
        chk_ColorLines.Refresh()
        RTB.ColorVisibleLines()
        'RTB.ColorAllLines()
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        chk_ColorLines.Checked = False
        EventsAreEnabled = old
    End Sub


    Private Sub txt_WebBrowserURL_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_WebBrowserURL.KeyDown
        If e.KeyCode = Keys.Return Then
            e.SuppressKeyPress = True
            e.Handled = True
            Dim url As String = txt_WebBrowserURL.Text
            If Not url.StartsWith("http") Then url = "http://" + url
            WB.Navigate(url)
        End If
    End Sub

    Private WB_zoom As Int32 = 100
    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If Running Then
            ' ------------------------------------------------------------- STOP RUNNING with SHIFT-ESC and ALT-E
            If e.KeyCode = Keys.Escape AndAlso _
               My.Computer.Keyboard.ShiftKeyDown Then
                If ViewMode = ViewModes.FullScreen Then SetViewMode_ThreadSafe(ViewModes.Maximized)
                StopRunning()
            End If
            If e.KeyCode = Keys.E AndAlso _
               My.Computer.Keyboard.AltKeyDown Then
                If ViewMode = ViewModes.FullScreen Then SetViewMode_ThreadSafe(ViewModes.Maximized)
                StopRunning()
            End If
            ' ------------------------------------------------------------- if WEB navigating then KEYS are disabled
            If PanelMode = PanelModes.Web Then
                Return
            End If
            ' -------------------------------------------------------------
            ' introduced in version 3.5  - for keys autorepeat 
            '    removed in version 3.96 - to avoid gosub accumulation
            'ExecutingKeyPress = False
            ' ------------------------------------------------------------- KEYS
            e.SuppressKeyPress = True
            e.Handled = True
            If Not ExecutingKeyPress Then
                ExecutingKeyPress = True
                ExecKeysEvent(e.KeyCode)
            End If
        Else
            ' ------------------------------------------------------------- F5 (RUN)
            If e.KeyCode = Keys.F5 OrElse _
                (e.KeyCode = Keys.R AndAlso My.Computer.Keyboard.AltKeyDown) Then
                StartRunning(True, 0)
            End If
            ' ------------------------------------------------------------- CUT / COPY / PASTE / UNDO / REDO
            If My.Computer.Keyboard.CtrlKeyDown Then
                e.SuppressKeyPress = True
                e.Handled = True
                Select Case e.KeyCode
                    Case Keys.F : Editor_Find()
                    Case Keys.X : RTB.ExecCut()
                    Case Keys.C : RTB.ExecCopy()
                    Case Keys.V : RTB.ExecPaste()
                    Case Keys.Z : RTB.ExecUndo()
                    Case Keys.Y : RTB.ExecRedo()
                    Case Keys.Space : RTB.CompleteKeyword()
                    Case Else
                        e.Handled = False
                        e.SuppressKeyPress = False
                End Select
            End If
        End If
    End Sub
    Private ExecutingKeyPress As Boolean = False
    Private Sub Form1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        RTB.Focus()
        ExecutingKeyPress = False
    End Sub


    ' =============================================================================================
    '  RICH TEXT BOX EDITOR
    ' =============================================================================================
    Private Color_Form As Color = Color.FromArgb(220, 220, 240)
    Private Color_Panels As Color = Color.FromArgb(240, 240, 240)
    Private Color_PanelEditing As Color = Color.FromArgb(240, 220, 180)
    Private Color_PanelRunning As Color = Color.FromArgb(190, 220, 170) '210, 240, 190) ' TODO
    Private Color_BackEditing As Color = Color.FromArgb(255, 250, 240)
    Private Color_BackRunning As Color = Color.FromArgb(210, 210, 210)  '230, 230, 230) ' TODO

    Private Sub RTB_Init()
        With RTB
            .AcceptsTab = True
            .DetectUrls = False
            .WordWrap = False
            .HideSelection = False
            ' The font-size determines the number of spaces for each TAB
            ' with font-size 15 each TAB is similar to 4 spaces
            .Font = New Font("Courier New", 15, FontStyle.Regular)
            .AutoWordSelection = True
            .AutoWordSelection = False
        End With

        'Dim ar() As Int32 = RTB.SelectionTabs

        'RTB_SetTabPositions(4)
    End Sub

    Private Sub chk_AutoIndent_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        If Not EventsAreEnabled Then Return
        ApplyEditorProps()
        RTB.AutoIndent()
    End Sub
    Private Sub TrackBars_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles tkbar_Speed.MouseLeave, _
                                                                                                  tkbar_Zoom.MouseLeave
        RTB.Focus()
    End Sub
    Private Sub tkbar_Speed_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tkbar_Speed.ValueChanged
        If Not EventsAreEnabled Then Return
        ApplyEditorProps()
        ShowExecutionDelayText(tkbar_Speed.Value)
    End Sub
    Private Sub tkbar_Zoom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tkbar_Zoom.ValueChanged
        If Not EventsAreEnabled Then Return
        ApplyEditorProps()
    End Sub

    Friend Sub ApplyEditorProps(Optional ByVal ForceNewZoom As Boolean = False)
        Dim z As Int32 = tkbar_Zoom.Value + 3
        Dim NewRtbZoom As Single = z / 11.0F
        If NewRtbZoom <> RTB.ZoomFactor Then
            If ForceNewZoom Then RTB.ZoomFactor = 0.1
            RTB.ZoomFactor = NewRtbZoom
        End If
        MenuStrip_Edit.Font = New Font("Tahoma", 8 + CInt(z * 0.6))
        MenuStrip_Exit.Font = New Font("Tahoma", 8 + CInt(z * 0.6))
        Form_Debug.ListView1.Font = New Font("Microsoft Sans Serif", 6 + CInt(z * 0.5))
        SetExecutionDelayParams(tkbar_Speed.Value)
    End Sub


    ' =============================================================================================
    '  PROGRAMMABLE BUTTONS
    ' =============================================================================================
    Private Const NBUTTONS As Int32 = 8
    Private ButtonSlots(NBUTTONS - 1) As Int32
    Private ButtonSlotsOldValues(NBUTTONS - 1) As Single

    Private Sub Buttons_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
                                                                    Handles Button_1.Click, _
                                                                            Button_2.Click, _
                                                                            Button_3.Click, _
                                                                            Button_4.Click, _
                                                                            Button_5.Click, _
                                                                            Button_6.Click, _
                                                                            Button_7.Click, _
                                                                            Button_8.Click
        ExecButton(CType(sender, CheckBox))
    End Sub

    Private Function GetButtonByIndex(ByVal i As Int32) As CheckBox
        Select Case i
            Case 1 : Return Button_1
            Case 2 : Return Button_2
            Case 3 : Return Button_3
            Case 4 : Return Button_4
            Case 5 : Return Button_5
            Case 6 : Return Button_6
            Case 7 : Return Button_7
            Case 8 : Return Button_8
            Case Else : Return Nothing
        End Select
    End Function

    Private Sub SetVisibleButtons()
        Dim b As CheckBox
        Dim ypos As Int32
        If Running Then
            ypos = chk_Run.Top - 2
        Else
            ypos = chk_Undo.Top - 2
        End If
        For i As Int32 = 1 To NBUTTONS
            b = GetButtonByIndex(i)
            b.Visible = b.Bottom < ypos AndAlso b.Text <> Nothing
        Next
    End Sub
    Private Sub ResetButtonSlots()
        For i As Int32 = 1 To NBUTTONS
            ButtonSlots(i - 1) = -1
        Next
    End Sub
    Friend Sub SetInitialButtonNames()
        For i As Int32 = 1 To NBUTTONS
            'SetButton_ThreadSafe(i, "Button " + i.ToString)
            SetButton_ThreadSafe(i, "")
        Next
        SetVisibleButtons()
    End Sub
    Private Sub DisableProgrammableButtons()
        For i As Int32 = 1 To NBUTTONS
            GetButtonByIndex(i).Enabled = False
        Next
    End Sub
    Private Sub EnableProgrammableButtons()
        For i As Int32 = 1 To NBUTTONS
            GetButtonByIndex(i).Enabled = True
        Next
    End Sub
    Private Sub UncheckProgrammableButtons()
        For i As Int32 = 1 To NBUTTONS
            GetButtonByIndex(i).Checked = False
        Next
    End Sub

    Private Sub ExecButtonsFromSlots()
        For i As Int32 = 0 To NBUTTONS - 1
            If ButtonSlots(i) >= 0 Then
                Dim NewValue As Single = Slots.ReadSlot_NoNan(ButtonSlots(i))
                If NewValue > 500 And ButtonSlotsOldValues(i) <= 500 Then
                    Dim button As CheckBox
                    button = GetButtonByIndex(i + 1)
                    If button.Enabled Then
                        button.Checked = True
                        ExecButton(button)
                    End If
                End If
                ButtonSlotsOldValues(i) = NewValue
            End If
        Next
    End Sub

    Private Sub ExecButton(ByVal button As CheckBox)
        If RTBLines Is Nothing Then
            Return
        End If
        Dim line As Int32 = FindLabel(button.Text)
        If line >= 0 Then
            ExecutionThread_Stop()
            If ExistsReturn() Then
                ReturnStack.Push(LineInExecution)
            End If
            GotoLine = line
            ExecutionThread_Start()
            button.Checked = False
            ' ------------------------------ buttons execution while not running
            If Not Running Then
                SelectLineLimitedLength(line)
            End If
        End If
    End Sub

    Private Function ExistsReturn() As Boolean
        Dim line As String
        For i As Int32 = 0 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("return") Then
                Return True
            End If
        Next
        Return False
    End Function
    Private Function FindLabel(ByVal TextToFind As String) As Int32
        ' ----------------------------------------------------------------------- compare with label text
        Dim TextToFind1 As String = " " + TextToFind.ToLower
        Dim TextToFind2 As String = " """ + TextToFind.ToLower + """"
        Dim line As String
        For i As Int32 = 0 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("label") Then
                RTB.RemoveComments(line)
                If line.EndsWith(TextToFind1) Or line.EndsWith(TextToFind2) Then
                    Return i
                End If
            End If
        Next
        ' ----------------------------------------------------------------------- if not found then extract first word
        TextToFind1 = " " & RTB.ExtractFirstWord(TextToFind).ToLower
        For i As Int32 = 0 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("label") Then
                RTB.RemoveComments(line)
                If line.EndsWith(TextToFind1) Then
                    Return i
                End If
            End If
        Next
        Return -1
    End Function

    ' =============================================================================================
    '  WINDOWS SCHEDULER PRECISION
    ' ============================================================================================= 
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Sub SchedulerMaxPrecision()
        If OperatingSystemIsWindows Then
            timeBeginPeriod(1)
        End If
    End Sub
    Private Sub ShedulerDefaultPrecision()
        If OperatingSystemIsWindows Then
            timeEndPeriod(1)
        End If
    End Sub

    ' =============================================================================================
    '   EXECUTION HELPING FUNCTIONS - WITH Invoke from Worker-Thread to UserInterface-Thread
    ' =============================================================================================
    Private Delegate Sub SetButton_Delegate(ByVal nbutton As Int32, ByVal text As String)
    Private Sub SetButton_ThreadSafe(ByVal nbutton As Int32, ByVal text As String)
        If InvokeRequired Then
            BeginInvoke(New SetButton_Delegate(AddressOf SetButton_ThreadSafe), nbutton, text)
        Else
            Dim b As CheckBox
            b = GetButtonByIndex(nbutton)
            If b Is Nothing Then Return
            If text = Nothing Then
                b.Text = Nothing
                SetVisibleButtons()
                Return
            End If
            Select Case text.ToLower
                Case "enabled"
                    b.Enabled = True
                Case "disabled"
                    b.Enabled = False
                Case Else
                    text = text.Replace("""", "")
                    Dim pixels As Size = TextRenderer.MeasureText(text, b.Font)
                    If pixels.Width < b.Width - 10 Then
                        b.Font = New Font(b.Font.FontFamily, 14)
                    Else
                        b.Font = New Font(b.Font.FontFamily, 10)
                    End If
                    b.Text = text
            End Select
            SetVisibleButtons()
        End If
    End Sub

    Private Delegate Sub SetButtonSlot_Delegate(ByVal nbutton As Int32, ByVal slot As Int32)
    Private Sub SetButtonSlot_ThreadSafe(ByVal nbutton As Int32, ByVal slot As Int32)
        If InvokeRequired Then
            BeginInvoke(New SetButtonSlot_Delegate(AddressOf SetButtonSlot_ThreadSafe), nbutton, slot)
        Else
            If nbutton > ButtonSlots.Length Then Return
            ButtonSlots(nbutton - 1) = slot
        End If
    End Sub

    'Private Delegate Sub UncheckButton_Delegate(ByVal button As CheckBox)
    'Private Sub UncheckButton_ThreadSafe(ByVal button As CheckBox)
    '    If InvokeRequired Then
    '        BeginInvoke(New UncheckButton_Delegate(AddressOf UncheckButton_ThreadSafe), button)
    '    Else
    '        button.Checked = False
    '    End If
    'End Sub

    Private Delegate Sub UncheckAllButtons_Delegate()
    Private Sub UncheckAllButtons_ThreadSafe()
        If InvokeRequired Then
            BeginInvoke(New UncheckAllButtons_Delegate(AddressOf UncheckAllButtons_ThreadSafe))
        Else
            UncheckProgrammableButtons()
        End If
    End Sub

    Private Delegate Sub Print_Message_Delegate(ByVal message As String)
    Private Sub Print_Message_ThreadSafe(ByVal message As String)
        If InvokeRequired Then
            BeginInvoke(New Print_Message_Delegate(AddressOf Print_Message_ThreadSafe), message)
            Threading.Thread.Sleep(1)
        Else
            StatusLabel1.Text = message
            StatusLabel1.Invalidate()
        End If
    End Sub

    Private Delegate Sub SetNewSpeed_Delegate(ByVal speed As Double)
    Private Sub SetNewSpeed_ThreadSafe(ByVal speed As Double)
        If InvokeRequired Then
            BeginInvoke(New SetNewSpeed_Delegate(AddressOf SetNewSpeed_ThreadSafe), speed)
        Else
            Dim old As Boolean = EventsAreEnabled
            EventsAreEnabled = False
            tkbar_Speed.Value = CInt(speed)
            EventsAreEnabled = old
            SetExecutionDelayParams(CInt(speed))
        End If
    End Sub

    Private Delegate Sub StopRunning_Delegate()
    Private Sub StopRunning_ThreadSafe()
        Running = False
        If InvokeRequired Then
            BeginInvoke(New StopRunning_Delegate(AddressOf StopRunning_ThreadSafe))
        Else
            StopRunning()
        End If
    End Sub

    'Private Delegate Sub SelectLine_Delegate(ByVal line As Int32)
    'Private Sub SelectLine_ThreadSafe(ByVal line As Int32)
    '    If InvokeRequired Then
    '        BeginInvoke(New SelectLine_Delegate(AddressOf SelectLine_ThreadSafe), line)
    '    Else
    '        Dim old As Boolean = EventsAreEnabled
    '        EventsAreEnabled = False
    '        RTB.SelectLine(line)
    '        EventsAreEnabled = old
    '    End If
    'End Sub

    Private Delegate Sub SelectLineLimitedLength_Delegate(ByVal line As Int32)
    Private Sub SelectLineLimitedLength_ThreadSafe(ByVal line As Int32)
        If InvokeRequired Then
            BeginInvoke(New SelectLineLimitedLength_Delegate(AddressOf SelectLineLimitedLength_ThreadSafe), line)
        Else
            Dim old As Boolean = EventsAreEnabled
            EventsAreEnabled = False
            SelectLineLimitedLength(line)
            EventsAreEnabled = old
        End If
    End Sub

    Private Sub SelectLineLimitedLength(ByVal line As Int32)
        Try
            If line < 0 Then line = 0
            ' ------------------------------------------------- calculate TABS and Zoom (about 10 uS)
            Dim limit As Int32 = CInt(34 / RTB.ZoomFactor) - 4
            Dim s As String = RTBLines(line)
            Dim j As Int32
            Dim i As Int32
            Dim tabs As Boolean = False
            For i = 0 To s.Length - 1
                If s(i) = vbTab Then
                    j += 4 - (j Mod 4)
                    tabs = True
                Else
                    j += 1
                End If
                If j > limit Then Exit For
            Next
            If tabs Then i += 1
            ' ------------------------------------------------- select line (about 1 mS)
            RTB.Select(RTB.GetFirstCharIndexFromLine(line), i)
        Catch
        End Try
    End Sub

    Private Delegate Sub InputDialog_Delegate(ByVal varname As String, ByVal prompt As String)
    Private Sub InputDialog_ThreadSafe(ByVal varname As String, ByVal prompt As String)
        If InvokeRequired Then
            '|||||||| The EndInvoke stops the calling thread until completion
            EndInvoke(BeginInvoke(New InputDialog_Delegate(AddressOf InputDialog_ThreadSafe), varname, prompt))
        Else
            Form_Input.txt_Input.Text = ""
            Form_Input.Prompt = prompt
            Form_Input.ShowDialog(Me)
            If Form_Input.ValidInput Then
                SetVariable(varname, Form_Input.txt_Input.Text)
            End If
        End If
    End Sub

    Private Delegate Sub Load_Media_Delegate(ByVal filename As String)
    Private Sub Load_Media_ThreadSafe(ByVal filename As String)
        If InvokeRequired Then
            ' ------------------------------------ wait the command execution with "Invoke" (not "BeginInvoke")
            Invoke(New Load_Media_Delegate(AddressOf Load_Media_ThreadSafe), filename)
        Else
            If filename Is Nothing Then filename = "stop"
            Select Case filename.ToLower
                Case "stop" : WMP.URL = "" : WebBrowserStop()
                Case "hide" : PreparePanelsForProgram()
                Case Else : LoadMediaFile(filename)
            End Select
            ' ------------------------------------- set buttons parent depending on ViewMode and PanelMode
            SetButtonsParent()
        End If
    End Sub

    Private Sub LoadMediaFile(ByVal filename As String)
        '
        filename = EvalString(filename)
        '
        If filename.StartsWith("http", StringComparison.InvariantCultureIgnoreCase) Then
            WebBrowserStart(filename)
        Else
            Dim fullPath As String
            Select Case Strings.Right(filename, 4).ToLower
                Case ".txt"
                    fullPath = PlatformAdjustedFileName(Application.StartupPath & "\Programs\" & filename)
                    If My.Computer.FileSystem.FileExists(fullPath) Then
                        ExecutionThread_Stop()
                        Load_Program(fullPath)
                        RTBLines = RTB.Lines
                        GotoLine = 0
                        ExecutionThread_Start()
                    End If
                    ExecutionDelay_Variable()
                Case ".jpg", ".bmp", ".png"
                    GroupBox2.Text = filename
                    fullPath = PlatformAdjustedFileName(Application.StartupPath & "\Media\" & filename)
                    If My.Computer.FileSystem.FileExists(fullPath) Then
                        PictureBox1.Image = Image.FromFile(fullPath)
                        PreparePanelsForImages()
                        GroupBox2.Text = filename
                    End If
                Case ".avi", ".wmv", ".mpg", ".mp4", ".mov", ".gif"
                    GroupBox2.Text = "Loading """ + filename + """   >>> PLEASE WAIT SOME SECONDS <<<"
                    fullPath = PlatformAdjustedFileName(Application.StartupPath & "\Media\" & filename)
                    If My.Computer.FileSystem.FileExists(fullPath) Then
                        WMP.URL = fullPath
                        WMP_WaitReady()
                        PreparePanelsForVideo()
                        GroupBox2.Text = filename
                    End If
                Case ".mp3", ".wav"
                    GroupBox2.Text = filename
                    fullPath = PlatformAdjustedFileName(Application.StartupPath & "\Media\" & filename)
                    If My.Computer.FileSystem.FileExists(fullPath) Then
                        WMP.Hide()
                        WMP.URL = fullPath
                        WMP_WaitReady()
                        GroupBox2.Text = filename
                    End If
                Case ".exe"
                    StartProcess_IfNotRunning_AndWait(filename)
                    Me.Activate()
            End Select
        End If
    End Sub



    ' =============================================================================================
    '   EXECUTION HELPING FUNCTIONS - Directly executed in the Worker-Thread
    ' =============================================================================================
    Friend Sub Beep_RepetitionLimited(ByVal ms As Int32)
        Static sw As Stopwatch
        If sw Is Nothing Then
            sw = New Stopwatch
        Else
            If sw.ElapsedMilliseconds < ms Then Return
        End If
        sw.Reset()
        sw.Start()
        Beep()
    End Sub
    Sub Wait_Seconds(ByVal seconds As Double)
        Thread.Sleep(CInt(seconds * 1000))
    End Sub

    Sub Wait_Button(ByVal ButtonName As String)
        Dim button As CheckBox = Nothing
        Dim b As CheckBox
        ButtonName = ButtonName.ToLower
        ' --------------------------------------------------- test name
        For i As Int32 = 1 To NBUTTONS
            b = GetButtonByIndex(i)
            If b.Text.ToLower = ButtonName Then
                button = b
                Exit For
            End If
        Next
        ' --------------------------------------------------- test first word of name
        If button Is Nothing Then
            ButtonName = RTB.ExtractFirstWord(ButtonName)
            For i As Int32 = 1 To NBUTTONS
                b = GetButtonByIndex(i)
                If RTB.ExtractFirstWord(b.Text).ToLower = ButtonName Then
                    button = b
                    Exit For
                End If
            Next
        End If
        ' --------------------------------------------------- wait the button release
        If button IsNot Nothing Then
            Do
                Threading.Thread.Sleep(5)
            Loop Until button.Checked
            UncheckAllButtons_ThreadSafe()
        End If
    End Sub

    Private Function FindElseOrEndif() As Int32
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = LineInExecution + 1 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("else") Then
                If counter = 0 Then  ' changed from "<=" to "=" since version 3.6
                    Return i
                End If
            ElseIf line.StartsWith("endif") Then
                If counter = 0 Then  ' changed from "<=" to "=" since version 3.6
                    Return i
                End If
                counter -= 1
            ElseIf line.StartsWith("if") Then
                counter += 1
            End If
        Next
        Return -1
    End Function

    Private Function FindEndif() As Int32
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = LineInExecution + 1 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("endif") Then
                If counter = 0 Then  ' changed from "<=" to "=" since version 3.6
                    Return i
                End If
                counter -= 1
            ElseIf line.StartsWith("if") Then
                counter += 1
            End If
        Next
        Return -1
    End Function

    Private Function FindCase(ByVal d As Double) As Int32
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = LineInExecution + 1 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("case") Then
                If counter = 0 Then
                    ' ----------------------------------------------------------- Tokenize to array of keywords
                    Dim l() As String = RTB.Tokenize(RTBLines(i).Trim)
                    If l.Length > 1 AndAlso d = EvalDouble(l(1)) Then
                        Return i
                    End If
                End If
            ElseIf line.StartsWith("endselect") Then
                counter -= 1
            ElseIf line.StartsWith("select") Then
                counter += 1
            End If
        Next
        Return -1
    End Function

    Private Function FindCaseElse() As Int32
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = LineInExecution + 1 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line = "caseelse" Then
                If counter = 0 Then
                    Return i
                End If
                counter -= 1
            ElseIf line.StartsWith("select") Then
                counter += 1
            End If
        Next
        Return -1
    End Function

    Private Function FindEndselect() As Int32
        Dim counter As Int32 = 0
        Dim line As String
        For i As Int32 = LineInExecution + 1 To RTBLines.Length - 1
            line = RTBLines(i).Trim.ToLower
            If line.StartsWith("endselect") Then
                If counter = 0 Then
                    Return i
                End If
                counter -= 1
            ElseIf line.StartsWith("select") Then
                counter += 1
            End If
        Next
        Return -1
    End Function


    ' =============================================================================================
    '  Keyboard Keys Events
    ' =============================================================================================
    Private Structure KeyEvent
        Public KeyCode As Keys
        Public IsGosub As Boolean
        Public LabelText As String
    End Structure
    Private KeyEvents(-1) As KeyEvent
    Private Sub ClearKeyEvents()
        ReDim KeyEvents(-1)
    End Sub
    Private Sub SetKeyEvent(ByVal s1 As String, ByVal s2 As String, ByVal s3 As String)
        Dim k As Keys = GetKeyCode(s1)
        Dim ix As Int32 = -1
        ' -------------------------------------------- test if KeyCode already exists
        For i As Int32 = 0 To KeyEvents.Length - 1
            If k = KeyEvents(i).KeyCode Then
                ix = i
            End If
        Next
        ' -------------------------------------------- if not exists create a new place
        If ix < 0 Then
            ix = KeyEvents.Length
            ReDim Preserve KeyEvents(ix)
        End If
        ' -------------------------------------------- add the new KeyEvent
        With KeyEvents(ix)
            .KeyCode = k
            .IsGosub = s2.ToLower = "gosub"
            .LabelText = s3.ToLower
        End With
    End Sub
    Private Function GetKeyCode(ByVal str As String) As Keys
        Select Case str.ToLower
            Case "1" : Return Keys.D1
            Case "2" : Return Keys.D2
            Case "3" : Return Keys.D3
            Case "4" : Return Keys.D4
            Case "5" : Return Keys.D5
            Case "6" : Return Keys.D6
            Case "7" : Return Keys.D7
            Case "8" : Return Keys.D8
            Case "9" : Return Keys.D9
            Case "0" : Return Keys.D0
            Case "a" : Return Keys.A
            Case "b" : Return Keys.B
            Case "c" : Return Keys.C
            Case "d" : Return Keys.D
            Case "e" : Return Keys.E
            Case "f" : Return Keys.F
            Case "g" : Return Keys.G
            Case "h" : Return Keys.H
            Case "i" : Return Keys.I
            Case "j" : Return Keys.J
            Case "k" : Return Keys.K
            Case "l" : Return Keys.L
            Case "m" : Return Keys.M
            Case "n" : Return Keys.N
            Case "o" : Return Keys.O
            Case "p" : Return Keys.P
            Case "q" : Return Keys.Q
            Case "r" : Return Keys.R
            Case "s" : Return Keys.S
            Case "t" : Return Keys.T
            Case "u" : Return Keys.U
            Case "v" : Return Keys.V
            Case "w" : Return Keys.W
            Case "x" : Return Keys.X
            Case "y" : Return Keys.Y
            Case "z" : Return Keys.Z
            Case "f1" : Return Keys.F1
            Case "f2" : Return Keys.F2
            Case "f3" : Return Keys.F3
            Case "f4" : Return Keys.F4
            Case "f5" : Return Keys.F5
            Case "f6" : Return Keys.F6
            Case "f7" : Return Keys.F7
            Case "f8" : Return Keys.F8
            Case "f9" : Return Keys.F9
            Case "f10" : Return Keys.F10
            Case "f11" : Return Keys.F11
            Case "f12" : Return Keys.F12
            Case "left" : Return Keys.Left
            Case "right" : Return Keys.Right
            Case "up" : Return Keys.Up
            Case "down" : Return Keys.Down
            Case "space" : Return Keys.Space
            Case "esc" : Return Keys.Escape
            Case "pageup" : Return Keys.PageUp
            Case "pagedown" : Return Keys.PageDown
            Case "home" : Return Keys.Home
            Case "end" : Return Keys.End
        End Select
    End Function

    Private Sub ExecKeysEvent(ByVal keycode As Keys)
        For Each k As KeyEvent In KeyEvents
            If keycode = k.KeyCode Then
                Dim line As Int32 = FindLabel(k.LabelText)
                If line >= 0 Then
                    ExecutionThread_Stop()
                    If k.IsGosub And ExistsReturn() Then
                        ReturnStack.Push(LineInExecution)
                    End If
                    GotoLine = line
                    ExecutionThread_Start()
                End If
                Return
            End If
        Next
    End Sub

    ' =============================================================================================
    '  EXECUTION DELAY
    ' =============================================================================================
    Private InstructionsCounter As Int32 = 0
    Private InstructionsCounterMax As Int32
    Private ExecutionDelayMillisec As Int32
    Private Sub SetExecutionDelayParams(ByVal n As Int32)
        If n = 0 Then n = tkbar_Speed.Value
        If n > 9 Then n = 9
        Select Case n
            Case 1 : ExecutionDelayMillisec = 1000 : InstructionsCounterMax = 0
            Case 2 : ExecutionDelayMillisec = 500 : InstructionsCounterMax = 0
            Case 3 : ExecutionDelayMillisec = 200 : InstructionsCounterMax = 0
            Case 4 : ExecutionDelayMillisec = 100 : InstructionsCounterMax = 0
            Case 5 : ExecutionDelayMillisec = 50 : InstructionsCounterMax = 0
            Case 6 : ExecutionDelayMillisec = 10 : InstructionsCounterMax = 0
            Case 7 : ExecutionDelayMillisec = 1 : InstructionsCounterMax = 0
            Case 8 : ExecutionDelayMillisec = 1 : InstructionsCounterMax = 10
            Case 9 : ExecutionDelayMillisec = 1 : InstructionsCounterMax = 100
        End Select
    End Sub
    Private Sub ShowExecutionDelayText(ByVal n As Int32)
        Dim s As String = ""
        Select Case n
            Case 1 : s = "1 instructions per second - CPU usage very low"
            Case 2 : s = "2 instructions per second - CPU usage very low"
            Case 3 : s = "5 instructions per second - CPU usage very low"
            Case 4 : s = "10 instructions per second - CPU usage very low"
            Case 5 : s = "20 instructions per second - CPU usage very low"
            Case 6 : s = "100 instructions per second - CPU usage very low"
            Case 7 : s = "1000 instructions per second - 1 mS each instruction - CPU usage very low"
            Case 8 : s = "10 000 instructions per second - 100 uS each instruction - CPU usage about 1%"
            Case 9 : s = "100 000 instructions per second - 10 uS each instruction - CPU usage about 10%"
        End Select
        StatusLabel1.Text = s
    End Sub
    Private Sub ExecutionDelay_Variable()
        If SingleStep Then Return
        InstructionsCounter += 1
        If InstructionsCounter >= InstructionsCounterMax Then
            InstructionsCounter = 0
            Thread.Sleep(ExecutionDelayMillisec)
        End If
    End Sub
    Private Sub ExecutionDelay_Minimum()
        InstructionsCounter += 1
        If InstructionsCounter >= InstructionsCounterMax Then
            InstructionsCounter = 0
            Thread.Sleep(1)
        End If
    End Sub


    ' =============================================================================================
    '   TIMERS
    ' =============================================================================================
    Private Sub TimerSlow_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerSlow.Tick
        If Running Then
            ExecButtonsFromSlots()
        Else
            chk_Undo.Enabled = RTB.Editor_CanUndo
            chk_Redo.Enabled = RTB.Editor_CanRedo
        End If
    End Sub

    Private BlueLineOld As Int32 = -1
    Private Sub Timer_Fast_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerFast.Tick
        If Running Or BlueLineOld < 0 Then
            ' --------------------------------- Select all the line (if not changing line the time about 0.002 mS)
            If LineInExecution <> BlueLineOld Then
                BlueLineOld = LineInExecution
                ' ----------------------------- Scroll only if the Speed is less than 5
                If tkbar_Speed.Value < 5 Then
                    RTB.ScrollToCenterSelectedLine(LineInExecution)
                End If
                ' ----------------------------- Select the first part (no horizzontal scroll)
                SelectLineLimitedLength(LineInExecution)
            End If
        End If

        ' ------------------------------------- Flickering booster (to test ListViewFlickerFree)
        'If My.Computer.Keyboard.CapsLock Then
        '    Form_Debug.ListView1.BeginUpdate()
        '    Form_Debug.ListView1.EndUpdate()
        'End If
        ' -------------------------------------------------------------------------------------
    End Sub



    ' =============================================================================================
    '   EXECUTION THREAD
    ' =============================================================================================
    Private ExecutionThread As Thread
    Private TerminateThread As Boolean
    Sub ExecutionThread_Start()
        If ExecutionThread IsNot Nothing Then Return
        ExecutionThread = New Thread(AddressOf MainExecutionThread)
        ExecutionThread.Priority = System.Threading.ThreadPriority.AboveNormal
        TerminateThread = False
        ExecutionThread.Start()
    End Sub
    Sub ExecutionThread_Stop()
        If ExecutionThread Is Nothing Then Return

        ' --------------------------------- Old versione with thread abort 
        'ExecutionThread.Abort()
        'ExecutionThread.Join()
        ' --------------------------------- New versione with terminate thread
        TerminateThread = True
        ExecutionThread.Join(1000)
        If ExecutionThread.IsAlive Then ExecutionThread.Abort()

        ExecutionThread = Nothing
    End Sub
    Sub MainExecutionThread()
        If RTBLines Is Nothing Then Return
        If RTBLines.Length = 0 Then Return
        Do
            RTB_Exec()
        Loop Until TerminateThread
        TerminateThread = False
    End Sub


    ' =============================================================================================
    '  EXECUTION
    ' =============================================================================================
    Friend Running As Boolean
    Friend Debugging As Boolean

    Private SingleStep As Boolean
    Private GotoLine As Int32 = -1
    Private LineInExecution As Int32 = -1
    Private LineBeforeRun As Int32 = -1
    Private RTBLines() As String
    Private ReturnStack As Stack(Of Integer) = New Stack(Of Integer)
    'Private sw As Stopwatch = New Stopwatch ' speed tester

    Friend Sub RTB_Exec()
        '
        If Not Running Then Thread.Sleep(1) : Return
        '
        ' ----------------------------------------------------------------- GOTO LINE
        If GotoLine >= 0 Then
            LineInExecution = GotoLine
            GotoLine = -1
            SkipEmptyLines(LineInExecution)
        Else
            If LineInExecution > RTBLines.Length - 1 Then
                LineInExecution = 0
            End If
            If Debugging Then
                If RTBLines(LineInExecution).ToLower.Contains("breakpoint") Then
                    LineBeforeRun = -1
                    SelectLineLimitedLength_ThreadSafe(LineInExecution)
                    StopRunning_ThreadSafe()
                    Exit Sub
                End If
            End If
        End If
        '
        ' ----------------------------------------------------------------- EXEC THE LINE
        ExecTheLine(LineInExecution)

        ' ----------------------------------------------------------------- do not increment the line
        If TerminateThread Then Return
        '
        ' ----------------------------------------------------------------- NEXT LINE
        LineInExecution += 1
        SkipEmptyLines(LineInExecution)
        '
        ' ----------------------------------------------------------------- SINGLE STEP
        If SingleStep Then
            SingleStep = False
            Exit Sub
        End If
        '
        ' ----------------------------------------------------------------- WAIT THE EXECUTION DELAY
        ExecutionDelay_Variable()
        '
        ' ----------------------------------------------------------------- speed tester
        'Print_Message_ThreadSafe(sw.Elapsed.TotalMilliseconds.ToString)
        'sw.Reset()
        'sw.Start()
    End Sub

    Private Sub SkipEmptyLines(ByRef i As Int32)
        For j As Int32 = 0 To RTBLines.Length - 1
            If Not LineIsEmptyOrComment(i) Then Exit For
            i += 1
            If i > RTBLines.Length - 1 Then i = 0
        Next
    End Sub

    Private Function LineIsEmptyOrComment(ByVal index As Int32) As Boolean
        If index < 0 Then Return True
        If index >= RTBLines.Length Then Return True
        Dim l As String = RTBLines(index).Trim
        If l = "" Then Return True
        If l.StartsWith("'") AndAlso Not l.ToLower.Contains("breakpoint") Then Return True
        Return False
    End Function


    ' =============================================================================================
    '  EXEC THE LINE
    ' =============================================================================================
    Friend Sub ExecTheLine(ByVal PC As Int32, Optional ByVal line As String = "")
        ' ----------------------------------------------------------------- Tokenize to array of keywords
        Dim l() As String
        If line <> "" Then
            l = RTB.Tokenize(line.Trim)
        Else
            l = RTB.Tokenize(RTBLines(PC).Trim)
        End If
        ' ----------------------------------------------------------------- if empty line return
        If l.Length = 0 Then ExecutionDelay_Minimum() : Return
        '
        Select Case l.Length
            Case 1
                Select Case l(0).ToLower
                    Case "beep"
                        Beep_RepetitionLimited(100)
                    Case "else"
                        Dim n As Int32 = FindEndif()
                        If n >= 0 And n < RTBLines.Length Then
                            GotoLine = n
                            LineInExecution = n - 1
                        End If
                    Case "caseelse"
                        Dim n As Int32 = FindEndselect()
                        If n >= 0 And n < RTBLines.Length Then
                            GotoLine = n
                            LineInExecution = n
                        End If
                    Case "return"
                        If ReturnStack.Count > 0 Then
                            Dim n As Int32 = ReturnStack.Pop
                            If n >= 0 And n < RTBLines.Length Then
                                GotoLine = n
                                LineInExecution = n - 1
                            End If
                        Else
                            ' --------------------- if can not RETURN then exec a STOP
                            If SingleStep Then
                                LineInExecution -= 1
                            Else
                                Do : Thread.Sleep(100) : Loop Until TerminateThread
                            End If
                        End If
                    Case "stop"
                        If SingleStep Then
                            LineInExecution -= 1
                        Else
                            Do : Thread.Sleep(100) : Loop Until TerminateThread
                        End If
                    Case "end"
                        StopRunning_ThreadSafe()
                        LineInExecution -= 1
                End Select
            Case 2
                Select Case l(0).ToLower
                    Case "gosub"
                        Dim n As Int32 = FindLabel(l(1))
                        If n >= 0 And n < RTBLines.Length Then
                            ReturnStack.Push(PC + 1)
                            GotoLine = n
                            LineInExecution = n
                        End If
                    Case "goto"
                        Dim n As Int32 = FindLabel(l(1))
                        If n >= 0 And n < RTBLines.Length Then
                            GotoLine = n
                            LineInExecution = n
                        End If
                    Case "if"
                        If Not EvalBoolean(l(1)) Then
                            Dim n As Int32 = FindElseOrEndif()
                            If n >= 0 And n < RTBLines.Length Then
                                GotoLine = n + 1
                                LineInExecution = n
                            End If
                        End If
                    Case "select"
                        Dim d As Double = EvalDouble(l(1))
                        Dim n As Int32 = FindCase(d)
                        If n >= 0 And n < RTBLines.Length Then
                            GotoLine = n + 1
                            LineInExecution = n
                        Else
                            n = FindCaseElse()
                            If n >= 0 And n < RTBLines.Length Then
                                GotoLine = n + 1
                                LineInExecution = n
                            Else
                                n = FindEndselect()
                                If n >= 0 And n < RTBLines.Length Then
                                    GotoLine = n
                                    LineInExecution = n
                                End If
                            End If
                        End If
                    Case "case"
                        Dim n As Int32 = FindEndselect()
                        If n >= 0 And n < RTBLines.Length Then
                            GotoLine = n
                            LineInExecution = n
                        End If
                    Case "load"
                        If l(1).ToLower.Trim.StartsWith("slots") Then
                            Dim n() As Double = ExtractNumericParams(l(1), 3)
                            If n.Length = 2 Then
                                If n(0) < 0 Then n(0) = 0
                                If n(0) > 999 Then n(0) = 999
                                If n(1) < 0 Then n(1) = 0
                                If n(1) > 999 Then n(1) = 999
                                LoadSlots(CInt(n(0)), CInt(n(1)))
                            Else
                                LoadSlots(0, 999)
                            End If
                        Else
                            Select Case l(1).ToLower.Trim
                                Case "vars"
                                    LoadVars()
                                Case Else
                                    Load_Media_ThreadSafe(l(1).Trim)
                            End Select
                        End If
                    Case "print"
                        Print_Message_ThreadSafe(EvalString(l(1)))
                    Case "save"
                        Select Case l(1).ToLower
                            Case "slots"
                                SaveSlots()
                            Case "vars"
                                SaveVars()
                        End Select
                    Case "speed"
                        SetNewSpeed_ThreadSafe(EvalDouble(l(1)))
                    Case "wait"
                        If Not SingleStep Then
                            If IsValidBoolean(l(1)) Then
                                Do
                                    Thread.Sleep(10)
                                Loop Until EvalBoolean(l(1))
                            End If
                        End If
                    Case "window"
                        Select Case l(1).ToLower
                            Case "sizable"
                                SetViewMode_ThreadSafe(ViewModes.Sizable)
                            Case "maximized"
                                SetViewMode_ThreadSafe(ViewModes.Maximized)
                            Case "fullscreen"
                                SetViewMode_ThreadSafe(ViewModes.FullScreen)
                        End Select
                End Select
            Case 3
                Select Case l(0).ToLower
                    Case "wait"
                        If Not SingleStep Then
                            If l(1).ToLower = "seconds" Then Wait_Seconds(EvalDouble(l(2)))
                            If l(1).ToLower = "button" Then Wait_Button(l(2))
                        End If
                    Case "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9"
                        If l(1) = "=" Then
                            NumVar(RTB.VarNameToIndex(l(0))) = EvalDouble(l(2))
                        End If
                    Case "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9"
                        If l(1) = "=" Then
                            StrVar(RTB.VarNameToIndex(l(0))) = EvalString(l(2))
                        End If
                End Select
            Case 4
                Select Case l(0).ToLower
                    Case "button"
                        If l(2).ToLower = "slot" Then SetButtonSlot_ThreadSafe(Val_Int(l(1)), Val_Int(l(3)))
                        If l(2).ToLower = "text" Then SetButton_ThreadSafe(Val_Int(l(1)), l(3))
                    Case "key"
                        If RTB.IsValidKey(l(1).ToLower) Then
                            SetKeyEvent(l(1), l(2), l(3))
                        End If
                    Case "slot"
                        Select Case l(3)
                            Case "Reset"
                                Slots.WriteSlot(CInt(EvalDouble(l(1))), NAN_Reset)
                            Case "Sleep"
                                Slots.WriteSlot(CInt(EvalDouble(l(1))), NAN_Sleep)
                            Case Else
                                Slots.WriteSlot(CInt(EvalDouble(l(1))), CSng(EvalDouble(l(3))))
                        End Select
                    Case "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", _
                         "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9"
                        If l(1) = "=" Then
                            If l(2).ToLower = "input" Then
                                InputDialog_ThreadSafe(l(0), l(3))
                            End If
                        End If
                End Select
        End Select
    End Sub

End Class