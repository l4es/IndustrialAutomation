﻿
Partial Class Form1
    Inherits System.Windows.Forms.Form

    ' =============================================================================================
    '  DEBUG - SINGLE STEP and EXEC LINE
    ' ============================================================================================= 
    Friend Sub Debug_RunSingleStep(ByVal StartLine As Int32)
        LineBeforeRun = -1
        SaveProgram_IfChanged()
        If Running Then StopRunning(False)
        RTBLines = RTB.Lines
        ' ---------------------------------------------- skip empty lines
        If LineIsEmptyOrComment(StartLine) Then
            SkipEmptyLines(StartLine)
            SelectLineLimitedLength_ThreadSafe(StartLine)
            RTB.ShowLinesCount()
            Exit Sub
        End If
        ' ----------------------------------------------
        StatusLabel1.Text = " Executed line " + (StartLine + 1).ToString
        SingleStep = True
        Running = True
        GotoLine = StartLine
        LineInExecution = StartLine
        LineBeforeRun = -1
        BlueLineOld = -1
        RTB_Exec()
        ' ---------------------------------------------- 
        ' SelectLine before Running = false to avoid "ShowSuggestions"
        ' ---------------------------------------------- 
        RTB.ScrollToCenterSelectedLine(LineInExecution)
        SelectLineLimitedLength_ThreadSafe(LineInExecution)
        BlueLineOld = LineInExecution
        ' ---------------------------------------------- 
        Running = False
        ' ----------------------------------------------
        RTB.ShowLinesCount()
        Form_Debug.ShowWatches()
        SetVisibleButtons()
    End Sub

    Friend Sub Debug_ExecLine(ByVal Line As String)
        ' ---------------------------------------------- 
        RTBLines = RTB.Lines
        ' ---------------------------------------------- 
        Dim l() As String
        Line = Line.Replace("http:", "http_")
        Line = Line.Replace("https:", "https_")
        l = Line.Split(":"c)
        For i As Int32 = 0 To l.Length - 1
            Dim s As String = l(i).Trim
            ' ---------------------------------------------------- exclude invalid keywords
            If s.ToLower.StartsWith("return") Then Continue For
            If s.ToLower.StartsWith("stop") Then Continue For
            If s.ToLower.StartsWith("wait") Then Continue For
            ' ---------------------------------------------------- restore normal http:
            s = s.Replace("http_", "http:")
            s = s.Replace("https_", "https:")
            ExecTheLine(0, s)
        Next
        ' ----------------------------------------------
        If Not Running Then
            ' ------------------------------------------ show the line eventually selected
            SelectLineLimitedLength_ThreadSafe(LineInExecution)
            ' ------------------------------------------ and the other info
            RTB.ShowLinesCount()
            Form_Debug.ShowWatches()
            SetVisibleButtons()
        End If
    End Sub


    ' =============================================================================================
    '  START STOP RUNNING
    ' ============================================================================================= 
    Dim MyScrollData As SyntaxRichTextBox.ScrollData
    Friend Sub StartRunning(ByVal ResetAll As Boolean, ByVal StartLine As Int32)
        ' --------------------------------------------------------
        If ResetAll Then
            ClearKeyEvents()
            SetInitialButtonNames()
            ResetButtonSlots()
            ReturnStack.Clear()
            LineInExecution = -1
            LineBeforeRun = RTB.GetFirstSelectedLine
            RTB.SaveSelectionAndScroll(MyScrollData)
        Else
            LineBeforeRun = -1
        End If
        ' --------------------------------------------------------
        ExecutionThread_Stop()
        SaveProgram_IfChanged()
        SetExecutionDelayParams(tkbar_Speed.Value)
        RTBLines = RTB.Lines
        Running = True
        GotoLine = StartLine
        LineInExecution = StartLine
        BlueLineOld = -1
        SetStartTime()
        ExecutionThread_Start()
        ' --------------------------------------------------------
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        Form_Debug.chk_Run.Checked = False
        Form_Debug.SetRunButtonText()
        EventsAreEnabled = old
        Panel_EditCommands.Visible = True
        ' --------------------------------------------------------
        RTB.ContextMenuStrip = MenuStrip_Exit
        RTB.Height = GroupBox2.Height - RTB.Top - 30
        RTB.ReadOnly = True
        RTB.BackColor = Color_BackRunning
        ' --------------------------------------------------------
        GroupBox2.BackColor = Color_PanelRunning
        StatusStrip1.BackColor = Color_Form
        StatusLabel1.BackColor = Color.LightYellow
        StatusLabel1.Text = ""
        SetEditCommands_Invisible()
        chk_Run.Visible = True
        chk_Run.Text = "STOP"
        chk_Run.Checked = False
        EnableProgrammableButtons()
        UncheckProgrammableButtons()
        SetVisibleButtons()
    End Sub

    Friend Sub StopRunning(Optional ByVal RestoreScrollAndSelection As Boolean = True)
        Running = False
        ExecutionThread_Stop()
        BlueLineOld = -1
        ' --------------------------------------------------------
        'ShowTrayWnd()
        PreparePanelsForProgram()
        WMP.Visible = False
        WMP.URL = Nothing
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        Form_Debug.chk_Run.Checked = True
        Form_Debug.SetRunButtonText()
        EventsAreEnabled = old
        Form_Debug.ShowWatches()
        ' --------------------------------------------------------
        RTB.ContextMenuStrip = MenuStrip_Edit
        RTB.Height = GroupBox2.Height - RTB.Top - 30
        RTB.ReadOnly = False
        RTB.BackColor = Color_BackEditing
        RTB.Focus()
        RTB.ShowLinesCount()
        ' --------------------------------------------------------
        GroupBox2.BackColor = Color_PanelEditing
        StatusStrip1.BackColor = Color_Form
        StatusLabel1.BackColor = Color.LightYellow
        SetEditCommands_Visible()
        chk_Run.Visible = True
        chk_Run.Text = "RUN"
        chk_Run.Checked = True
        UncheckProgrammableButtons()
        SetVisibleButtons()
        ' --------------------------------------------------------
        If RestoreScrollAndSelection Then
            If LineBeforeRun >= 0 Then
                Dim oldEventsEnabled As Boolean = EventsAreEnabled
                EventsAreEnabled = False
                RTB.RestoreSelectionAndScroll(MyScrollData)
                LineInExecution = LineBeforeRun
                BlueLineOld = LineBeforeRun
                RTB.ShowLinesCount()
                EventsAreEnabled = oldEventsEnabled
            End If
        End If
    End Sub

    Friend Sub CopyRtbLines()
        RTBLines = RTB.Lines
    End Sub


    ' =============================================================================================
    '  VIEW MODES
    ' ============================================================================================= 
    Friend Enum ViewModes
        Sizable
        Maximized
        FullScreen
    End Enum
    Friend ViewMode As ViewModes = ViewModes.Sizable
    Friend WindowRectangle As Rectangle

    Private Sub SetEditCommands_Visible()
        chk_Undo.Visible = True
        chk_Redo.Visible = True
        chk_Load.Visible = True
        chk_Save.Visible = True
    End Sub
    Private Sub SetEditCommands_Invisible()
        chk_Undo.Visible = False
        chk_Redo.Visible = False
        chk_Load.Visible = False
        chk_Save.Visible = False
    End Sub

    Private Sub SetPanels_Visible()
        GroupBox1.Visible = True
        GroupBox2.Visible = True
        StatusLabel1.Visible = True
        StatusStrip1.Visible = True
        GroupBox2.Text = ""
    End Sub
    Private Sub SetPanels_Invisible()
        GroupBox1.Visible = False
        GroupBox2.Visible = False
        StatusLabel1.Visible = False
        StatusStrip1.Visible = False
    End Sub

    Private Sub SetButtonsParent(ByVal ctrl As Control)
        For i As Int32 = 1 To NBUTTONS
            GetButtonByIndex(i).Parent = ctrl
        Next
    End Sub

    Private Sub SetButtonsToFront()
        For i As Int32 = 1 To NBUTTONS
            GetButtonByIndex(i).BringToFront()
        Next
    End Sub

    Private Sub SetButtonsParent()
        If ViewMode = ViewModes.FullScreen Then
            Select Case PanelMode
                Case PanelModes.Program
                    SetButtonsParent(GroupBox1)
                Case PanelModes.Images
                    SetButtonsParent(PictureBox1)
                Case PanelModes.Video
                    SetButtonsParent(Me)
                Case PanelModes.Web
                    SetButtonsParent(GroupBox1)
            End Select
        Else
            SetButtonsParent(GroupBox1)
        End If
        SetButtonsToFront()
    End Sub


    Private Sub SetViewMode()
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False

        If WindowState = FormWindowState.Maximized Then
            WindowState = FormWindowState.Normal
        End If

        If WindowState = FormWindowState.Normal Then
            WindowRectangle = Me.Bounds
        End If

        Select Case ViewMode
            Case ViewModes.Sizable
                SetPanels_Visible()

                If Running Then
                    SetEditCommands_Invisible()
                    Panel_EditCommands.Visible = False
                Else
                    SetEditCommands_Visible()
                    Panel_EditCommands.Visible = True
                End If
                chk_Run.Visible = True

                Me.Bounds = WindowRectangle
                RTB.Height = GroupBox2.Height - RTB.Top - 30
                Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
                Me.WindowState = FormWindowState.Normal

                Me.TopMost = False
                'ShowTrayWnd()

            Case ViewModes.Maximized
                SetPanels_Visible()

                If Running Then
                    SetEditCommands_Invisible()
                    Panel_EditCommands.Visible = False
                Else
                    SetEditCommands_Visible()
                    Panel_EditCommands.Visible = True
                End If
                chk_Run.Visible = True

                RTB.Height = GroupBox2.Height - RTB.Top - 4
                Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
                Me.WindowState = FormWindowState.Maximized

                'Me.TopMost = True
                'Me.Hide()
                'Me.Show()
                'Me.Refresh()
                'ShowTrayWnd()

            Case ViewModes.FullScreen
                SetPanels_Invisible()

                If Running Then
                    SetEditCommands_Invisible()
                    Panel_EditCommands.Visible = False
                    chk_Run.Visible = False
                    Panel_EditCommands.Visible = False
                Else
                    SetEditCommands_Visible()
                    Panel_EditCommands.Visible = True
                    chk_Run.Visible = True
                    Panel_EditCommands.Visible = True
                End If

                RTB.Height = GroupBox2.Height - RTB.Top - 4
                Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                Me.WindowState = FormWindowState.Maximized

                Dim r As Rectangle = Screen.GetBounds(Me.Location)
                Me.Location = r.Location
                Me.Size = r.Size

                'Me.TopMost = True
                'Me.Hide()
                'Me.Show()
                'Me.Refresh()
                'HideTrayWnd()
        End Select

        Select Case PanelMode
            Case PanelModes.Program
                PreparePanelsForProgram()
                chk_Run.Visible = True
            Case PanelModes.Images
                SetPictureBoxPlacement()
            Case PanelModes.Video
                SetWmpPlacement()
            Case PanelModes.Web
                GroupBox1.Visible = True
                GroupBox2.Visible = True
                chk_Run.Visible = True
                WB.Visible = True
                WB.Show()
        End Select
        SetButtonsParent()

        Me.Focus()
        OldWindowState = Me.WindowState
        EventsAreEnabled = old
    End Sub

    Private Delegate Sub SetViewMode_Delegate(ByVal message As ViewModes)
    Private Sub SetViewMode_ThreadSafe(ByVal NewViewMode As ViewModes)
        If InvokeRequired Then
            BeginInvoke(New SetViewMode_Delegate(AddressOf SetViewMode_ThreadSafe), NewViewMode)
        Else
            If NewViewMode <> ViewMode Then
                ViewMode = NewViewMode
                Me.Opacity = 0
                SetViewMode()
                Me.Opacity = 100
                Save_INI()
            End If
        End If
    End Sub


    ' =============================================================================================
    '  PANELS - WMP - PictureBox1 - WB
    ' ============================================================================================= 
    Private Enum PanelModes
        Program
        Images
        Video
        Web
    End Enum
    Private PanelMode As PanelModes

    Private Sub PreparePanelsForProgram()
        PanelMode = PanelModes.Program
        GroupBox1.Visible = True
        GroupBox2.Visible = True
        StatusLabel1.Visible = True
        StatusStrip1.Visible = True
        GroupBox2.Text = "Program"
        GroupBox2.BackgroundImage = Nothing
        GroupBox2.BackColor = Color_PanelRunning
        WebBrowserStop()
        PictureBox1.Visible = False
        txt_WebBrowserURL.Visible = False
        btnGoBack.Visible = False
        btnGoForward.Visible = False
        WMP.Visible = False
        RTB.Visible = True
        StatusLabel1.Visible = True
        Panel_EditCommands.Visible = True
        Me.Focus() ' re-enable Form1_KeyDown
    End Sub
    ' ------------------------------------------------------------------------------------- PICTUREBOX
    Private Sub PreparePanelsForImages()
        If PanelMode = PanelModes.Images Then Return
        PanelMode = PanelModes.Images
        WebBrowserStop()
        txt_WebBrowserURL.Visible = False
        btnGoBack.Visible = False
        btnGoForward.Visible = False
        WMP.Visible = False
        RTB.Visible = False
        SetPictureBoxPlacement()
        PictureBox1.Visible = True
        If ViewMode <> ViewModes.FullScreen Then StatusLabel1.Visible = True
        Panel_EditCommands.Visible = False
        Me.Focus() ' re-enable Form1_KeyDown
    End Sub
    Private Sub SetPictureBoxPlacement()
        If ViewMode = ViewModes.FullScreen Then
            PictureBox1.Parent = Me
            PictureBox1.Left = 0
            PictureBox1.Top = 0
            PictureBox1.Width = Me.ClientSize.Width
            PictureBox1.Height = Me.ClientSize.Height
            SetPanels_Invisible()
        Else
            PictureBox1.Parent = GroupBox2
            PictureBox1.Left = 2
            PictureBox1.Top = 16
            PictureBox1.Width = GroupBox2.ClientSize.Width - 4
            If Running Then
                PictureBox1.Height = GroupBox2.ClientSize.Height - 16 - 4
            Else
                PictureBox1.Height = GroupBox2.ClientSize.Height - 16 - 40
            End If
            SetPanels_Visible()
        End If
    End Sub
    ' ------------------------------------------------------------------------------------- WMP
    Private Sub PreparePanelsForVideo()
        If PanelMode = PanelModes.Video Then Return
        PanelMode = PanelModes.Video
        GroupBox2.Text = ""
        GroupBox2.BackgroundImage = Nothing
        GroupBox2.BackColor = Color_PanelRunning
        txt_WebBrowserURL.Visible = False
        btnGoBack.Visible = False
        btnGoForward.Visible = False
        RTB.Visible = False
        PictureBox1.Visible = False
        WebBrowserStop()
        WMP.stretchToFit = True
        SetWmpPlacement()
        WMP.Visible = True
        If ViewMode <> ViewModes.FullScreen Then StatusLabel1.Visible = True
        Panel_EditCommands.Visible = False
        Me.Focus() ' re-enable Form1_KeyDown
    End Sub
    Private Sub SetWmpPlacement()
        If ViewMode = ViewModes.FullScreen Then
            WMP.Parent = Me
            WMP.Left = 0
            WMP.Top = 0
            WMP.Width = Me.ClientSize.Width
            WMP.Height = Me.ClientSize.Height
            SetPanels_Invisible()
        Else
            WMP.Parent = GroupBox2
            WMP.Left = 2
            WMP.Top = 16
            WMP.Width = GroupBox2.ClientSize.Width - 4
            If Running Then
                WMP.Height = GroupBox2.ClientSize.Height - 16 - 4
            Else
                WMP.Height = GroupBox2.ClientSize.Height - 16 - 40
            End If
            SetPanels_Visible()
        End If
    End Sub
    Private Sub WMP_WaitReady()
        Do
            Application.DoEvents()
        Loop Until WMP.playState <> WMPLib.WMPPlayState.wmppsTransitioning
    End Sub
    Private Sub WMP_Init()
        WMP.Dock = DockStyle.Fill
        WMP.stretchToFit = True
        WMP.uiMode = "none"
        WMP.Visible = False
        'WMP.enableContextMenu = False '  disable context menu
        WMP.Ctlenabled = False        '  disable click to stop and context menu
    End Sub
    ' ------------------------------------------------------------------------------------- WEB
    Private WithEvents WB As WebBrowser = New WebBrowser
    Private WebBrowserRunning As Boolean
    Private Sub PreparePanelsForWeb()
        If PanelMode = PanelModes.Web Then Return
        PanelMode = PanelModes.Web
        SetPanels_Visible()
        Panel_EditCommands.Visible = False
        GroupBox2.Text = ""
        GroupBox2.BackgroundImage = Nothing
        GroupBox2.BackColor = Color_PanelRunning
        WMP.URL = ""
        PictureBox1.Visible = False
        txt_WebBrowserURL.Left = 80
        txt_WebBrowserURL.Top = StatusLabel1.Top + 6
        txt_WebBrowserURL.Width = StatusLabel1.Width - 80
        txt_WebBrowserURL.Height = 31
        txt_WebBrowserURL.Visible = True
        btnGoBack.Visible = True
        btnGoForward.Visible = True
        StatusLabel1.Visible = False
        WMP.Visible = False
        RTB.Visible = False
        WB.Parent = GroupBox2
        WB.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        WB.Location = New Point(0, 0)
        WB.Size = GroupBox2.Size
        WB.ScriptErrorsSuppressed = True
        Me.Focus()                  ' re-enable Form1_KeyDown
    End Sub
    Private Sub WebBrowserStart(ByVal url As String)
        PreparePanelsForWeb()
        WB.Navigate(url)
        WB.Show()
        WebBrowserRunning = True
    End Sub
    Private Sub WebBrowserStop()
        If WB.Visible Then WB.Hide()
        If WB.Url IsNot Nothing Then
            WB.Stop()
            WB.Dispose()
            WB = New WebBrowser
        End If
        WebBrowserRunning = False
    End Sub
    Private Sub WebBrowser_NewWindow(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles WB.NewWindow
        e.Cancel = True
        If WB.Document IsNot Nothing Then
            Dim currentElement As HtmlElement = WB.Document.ActiveElement
            If currentElement IsNot Nothing Then
                Dim targetPath As String = currentElement.GetAttribute("href")
                WB.Navigate(targetPath)
            End If
        End If
    End Sub
    Private Sub WB_Navigated(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles WB.Navigated
        txt_WebBrowserURL.Text = WB.Url.ToString.TrimEnd(New Char() {"/"c})
    End Sub
    Private Sub btnGoBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoBack.Click
        If WB.CanGoBack Then
            WB.GoBack()
        End If
    End Sub
    Private Sub btnGoForward_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoForward.Click
        If WB.CanGoForward Then
            WB.GoForward()
        End If
    End Sub
    Private Sub CurrentBrowser_CanGoBackChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles WB.CanGoBackChanged
        btnGoBack.Enabled = WB.CanGoBack
    End Sub
    Private Sub CurrentBrowser_CanGoForwardChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles WB.CanGoForwardChanged
        btnGoForward.Enabled = WB.CanGoForward
    End Sub


    ' =============================================================================================
    '  PANELS EVENTS
    ' ============================================================================================= 
    Private Sub GroupBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox1.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            MenuStrip_Exit.Show(GroupBox1, New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub GroupBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox2.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            MenuStrip_Exit.Show(GroupBox2, New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            MenuStrip_Exit.Show(Me, New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            MenuStrip_Exit.Show(PictureBox1, New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub WMP_ClickEvent(ByVal sender As Object, ByVal e As AxWMPLib._WMPOCXEvents_ClickEvent) Handles WMP.ClickEvent
        If e.nButton = 2 Then
            MenuStrip_Exit.Show(WMP, New Point(e.fX, e.fY))
        End If
    End Sub

    Private Sub MenuStrip_Exit_ViewMode_Sizable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_ViewMode_Sizable.Click
        SetViewMode_ThreadSafe(ViewModes.Sizable)
    End Sub
    Private Sub MenuStrip_Exit_ViewMode_Maximized_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_ViewMode_Maximized.Click
        SetViewMode_ThreadSafe(ViewModes.Maximized)
    End Sub
    Private Sub MenuStrip_Exit_ViewMode_FullScreen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_ViewMode_FullScreen.Click
        SetViewMode_ThreadSafe(ViewModes.FullScreen)
    End Sub
    Private Sub MenuStrip_Exit_Debug_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_Debug.Click
        If Form_Debug.WindowState = FormWindowState.Minimized Then Form_Debug.WindowState = FormWindowState.Normal
        Form_Debug.Show()
    End Sub
    Private Sub MenuStrip_Exit_StopRunning_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_StopRunning.Click
        StopRunning()
    End Sub
    Private Sub MenuStrip_Exit_TerminateApp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_Exit_TerminateApp.Click
        CloseAll()
        Close()
    End Sub

    Private Sub MenuStrip_Exit_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MenuStrip_Exit.Opening
        MenuStrip_Exit_ViewMode_Sizable.Checked = ViewMode = ViewModes.Sizable
        MenuStrip_Exit_ViewMode_Maximized.Checked = ViewMode = ViewModes.Maximized
        MenuStrip_Exit_ViewMode_FullScreen.Checked = ViewMode = ViewModes.FullScreen
        MenuStrip_Exit_ViewMode_Sizable.Enabled = ViewMode <> ViewModes.Sizable
        MenuStrip_Exit_ViewMode_Maximized.Enabled = ViewMode <> ViewModes.Maximized
        MenuStrip_Exit_ViewMode_FullScreen.Enabled = ViewMode <> ViewModes.FullScreen
    End Sub

End Class
