﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Debug
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Debug))
        Me.chk_Run = New System.Windows.Forms.CheckBox
        Me.chk_AddWatch = New System.Windows.Forms.CheckBox
        Me.chk_Step = New System.Windows.Forms.CheckBox
        Me.MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip_DeleteSelectedWatches = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuStrip_DeleteAllWatches = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.chk_Exec = New System.Windows.Forms.CheckBox
        Me.txt_Exec = New System.Windows.Forms.TextBox
        Me.ListView1 = New Theremino_Automation.ListViewFlickerFree
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'chk_Run
        '
        Me.chk_Run.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Run.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.chk_Run.Checked = True
        Me.chk_Run.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_Run.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Run.FlatAppearance.BorderSize = 3
        Me.chk_Run.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Run.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Run.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Run.ForeColor = System.Drawing.Color.Black
        Me.chk_Run.Location = New System.Drawing.Point(10, 11)
        Me.chk_Run.Name = "chk_Run"
        Me.chk_Run.Size = New System.Drawing.Size(165, 30)
        Me.chk_Run.TabIndex = 13
        Me.chk_Run.Text = "RUN FROM CURSOR"
        Me.chk_Run.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Run.UseVisualStyleBackColor = False
        '
        'chk_AddWatch
        '
        Me.chk_AddWatch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chk_AddWatch.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_AddWatch.AutoCheck = False
        Me.chk_AddWatch.BackColor = System.Drawing.Color.OldLace
        Me.chk_AddWatch.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_AddWatch.FlatAppearance.BorderSize = 3
        Me.chk_AddWatch.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_AddWatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_AddWatch.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_AddWatch.ForeColor = System.Drawing.Color.Black
        Me.chk_AddWatch.Location = New System.Drawing.Point(314, 11)
        Me.chk_AddWatch.Name = "chk_AddWatch"
        Me.chk_AddWatch.Size = New System.Drawing.Size(109, 30)
        Me.chk_AddWatch.TabIndex = 11
        Me.chk_AddWatch.Text = "ADD WATCH"
        Me.chk_AddWatch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_AddWatch.UseVisualStyleBackColor = False
        '
        'chk_Step
        '
        Me.chk_Step.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Step.AutoCheck = False
        Me.chk_Step.BackColor = System.Drawing.Color.OldLace
        Me.chk_Step.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Step.FlatAppearance.BorderSize = 3
        Me.chk_Step.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Step.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Step.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Step.ForeColor = System.Drawing.Color.Black
        Me.chk_Step.Location = New System.Drawing.Point(182, 11)
        Me.chk_Step.Name = "chk_Step"
        Me.chk_Step.Size = New System.Drawing.Size(113, 30)
        Me.chk_Step.TabIndex = 12
        Me.chk_Step.Text = "SINGLE STEP"
        Me.chk_Step.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Step.UseVisualStyleBackColor = False
        '
        'MenuStrip
        '
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuStrip_DeleteSelectedWatches, Me.ToolStripSeparator6, Me.MenuStrip_DeleteAllWatches})
        Me.MenuStrip.Name = "ContextMenuStrip1"
        Me.MenuStrip.Size = New System.Drawing.Size(335, 70)
        '
        'MenuStrip_DeleteSelectedWatches
        '
        Me.MenuStrip_DeleteSelectedWatches.Image = CType(resources.GetObject("MenuStrip_DeleteSelectedWatches.Image"), System.Drawing.Image)
        Me.MenuStrip_DeleteSelectedWatches.Name = "MenuStrip_DeleteSelectedWatches"
        Me.MenuStrip_DeleteSelectedWatches.Size = New System.Drawing.Size(334, 30)
        Me.MenuStrip_DeleteSelectedWatches.Text = "Delete selected watches (DEL)"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(331, 6)
        '
        'MenuStrip_DeleteAllWatches
        '
        Me.MenuStrip_DeleteAllWatches.Image = CType(resources.GetObject("MenuStrip_DeleteAllWatches.Image"), System.Drawing.Image)
        Me.MenuStrip_DeleteAllWatches.Name = "MenuStrip_DeleteAllWatches"
        Me.MenuStrip_DeleteAllWatches.Size = New System.Drawing.Size(334, 30)
        Me.MenuStrip_DeleteAllWatches.Text = "Delete all watches"
        '
        'Timer1
        '
        '
        'chk_Exec
        '
        Me.chk_Exec.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chk_Exec.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Exec.AutoCheck = False
        Me.chk_Exec.BackColor = System.Drawing.Color.OldLace
        Me.chk_Exec.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Exec.FlatAppearance.BorderSize = 3
        Me.chk_Exec.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Exec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Exec.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Exec.ForeColor = System.Drawing.Color.Black
        Me.chk_Exec.Location = New System.Drawing.Point(354, 165)
        Me.chk_Exec.Name = "chk_Exec"
        Me.chk_Exec.Size = New System.Drawing.Size(70, 30)
        Me.chk_Exec.TabIndex = 15
        Me.chk_Exec.Text = "EXEC"
        Me.chk_Exec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Exec.UseVisualStyleBackColor = False
        '
        'txt_Exec
        '
        Me.txt_Exec.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_Exec.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Exec.Location = New System.Drawing.Point(10, 168)
        Me.txt_Exec.Name = "txt_Exec"
        Me.txt_Exec.Size = New System.Drawing.Size(334, 26)
        Me.txt_Exec.TabIndex = 16
        '
        'ListView1
        '
        Me.ListView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ListView1.ContextMenuStrip = Me.MenuStrip
        Me.ListView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.ForeColor = System.Drawing.Color.Black
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(10, 52)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(414, 104)
        Me.ListView1.TabIndex = 14
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Form_Debug
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(434, 201)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.txt_Exec)
        Me.Controls.Add(Me.chk_Exec)
        Me.Controls.Add(Me.chk_Run)
        Me.Controls.Add(Me.chk_AddWatch)
        Me.Controls.Add(Me.chk_Step)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(450, 240)
        Me.Name = "Form_Debug"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Form_Debug"
        Me.MenuStrip.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chk_Run As System.Windows.Forms.CheckBox
    Friend WithEvents chk_AddWatch As System.Windows.Forms.CheckBox
    Friend WithEvents chk_Step As System.Windows.Forms.CheckBox
    Friend WithEvents ListView1 As ListViewFlickerFree
    Friend WithEvents MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MenuStrip_DeleteSelectedWatches As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip_DeleteAllWatches As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents chk_Exec As System.Windows.Forms.CheckBox
    Friend WithEvents txt_Exec As System.Windows.Forms.TextBox
End Class
