﻿Public Class Form_Debug

    Private Sub Form_Debug_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Text = AppTitleAndVersion("") + " - Debug"
        ListView_Init()
        Timer1.Interval = 100
        Timer1.Enabled = True
        Me.DoubleBuffered = False
    End Sub

    Private Sub Form_Debug_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        ResizeListViewColumns()
    End Sub

    Private Sub Form_Debug_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        e.Cancel = True
    End Sub

    Private Sub Form_Debug_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        Form1.Debugging = Me.Visible
    End Sub

    Private Sub Form_Debug_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Form_Debug_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        ResizeListViewColumns()
        Form1.Debugging = Me.WindowState <> FormWindowState.Minimized
    End Sub

    ' ------------------------------------------------------------------
    '  Call this function from Form.Resize (not from ListView.resize)
    '  (otherwise the listview scroll produces problems)
    ' ------------------------------------------------------------------
    Friend Sub ResizeListViewColumns()
        With ListView1
            Dim w As Int32 = .Width - 6
            If IsVerticalScrollBarVisible(ListView1) Then
                w = w - SystemInformation.VerticalScrollBarWidth
            End If
            Dim old As Boolean = EventsAreEnabled
            EventsAreEnabled = False
            w = w - .Columns(2).Width
            .Columns(0).Width = CInt(w * 0.5)
            .Columns(1).Width = CInt(w * 0.5)
            EventsAreEnabled = old
        End With
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not Me.Visible Then Return
        If Me.WindowState = FormWindowState.Minimized Then Return
        ShowWatches(True)
    End Sub

    Private Function IsVerticalScrollBarVisible(ByVal lv As ListView) As Boolean
        Return (lv.Width - lv.ClientSize.Width) > 10
    End Function


    ' ===================================================================================
    '   BUTTONS
    ' ===================================================================================
    Private Sub chk_Run_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_Run.CheckedChanged
        If Not EventsAreEnabled Then Return
        If chk_Run.Checked Then
            Form1.StopRunning(False)
        Else
            Dim line As Int32 = Form1.RTB.GetLineFromCharIndex(Form1.RTB.SelectionStart)
            Form1.StartRunning(False, line)
        End If
        SetRunButtonText()
    End Sub

    Friend Sub SetRunButtonText()
        If chk_Run.Checked Then
            chk_Run.Text = "RUN FROM CURSOR"
        Else
            chk_Run.Text = "STOP"
        End If
    End Sub

    Private Sub chk_Step_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Step.Click
        Dim line As Int32 = Form1.RTB.GetLineFromCharIndex(Form1.RTB.SelectionStart)
        Form1.Debug_RunSingleStep(line)
    End Sub

    Private Sub chk_AddWatch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_AddWatch.Click
        Dim s As String = Form1.RTB.SelectedText.Trim
        'If s = "" Then return
        If s = "" Then s = "New watch"
        AddWatchLine(s)
        ListView1.SelectedIndices.Clear()
        ListView1.Items(ListView1.Items.Count - 1).Selected = True
        ListView1.EnsureVisible(ListView1.Items.Count - 1)
        ListView1.Focus()
        Save_Program(ProgramFile_PathAndName)
    End Sub

    ' ===================================================================================
    '   EXEC LINE
    ' ===================================================================================
    Private Sub txt_Exec_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Exec.TextChanged
        If Not EventsAreEnabled Then Return
        ' ----------------------------------------------------- replace keywords
        TxtExecReplaceKeywords()
        ' ----------------------------------------------------- show suggestions 
        TxtExecShowSuggestions()
    End Sub

    Private Sub txt_Exec_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_Exec.MouseClick
        ' ----------------------------------------------------- show suggestions 
        TxtExecShowSuggestions()
    End Sub

    Private Sub txt_Exec_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_Exec.KeyUp
        ' ----------------------------------------------------- show suggestions 
        TxtExecShowSuggestions()
    End Sub

    Private Sub TxtExecReplaceKeywords()
        If Not EventsAreEnabled Then Return
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        Form1.RTB.TextModified = True
        Dim oldselectionstart As Int32 = txt_Exec.SelectionStart
        Dim l() As String = txt_Exec.Text.Split(":"c)
        For i As Int32 = 0 To l.Length - 1
            Dim s1 As String = l(i).Trim
            Dim s2 As String = s1
            Form1.RTB.ReplaceKeywords(-1, s2)
            If s1 <> "" Then
                txt_Exec.Text = txt_Exec.Text.Replace(s1, s2)
            End If
        Next
        txt_Exec.SelectionStart = oldselectionstart
        txt_Exec.Refresh()
        EventsAreEnabled = old
    End Sub

    Private Sub TxtExecShowSuggestions()
        ' --------------------------------------------------------- split instructions to array
        Dim s As String = txt_Exec.Text
        s = s.Replace("http:", "http_")
        s = s.Replace("https:", "https_")
        Dim l() As String = s.Split(":"c)
        ' ---------------------------------------------------------- find the index in the instructions array
        Dim SelectionIndex As Int32 = txt_Exec.SelectionStart
        Dim ArrayIndex As Int32 = 0
        For i As Int32 = 0 To l.Length - 1
            If SelectionIndex <= l(i).Length Then
                Exit For
            Else
                SelectionIndex -= l(i).Length + 1
                ArrayIndex += 1
            End If
        Next
        ' ---------------------------------------------------------- show suggestions
        Form1.RTB.ShowSuggestions(l(ArrayIndex), _
                                  0, _
                                  GetCompleteWord(txt_Exec.Text.Replace(":", " "), txt_Exec.SelectionStart))

        Dim s2 As String = Form1.StatusLabel1.Text
        If s2.StartsWith("ERROR") Then
            txt_Exec.BackColor = Color.FromArgb(255, 180, 170)
        ElseIf s2.StartsWith("WARNING") Then
            txt_Exec.BackColor = Color.FromArgb(255, 200, 100)
        Else
            txt_Exec.BackColor = Color.White
        End If
    End Sub

    Private Sub chk_Exec_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Exec.Click
        Form1.Debug_ExecLine(txt_Exec.Text)
    End Sub

    ' ===================================================================================
    '   MENU STRIP
    ' ===================================================================================
    Private Sub MenuStrip_DeleteSelectedWatches_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_DeleteSelectedWatches.Click
        DeleteSelectedWatches()
        Save_Program(ProgramFile_PathAndName)
    End Sub
    Private Sub MenuStrip_DeleteAllWatches_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuStrip_DeleteAllWatches.Click
        DeleteAllWatches()
        Save_Program(ProgramFile_PathAndName)
    End Sub


    ' ===================================================================================
    '  LIST VIEW INIT
    ' ===================================================================================
    Private Sub ListView_Init()
        With ListView1
            .OwnerDraw = True
            .GridLines = True
            .FullRowSelect = True
            .LabelEdit = True
            '
            .View = View.Details
            .HideSelection = False
            .AllowColumnReorder = False
            .CheckBoxes = False
            .Sorting = SortOrder.None
            .BringToFront()
            '
            ' ----------------------------------------------------------------- column headers
            '.Header_BackColor1 = Color.FromArgb(255, 255, 200)
            '.Header_BackColor2 = Color.FromArgb(200, 200, 200)
            .Header_ForeColor = Color.FromArgb(20, 20, 20)
            .Header_ShadowColor = Color.FromArgb(255, 255, 200)
            .Header_Font = New Font("Microsoft Sans Serif", 11, FontStyle.Regular)
            '
            ' -----------------------------------------------------------------
            .Header_TextVerticalPosition = -1
            '.Header_TextAlignments = New StringAlignment() {StringAlignment.Near, _
            '                                                StringAlignment.Near, _
            '                                                StringAlignment.Near}
            .Clear()
            .Columns.Add(" Expression", 200, HorizontalAlignment.Left)
            .Columns.Add(" Value", 150, HorizontalAlignment.Left)
            .Columns.Add(" Type", 80, HorizontalAlignment.Left)
        End With
        ResizeListViewColumns()
    End Sub



    ' ===================================================================================
    '  LIST VIEW AFTER-LABEL-EDIT
    ' -----------------------------------------------------------------------------------
    '  When the "AfterLabelEdit" event is fired the label text is the OLD text
    '  The solution is to pospone the following functions using the "MethodInvoker"
    ' ===================================================================================
    Private Sub ListView1_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs) Handles ListView1.AfterLabelEdit
        ListView1.BeginInvoke(New MethodInvoker(AddressOf AfterLabelEdit_WithLabelReallyUpdated))
    End Sub
    Private Sub AfterLabelEdit_WithLabelReallyUpdated()
        If Not EventsAreEnabled Or Not Form1.Visible Then
            ' Here we detected that the application is closing
            ' and the Form1.RTB text is empty
            ' This "Return" ensures do not save an empty program 
            Return
        End If
        Form1.RTB.ReplaceKeywords(-1, ListView1.SelectedItems(0).Text)
        ShowWatches()
        Save_Program(ProgramFile_PathAndName)
    End Sub


    ' ===================================================================================
    '  DELETE WITH KEY DOWN
    ' ===================================================================================
    Private Sub ListView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView1.KeyDown
        If e.KeyCode = Keys.Delete Then
            DeleteSelectedWatches()
            Save_Program(ProgramFile_PathAndName)
        End If
    End Sub

    ' ===================================================================================
    '  BeginEdit by DoubleClick
    ' ===================================================================================
    'Private Sub ListView1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView1.MouseDoubleClick
    '    Dim CurrentItem As ListViewItem = ListView1.GetItemAt(e.X, e.Y)
    '    CurrentItem.BeginEdit()
    'End Sub
    Private Sub ListView1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView1.DoubleClick
        Dim i As Int32 = ListView1.SelectedIndices(0)
        If i < 0 Then Return
        ListView1.Items(i).BeginEdit()
    End Sub


    ' ===================================================================================
    '  WATCHES
    ' ===================================================================================
    Friend Sub ShowWatches(Optional ByVal fast As Boolean = False)
        For i As Int32 = 0 To ListView1.Items.Count - 1
            ' ---------------------------------------------------------- fast execution excluding error lines
            If fast Then
                If ListView1.Items(i).SubItems(1).Text = "ERROR" Then
                    Continue For
                End If
            End If
            ' ---------------------------------------------------------- 
            Dim WatchText As String = ListView1.Items(i).Text
            Dim Value As String
            Dim ValueType As String
            ' ---------------------------------------------------------- 
            If IsValidBoolean(WatchText) Then
                Value = EvalBoolean(WatchText).ToString
                ValueType = "Boolean"
            ElseIf IsValidString(WatchText) Then
                Value = EvalString(WatchText)
                ValueType = "String"
            ElseIf IsValidDouble(WatchText) Then
                Value = EvalDouble(WatchText).ToString(GCI)
                ValueType = "Number"
            Else
                Value = "ERROR"
                ValueType = "---"
            End If
            ' ---------------------------------------------------------- 
            If ListView1.Items(i).SubItems(1).Text <> Value Then
                ListView1.Items(i).SubItems(1).Text = Value
            End If
            If ListView1.Items(i).SubItems(2).Text <> ValueType Then
                ListView1.Items(i).SubItems(2).Text = ValueType
            End If
        Next
    End Sub

    Friend Function WatchesToString() As String
        Dim s As String = vbCrLf
        For i As Int32 = 0 To ListView1.Items.Count - 1
            s += "'WATCH " + ListView1.Items(i).Text + vbCrLf
        Next
        Dim s2 As String = txt_Exec.Text.Trim
        If s2 <> "" Then
            s += "'EXEC " + s2 + vbCrLf
        End If
        Return s
    End Function

    Private Sub DeleteSelectedWatches()
        If ListView1.Items.Count = 0 Then Return
        If ListView1.SelectedIndices.Count = 0 Then Return
        Dim selectedline As Int32 = ListView1.SelectedIndices(0)
        For Each i As ListViewItem In ListView1.SelectedItems
            ListView1.Items.Remove(i)
        Next
        If selectedline >= ListView1.Items.Count Then
            selectedline = ListView1.Items.Count - 1
        End If
        If selectedline >= 0 Then
            ListView1.Items(selectedline).Selected = True
        End If
    End Sub

    Friend Sub DeleteAllWatches()
        ListView1.Items.Clear()
    End Sub

    Friend Sub AddWatchLine(ByVal s As String)
        ListView1.Items.Add(New ListViewItem(New String() {s, "", ""}))
        ShowWatches()
    End Sub

End Class