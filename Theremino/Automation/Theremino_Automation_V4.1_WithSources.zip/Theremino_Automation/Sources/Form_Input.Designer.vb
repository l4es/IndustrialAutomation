﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Input
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Input))
        Me.chk_Ok = New System.Windows.Forms.CheckBox
        Me.txt_Input = New System.Windows.Forms.TextBox
        Me.chk_Cancel = New System.Windows.Forms.CheckBox
        Me.lbl_Prompt = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'chk_Ok
        '
        Me.chk_Ok.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chk_Ok.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Ok.AutoCheck = False
        Me.chk_Ok.BackColor = System.Drawing.Color.OldLace
        Me.chk_Ok.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Ok.FlatAppearance.BorderSize = 3
        Me.chk_Ok.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Ok.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Ok.ForeColor = System.Drawing.Color.Black
        Me.chk_Ok.Location = New System.Drawing.Point(189, 81)
        Me.chk_Ok.Name = "chk_Ok"
        Me.chk_Ok.Size = New System.Drawing.Size(90, 30)
        Me.chk_Ok.TabIndex = 15
        Me.chk_Ok.Text = "OK"
        Me.chk_Ok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Ok.UseVisualStyleBackColor = False
        '
        'txt_Input
        '
        Me.txt_Input.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_Input.BackColor = System.Drawing.Color.White
        Me.txt_Input.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Input.ForeColor = System.Drawing.Color.Black
        Me.txt_Input.Location = New System.Drawing.Point(12, 39)
        Me.txt_Input.Name = "txt_Input"
        Me.txt_Input.Size = New System.Drawing.Size(268, 26)
        Me.txt_Input.TabIndex = 16
        '
        'chk_Cancel
        '
        Me.chk_Cancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Cancel.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_Cancel.AutoCheck = False
        Me.chk_Cancel.BackColor = System.Drawing.Color.OldLace
        Me.chk_Cancel.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.chk_Cancel.FlatAppearance.BorderSize = 3
        Me.chk_Cancel.FlatAppearance.CheckedBackColor = System.Drawing.Color.Orange
        Me.chk_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_Cancel.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Cancel.ForeColor = System.Drawing.Color.Black
        Me.chk_Cancel.Location = New System.Drawing.Point(12, 81)
        Me.chk_Cancel.Name = "chk_Cancel"
        Me.chk_Cancel.Size = New System.Drawing.Size(90, 30)
        Me.chk_Cancel.TabIndex = 17
        Me.chk_Cancel.Text = "CANCEL"
        Me.chk_Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Cancel.UseVisualStyleBackColor = False
        '
        'lbl_Prompt
        '
        Me.lbl_Prompt.AutoSize = True
        Me.lbl_Prompt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Prompt.ForeColor = System.Drawing.Color.Black
        Me.lbl_Prompt.Location = New System.Drawing.Point(12, 10)
        Me.lbl_Prompt.Name = "lbl_Prompt"
        Me.lbl_Prompt.Size = New System.Drawing.Size(60, 20)
        Me.lbl_Prompt.TabIndex = 18
        Me.lbl_Prompt.Text = "Prompt"
        '
        'Form_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(291, 122)
        Me.ControlBox = False
        Me.Controls.Add(Me.lbl_Prompt)
        Me.Controls.Add(Me.chk_Cancel)
        Me.Controls.Add(Me.txt_Input)
        Me.Controls.Add(Me.chk_Ok)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(240, 100)
        Me.Name = "Form_Input"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Input from Automation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chk_Ok As System.Windows.Forms.CheckBox
    Friend WithEvents txt_Input As System.Windows.Forms.TextBox
    Friend WithEvents chk_Cancel As System.Windows.Forms.CheckBox
    Friend WithEvents lbl_Prompt As System.Windows.Forms.Label
End Class
