﻿Public Class Form_Input

    Friend ValidInput As Boolean = False
    Friend Prompt As String

    Private Sub Form_Input_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       
        'Timer1.Start()
    End Sub

    Private Sub Form_Input_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.TopMost = True
        Prompt = Prompt.Trim
        If Prompt = "" Then Prompt = "Input?"
        lbl_Prompt.Text = Prompt.Replace("""", "")
        txt_Input.Focus()
    End Sub

    Private Sub Form_Input_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Me.Hide()
        'e.Cancel = True
    End Sub

    Private Sub Form_Input_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub chk_Ok_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Ok.Click
        ValidInput = True
        Me.Close()
    End Sub

    Private Sub chk_Cancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_Cancel.Click
        ValidInput = False
        Me.Close()
    End Sub

End Class