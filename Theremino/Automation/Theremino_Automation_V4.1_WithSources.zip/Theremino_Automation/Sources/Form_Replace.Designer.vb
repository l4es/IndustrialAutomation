﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Replace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chk_MatchCase = New System.Windows.Forms.CheckBox
        Me.txtReplace = New System.Windows.Forms.TextBox
        Me.lblReplace = New System.Windows.Forms.Label
        Me.txtFind = New System.Windows.Forms.TextBox
        Me.lblFindWhat = New System.Windows.Forms.Label
        Me.cmdClose = New System.Windows.Forms.Button
        Me.cmdReplaceAll = New System.Windows.Forms.Button
        Me.cmdReplace = New System.Windows.Forms.Button
        Me.cmdFind = New System.Windows.Forms.Button
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.chkOnlyInSelection = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'chk_MatchCase
        '
        Me.chk_MatchCase.AutoSize = True
        Me.chk_MatchCase.Location = New System.Drawing.Point(12, 98)
        Me.chk_MatchCase.Name = "chk_MatchCase"
        Me.chk_MatchCase.Size = New System.Drawing.Size(82, 17)
        Me.chk_MatchCase.TabIndex = 7
        Me.chk_MatchCase.Text = "Match &case"
        '
        'txtReplace
        '
        Me.txtReplace.Location = New System.Drawing.Point(90, 35)
        Me.txtReplace.Name = "txtReplace"
        Me.txtReplace.Size = New System.Drawing.Size(170, 20)
        Me.txtReplace.TabIndex = 6
        '
        'lblReplace
        '
        Me.lblReplace.AutoSize = True
        Me.lblReplace.Location = New System.Drawing.Point(12, 38)
        Me.lblReplace.Name = "lblReplace"
        Me.lblReplace.Size = New System.Drawing.Size(72, 13)
        Me.lblReplace.TabIndex = 6
        Me.lblReplace.Text = "Re&place with:"
        '
        'txtFind
        '
        Me.txtFind.Location = New System.Drawing.Point(90, 9)
        Me.txtFind.Name = "txtFind"
        Me.txtFind.Size = New System.Drawing.Size(170, 20)
        Me.txtFind.TabIndex = 5
        '
        'lblFindWhat
        '
        Me.lblFindWhat.AutoSize = True
        Me.lblFindWhat.Location = New System.Drawing.Point(12, 9)
        Me.lblFindWhat.Name = "lblFindWhat"
        Me.lblFindWhat.Size = New System.Drawing.Size(56, 13)
        Me.lblFindWhat.TabIndex = 4
        Me.lblFindWhat.Text = "Fi&nd what:"
        '
        'cmdClose
        '
        Me.cmdClose.Location = New System.Drawing.Point(268, 94)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(75, 23)
        Me.cmdClose.TabIndex = 11
        Me.cmdClose.Text = "Close"
        '
        'cmdReplaceAll
        '
        Me.cmdReplaceAll.Enabled = False
        Me.cmdReplaceAll.Location = New System.Drawing.Point(268, 60)
        Me.cmdReplaceAll.Name = "cmdReplaceAll"
        Me.cmdReplaceAll.Size = New System.Drawing.Size(75, 23)
        Me.cmdReplaceAll.TabIndex = 10
        Me.cmdReplaceAll.Text = "Replace &All"
        '
        'cmdReplace
        '
        Me.cmdReplace.Enabled = False
        Me.cmdReplace.Location = New System.Drawing.Point(268, 33)
        Me.cmdReplace.Name = "cmdReplace"
        Me.cmdReplace.Size = New System.Drawing.Size(75, 23)
        Me.cmdReplace.TabIndex = 9
        Me.cmdReplace.Text = "&Replace"
        '
        'cmdFind
        '
        Me.cmdFind.Enabled = False
        Me.cmdFind.Location = New System.Drawing.Point(268, 6)
        Me.cmdFind.Name = "cmdFind"
        Me.cmdFind.Size = New System.Drawing.Size(75, 23)
        Me.cmdFind.TabIndex = 8
        Me.cmdFind.Text = "&Find Next"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(12, 75)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(83, 17)
        Me.CheckBox1.TabIndex = 12
        Me.CheckBox1.Text = "Whole word"
        '
        'chkOnlyInSelection
        '
        Me.chkOnlyInSelection.AutoSize = True
        Me.chkOnlyInSelection.Location = New System.Drawing.Point(129, 97)
        Me.chkOnlyInSelection.Name = "chkOnlyInSelection"
        Me.chkOnlyInSelection.Size = New System.Drawing.Size(103, 17)
        Me.chkOnlyInSelection.TabIndex = 13
        Me.chkOnlyInSelection.Text = "Only in selection"
        '
        'Form_Replace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(352, 126)
        Me.Controls.Add(Me.chkOnlyInSelection)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.chk_MatchCase)
        Me.Controls.Add(Me.txtReplace)
        Me.Controls.Add(Me.lblFindWhat)
        Me.Controls.Add(Me.lblReplace)
        Me.Controls.Add(Me.txtFind)
        Me.Controls.Add(Me.cmdFind)
        Me.Controls.Add(Me.cmdReplace)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdReplaceAll)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.KeyPreview = True
        Me.Name = "Form_Replace"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Find and Replace"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chk_MatchCase As System.Windows.Forms.CheckBox
    Friend WithEvents txtReplace As System.Windows.Forms.TextBox
    Friend WithEvents lblReplace As System.Windows.Forms.Label
    Friend WithEvents txtFind As System.Windows.Forms.TextBox
    Friend WithEvents lblFindWhat As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdReplaceAll As System.Windows.Forms.Button
    Friend WithEvents cmdReplace As System.Windows.Forms.Button
    Friend WithEvents cmdFind As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkOnlyInSelection As System.Windows.Forms.CheckBox
End Class
