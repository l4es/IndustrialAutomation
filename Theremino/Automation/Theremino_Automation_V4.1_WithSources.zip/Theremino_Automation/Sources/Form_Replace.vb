﻿Public Class Form_Replace

    Private Sub Form_Replace_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Me.Left = Cursor.Position.X
        Me.Top = Cursor.Position.Y
    End Sub

    Private Sub Form_Replace_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        e.Cancel = True
    End Sub

    Private Sub Form_Replace_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        If Me.Visible Then
            If m_CodeBox.SelectedText <> "" Then
                txtFind.Text = m_CodeBox.SelectedText
            End If
        End If
    End Sub

    Private Sub Form_Replace_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F3 Then
            FindTextDownward()
        End If
    End Sub


    '=====================================================================================
    ' VARIABLES
    '=====================================================================================
    Dim FindStartPosition As Integer
    Dim m_CodeBox As SyntaxRichTextBox
    Dim m_DialogType As DialogTypeValue = DialogTypeValue.Find

    Friend Enum DialogTypeValue
        Find = 0
        Replace = 1
    End Enum

    '=====================================================================================
    ' PROPERTIES
    '=====================================================================================
    Friend Property DialogType() As DialogTypeValue
        Get
            Return m_DialogType
        End Get
        Set(ByVal Value As DialogTypeValue)
            m_DialogType = Value
            UpdateForm()
        End Set
    End Property

    Public WriteOnly Property OwnerCodeBox() As SyntaxRichTextBox
        Set(ByVal Value As SyntaxRichTextBox)
            m_CodeBox = Value
        End Set
    End Property

    '=====================================================================================
    ' HELPER ROUTINES
    '=====================================================================================
    Private Sub UpdateForm()
        If m_DialogType = DialogTypeValue.Find Then
            Me.Text = " Find"
            lblReplace.Visible = False
            txtReplace.Visible = False
            cmdReplace.Visible = False
            cmdReplaceAll.Visible = False
        Else
            Me.Text = " Replace"
            lblReplace.Visible = True
            txtReplace.Visible = True
            cmdReplace.Visible = True
            cmdReplaceAll.Visible = True
        End If
    End Sub

    'Private Sub FindTextUpward()
    '    Dim FoundAt As Integer
    '    FindStartPosition = m_CodeBox.SelectionStart - 1
    '    If FindStartPosition = -1 Then
    '        'MessageBox.Show("No occurrences of """ & SearchText & """ were found", "Finished Find", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
    '        Beep()
    '        Exit Sub
    '    End If
    '    If chk_MatchCase.Checked Then
    '        FoundAt = InStrRev(m_CodeBox.Text, txtFind.Text, FindStartPosition, CompareMethod.Binary)
    '    Else
    '        FoundAt = InStrRev(m_CodeBox.Text, txtFind.Text, FindStartPosition, CompareMethod.Text)
    '    End If
    '    If FoundAt > 0 Then
    '        m_CodeBox.Select(FoundAt - 1, txtFind.Text.Length)
    '    Else
    '        'MessageBox.Show("No occurrences of """ & SearchText & """ were found", "Finished Find", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
    '        Beep()
    '    End If
    'End Sub

    Private Sub FindTextDownward()
        Dim FoundAt As Integer
        FindStartPosition = m_CodeBox.SelectionStart + 2
        If FindStartPosition >= m_CodeBox.Text.Length Then
            'MessageBox.Show("No occurrences of """ & SearchText & """ were found", "Finished Find", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
            Beep()
            Exit Sub
        End If
        If chk_MatchCase.Checked Then
            FoundAt = InStr(FindStartPosition, m_CodeBox.Text, txtFind.Text, CompareMethod.Binary)
        Else
            FoundAt = InStr(FindStartPosition, m_CodeBox.Text, txtFind.Text, CompareMethod.Text)
        End If
        If FoundAt > 0 Then
            m_CodeBox.Select(FoundAt - 1, txtFind.Text.Length)
        Else
            'MessageBox.Show("No occurrences of """ & SearchText & """ were found", "Finished Find", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
            Beep()
            m_CodeBox.Select(0, 0)
        End If
    End Sub

    '=====================================================================================
    ' EVENTS
    '=====================================================================================
    Private Sub cmdFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFind.Click
        'If optDown.Checked = True Then
        FindTextDownward()
        'Else
        'FindTextUpward()
        'End If
    End Sub

    Private Sub cmdReplace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplace.Click
        Dim StartAt As Integer = m_CodeBox.SelectionStart
        If m_CodeBox.SelectedText = "" Then Return
        m_CodeBox.SelectedText = Replace(m_CodeBox.SelectedText, txtFind.Text, txtReplace.Text, , , GetCompareMethod)

        Form1.RTB.PaintEventEnabled = False
        Form1.RTB.ColorAllOrVisibleLines()
        Form1.RTB.PaintEventEnabled = True

        m_CodeBox.Select(StartAt, txtReplace.Text.Length)
        m_CodeBox.Undo_AddEntry()
    End Sub

    Private Sub cmdReplaceAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplaceAll.Click
        Dim StartAt As Integer = m_CodeBox.SelectionStart

        If chkOnlyInSelection.Checked Then
            m_CodeBox.SelectedText = Replace(m_CodeBox.SelectedText, txtFind.Text, txtReplace.Text, , , GetCompareMethod)
        Else
            m_CodeBox.Text = Replace(m_CodeBox.Text, txtFind.Text, txtReplace.Text, , , GetCompareMethod)
        End If

        Form1.RTB.PaintEventEnabled = False
        Form1.RTB.ColorAllOrVisibleLines()
        Form1.RTB.PaintEventEnabled = True

        m_CodeBox.SelectionStart = StartAt
        m_CodeBox.Undo_AddEntry()
    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Me.Hide()
    End Sub

    Private Function GetCompareMethod() As CompareMethod
        If chk_MatchCase.Checked Then
            Return CompareMethod.Binary
        Else
            Return CompareMethod.Text
        End If
    End Function

    Private Sub txtFind_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtFind.KeyUp
        If e.KeyCode = Keys.Enter Then
            FindTextDownward()
        End If
    End Sub

    Private Sub txtFind_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFind.TextChanged
        Dim en As Boolean = txtFind.Text <> ""
        cmdFind.Enabled = en
        cmdReplace.Enabled = en
        cmdReplaceAll.Enabled = en
    End Sub

End Class