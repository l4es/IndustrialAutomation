﻿

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function


    ' =======================================================================================================
    '   Files
    ' =======================================================================================================
    Private Function FileIsInAppFolders(ByVal filename As String) As Boolean
        If filename.StartsWith(Application.StartupPath, StringComparison.InvariantCultureIgnoreCase) Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function
    Public Function GetPath(ByVal str As String) As String
        Try
            Return IO.Path.GetDirectoryName(str) & "\"
        Catch
            Return str
        End Try
    End Function

    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Combo functions
    ' ================================================================================================
    Friend Sub Combo_InitFromEnum(ByVal combo As ComboBox, ByVal enumType As Type) ' use GeType(enum)
        For Each s As String In [Enum].GetNames(enumType)
            combo.Items.Add(s)
        Next
    End Sub


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Friend Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Friend Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Friend Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Strings.Left(s, i - 1).Trim
            s = Mid(s, i + 1).Trim
        Else
            ExtractParamName = s.Trim
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub Save_INI()
        '
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            ' ------------------------------------------------------------------------------
            r = GetFormRectangle(Form_Debug)
            f.WriteLine(TabString("Form_Debug_Top", r.Top))
            f.WriteLine(TabString("Form_Debug_Left", r.Left))
            f.WriteLine(TabString("Form_Debug_Width", r.Width))
            f.WriteLine(TabString("Form_Debug_Height", r.Height))
            f.WriteLine(TabString("Form_Debug_WindowState", Form_Debug.WindowState))
            f.WriteLine(TabString("Form_Debug_Visible", Form_Debug.Visible))
            ' ------------------------------------------------------------------------------
            f.WriteLine(TabString("ViewMode", Form1.ViewMode.ToString))
            f.WriteLine(TabString("WindowRectangle", RectangleToString(Form1.WindowRectangle)))
            f.WriteLine(TabString("ProgramFile", ProgramFile_PathAndName))
            ' ------------------------------------------------------------------------------
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Params"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("Speed", Form1.tkbar_Speed.Value))
            f.WriteLine(TabString("Zoom", Form1.tkbar_Zoom.Value))
            f.WriteLine(TabString("Running", Form1.Running.ToString))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        If My.Computer.FileSystem.FileExists(iniFileName) Then

            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = Val_Int(l)
                    Case "Form1_Left" : Form1.Left = Val_Int(l)
                    Case "Form1_Width" : Form1.Width = Val_Int(l)
                    Case "Form1_Height" : Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : Form1.WindowState = CType((Val(l)), FormWindowState)
                        ' ---------------------------------------------------------------
                    Case "Form_Debug_Top" : Form_Debug.Top = Val_Int(l)
                    Case "Form_Debug_Left" : Form_Debug.Left = Val_Int(l)
                    Case "Form_Debug_Width" : Form_Debug.Width = Val_Int(l)
                    Case "Form_Debug_Height" : Form_Debug.Height = Val_Int(l)
                    Case "Form_Debug_WindowState" : Form_Debug.WindowState = CType((Val(l)), FormWindowState)
                    Case "Form_Debug_Visible" : Form_Debug.Visible = l = "True"
                        ' ---------------------------------------------------------------
                    Case "ViewMode" : Form1.ViewMode = ViewModeFromString(l)
                    Case "WindowRectangle" : Form1.WindowRectangle = RectangleFromString(l)
                    Case "ProgramFile" : ProgramFile_PathAndName = l
                        ' ---------------------------------------------------------------
                    Case "Speed" : Form1.tkbar_Speed.Value = Val_Int(l)
                    Case "Zoom" : Form1.tkbar_Zoom.Value = Val_Int(l)
                    Case "Running" : Form1.Running = l = "True"
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
        LimitFormPosition(Form_Debug)
    End Sub

    Private Function RectangleToString(ByVal r As Rectangle) As String
        Return r.X.ToString + " " + r.Y.ToString + " " + r.Width.ToString + " " + r.Height.ToString
    End Function

    Private Function RectangleFromString(ByVal s As String) As Rectangle
        Dim r() As String = Split(s, " ")
        If r.Length = 4 Then
            Return New Rectangle(Val_Int(r(0)), Val_Int(r(1)), Val_Int(r(2)), Val_Int(r(3)))
        End If
    End Function

    Private Function ViewModeFromString(ByVal s As String) As Form1.ViewModes
        Select Case s.ToLower
            Case "sizable" : Return Form1.ViewModes.Sizable
            Case "maximized" : Return Form1.ViewModes.Maximized
            Case "fullscreen" : Return Form1.ViewModes.FullScreen
            Case Else : Return Form1.ViewModes.Sizable
        End Select
    End Function

    ' ==================================================================================================
    '  SAVE LOAD -- SLOTS  (Save time = 2 mS / Load time = 500 uS)
    ' ==================================================================================================
    Private SlotsFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\_Slots.txt")
    Friend Sub SaveSlots()
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(SlotsFileName)
            For i As Int32 = 0 To 999
                f.WriteLine(Slots.ReadSlot(i).ToString(GCI))
            Next
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub
    Friend Sub LoadSlots(ByVal FirstSlot As Int32, ByVal LastSlot As Int32)
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        If My.Computer.FileSystem.FileExists(SlotsFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(SlotsFileName)
            Dim l As String
            Dim i As Int32 = 0
            Do While Not f.EndOfStream
                l = f.ReadLine()
                If i >= FirstSlot And i <= LastSlot Then
                    Slots.WriteSlot(i, CSng(Val(l)))
                End If
                i += 1
            Loop
            f.Close()
        End If
    End Sub

    ' ==================================================================================================
    '  SAVE LOAD -- VARS
    ' ==================================================================================================
    Private VarsFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\_Vars.txt")
    Friend Sub SaveVars()
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(VarsFileName)
            For i As Int32 = 1 To 9
                f.WriteLine(NumVar(i).ToString(GCI))
            Next
            For i As Int32 = 1 To 9
                f.WriteLine(StrVar(i))
            Next
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub
    Friend Sub LoadVars()
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        If My.Computer.FileSystem.FileExists(VarsFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(VarsFileName)
            For i As Int32 = 1 To 9
                If f.EndOfStream Then Exit For
                NumVar(i) = Val(f.ReadLine())
            Next
            For i As Int32 = 1 To 9
                If f.EndOfStream Then Exit For
                StrVar(i) = f.ReadLine()
            Next
            f.Close()
        End If
    End Sub

    ' ==================================================================================================
    '  SAVE LOAD -- PROGRAMS
    ' ==================================================================================================
    Friend ProgramFile_PathAndName As String = ""

    Friend Sub SaveProgram_IfChanged()
        If Form1.RTB.TextModified Then
            Save_Program(ProgramFile_PathAndName)
        End If
    End Sub

    Friend Sub Save_Program(Optional ByVal fileName As String = "")
        If fileName = "" Then
            SaveProgramDialog()
            Return
        End If
        Try
            Form1.RTB.SaveFile(fileName, RichTextBoxStreamType.PlainText)
            AppendWatches(fileName)
            ProgramFile_PathAndName = fileName
            Form1.ShowWindowTitle()
        Catch
        End Try
    End Sub

    Private Sub AppendWatches(ByVal fileName As String)
        Dim sw As IO.StreamWriter
        sw = My.Computer.FileSystem.OpenTextFileWriter(fileName, True)
        sw.Write(Form_Debug.WatchesToString)
        sw.Close()
    End Sub

    Friend Sub Load_Program(Optional ByVal fileName As String = "")
        ' -------------------------------------------------------------------------------
        SaveProgram_IfChanged()
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        If fileName = "" Then fileName = ProgramFile_PathAndName
        ' -------------------------------------------------------------------------------
        If My.Computer.FileSystem.FileExists(fileName) Then
            If Not FileIsInAppFolders(fileName) Then
                MsgBox("Warning can not run programs outside the application folders" + vbCrLf + vbCrLf + _
                       "The file will be copied in the ""Programs"" folder")
                ' -----------------------------------------------------------------------
                '  test the path and eventually copy it in the same subfolder of "programs"
                ' -----------------------------------------------------------------------
                Dim destname As String
                Dim i As Int32 = InStr(fileName, "Theremino_Automation\Programs\", CompareMethod.Text)
                If i > 0 Then
                    destname = Application.StartupPath + "\Programs\" + Mid(fileName, i + 30)
                Else
                    destname = Application.StartupPath + "\Programs\" + IO.Path.GetFileName(fileName)
                End If
                ' -----------------------------------------------------------------------
                IO.File.Copy(fileName, destname)
                fileName = destname
            End If
        Else
            fileName = FindFileInAppFolders(fileName)
        End If
        ' -------------------------------------------------------------------------------
        If My.Computer.FileSystem.FileExists(fileName) Then

            Form1.StatusLabel1.Text = ""
            Form1.RTB.Text = vbCrLf + vbCrLf + "    ""LOADING PROGRAM - PLEASE WAIT"""
            Form1.Refresh()

            Dim old As Boolean = EventsAreEnabled
            EventsAreEnabled = False
            Form1.RTB.Enabled = False
            Form1.RTB.PaintEventEnabled = False

            ' ------------------------------------- load the file
            Form1.RTB.LoadFileTrimmed(fileName)

            Form1.RTB.ExtractWatches()
            Form1.RTB.DeleteFinalEmptyLines()
            ProgramFile_PathAndName = fileName

            Form1.ApplyEditorProps(True)

            Form1.RTB.ColorAllOrVisibleLines()

            Form1.RTB.Visible = False
            Form1.RTB.TooLongToAutoindent = False
            Form1.RTB.AutoIndent()
            Form1.RTB.Visible = True

            Form1.RTB.Undo_Clear()
            Form1.RTB.ShowLinesCount()

            Form1.RTB.PaintEventEnabled = True
            Form1.RTB.Enabled = True
            EventsAreEnabled = old
            ProgramFile_PathAndName = fileName
            Form1.ShowWindowTitle()
            Form_Debug.ShowWatches()
            Form1.SetInitialButtonNames()

            Form1.StatusLabel1.Text = "Loaded program :  " + IO.Path.GetFileName(fileName)
        End If
    End Sub

    Private Function FindFileInAppFolders(ByVal fname As String) As String
        fname = IO.Path.GetFileName(fname)
        Dim FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim wildcards() As String = {"*.txt"}
        Dim s As String = Application.StartupPath & "\"
        FileNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchAllSubDirectories, wildcards)
        For Each str As String In FileNames
            If str.EndsWith(fname) Then
                Return str
            End If
        Next
        Return ""
    End Function

    ' ==================================================================================================
    '  SAVE LOAD -- PROGRAMS -- DIALOGS
    ' ==================================================================================================
    Friend Sub SaveProgramDialog()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.InitialDirectory = PrepareSaveLoadFolder()
        sfd.FileName = IO.Path.GetFileName(ProgramFile_PathAndName)
        'SFD.RestoreDirectory = False
        sfd.AutoUpgradeEnabled = True
        sfd.Title = "Save program file"
        sfd.ValidateNames = False
        sfd.DefaultExt = ".txt"
        sfd.AddExtension = True
        sfd.Filter = "All files (*.*)|*.*"
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Save_Program(sfd.FileName)
        End If
    End Sub

    Friend Sub LoadProgramDialog()
        'If Not Editor_OkToGo("File open") Then Exit Sub
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ofd.InitialDirectory = PrepareSaveLoadFolder()
        ofd.FileName = IO.Path.GetFileName(ProgramFile_PathAndName)
        'OFD.RestoreDirectory = True
        ofd.AutoUpgradeEnabled = True
        ofd.Title = "Load program file"
        ofd.ValidateNames = False
        ofd.Multiselect = True
        ofd.Filter = "All files (*.*)|*.*"
        ofd.DefaultExt = ".txt"
        'SendKeys.Send("{HOME}{END}^A") ' name visible and selected
        SendKeys.Send("{HOME}{END}")   ' name visible and unselected
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Load_Program(ofd.FileName)
        End If
    End Sub

    Private Function PrepareSaveLoadFolder() As String
        PrepareSaveLoadFolder = ""
        If My.Computer.FileSystem.FileExists(ProgramFile_PathAndName) Then
            PrepareSaveLoadFolder = GetPath(ProgramFile_PathAndName)
        End If
        If Not FolderExists(PrepareSaveLoadFolder) Or Not FileIsInAppFolders(PrepareSaveLoadFolder) Then
            PrepareSaveLoadFolder = Windows.Forms.Application.StartupPath & "\Programs"
        End If
        PrepareSaveLoadFolder = PlatformAdjustedFileName(PrepareSaveLoadFolder)
    End Function

    'Friend Function Editor_OkToGo(ByVal CaptionText As String) As Boolean
    '    If Form1.RTB.TextModified Then
    '        Dim r As MsgBoxResult = MsgBox("Save the file before ?", MsgBoxStyle.Question Or MsgBoxStyle.YesNoCancel, CaptionText)
    '        If r = MsgBoxResult.Yes Then
    '            Save_Program()
    '            Return True
    '        End If
    '        If r = MsgBoxResult.No Then
    '            Return True
    '        End If
    '        Return False
    '    Else
    '        Return True
    '    End If
    'End Function

End Module
