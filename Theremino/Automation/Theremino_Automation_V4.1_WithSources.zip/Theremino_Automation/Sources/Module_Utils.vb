﻿Module Module_Utils

    Friend GCI As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

    Friend StartTime As Date = Now()
    Friend Sub SetStartTime()
        StartTime = Now()
    End Sub

    ' =======================================================================================
    '  VARS
    ' =======================================================================================
    Friend NumVar(9) As Double
    Friend StrVar() As String = {"", "", "", "", "", "", "", "", "", ""}

    Friend Sub GetVariable(ByVal name As String, ByRef value As Object)
        Select Case name.ToLower
            Case "v1" : value = NumVar(1)
            Case "v2" : value = NumVar(2)
            Case "v3" : value = NumVar(3)
            Case "v4" : value = NumVar(4)
            Case "v5" : value = NumVar(5)
            Case "v6" : value = NumVar(6)
            Case "v7" : value = NumVar(7)
            Case "v8" : value = NumVar(8)
            Case "v9" : value = NumVar(9)

            Case "s1" : value = StrVar(1)
            Case "s2" : value = StrVar(2)
            Case "s3" : value = StrVar(3)
            Case "s4" : value = StrVar(4)
            Case "s5" : value = StrVar(5)
            Case "s6" : value = StrVar(6)
            Case "s7" : value = StrVar(7)
            Case "s8" : value = StrVar(8)
            Case "s9" : value = StrVar(9)
        End Select
    End Sub

    Friend Sub SetVariable(ByVal name As String, ByVal value As String)
        Select Case name.ToLower
            Case "v1" : NumVar(1) = Val(value)
            Case "v2" : NumVar(2) = Val(value)
            Case "v3" : NumVar(3) = Val(value)
            Case "v4" : NumVar(4) = Val(value)
            Case "v5" : NumVar(5) = Val(value)
            Case "v6" : NumVar(6) = Val(value)
            Case "v7" : NumVar(7) = Val(value)
            Case "v8" : NumVar(8) = Val(value)
            Case "v9" : NumVar(9) = Val(value)

            Case "s1" : StrVar(1) = value
            Case "s2" : StrVar(2) = value
            Case "s3" : StrVar(3) = value
            Case "s4" : StrVar(4) = value
            Case "s5" : StrVar(5) = value
            Case "s6" : StrVar(6) = value
            Case "s7" : StrVar(7) = value
            Case "s8" : StrVar(8) = value
            Case "s9" : StrVar(9) = value
        End Select
    End Sub

    Friend Sub ResetAllVars()
        For i As Int32 = 0 To 9
            NumVar(i) = 0
            StrVar(i) = ""
        Next
    End Sub

    Friend Sub Swap(Of T)(ByRef d1 As T, ByRef d2 As T)
        Dim d As T = d2
        d2 = d1
        d1 = d
    End Sub

    ' ----------------------------------------------------------------------------------
    '  Extract from "text" the complete word pointed by the "selectionIndex"
    ' ----------------------------------------------------------------------------------
    Friend Function GetCompleteWord(ByVal text As String, _
                                    ByVal selectionIndex As Int32) As String
        Dim start, length As Int32
        FindWordPointers(text, selectionIndex, start, length)
        Return text.Substring(start, length)
    End Function

    ' ----------------------------------------------------------------------------------
    '  Extract from "text" start and length of the word pointed by the "selectionIndex"
    ' ----------------------------------------------------------------------------------
    Friend Sub FindWordPointers(ByVal text As String, _
                                ByVal selectionIndex As Int32, _
                                ByRef start As Int32, _
                                ByRef lenght As Int32)
        Const separators As String = " " + vbCr + vbLf + vbTab
        Dim i1, i2 As Int32
        For i1 = selectionIndex To 1 Step -1
            If InStr(separators, text(i1 - 1)) > 0 Then
                Exit For
            End If
        Next
        For i2 = selectionIndex To text.Length - 1
            If InStr(separators, text(i2)) > 0 Then
                Exit For
            End If
        Next
        start = i1
        lenght = i2 - i1
    End Sub


    ' ----------------------------------------------------------------------------------
    '  Extract numeric params from a string
    '  Valid only if fields are not more than MaxFieldNumber 
    ' ----------------------------------------------------------------------------------
    Friend Function ExtractNumericParams(ByVal s As String, ByVal MaxFieldsNumber As Int32) As Double()
        Dim n(-1) As Double
        Dim sa As String() = s.Split(" "c)
        Dim paramsCount As Int32 = 0
        For i As Int32 = 0 To sa.Length - 1
            If sa(i) <> "" Then
                If IsValidDouble(sa(i)) Then
                    ReDim Preserve n(n.Length)
                    n(n.Length - 1) = EvalDouble(sa(i))
                End If
                paramsCount += 1
            End If
        Next
        If paramsCount > MaxFieldsNumber Then ReDim n(-1)
        Return n
    End Function

    ' =======================================================================================
    '  TrayWnd
    ' =======================================================================================
    'Private Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As Int32
    'Private Declare Function ShowWindow Lib "user32" (ByVal hwnd As Int32, ByVal nCmdShow As Int32) As Int32
    'Private Const SW_HIDE As Int32 = 0
    'Private Const SW_SHOW As Int32 = 5

    'Friend Sub HideTrayWnd()
    '    Dim lngHandle As Int32
    '    lngHandle = FindWindow("Shell_TrayWnd", "")
    '    ShowWindow(lngHandle, SW_HIDE)
    'End Sub

    'Friend Sub ShowTrayWnd()
    '    Dim lngHandle As Int32
    '    lngHandle = FindWindow("Shell_TrayWnd", "")
    '    ShowWindow(lngHandle, SW_SHOW)
    'End Sub

    ' =============================================================================
    '   START PROCESS (IF NOT RUNNING) AND WAIT
    ' =============================================================================
    Friend Sub StartProcess_IfNotRunning_AndWait(ByVal filename As String)
        ' ------------------------------------------------------------------ Prepare path
        If Not IO.Path.IsPathRooted(filename) Then
            filename = Application.StartupPath + "\" + filename
        End If
        If Not IO.File.Exists(filename) Then Return
        ' ------------------------------------------------------------------ Test if already running
        If AppIsRunning(filename) Then Return
        ' ------------------------------------------------------------------ Start process
        Dim proc As Process
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(filename)
        psi.FileName = filename
        proc = Process.Start(psi)
        ' ------------------------------------------------------------------ Wait process really started 
        For i As Int32 = 1 To 100
            Threading.Thread.Sleep(100)
            proc.Refresh()
            If proc.MainWindowTitle.Contains(".") Then Exit For
        Next
        Threading.Thread.Sleep(500)
    End Sub

    ' =============================================================================
    '   App Is Running  (testing the complete path of the running app)
    ' =============================================================================
    Friend Function AppIsRunning(ByVal FileName As String) As Boolean
        ' ------------------------------------------------------------------ Normalize filename
        FileName = FileName.Replace("/", "\")
        ' ------------------------------------------------------------------ Compare with all processes
        Dim p() As System.Diagnostics.Process
        p = System.Diagnostics.Process.GetProcesses()
        For i As Int32 = 0 To p.Length - 1
            Try
                If p(i).MainWindowTitle = "" Then Continue For
                If p(i).MainModule.FileName = FileName Then Return True
            Catch
            End Try
        Next
        Return False
    End Function

End Module
