
' -----------------------------------------
' TODO - _MAIN TODO LIST
' -----------------------------------------
' All done

' -----------------------------------------
'  NEXT VERSION
' -----------------------------------------
' Sound <freq> <ms> <type Sin/Triangle/Square/Noise> 
' SendMail (example: when radioactivity is more than some limit)
'     Mail Host (SMTP)/ Mail User / Mail Pass
'     Mail Dest / Mail From / Mail Subject / Mail Body / Mail Send
' Fullscreen locked (exit only with shift-esc)

' -----------------------------------------
'  NOT IMPORTANT
' -----------------------------------------
' Buttons size and position
' Standard save/load
' First Breakpoint not stopping
' Named vars (Dim name As Number / Dim name As String)

' -----------------------------------------
' to think - Immediate char and string arrays
' -----------------------------------------
' Private Keywords() As String = {"PI", "Int", "Beep", "Button", "Disabled")
' Dim trimchars() As Char = {"("c, ")"c}

' -----------------------------------------
' DONE 
' -----------------------------------------
' Run from Here
' Single step
' AutoIndent
' SaveSlots
' LoadSlots
' Test WAIT with EvalDouble
' Test "Wait Button" (ok if using a string)
' Print Strings
' V1toV9 in Math operations (eval)
' Gosub with stack
' Return
' ...
' If (V1 to V9 ) (> < <> =) (V1 to V9 / NUMBER)
' Else
' Endif 
' ...
' Trim
' Beep
' Button names and goto names
' Auto complete suggestions and keywords
' Print and remove all automatic print
' Speed
' V1 to V9
' Tab not making tab but calling indent
' CTRL-Z and CTRL-Y cursor
' Autocomplete
' Load FILENAME 
' Load PROGRAMNAME
' undo cursor position
' replace keywords not changing spaces
' indent and comment
' Cut, Copy and Paste on right mouse button. 
' Optimize rename keywords
' undo/redo
' Suggestions
' Colors
' Load Image name
' Load Program name
' Test "Wait Button"
' save/load program
' GCode senza riga vuota iniziale non parte
' GCode senza G00
' Start-bar buttons not visible

' -----------------------------------------
' DONE - Version 4.xx
' -----------------------------------------
' Aggiunti gli errori nelle espressioni di PRINT
' Aggiunto il load dei file da stringa (Load s1..s9)
' Aggiunti demo:"Demo-BM_Foundation1.txt" e "Demo-BM_Foundation2.txt"
' Aggiunto Select Case EndSelect
' Aggiunto Autoindent
' Aggiunte funzioni SQRT ABS SIGN
' Aggiunto END che termina l'esecuzione
' Aggiunti Alt-R e F5 per RUN
' Aggiunti Alt-E e SHIFT-ESC per STOP
' Aggiunti i menu sul tasto destro del mouse per Sizable/Maximized/FullScreen
' Migliorato di molto il WebBrowser interno, ora si pu� anche navigare con i link delle pagine
' Print EXPRESSION detects invalid Functions
' Aumentato a 300 il numero di linee colorabili
' Completate Window Sizable/Maximized/FullScreen
' Migliorato il controllo degli errori
' Aumentati Buttons a sei
' Aggiunto Load apps (ad esempio: Load SlotViewer.exe)
' Stop lascia lo scroll dove si trova e non lo porta a inizio pagina
' Eliminato checkbox autoselect
' Migliorato autoindent
' Eliminate le maiuscole dalla linee speciali che contengono labels
' Load Application.exe lancia la app solo se non � gi� attiva 
'   (e non si fa ingannare da altre, controlla il path completo) 
' Load app attende che la app si apra e poi rid� il focus a Automation
' Keys 4 e 6 Gosub CloseGripper nel file "WinGoArm_Limits_Per_Livio__TEST"
' Form Debug / RunFromCursor / StepByStep
' Sizable/Maximized/FullScreen - Selezionato il menu attuale e disabilitati gli altri
' Il "numero di linea" viene aggiornato dopo SingleStep e RunStop
' Lista di Watches completata
' Disable and enable of Undo e Redo keys
' Redraw after minimize  
' Watches thread safe
' Timed Watch update
' Ora i Buttons sono otto
' Breakpoints con Speed = 9
' Aggiunta l'esecuzione immediata con il pulsante EXEC
' Esecuzione immediata anche di pi� istruzioni (separate da ":")
' Se Return se non trova dove tornare non prosegue ma agisce come uno Stop
' Eliminate linee vuote finali nel Load del file
' Save-Load files in external path
' Test-KeyboardKeys --- non torna a eseguire il key 1
' Gosub e Return a posto
' Undo e Redo scrollano per visualizzare il punto modificato
' Buttons abilitati anche durante lo STOP
' Eliminato checkbox autoindent
' Ridotte dimensioni minime della finestra

' STOP riposiziona il cursore dove era prima della esecuzione (a meno che si siano usate funzioni di debug)
' Maiuscole delle linee speciali che contengono labels
' Premendo Button o Keys eliminato autorepeat (ma se si preme pi� volte i Gosub si accumulano).
' Buttons completati e abilitati correttamente.
' Automatic casing also for debug window "Exec line" and "Watches"
' Complete keyword with CTRL-SPACE
' Buttons visibili anche in FullScreen
' Autoindent che testa linee EmptyOrTerminator e EmptyOrInitiator
' Le variabili V1..V9 e S1..S9 funzionano sia minuscole che maiuscole
' Save Slots/Vars e Load Slots/Vars 
' V1 or S1 = Input "Prompt"
' Button n Text (senza apici)
' Goto e Gosub (senza apici)
' Print seguito da End
' SaveSlots e SaveVars sempre eseguiti alla chiusura
' LoadSlots v1 v2 oppure LoadSlots 10 to 20 oppure LoadSlots 10 to V2*4
' Disabled the Horizzontal scrollbar
' Tabs are equivalent to 4 spaces
' Eliminato il flickering della ListView
' Path combine durante la copia del file
' Sistemato OpenFileDialog che visualizzava solo parte del nome
' Selection length with Tabs and Zoom
' Eliminate quasi tutte le exceptions

' Aggiunata la TextBox per gli indirizzi WEB
' Aggiunto il costrutto Select, Case, CaseElse, EndSelect
' Corretto l'errore di indentazione con spazi
' L'istruzione speed aggiorna il cursore
' Trimmate le righe durante il Load



