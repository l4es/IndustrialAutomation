﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Me.cmd_Disconnect = New System.Windows.Forms.Button
        Me.cmd_Connect = New System.Windows.Forms.Button
        Me.txt_Weight = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'cmd_Disconnect
        '
        Me.cmd_Disconnect.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Disconnect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Disconnect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Disconnect.Location = New System.Drawing.Point(247, 58)
        Me.cmd_Disconnect.Name = "cmd_Disconnect"
        Me.cmd_Disconnect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Disconnect.Size = New System.Drawing.Size(91, 26)
        Me.cmd_Disconnect.TabIndex = 20
        Me.cmd_Disconnect.Text = "Disconnect"
        Me.cmd_Disconnect.UseVisualStyleBackColor = False
        '
        'cmd_Connect
        '
        Me.cmd_Connect.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Connect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Connect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Connect.Location = New System.Drawing.Point(247, 22)
        Me.cmd_Connect.Name = "cmd_Connect"
        Me.cmd_Connect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Connect.Size = New System.Drawing.Size(91, 26)
        Me.cmd_Connect.TabIndex = 19
        Me.cmd_Connect.Text = "Connect"
        Me.cmd_Connect.UseVisualStyleBackColor = False
        '
        'txt_Weight
        '
        Me.txt_Weight.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Weight.Location = New System.Drawing.Point(29, 45)
        Me.txt_Weight.Name = "txt_Weight"
        Me.txt_Weight.Size = New System.Drawing.Size(174, 38)
        Me.txt_Weight.TabIndex = 35
        Me.txt_Weight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(46, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(138, 24)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Weight (grams)"
        '
        'Timer1
        '
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 99)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_Weight)
        Me.Controls.Add(Me.cmd_Disconnect)
        Me.Controls.Add(Me.cmd_Connect)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(68, 32)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Electronic Balance Reader"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents cmd_Disconnect As System.Windows.Forms.Button
    Public WithEvents cmd_Connect As System.Windows.Forms.Button
    Friend WithEvents txt_Weight As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
