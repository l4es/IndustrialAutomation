﻿
Imports System.IO.Ports
Imports System.Diagnostics

Public Class Form_Main

    ' ================================================================================================
    '  Open and Close
    ' ================================================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ' --------------------------------------- Form title
        Me.Text = AppTitleAndVersion("Theremino - Balance Reader")
        ' --------------------------------------- Form position and saved parameters
        Load_INI()
        ' --------------------------------------- Auto-connect at start
        Connect_ScaleComPort()
        ' --------------------------------------- Start timer1 with 20 Hz frequency
        Timer1.Interval = 50
        Timer1.Start()
        ' --------------------------------------- Enable events
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub
    Private Sub MainForm_FormClosed(ByVal eventSender As System.Object, _
                                    ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) _
                                    Handles Me.FormClosed
        Application.DoEvents()
        Disconnect_ScaleComPort()
        Save_INI()
    End Sub
    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    ' ================================================================================================
    '  User interface - Control buttons
    ' ================================================================================================
    Private Sub cmd_Connect_Click(ByVal eventSender As System.Object, _
                                  ByVal eventArgs As System.EventArgs) Handles cmd_Connect.Click
        Connect_ScaleComPort()
    End Sub
    Private Sub cmd_Disconnect_Click(ByVal eventSender As System.Object, _
                                     ByVal eventArgs As System.EventArgs) Handles cmd_Disconnect.Click
        Disconnect_ScaleComPort()
    End Sub

    ' ================================================================================================
    '  Periodically update grams on the user interface
    ' ================================================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        txt_Weight.Text = Weight.ToString("0.00", Globalization.CultureInfo.InvariantCulture)
    End Sub



    ' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    '  Following functions are specialized to read RS232 packets from a "HS-N" balance
    ' """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    '  The model is: "HS-N ElectronicBalance" 
    '  Produced by: FUZHOU HENGZHAN ELECTRONIC CO.,LTD
    '  And the protocol is explained in the document "WeightDecoding.txt"
    ' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


    ' ================================================================================================
    '  RS232 ComPort - Connect / Disconnect
    ' ================================================================================================
    Private WithEvents ScaleComPort As New SerialPort()

    Private Sub Connect_ScaleComPort()
        ' -------------------------------------------- If the port is Open then close it
        Disconnect_ScaleComPort()
        ' -------------------------------------------- Set PORT and SPEED
        ScaleComPort.PortName = "COM1"
        ScaleComPort.BaudRate = 9600
        ScaleComPort.Parity = Parity.None
        ScaleComPort.DataBits = 8
        ScaleComPort.StopBits = StopBits.One
        ' -------------------------------------------- Set params
        ScaleComPort.ReceivedBytesThreshold = 1
        ScaleComPort.ReadBufferSize = 5000
        ' -------------------------------------------- Disable DTR
        ScaleComPort.DtrEnable = False
        ' -------------------------------------------- Try to open the port
        Try
            ScaleComPort.Open()
        Catch
        End Try
        ' -------------------------------------------- Test if the port is really open
        If ScaleComPort.IsOpen Then
            cmd_Disconnect.Enabled = True
            cmd_Connect.Enabled = False
        Else
            cmd_Disconnect.Enabled = False
            cmd_Connect.Enabled = True
        End If
    End Sub

    Private Sub Disconnect_ScaleComPort()
        If ScaleComPort.IsOpen Then
            ScaleComPort.Close()
        End If
        cmd_Connect.Enabled = True
        cmd_Disconnect.Enabled = False
        txt_Weight.Text = ""
    End Sub


    ' ================================================================================================
    '  RS232 ComPort - Receive Data
    ' ================================================================================================
    Private Weight As Single = 0
    Private b1 As Int32
    Private b2 As Int32
    Private bufptr As Int32
    Private buf(99) As Int32

    Private Sub comPort_DataReceived(ByVal sender As Object, _
                                     ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
                                     Handles ScaleComPort.DataReceived
        '
        While ScaleComPort.BytesToRead > 0
            ' ------------------------------------------------ save precedent byte (b1)
            b1 = b2
            ' ------------------------------------------------ read the new byte
            b2 = ScaleComPort.ReadByte
            ' ------------------------------------------------ eventually print debug values
            'Debug.Print(b1.ToString & "  " & b2.ToString)
            ' ------------------------------------------------ detect start packet
            If b1 = 254 And b2 = 85 Then
                bufptr = 0
            End If
            ' ------------------------------------------------ place the new byte in the buffer
            buf(bufptr) = b2
            bufptr += 1
            ' ------------------------------------------------ when buffer contains 12 bytes
            If bufptr > 12 Then
                ' -------------------------------------------- if last two bytes are correct
                If b1 = 170 And b2 = 254 Then
                    ' ---------------------------------------- decode weight value in grams
                    Weight = buf(3) * 256 + buf(4)
                    Weight /= 100
                    ' ---------------------------------------- write weight value on slot 1
                    Slots.WriteSlot(1, Weight)
                    ' ---------------------------------------- eventually print a debug string
                    'Dim s As String = ""
                    'For i As Int32 = 1 To 9
                    '    s &= buf(i).ToString & " "
                    'Next
                    'Debug.Print(s & Weight.ToString("0.00g"))
                End If
            End If
        End While
    End Sub

End Class