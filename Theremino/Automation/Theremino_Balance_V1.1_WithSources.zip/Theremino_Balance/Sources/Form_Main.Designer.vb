﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Me.cmd_Calibrate = New System.Windows.Forms.Button
        Me.cmd_Tare = New System.Windows.Forms.Button
        Me.txt_Weight = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txt_OutSlot = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_InSlot = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'cmd_Calibrate
        '
        Me.cmd_Calibrate.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Calibrate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Calibrate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmd_Calibrate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Calibrate.Location = New System.Drawing.Point(224, 59)
        Me.cmd_Calibrate.Name = "cmd_Calibrate"
        Me.cmd_Calibrate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Calibrate.Size = New System.Drawing.Size(79, 26)
        Me.cmd_Calibrate.TabIndex = 20
        Me.cmd_Calibrate.Text = "Calibrate"
        Me.cmd_Calibrate.UseVisualStyleBackColor = False
        '
        'cmd_Tare
        '
        Me.cmd_Tare.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Tare.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Tare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmd_Tare.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Tare.Location = New System.Drawing.Point(140, 59)
        Me.cmd_Tare.Name = "cmd_Tare"
        Me.cmd_Tare.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Tare.Size = New System.Drawing.Size(79, 26)
        Me.cmd_Tare.TabIndex = 19
        Me.cmd_Tare.Text = "Tare"
        Me.cmd_Tare.UseVisualStyleBackColor = False
        '
        'txt_Weight
        '
        Me.txt_Weight.BackColor = System.Drawing.Color.DarkBlue
        Me.txt_Weight.Font = New System.Drawing.Font("Tahoma", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Weight.ForeColor = System.Drawing.Color.Gold
        Me.txt_Weight.Location = New System.Drawing.Point(140, 8)
        Me.txt_Weight.Name = "txt_Weight"
        Me.txt_Weight.ReadOnly = True
        Me.txt_Weight.Size = New System.Drawing.Size(163, 46)
        Me.txt_Weight.TabIndex = 35
        Me.txt_Weight.Text = "0.00"
        Me.txt_Weight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 10)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(119, 19)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Weight (grams)"
        '
        'Timer1
        '
        '
        'txt_OutSlot
        '
        Me.txt_OutSlot.Location = New System.Drawing.Point(78, 42)
        Me.txt_OutSlot.Name = "txt_OutSlot"
        Me.txt_OutSlot.Size = New System.Drawing.Size(48, 20)
        Me.txt_OutSlot.TabIndex = 37
        Me.txt_OutSlot.Text = "-1"
        Me.txt_OutSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(14, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Output Slot"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(14, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Input Slot"
        '
        'txt_InSlot
        '
        Me.txt_InSlot.Location = New System.Drawing.Point(78, 65)
        Me.txt_InSlot.Name = "txt_InSlot"
        Me.txt_InSlot.Size = New System.Drawing.Size(48, 20)
        Me.txt_InSlot.TabIndex = 39
        Me.txt_InSlot.Text = "13"
        Me.txt_InSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(312, 92)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_InSlot)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_OutSlot)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_Weight)
        Me.Controls.Add(Me.cmd_Calibrate)
        Me.Controls.Add(Me.cmd_Tare)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(68, 32)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Balance"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents cmd_Calibrate As System.Windows.Forms.Button
    Public WithEvents cmd_Tare As System.Windows.Forms.Button
    Friend WithEvents txt_Weight As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txt_OutSlot As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_InSlot As System.Windows.Forms.TextBox
End Class
