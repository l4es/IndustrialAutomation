﻿
Public Class Form_Main

    ' ================================================================================================
    '  Open, Close and Move the main form
    ' ================================================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ' --------------------------------------- Form title
        Me.Text = AppTitleAndVersion("Theremino Balance")
        ' --------------------------------------- Form position and saved parameters
        Load_INI()
        SetParams()
        ' --------------------------------------- Start timer1 with 20 Hz frequency
        Timer1.Interval = 50
        Timer1.Start()
        ' --------------------------------------- Enable events
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub
    Private Sub Form_Main_FormClosing(ByVal sender As Object, _
                                      ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
    End Sub
    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    ' ================================================================================================
    '  Slots
    ' ================================================================================================
    Private Sub txt_OutSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_OutSlot.TextChanged
        If Not EventsAreEnabled Then Return
        SetParams()
        Save_INI()
    End Sub
    Private Sub txt_InSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_InSlot.TextChanged
        If Not EventsAreEnabled Then Return
        SetParams()
        Save_INI()
    End Sub

    Private Sub SetParams()
        SlotOut = CInt(Val(txt_OutSlot.Text))
        SlotIn = CInt(Val(txt_InSlot.Text))
    End Sub

    ' ================================================================================================
    '  Control buttons
    ' ================================================================================================
    Private Sub cmd_Tare_Click(ByVal eventSender As System.Object, _
                               ByVal eventArgs As System.EventArgs) Handles cmd_Tare.Click
        TrimZero = SmoothedValue
    End Sub
    Private Sub cmd_Calibrate_Click(ByVal eventSender As System.Object, _
                                    ByVal eventArgs As System.EventArgs) Handles cmd_Calibrate.Click
        '
        Dim CalibrationWeight As Single = -1
        'Dim ClassicWeights() As Single = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000}
        'For Each w As Single In ClassicWeights
        '    If Math.Abs(Weight / w - 1) < 0.1 Then
        '        CalibrationWeight = w
        '    End If
        'Next
        If CalibrationWeight < 0 Then
            CalibrationWeight = CSng(Val(InputBox("Unrecognized calibration weight." + vbCrLf + vbCrLf + vbCrLf + _
                                                  "Please write the calibration weight grams:", _
                                                  "Theremino - Balance Adc24")))
        End If
        If CalibrationWeight > 0 Then
            TrimScale *= CalibrationWeight / Weight
        End If
    End Sub

    ' ================================================================================================
    '  Timed operation
    ' ================================================================================================
    Friend SlotIn As Int32 = 1
    Friend SlotOut As Int32 = 2
    Friend TrimZero As Single = 0
    Friend TrimScale As Single = 6.6

    Private ci As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture
    Private RawValue As Single
    Private SmoothedValue As Single
    Private Weight As Single

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' ---------------------------------------------------- read the input Slot
        RawValue = Slots.ReadSlot_NoNan(SlotIn)
        ' ---------------------------------------------------- stabilize the value 
        SmoothValue_Pow_Adaptive(SmoothedValue, RawValue, 15000)
        ' ---------------------------------------------------- calculate the weight
        If TrimScale = 0 Then TrimScale = 1
        Weight = TrimScale * (SmoothedValue - TrimZero)
        ' ---------------------------------------------------- show the weight
        If txt_Weight.SelectionLength = 0 Then
            txt_Weight.Text = Weight.ToString("0.00", ci)
        End If
        ' ---------------------------------------------------- write weight to output Slot
        Slots.WriteSlot(SlotOut, Weight)
    End Sub

    ' ================================================================================================
    '   Adaptive, HiQuality, smoothing function
    ' ================================================================================================
    Private Sub SmoothValue_Pow_Adaptive(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        If Single.IsInfinity(new_value) Then new_value = 0
        Dim delta As Single = new_value - value
        Dim delta_sgn As Single = Math.Sign(delta)
        Dim delta_abs As Single = Math.Abs(delta)
        Dim delta_pow As Single = CSng(delta_abs ^ 2) * speed
        If value <> 0 Then delta_pow /= Math.Abs(value)
        If delta_pow >= delta_abs Then
            value = new_value
        Else
            value += delta_sgn * delta_pow
        End If
    End Sub


End Class