﻿
Imports System.Math
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False


    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function


    ' =======================================================================================================
    '   Files
    ' =======================================================================================================

    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function

    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function

    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function

    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            If .Left < -9000 Then .Left = 0
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================

    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function

    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function

    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function

    Private Function Val_Double(ByVal l As String) As Double
        Return Val(Replace(l, ",", "."))
    End Function

    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(Replace(l, ",", ".")))
    End Function

    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function

    Private Function MultilineToString(ByVal Name As String, _
                                  ByVal Value As String) As String

        Value = Value.Replace(vbCrLf, "%M")
        Return Name & "=" & Value
    End Function

    Private Function StringToMultiline(ByVal Value As String) As String
        Value = Value.Replace("%M", vbCrLf)
        Return Value
    End Function


    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Strings.Left(s, i - 1).Trim
            s = Mid(s, i + 1).Trim
        Else
            ExtractParamName = s.Trim
            s = ""
        End If
    End Function

    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function



    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub SaveConfigurationAs()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.DefaultExt = ".txt"
        sfd.Filter = "Configuration file (*.txt)|*txt"
        'sfd.FileName = AssemblyName() & "_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
        sfd.FileName = "MCA_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Save_INI(sfd.FileName)
        End If
    End Sub

    Friend Sub LoadConfiguration()
        Dim ofd As OpenFileDialog = New OpenFileDialog
        ofd.Filter = "Configuration file (*.txt)|*txt"
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Load_INI(ofd.FileName)
        End If
    End Sub


    Friend Sub Save_INI(Optional ByVal iniFileName As String = "")
        '
        If iniFileName = "" Then
            iniFileName = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        End If
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form_Main)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            'f.WriteLine(TabString("Form1_Width", r.Width))
            'f.WriteLine(TabString("Form1_Height", r.Height))
            '
            f.WriteLine("")
            f.WriteLine(" Options")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("TrimZero", Form_Main.TrimZero.ToString.Replace(",", ".")))
            f.WriteLine(TabString("TrimScale", Form_Main.TrimScale.ToString.Replace(",", ".")))
            f.WriteLine(TabString("SlotOut", Form_Main.txt_OutSlot.Text))
            f.WriteLine(TabString("SlotIn", Form_Main.txt_InSlot.Text))
            '
            f.Close()
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI(Optional ByVal iniFileName As String = "")
        ' ----------------------------------------- avoid trackbars and other controls min-max overflow
        On Error Resume Next
        ' 
        Dim LoadAll As Boolean = False
        If iniFileName = "" Then
            iniFileName = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
            LoadAll = True
        End If
        '
        Dim l As String
        If My.Computer.FileSystem.FileExists(iniFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Dim param As String = ExtractParamName(l)
                Select Case param
                    ' -----------------------------------------------------------------
                    Case "Form1_Top" : If LoadAll Then Form_Main.Top = CInt(Val(l))
                    Case "Form1_Left" : If LoadAll Then Form_Main.Left = CInt(Val(l))
                        'Case "Form1_Width" : If LoadAll Then Form_Main.Width = CInt(Val(l))
                        'Case "Form1_Height" : If LoadAll Then Form_Main.Height = CInt(Val(l))
                        '
                        ' -----------------------------------------------------------------
                    Case "TrimZero" : Form_Main.TrimZero = Val_Single(l)
                    Case "TrimScale" : Form_Main.TrimScale = Val_Single(l)
                    Case "SlotOut" : Form_Main.txt_OutSlot.Text = l
                    Case "SlotIn" : Form_Main.txt_InSlot.Text = l
                End Select
            Loop
            f.Close()
        End If
        If Form_Main.WindowState = FormWindowState.Minimized Then Form_Main.WindowState = FormWindowState.Normal
        LimitFormPosition(Form_Main)
    End Sub

End Module
