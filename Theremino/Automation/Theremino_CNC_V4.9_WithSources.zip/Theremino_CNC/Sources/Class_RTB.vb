
Imports System.Collections.Generic

Public Class SyntaxRichTextBox
    Inherits System.Windows.Forms.RichTextBox

    Friend RTB_Editing As Boolean = True

    Friend VisibleLines As Int32

    Private Sub Me_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        CalcVisibleLinesCount()
    End Sub

    Friend Sub CalcVisibleLinesCount()
        Dim topIndex As Integer = Me.GetCharIndexFromPosition(New Point(1, 1))
        Dim bottomIndex As Integer = Me.GetCharIndexFromPosition(New Point(1, Me.Height - 1))
        Dim topLine As Integer = Me.GetLineFromCharIndex(topIndex)
        Dim bottomLine As Integer = Me.GetLineFromCharIndex(bottomIndex)
        VisibleLines = bottomLine - topLine
    End Sub

    ' ===============================================================================================
    '  DISABLE MOUSE SELECTION WHEN NON EDITING
    ' ===============================================================================================
    Private Sub RTB_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseLeave
        If Not RTB_Editing Then Enabled = True
    End Sub
    Private Sub RTB_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If Not RTB_Editing Then Enabled = False
    End Sub

    ' ===============================================================================================
    '  ENABLE DISABLE PAINT
    ' ===============================================================================================
    Friend PaintEventEnabled As Boolean = True
    Protected Overrides Sub WndProc(ByRef m As Message)
        Const WM_PAINT As Int32 = &HF
        If m.Msg = WM_PAINT AndAlso Not PaintEventEnabled Then
            m.Result = IntPtr.Zero
        Else
            MyBase.WndProc(m)
        End If
    End Sub

    ' ===============================================================================================
    '  MIXED FUNCTIONS
    ' ===============================================================================================
    Friend Sub SelectLine(ByVal line As Int32)
        If line >= 0 AndAlso line < Lines.Length AndAlso Lines.Length > 0 Then
            Dim lineStart As Int32 = GetFirstCharIndexFromLine(line)
            Dim lineLength As Int32 = Lines(line).Length
            Me.Select(lineStart, lineLength)
        Else
            Me.Select(0, 0)
        End If
    End Sub
    Private Sub SelectLines(ByVal FirstLine As Int32, ByVal LastLine As Int32)
        If LastLine < FirstLine Then Return
        Dim FirstChar As Int32 = Me.GetFirstCharIndexFromLine(FirstLine)
        Dim LastChar As Int32 = Me.GetFirstCharIndexFromLine(LastLine) + Me.Lines(LastLine).Length '- 1
        Me.Select(FirstChar, LastChar - FirstChar)
    End Sub
    Private Function GetFirstSelectedLine() As Int32
        Return Me.GetLineFromCharIndex(Me.SelectionStart)
    End Function
    Private Function GetLastSelectedLine() As Int32
        Return Me.GetLineFromCharIndex(Me.SelectionStart + Me.SelectionLength)
    End Function
    Private Function GetFirstVisibleCharIndex() As Int32
        Return Me.GetCharIndexFromPosition(New Point(1, 1))
    End Function

    ' ===============================================================================================
    '  CUT COPY and PASTE
    ' ===============================================================================================
    Friend Sub ExecCut()
        If Me.SelectionLength > 0 Then
            SendTextToClipboard()
            Me.SelectedText = ""
        End If
    End Sub
    Friend Sub ExecCopy()
        If Me.SelectionLength > 0 Then
            SendTextToClipboard()
        End If
    End Sub
    Private Sub SendTextToClipboard()
        Dim data As IDataObject
        data = New DataObject(DataFormats.Text, Me.SelectedText.Replace(vbLf, vbCrLf))
        Clipboard.SetDataObject(data, True)
    End Sub
    Friend Sub ExecPaste()
        If Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) Then
            Me.Enabled = False
            PaintEventEnabled = False
            ' ------------------------------------------------------------ extract only the text from clipbbard
            Dim startline As Int32 = GetLineFromCharIndex(SelectionStart)
            Me.SelectedText = Clipboard.GetText
            Dim endline As Int32 = GetLineFromCharIndex(SelectionStart + SelectionLength)
            ' ------------------------------------------------------------
            PaintEventEnabled = True
            Me.Enabled = True
            Me.Focus()
        End If
    End Sub
    Friend Sub ExecDelete()
        If Me.SelectionLength > 0 Then
            Me.SelectedText = ""
        End If
    End Sub
    'Friend Function Editor_CanPaste() As Boolean
    '    Return Clipboard.GetDataObject().GetDataPresent(DataFormats.Text)
    'End Function


    ' ===============================================================================================
    '  MODIFY GCODE - INDENT/UNINDENT - COMMENT/UN-COMMENT
    ' ===============================================================================================
    Friend Sub ModifyGcode(ByVal Operation As String, ByVal OnlySelectedLines As Boolean)
        If Me.Lines.Length = 0 Then Return
        SetCursor_Hourglass()
        Me.Enabled = False
        PaintEventEnabled = False
        ' ----------------------------------------------------------------
        Dim FirstVisibleCharIndex As Int32 = GetFirstVisibleCharIndex()
        Dim FirstLine As Int32 = 0
        Dim LastLine As Int32 = Me.Lines.Length - 1
        If OnlySelectedLines Then
            FirstLine = GetFirstSelectedLine()
            LastLine = GetLastSelectedLine()
        End If
        ' ----------------------------------------------------------------
        Select Case Operation
            Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB", "TRANSLATE_TO_ZERO_XY", "TRANSLATE_TO_ZERO_XYAB", _
                  "ROTATE_LEFT_XY", "ROTATE_LEFT_XYAB", "ROTATE_RIGHT_XY", "ROTATE_RIGHT_XYAB", "NORMALIZE"
                PARSER_ModifyGcode(FirstLine, LastLine, Operation)
            Case "INDENT"
                For i As Int32 = FirstLine To LastLine
                    GcodeLines(i) = vbTab + GcodeLines(i)
                Next
            Case "UNINDENT"
                For i As Int32 = FirstLine To LastLine
                    GcodeLines(i) = GcodeLines(i).TrimStart
                Next
            Case "COMMENT"
                For i As Int32 = FirstLine To LastLine
                    If GcodeLines(i).Trim <> "" Then
                        GcodeLines(i) = "(" + GcodeLines(i) + ")"
                    End If
                Next
            Case "UNCOMMENT"
                For i As Int32 = FirstLine To LastLine
                    If GcodeLines(i).Trim.StartsWith("(") Then
                        GcodeLines(i) = Strings.Replace(GcodeLines(i), "(", "", , 1)
                        GcodeLines(i) = Strings.Replace(GcodeLines(i), ")", "", , 1)
                    End If
                Next
        End Select
        ' ---------------------------------------------------------------- assign to selected text (for UNDO-REDO)
        Dim s As String
        s = String.Join(vbCr, GcodeLines, FirstLine, LastLine - FirstLine + 1)
        Me.SelectLines(FirstLine, LastLine)
        Me.SelectedText = s
        ' ---------------------------------------------------------------- reposition selection and scroll
        If OnlySelectedLines Then
            Me.SelectionStart = FirstVisibleCharIndex
            Me.ScrollToCaret()
            Me.SelectLines(FirstLine, LastLine)
        Else
            Me.SelectionStart = FirstVisibleCharIndex
            Me.SelectionLength = 0
            Me.ScrollToCaret()
        End If
        ' ----------------------------------------------------------------
        Form1.ReparseGcodeAndUpdateUserInterface()
        ' ----------------------------------------------------------------
        Me.Enabled = True
        PaintEventEnabled = True
        SetCursor_Default()
        Me.Focus()
    End Sub

End Class
