﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim DesignerRectTracker1 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems1 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems2 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker2 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems3 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems4 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker4 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker5 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems5 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems6 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker6 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker7 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems7 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems8 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker8 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker9 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems9 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems10 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker10 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker11 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems11 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems12 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker12 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker13 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems13 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems14 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker14 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker15 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems15 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems16 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker16 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker17 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems17 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems18 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker18 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker19 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems19 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems20 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker20 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker21 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems21 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems22 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker22 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker23 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems23 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems24 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker24 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker25 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems25 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems26 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker26 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker27 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems27 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems28 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker28 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker29 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems29 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems30 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker30 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker31 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems31 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems32 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker32 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker33 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems33 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems34 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker34 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker35 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems35 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems36 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker36 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker37 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems37 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems38 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker38 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker39 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems39 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems40 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker40 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker41 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems41 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems42 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker42 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker43 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems43 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems44 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker44 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker45 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems45 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems46 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker46 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker47 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems47 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems48 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker48 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker49 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems49 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems50 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker50 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker51 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems51 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems52 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker52 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker53 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems53 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems54 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker54 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker55 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems55 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems56 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker56 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker57 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems57 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems58 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker58 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker59 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems59 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems60 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker60 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker61 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems61 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems62 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker62 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_LoadGcode = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SaveGcode = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SaveGcodeAs = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_SaveToolpathImage = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_ConvertToMM_XYZ = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_ConvertToMM_XYZAB = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_TranslateToZero_XY = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_TranslateToZero_XYAB = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_RotateLeft_XY = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_RotateLeft_XYAB = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_RotateRight_XY = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_RotateRight_XYAB = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Normalize = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Options = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_3DPrinters = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_ControlTemperatures = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_EditTempTables = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Skins = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_EditSkinFile = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_OpenSkinsFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_ReloadSelectedSkin = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelpENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelpITA = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_GMcodes_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_GMcodes_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_LoadGcode = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_SaveGcode = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_SaveGcodeAs = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Skin = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_View = New System.Windows.Forms.ToolStripButton
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel
        Me.GroupBox_Gcode = New System.Windows.Forms.GroupBox
        Me.txt_Debug = New Theremino_CNC.MyTextBox
        Me.btn_ToolStop = New Theremino_CNC.MyButton
        Me.btn_Down = New Theremino_CNC.MyButton
        Me.btn_Up = New Theremino_CNC.MyButton
        Me.btn_ZoomMinus = New Theremino_CNC.MyButton
        Me.btn_ZoomPlus = New Theremino_CNC.MyButton
        Me.RTB = New Theremino_CNC.SyntaxRichTextBox
        Me.CTX_Edit = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CTX_Edit_Find = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.CTX_Edit_Cut = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Copy = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Paste = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Delete = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.CTX_Edit_SelectAll = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.CTX_Edit_Comment = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Uncomment = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.CTX_Edit_Indent = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Unindent = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator
        Me.CTX_Edit_Undo = New System.Windows.Forms.ToolStripMenuItem
        Me.CTX_Edit_Redo = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox_Controls = New System.Windows.Forms.GroupBox
        Me.btn_GCodeStop = New Theremino_CNC.MyButton
        Me.btn_GcodePause = New Theremino_CNC.MyButton
        Me.btn_GcodeLoad = New Theremino_CNC.MyButton
        Me.btn_GcodeRewind = New Theremino_CNC.MyButton
        Me.btn_GcodeStart = New Theremino_CNC.MyButton
        Me.GroupBox_Motors = New System.Windows.Forms.GroupBox
        Me.txt_EditCoord = New Theremino_CNC.MyTextBox
        Me.btn_LookAhead = New Theremino_CNC.MyButton
        Me.txt_Speed = New Theremino_CNC.MyTextBox
        Me.lbl_Speed = New System.Windows.Forms.Label
        Me.lbl_Rapid = New System.Windows.Forms.Label
        Me.btn_FeedSpeedLocked = New Theremino_CNC.MyButton
        Me.lbl_CoordB = New System.Windows.Forms.Label
        Me.lbl_CoordA = New System.Windows.Forms.Label
        Me.lbl_CoordZ = New System.Windows.Forms.Label
        Me.lbl_CoordY = New System.Windows.Forms.Label
        Me.lbl_CoordX = New System.Windows.Forms.Label
        Me.btn_ZeroB = New Theremino_CNC.MyButton
        Me.txt_MaxError = New Theremino_CNC.MyTextBox
        Me.btn_ZeroA = New Theremino_CNC.MyButton
        Me.btn_ZeroZ = New Theremino_CNC.MyButton
        Me.lbl_MaxErr = New System.Windows.Forms.Label
        Me.btn_ZeroY = New Theremino_CNC.MyButton
        Me.txt_Feed = New Theremino_CNC.MyTextBox
        Me.btn_ZeroX = New Theremino_CNC.MyButton
        Me.lbl_Feed = New System.Windows.Forms.Label
        Me.txt_Rapid = New Theremino_CNC.MyTextBox
        Me.txt_CtrlJog = New Theremino_CNC.MyTextBox
        Me.lbl_Jog = New System.Windows.Forms.Label
        Me.GroupBox_Toolpath = New System.Windows.Forms.GroupBox
        Me.btn_ZoomTpMinus = New Theremino_CNC.MyButton
        Me.btn_ZoomTpPlus = New Theremino_CNC.MyButton
        Me.btn_GotoHome = New Theremino_CNC.MyButton
        Me.btn_GotoBottomLeft = New Theremino_CNC.MyButton
        Me.btn_GotoTopRight = New Theremino_CNC.MyButton
        Me.btn_GotoZero = New Theremino_CNC.MyButton
        Me.btn_TestLowZ = New Theremino_CNC.MyButton
        Me.PanelCursor1 = New System.Windows.Forms.Panel
        Me.PanelCursor2 = New System.Windows.Forms.Panel
        Me.Pic_Toolpath = New System.Windows.Forms.PictureBox
        Me.PanelBack1 = New System.Windows.Forms.Panel
        Me.GroupBox_Temperatures = New System.Windows.Forms.GroupBox
        Me.lbl_TempExtruders = New System.Windows.Forms.Label
        Me.lbl_TempPrintBed = New System.Windows.Forms.Label
        Me.lbl_TempChamber = New System.Windows.Forms.Label
        Me.lbl_TempAmbient = New System.Windows.Forms.Label
        Me.PanelBack2 = New System.Windows.Forms.Panel
        Me.GroupBox_Calibrations = New System.Windows.Forms.GroupBox
        Me.btn_CalibrateAB = New Theremino_CNC.MyButton
        Me.btn_CalibrationSettings = New Theremino_CNC.MyButton
        Me.btn_CalibrateZ = New Theremino_CNC.MyButton
        Me.btn_SetZetaHome = New Theremino_CNC.MyButton
        Me.btn_CalibrateXY = New Theremino_CNC.MyButton
        Me.PanelSplitter = New System.Windows.Forms.Panel
        Me.btn_InOutEnabled = New Theremino_CNC.MyButton
        Me.btn_HalEnabled = New Theremino_CNC.MyButton
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox_Gcode.SuspendLayout()
        Me.CTX_Edit.SuspendLayout()
        Me.GroupBox_Controls.SuspendLayout()
        Me.GroupBox_Motors.SuspendLayout()
        Me.GroupBox_Toolpath.SuspendLayout()
        CType(Me.Pic_Toolpath, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBack1.SuspendLayout()
        Me.GroupBox_Temperatures.SuspendLayout()
        Me.PanelBack2.SuspendLayout()
        Me.GroupBox_Calibrations.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tools, Me.Menu_Options, Me.Menu_3DPrinters, Me.Menu_Skins, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(893, 30)
        Me.MenuStrip1.TabIndex = 212
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_LoadGcode, Me.Menu_File_SaveGcode, Me.Menu_File_SaveGcodeAs, Me.ToolStripSeparator14, Me.Menu_File_SaveToolpathImage, Me.ToolStripSeparator6, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(53, 26)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_LoadGcode
        '
        Me.Menu_File_LoadGcode.Image = CType(resources.GetObject("Menu_File_LoadGcode.Image"), System.Drawing.Image)
        Me.Menu_File_LoadGcode.Name = "Menu_File_LoadGcode"
        Me.Menu_File_LoadGcode.Size = New System.Drawing.Size(257, 26)
        Me.Menu_File_LoadGcode.Text = "Load GCode"
        '
        'Menu_File_SaveGcode
        '
        Me.Menu_File_SaveGcode.Image = CType(resources.GetObject("Menu_File_SaveGcode.Image"), System.Drawing.Image)
        Me.Menu_File_SaveGcode.Name = "Menu_File_SaveGcode"
        Me.Menu_File_SaveGcode.Size = New System.Drawing.Size(257, 26)
        Me.Menu_File_SaveGcode.Text = "Save GCode"
        '
        'Menu_File_SaveGcodeAs
        '
        Me.Menu_File_SaveGcodeAs.Image = CType(resources.GetObject("Menu_File_SaveGcodeAs.Image"), System.Drawing.Image)
        Me.Menu_File_SaveGcodeAs.Name = "Menu_File_SaveGcodeAs"
        Me.Menu_File_SaveGcodeAs.Size = New System.Drawing.Size(257, 26)
        Me.Menu_File_SaveGcodeAs.Text = "Save GCode as"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(254, 6)
        '
        'Menu_File_SaveToolpathImage
        '
        Me.Menu_File_SaveToolpathImage.Image = CType(resources.GetObject("Menu_File_SaveToolpathImage.Image"), System.Drawing.Image)
        Me.Menu_File_SaveToolpathImage.Name = "Menu_File_SaveToolpathImage"
        Me.Menu_File_SaveToolpathImage.Size = New System.Drawing.Size(257, 26)
        Me.Menu_File_SaveToolpathImage.Text = "Save Toolpath image"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(254, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(257, 26)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tools
        '
        Me.Menu_Tools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_ConvertToMM_XYZ, Me.Menu_ConvertToMM_XYZAB, Me.ToolStripSeparator15, Me.Menu_TranslateToZero_XY, Me.Menu_TranslateToZero_XYAB, Me.ToolStripSeparator16, Me.Menu_RotateLeft_XY, Me.Menu_RotateLeft_XYAB, Me.Menu_RotateRight_XY, Me.Menu_RotateRight_XYAB, Me.ToolStripSeparator13, Me.Menu_Normalize})
        Me.Menu_Tools.Name = "Menu_Tools"
        Me.Menu_Tools.Size = New System.Drawing.Size(68, 26)
        Me.Menu_Tools.Text = "Tools"
        '
        'Menu_ConvertToMM_XYZ
        '
        Me.Menu_ConvertToMM_XYZ.Image = CType(resources.GetObject("Menu_ConvertToMM_XYZ.Image"), System.Drawing.Image)
        Me.Menu_ConvertToMM_XYZ.Name = "Menu_ConvertToMM_XYZ"
        Me.Menu_ConvertToMM_XYZ.Size = New System.Drawing.Size(382, 26)
        Me.Menu_ConvertToMM_XYZ.Text = "Convert to mm. (x/y/z)"
        '
        'Menu_ConvertToMM_XYZAB
        '
        Me.Menu_ConvertToMM_XYZAB.Image = CType(resources.GetObject("Menu_ConvertToMM_XYZAB.Image"), System.Drawing.Image)
        Me.Menu_ConvertToMM_XYZAB.Name = "Menu_ConvertToMM_XYZAB"
        Me.Menu_ConvertToMM_XYZAB.Size = New System.Drawing.Size(382, 26)
        Me.Menu_ConvertToMM_XYZAB.Text = "Convert to mm. (x/y/z/a/b)"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(379, 6)
        '
        'Menu_TranslateToZero_XY
        '
        Me.Menu_TranslateToZero_XY.Image = CType(resources.GetObject("Menu_TranslateToZero_XY.Image"), System.Drawing.Image)
        Me.Menu_TranslateToZero_XY.Name = "Menu_TranslateToZero_XY"
        Me.Menu_TranslateToZero_XY.Size = New System.Drawing.Size(382, 26)
        Me.Menu_TranslateToZero_XY.Text = "Translate to zero (x/y)"
        '
        'Menu_TranslateToZero_XYAB
        '
        Me.Menu_TranslateToZero_XYAB.Image = CType(resources.GetObject("Menu_TranslateToZero_XYAB.Image"), System.Drawing.Image)
        Me.Menu_TranslateToZero_XYAB.Name = "Menu_TranslateToZero_XYAB"
        Me.Menu_TranslateToZero_XYAB.Size = New System.Drawing.Size(382, 26)
        Me.Menu_TranslateToZero_XYAB.Text = "Translate to zero (x/y a/b)"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(379, 6)
        '
        'Menu_RotateLeft_XY
        '
        Me.Menu_RotateLeft_XY.Image = CType(resources.GetObject("Menu_RotateLeft_XY.Image"), System.Drawing.Image)
        Me.Menu_RotateLeft_XY.Name = "Menu_RotateLeft_XY"
        Me.Menu_RotateLeft_XY.Size = New System.Drawing.Size(382, 26)
        Me.Menu_RotateLeft_XY.Text = "Rotate left (x/y)"
        '
        'Menu_RotateLeft_XYAB
        '
        Me.Menu_RotateLeft_XYAB.Image = CType(resources.GetObject("Menu_RotateLeft_XYAB.Image"), System.Drawing.Image)
        Me.Menu_RotateLeft_XYAB.Name = "Menu_RotateLeft_XYAB"
        Me.Menu_RotateLeft_XYAB.Size = New System.Drawing.Size(382, 26)
        Me.Menu_RotateLeft_XYAB.Text = "Rotate left (x/y a/b)"
        '
        'Menu_RotateRight_XY
        '
        Me.Menu_RotateRight_XY.Image = CType(resources.GetObject("Menu_RotateRight_XY.Image"), System.Drawing.Image)
        Me.Menu_RotateRight_XY.Name = "Menu_RotateRight_XY"
        Me.Menu_RotateRight_XY.Size = New System.Drawing.Size(382, 26)
        Me.Menu_RotateRight_XY.Text = "Rotate right (x/y)"
        '
        'Menu_RotateRight_XYAB
        '
        Me.Menu_RotateRight_XYAB.Image = CType(resources.GetObject("Menu_RotateRight_XYAB.Image"), System.Drawing.Image)
        Me.Menu_RotateRight_XYAB.Name = "Menu_RotateRight_XYAB"
        Me.Menu_RotateRight_XYAB.Size = New System.Drawing.Size(382, 26)
        Me.Menu_RotateRight_XYAB.Text = "Rotate right (x/y a/b)"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(379, 6)
        '
        'Menu_Normalize
        '
        Me.Menu_Normalize.Image = CType(resources.GetObject("Menu_Normalize.Image"), System.Drawing.Image)
        Me.Menu_Normalize.Name = "Menu_Normalize"
        Me.Menu_Normalize.Size = New System.Drawing.Size(382, 26)
        Me.Menu_Normalize.Text = "Normalize x/y and strip line numbers"
        '
        'Menu_Options
        '
        Me.Menu_Options.Name = "Menu_Options"
        Me.Menu_Options.Size = New System.Drawing.Size(88, 26)
        Me.Menu_Options.Text = "Options"
        '
        'Menu_3DPrinters
        '
        Me.Menu_3DPrinters.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_ControlTemperatures, Me.Menu_EditTempTables})
        Me.Menu_3DPrinters.Name = "Menu_3DPrinters"
        Me.Menu_3DPrinters.Size = New System.Drawing.Size(117, 26)
        Me.Menu_3DPrinters.Text = "3D Printers"
        '
        'Menu_ControlTemperatures
        '
        Me.Menu_ControlTemperatures.CheckOnClick = True
        Me.Menu_ControlTemperatures.Name = "Menu_ControlTemperatures"
        Me.Menu_ControlTemperatures.Size = New System.Drawing.Size(276, 26)
        Me.Menu_ControlTemperatures.Text = "Control temperatures"
        '
        'Menu_EditTempTables
        '
        Me.Menu_EditTempTables.Image = CType(resources.GetObject("Menu_EditTempTables.Image"), System.Drawing.Image)
        Me.Menu_EditTempTables.Name = "Menu_EditTempTables"
        Me.Menu_EditTempTables.Size = New System.Drawing.Size(276, 26)
        Me.Menu_EditTempTables.Text = "Edit temperature tables"
        '
        'Menu_Skins
        '
        Me.Menu_Skins.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_EditSkinFile, Me.Menu_OpenSkinsFolder, Me.Menu_ReloadSelectedSkin})
        Me.Menu_Skins.Name = "Menu_Skins"
        Me.Menu_Skins.Size = New System.Drawing.Size(68, 26)
        Me.Menu_Skins.Text = "Skins"
        '
        'Menu_EditSkinFile
        '
        Me.Menu_EditSkinFile.Image = CType(resources.GetObject("Menu_EditSkinFile.Image"), System.Drawing.Image)
        Me.Menu_EditSkinFile.Name = "Menu_EditSkinFile"
        Me.Menu_EditSkinFile.Size = New System.Drawing.Size(257, 26)
        Me.Menu_EditSkinFile.Text = "Edit skin file"
        '
        'Menu_OpenSkinsFolder
        '
        Me.Menu_OpenSkinsFolder.Image = CType(resources.GetObject("Menu_OpenSkinsFolder.Image"), System.Drawing.Image)
        Me.Menu_OpenSkinsFolder.Name = "Menu_OpenSkinsFolder"
        Me.Menu_OpenSkinsFolder.Size = New System.Drawing.Size(257, 26)
        Me.Menu_OpenSkinsFolder.Text = "Open skins folder"
        '
        'Menu_ReloadSelectedSkin
        '
        Me.Menu_ReloadSelectedSkin.Image = CType(resources.GetObject("Menu_ReloadSelectedSkin.Image"), System.Drawing.Image)
        Me.Menu_ReloadSelectedSkin.Name = "Menu_ReloadSelectedSkin"
        Me.Menu_ReloadSelectedSkin.Size = New System.Drawing.Size(257, 26)
        Me.Menu_ReloadSelectedSkin.Text = "Reload selected skin"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelpENG, Me.Menu_Help_ProgramHelpITA, Me.ToolStripSeparator5, Me.Menu_Help_GMcodes_ENG, Me.Menu_Help_GMcodes_ITA, Me.ToolStripSeparator4, Me.Menu_Help_OpenFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(61, 26)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelpENG
        '
        Me.Menu_Help_ProgramHelpENG.Image = CType(resources.GetObject("Menu_Help_ProgramHelpENG.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelpENG.Name = "Menu_Help_ProgramHelpENG"
        Me.Menu_Help_ProgramHelpENG.Size = New System.Drawing.Size(255, 26)
        Me.Menu_Help_ProgramHelpENG.Text = "Program help ENG"
        '
        'Menu_Help_ProgramHelpITA
        '
        Me.Menu_Help_ProgramHelpITA.Image = CType(resources.GetObject("Menu_Help_ProgramHelpITA.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelpITA.Name = "Menu_Help_ProgramHelpITA"
        Me.Menu_Help_ProgramHelpITA.Size = New System.Drawing.Size(255, 26)
        Me.Menu_Help_ProgramHelpITA.Text = "Program help ITA"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(252, 6)
        '
        'Menu_Help_GMcodes_ENG
        '
        Me.Menu_Help_GMcodes_ENG.Image = CType(resources.GetObject("Menu_Help_GMcodes_ENG.Image"), System.Drawing.Image)
        Me.Menu_Help_GMcodes_ENG.Name = "Menu_Help_GMcodes_ENG"
        Me.Menu_Help_GMcodes_ENG.Size = New System.Drawing.Size(255, 26)
        Me.Menu_Help_GMcodes_ENG.Text = "G and M codes ENG"
        '
        'Menu_Help_GMcodes_ITA
        '
        Me.Menu_Help_GMcodes_ITA.Image = CType(resources.GetObject("Menu_Help_GMcodes_ITA.Image"), System.Drawing.Image)
        Me.Menu_Help_GMcodes_ITA.Name = "Menu_Help_GMcodes_ITA"
        Me.Menu_Help_GMcodes_ITA.Size = New System.Drawing.Size(255, 26)
        Me.Menu_Help_GMcodes_ITA.Text = "G and M codes ITA"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(252, 6)
        '
        'Menu_Help_OpenFolder
        '
        Me.Menu_Help_OpenFolder.Image = CType(resources.GetObject("Menu_Help_OpenFolder.Image"), System.Drawing.Image)
        Me.Menu_Help_OpenFolder.Name = "Menu_Help_OpenFolder"
        Me.Menu_Help_OpenFolder.Size = New System.Drawing.Size(255, 26)
        Me.Menu_Help_OpenFolder.Text = "Open help folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(72, 26)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_LoadGcode, Me.ToolStripSeparator1, Me.ToolStripButton_SaveGcode, Me.ToolStripSeparator3, Me.ToolStripButton_SaveGcodeAs, Me.ToolStripSeparator7, Me.ToolStripButton_Skin, Me.ToolStripSeparator2, Me.ToolStripButton_View})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 30)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.ShowItemToolTips = False
        Me.ToolStrip1.Size = New System.Drawing.Size(893, 29)
        Me.ToolStrip1.TabIndex = 213
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_LoadGcode
        '
        Me.ToolStripButton_LoadGcode.Image = CType(resources.GetObject("ToolStripButton_LoadGcode.Image"), System.Drawing.Image)
        Me.ToolStripButton_LoadGcode.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_LoadGcode.Name = "ToolStripButton_LoadGcode"
        Me.ToolStripButton_LoadGcode.Size = New System.Drawing.Size(73, 26)
        Me.ToolStripButton_LoadGcode.Text = "Load"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 29)
        '
        'ToolStripButton_SaveGcode
        '
        Me.ToolStripButton_SaveGcode.Image = CType(resources.GetObject("ToolStripButton_SaveGcode.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveGcode.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveGcode.Name = "ToolStripButton_SaveGcode"
        Me.ToolStripButton_SaveGcode.Size = New System.Drawing.Size(73, 26)
        Me.ToolStripButton_SaveGcode.Text = "Save"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 29)
        '
        'ToolStripButton_SaveGcodeAs
        '
        Me.ToolStripButton_SaveGcodeAs.Image = CType(resources.GetObject("ToolStripButton_SaveGcodeAs.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveGcodeAs.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveGcodeAs.Name = "ToolStripButton_SaveGcodeAs"
        Me.ToolStripButton_SaveGcodeAs.Size = New System.Drawing.Size(98, 26)
        Me.ToolStripButton_SaveGcodeAs.Text = "Save as"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 29)
        '
        'ToolStripButton_Skin
        '
        Me.ToolStripButton_Skin.Image = CType(resources.GetObject("ToolStripButton_Skin.Image"), System.Drawing.Image)
        Me.ToolStripButton_Skin.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Skin.Name = "ToolStripButton_Skin"
        Me.ToolStripButton_Skin.Size = New System.Drawing.Size(71, 26)
        Me.ToolStripButton_Skin.Text = "Skin:"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 29)
        '
        'ToolStripButton_View
        '
        Me.ToolStripButton_View.Image = CType(resources.GetObject("ToolStripButton_View.Image"), System.Drawing.Image)
        Me.ToolStripButton_View.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_View.Name = "ToolStripButton_View"
        Me.ToolStripButton_View.Size = New System.Drawing.Size(76, 26)
        Me.ToolStripButton_View.Text = "View:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1, Me.StatusLabel2, Me.StatusLabel3, Me.StatusLabel4, Me.StatusLabel5})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 506)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(893, 29)
        Me.StatusStrip1.TabIndex = 700
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(120, 24)
        Me.StatusLabel1.Text = "- - -"
        Me.StatusLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'StatusLabel2
        '
        Me.StatusLabel2.AutoSize = False
        Me.StatusLabel2.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel2.Name = "StatusLabel2"
        Me.StatusLabel2.Size = New System.Drawing.Size(200, 24)
        Me.StatusLabel2.Text = "- - -"
        Me.StatusLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'StatusLabel3
        '
        Me.StatusLabel3.AutoSize = False
        Me.StatusLabel3.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel3.Name = "StatusLabel3"
        Me.StatusLabel3.Size = New System.Drawing.Size(180, 24)
        Me.StatusLabel3.Text = " - - -"
        Me.StatusLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'StatusLabel4
        '
        Me.StatusLabel4.AutoSize = False
        Me.StatusLabel4.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel4.Name = "StatusLabel4"
        Me.StatusLabel4.Size = New System.Drawing.Size(120, 24)
        Me.StatusLabel4.Text = "- - -"
        Me.StatusLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'StatusLabel5
        '
        Me.StatusLabel5.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel5.Name = "StatusLabel5"
        Me.StatusLabel5.Size = New System.Drawing.Size(258, 24)
        Me.StatusLabel5.Spring = True
        Me.StatusLabel5.Text = "- - -"
        Me.StatusLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'GroupBox_Gcode
        '
        Me.GroupBox_Gcode.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Gcode.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Gcode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Gcode.Controls.Add(Me.txt_Debug)
        Me.GroupBox_Gcode.Controls.Add(Me.btn_ToolStop)
        Me.GroupBox_Gcode.Controls.Add(Me.btn_Down)
        Me.GroupBox_Gcode.Controls.Add(Me.btn_Up)
        Me.GroupBox_Gcode.Controls.Add(Me.btn_ZoomMinus)
        Me.GroupBox_Gcode.Controls.Add(Me.btn_ZoomPlus)
        Me.GroupBox_Gcode.Controls.Add(Me.RTB)
        Me.GroupBox_Gcode.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Gcode.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Gcode.Location = New System.Drawing.Point(2, 77)
        Me.GroupBox_Gcode.Name = "GroupBox_Gcode"
        Me.GroupBox_Gcode.Size = New System.Drawing.Size(297, 214)
        Me.GroupBox_Gcode.TabIndex = 500
        Me.GroupBox_Gcode.TabStop = False
        Me.GroupBox_Gcode.Text = " Gcode "
        '
        'txt_Debug
        '
        Me.txt_Debug.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_Debug.ArrowsIncrement = 0
        Me.txt_Debug.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Debug.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Debug.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Debug.Decimals = 3
        Me.txt_Debug.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Debug.ForeColor = System.Drawing.Color.Black
        Me.txt_Debug.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txt_Debug.Increment = 0
        Me.txt_Debug.Location = New System.Drawing.Point(193, 8)
        Me.txt_Debug.MaxLength = 9
        Me.txt_Debug.MaxValue = 999999999
        Me.txt_Debug.MinValue = -999999999
        Me.txt_Debug.Multiline = True
        Me.txt_Debug.Name = "txt_Debug"
        Me.txt_Debug.NumericValue = 0
        Me.txt_Debug.RectangleColor = System.Drawing.Color.White
        Me.txt_Debug.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Debug.RoundingStep = 0
        Me.txt_Debug.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txt_Debug.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Debug.Size = New System.Drawing.Size(93, 46)
        Me.txt_Debug.TabIndex = 644
        Me.txt_Debug.TabStop = False
        Me.txt_Debug.Text = "Debug"
        Me.txt_Debug.Visible = False
        Me.txt_Debug.WordWrap = False
        '
        'btn_ToolStop
        '
        Me.btn_ToolStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ToolStop.BackColor = System.Drawing.Color.Transparent
        Me.btn_ToolStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ToolStop.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ToolStop.CenterPtTracker = DesignerRectTracker1
        Me.btn_ToolStop.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ToolStop.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ToolStop.ColorFillBlendChecked = CBlendItems2
        Me.btn_ToolStop.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ToolStop.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ToolStop.Corners.All = CType(7, Short)
        Me.btn_ToolStop.Corners.LowerLeft = CType(7, Short)
        Me.btn_ToolStop.Corners.LowerRight = CType(7, Short)
        Me.btn_ToolStop.Corners.UpperLeft = CType(7, Short)
        Me.btn_ToolStop.Corners.UpperRight = CType(7, Short)
        Me.btn_ToolStop.DimFactorGray = -20
        Me.btn_ToolStop.DimFactorOver = 30
        Me.btn_ToolStop.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ToolStop.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ToolStop.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ToolStop.FocalPoints.CenterPtY = 1.0!
        Me.btn_ToolStop.FocalPoints.FocusPtX = 0.0!
        Me.btn_ToolStop.FocalPoints.FocusPtY = 0.0!
        Me.btn_ToolStop.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ToolStop.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ToolStop.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ToolStop.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ToolStop.FocusPtTracker = DesignerRectTracker2
        Me.btn_ToolStop.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ToolStop.ForeColor = System.Drawing.Color.Black
        Me.btn_ToolStop.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ToolStop.Image = Nothing
        Me.btn_ToolStop.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ToolStop.ImageIndex = 0
        Me.btn_ToolStop.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ToolStop.Location = New System.Drawing.Point(72, 190)
        Me.btn_ToolStop.Name = "btn_ToolStop"
        Me.btn_ToolStop.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ToolStop.SideImage = Nothing
        Me.btn_ToolStop.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ToolStop.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ToolStop.Size = New System.Drawing.Size(84, 21)
        Me.btn_ToolStop.TabIndex = 50
        Me.btn_ToolStop.Text = "Tool stop"
        Me.btn_ToolStop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ToolStop.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ToolStop.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_ToolStop.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ToolStop.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_Down
        '
        Me.btn_Down.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Down.BackColor = System.Drawing.Color.Transparent
        Me.btn_Down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Down.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Down.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Down.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Down.ColorFillBlendChecked = CBlendItems4
        Me.btn_Down.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Down.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Down.Corners.All = CType(7, Short)
        Me.btn_Down.Corners.LowerLeft = CType(7, Short)
        Me.btn_Down.Corners.LowerRight = CType(7, Short)
        Me.btn_Down.Corners.UpperLeft = CType(7, Short)
        Me.btn_Down.Corners.UpperRight = CType(7, Short)
        Me.btn_Down.DimFactorGray = -20
        Me.btn_Down.DimFactorOver = 30
        Me.btn_Down.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_Down.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_Down.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Down.FocalPoints.CenterPtY = 1.0!
        Me.btn_Down.FocalPoints.FocusPtX = 0.0!
        Me.btn_Down.FocalPoints.FocusPtY = 0.0!
        Me.btn_Down.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_Down.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_Down.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Down.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Down.FocusPtTracker = DesignerRectTracker4
        Me.btn_Down.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Down.ForeColor = System.Drawing.Color.Black
        Me.btn_Down.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Down.Image = Nothing
        Me.btn_Down.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Down.ImageIndex = 0
        Me.btn_Down.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Down.Location = New System.Drawing.Point(238, 190)
        Me.btn_Down.Name = "btn_Down"
        Me.btn_Down.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_Down.SideImage = Nothing
        Me.btn_Down.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Down.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Down.Size = New System.Drawing.Size(52, 21)
        Me.btn_Down.TabIndex = 40
        Me.btn_Down.Text = "Down"
        Me.btn_Down.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Down.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Down.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_Down.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Down.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_Up
        '
        Me.btn_Up.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Up.BackColor = System.Drawing.Color.Transparent
        Me.btn_Up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Up.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Up.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Up.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Up.ColorFillBlendChecked = CBlendItems6
        Me.btn_Up.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Up.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Up.Corners.All = CType(7, Short)
        Me.btn_Up.Corners.LowerLeft = CType(7, Short)
        Me.btn_Up.Corners.LowerRight = CType(7, Short)
        Me.btn_Up.Corners.UpperLeft = CType(7, Short)
        Me.btn_Up.Corners.UpperRight = CType(7, Short)
        Me.btn_Up.DimFactorGray = -20
        Me.btn_Up.DimFactorOver = 30
        Me.btn_Up.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_Up.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_Up.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Up.FocalPoints.CenterPtY = 1.0!
        Me.btn_Up.FocalPoints.FocusPtX = 0.0!
        Me.btn_Up.FocalPoints.FocusPtY = 0.0!
        Me.btn_Up.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_Up.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_Up.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Up.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Up.FocusPtTracker = DesignerRectTracker6
        Me.btn_Up.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Up.ForeColor = System.Drawing.Color.Black
        Me.btn_Up.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Up.Image = Nothing
        Me.btn_Up.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Up.ImageIndex = 0
        Me.btn_Up.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Up.Location = New System.Drawing.Point(183, 190)
        Me.btn_Up.Name = "btn_Up"
        Me.btn_Up.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_Up.SideImage = Nothing
        Me.btn_Up.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Up.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Up.Size = New System.Drawing.Size(52, 21)
        Me.btn_Up.TabIndex = 30
        Me.btn_Up.Text = "Up"
        Me.btn_Up.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Up.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Up.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_Up.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Up.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_ZoomMinus
        '
        Me.btn_ZoomMinus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ZoomMinus.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZoomMinus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZoomMinus.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomMinus.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZoomMinus.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZoomMinus.ColorFillBlendChecked = CBlendItems8
        Me.btn_ZoomMinus.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ZoomMinus.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ZoomMinus.Corners.All = CType(7, Short)
        Me.btn_ZoomMinus.Corners.LowerLeft = CType(7, Short)
        Me.btn_ZoomMinus.Corners.LowerRight = CType(7, Short)
        Me.btn_ZoomMinus.Corners.UpperLeft = CType(7, Short)
        Me.btn_ZoomMinus.Corners.UpperRight = CType(7, Short)
        Me.btn_ZoomMinus.DimFactorGray = -20
        Me.btn_ZoomMinus.DimFactorOver = 30
        Me.btn_ZoomMinus.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomMinus.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomMinus.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZoomMinus.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZoomMinus.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZoomMinus.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZoomMinus.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ZoomMinus.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ZoomMinus.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZoomMinus.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = True
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomMinus.FocusPtTracker = DesignerRectTracker8
        Me.btn_ZoomMinus.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZoomMinus.ForeColor = System.Drawing.Color.Black
        Me.btn_ZoomMinus.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZoomMinus.Image = Nothing
        Me.btn_ZoomMinus.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomMinus.ImageIndex = 0
        Me.btn_ZoomMinus.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZoomMinus.Location = New System.Drawing.Point(8, 190)
        Me.btn_ZoomMinus.Name = "btn_ZoomMinus"
        Me.btn_ZoomMinus.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZoomMinus.SideImage = Nothing
        Me.btn_ZoomMinus.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomMinus.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZoomMinus.Size = New System.Drawing.Size(28, 21)
        Me.btn_ZoomMinus.TabIndex = 10
        Me.btn_ZoomMinus.Text = "-"
        Me.btn_ZoomMinus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomMinus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZoomMinus.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ZoomMinus.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZoomMinus.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_ZoomPlus
        '
        Me.btn_ZoomPlus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ZoomPlus.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZoomPlus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZoomPlus.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomPlus.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZoomPlus.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZoomPlus.ColorFillBlendChecked = CBlendItems10
        Me.btn_ZoomPlus.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ZoomPlus.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ZoomPlus.Corners.All = CType(7, Short)
        Me.btn_ZoomPlus.Corners.LowerLeft = CType(7, Short)
        Me.btn_ZoomPlus.Corners.LowerRight = CType(7, Short)
        Me.btn_ZoomPlus.Corners.UpperLeft = CType(7, Short)
        Me.btn_ZoomPlus.Corners.UpperRight = CType(7, Short)
        Me.btn_ZoomPlus.DimFactorGray = -20
        Me.btn_ZoomPlus.DimFactorOver = 30
        Me.btn_ZoomPlus.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomPlus.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomPlus.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZoomPlus.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZoomPlus.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZoomPlus.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZoomPlus.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ZoomPlus.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ZoomPlus.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZoomPlus.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomPlus.FocusPtTracker = DesignerRectTracker10
        Me.btn_ZoomPlus.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZoomPlus.ForeColor = System.Drawing.Color.Black
        Me.btn_ZoomPlus.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZoomPlus.Image = Nothing
        Me.btn_ZoomPlus.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomPlus.ImageIndex = 0
        Me.btn_ZoomPlus.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZoomPlus.Location = New System.Drawing.Point(39, 190)
        Me.btn_ZoomPlus.Name = "btn_ZoomPlus"
        Me.btn_ZoomPlus.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZoomPlus.SideImage = Nothing
        Me.btn_ZoomPlus.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomPlus.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZoomPlus.Size = New System.Drawing.Size(28, 21)
        Me.btn_ZoomPlus.TabIndex = 20
        Me.btn_ZoomPlus.Text = "+"
        Me.btn_ZoomPlus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomPlus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZoomPlus.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_ZoomPlus.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZoomPlus.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'RTB
        '
        Me.RTB.AcceptsTab = True
        Me.RTB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RTB.BackColor = System.Drawing.Color.Gainsboro
        Me.RTB.ContextMenuStrip = Me.CTX_Edit
        Me.RTB.DetectUrls = False
        Me.RTB.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RTB.ForeColor = System.Drawing.Color.Black
        Me.RTB.HideSelection = False
        Me.RTB.Location = New System.Drawing.Point(8, 19)
        Me.RTB.Name = "RTB"
        Me.RTB.Size = New System.Drawing.Size(282, 167)
        Me.RTB.TabIndex = 1
        Me.RTB.TabStop = False
        Me.RTB.Text = ""
        Me.RTB.WordWrap = False
        '
        'CTX_Edit
        '
        Me.CTX_Edit.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CTX_Edit.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CTX_Edit_Find, Me.ToolStripSeparator11, Me.CTX_Edit_Cut, Me.CTX_Edit_Copy, Me.CTX_Edit_Paste, Me.CTX_Edit_Delete, Me.ToolStripSeparator8, Me.CTX_Edit_SelectAll, Me.ToolStripSeparator9, Me.CTX_Edit_Comment, Me.CTX_Edit_Uncomment, Me.ToolStripSeparator10, Me.CTX_Edit_Indent, Me.CTX_Edit_Unindent, Me.ToolStripSeparator12, Me.CTX_Edit_Undo, Me.CTX_Edit_Redo})
        Me.CTX_Edit.Name = "ContextMenuStrip1"
        Me.CTX_Edit.Size = New System.Drawing.Size(227, 370)
        '
        'CTX_Edit_Find
        '
        Me.CTX_Edit_Find.Image = CType(resources.GetObject("CTX_Edit_Find.Image"), System.Drawing.Image)
        Me.CTX_Edit_Find.Name = "CTX_Edit_Find"
        Me.CTX_Edit_Find.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Find.Text = "Find and Replace"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(223, 6)
        '
        'CTX_Edit_Cut
        '
        Me.CTX_Edit_Cut.Image = CType(resources.GetObject("CTX_Edit_Cut.Image"), System.Drawing.Image)
        Me.CTX_Edit_Cut.Name = "CTX_Edit_Cut"
        Me.CTX_Edit_Cut.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Cut.Text = "Cut"
        '
        'CTX_Edit_Copy
        '
        Me.CTX_Edit_Copy.Image = CType(resources.GetObject("CTX_Edit_Copy.Image"), System.Drawing.Image)
        Me.CTX_Edit_Copy.Name = "CTX_Edit_Copy"
        Me.CTX_Edit_Copy.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Copy.Text = "Copy"
        '
        'CTX_Edit_Paste
        '
        Me.CTX_Edit_Paste.Image = CType(resources.GetObject("CTX_Edit_Paste.Image"), System.Drawing.Image)
        Me.CTX_Edit_Paste.Name = "CTX_Edit_Paste"
        Me.CTX_Edit_Paste.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Paste.Text = "Paste"
        '
        'CTX_Edit_Delete
        '
        Me.CTX_Edit_Delete.Image = CType(resources.GetObject("CTX_Edit_Delete.Image"), System.Drawing.Image)
        Me.CTX_Edit_Delete.Name = "CTX_Edit_Delete"
        Me.CTX_Edit_Delete.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Delete.Text = "Delete"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(223, 6)
        '
        'CTX_Edit_SelectAll
        '
        Me.CTX_Edit_SelectAll.Image = CType(resources.GetObject("CTX_Edit_SelectAll.Image"), System.Drawing.Image)
        Me.CTX_Edit_SelectAll.Name = "CTX_Edit_SelectAll"
        Me.CTX_Edit_SelectAll.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_SelectAll.Text = "Select all"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(223, 6)
        '
        'CTX_Edit_Comment
        '
        Me.CTX_Edit_Comment.Image = CType(resources.GetObject("CTX_Edit_Comment.Image"), System.Drawing.Image)
        Me.CTX_Edit_Comment.Name = "CTX_Edit_Comment"
        Me.CTX_Edit_Comment.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Comment.Text = "Comment"
        '
        'CTX_Edit_Uncomment
        '
        Me.CTX_Edit_Uncomment.Image = CType(resources.GetObject("CTX_Edit_Uncomment.Image"), System.Drawing.Image)
        Me.CTX_Edit_Uncomment.Name = "CTX_Edit_Uncomment"
        Me.CTX_Edit_Uncomment.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Uncomment.Text = "Un-comment"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(223, 6)
        '
        'CTX_Edit_Indent
        '
        Me.CTX_Edit_Indent.Image = CType(resources.GetObject("CTX_Edit_Indent.Image"), System.Drawing.Image)
        Me.CTX_Edit_Indent.Name = "CTX_Edit_Indent"
        Me.CTX_Edit_Indent.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Indent.Text = "Indent"
        '
        'CTX_Edit_Unindent
        '
        Me.CTX_Edit_Unindent.Image = CType(resources.GetObject("CTX_Edit_Unindent.Image"), System.Drawing.Image)
        Me.CTX_Edit_Unindent.Name = "CTX_Edit_Unindent"
        Me.CTX_Edit_Unindent.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Unindent.Text = "Un-indent"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(223, 6)
        '
        'CTX_Edit_Undo
        '
        Me.CTX_Edit_Undo.Image = CType(resources.GetObject("CTX_Edit_Undo.Image"), System.Drawing.Image)
        Me.CTX_Edit_Undo.Name = "CTX_Edit_Undo"
        Me.CTX_Edit_Undo.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Undo.Text = "Undo   (CTRL Z)"
        '
        'CTX_Edit_Redo
        '
        Me.CTX_Edit_Redo.Image = CType(resources.GetObject("CTX_Edit_Redo.Image"), System.Drawing.Image)
        Me.CTX_Edit_Redo.Name = "CTX_Edit_Redo"
        Me.CTX_Edit_Redo.Size = New System.Drawing.Size(226, 28)
        Me.CTX_Edit_Redo.Text = "Redo   (CTRL Y)"
        '
        'GroupBox_Controls
        '
        Me.GroupBox_Controls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Controls.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Controls.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Controls.Controls.Add(Me.btn_GCodeStop)
        Me.GroupBox_Controls.Controls.Add(Me.btn_GcodePause)
        Me.GroupBox_Controls.Controls.Add(Me.btn_GcodeLoad)
        Me.GroupBox_Controls.Controls.Add(Me.btn_GcodeRewind)
        Me.GroupBox_Controls.Controls.Add(Me.btn_GcodeStart)
        Me.GroupBox_Controls.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Controls.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Controls.Location = New System.Drawing.Point(2, 296)
        Me.GroupBox_Controls.Name = "GroupBox_Controls"
        Me.GroupBox_Controls.Size = New System.Drawing.Size(297, 154)
        Me.GroupBox_Controls.TabIndex = 510
        Me.GroupBox_Controls.TabStop = False
        Me.GroupBox_Controls.Text = " Controls "
        '
        'btn_GCodeStop
        '
        Me.btn_GCodeStop.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GCodeStop.BackColor = System.Drawing.Color.Transparent
        Me.btn_GCodeStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GCodeStop.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GCodeStop.CenterPtTracker = DesignerRectTracker11
        Me.btn_GCodeStop.CheckButton = True
        Me.btn_GCodeStop.Checked = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GCodeStop.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GCodeStop.ColorFillBlendChecked = CBlendItems12
        Me.btn_GCodeStop.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_GCodeStop.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_GCodeStop.Corners.All = CType(12, Short)
        Me.btn_GCodeStop.Corners.LowerLeft = CType(12, Short)
        Me.btn_GCodeStop.Corners.LowerRight = CType(12, Short)
        Me.btn_GCodeStop.Corners.UpperLeft = CType(12, Short)
        Me.btn_GCodeStop.Corners.UpperRight = CType(12, Short)
        Me.btn_GCodeStop.DimFactorGray = -20
        Me.btn_GCodeStop.DimFactorOver = 30
        Me.btn_GCodeStop.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GCodeStop.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GCodeStop.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GCodeStop.FocalPoints.CenterPtY = 1.0!
        Me.btn_GCodeStop.FocalPoints.FocusPtX = 0.0!
        Me.btn_GCodeStop.FocalPoints.FocusPtY = 0.0!
        Me.btn_GCodeStop.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GCodeStop.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GCodeStop.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GCodeStop.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GCodeStop.FocusPtTracker = DesignerRectTracker12
        Me.btn_GCodeStop.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GCodeStop.ForeColor = System.Drawing.Color.Black
        Me.btn_GCodeStop.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GCodeStop.Image = Nothing
        Me.btn_GCodeStop.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GCodeStop.ImageIndex = 0
        Me.btn_GCodeStop.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GCodeStop.Location = New System.Drawing.Point(13, 110)
        Me.btn_GCodeStop.Name = "btn_GCodeStop"
        Me.btn_GCodeStop.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GCodeStop.SideImage = Nothing
        Me.btn_GCodeStop.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GCodeStop.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GCodeStop.Size = New System.Drawing.Size(273, 36)
        Me.btn_GCodeStop.TabIndex = 100
        Me.btn_GCodeStop.Text = "STOP"
        Me.btn_GCodeStop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GCodeStop.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GCodeStop.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_GCodeStop.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GCodeStop.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GcodePause
        '
        Me.btn_GcodePause.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GcodePause.BackColor = System.Drawing.Color.Transparent
        Me.btn_GcodePause.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GcodePause.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodePause.CenterPtTracker = DesignerRectTracker13
        Me.btn_GcodePause.CheckButton = True
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodePause.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodePause.ColorFillBlendChecked = CBlendItems14
        Me.btn_GcodePause.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_GcodePause.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_GcodePause.Corners.All = CType(12, Short)
        Me.btn_GcodePause.Corners.LowerLeft = CType(12, Short)
        Me.btn_GcodePause.Corners.LowerRight = CType(12, Short)
        Me.btn_GcodePause.Corners.UpperLeft = CType(12, Short)
        Me.btn_GcodePause.Corners.UpperRight = CType(12, Short)
        Me.btn_GcodePause.DimFactorGray = -20
        Me.btn_GcodePause.DimFactorOver = 30
        Me.btn_GcodePause.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodePause.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodePause.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodePause.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodePause.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodePause.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodePause.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GcodePause.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GcodePause.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodePause.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodePause.FocusPtTracker = DesignerRectTracker14
        Me.btn_GcodePause.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodePause.ForeColor = System.Drawing.Color.Black
        Me.btn_GcodePause.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GcodePause.Image = Nothing
        Me.btn_GcodePause.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodePause.ImageIndex = 0
        Me.btn_GcodePause.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodePause.Location = New System.Drawing.Point(13, 67)
        Me.btn_GcodePause.Name = "btn_GcodePause"
        Me.btn_GcodePause.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GcodePause.SideImage = Nothing
        Me.btn_GcodePause.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodePause.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodePause.Size = New System.Drawing.Size(134, 36)
        Me.btn_GcodePause.TabIndex = 80
        Me.btn_GcodePause.Text = "PAUSE"
        Me.btn_GcodePause.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodePause.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodePause.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_GcodePause.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GcodePause.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GcodeLoad
        '
        Me.btn_GcodeLoad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GcodeLoad.BackColor = System.Drawing.Color.Transparent
        Me.btn_GcodeLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GcodeLoad.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeLoad.CenterPtTracker = DesignerRectTracker15
        Me.btn_GcodeLoad.CheckButton = True
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeLoad.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems16.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeLoad.ColorFillBlendChecked = CBlendItems16
        Me.btn_GcodeLoad.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_GcodeLoad.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_GcodeLoad.Corners.All = CType(12, Short)
        Me.btn_GcodeLoad.Corners.LowerLeft = CType(12, Short)
        Me.btn_GcodeLoad.Corners.LowerRight = CType(12, Short)
        Me.btn_GcodeLoad.Corners.UpperLeft = CType(12, Short)
        Me.btn_GcodeLoad.Corners.UpperRight = CType(12, Short)
        Me.btn_GcodeLoad.DimFactorGray = -20
        Me.btn_GcodeLoad.DimFactorOver = 30
        Me.btn_GcodeLoad.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeLoad.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeLoad.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeLoad.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeLoad.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeLoad.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeLoad.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeLoad.FocusPtTracker = DesignerRectTracker16
        Me.btn_GcodeLoad.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeLoad.ForeColor = System.Drawing.Color.Black
        Me.btn_GcodeLoad.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GcodeLoad.Image = Nothing
        Me.btn_GcodeLoad.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.ImageIndex = 0
        Me.btn_GcodeLoad.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeLoad.Location = New System.Drawing.Point(152, 26)
        Me.btn_GcodeLoad.Name = "btn_GcodeLoad"
        Me.btn_GcodeLoad.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GcodeLoad.SideImage = Nothing
        Me.btn_GcodeLoad.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeLoad.Size = New System.Drawing.Size(134, 36)
        Me.btn_GcodeLoad.TabIndex = 70
        Me.btn_GcodeLoad.Text = "Load"
        Me.btn_GcodeLoad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeLoad.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeLoad.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_GcodeLoad.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GcodeLoad.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GcodeRewind
        '
        Me.btn_GcodeRewind.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GcodeRewind.BackColor = System.Drawing.Color.Transparent
        Me.btn_GcodeRewind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GcodeRewind.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRewind.CenterPtTracker = DesignerRectTracker17
        Me.btn_GcodeRewind.CheckButton = True
        CBlendItems17.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems17.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeRewind.ColorFillBlend = CBlendItems17
        CBlendItems18.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems18.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeRewind.ColorFillBlendChecked = CBlendItems18
        Me.btn_GcodeRewind.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_GcodeRewind.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_GcodeRewind.Corners.All = CType(12, Short)
        Me.btn_GcodeRewind.Corners.LowerLeft = CType(12, Short)
        Me.btn_GcodeRewind.Corners.LowerRight = CType(12, Short)
        Me.btn_GcodeRewind.Corners.UpperLeft = CType(12, Short)
        Me.btn_GcodeRewind.Corners.UpperRight = CType(12, Short)
        Me.btn_GcodeRewind.DimFactorGray = -20
        Me.btn_GcodeRewind.DimFactorOver = 30
        Me.btn_GcodeRewind.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRewind.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeRewind.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeRewind.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeRewind.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeRewind.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeRewind.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GcodeRewind.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GcodeRewind.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeRewind.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeRewind.FocusPtTracker = DesignerRectTracker18
        Me.btn_GcodeRewind.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeRewind.ForeColor = System.Drawing.Color.Black
        Me.btn_GcodeRewind.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GcodeRewind.Image = Nothing
        Me.btn_GcodeRewind.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.ImageIndex = 0
        Me.btn_GcodeRewind.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeRewind.Location = New System.Drawing.Point(152, 67)
        Me.btn_GcodeRewind.Name = "btn_GcodeRewind"
        Me.btn_GcodeRewind.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GcodeRewind.SideImage = Nothing
        Me.btn_GcodeRewind.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeRewind.Size = New System.Drawing.Size(134, 36)
        Me.btn_GcodeRewind.TabIndex = 90
        Me.btn_GcodeRewind.Text = "Rewind"
        Me.btn_GcodeRewind.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeRewind.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeRewind.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_GcodeRewind.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GcodeRewind.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GcodeStart
        '
        Me.btn_GcodeStart.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GcodeStart.BackColor = System.Drawing.Color.Transparent
        Me.btn_GcodeStart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GcodeStart.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeStart.CenterPtTracker = DesignerRectTracker19
        Me.btn_GcodeStart.CheckButton = True
        CBlendItems19.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems19.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GcodeStart.ColorFillBlend = CBlendItems19
        CBlendItems20.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems20.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GcodeStart.ColorFillBlendChecked = CBlendItems20
        Me.btn_GcodeStart.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_GcodeStart.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_GcodeStart.Corners.All = CType(12, Short)
        Me.btn_GcodeStart.Corners.LowerLeft = CType(12, Short)
        Me.btn_GcodeStart.Corners.LowerRight = CType(12, Short)
        Me.btn_GcodeStart.Corners.UpperLeft = CType(12, Short)
        Me.btn_GcodeStart.Corners.UpperRight = CType(12, Short)
        Me.btn_GcodeStart.DimFactorGray = -20
        Me.btn_GcodeStart.DimFactorOver = 30
        Me.btn_GcodeStart.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeStart.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GcodeStart.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GcodeStart.FocalPoints.CenterPtY = 1.0!
        Me.btn_GcodeStart.FocalPoints.FocusPtX = 0.0!
        Me.btn_GcodeStart.FocalPoints.FocusPtY = 0.0!
        Me.btn_GcodeStart.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_GcodeStart.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_GcodeStart.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GcodeStart.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GcodeStart.FocusPtTracker = DesignerRectTracker20
        Me.btn_GcodeStart.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GcodeStart.ForeColor = System.Drawing.Color.Black
        Me.btn_GcodeStart.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GcodeStart.Image = Nothing
        Me.btn_GcodeStart.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeStart.ImageIndex = 0
        Me.btn_GcodeStart.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GcodeStart.Location = New System.Drawing.Point(12, 26)
        Me.btn_GcodeStart.Name = "btn_GcodeStart"
        Me.btn_GcodeStart.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GcodeStart.SideImage = Nothing
        Me.btn_GcodeStart.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeStart.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GcodeStart.Size = New System.Drawing.Size(134, 36)
        Me.btn_GcodeStart.TabIndex = 60
        Me.btn_GcodeStart.Text = "START"
        Me.btn_GcodeStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GcodeStart.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GcodeStart.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_GcodeStart.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GcodeStart.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'GroupBox_Motors
        '
        Me.GroupBox_Motors.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Motors.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Motors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Motors.Controls.Add(Me.txt_EditCoord)
        Me.GroupBox_Motors.Controls.Add(Me.btn_LookAhead)
        Me.GroupBox_Motors.Controls.Add(Me.txt_Speed)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_Speed)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_Rapid)
        Me.GroupBox_Motors.Controls.Add(Me.btn_FeedSpeedLocked)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_CoordB)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_CoordA)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_CoordZ)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_CoordY)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_CoordX)
        Me.GroupBox_Motors.Controls.Add(Me.btn_ZeroB)
        Me.GroupBox_Motors.Controls.Add(Me.txt_MaxError)
        Me.GroupBox_Motors.Controls.Add(Me.btn_ZeroA)
        Me.GroupBox_Motors.Controls.Add(Me.btn_ZeroZ)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_MaxErr)
        Me.GroupBox_Motors.Controls.Add(Me.btn_ZeroY)
        Me.GroupBox_Motors.Controls.Add(Me.txt_Feed)
        Me.GroupBox_Motors.Controls.Add(Me.btn_ZeroX)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_Feed)
        Me.GroupBox_Motors.Controls.Add(Me.txt_Rapid)
        Me.GroupBox_Motors.Controls.Add(Me.txt_CtrlJog)
        Me.GroupBox_Motors.Controls.Add(Me.lbl_Jog)
        Me.GroupBox_Motors.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Motors.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Motors.Location = New System.Drawing.Point(0, 204)
        Me.GroupBox_Motors.Name = "GroupBox_Motors"
        Me.GroupBox_Motors.Size = New System.Drawing.Size(460, 245)
        Me.GroupBox_Motors.TabIndex = 530
        Me.GroupBox_Motors.TabStop = False
        Me.GroupBox_Motors.Text = " Motors "
        '
        'txt_EditCoord
        '
        Me.txt_EditCoord.ArrowsIncrement = 0
        Me.txt_EditCoord.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_EditCoord.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_EditCoord.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_EditCoord.Decimals = 3
        Me.txt_EditCoord.Font = New System.Drawing.Font("Arial", 25.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EditCoord.ForeColor = System.Drawing.Color.Black
        Me.txt_EditCoord.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txt_EditCoord.Increment = 0
        Me.txt_EditCoord.Location = New System.Drawing.Point(398, 9)
        Me.txt_EditCoord.MaxLength = 9
        Me.txt_EditCoord.MaxValue = 999999999
        Me.txt_EditCoord.MinValue = -999999999
        Me.txt_EditCoord.Multiline = True
        Me.txt_EditCoord.Name = "txt_EditCoord"
        Me.txt_EditCoord.NumericValue = 0
        Me.txt_EditCoord.RectangleColor = System.Drawing.Color.White
        Me.txt_EditCoord.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_EditCoord.RoundingStep = 0
        Me.txt_EditCoord.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_EditCoord.Size = New System.Drawing.Size(46, 38)
        Me.txt_EditCoord.TabIndex = 643
        Me.txt_EditCoord.TabStop = False
        Me.txt_EditCoord.Text = "0"
        Me.txt_EditCoord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_EditCoord.Visible = False
        Me.txt_EditCoord.WordWrap = False
        '
        'btn_LookAhead
        '
        Me.btn_LookAhead.BackColor = System.Drawing.Color.Transparent
        Me.btn_LookAhead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_LookAhead.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LookAhead.CenterPtTracker = DesignerRectTracker21
        Me.btn_LookAhead.CheckButton = True
        CBlendItems21.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems21.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_LookAhead.ColorFillBlend = CBlendItems21
        CBlendItems22.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems22.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_LookAhead.ColorFillBlendChecked = CBlendItems22
        Me.btn_LookAhead.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_LookAhead.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_LookAhead.Corners.All = CType(7, Short)
        Me.btn_LookAhead.Corners.LowerLeft = CType(7, Short)
        Me.btn_LookAhead.Corners.LowerRight = CType(7, Short)
        Me.btn_LookAhead.Corners.UpperLeft = CType(7, Short)
        Me.btn_LookAhead.Corners.UpperRight = CType(7, Short)
        Me.btn_LookAhead.DimFactorGray = -20
        Me.btn_LookAhead.DimFactorOver = 30
        Me.btn_LookAhead.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_LookAhead.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_LookAhead.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_LookAhead.FocalPoints.CenterPtY = 1.0!
        Me.btn_LookAhead.FocalPoints.FocusPtX = 0.0!
        Me.btn_LookAhead.FocalPoints.FocusPtY = 0.0!
        Me.btn_LookAhead.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_LookAhead.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_LookAhead.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_LookAhead.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LookAhead.FocusPtTracker = DesignerRectTracker22
        Me.btn_LookAhead.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LookAhead.ForeColor = System.Drawing.Color.Black
        Me.btn_LookAhead.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_LookAhead.Image = Nothing
        Me.btn_LookAhead.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LookAhead.ImageIndex = 0
        Me.btn_LookAhead.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_LookAhead.Location = New System.Drawing.Point(8, 145)
        Me.btn_LookAhead.Name = "btn_LookAhead"
        Me.btn_LookAhead.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_LookAhead.SideImage = Nothing
        Me.btn_LookAhead.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LookAhead.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_LookAhead.Size = New System.Drawing.Size(189, 26)
        Me.btn_LookAhead.TabIndex = 641
        Me.btn_LookAhead.Text = "Look Ahead disabled"
        Me.btn_LookAhead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LookAhead.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_LookAhead.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_LookAhead.TextShadow = System.Drawing.Color.Transparent
        Me.btn_LookAhead.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'txt_Speed
        '
        Me.txt_Speed.ArrowsIncrement = 100
        Me.txt_Speed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Speed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Speed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Speed.DimFactorGray = -10
        Me.txt_Speed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Speed.ForeColor = System.Drawing.Color.Black
        Me.txt_Speed.Increment = 10
        Me.txt_Speed.Location = New System.Drawing.Point(127, 85)
        Me.txt_Speed.MaxValue = 99000
        Me.txt_Speed.MinValue = 0
        Me.txt_Speed.Name = "txt_Speed"
        Me.txt_Speed.NumericValue = 0
        Me.txt_Speed.RectangleColor = System.Drawing.Color.White
        Me.txt_Speed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Speed.RoundingStep = 0
        Me.txt_Speed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Speed.Size = New System.Drawing.Size(70, 25)
        Me.txt_Speed.SuppressZeros = True
        Me.txt_Speed.TabIndex = 130
        Me.txt_Speed.TabStop = False
        Me.txt_Speed.Text = "0"
        Me.txt_Speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_Speed
        '
        Me.lbl_Speed.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Speed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Speed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Speed.Location = New System.Drawing.Point(8, 84)
        Me.lbl_Speed.Name = "lbl_Speed"
        Me.lbl_Speed.Size = New System.Drawing.Size(118, 26)
        Me.lbl_Speed.TabIndex = 560
        Me.lbl_Speed.Text = "Speed (RPM)"
        Me.lbl_Speed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_Rapid
        '
        Me.lbl_Rapid.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Rapid.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Rapid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Rapid.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_Rapid.Location = New System.Drawing.Point(8, 23)
        Me.lbl_Rapid.Name = "lbl_Rapid"
        Me.lbl_Rapid.Size = New System.Drawing.Size(118, 26)
        Me.lbl_Rapid.TabIndex = 540
        Me.lbl_Rapid.Text = "Rapid (mm/m)"
        Me.lbl_Rapid.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_FeedSpeedLocked
        '
        Me.btn_FeedSpeedLocked.BackColor = System.Drawing.Color.Transparent
        Me.btn_FeedSpeedLocked.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_FeedSpeedLocked.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_FeedSpeedLocked.CenterPtTracker = DesignerRectTracker23
        Me.btn_FeedSpeedLocked.CheckButton = True
        CBlendItems23.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems23.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_FeedSpeedLocked.ColorFillBlend = CBlendItems23
        CBlendItems24.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems24.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_FeedSpeedLocked.ColorFillBlendChecked = CBlendItems24
        Me.btn_FeedSpeedLocked.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_FeedSpeedLocked.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_FeedSpeedLocked.Corners.All = CType(7, Short)
        Me.btn_FeedSpeedLocked.Corners.LowerLeft = CType(7, Short)
        Me.btn_FeedSpeedLocked.Corners.LowerRight = CType(7, Short)
        Me.btn_FeedSpeedLocked.Corners.UpperLeft = CType(7, Short)
        Me.btn_FeedSpeedLocked.Corners.UpperRight = CType(7, Short)
        Me.btn_FeedSpeedLocked.DimFactorGray = -20
        Me.btn_FeedSpeedLocked.DimFactorOver = 30
        Me.btn_FeedSpeedLocked.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_FeedSpeedLocked.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_FeedSpeedLocked.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_FeedSpeedLocked.FocalPoints.CenterPtY = 1.0!
        Me.btn_FeedSpeedLocked.FocalPoints.FocusPtX = 0.0!
        Me.btn_FeedSpeedLocked.FocalPoints.FocusPtY = 0.0!
        Me.btn_FeedSpeedLocked.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_FeedSpeedLocked.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_FeedSpeedLocked.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_FeedSpeedLocked.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_FeedSpeedLocked.FocusPtTracker = DesignerRectTracker24
        Me.btn_FeedSpeedLocked.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_FeedSpeedLocked.ForeColor = System.Drawing.Color.Black
        Me.btn_FeedSpeedLocked.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_FeedSpeedLocked.Image = Nothing
        Me.btn_FeedSpeedLocked.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_FeedSpeedLocked.ImageIndex = 0
        Me.btn_FeedSpeedLocked.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_FeedSpeedLocked.Location = New System.Drawing.Point(8, 115)
        Me.btn_FeedSpeedLocked.Name = "btn_FeedSpeedLocked"
        Me.btn_FeedSpeedLocked.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_FeedSpeedLocked.SideImage = Nothing
        Me.btn_FeedSpeedLocked.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_FeedSpeedLocked.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_FeedSpeedLocked.Size = New System.Drawing.Size(189, 26)
        Me.btn_FeedSpeedLocked.TabIndex = 140
        Me.btn_FeedSpeedLocked.Text = "Feed & Speed from GCode"
        Me.btn_FeedSpeedLocked.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_FeedSpeedLocked.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_FeedSpeedLocked.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_FeedSpeedLocked.TextShadow = System.Drawing.Color.Transparent
        Me.btn_FeedSpeedLocked.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'lbl_CoordB
        '
        Me.lbl_CoordB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_CoordB.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.lbl_CoordB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_CoordB.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CoordB.ForeColor = System.Drawing.Color.Black
        Me.lbl_CoordB.Location = New System.Drawing.Point(268, 195)
        Me.lbl_CoordB.Name = "lbl_CoordB"
        Me.lbl_CoordB.Size = New System.Drawing.Size(181, 40)
        Me.lbl_CoordB.TabIndex = 640
        Me.lbl_CoordB.Text = "0.000"
        Me.lbl_CoordB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_CoordA
        '
        Me.lbl_CoordA.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_CoordA.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.lbl_CoordA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_CoordA.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CoordA.ForeColor = System.Drawing.Color.Black
        Me.lbl_CoordA.Location = New System.Drawing.Point(268, 152)
        Me.lbl_CoordA.Name = "lbl_CoordA"
        Me.lbl_CoordA.Size = New System.Drawing.Size(181, 40)
        Me.lbl_CoordA.TabIndex = 630
        Me.lbl_CoordA.Text = "0.000"
        Me.lbl_CoordA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_CoordZ
        '
        Me.lbl_CoordZ.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_CoordZ.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.lbl_CoordZ.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_CoordZ.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CoordZ.ForeColor = System.Drawing.Color.Black
        Me.lbl_CoordZ.Location = New System.Drawing.Point(268, 109)
        Me.lbl_CoordZ.Name = "lbl_CoordZ"
        Me.lbl_CoordZ.Size = New System.Drawing.Size(181, 40)
        Me.lbl_CoordZ.TabIndex = 620
        Me.lbl_CoordZ.Text = "0.000"
        Me.lbl_CoordZ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_CoordY
        '
        Me.lbl_CoordY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_CoordY.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.lbl_CoordY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_CoordY.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CoordY.ForeColor = System.Drawing.Color.Black
        Me.lbl_CoordY.Location = New System.Drawing.Point(268, 66)
        Me.lbl_CoordY.Name = "lbl_CoordY"
        Me.lbl_CoordY.Size = New System.Drawing.Size(181, 40)
        Me.lbl_CoordY.TabIndex = 610
        Me.lbl_CoordY.Text = "0.000"
        Me.lbl_CoordY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_CoordX
        '
        Me.lbl_CoordX.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_CoordX.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.lbl_CoordX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_CoordX.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CoordX.ForeColor = System.Drawing.Color.Black
        Me.lbl_CoordX.Location = New System.Drawing.Point(268, 23)
        Me.lbl_CoordX.Name = "lbl_CoordX"
        Me.lbl_CoordX.Size = New System.Drawing.Size(181, 40)
        Me.lbl_CoordX.TabIndex = 600
        Me.lbl_CoordX.Text = "0.000"
        Me.lbl_CoordX.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_ZeroB
        '
        Me.btn_ZeroB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ZeroB.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZeroB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZeroB.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker25.IsActive = False
        DesignerRectTracker25.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker25.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroB.CenterPtTracker = DesignerRectTracker25
        Me.btn_ZeroB.CheckButton = True
        CBlendItems25.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems25.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZeroB.ColorFillBlend = CBlendItems25
        CBlendItems26.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems26.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZeroB.ColorFillBlendChecked = CBlendItems26
        Me.btn_ZeroB.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ZeroB.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ZeroB.Corners.All = CType(15, Short)
        Me.btn_ZeroB.Corners.LowerLeft = CType(15, Short)
        Me.btn_ZeroB.Corners.LowerRight = CType(15, Short)
        Me.btn_ZeroB.Corners.UpperLeft = CType(15, Short)
        Me.btn_ZeroB.Corners.UpperRight = CType(15, Short)
        Me.btn_ZeroB.DimFactorGray = -20
        Me.btn_ZeroB.DimFactorOver = 30
        Me.btn_ZeroB.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroB.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroB.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZeroB.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZeroB.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZeroB.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZeroB.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ZeroB.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ZeroB.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZeroB.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker26.IsActive = False
        DesignerRectTracker26.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker26.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroB.FocusPtTracker = DesignerRectTracker26
        Me.btn_ZeroB.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZeroB.ForeColor = System.Drawing.Color.Black
        Me.btn_ZeroB.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZeroB.Image = Nothing
        Me.btn_ZeroB.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroB.ImageIndex = 0
        Me.btn_ZeroB.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZeroB.Location = New System.Drawing.Point(220, 197)
        Me.btn_ZeroB.Name = "btn_ZeroB"
        Me.btn_ZeroB.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZeroB.SideImage = Nothing
        Me.btn_ZeroB.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroB.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZeroB.Size = New System.Drawing.Size(43, 37)
        Me.btn_ZeroB.TabIndex = 220
        Me.btn_ZeroB.Text = "B"
        Me.btn_ZeroB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZeroB.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_ZeroB.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZeroB.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'txt_MaxError
        '
        Me.txt_MaxError.ArrowsIncrement = 0.01
        Me.txt_MaxError.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_MaxError.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_MaxError.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxError.Decimals = 3
        Me.txt_MaxError.DimFactorGray = -10
        Me.txt_MaxError.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxError.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxError.Increment = 0.002
        Me.txt_MaxError.Location = New System.Drawing.Point(127, 178)
        Me.txt_MaxError.MaxValue = 5
        Me.txt_MaxError.MinValue = 0
        Me.txt_MaxError.Name = "txt_MaxError"
        Me.txt_MaxError.NumericValue = 1
        Me.txt_MaxError.NumericValueInteger = 1
        Me.txt_MaxError.RectangleColor = System.Drawing.Color.White
        Me.txt_MaxError.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_MaxError.RoundingStep = 0
        Me.txt_MaxError.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_MaxError.Size = New System.Drawing.Size(70, 25)
        Me.txt_MaxError.SuppressZeros = True
        Me.txt_MaxError.TabIndex = 150
        Me.txt_MaxError.TabStop = False
        Me.txt_MaxError.Text = "1"
        Me.txt_MaxError.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_ZeroA
        '
        Me.btn_ZeroA.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ZeroA.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZeroA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZeroA.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker27.IsActive = False
        DesignerRectTracker27.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker27.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroA.CenterPtTracker = DesignerRectTracker27
        Me.btn_ZeroA.CheckButton = True
        CBlendItems27.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems27.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZeroA.ColorFillBlend = CBlendItems27
        CBlendItems28.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems28.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZeroA.ColorFillBlendChecked = CBlendItems28
        Me.btn_ZeroA.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ZeroA.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ZeroA.Corners.All = CType(15, Short)
        Me.btn_ZeroA.Corners.LowerLeft = CType(15, Short)
        Me.btn_ZeroA.Corners.LowerRight = CType(15, Short)
        Me.btn_ZeroA.Corners.UpperLeft = CType(15, Short)
        Me.btn_ZeroA.Corners.UpperRight = CType(15, Short)
        Me.btn_ZeroA.DimFactorGray = -20
        Me.btn_ZeroA.DimFactorOver = 30
        Me.btn_ZeroA.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroA.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroA.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZeroA.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZeroA.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZeroA.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZeroA.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ZeroA.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ZeroA.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZeroA.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker28.IsActive = False
        DesignerRectTracker28.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker28.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroA.FocusPtTracker = DesignerRectTracker28
        Me.btn_ZeroA.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZeroA.ForeColor = System.Drawing.Color.Black
        Me.btn_ZeroA.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZeroA.Image = Nothing
        Me.btn_ZeroA.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroA.ImageIndex = 0
        Me.btn_ZeroA.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZeroA.Location = New System.Drawing.Point(220, 154)
        Me.btn_ZeroA.Name = "btn_ZeroA"
        Me.btn_ZeroA.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZeroA.SideImage = Nothing
        Me.btn_ZeroA.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroA.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZeroA.Size = New System.Drawing.Size(43, 37)
        Me.btn_ZeroA.TabIndex = 210
        Me.btn_ZeroA.Text = "A"
        Me.btn_ZeroA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroA.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZeroA.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_ZeroA.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZeroA.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_ZeroZ
        '
        Me.btn_ZeroZ.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ZeroZ.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZeroZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZeroZ.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker29.IsActive = False
        DesignerRectTracker29.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker29.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroZ.CenterPtTracker = DesignerRectTracker29
        Me.btn_ZeroZ.CheckButton = True
        CBlendItems29.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems29.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZeroZ.ColorFillBlend = CBlendItems29
        CBlendItems30.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems30.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZeroZ.ColorFillBlendChecked = CBlendItems30
        Me.btn_ZeroZ.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ZeroZ.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ZeroZ.Corners.All = CType(15, Short)
        Me.btn_ZeroZ.Corners.LowerLeft = CType(15, Short)
        Me.btn_ZeroZ.Corners.LowerRight = CType(15, Short)
        Me.btn_ZeroZ.Corners.UpperLeft = CType(15, Short)
        Me.btn_ZeroZ.Corners.UpperRight = CType(15, Short)
        Me.btn_ZeroZ.DimFactorGray = -20
        Me.btn_ZeroZ.DimFactorOver = 30
        Me.btn_ZeroZ.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroZ.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroZ.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZeroZ.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZeroZ.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZeroZ.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZeroZ.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ZeroZ.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ZeroZ.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZeroZ.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker30.IsActive = False
        DesignerRectTracker30.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker30.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroZ.FocusPtTracker = DesignerRectTracker30
        Me.btn_ZeroZ.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZeroZ.ForeColor = System.Drawing.Color.Black
        Me.btn_ZeroZ.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZeroZ.Image = Nothing
        Me.btn_ZeroZ.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroZ.ImageIndex = 0
        Me.btn_ZeroZ.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZeroZ.Location = New System.Drawing.Point(220, 111)
        Me.btn_ZeroZ.Name = "btn_ZeroZ"
        Me.btn_ZeroZ.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZeroZ.SideImage = Nothing
        Me.btn_ZeroZ.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroZ.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZeroZ.Size = New System.Drawing.Size(43, 37)
        Me.btn_ZeroZ.TabIndex = 200
        Me.btn_ZeroZ.Text = "Z"
        Me.btn_ZeroZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroZ.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZeroZ.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_ZeroZ.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZeroZ.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'lbl_MaxErr
        '
        Me.lbl_MaxErr.BackColor = System.Drawing.Color.Transparent
        Me.lbl_MaxErr.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MaxErr.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_MaxErr.Location = New System.Drawing.Point(8, 177)
        Me.lbl_MaxErr.Name = "lbl_MaxErr"
        Me.lbl_MaxErr.Size = New System.Drawing.Size(118, 26)
        Me.lbl_MaxErr.TabIndex = 570
        Me.lbl_MaxErr.Text = "Max err. (mm)"
        Me.lbl_MaxErr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_ZeroY
        '
        Me.btn_ZeroY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ZeroY.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZeroY.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZeroY.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker31.IsActive = False
        DesignerRectTracker31.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker31.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroY.CenterPtTracker = DesignerRectTracker31
        Me.btn_ZeroY.CheckButton = True
        CBlendItems31.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems31.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZeroY.ColorFillBlend = CBlendItems31
        CBlendItems32.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems32.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZeroY.ColorFillBlendChecked = CBlendItems32
        Me.btn_ZeroY.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ZeroY.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ZeroY.Corners.All = CType(15, Short)
        Me.btn_ZeroY.Corners.LowerLeft = CType(15, Short)
        Me.btn_ZeroY.Corners.LowerRight = CType(15, Short)
        Me.btn_ZeroY.Corners.UpperLeft = CType(15, Short)
        Me.btn_ZeroY.Corners.UpperRight = CType(15, Short)
        Me.btn_ZeroY.DimFactorGray = -20
        Me.btn_ZeroY.DimFactorOver = 30
        Me.btn_ZeroY.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroY.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroY.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZeroY.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZeroY.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZeroY.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZeroY.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ZeroY.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ZeroY.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZeroY.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker32.IsActive = False
        DesignerRectTracker32.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker32.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroY.FocusPtTracker = DesignerRectTracker32
        Me.btn_ZeroY.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZeroY.ForeColor = System.Drawing.Color.Black
        Me.btn_ZeroY.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZeroY.Image = Nothing
        Me.btn_ZeroY.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroY.ImageIndex = 0
        Me.btn_ZeroY.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZeroY.Location = New System.Drawing.Point(220, 68)
        Me.btn_ZeroY.Name = "btn_ZeroY"
        Me.btn_ZeroY.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZeroY.SideImage = Nothing
        Me.btn_ZeroY.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroY.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZeroY.Size = New System.Drawing.Size(43, 37)
        Me.btn_ZeroY.TabIndex = 190
        Me.btn_ZeroY.Text = "Y"
        Me.btn_ZeroY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroY.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZeroY.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_ZeroY.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZeroY.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'txt_Feed
        '
        Me.txt_Feed.ArrowsIncrement = 100
        Me.txt_Feed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Feed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Feed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Feed.DimFactorGray = -10
        Me.txt_Feed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Feed.ForeColor = System.Drawing.Color.Black
        Me.txt_Feed.Increment = 100
        Me.txt_Feed.Location = New System.Drawing.Point(127, 54)
        Me.txt_Feed.MaxValue = 99000
        Me.txt_Feed.MinValue = 0
        Me.txt_Feed.Name = "txt_Feed"
        Me.txt_Feed.NumericValue = 500
        Me.txt_Feed.NumericValueInteger = 500
        Me.txt_Feed.RectangleColor = System.Drawing.Color.White
        Me.txt_Feed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Feed.RoundingStep = 0
        Me.txt_Feed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Feed.Size = New System.Drawing.Size(70, 25)
        Me.txt_Feed.SuppressZeros = True
        Me.txt_Feed.TabIndex = 120
        Me.txt_Feed.TabStop = False
        Me.txt_Feed.Text = "500"
        Me.txt_Feed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_ZeroX
        '
        Me.btn_ZeroX.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ZeroX.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZeroX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZeroX.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker33.IsActive = False
        DesignerRectTracker33.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker33.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroX.CenterPtTracker = DesignerRectTracker33
        Me.btn_ZeroX.CheckButton = True
        CBlendItems33.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems33.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZeroX.ColorFillBlend = CBlendItems33
        CBlendItems34.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems34.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZeroX.ColorFillBlendChecked = CBlendItems34
        Me.btn_ZeroX.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ZeroX.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ZeroX.Corners.All = CType(15, Short)
        Me.btn_ZeroX.Corners.LowerLeft = CType(15, Short)
        Me.btn_ZeroX.Corners.LowerRight = CType(15, Short)
        Me.btn_ZeroX.Corners.UpperLeft = CType(15, Short)
        Me.btn_ZeroX.Corners.UpperRight = CType(15, Short)
        Me.btn_ZeroX.DimFactorGray = -20
        Me.btn_ZeroX.DimFactorOver = 30
        Me.btn_ZeroX.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroX.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZeroX.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZeroX.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZeroX.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZeroX.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZeroX.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ZeroX.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ZeroX.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZeroX.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker34.IsActive = False
        DesignerRectTracker34.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker34.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZeroX.FocusPtTracker = DesignerRectTracker34
        Me.btn_ZeroX.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZeroX.ForeColor = System.Drawing.Color.Black
        Me.btn_ZeroX.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZeroX.Image = Nothing
        Me.btn_ZeroX.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroX.ImageIndex = 0
        Me.btn_ZeroX.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZeroX.Location = New System.Drawing.Point(220, 25)
        Me.btn_ZeroX.Name = "btn_ZeroX"
        Me.btn_ZeroX.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZeroX.SideImage = Nothing
        Me.btn_ZeroX.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroX.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZeroX.Size = New System.Drawing.Size(43, 37)
        Me.btn_ZeroX.TabIndex = 180
        Me.btn_ZeroX.Text = "X"
        Me.btn_ZeroX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZeroX.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZeroX.TextMargin = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btn_ZeroX.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZeroX.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'lbl_Feed
        '
        Me.lbl_Feed.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Feed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Feed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Feed.Location = New System.Drawing.Point(8, 53)
        Me.lbl_Feed.Name = "lbl_Feed"
        Me.lbl_Feed.Size = New System.Drawing.Size(118, 26)
        Me.lbl_Feed.TabIndex = 550
        Me.lbl_Feed.Text = "Feed (mm/m)"
        Me.lbl_Feed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Rapid
        '
        Me.txt_Rapid.ArrowsIncrement = 100
        Me.txt_Rapid.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Rapid.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Rapid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapid.DimFactorGray = -10
        Me.txt_Rapid.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapid.ForeColor = System.Drawing.Color.Black
        Me.txt_Rapid.Increment = 100
        Me.txt_Rapid.Location = New System.Drawing.Point(127, 24)
        Me.txt_Rapid.MaxValue = 99000
        Me.txt_Rapid.MinValue = 0
        Me.txt_Rapid.Name = "txt_Rapid"
        Me.txt_Rapid.NumericValue = 500
        Me.txt_Rapid.NumericValueInteger = 500
        Me.txt_Rapid.RectangleColor = System.Drawing.Color.White
        Me.txt_Rapid.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Rapid.RoundingStep = 0
        Me.txt_Rapid.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Rapid.Size = New System.Drawing.Size(70, 25)
        Me.txt_Rapid.SuppressZeros = True
        Me.txt_Rapid.TabIndex = 110
        Me.txt_Rapid.TabStop = False
        Me.txt_Rapid.Text = "500"
        Me.txt_Rapid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_CtrlJog
        '
        Me.txt_CtrlJog.ArrowsIncrement = 0.01
        Me.txt_CtrlJog.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CtrlJog.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CtrlJog.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CtrlJog.Decimals = 2
        Me.txt_CtrlJog.DimFactorGray = -10
        Me.txt_CtrlJog.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CtrlJog.ForeColor = System.Drawing.Color.Black
        Me.txt_CtrlJog.Increment = 0.005
        Me.txt_CtrlJog.Location = New System.Drawing.Point(127, 209)
        Me.txt_CtrlJog.MaxValue = 100
        Me.txt_CtrlJog.MinValue = 0.01
        Me.txt_CtrlJog.Name = "txt_CtrlJog"
        Me.txt_CtrlJog.NumericValue = 0.1
        Me.txt_CtrlJog.RectangleColor = System.Drawing.Color.White
        Me.txt_CtrlJog.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CtrlJog.RoundingStep = 0
        Me.txt_CtrlJog.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CtrlJog.Size = New System.Drawing.Size(70, 25)
        Me.txt_CtrlJog.SuppressZeros = True
        Me.txt_CtrlJog.TabIndex = 160
        Me.txt_CtrlJog.TabStop = False
        Me.txt_CtrlJog.Text = "0.1"
        Me.txt_CtrlJog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_Jog
        '
        Me.lbl_Jog.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Jog.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Jog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Jog.Location = New System.Drawing.Point(8, 208)
        Me.lbl_Jog.Name = "lbl_Jog"
        Me.lbl_Jog.Size = New System.Drawing.Size(118, 26)
        Me.lbl_Jog.TabIndex = 580
        Me.lbl_Jog.Text = "Ctrl Jog (mm)"
        Me.lbl_Jog.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox_Toolpath
        '
        Me.GroupBox_Toolpath.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Toolpath.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Toolpath.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_ZoomTpMinus)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_ZoomTpPlus)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_GotoHome)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_GotoBottomLeft)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_GotoTopRight)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_GotoZero)
        Me.GroupBox_Toolpath.Controls.Add(Me.btn_TestLowZ)
        Me.GroupBox_Toolpath.Controls.Add(Me.PanelCursor1)
        Me.GroupBox_Toolpath.Controls.Add(Me.PanelCursor2)
        Me.GroupBox_Toolpath.Controls.Add(Me.Pic_Toolpath)
        Me.GroupBox_Toolpath.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Toolpath.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Toolpath.Location = New System.Drawing.Point(0, 2)
        Me.GroupBox_Toolpath.Name = "GroupBox_Toolpath"
        Me.GroupBox_Toolpath.Size = New System.Drawing.Size(577, 198)
        Me.GroupBox_Toolpath.TabIndex = 520
        Me.GroupBox_Toolpath.TabStop = False
        Me.GroupBox_Toolpath.Text = " Toolpath "
        '
        'btn_ZoomTpMinus
        '
        Me.btn_ZoomTpMinus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ZoomTpMinus.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZoomTpMinus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZoomTpMinus.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker35.IsActive = True
        DesignerRectTracker35.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker35.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomTpMinus.CenterPtTracker = DesignerRectTracker35
        CBlendItems35.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems35.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZoomTpMinus.ColorFillBlend = CBlendItems35
        CBlendItems36.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems36.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZoomTpMinus.ColorFillBlendChecked = CBlendItems36
        Me.btn_ZoomTpMinus.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ZoomTpMinus.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ZoomTpMinus.Corners.All = CType(7, Short)
        Me.btn_ZoomTpMinus.Corners.LowerLeft = CType(7, Short)
        Me.btn_ZoomTpMinus.Corners.LowerRight = CType(7, Short)
        Me.btn_ZoomTpMinus.Corners.UpperLeft = CType(7, Short)
        Me.btn_ZoomTpMinus.Corners.UpperRight = CType(7, Short)
        Me.btn_ZoomTpMinus.DimFactorGray = -20
        Me.btn_ZoomTpMinus.DimFactorOver = 30
        Me.btn_ZoomTpMinus.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomTpMinus.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomTpMinus.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZoomTpMinus.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZoomTpMinus.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZoomTpMinus.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZoomTpMinus.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ZoomTpMinus.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ZoomTpMinus.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZoomTpMinus.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker36.IsActive = False
        DesignerRectTracker36.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker36.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomTpMinus.FocusPtTracker = DesignerRectTracker36
        Me.btn_ZoomTpMinus.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZoomTpMinus.ForeColor = System.Drawing.Color.Black
        Me.btn_ZoomTpMinus.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZoomTpMinus.Image = Nothing
        Me.btn_ZoomTpMinus.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpMinus.ImageIndex = 0
        Me.btn_ZoomTpMinus.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZoomTpMinus.Location = New System.Drawing.Point(8, 174)
        Me.btn_ZoomTpMinus.Name = "btn_ZoomTpMinus"
        Me.btn_ZoomTpMinus.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZoomTpMinus.SideImage = Nothing
        Me.btn_ZoomTpMinus.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpMinus.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZoomTpMinus.Size = New System.Drawing.Size(28, 21)
        Me.btn_ZoomTpMinus.TabIndex = 162
        Me.btn_ZoomTpMinus.Text = "-"
        Me.btn_ZoomTpMinus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpMinus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZoomTpMinus.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ZoomTpMinus.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZoomTpMinus.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_ZoomTpPlus
        '
        Me.btn_ZoomTpPlus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ZoomTpPlus.BackColor = System.Drawing.Color.Transparent
        Me.btn_ZoomTpPlus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ZoomTpPlus.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker37.IsActive = False
        DesignerRectTracker37.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker37.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomTpPlus.CenterPtTracker = DesignerRectTracker37
        CBlendItems37.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems37.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ZoomTpPlus.ColorFillBlend = CBlendItems37
        CBlendItems38.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems38.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ZoomTpPlus.ColorFillBlendChecked = CBlendItems38
        Me.btn_ZoomTpPlus.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ZoomTpPlus.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ZoomTpPlus.Corners.All = CType(7, Short)
        Me.btn_ZoomTpPlus.Corners.LowerLeft = CType(7, Short)
        Me.btn_ZoomTpPlus.Corners.LowerRight = CType(7, Short)
        Me.btn_ZoomTpPlus.Corners.UpperLeft = CType(7, Short)
        Me.btn_ZoomTpPlus.Corners.UpperRight = CType(7, Short)
        Me.btn_ZoomTpPlus.DimFactorGray = -20
        Me.btn_ZoomTpPlus.DimFactorOver = 30
        Me.btn_ZoomTpPlus.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomTpPlus.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ZoomTpPlus.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ZoomTpPlus.FocalPoints.CenterPtY = 1.0!
        Me.btn_ZoomTpPlus.FocalPoints.FocusPtX = 0.0!
        Me.btn_ZoomTpPlus.FocalPoints.FocusPtY = 0.0!
        Me.btn_ZoomTpPlus.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ZoomTpPlus.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ZoomTpPlus.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ZoomTpPlus.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker38.IsActive = False
        DesignerRectTracker38.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker38.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ZoomTpPlus.FocusPtTracker = DesignerRectTracker38
        Me.btn_ZoomTpPlus.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ZoomTpPlus.ForeColor = System.Drawing.Color.Black
        Me.btn_ZoomTpPlus.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ZoomTpPlus.Image = Nothing
        Me.btn_ZoomTpPlus.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpPlus.ImageIndex = 0
        Me.btn_ZoomTpPlus.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ZoomTpPlus.Location = New System.Drawing.Point(39, 174)
        Me.btn_ZoomTpPlus.Name = "btn_ZoomTpPlus"
        Me.btn_ZoomTpPlus.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ZoomTpPlus.SideImage = Nothing
        Me.btn_ZoomTpPlus.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpPlus.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ZoomTpPlus.Size = New System.Drawing.Size(28, 21)
        Me.btn_ZoomTpPlus.TabIndex = 163
        Me.btn_ZoomTpPlus.Text = "+"
        Me.btn_ZoomTpPlus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ZoomTpPlus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ZoomTpPlus.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_ZoomTpPlus.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ZoomTpPlus.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GotoHome
        '
        Me.btn_GotoHome.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GotoHome.BackColor = System.Drawing.Color.Transparent
        Me.btn_GotoHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GotoHome.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker39.IsActive = False
        DesignerRectTracker39.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker39.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoHome.CenterPtTracker = DesignerRectTracker39
        CBlendItems39.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems39.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GotoHome.ColorFillBlend = CBlendItems39
        CBlendItems40.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems40.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GotoHome.ColorFillBlendChecked = CBlendItems40
        Me.btn_GotoHome.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GotoHome.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GotoHome.Corners.All = CType(7, Short)
        Me.btn_GotoHome.Corners.LowerLeft = CType(7, Short)
        Me.btn_GotoHome.Corners.LowerRight = CType(7, Short)
        Me.btn_GotoHome.Corners.UpperLeft = CType(7, Short)
        Me.btn_GotoHome.Corners.UpperRight = CType(7, Short)
        Me.btn_GotoHome.DimFactorGray = -20
        Me.btn_GotoHome.DimFactorOver = 30
        Me.btn_GotoHome.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoHome.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoHome.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GotoHome.FocalPoints.CenterPtY = 1.0!
        Me.btn_GotoHome.FocalPoints.FocusPtX = 0.0!
        Me.btn_GotoHome.FocalPoints.FocusPtY = 0.0!
        Me.btn_GotoHome.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GotoHome.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GotoHome.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GotoHome.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker40.IsActive = False
        DesignerRectTracker40.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker40.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoHome.FocusPtTracker = DesignerRectTracker40
        Me.btn_GotoHome.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GotoHome.ForeColor = System.Drawing.Color.Black
        Me.btn_GotoHome.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GotoHome.Image = Nothing
        Me.btn_GotoHome.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoHome.ImageIndex = 0
        Me.btn_GotoHome.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GotoHome.Location = New System.Drawing.Point(253, 174)
        Me.btn_GotoHome.Name = "btn_GotoHome"
        Me.btn_GotoHome.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GotoHome.SideImage = Nothing
        Me.btn_GotoHome.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoHome.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GotoHome.Size = New System.Drawing.Size(78, 21)
        Me.btn_GotoHome.TabIndex = 161
        Me.btn_GotoHome.Text = "Goto home"
        Me.btn_GotoHome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GotoHome.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_GotoHome.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GotoHome.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GotoBottomLeft
        '
        Me.btn_GotoBottomLeft.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GotoBottomLeft.BackColor = System.Drawing.Color.Transparent
        Me.btn_GotoBottomLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GotoBottomLeft.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker41.IsActive = False
        DesignerRectTracker41.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker41.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoBottomLeft.CenterPtTracker = DesignerRectTracker41
        CBlendItems41.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems41.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GotoBottomLeft.ColorFillBlend = CBlendItems41
        CBlendItems42.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems42.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GotoBottomLeft.ColorFillBlendChecked = CBlendItems42
        Me.btn_GotoBottomLeft.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GotoBottomLeft.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GotoBottomLeft.Corners.All = CType(7, Short)
        Me.btn_GotoBottomLeft.Corners.LowerLeft = CType(7, Short)
        Me.btn_GotoBottomLeft.Corners.LowerRight = CType(7, Short)
        Me.btn_GotoBottomLeft.Corners.UpperLeft = CType(7, Short)
        Me.btn_GotoBottomLeft.Corners.UpperRight = CType(7, Short)
        Me.btn_GotoBottomLeft.DimFactorGray = -20
        Me.btn_GotoBottomLeft.DimFactorOver = 30
        Me.btn_GotoBottomLeft.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoBottomLeft.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoBottomLeft.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GotoBottomLeft.FocalPoints.CenterPtY = 1.0!
        Me.btn_GotoBottomLeft.FocalPoints.FocusPtX = 0.0!
        Me.btn_GotoBottomLeft.FocalPoints.FocusPtY = 0.0!
        Me.btn_GotoBottomLeft.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GotoBottomLeft.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GotoBottomLeft.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GotoBottomLeft.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker42.IsActive = False
        DesignerRectTracker42.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker42.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoBottomLeft.FocusPtTracker = DesignerRectTracker42
        Me.btn_GotoBottomLeft.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GotoBottomLeft.ForeColor = System.Drawing.Color.Black
        Me.btn_GotoBottomLeft.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GotoBottomLeft.Image = Nothing
        Me.btn_GotoBottomLeft.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoBottomLeft.ImageIndex = 0
        Me.btn_GotoBottomLeft.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GotoBottomLeft.Location = New System.Drawing.Point(335, 174)
        Me.btn_GotoBottomLeft.Name = "btn_GotoBottomLeft"
        Me.btn_GotoBottomLeft.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GotoBottomLeft.SideImage = Nothing
        Me.btn_GotoBottomLeft.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoBottomLeft.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GotoBottomLeft.Size = New System.Drawing.Size(116, 21)
        Me.btn_GotoBottomLeft.TabIndex = 159
        Me.btn_GotoBottomLeft.Text = "Goto bottom-left"
        Me.btn_GotoBottomLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoBottomLeft.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GotoBottomLeft.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_GotoBottomLeft.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GotoBottomLeft.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GotoTopRight
        '
        Me.btn_GotoTopRight.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GotoTopRight.BackColor = System.Drawing.Color.Transparent
        Me.btn_GotoTopRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GotoTopRight.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker43.IsActive = False
        DesignerRectTracker43.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker43.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoTopRight.CenterPtTracker = DesignerRectTracker43
        CBlendItems43.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems43.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GotoTopRight.ColorFillBlend = CBlendItems43
        CBlendItems44.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems44.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GotoTopRight.ColorFillBlendChecked = CBlendItems44
        Me.btn_GotoTopRight.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GotoTopRight.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GotoTopRight.Corners.All = CType(7, Short)
        Me.btn_GotoTopRight.Corners.LowerLeft = CType(7, Short)
        Me.btn_GotoTopRight.Corners.LowerRight = CType(7, Short)
        Me.btn_GotoTopRight.Corners.UpperLeft = CType(7, Short)
        Me.btn_GotoTopRight.Corners.UpperRight = CType(7, Short)
        Me.btn_GotoTopRight.DimFactorGray = -20
        Me.btn_GotoTopRight.DimFactorOver = 30
        Me.btn_GotoTopRight.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoTopRight.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoTopRight.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GotoTopRight.FocalPoints.CenterPtY = 1.0!
        Me.btn_GotoTopRight.FocalPoints.FocusPtX = 0.0!
        Me.btn_GotoTopRight.FocalPoints.FocusPtY = 0.0!
        Me.btn_GotoTopRight.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GotoTopRight.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GotoTopRight.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GotoTopRight.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker44.IsActive = False
        DesignerRectTracker44.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker44.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoTopRight.FocusPtTracker = DesignerRectTracker44
        Me.btn_GotoTopRight.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GotoTopRight.ForeColor = System.Drawing.Color.Black
        Me.btn_GotoTopRight.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GotoTopRight.Image = Nothing
        Me.btn_GotoTopRight.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoTopRight.ImageIndex = 0
        Me.btn_GotoTopRight.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GotoTopRight.Location = New System.Drawing.Point(454, 174)
        Me.btn_GotoTopRight.Name = "btn_GotoTopRight"
        Me.btn_GotoTopRight.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GotoTopRight.SideImage = Nothing
        Me.btn_GotoTopRight.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoTopRight.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GotoTopRight.Size = New System.Drawing.Size(116, 20)
        Me.btn_GotoTopRight.TabIndex = 158
        Me.btn_GotoTopRight.Text = "Goto top-right"
        Me.btn_GotoTopRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoTopRight.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GotoTopRight.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_GotoTopRight.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GotoTopRight.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_GotoZero
        '
        Me.btn_GotoZero.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GotoZero.BackColor = System.Drawing.Color.Transparent
        Me.btn_GotoZero.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_GotoZero.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker45.IsActive = False
        DesignerRectTracker45.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker45.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoZero.CenterPtTracker = DesignerRectTracker45
        CBlendItems45.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems45.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_GotoZero.ColorFillBlend = CBlendItems45
        CBlendItems46.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems46.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_GotoZero.ColorFillBlendChecked = CBlendItems46
        Me.btn_GotoZero.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_GotoZero.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_GotoZero.Corners.All = CType(7, Short)
        Me.btn_GotoZero.Corners.LowerLeft = CType(7, Short)
        Me.btn_GotoZero.Corners.LowerRight = CType(7, Short)
        Me.btn_GotoZero.Corners.UpperLeft = CType(7, Short)
        Me.btn_GotoZero.Corners.UpperRight = CType(7, Short)
        Me.btn_GotoZero.DimFactorGray = -20
        Me.btn_GotoZero.DimFactorOver = 30
        Me.btn_GotoZero.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoZero.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_GotoZero.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_GotoZero.FocalPoints.CenterPtY = 1.0!
        Me.btn_GotoZero.FocalPoints.FocusPtX = 0.0!
        Me.btn_GotoZero.FocalPoints.FocusPtY = 0.0!
        Me.btn_GotoZero.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_GotoZero.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_GotoZero.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_GotoZero.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker46.IsActive = False
        DesignerRectTracker46.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker46.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_GotoZero.FocusPtTracker = DesignerRectTracker46
        Me.btn_GotoZero.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GotoZero.ForeColor = System.Drawing.Color.Black
        Me.btn_GotoZero.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_GotoZero.Image = Nothing
        Me.btn_GotoZero.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoZero.ImageIndex = 0
        Me.btn_GotoZero.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_GotoZero.Location = New System.Drawing.Point(171, 174)
        Me.btn_GotoZero.Name = "btn_GotoZero"
        Me.btn_GotoZero.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_GotoZero.SideImage = Nothing
        Me.btn_GotoZero.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoZero.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_GotoZero.Size = New System.Drawing.Size(78, 21)
        Me.btn_GotoZero.TabIndex = 157
        Me.btn_GotoZero.Text = "Goto zero"
        Me.btn_GotoZero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_GotoZero.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_GotoZero.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_GotoZero.TextShadow = System.Drawing.Color.Transparent
        Me.btn_GotoZero.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_TestLowZ
        '
        Me.btn_TestLowZ.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_TestLowZ.BackColor = System.Drawing.Color.Transparent
        Me.btn_TestLowZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_TestLowZ.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker47.IsActive = False
        DesignerRectTracker47.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker47.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestLowZ.CenterPtTracker = DesignerRectTracker47
        Me.btn_TestLowZ.CheckButton = True
        CBlendItems47.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems47.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TestLowZ.ColorFillBlend = CBlendItems47
        CBlendItems48.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems48.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_TestLowZ.ColorFillBlendChecked = CBlendItems48
        Me.btn_TestLowZ.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_TestLowZ.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_TestLowZ.Corners.All = CType(7, Short)
        Me.btn_TestLowZ.Corners.LowerLeft = CType(7, Short)
        Me.btn_TestLowZ.Corners.LowerRight = CType(7, Short)
        Me.btn_TestLowZ.Corners.UpperLeft = CType(7, Short)
        Me.btn_TestLowZ.Corners.UpperRight = CType(7, Short)
        Me.btn_TestLowZ.DimFactorGray = -20
        Me.btn_TestLowZ.DimFactorOver = 30
        Me.btn_TestLowZ.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_TestLowZ.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_TestLowZ.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_TestLowZ.FocalPoints.CenterPtY = 1.0!
        Me.btn_TestLowZ.FocalPoints.FocusPtX = 0.0!
        Me.btn_TestLowZ.FocalPoints.FocusPtY = 0.0!
        Me.btn_TestLowZ.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_TestLowZ.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_TestLowZ.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_TestLowZ.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker48.IsActive = False
        DesignerRectTracker48.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker48.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestLowZ.FocusPtTracker = DesignerRectTracker48
        Me.btn_TestLowZ.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TestLowZ.ForeColor = System.Drawing.Color.Black
        Me.btn_TestLowZ.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_TestLowZ.Image = Nothing
        Me.btn_TestLowZ.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestLowZ.ImageIndex = 0
        Me.btn_TestLowZ.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_TestLowZ.Location = New System.Drawing.Point(72, 174)
        Me.btn_TestLowZ.Name = "btn_TestLowZ"
        Me.btn_TestLowZ.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_TestLowZ.SideImage = Nothing
        Me.btn_TestLowZ.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestLowZ.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TestLowZ.Size = New System.Drawing.Size(88, 21)
        Me.btn_TestLowZ.TabIndex = 156
        Me.btn_TestLowZ.Text = "Test Low-Z"
        Me.btn_TestLowZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestLowZ.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_TestLowZ.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_TestLowZ.TextShadow = System.Drawing.Color.Transparent
        Me.btn_TestLowZ.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'PanelCursor1
        '
        Me.PanelCursor1.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.PanelCursor1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelCursor1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.PanelCursor1.Location = New System.Drawing.Point(49, 34)
        Me.PanelCursor1.Name = "PanelCursor1"
        Me.PanelCursor1.Size = New System.Drawing.Size(2, 70)
        Me.PanelCursor1.TabIndex = 154
        '
        'PanelCursor2
        '
        Me.PanelCursor2.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.PanelCursor2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelCursor2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.PanelCursor2.Location = New System.Drawing.Point(24, 52)
        Me.PanelCursor2.Name = "PanelCursor2"
        Me.PanelCursor2.Size = New System.Drawing.Size(100, 2)
        Me.PanelCursor2.TabIndex = 155
        '
        'Pic_Toolpath
        '
        Me.Pic_Toolpath.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pic_Toolpath.BackColor = System.Drawing.Color.Gainsboro
        Me.Pic_Toolpath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Toolpath.Location = New System.Drawing.Point(8, 19)
        Me.Pic_Toolpath.Name = "Pic_Toolpath"
        Me.Pic_Toolpath.Size = New System.Drawing.Size(560, 150)
        Me.Pic_Toolpath.TabIndex = 153
        Me.Pic_Toolpath.TabStop = False
        '
        'PanelBack1
        '
        Me.PanelBack1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelBack1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelBack1.Controls.Add(Me.GroupBox_Temperatures)
        Me.PanelBack1.Controls.Add(Me.GroupBox_Controls)
        Me.PanelBack1.Controls.Add(Me.GroupBox_Gcode)
        Me.PanelBack1.Location = New System.Drawing.Point(0, 58)
        Me.PanelBack1.Name = "PanelBack1"
        Me.PanelBack1.Size = New System.Drawing.Size(299, 451)
        Me.PanelBack1.TabIndex = 701
        '
        'GroupBox_Temperatures
        '
        Me.GroupBox_Temperatures.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Temperatures.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Temperatures.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Temperatures.Controls.Add(Me.lbl_TempExtruders)
        Me.GroupBox_Temperatures.Controls.Add(Me.lbl_TempPrintBed)
        Me.GroupBox_Temperatures.Controls.Add(Me.lbl_TempChamber)
        Me.GroupBox_Temperatures.Controls.Add(Me.lbl_TempAmbient)
        Me.GroupBox_Temperatures.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Temperatures.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Temperatures.Location = New System.Drawing.Point(2, 2)
        Me.GroupBox_Temperatures.Name = "GroupBox_Temperatures"
        Me.GroupBox_Temperatures.Size = New System.Drawing.Size(297, 72)
        Me.GroupBox_Temperatures.TabIndex = 511
        Me.GroupBox_Temperatures.TabStop = False
        Me.GroupBox_Temperatures.Text = " Temperatures "
        '
        'lbl_TempExtruders
        '
        Me.lbl_TempExtruders.BackColor = System.Drawing.Color.Transparent
        Me.lbl_TempExtruders.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TempExtruders.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_TempExtruders.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_TempExtruders.Location = New System.Drawing.Point(129, 46)
        Me.lbl_TempExtruders.Name = "lbl_TempExtruders"
        Me.lbl_TempExtruders.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.lbl_TempExtruders.Size = New System.Drawing.Size(162, 20)
        Me.lbl_TempExtruders.TabIndex = 544
        Me.lbl_TempExtruders.Text = "Extruders 999.9 999.9"
        Me.lbl_TempExtruders.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl_TempPrintBed
        '
        Me.lbl_TempPrintBed.BackColor = System.Drawing.Color.Transparent
        Me.lbl_TempPrintBed.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TempPrintBed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_TempPrintBed.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_TempPrintBed.Location = New System.Drawing.Point(9, 46)
        Me.lbl_TempPrintBed.Name = "lbl_TempPrintBed"
        Me.lbl_TempPrintBed.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.lbl_TempPrintBed.Size = New System.Drawing.Size(114, 20)
        Me.lbl_TempPrintBed.TabIndex = 543
        Me.lbl_TempPrintBed.Text = "Print bed 999.9"
        Me.lbl_TempPrintBed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl_TempChamber
        '
        Me.lbl_TempChamber.BackColor = System.Drawing.Color.Transparent
        Me.lbl_TempChamber.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TempChamber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_TempChamber.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_TempChamber.Location = New System.Drawing.Point(129, 23)
        Me.lbl_TempChamber.Name = "lbl_TempChamber"
        Me.lbl_TempChamber.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.lbl_TempChamber.Size = New System.Drawing.Size(162, 20)
        Me.lbl_TempChamber.TabIndex = 542
        Me.lbl_TempChamber.Text = "Chamber 999.9"
        Me.lbl_TempChamber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl_TempAmbient
        '
        Me.lbl_TempAmbient.BackColor = System.Drawing.Color.Transparent
        Me.lbl_TempAmbient.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TempAmbient.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_TempAmbient.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_TempAmbient.Location = New System.Drawing.Point(9, 23)
        Me.lbl_TempAmbient.Name = "lbl_TempAmbient"
        Me.lbl_TempAmbient.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.lbl_TempAmbient.Size = New System.Drawing.Size(114, 20)
        Me.lbl_TempAmbient.TabIndex = 541
        Me.lbl_TempAmbient.Text = "Ambient 999.9"
        Me.lbl_TempAmbient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PanelBack2
        '
        Me.PanelBack2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelBack2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelBack2.Controls.Add(Me.GroupBox_Calibrations)
        Me.PanelBack2.Controls.Add(Me.GroupBox_Motors)
        Me.PanelBack2.Controls.Add(Me.GroupBox_Toolpath)
        Me.PanelBack2.Location = New System.Drawing.Point(314, 58)
        Me.PanelBack2.Name = "PanelBack2"
        Me.PanelBack2.Size = New System.Drawing.Size(581, 451)
        Me.PanelBack2.TabIndex = 702
        '
        'GroupBox_Calibrations
        '
        Me.GroupBox_Calibrations.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Calibrations.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox_Calibrations.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox_Calibrations.Controls.Add(Me.btn_CalibrateAB)
        Me.GroupBox_Calibrations.Controls.Add(Me.btn_CalibrationSettings)
        Me.GroupBox_Calibrations.Controls.Add(Me.btn_CalibrateZ)
        Me.GroupBox_Calibrations.Controls.Add(Me.btn_SetZetaHome)
        Me.GroupBox_Calibrations.Controls.Add(Me.btn_CalibrateXY)
        Me.GroupBox_Calibrations.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Calibrations.ForeColor = System.Drawing.Color.Black
        Me.GroupBox_Calibrations.Location = New System.Drawing.Point(464, 204)
        Me.GroupBox_Calibrations.Name = "GroupBox_Calibrations"
        Me.GroupBox_Calibrations.Size = New System.Drawing.Size(112, 245)
        Me.GroupBox_Calibrations.TabIndex = 531
        Me.GroupBox_Calibrations.TabStop = False
        Me.GroupBox_Calibrations.Text = "Calibrations"
        '
        'btn_CalibrateAB
        '
        Me.btn_CalibrateAB.BackColor = System.Drawing.Color.Transparent
        Me.btn_CalibrateAB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_CalibrateAB.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker49.IsActive = False
        DesignerRectTracker49.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker49.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateAB.CenterPtTracker = DesignerRectTracker49
        Me.btn_CalibrateAB.CheckButton = True
        CBlendItems49.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems49.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CalibrateAB.ColorFillBlend = CBlendItems49
        CBlendItems50.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems50.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CalibrateAB.ColorFillBlendChecked = CBlendItems50
        Me.btn_CalibrateAB.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_CalibrateAB.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_CalibrateAB.Corners.All = CType(7, Short)
        Me.btn_CalibrateAB.Corners.LowerLeft = CType(7, Short)
        Me.btn_CalibrateAB.Corners.LowerRight = CType(7, Short)
        Me.btn_CalibrateAB.Corners.UpperLeft = CType(7, Short)
        Me.btn_CalibrateAB.Corners.UpperRight = CType(7, Short)
        Me.btn_CalibrateAB.DimFactorGray = -20
        Me.btn_CalibrateAB.DimFactorOver = 30
        Me.btn_CalibrateAB.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateAB.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateAB.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CalibrateAB.FocalPoints.CenterPtY = 1.0!
        Me.btn_CalibrateAB.FocalPoints.FocusPtX = 0.0!
        Me.btn_CalibrateAB.FocalPoints.FocusPtY = 0.0!
        Me.btn_CalibrateAB.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_CalibrateAB.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_CalibrateAB.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CalibrateAB.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker50.IsActive = False
        DesignerRectTracker50.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker50.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateAB.FocusPtTracker = DesignerRectTracker50
        Me.btn_CalibrateAB.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CalibrateAB.ForeColor = System.Drawing.Color.Black
        Me.btn_CalibrateAB.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CalibrateAB.Image = Nothing
        Me.btn_CalibrateAB.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateAB.ImageIndex = 0
        Me.btn_CalibrateAB.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CalibrateAB.Location = New System.Drawing.Point(8, 168)
        Me.btn_CalibrateAB.Name = "btn_CalibrateAB"
        Me.btn_CalibrateAB.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_CalibrateAB.SideImage = Nothing
        Me.btn_CalibrateAB.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateAB.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CalibrateAB.Size = New System.Drawing.Size(98, 37)
        Me.btn_CalibrateAB.TabIndex = 651
        Me.btn_CalibrateAB.Text = "Calibrate AB"
        Me.btn_CalibrateAB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateAB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CalibrateAB.TextMargin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.btn_CalibrateAB.TextShadow = System.Drawing.Color.Transparent
        Me.btn_CalibrateAB.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_CalibrationSettings
        '
        Me.btn_CalibrationSettings.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_CalibrationSettings.BackColor = System.Drawing.Color.Transparent
        Me.btn_CalibrationSettings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_CalibrationSettings.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker51.IsActive = False
        DesignerRectTracker51.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker51.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrationSettings.CenterPtTracker = DesignerRectTracker51
        CBlendItems51.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems51.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CalibrationSettings.ColorFillBlend = CBlendItems51
        CBlendItems52.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems52.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CalibrationSettings.ColorFillBlendChecked = CBlendItems52
        Me.btn_CalibrationSettings.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_CalibrationSettings.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_CalibrationSettings.Corners.All = CType(7, Short)
        Me.btn_CalibrationSettings.Corners.LowerLeft = CType(7, Short)
        Me.btn_CalibrationSettings.Corners.LowerRight = CType(7, Short)
        Me.btn_CalibrationSettings.Corners.UpperLeft = CType(7, Short)
        Me.btn_CalibrationSettings.Corners.UpperRight = CType(7, Short)
        Me.btn_CalibrationSettings.DimFactorGray = -20
        Me.btn_CalibrationSettings.DimFactorOver = 30
        Me.btn_CalibrationSettings.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrationSettings.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrationSettings.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CalibrationSettings.FocalPoints.CenterPtY = 1.0!
        Me.btn_CalibrationSettings.FocalPoints.FocusPtX = 0.0!
        Me.btn_CalibrationSettings.FocalPoints.FocusPtY = 0.0!
        Me.btn_CalibrationSettings.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_CalibrationSettings.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_CalibrationSettings.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CalibrationSettings.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker52.IsActive = False
        DesignerRectTracker52.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker52.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrationSettings.FocusPtTracker = DesignerRectTracker52
        Me.btn_CalibrationSettings.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CalibrationSettings.ForeColor = System.Drawing.Color.Black
        Me.btn_CalibrationSettings.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CalibrationSettings.Image = Nothing
        Me.btn_CalibrationSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrationSettings.ImageIndex = 0
        Me.btn_CalibrationSettings.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CalibrationSettings.Location = New System.Drawing.Point(8, 209)
        Me.btn_CalibrationSettings.Name = "btn_CalibrationSettings"
        Me.btn_CalibrationSettings.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_CalibrationSettings.SideImage = Nothing
        Me.btn_CalibrationSettings.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrationSettings.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CalibrationSettings.Size = New System.Drawing.Size(98, 29)
        Me.btn_CalibrationSettings.TabIndex = 650
        Me.btn_CalibrationSettings.Text = "Settings"
        Me.btn_CalibrationSettings.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrationSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CalibrationSettings.TextMargin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.btn_CalibrationSettings.TextShadow = System.Drawing.Color.Transparent
        Me.btn_CalibrationSettings.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_CalibrateZ
        '
        Me.btn_CalibrateZ.BackColor = System.Drawing.Color.Transparent
        Me.btn_CalibrateZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_CalibrateZ.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker53.IsActive = False
        DesignerRectTracker53.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker53.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateZ.CenterPtTracker = DesignerRectTracker53
        Me.btn_CalibrateZ.CheckButton = True
        CBlendItems53.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems53.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CalibrateZ.ColorFillBlend = CBlendItems53
        CBlendItems54.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems54.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CalibrateZ.ColorFillBlendChecked = CBlendItems54
        Me.btn_CalibrateZ.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_CalibrateZ.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_CalibrateZ.Corners.All = CType(7, Short)
        Me.btn_CalibrateZ.Corners.LowerLeft = CType(7, Short)
        Me.btn_CalibrateZ.Corners.LowerRight = CType(7, Short)
        Me.btn_CalibrateZ.Corners.UpperLeft = CType(7, Short)
        Me.btn_CalibrateZ.Corners.UpperRight = CType(7, Short)
        Me.btn_CalibrateZ.DimFactorGray = -20
        Me.btn_CalibrateZ.DimFactorOver = 30
        Me.btn_CalibrateZ.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateZ.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateZ.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CalibrateZ.FocalPoints.CenterPtY = 1.0!
        Me.btn_CalibrateZ.FocalPoints.FocusPtX = 0.0!
        Me.btn_CalibrateZ.FocalPoints.FocusPtY = 0.0!
        Me.btn_CalibrateZ.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_CalibrateZ.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_CalibrateZ.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CalibrateZ.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker54.IsActive = False
        DesignerRectTracker54.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker54.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateZ.FocusPtTracker = DesignerRectTracker54
        Me.btn_CalibrateZ.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CalibrateZ.ForeColor = System.Drawing.Color.Black
        Me.btn_CalibrateZ.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CalibrateZ.Image = Nothing
        Me.btn_CalibrateZ.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateZ.ImageIndex = 0
        Me.btn_CalibrateZ.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CalibrateZ.Location = New System.Drawing.Point(8, 127)
        Me.btn_CalibrateZ.Name = "btn_CalibrateZ"
        Me.btn_CalibrateZ.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_CalibrateZ.SideImage = Nothing
        Me.btn_CalibrateZ.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateZ.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CalibrateZ.Size = New System.Drawing.Size(98, 37)
        Me.btn_CalibrateZ.TabIndex = 649
        Me.btn_CalibrateZ.Text = "Calibrate Z"
        Me.btn_CalibrateZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateZ.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CalibrateZ.TextMargin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.btn_CalibrateZ.TextShadow = System.Drawing.Color.Transparent
        Me.btn_CalibrateZ.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_SetZetaHome
        '
        Me.btn_SetZetaHome.BackColor = System.Drawing.Color.Transparent
        Me.btn_SetZetaHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_SetZetaHome.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker55.IsActive = False
        DesignerRectTracker55.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker55.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetZetaHome.CenterPtTracker = DesignerRectTracker55
        Me.btn_SetZetaHome.CheckButton = True
        CBlendItems55.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems55.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SetZetaHome.ColorFillBlend = CBlendItems55
        CBlendItems56.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems56.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SetZetaHome.ColorFillBlendChecked = CBlendItems56
        Me.btn_SetZetaHome.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_SetZetaHome.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_SetZetaHome.Corners.All = CType(7, Short)
        Me.btn_SetZetaHome.Corners.LowerLeft = CType(7, Short)
        Me.btn_SetZetaHome.Corners.LowerRight = CType(7, Short)
        Me.btn_SetZetaHome.Corners.UpperLeft = CType(7, Short)
        Me.btn_SetZetaHome.Corners.UpperRight = CType(7, Short)
        Me.btn_SetZetaHome.DimFactorGray = -20
        Me.btn_SetZetaHome.DimFactorOver = 30
        Me.btn_SetZetaHome.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_SetZetaHome.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_SetZetaHome.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_SetZetaHome.FocalPoints.CenterPtY = 1.0!
        Me.btn_SetZetaHome.FocalPoints.FocusPtX = 0.0!
        Me.btn_SetZetaHome.FocalPoints.FocusPtY = 0.0!
        Me.btn_SetZetaHome.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_SetZetaHome.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_SetZetaHome.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SetZetaHome.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker56.IsActive = False
        DesignerRectTracker56.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker56.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetZetaHome.FocusPtTracker = DesignerRectTracker56
        Me.btn_SetZetaHome.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SetZetaHome.ForeColor = System.Drawing.Color.Black
        Me.btn_SetZetaHome.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_SetZetaHome.Image = Nothing
        Me.btn_SetZetaHome.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZetaHome.ImageIndex = 0
        Me.btn_SetZetaHome.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SetZetaHome.Location = New System.Drawing.Point(8, 22)
        Me.btn_SetZetaHome.Name = "btn_SetZetaHome"
        Me.btn_SetZetaHome.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_SetZetaHome.SideImage = Nothing
        Me.btn_SetZetaHome.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZetaHome.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SetZetaHome.Size = New System.Drawing.Size(98, 60)
        Me.btn_SetZetaHome.TabIndex = 646
        Me.btn_SetZetaHome.Text = "Set Zeta      HOME"
        Me.btn_SetZetaHome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZetaHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SetZetaHome.TextMargin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.btn_SetZetaHome.TextShadow = System.Drawing.Color.Transparent
        Me.btn_SetZetaHome.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_CalibrateXY
        '
        Me.btn_CalibrateXY.BackColor = System.Drawing.Color.Transparent
        Me.btn_CalibrateXY.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_CalibrateXY.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker57.IsActive = False
        DesignerRectTracker57.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker57.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateXY.CenterPtTracker = DesignerRectTracker57
        Me.btn_CalibrateXY.CheckButton = True
        CBlendItems57.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems57.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CalibrateXY.ColorFillBlend = CBlendItems57
        CBlendItems58.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems58.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CalibrateXY.ColorFillBlendChecked = CBlendItems58
        Me.btn_CalibrateXY.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_CalibrateXY.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_CalibrateXY.Corners.All = CType(7, Short)
        Me.btn_CalibrateXY.Corners.LowerLeft = CType(7, Short)
        Me.btn_CalibrateXY.Corners.LowerRight = CType(7, Short)
        Me.btn_CalibrateXY.Corners.UpperLeft = CType(7, Short)
        Me.btn_CalibrateXY.Corners.UpperRight = CType(7, Short)
        Me.btn_CalibrateXY.DimFactorGray = -20
        Me.btn_CalibrateXY.DimFactorOver = 30
        Me.btn_CalibrateXY.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateXY.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CalibrateXY.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CalibrateXY.FocalPoints.CenterPtY = 1.0!
        Me.btn_CalibrateXY.FocalPoints.FocusPtX = 0.0!
        Me.btn_CalibrateXY.FocalPoints.FocusPtY = 0.0!
        Me.btn_CalibrateXY.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_CalibrateXY.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_CalibrateXY.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CalibrateXY.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker58.IsActive = False
        DesignerRectTracker58.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker58.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CalibrateXY.FocusPtTracker = DesignerRectTracker58
        Me.btn_CalibrateXY.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CalibrateXY.ForeColor = System.Drawing.Color.Black
        Me.btn_CalibrateXY.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CalibrateXY.Image = Nothing
        Me.btn_CalibrateXY.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateXY.ImageIndex = 0
        Me.btn_CalibrateXY.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CalibrateXY.Location = New System.Drawing.Point(8, 86)
        Me.btn_CalibrateXY.Name = "btn_CalibrateXY"
        Me.btn_CalibrateXY.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_CalibrateXY.SideImage = Nothing
        Me.btn_CalibrateXY.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateXY.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CalibrateXY.Size = New System.Drawing.Size(98, 37)
        Me.btn_CalibrateXY.TabIndex = 645
        Me.btn_CalibrateXY.Text = "Calibrate XY"
        Me.btn_CalibrateXY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CalibrateXY.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CalibrateXY.TextMargin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.btn_CalibrateXY.TextShadow = System.Drawing.Color.Transparent
        Me.btn_CalibrateXY.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'PanelSplitter
        '
        Me.PanelSplitter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelSplitter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelSplitter.Cursor = System.Windows.Forms.Cursors.VSplit
        Me.PanelSplitter.Location = New System.Drawing.Point(302, 62)
        Me.PanelSplitter.Name = "PanelSplitter"
        Me.PanelSplitter.Size = New System.Drawing.Size(8, 447)
        Me.PanelSplitter.TabIndex = 703
        '
        'btn_InOutEnabled
        '
        Me.btn_InOutEnabled.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_InOutEnabled.BackColor = System.Drawing.Color.Transparent
        Me.btn_InOutEnabled.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_InOutEnabled.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker59.IsActive = False
        DesignerRectTracker59.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker59.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_InOutEnabled.CenterPtTracker = DesignerRectTracker59
        Me.btn_InOutEnabled.CheckButton = True
        CBlendItems59.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems59.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_InOutEnabled.ColorFillBlend = CBlendItems59
        CBlendItems60.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems60.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_InOutEnabled.ColorFillBlendChecked = CBlendItems60
        Me.btn_InOutEnabled.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_InOutEnabled.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_InOutEnabled.Corners.All = CType(8, Short)
        Me.btn_InOutEnabled.Corners.LowerLeft = CType(8, Short)
        Me.btn_InOutEnabled.Corners.LowerRight = CType(8, Short)
        Me.btn_InOutEnabled.Corners.UpperLeft = CType(8, Short)
        Me.btn_InOutEnabled.Corners.UpperRight = CType(8, Short)
        Me.btn_InOutEnabled.DimFactorGray = -20
        Me.btn_InOutEnabled.DimFactorOver = 30
        Me.btn_InOutEnabled.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_InOutEnabled.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_InOutEnabled.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_InOutEnabled.FocalPoints.CenterPtY = 1.0!
        Me.btn_InOutEnabled.FocalPoints.FocusPtX = 0.0!
        Me.btn_InOutEnabled.FocalPoints.FocusPtY = 0.0!
        Me.btn_InOutEnabled.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_InOutEnabled.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_InOutEnabled.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_InOutEnabled.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker60.IsActive = False
        DesignerRectTracker60.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker60.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_InOutEnabled.FocusPtTracker = DesignerRectTracker60
        Me.btn_InOutEnabled.Font = New System.Drawing.Font("Tahoma", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_InOutEnabled.ForeColor = System.Drawing.Color.Black
        Me.btn_InOutEnabled.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_InOutEnabled.Image = Nothing
        Me.btn_InOutEnabled.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InOutEnabled.ImageIndex = 0
        Me.btn_InOutEnabled.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_InOutEnabled.Location = New System.Drawing.Point(615, -2)
        Me.btn_InOutEnabled.Name = "btn_InOutEnabled"
        Me.btn_InOutEnabled.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_InOutEnabled.SideImage = Nothing
        Me.btn_InOutEnabled.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InOutEnabled.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_InOutEnabled.Size = New System.Drawing.Size(151, 30)
        Me.btn_InOutEnabled.TabIndex = 182
        Me.btn_InOutEnabled.Text = "IN OUT enabled"
        Me.btn_InOutEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InOutEnabled.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_InOutEnabled.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_InOutEnabled.TextShadow = System.Drawing.Color.Transparent
        Me.btn_InOutEnabled.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_HalEnabled
        '
        Me.btn_HalEnabled.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_HalEnabled.BackColor = System.Drawing.Color.Transparent
        Me.btn_HalEnabled.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_HalEnabled.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker61.IsActive = False
        DesignerRectTracker61.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker61.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_HalEnabled.CenterPtTracker = DesignerRectTracker61
        Me.btn_HalEnabled.CheckButton = True
        CBlendItems61.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems61.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_HalEnabled.ColorFillBlend = CBlendItems61
        CBlendItems62.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems62.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_HalEnabled.ColorFillBlendChecked = CBlendItems62
        Me.btn_HalEnabled.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_HalEnabled.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_HalEnabled.Corners.All = CType(8, Short)
        Me.btn_HalEnabled.Corners.LowerLeft = CType(8, Short)
        Me.btn_HalEnabled.Corners.LowerRight = CType(8, Short)
        Me.btn_HalEnabled.Corners.UpperLeft = CType(8, Short)
        Me.btn_HalEnabled.Corners.UpperRight = CType(8, Short)
        Me.btn_HalEnabled.DimFactorGray = -20
        Me.btn_HalEnabled.DimFactorOver = 30
        Me.btn_HalEnabled.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_HalEnabled.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_HalEnabled.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_HalEnabled.FocalPoints.CenterPtY = 1.0!
        Me.btn_HalEnabled.FocalPoints.FocusPtX = 0.0!
        Me.btn_HalEnabled.FocalPoints.FocusPtY = 0.0!
        Me.btn_HalEnabled.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_HalEnabled.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_HalEnabled.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_HalEnabled.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker62.IsActive = False
        DesignerRectTracker62.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker62.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_HalEnabled.FocusPtTracker = DesignerRectTracker62
        Me.btn_HalEnabled.Font = New System.Drawing.Font("Tahoma", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_HalEnabled.ForeColor = System.Drawing.Color.Black
        Me.btn_HalEnabled.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_HalEnabled.Image = Nothing
        Me.btn_HalEnabled.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_HalEnabled.ImageIndex = 0
        Me.btn_HalEnabled.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_HalEnabled.Location = New System.Drawing.Point(766, -2)
        Me.btn_HalEnabled.Name = "btn_HalEnabled"
        Me.btn_HalEnabled.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_HalEnabled.SideImage = Nothing
        Me.btn_HalEnabled.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_HalEnabled.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_HalEnabled.Size = New System.Drawing.Size(127, 30)
        Me.btn_HalEnabled.TabIndex = 181
        Me.btn_HalEnabled.Text = "HAL enabled"
        Me.btn_HalEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_HalEnabled.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_HalEnabled.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_HalEnabled.TextShadow = System.Drawing.Color.Transparent
        Me.btn_HalEnabled.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(893, 535)
        Me.Controls.Add(Me.btn_InOutEnabled)
        Me.Controls.Add(Me.PanelSplitter)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btn_HalEnabled)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PanelBack1)
        Me.Controls.Add(Me.PanelBack2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(770, 527)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino CNC"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox_Gcode.ResumeLayout(False)
        Me.GroupBox_Gcode.PerformLayout()
        Me.CTX_Edit.ResumeLayout(False)
        Me.GroupBox_Controls.ResumeLayout(False)
        Me.GroupBox_Motors.ResumeLayout(False)
        Me.GroupBox_Motors.PerformLayout()
        Me.GroupBox_Toolpath.ResumeLayout(False)
        CType(Me.Pic_Toolpath, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBack1.ResumeLayout(False)
        Me.GroupBox_Temperatures.ResumeLayout(False)
        Me.PanelBack2.ResumeLayout(False)
        Me.GroupBox_Calibrations.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_GcodeLoad As MyButton
    Friend WithEvents btn_GcodeStart As MyButton
    Friend WithEvents btn_GcodeRewind As MyButton
    Friend WithEvents GroupBox_Motors As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Toolpath As System.Windows.Forms.GroupBox
    Friend WithEvents Pic_Toolpath As System.Windows.Forms.PictureBox
    Friend WithEvents txt_CtrlJog As MyTextBox
    Friend WithEvents lbl_Jog As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Gcode As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txt_MaxError As MyTextBox
    Friend WithEvents lbl_MaxErr As System.Windows.Forms.Label
    Friend WithEvents txt_Feed As MyTextBox
    Friend WithEvents lbl_Feed As System.Windows.Forms.Label
    Friend WithEvents txt_Rapid As MyTextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_LoadGcode As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SaveGcodeAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_Skin As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton_LoadGcode As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton_SaveGcodeAs As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_OpenFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents RTB As SyntaxRichTextBox
    Friend WithEvents btn_ZeroB As MyButton
    Friend WithEvents btn_ZeroA As MyButton
    Friend WithEvents btn_ZeroZ As MyButton
    Friend WithEvents btn_ZeroY As MyButton
    Friend WithEvents btn_ZeroX As MyButton
    Friend WithEvents lbl_CoordX As System.Windows.Forms.Label
    Friend WithEvents lbl_CoordB As System.Windows.Forms.Label
    Friend WithEvents lbl_CoordA As System.Windows.Forms.Label
    Friend WithEvents lbl_CoordZ As System.Windows.Forms.Label
    Friend WithEvents lbl_CoordY As System.Windows.Forms.Label
    Friend WithEvents btn_GcodePause As MyButton
    Friend WithEvents GroupBox_Controls As System.Windows.Forms.GroupBox
    Friend WithEvents btn_GCodeStop As MyButton
    Friend WithEvents StatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btn_FeedSpeedLocked As MyButton
    Friend WithEvents lbl_Rapid As System.Windows.Forms.Label
    Friend WithEvents Menu_File_SaveGcode As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_SaveGcode As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txt_Speed As MyTextBox
    Friend WithEvents lbl_Speed As System.Windows.Forms.Label
    Friend WithEvents ToolStripButton_View As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_ZoomMinus As MyButton
    Friend WithEvents btn_ZoomPlus As MyButton
    Friend WithEvents btn_Up As MyButton
    Friend WithEvents btn_Down As MyButton
    Friend WithEvents btn_ToolStop As MyButton
    Friend WithEvents PanelCursor1 As System.Windows.Forms.Panel
    Friend WithEvents PanelCursor2 As System.Windows.Forms.Panel
    Friend WithEvents Menu_Skins As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_EditSkinFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_OpenSkinsFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_ReloadSelectedSkin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btn_LookAhead As MyButton
    Friend WithEvents btn_HalEnabled As MyButton
    Friend WithEvents btn_InOutEnabled As MyButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents txt_EditCoord As MyTextBox
    Friend WithEvents Menu_Help_ProgramHelpENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelpITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_GMcodes_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_GMcodes_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btn_GotoZero As MyButton
    Friend WithEvents btn_TestLowZ As MyButton
    Friend WithEvents btn_GotoTopRight As MyButton
    Friend WithEvents CTX_Edit As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CTX_Edit_Cut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Copy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Paste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Delete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CTX_Edit_SelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CTX_Edit_Comment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Uncomment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CTX_Edit_Indent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Unindent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CTX_Edit_Find As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CTX_Edit_Undo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CTX_Edit_Redo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btn_GotoBottomLeft As MyButton
    Friend WithEvents PanelBack1 As System.Windows.Forms.Panel
    Friend WithEvents PanelBack2 As System.Windows.Forms.Panel
    Friend WithEvents PanelSplitter As System.Windows.Forms.Panel
    Friend WithEvents Menu_Tools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_TranslateToZero_XY As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_RotateLeft_XY As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_RotateRight_XY As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_ConvertToMM_XYZ As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_ConvertToMM_XYZAB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_TranslateToZero_XYAB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_RotateLeft_XYAB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_RotateRight_XYAB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_SaveToolpathImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Normalize As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox_Calibrations As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CalibrateXY As MyButton
    Friend WithEvents btn_SetZetaHome As MyButton
    Friend WithEvents btn_GotoHome As MyButton
    Friend WithEvents btn_CalibrateZ As MyButton
    Friend WithEvents StatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btn_CalibrationSettings As MyButton
    Friend WithEvents btn_CalibrateAB As MyButton
    Friend WithEvents btn_ZoomTpMinus As MyButton
    Friend WithEvents btn_ZoomTpPlus As MyButton
    Friend WithEvents txt_Debug As MyTextBox
    Friend WithEvents Menu_3DPrinters As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_EditTempTables As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_ControlTemperatures As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox_Temperatures As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_TempAmbient As System.Windows.Forms.Label
    Friend WithEvents lbl_TempChamber As System.Windows.Forms.Label
    Friend WithEvents lbl_TempPrintBed As System.Windows.Forms.Label
    Friend WithEvents lbl_TempExtruders As System.Windows.Forms.Label
    Friend WithEvents Menu_Options As System.Windows.Forms.ToolStripMenuItem
End Class
