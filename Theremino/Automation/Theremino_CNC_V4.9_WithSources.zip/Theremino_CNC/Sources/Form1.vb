﻿
Public Class Form1

    ' ==================================================================================================
    '   MAIN ENTRY POINT
    ' ==================================================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' ----------------------------------------------------
        ' Remember to set in the Form Properties:
        '  - ShowInTaskbar = False 
        ' ----------------------------------------------------
        EventsAreEnabled = False
        ' ---------------------------------------------------- window aspect
        GetWindowsDPI()
        ShowWindowTitle()
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------- load and init (DO NOT change order)
        CNC_Init(Pic_Toolpath)
        GraphicThread_Start()
        Load_INI()
        CNC_ReadTemperatureTables()
        ' ---------------------------------------------------- temperature panel
        ShowTemperaturePanel()
        ' ---------------------------------------------------- windowstate and splitter while minimized
        If StartupWindowState = FormWindowState.Minimized Then
            SetSplitterPosition(StartupSplitterPosition)
            UpdateBackPanels()
            Me.WindowState = StartupWindowState
        Else
            Me.WindowState = StartupWindowState
            SetSplitterPosition(StartupSplitterPosition)
            UpdateBackPanels()
        End If
        ' ---------------------------------------------------- init form and graphics
        InitToolCursors()
        CNC_CalcToolPositions()
        ShowToolCursors()
        Form_Calibrations.SetAllParams()
        Form_Options.SetAllParams()
        SetAllParams()
        UpdateFeedSpeedLockedButton()
        UpdateLookAheadButton()
        SKIN_SetUserInterfaceColors()
        CNC_InitViewParams()
        CNC_EnsureSafeValuesToInputSlots()
        ' ------------------------------------------------------------
        '  VISIBLE = FALSE must be AFTER form settings (LOAD and INIT) 
        '  and BEFORE slow operations (LOAD GCODE and START HAL)
        ' ------------------------------------------------------------
        Me.Visible = False
        ' ---------------------------------------------------- load GCode
        LoadGcode(GcodeFile_PathAndName)
        ResetGcodeTime()
        ' ---------------------------------------------------- init axis
        CNC_Dest = CNC_Tip
        CNC_ResetAllAxis()
        ShowCoords()
        ' ---------------------------------------------------- start HAL
        If btn_HalEnabled.Checked Then
            StartThereminoHAL()
            ' --------------------- simulate slow computers
            'SleepMyThread(8000)
            ' ---------------------
        End If
        ' ---------------------------------------------------- start
        EventsAreEnabled = True
        ShedulerMaxPrecision()
        UserInterfaceTimer_Start()
        ExecutionThread_Start()
        JOY_Open()
        ' ---------------------------------------------------- invalid codes and minimized
        If GC_InvalidCodes <> "" Then
            If WindowState = FormWindowState.Minimized Then
                WindowState = FormWindowState.Normal
            End If
        End If
        ' ---------------------------------------------------- show
        Me.ShowInTaskbar = True
        Me.Visible = True
        Me.Activate()
        Pic_Toolpath.Focus()
        If OperatingSystemIsWindows Then
            Forms_FadeTo(1, 300)
        Else
            Me.Opacity = 1
        End If
        ' ---------------------------------------------------- XP bug correction
        If OperatingSystemIs_XP_or_Vista Then
            btn_HalEnabled.Left = Me.ClientSize.Width - btn_HalEnabled.Width - 2
            btn_InOutEnabled.Left = btn_HalEnabled.Left - btn_InOutEnabled.Width - 2
        End If
        ' ---------------------------------------------------- RTB bug correction
        RTB.AutoWordSelection = True
        RTB.AutoWordSelection = False
        ' ---------------------------------------------------- test invalid codes
        PARSER_TestInvalidCodes()
        ' ---------------------------------------------------- test GamePad POV
        JOY_TestPovInitialStatus()
        ' -------------------------------------------------------------------------------
        ' REAL-TIME - The execution Thread is not influenced by this
        ' -------------------------------------------------------------------------------
        'System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Normal
        'System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If CNC_GcodeRunning Or btn_GcodePause.Checked Then
            Select Case Form_MsgBox.Message_YesNo("Gcode is running." + vbCrLf + _
                                                  "Stop GCode and close all ?", ContentAlignment.MiddleLeft)
                Case "YES"
                Case Else
                    e.Cancel = True
                    Return
            End Select
        End If
        If Not TestGcodeModified() Then
            e.Cancel = True
            Return
        End If
        ' -------------------------------------- 
        Form_Replace.Hide()
        Form_Calibrations.Hide()
        Form_Options.Hide()
        ' -------------------------------------- close
        EventsAreEnabled = False
        ShedulerDefaultPrecision()
        UserInterfaceTimer_Stop()
        ExecutionThread_Stop()
        GraphicThread_Stop()
        JOY_Close()
        CNC_SetSpeed(0)
        txt_Speed.NumericValueInteger = 0
        CNC_ResetCoolings()
        CNC_SetMainEnableOutput(False)
        CNC_ResetSpindleOutputs(True)
        Save_INI()
        StopThereminoHAL()
        ' -------------------------------------- fade
        If OperatingSystemIs_XP_or_Vista Then
            Forms_FadeTo(0, 50)
        ElseIf OperatingSystemIsWindows Then
            Forms_FadeTo(0, 300)
        Else
            Me.Opacity = 1
        End If
        Me.Refresh()
    End Sub

    Friend Sub ShowWindowTitle()
        Text = AppTitleAndVersion()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Exit Sub
        If WindowState = FormWindowState.Minimized Then Return
        CorrectSplitterPosition()
    End Sub

    Friend Sub RefreshForm_OnlyForXP()
        If OperatingSystemIs_XP_or_Vista Then
            Me.Refresh()
        End If
    End Sub

    Private Sub Pic_Toolpath_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pic_Toolpath.SizeChanged
        If Not EventsAreEnabled Then Exit Sub
        GraphicThread_InitToolPathImageAndGraphics()
        GraphicThread_DrawToolpathImage(True)
        InitToolCursors()
        If SkinHasButtonsImages Then SKIN_SetUserInterfaceColors()
    End Sub

    Friend Sub GetWindowsDPI()
        ' -------------------------------------------------- get DPI coefficient
        ' Small - 100% =  96 DPI (Pixels/Dots Per Inch)
        'Medium - 125% = 120 DPI (Pixels/Dots Per Inch)
        'Larger - 150% = 144 DPI (Pixels/Dots Per Inch)
        WindowsDpiCoeff = Me.CreateGraphics.DpiX / 96.0F

        ' -------------------------------------------------- correct some items
        If WindowsDpiCoeff > 1 Then
            PanelBack1Min = 380
            PanelBack2Min = 785
            StatusStrip1.Height = 28
        Else
            PanelBack1Min = 300
            PanelBack2Min = 590
            StatusStrip1.Height = 24
        End If

        ' --------------------------------------------------------------------- 
        '  Correct MinWidth for XP and Windows10 with high DPI settings
        ' --------------------------------------------------------------------- 
        If Me.MinimumSize.Width < PanelBack1Min + PanelBack2Min Then
            Me.MinimumSize = New Size(PanelBack1Min + PanelBack2Min, _
                                      Me.MinimumSize.Height)
        End If

        ' ---------------------------------------------------------------------
        '  Correct positions and dimensions if they are out of the form window
        '  These errors could be caused by video driver errors, on some PC
        '  like, for example, the "Acer Aspire One D260"
        ' ---------------------------------------------------------------------
        If btn_HalEnabled.Right > Me.ClientSize.Width Then
            btn_HalEnabled.Left = Me.ClientSize.Width - btn_HalEnabled.Width
            btn_InOutEnabled.Left = btn_HalEnabled.Left - btn_InOutEnabled.Width
        End If
        Dim ClientAreaHeight As Int32 = Me.ClientSize.Height _
                                        - MenuStrip1.Height _
                                        - ToolStrip1.Height _
                                        - StatusStrip1.Height
        If PanelBack1.Height > ClientAreaHeight Then
            PanelBack1.Height = ClientAreaHeight - 1
            PanelBack2.Height = ClientAreaHeight - 1
            PanelSplitter.Height = ClientAreaHeight - 5
        End If

    End Sub

    Private Sub txt_Debug_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_Debug.MouseDoubleClick
        DebugWindow_Hide()
    End Sub

    Private Sub ShowTemperaturePanel()
        If Menu_ControlTemperatures.Checked Then
            GroupBox_Temperatures.Visible = True
            GroupBox_Gcode.Top = GroupBox_Temperatures.Bottom + 6
            GroupBox_Gcode.Height = GroupBox_Controls.Top - GroupBox_Gcode.Top - 6
            TemperatureController.Active = True
        Else
            GroupBox_Temperatures.Visible = False
            GroupBox_Gcode.Top = GroupBox_Toolpath.Top
            GroupBox_Gcode.Height = GroupBox_Controls.Top - 6
            TemperatureController.Active = False
        End If
    End Sub


    ' ==============================================================================================================
    '   UPDATE USER INTERFACE INFO
    ' ==============================================================================================================
    Private Sub UpdateUserInterfaceInfo()
        EventsAreEnabled = False
        ShowSelectedLine()
        ShowGcodeLine()
        ShowGcodeTime()
        ShowFeed()
        ShowSpeed()
        ShowCoords()
        ShowToolCursors()
        ShowTemperatures()
        EventsAreEnabled = True
    End Sub

    ' ==============================================================================================================
    '   USER INTERFACE INFO
    ' ==============================================================================================================
    Private CursorLine As Int32 = Int32.MinValue
    Private Sub ShowSelectedLine()
        If CNC_LineInExecution <> CursorLine Then
            CursorLine = CNC_LineInExecution
            If CursorLine >= 0 And CursorLine < GcodeLines.Length Then
                ' ------------------------------------------------------------------------- slow RTB functions
                ' WARNING - Some RTB accessing functions are very slow -
                ' Do not use RTB.ScrollToCaret 
                ' Do not use RTB.Lines(CursorLine).Length
                ' Use GcodeLines(CursorLine).Length instead
                ' ------------------------------------------------------------------------- fast
                'RTB.PaintEventEnabled = False
                'RTB.SelectionLength = 0
                'RTB.SelectionStart = RTB.GetFirstCharIndexFromLine(OldSelectedLine)
                'RTB.SelectionLength = GcodeLines(OldSelectedLine).Length
                'RTB.PaintEventEnabled = True
                ' ------------------------------------------------------------------------- fast
                'RTB.PaintEventEnabled = False
                'RTB.SelectionLength = 0
                'RTB.Select(RTB.GetFirstCharIndexFromLine(CursorLine), GcodeLines(CursorLine).Length)
                'RTB.PaintEventEnabled = True
                ' ------------------------------------------------------------------------- fast and middle selected line
                RTB.PaintEventEnabled = False
                RTB.SelectionLength = 0
                Dim lastline As Int32 = CursorLine + RTB.VisibleLines \ 2 - 1
                If lastline >= RTB.Lines.Length Then lastline = RTB.Lines.Length - 1
                If lastline < 0 Then lastline = 0
                RTB.Select(RTB.GetFirstCharIndexFromLine(lastline), 1)
                RTB.Select(RTB.GetFirstCharIndexFromLine(CursorLine), GcodeLines(CursorLine).Length)
                RTB.PaintEventEnabled = True
            End If
        End If
    End Sub
    Friend Sub ShowGcodeLine()
        Static old As Int32 = Int32.MinValue
        If CNC_LineToBeExecuted <> old Then
            old = CNC_LineToBeExecuted
            StatusLabel1.Text = "Line: " + (old + 1).ToString
        End If
    End Sub
    Friend Sub ShowGcodeTotalLines()
        StatusLabel2.Text = "Total lines: " + GcodeLines.Length.ToString
    End Sub
    Friend Sub ShowGcodeTotalTime()
        StatusLabel3.Text = "Total time: " + SecondsToMinSec(CNC_CalcTotalTime)
    End Sub
    Friend Sub ShowGcodeTime()
        Static old As Int32 = Int32.MinValue
        Dim sec As Int32 = CInt(GcodeTime.Elapsed.TotalSeconds)
        If sec <> old Then
            old = sec
            StatusLabel4.Text = "Time: " + SecondsToMinSec(sec)
        End If
    End Sub
    Friend Sub ShowGcodeName()
        Static old As String = ""
        If GcodeFile_PathAndName <> old Then
            old = GcodeFile_PathAndName
            StatusLabel5.Text = "File: " + IO.Path.GetFileName(old)
        End If
    End Sub
    Friend Sub ShowFeed()
        Static old As Double = Double.MinValue
        If CNC_Feed <> old Then
            old = CNC_Feed
            txt_Feed.Text = old.ToString("0")
        End If
    End Sub
    Friend Sub ShowSpeed()
        Static old As Double = Double.MinValue
        If CNC_Speed <> old Then
            old = CNC_Speed
            txt_Speed.Text = old.ToString("0")
        End If
    End Sub
    Private Sub ShowCoords()
        Static oldx As Double = Double.MinValue
        Static oldy As Double = Double.MinValue
        Static oldz As Double = Double.MinValue
        Static olda As Double = Double.MinValue
        Static oldb As Double = Double.MinValue
        With UserInterfaceTipPosition
            If .x <> oldx Then
                oldx = .x
                lbl_CoordX.Text = oldx.ToString("0.000", Globalization.CultureInfo.InvariantCulture)
            End If
            If .y <> oldy Then
                oldy = .y
                lbl_CoordY.Text = oldy.ToString("0.000", Globalization.CultureInfo.InvariantCulture)
            End If
            If .z <> oldz Then
                oldz = .z
                lbl_CoordZ.Text = oldz.ToString("0.000", Globalization.CultureInfo.InvariantCulture)
            End If
            If .a <> olda Then
                olda = .a
                lbl_CoordA.Text = olda.ToString("0.000", Globalization.CultureInfo.InvariantCulture)
            End If
            If .b <> oldb Then
                oldb = .b
                lbl_CoordB.Text = oldb.ToString("0.000", Globalization.CultureInfo.InvariantCulture)
            End If
        End With
    End Sub
    Private CursorDeltaX As Int32
    Private CursorDeltaY As Int32
    Friend Sub InitToolCursors()
        CursorDeltaX = Pic_Toolpath.Location.X + 2
        CursorDeltaY = Pic_Toolpath.Location.Y + 2
        ToolPositionX = -99
        ToolPositionY = -99
        PanelCursor1.Top = CursorDeltaY
        PanelCursor1.Height = Pic_Toolpath.ClientSize.Height
        PanelCursor2.Left = CursorDeltaX
        PanelCursor2.Width = Pic_Toolpath.ClientSize.Width
        ShowToolCursors()
    End Sub
    Private Sub ShowToolCursors()
        If Math.Abs(ToolPositionX) > 100000 Or Math.Abs(ToolPositionY) > 100000 Then Return
        Dim x As Int32 = CInt(ToolPositionX)
        Dim y As Int32 = CInt(ToolPositionY)
        If x < 0 Or x > Pic_Toolpath.ClientSize.Width Then x = -99
        If y < 0 Or y > Pic_Toolpath.ClientSize.Height Then y = -99
        PanelCursor1.Left = x + CursorDeltaX
        PanelCursor2.Top = y + CursorDeltaY
    End Sub
    Private Sub ShowTemperatures()
        If TemperatureController.Active Then
            lbl_TempAmbient.Text = "Ambient " + TempAmbient.GetText()
            lbl_TempChamber.Text = "Chamber " + TempChamber.GetText()
            lbl_TempPrintBed.Text = "Print bed" + TempPrintBed.GetText()
            lbl_TempExtruders.Text = "Extruders " + TempExtruder1.GetText() + " " + _
                                                    TempExtruder2.GetText()
        End If
    End Sub

    ' ====================================================================================================
    '  USER INTERFACE TIMER
    ' ====================================================================================================
    Private RedrawAfterStop As Boolean = False
    Private UiRedrawEnabled As Boolean = True

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        If UiRedrawEnabled Then
            UpdateUserInterfaceInfo()
        End If
        If CNC_GcodeRunning Then
            ToolpathPic.Invalidate()
        End If
        ' ------------------------------------------------------------- 
        If RedrawAfterStop Then
            If CNC_Distance = 0 Then
                RedrawAfterStop = False
                ' ----------------------------------------------------- recalc view params if not zoomed
                If CNC_GetZoom() < 1.5 Then
                    GraphicThread_DrawToolpathImage(True)
                Else
                    GraphicThread_CenterViewArea()
                End If
            End If
        End If
        ' -------------------------------------------------------------
        Form_MsgBox.TestHide()
        ' -------------------------------------------------------------
        JOY_TimedExecution()
        ' -------------------------------------------------------------
        DebugWindowUpdate()
        ' -------------------------------------------------------------
        'StatusLabel5.Text = Thread_LoopTimeMin.ToString("0.000 mS") + "   " + _
        '                    Thread_LoopTimeMax.ToString("0.000 mS")
    End Sub
    Friend Sub UserInterfaceTimer_Start()
        Timer1.Interval = 50
        Timer1.Enabled = True
    End Sub
    Friend Sub UserInterfaceTimer_Stop()
        Timer1.Enabled = False
    End Sub
    Friend Sub UserInterfaceRedraw_Enable()
        UiRedrawEnabled = True
    End Sub
    Friend Sub UserInterfaceRedraw_Disable()
        UiRedrawEnabled = False
    End Sub

    Friend Sub ActivateTest_ForRedrawAfterStop()
        ' this little change ensures that distance will be different from zero in the first test
        CNC_Distance += 0.000000001
        RedrawAfterStop = True
    End Sub

End Class

