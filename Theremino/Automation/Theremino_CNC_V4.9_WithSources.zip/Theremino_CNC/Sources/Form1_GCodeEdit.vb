﻿Partial Class Form1

    ' ==============================================================================================================
    '   RTB - GCODE EDIT
    ' ==============================================================================================================
    Private Sub RTB_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RTB.SelectionChanged
        If Not EventsAreEnabled Then Return
        If CNC_GcodeRunning Or btn_GcodePause.Checked Then Return
        CNC_LineInExecution = RTB.GetLineFromCharIndex(RTB.SelectionStart)
        CNC_LineToBeExecuted = CNC_LineInExecution
        ShowGcodeLine()
        CursorLine = -1
    End Sub
    Private Sub RTB_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RTB.TextChanged
        If Not EventsAreEnabled Then Return
        SetGcodeModifiedFlag(RTB.Modified)
        TextChangedSinceLastRedraw = True
    End Sub
    Private Sub RTB_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RTB.KeyDown
        If e.Modifiers = Keys.Control Then
            Select Case e.KeyCode
                Case Keys.Z, Keys.U
                    If RTB.CanUndo Then
                        SetCursor_Hourglass()
                        RTB.Undo()
                        Undo_Redo_PostActions()
                        SetCursor_Default()
                    End If
                    e.Handled = True
                Case Keys.Y, Keys.R
                    If RTB.CanRedo Then
                        SetCursor_Hourglass()
                        RTB.Redo()
                        Undo_Redo_PostActions()
                        SetCursor_Default()
                    End If
                    e.Handled = True
                Case Keys.F
                    Editor_FindAndReplace()
                    e.Handled = True
            End Select
        End If
    End Sub
    Private TextChangedSinceLastRedraw As Boolean = False
    Private Sub RTB_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RTB.KeyUp
        If TextChangedSinceLastRedraw Then
            TextChangedSinceLastRedraw = False
            ReparseGcodeAndUpdateUserInterface()
        Else
            GraphicThread_DrawToolpathImage(False)
        End If
    End Sub
    Friend Sub SetGcodeModifiedFlag(ByVal modified As Boolean)
        If modified Then
            GroupBox_Gcode.Text = "GCode (modified)"
        Else
            GroupBox_Gcode.Text = "GCode"
        End If
        GcodeModified = modified
    End Sub
    Private Sub RTB_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RTB.MouseDown
        If CNC_GcodeRunning Or btn_GcodePause.Checked Then
            Pic_Toolpath.Select()
            Return
        End If
        UserInterfaceRedraw_Disable()
        ' -------------------------------------- used to update red part on toolpath
        GraphicThread_DrawToolpathImage(False)
        CNC_TimedUpdateEnabled = False
    End Sub

    Private Sub Undo_Redo_PostActions()
        ReparseGcodeAndUpdateUserInterface()
        RTB.ScrollToCaret()
        If Not RTB.CanUndo Then SetGcodeModifiedFlag(False)
        GraphicThread_DrawToolpathImage(True)
    End Sub

    Friend Sub ReparseGcodeAndUpdateUserInterface()
        GcodeLines = RTB.Lines
        PARSER_ParseGcode()
        ' --------------------------------------------- speed test
        'Dim sw As Stopwatch = New Stopwatch
        'sw.Start()
        ' ---------------------------------------------
        GraphicThread_DrawToolpathImage(True)
        GraphicThread_WaitToolpathImageCompletion()
        ' ---------------------------------------------
        'Me.Text = sw.ElapsedMilliseconds.ToString
        ' ---------------------------------------------
        ShowGcodeTotalLines()
        ShowGcodeTotalTime()
        EnableCoordinates()
        CalibrationButtons_Enable()
        CNC_CalcToolPositions()
        ShowToolCursors()
    End Sub

    Friend Sub EnableCoordinates()
        lbl_CoordZ.Visible = GC_UsedZ
        lbl_CoordA.Visible = GC_UsedA
        lbl_CoordB.Visible = GC_UsedB
        btn_ZeroZ.Visible = GC_UsedZ
        btn_ZeroA.Visible = GC_UsedA
        btn_ZeroB.Visible = GC_UsedB
        btn_ZeroA.Text = GC_NameA
        btn_ZeroB.Text = GC_NameB
    End Sub

    ' ==============================================================================================================
    '   GCODE TEXTBOX COMMANDS
    ' ==============================================================================================================
    Private Sub btn_ZoomMinus_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ZoomMinus.ClickButtonArea
        EventsAreEnabled = False
        SetZoomFactor(RTB.ZoomFactor - 0.1F)
        EventsAreEnabled = True
    End Sub
    Private Sub btn_ZoomPlus_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ZoomPlus.ClickButtonArea
        EventsAreEnabled = False
        SetZoomFactor(RTB.ZoomFactor + 0.1F)
        EventsAreEnabled = True
    End Sub
    Friend Sub SetZoomFactor(ByVal z As Single)
        z = CInt(z * 10) / 10.0F
        If z < 0.5 Or z > 1.4 Then Return
        If z > 0.9 Then
            RTB.Font = New Font(RTB.Font, FontStyle.Regular)
        Else
            RTB.Font = New Font(RTB.Font, FontStyle.Bold)
        End If
        RTB.ZoomFactor = z
        RTB.CalcVisibleLinesCount()
        RTB.Focus()
    End Sub
    Private Sub btn_Up_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Up.ClickButtonArea
        For i As Int32 = RTB.GetLineFromCharIndex(RTB.SelectionStart) - 1 To 1 Step -1
            If GCodeParsedLines(i).LastCMD = "TOOL" Or GCodeParsedLines(i).LastCMD = "PAUSE" Then
                CNC_LineInExecution = i
                CNC_LineToBeExecuted = i + 1
                UpdateUserInterfaceInfo()
                GraphicThread_DrawToolpathImage(False)
                Return
            End If
        Next
        CNC_LineInExecution = 0
        CNC_LineToBeExecuted = CNC_LineInExecution
        UpdateUserInterfaceInfo()
        GraphicThread_DrawToolpathImage(False)
        RTB.Focus()
    End Sub
    Private Sub btn_Down_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Down.ClickButtonArea
        For i As Int32 = RTB.GetLineFromCharIndex(RTB.SelectionStart) + 1 To RTB.Lines.Length - 1 Step 1
            If GCodeParsedLines(i).LastCMD = "TOOL" Or GCodeParsedLines(i).LastCMD = "PAUSE" Then
                CNC_LineInExecution = i
                CNC_LineToBeExecuted = i + 1
                UpdateUserInterfaceInfo()
                GraphicThread_DrawToolpathImage(False)
                Return
            End If
        Next
        CNC_LineInExecution = RTB.Lines.Length - 1
        CNC_LineToBeExecuted = CNC_LineInExecution
        UpdateUserInterfaceInfo()
        GraphicThread_DrawToolpathImage(False)
        RTB.Focus()
    End Sub


    ' -----------------------------------------------------------------------------------------------------
    '  CONTEXTUAL MENU - EDITOR
    ' -----------------------------------------------------------------------------------------------------
    Private Sub CTX_Edit_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles CTX_Edit.Opening
        If RTB.SelectionLength > 0 Then
            CTX_Edit_Cut.Enabled = True
            CTX_Edit_Copy.Enabled = True
            CTX_Edit_Delete.Enabled = True
        Else
            CTX_Edit_Cut.Enabled = False
            CTX_Edit_Copy.Enabled = False
            CTX_Edit_Delete.Enabled = False
        End If
        CTX_Edit_Paste.Enabled = RTB.CanPaste(DataFormats.GetFormat(DataFormats.Text))
        CTX_Edit_Undo.Enabled = RTB.CanUndo
        CTX_Edit_Redo.Enabled = RTB.CanRedo
        SKIN_UpdateControlBaseColors(CTX_Edit)
    End Sub
    Private Sub CTX_Edit_Opened(ByVal sender As Object, ByVal e As System.EventArgs) Handles CTX_Edit.Opened
        CTX_Edit.Top -= 15
        CTX_Edit.Left -= 100
    End Sub
    Private Sub CTX_Edit_Cut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Cut.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ExecCut()
        ReparseGcodeAndUpdateUserInterface()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Copy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Copy.Click
        RTB.ExecCopy()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Paste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Paste.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ExecPaste()
        ReparseGcodeAndUpdateUserInterface()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Delete.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ExecDelete()
        ReparseGcodeAndUpdateUserInterface()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_SelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_SelectAll.Click
        RTB.SelectAll()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Comment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Comment.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("COMMENT", True)
        CNC_CalcToolPositions()
        ShowToolCursors()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Uncomment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Uncomment.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("UNCOMMENT", True)
        CNC_CalcToolPositions()
        ShowToolCursors()
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Indent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Indent.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("INDENT", True)
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Unindent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Unindent.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("UNINDENT", True)
        RTB.Focus()
    End Sub
    Private Sub CTX_Edit_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Find.Click
        Editor_FindAndReplace()
    End Sub
    Private Sub CTX_Edit_Undo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Undo.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        SetCursor_Hourglass()
        RTB.Undo()
        Undo_Redo_PostActions()
        RTB.Focus()
        SetCursor_Default()
    End Sub
    Private Sub CTX_Edit_Redo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTX_Edit_Redo.Click
        CTX_Edit.Close()
        RefreshForm_OnlyForXP()
        SetCursor_Hourglass()
        RTB.Redo()
        Undo_Redo_PostActions()
        RTB.Focus()
        SetCursor_Default()
    End Sub

    ' ===============================================================================================================
    '  FIND - REPLACE and Options
    ' ===============================================================================================================
    Private Sub Editor_FindAndReplace()
        With Form_Replace
            Dim p As Point
            p.X = Me.PanelSplitter.Right
            p.Y = Me.GroupBox_Motors.Top + 40
            p = Me.PointToScreen(p)
            .Location = p
            .lblFind.BackgroundImage = Nothing
            .lblReplace.BackgroundImage = Nothing
            .txtFind.Text = Strings.Left(RTB.SelectedText, 16)
            .txtReplace.Text = .txtFind.Text
            .txtFind.SelectionStart = 99
            .txtFind.SelectionLength = 0
            .txtFind.Refresh()
            .txtFind.Focus()
        End With
        Form_Replace.OwnerCodeBox = RTB
        Form_Replace.Hide()
        Form_Replace.Show(Me)
    End Sub

End Class
