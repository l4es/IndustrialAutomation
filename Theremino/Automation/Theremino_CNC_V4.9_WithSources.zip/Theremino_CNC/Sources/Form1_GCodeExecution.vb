﻿Partial Class Form1

    ' ==============================================================================================================
    '   COMMANDS
    ' ==============================================================================================================
    Private Sub btn_GcodeStart_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeStart.ClickButtonArea
        StartRunningState()
    End Sub
    Private Sub btn_GcodePause_ClickButtonArea(ByVal Sender As Object, ByVal e As System.EventArgs) Handles btn_GcodePause.ClickButtonArea
        Pic_Toolpath.Focus()
        If Not btn_GcodeStart.Checked Then
            btn_GcodePause.Checked = False
            Return
        End If
        If btn_GcodePause.Checked Then
            UserInterfaceRedraw_Disable()
            RTB.ContextMenuStrip = CTX_Edit
            CNC_GcodeRunning = False
            CNC_TimedUpdateEnabled = False
            CNC_SetSpindleOnOff(0)
            GcodeTime.Stop()
            If CNC_LineInExecution > 0 Then
                CNC_LineInExecution -= 1
                CNC_LineToBeExecuted -= 1
            End If
        Else
            CNC_EnableTimedUpdateAndUserInterface()
            GraphicThread_DrawToolpathImage(False)
            CNC_RestoreOutputSignals()
            RTB.ContextMenuStrip = Nothing
            CNC_GcodeRunning = True
            GcodeTime.Start()
        End If
        SKIN_UpdateButtons_Form1()
    End Sub
    Private Sub btn_GcodeStop_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GCodeStop.ClickButtonArea
        btn_GCodeStop.Text = "STOP"
        CNC_GcodeRunning = True
        StopRunningState("")
        StopCalibrations()
        SKIN_UpdateButtons_Form1()
    End Sub
    Private Sub btn_GcodeLoad_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeLoad.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        btn_GCodeStop.Text = "STOP"
        LoadGcodeDialog()
        btn_GcodeLoad.Checked = False
        Pic_Toolpath.Focus()
        SKIN_UpdateButtons_Form1()
        UserInterfaceRedraw_Disable()
        RTB.SelectionLength = 1
    End Sub
    Private Sub btn_GcodeRewind_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GcodeRewind.ClickButtonArea
        RewindGcode()
    End Sub

    Friend Sub RewindGcode()
        If Not btn_GcodeRewind.Enabled Then Return
        SKIN_UpdateButtons_Form1()
        btn_GCodeStop.Text = "STOP"
        btn_GcodeRewind.Refresh()
        CNC_LineInExecution = 0
        CNC_LineToBeExecuted = 0
        UpdateUserInterfaceInfo()
        UserInterfaceRedraw_Disable()
        RTB.SelectionLength = 1
        CNC_Dest = CNC_Tip
        CNC_SetFeedMode(Feed_Modes.None)
        btn_GcodeRewind.Checked = False
        Pic_Toolpath.Focus()
        GraphicThread_DrawToolpathImage(False)
        ResetGcodeTime()
        SKIN_UpdateButtons_Form1()
    End Sub

    Friend Sub StartRunningState()
        If CNC_GcodeRunning Then
            btn_GcodeStart.Checked = True
            btn_GcodePause.Checked = True
            btn_GcodePause_ClickButtonArea(New Object, New System.EventArgs)
            Return
        End If
        If GCodeParsedLines.Length = 0 Then
            btn_GcodeStart.Checked = False
            SKIN_UpdateButtons_Form1()
            Return
        End If
        If GC_UsedZ AndAlso CNC_TestLowZ AndAlso _
           CNC_Tip.z < CNC_WarningZeta AndAlso Not btn_GcodePause.Checked Then
            If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                         vbCr + "Do you really want to start?") <> "YES" Then
                btn_GcodeStart.Checked = False
                SKIN_UpdateButtons_Form1()
                Return
            End If
        End If
        ExecutionThread_Stop()
        CNC_ReadTemperatureTables()
        ExecutionThread_Start()
        Pic_Toolpath.Focus()
        btn_GCodeStop.Text = "STOP"
        btn_GCodeStop.Checked = False
        btn_GcodePause.Checked = False
        btn_GcodeStart.Checked = True
        RTB.ReadOnly = True
        RTB.ContextMenuStrip = Nothing
        EnableAllControls(False)
        CalibrationButtons_Disable()
        GraphicThread_DrawToolpathImage(False)
        GraphicThread_WaitToolpathImageCompletion()
        CNC_SetAccessoryEnableOutput(True)
        CNC_RestoreOutputSignals()
        CNC_EnsureZeroToDeltaSlots()
        CNC_EnsureSafeValuesToInputSlots()
        ' ----------------------------------------------- ensure zero to unsed axis
        If Not GC_UsedZ Then CNC_Dest.z = 0
        If Not GC_UsedA Then CNC_Dest.a = 0
        If Not GC_UsedB Then CNC_Dest.b = 0
        ' -----------------------------------------------
        CNC_SetFeedMode(GCodeParsedLines(CNC_LineInExecution).FeedMode)
        CNC_LookAhead_LastSegment.InitWithValue(0)
        CNC_GcodeRunning = True
        CNC_EnableTimedUpdateAndUserInterface()
        GcodeTime.Start()
        SKIN_UpdateButtons_Form1()
    End Sub

    Friend Sub StopRunningState(ByVal reason As String)
        If reason <> "" Then
            btn_GCodeStop.Text = "STOP (" + reason + ")"
            If reason = "end of program" Then
                RTB.ScrollToCaret()
            End If
        End If
        btn_GcodePause.Checked = False
        btn_GcodePause.Refresh()
        btn_GCodeStop.Checked = True
        btn_GCodeStop.Refresh()
        CNC_SetFeedMode(Feed_Modes.None)
        If CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.AllLocked Or _
           CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.SpeedLocked Then
            CNC_ResetSpindleOutputs(False)
        Else
            CNC_ResetSpindleOutputs(True)
        End If
        CNC_SetAccessoryEnableOutput(False)
        CNC_ResetCoolings()
        CNC_GcodeRunning = False
        CNC_TimedUpdateEnabled = False
        CNC_CipExecution = False
        CNC_CipExecute = False
        CNC_Dest = CNC_Tip
        GcodeTime.Stop()
        UserInterfaceRedraw_Disable()
        RTB.ReadOnly = False
        RTB.ContextMenuStrip = CTX_Edit
        btn_GcodeStart.Checked = False
        EnableAllControls(True)
        CalibrationButtons_Enable()
        CalibrationButtons_Uncheck()
        SKIN_UpdateButtons_Form1()
        UpdateUserInterfaceInfo()
        ' this overrides the "Max Err" effects (but it is better to see them)
        'GraphicThread_DrawToolpathImage(True)
        Pic_Toolpath.Focus()
    End Sub
    Friend Sub ResetGcodeTime()
        GcodeTime.Reset()
        ShowGcodeTime()
    End Sub
    Private Sub EnableAllControls(ByVal enable As Boolean)
        btn_InOutEnabled.Enabled = enable
        btn_HalEnabled.Enabled = enable
        Menu_File.Enabled = enable
        Menu_Tools.Enabled = enable
        Menu_Options.Enabled = enable
        Menu_Skins.Enabled = enable
        Menu_3DPrinters.Enabled = enable
        ToolStripButton_LoadGcode.Enabled = enable
        ToolStripButton_SaveGcode.Enabled = enable
        ToolStripButton_SaveGcodeAs.Enabled = enable
        btn_GcodeLoad.Enabled = enable
        btn_GcodeRewind.Enabled = enable
        btn_Up.Enabled = enable
        btn_Down.Enabled = enable
        btn_GotoZero.Enabled = enable
        btn_GotoHome.Enabled = enable
        btn_GotoBottomLeft.Enabled = enable
        btn_GotoTopRight.Enabled = enable
        btn_ZeroX.Enabled = enable
        btn_ZeroY.Enabled = enable
        btn_ZeroZ.Enabled = enable
        btn_ZeroA.Enabled = enable
        btn_ZeroB.Enabled = enable
    End Sub

    Private Sub DisableAll(ByVal reason As String) ' M84
        CNC_SetMainEnableOutput(False)
        btn_InOutEnabled.Checked = False
    End Sub

    ' ==================================================================================================
    '   CROSS THREAD FUNCTIONS
    ' ==================================================================================================
    Friend Delegate Sub DisableAllCrossThread_Delegate(ByVal reason As String)
    Friend Sub DisableAllCrossThread(ByVal reason As String)
        If InvokeRequired Then
            BeginInvoke(New DisableAllCrossThread_Delegate(AddressOf DisableAll), reason)
        Else
            DisableAll(reason)
        End If
    End Sub

    Friend Delegate Sub StopRunningStateCrossThread_Delegate(ByVal reason As String)
    Friend Sub StopRunningStateCrossThread(ByVal reason As String)
        If InvokeRequired Then
            BeginInvoke(New StopRunningStateCrossThread_Delegate(AddressOf StopRunningStateCrossThread), reason)
        Else
            StopRunningState(reason)
        End If
    End Sub

    Friend Delegate Sub MessageCrossThread_Delegate(ByVal text As String)
    Friend Sub MessageCrossThread(ByVal text As String)
        If InvokeRequired Then
            BeginInvoke(New MessageCrossThread_Delegate(AddressOf MessageCrossThread), text)
        Else
            Form_MsgBox.Message_OK(text, , 16)
        End If
    End Sub

    Friend Delegate Sub SimpleMessageCrossThread_Delegate(ByVal text As String)
    Friend Sub SimpleMessageCrossThread(ByVal text As String)
        If InvokeRequired Then
            BeginInvoke(New SimpleMessageCrossThread_Delegate(AddressOf SimpleMessageCrossThread), text)
        Else
            Form_MsgBox.SimpleMessage(text)
        End If
    End Sub

End Class
