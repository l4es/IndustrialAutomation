﻿
Partial Class Form1

    ' =========================================================================
    '   THEREMINO HAL - START STOP
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        If HalProcess Is Nothing OrElse HalProcess.HasExited Then
            Dim path As String = Application.StartupPath & "\Theremino_HAL.exe"
            If Not My.Computer.FileSystem.FileExists(path) Then
                path = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
            End If
            If Not My.Computer.FileSystem.FileExists(path) Then Return
            Dim psi As New ProcessStartInfo
            psi.WorkingDirectory = IO.Path.GetDirectoryName(path)
            psi.FileName = path
            HalProcess = Process.Start(psi)
            HalProcess.SynchronizingObject = Me
            ' ----------------------------------------------- Wait HAL really started 
            For i As Int32 = 1 To 100
                SleepMyThread(100)
                HalProcess.Refresh()
                If HalProcess.MainWindowTitle.Contains(".") Then Exit For
            Next
        End If
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing Then
            If HalProcess.HasExited Then
                HalProcess = Nothing
                Return
            End If
            For i As Int32 = 1 To 100
                HalProcess.CloseMainWindow()
                HalProcess.Refresh()
                SleepMyThread(100)
                If HalProcess.HasExited Then
                    HalProcess = Nothing
                    Return
                End If
            Next
            HalProcess.Kill()
            HalProcess = Nothing
        End If
    End Sub

    Private Sub btn_HalEnabled_CheckedChanged(ByVal Sender As Object, ByVal e As System.EventArgs) Handles btn_HalEnabled.CheckedChanged
        If Not EventsAreEnabled Then Exit Sub
        If btn_HalEnabled.Checked Then
            StartThereminoHAL()
        Else
            StopThereminoHAL()
        End If
    End Sub


    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(180, 180, 180), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    ' ===================================================================================
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message.
    ' ===================================================================================
    '#If Not Debug Then
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub
    '#End If

    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_LoadGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_LoadGcode.Click
        LoadGcodeDialog()
        Pic_Toolpath.Focus()
    End Sub
    Private Sub Menu_File_SaveGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveGcode.Click
        SaveGcode_IfChanged()
    End Sub
    Private Sub Menu_File_SaveGcodeAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveGcodeAs.Click
        SaveGcodeDialog()
    End Sub
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        Me.Close()
    End Sub
    Private Sub Menu_File_SaveToolpathImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveToolpathImage.Click
        SaveImage(Pic_Toolpath)
    End Sub

    ' =======================================================================================
    '   MENU TOOLS
    ' =======================================================================================
    Private Sub Menu_Tools_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Tools.DropDownOpening
        If GC_UsedA Or GC_UsedB Then
            Menu_ConvertToMM_XYZAB.Enabled = True
            Menu_TranslateToZero_XYAB.Enabled = True
            Menu_RotateLeft_XYAB.Enabled = True
            Menu_RotateRight_XYAB.Enabled = True
        Else
            Menu_ConvertToMM_XYZAB.Enabled = False
            Menu_TranslateToZero_XYAB.Enabled = False
            Menu_RotateLeft_XYAB.Enabled = False
            Menu_RotateRight_XYAB.Enabled = False
        End If
    End Sub
    Private Sub Menu_ConvertToMM_XYZ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_ConvertToMM_XYZ.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("CONVERT_TO_MM_XYZ", False)
    End Sub
    Private Sub Menu_ConvertToMM_XYZAB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_ConvertToMM_XYZAB.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("CONVERT_TO_MM_XYZAB", False)
    End Sub
    Private Sub Menu_TranslateToZero_XY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_TranslateToZero_XY.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("TRANSLATE_TO_ZERO_XY", False)
    End Sub
    Private Sub Menu_TranslateToZero_XYAB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_TranslateToZero_XYAB.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("TRANSLATE_TO_ZERO_XYAB", False)
    End Sub
    Private Sub Menu_RotateLeft_XY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_RotateLeft_XY.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("ROTATE_LEFT_XY", False)
    End Sub
    Private Sub Menu_RotateLeft_XYAB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_RotateLeft_XYAB.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("ROTATE_LEFT_XYAB", False)
    End Sub
    Private Sub Menu_RotateRight_XY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_RotateRight_XY.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("ROTATE_RIGHT_XY", False)
    End Sub
    Private Sub Menu_RotateRight_XYAB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_RotateRight_XYAB.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("ROTATE_RIGHT_XYAB", False)
    End Sub
    Private Sub Menu_Normalize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Normalize.Click
        RefreshForm_OnlyForXP()
        RTB.ModifyGcode("NORMALIZE", False)
    End Sub

    ' =======================================================================================
    '   MENU Options
    ' =======================================================================================
    Private Sub Menu_Options_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Options.Click
        If Form_Options.Visible Then
            Form_Options.Hide()
        Else
            Dim p As Point
            p.X = 130
            p.Y = 30
            p = Me.PointToScreen(p)
            Form_Options.Opacity = 0
            Form_Options.Location = p
            Form_Options.Show(Me)
            Form_Options.Refresh()
            Form_Options.Opacity = 1
        End If
    End Sub

    ' =======================================================================================
    '   MENU 3D Printers
    ' =======================================================================================
    Private Sub Menu_ControlTemperatures_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_ControlTemperatures.Click
        ShowTemperaturePanel()
    End Sub
    Private Sub Menu_EditTempTables_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_EditTempTables.Click
        Dim f As String = Application.StartupPath + "\TemperatureTables.txt"
        If Not FileExists(f) Then Return
        Dim pr As Process = Process.Start(f)
        pr.WaitForExit()
        ExecutionThread_Stop()
        CNC_ReadTemperatureTables()
        ExecutionThread_Start()
    End Sub

    ' =======================================================================================
    '   MENU SKINS
    ' =======================================================================================
    Private Sub Menu_EditSkins_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_EditSkinFile.Click
        Dim f As String = Application.StartupPath + "\Skins\Skins.txt"
        If Not FileExists(f) Then Return
        Dim pr As Process = Process.Start(f)
        pr.WaitForExit()
        SKIN_SetUserInterfaceColors()
        GraphicThread_DrawToolpathImage(False)
    End Sub
    Private Sub Menu_OpenSkinsFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_OpenSkinsFolder.Click
        Process.Start(Application.StartupPath + "\Skins")
    End Sub
    Private Sub Menu_ReloadSelectedSkin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_ReloadSelectedSkin.Click
        SKIN_SetUserInterfaceColors()
        GraphicThread_DrawToolpathImage(False)
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelpENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelpENG.Click
        StartLocalizedHelp("Theremino_CNC_Help_ENG.pdf")
    End Sub
    Private Sub Menu_Help_ProgramHelpITA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelpITA.Click
        StartLocalizedHelp("Theremino_CNC_Help_ITA.pdf")
    End Sub
    Private Sub Menu_Help_GMcodes_ENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_GMcodes_ENG.Click
        StartLocalizedHelp("G_and_M_codes_ENG.pdf")
    End Sub
    Private Sub Menu_Help_GMcodes_ITA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_GMcodes_ITA.Click
        StartLocalizedHelp("G_and_M_codes_ITA.pdf")
    End Sub
    Private Sub Menu_Help_OpenFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_OpenFolder.Click
        Process.Start(Application.StartupPath + "\Docs")
    End Sub
    Private Sub StartLocalizedHelp(ByVal filename As String)
        filename = Application.StartupPath + "\Docs\" + filename
        If FileExists(filename) Then
            Process.Start(filename)
            Return
        End If
        If filename.EndsWith("_ENG.pdf") Then
            filename = filename.Replace("_ENG.pdf", "_ITA.pdf")
        End If
        If FileExists(filename) Then
            Process.Start(filename)
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog()
    End Sub

    ' =======================================================================================
    '   TOOLBAR
    ' =======================================================================================
    Private Sub ToolStripButton_LoadGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_LoadGcode.Click
        LoadGcodeDialog()
        Pic_Toolpath.Focus()
    End Sub
    Private Sub ToolStripButton_SaveGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_SaveGcode.Click
        SaveGcode_IfChanged()
    End Sub
    Private Sub ToolStripButton_SaveGcodeAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_SaveGcodeAs.Click
        SaveGcodeDialog()
    End Sub
    Private Sub ToolStripButton_Skin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Skin.Click
        SKIN_SelectSkin()
    End Sub
    Private Sub ToolStripButton_View_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_View.Click
        CNC_SelectViewType()
    End Sub


    ' ==============================================================================================================
    '   CHECK BUTTONS
    ' ==============================================================================================================
    Private Sub buttons_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles btn_InOutEnabled.ClickButtonArea, _
                                                                            btn_HalEnabled.ClickButtonArea, _
                                                                            btn_ToolStop.ClickButtonArea, _
                                                                            btn_TestLowZ.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        CalibrationButtons_Enable()
    End Sub
    Private Sub btn_FeedSpeedLocked_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                Handles btn_FeedSpeedLocked.ClickButtonArea
        '
        CNC_FeedSpeedLockedType = CType((CNC_FeedSpeedLockedType + 1) Mod 4, CNC_FeedSpeedLockedTypes)
        UpdateFeedSpeedLockedButton()
        SKIN_UpdateButtons_Form1()
        ShowGcodeTotalTime()
    End Sub
    Friend Sub UpdateFeedSpeedLockedButton()
        Select Case CNC_FeedSpeedLockedType
            Case CNC_FeedSpeedLockedTypes.AllFromGcode
                btn_FeedSpeedLocked.Text = "Feed & Speed from GCode"
                btn_FeedSpeedLocked.Checked = False
            Case CNC_FeedSpeedLockedTypes.FeedLocked
                btn_FeedSpeedLocked.Text = "Feed locked"
                btn_FeedSpeedLocked.Checked = True
            Case CNC_FeedSpeedLockedTypes.SpeedLocked
                btn_FeedSpeedLocked.Text = "Speed locked"
                btn_FeedSpeedLocked.Checked = True
            Case CNC_FeedSpeedLockedTypes.AllLocked
                btn_FeedSpeedLocked.Text = "Feed & Speed locked"
                btn_FeedSpeedLocked.Checked = True
        End Select
    End Sub
    Private Sub btn_LookAhead_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles btn_LookAhead.ClickButtonArea
        '
        CNC_LookAheadType = CType((CNC_LookAheadType + 1) Mod 4, CNC_LookAheadTypes)
        UpdateLookAheadButton()
        SKIN_UpdateButtons_Form1()
    End Sub
    Friend Sub UpdateLookAheadButton()
        Select Case CNC_LookAheadType
            Case CNC_LookAheadTypes.None
                btn_LookAhead.Text = "Look Ahead disabled"
                btn_LookAhead.Checked = False
                lbl_MaxErr.Visible = True
                txt_MaxError.Visible = True
            Case CNC_LookAheadTypes.LookAhead
                btn_LookAhead.Text = "Look Ahead enabled"
                btn_LookAhead.Checked = True
                lbl_MaxErr.Visible = True
                txt_MaxError.Visible = True
            Case CNC_LookAheadTypes.LookAheadHiPrecision
                btn_LookAhead.Text = "Look Ahead Hi-Precision"
                btn_LookAhead.Checked = True
                lbl_MaxErr.Visible = True
                txt_MaxError.Visible = True
            Case CNC_LookAheadTypes.ExactStopAllMotors
                btn_LookAhead.Text = "Stop every segment"
                btn_LookAhead.Checked = True
                lbl_MaxErr.Visible = False
                txt_MaxError.Visible = False
        End Select
    End Sub


    ' ==============================================================================================================
    '   CONTROLS HILIGHT ON MOUSE ENTER
    ' ==============================================================================================================
    Private Sub Buttons_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles btn_InOutEnabled.MouseEnter, _
                                                                            btn_HalEnabled.MouseEnter, _
                                                                            btn_ZoomMinus.MouseEnter, _
                                                                            btn_ZoomPlus.MouseEnter, _
                                                                            btn_Up.MouseEnter, _
                                                                            btn_Down.MouseEnter, _
                                                                            btn_ToolStop.MouseEnter, _
                                                                            btn_TestLowZ.MouseEnter, _
                                                                            btn_ZoomTpMinus.MouseEnter, _
                                                                            btn_ZoomTpPlus.MouseEnter, _
                                                                            btn_GotoZero.MouseEnter, _
                                                                            btn_GotoHome.MouseEnter, _
                                                                            btn_GotoBottomLeft.MouseEnter, _
                                                                            btn_GotoTopRight.MouseEnter, _
                                                                            btn_SetZetaHome.MouseEnter, _
                                                                            btn_CalibrateXY.MouseEnter, _
                                                                            btn_CalibrateAB.MouseEnter, _
                                                                            btn_CalibrateZ.MouseEnter, _
                                                                            btn_CalibrationSettings.MouseEnter, _
                                                                            btn_GcodeStart.MouseEnter, _
                                                                            btn_GcodeLoad.MouseEnter, _
                                                                            btn_GcodePause.MouseEnter, _
                                                                            btn_GcodeRewind.MouseEnter, _
                                                                            btn_GCodeStop.MouseEnter, _
                                                                            btn_FeedSpeedLocked.MouseEnter, _
                                                                            btn_LookAhead.MouseEnter, _
                                                                            btn_ZeroX.MouseEnter, _
                                                                            btn_ZeroY.MouseEnter, _
                                                                            btn_ZeroZ.MouseEnter, _
                                                                            btn_ZeroA.MouseEnter, _
                                                                            btn_ZeroB.MouseEnter
        SKIN_MouseEnteringButton(Sender)
    End Sub
    Private Sub Buttons_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                 Handles btn_InOutEnabled.MouseLeave, _
                                                                            btn_HalEnabled.MouseLeave, _
                                                                            btn_ZoomMinus.MouseLeave, _
                                                                            btn_ZoomPlus.MouseLeave, _
                                                                            btn_Up.MouseLeave, _
                                                                            btn_Down.MouseLeave, _
                                                                            btn_ToolStop.MouseLeave, _
                                                                            btn_TestLowZ.MouseLeave, _
                                                                            btn_ZoomTpMinus.MouseLeave, _
                                                                            btn_ZoomTpPlus.MouseLeave, _
                                                                            btn_GotoZero.MouseLeave, _
                                                                            btn_GotoHome.MouseLeave, _
                                                                            btn_GotoBottomLeft.MouseLeave, _
                                                                            btn_GotoTopRight.MouseLeave, _
                                                                            btn_SetZetaHome.MouseLeave, _
                                                                            btn_CalibrateXY.MouseLeave, _
                                                                            btn_CalibrateAB.MouseLeave, _
                                                                            btn_CalibrateZ.MouseLeave, _
                                                                            btn_CalibrationSettings.MouseLeave, _
                                                                            btn_GcodeStart.MouseLeave, _
                                                                            btn_GcodeLoad.MouseLeave, _
                                                                            btn_GcodePause.MouseLeave, _
                                                                            btn_GcodeRewind.MouseLeave, _
                                                                            btn_GCodeStop.MouseLeave, _
                                                                            btn_FeedSpeedLocked.MouseLeave, _
                                                                            btn_LookAhead.MouseLeave, _
                                                                            btn_ZeroX.MouseLeave, _
                                                                            btn_ZeroY.MouseLeave, _
                                                                            btn_ZeroZ.MouseLeave, _
                                                                            btn_ZeroA.MouseLeave, _
                                                                            btn_ZeroB.MouseLeave
        SKIN_MouseLeavingButton(Sender)
    End Sub

    Private Sub CoordLabels_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles lbl_CoordX.MouseEnter, _
                                                                            lbl_CoordY.MouseEnter, _
                                                                            lbl_CoordZ.MouseEnter, _
                                                                            lbl_CoordA.MouseEnter, _
                                                                            lbl_CoordB.MouseEnter
        If CNC_GcodeRunning Then Return
        SKIN_MouseEnteringLabel(Sender)
    End Sub
    Private Sub CoordLabels_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles lbl_CoordX.MouseLeave, _
                                                                            lbl_CoordY.MouseLeave, _
                                                                            lbl_CoordZ.MouseLeave, _
                                                                            lbl_CoordA.MouseLeave, _
                                                                            lbl_CoordB.MouseLeave
        SKIN_MouseLeavingLabel(Sender)
    End Sub


    ' -----------------------------------------------------------------------------------------------------
    '  Mouse events redirected from Cursor Panels
    ' -----------------------------------------------------------------------------------------------------
    Private Sub PanelCursor1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor1.MouseDoubleClick
        Pic_ToolPath_MouseDoubleClick(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor2_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor2.MouseDoubleClick
        Pic_ToolPath_MouseDoubleClick(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor1_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor1.MouseWheel
        Pic_ToolPath_MouseWheel(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor2_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor2.MouseWheel
        Pic_ToolPath_MouseWheel(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor1.MouseDown
        Pic_ToolPath_MouseDown(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor2.MouseDown
        Pic_ToolPath_MouseDown(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor1.MouseMove
        Pic_ToolPath_MouseMove(sender, CreateMouseEventArgs(e))
    End Sub
    Private Sub PanelCursor2_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelCursor2.MouseMove
        Pic_ToolPath_MouseMove(sender, CreateMouseEventArgs(e))
    End Sub
    Private Function CreateMouseEventArgs(ByVal e As MouseEventArgs) As MouseEventArgs
        Dim pos As Point = Pic_Toolpath.PointToClient(MousePosition)
        Return New MouseEventArgs(e.Button, 0, pos.X, pos.Y, e.Delta)
    End Function


    ' ===============================================================================================================
    '  SPLITTER PANEL
    ' ===============================================================================================================
    Private PanelBack1Min As Int32
    Private PanelBack2Min As Int32
    Private StartMouseX As Int32
    Private PanelSplitterPosition As Int32
    Private Sub PanelSplitter_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PanelSplitter.MouseDown
        StartMouseX = Control.MousePosition.X
        PanelSplitterPosition = PanelSplitter.Left
        Do
            Dim newpos As Int32 = PanelSplitterPosition + Control.MousePosition.X - StartMouseX
            SetSplitterPosition(newpos)
            SleepMyThread(16)
            Application.DoEvents()
        Loop Until Control.MouseButtons = Windows.Forms.MouseButtons.None
        UpdateBackPanels()
    End Sub
    Private Sub PanelSplitter_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PanelSplitter.MouseEnter
        SplitterHiLight(PanelSplitter, True)
    End Sub
    Private Sub PanelSplitter_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PanelSplitter.MouseLeave
        SplitterHiLight(PanelSplitter, False)
    End Sub
    Friend Sub CorrectSplitterPosition()
        Dim x As Int32 = PanelSplitter.Left
        If x < PanelBack1Min Then x = PanelBack1Min
        If x > Me.ClientSize.Width - PanelBack2Min Then x = Me.ClientSize.Width - PanelBack2Min
        If x <> PanelSplitter.Left Then
            PanelSplitter.Left = x
            UpdateBackPanels()
        End If
    End Sub
    Friend Sub SetSplitterPosition(ByVal x As Int32)
        If x < PanelBack1Min Then x = PanelBack1Min
        If x > Me.ClientSize.Width - PanelBack2Min Then x = Me.ClientSize.Width - PanelBack2Min
        If x <> PanelSplitter.Left Then
            PanelSplitter.Left = x
        End If
    End Sub
    Friend Sub UpdateBackPanels()
        PanelBack1.Width = PanelSplitter.Left - 1
        PanelBack2.Left = PanelSplitter.Right + 3
        PanelBack2.Width = Me.ClientSize.Width - PanelBack2.Left + 2
        SKIN_UpdateButtons_Form1()
    End Sub

  
    ' ==============================================================================================================
    '   Params 
    ' ==============================================================================================================
    Private Sub Params_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                            btn_InOutEnabled.LostFocus, _
                                                                            btn_HalEnabled.LostFocus, _
                                                                            btn_ToolStop.LostFocus, _
                                                                            btn_TestLowZ.LostFocus, _
                                                                            txt_Rapid.LostFocus, _
                                                                            txt_Feed.LostFocus, _
                                                                            txt_Speed.LostFocus, _
                                                                            btn_FeedSpeedLocked.LostFocus, _
                                                                            btn_LookAhead.LostFocus, _
                                                                            txt_MaxError.LostFocus, _
                                                                            txt_CtrlJog.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub Params_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                            btn_InOutEnabled.CheckedChanged, _
                                                                            btn_ToolStop.CheckedChanged, _
                                                                            btn_TestLowZ.CheckedChanged, _
                                                                            txt_Rapid.TextChanged, _
                                                                            txt_Feed.TextChanged, _
                                                                            txt_Speed.TextChanged, _
                                                                            txt_MaxError.TextChanged, _
                                                                            txt_CtrlJog.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        ' ---------------------------------------------- first update btn_InOutEnabled
        If sender Is btn_InOutEnabled Then
            btn_InOutEnabled_CheckedChanged()
        End If
        ' ---------------------------------------------- then the others
        EventsAreEnabled = False
        SetAllParams()
        EventsAreEnabled = True
    End Sub

    Friend Sub btn_InOutEnabled_CheckedChanged()
        If btn_InOutEnabled.Checked Then
            CNC_InOutEnabled = True
            CNC_SetMainEnableOutput(True)
            ' ---------------------------------- reset all axis to hardware position
            CNC_TimedUpdateEnabled = False
            CNC_ResetAllAxis()
            CNC_Tip = CNC_HardwareTip
            CNC_Home_Z = CNC_HardwareHome_Z
            CNC_Dest = CNC_Tip
            CNC_WriteSlotValues()
            CNC_EnableTimedUpdateAndUserInterface()
        Else
            CNC_HardwareTip = CNC_Tip
            CNC_InOutEnabled = True
            CNC_SetMainEnableOutput(False)
            CNC_InOutEnabled = False
        End If
    End Sub

    Private Sub SetAllParams()
        CNC_InOutEnabled = btn_InOutEnabled.Checked
        CNC_ToolStop = btn_ToolStop.Checked
        CNC_TestLowZ = btn_TestLowZ.Checked
        CNC_SetRapid(txt_Rapid.NumericValueInteger)
        CNC_SetFeed(txt_Feed.NumericValueInteger)
        CNC_SetSpeed(txt_Speed.NumericValueInteger)
        CNC_MaxError = txt_MaxError.NumericValue
        CNC_JogStep = txt_CtrlJog.NumericValue
        ' ------------------------------------------------------------
        ShowGcodeTotalTime()
        ' ------------------------------ must be after CNC_InOutEnabled and CNC_SetSlots
        CNC_SetMainEnableOutput(CNC_InOutEnabled)
    End Sub


End Class
