﻿Partial Class Form1

    ' ==============================================================================================================
    '   ToolPath PictureBox - Mouse events
    ' ==============================================================================================================
    Private Sub Pic_ToolPath_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_Toolpath.MouseDoubleClick
        If CNC_GcodeRunning Or btn_GcodePause.Checked Then Return
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim i As Int32 = CNC_FindNearestSegment(e.X, e.Y)
            CNC_LineInExecution = i
            CNC_LineToBeExecuted = i
            GraphicThread_DrawToolpathImage(False)
            UpdateUserInterfaceInfo()
        End If
    End Sub
    Private Sub Pic_ToolPath_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_Toolpath.MouseDown
        Pic_Toolpath.Focus()
        If e.Button = Windows.Forms.MouseButtons.Left Then
            CNC_EnableTimedUpdateAndUserInterface()
            GraphicThread_SetStartPosition(e.X, e.Y)
        End If
        If CNC_GcodeRunning Or btn_GcodePause.Checked Then Return
        If GCodeParsedLines.Length = 0 Then Return
        If e.Button = Windows.Forms.MouseButtons.Right Then
            If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
                If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                             vbCr + "Do you really want to move?") <> "YES" Then
                    Return
                End If
            End If
            CNC_EnableTimedUpdateAndUserInterface()
            ' ----------------------------------------------- stop and wait motor stop
            StopLastMovementAndWaitMotorStop()
            ' -----------------------------------------------
            SetDestinationFromPboxXY(e.X, e.Y)
            ' ----------------------------------------------- prenote a redraw 
            ActivateTest_ForRedrawAfterStop()
        End If
        Pic_Toolpath.Focus()
        ' --------------------------------------------------- show test values
        'GraphicThread_ShowTestValues(1, e.X, e.Y)
    End Sub

    Private Sub Pic_ToolPath_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_Toolpath.MouseWheel
        If Pic_Toolpath.ClientRectangle.Contains(e.Location) Then
            CNC_EnableTimedUpdateAndUserInterface()
            GraphicThread_SetZoomAndPosition(1 + e.Delta / 600.0F, e.X, e.Y)
        End If
    End Sub

    Private Sub Pic_ToolPath_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_Toolpath.MouseMove
        ' --------------------------------------------------- drag with left button
        If e.Button = Windows.Forms.MouseButtons.Left Then
            GraphicThread_SetDeltaPosition(e.X, e.Y)
        End If
        ' ---------------------------------- continuous move (requires different formula)
        'GraphicThread_SetZoom(1, e.X, e.Y)
    End Sub

    Friend Sub StopLastMovementAndWaitMotorStop()
        ' --------------------------------------------- stop movement
        CNC_Dest = CNC_Tip
        ' --------------------------------------------- wait motor stop up to 0.5 seconds
        For i As Int32 = 1 To 500
            If CNC_MaxDelta() = 0 Then Exit For
            SleepMyThread(1)
        Next
        ' --------------------------------------------- mark loop meter "TimeOld" as invalid
        RestartThreadLoopMeter()
    End Sub


    ' ==============================================================================================================
    '   ToolPath - BUTTON COMMANDS
    ' ==============================================================================================================
    Private Sub btn_ZoomTpMinus_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ZoomTpMinus.ClickButtonArea
        CNC_EnableTimedUpdateAndUserInterface()
        GraphicThread_SetZoomAndPosition(0.8, -1, -1)
    End Sub
    Private Sub btn_ZoomTpPlus_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ZoomTpPlus.ClickButtonArea
        CNC_EnableTimedUpdateAndUserInterface()
        GraphicThread_SetZoomAndPosition(1.2, -1, -1)
    End Sub
    Private Sub btn_GotoZero_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GotoZero.ClickButtonArea
        If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
            If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                         vbCr + "Do you really want to move?") <> "YES" Then
                Return
            End If
        End If
        CNC_GotoZero()
    End Sub
    Private Sub btn_GotoHome_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GotoHome.ClickButtonArea
        If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
            If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                         vbCr + "Do you really want to move?") <> "YES" Then
                Return
            End If
        End If
        CNC_GotoHome()
    End Sub
    Private Sub btn_GotoBottomLeft_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GotoBottomLeft.ClickButtonArea
        If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
            If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                         vbCr + "Do you really want to move?") <> "YES" Then
                Return
            End If
        End If
        CNC_GotoBottomLeft()
    End Sub
    Private Sub btn_GotoTopRight_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_GotoTopRight.ClickButtonArea
        If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
            If Form_MsgBox.Message_YesNo("WARNING: Z is low" + _
                                         vbCr + "Do you really want to move?") <> "YES" Then
                Return
            End If
        End If
        CNC_GotoTopRight()
    End Sub

    Friend Sub CNC_GotoZero()
        CNC_EnableTimedUpdateAndUserInterface()
        StopLastMovementAndWaitMotorStop()
        CNC_Dest.x = 0
        CNC_Dest.y = 0
        CNC_Dest.z = 0
        ActivateTest_ForRedrawAfterStop()
    End Sub

    Friend Sub CNC_GotoHome()
        ' -------------------------------------------- normal goto home 
        'CNC_EnableTimedUpdateAndUserInterface()
        'StopLastMovementAndWaitMotorStop()
        'CNC_Dest.x = 0
        'CNC_Dest.y = 0
        'CNC_Dest.z = CNC_Home_Z
        'ActivateTest_ForRedrawAfterStop()
        ' -------------------------------------------- double phase goto home 
        CNC_EnableTimedUpdateAndUserInterface()
        StopLastMovementAndWaitMotorStop()
        If CNC_Dest.z = CNC_Home_Z Then
            CNC_Dest.x = 0
            CNC_Dest.y = 0
        Else
            CNC_Dest.z = CNC_Home_Z
        End If
        ActivateTest_ForRedrawAfterStop()
    End Sub

    Friend Sub CNC_GotoBottomLeft()
        CNC_EnableTimedUpdateAndUserInterface()
        StopLastMovementAndWaitMotorStop()
        CNC_Dest.x = GC_MinCoord.x
        CNC_Dest.y = GC_MinCoord.y
        ActivateTest_ForRedrawAfterStop()
    End Sub

    Friend Sub CNC_GotoTopRight()
        CNC_EnableTimedUpdateAndUserInterface()
        StopLastMovementAndWaitMotorStop()
        CNC_Dest.x = GC_MaxCoord.x
        CNC_Dest.y = GC_MaxCoord.y
        ActivateTest_ForRedrawAfterStop()
    End Sub


    ' ==============================================================================================================
    '   Keyboard Jog
    ' ==============================================================================================================
    Private SlowJogWaitingKeyUp As Boolean = False
    Private PressedKeys As Generic.Dictionary(Of Int32, Int32) = New Generic.Dictionary(Of Int32, Int32)
    Friend Sub CNC_TestPressedKeys()
        If PressedKeys.Count = 0 Then Return
        ' -------------------------------------------------------
        Dim mm As Double
        mm = CNC_Rapid / (1000 / CNC_LoopTimeMillisec) / 60
        ' -------------------------------------------------------
        If My.Computer.Keyboard.ShiftKeyDown Then
            mm *= CNC_JogSpeedShift / 100
        Else
            mm *= CNC_JogSpeedNormal / 100
        End If
        ' -------------------------------------------------------
        Try
            For Each k As Int32 In PressedKeys.Keys
                CNC_Jog(k, mm)
            Next
        Catch
        End Try
    End Sub
    Private Sub Pic_Toolpath_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles Pic_Toolpath.PreviewKeyDown
        e.IsInputKey = True
    End Sub
    Private Sub MyBase_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        '
        ' --------------------------------------------------- Jog with ARROWS and PAGE UP/DOWN
        Select Case e.KeyCode
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.PageUp, Keys.PageDown, Keys.A, Keys.S, Keys.B, Keys.N, Keys.Z, Keys.X
                If Pic_Toolpath.Focused AndAlso btn_GCodeStop.Checked Then
                    e.Handled = True
                    CNC_KeySpacePressed = False
                    ' ---------------------------------------------------
                    If GC_UsedZ AndAlso CNC_TestLowZ AndAlso CNC_Tip.z < CNC_WarningZeta Then
                        Select Case e.KeyCode
                            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down
                                Form_MsgBox.Message_OK("WARNING: Z is low" + _
                                                       vbCr + "Raise Z with PageUp" + _
                                                       vbCr + "or disable the ""Test low Z"" button")
                                PressedKeys.Clear()
                                Return
                        End Select
                    End If
                    ' ---------------------------------------------------
                    CNC_EnableTimedUpdateAndUserInterface()
                    ' ---------------------------------------------------
                    If My.Computer.Keyboard.AltKeyDown Then
                        CNC_Jog(e.KeyCode, 0.001)
                    Else
                        If My.Computer.Keyboard.CtrlKeyDown Then
                            If Not SlowJogWaitingKeyUp Then
                                CNC_Jog(e.KeyCode, CNC_JogStep)
                                SlowJogWaitingKeyUp = True
                            End If
                        Else
                            If Not PressedKeys.ContainsKey(e.KeyCode) Then
                                ' -------------------------------------------------------
                                '  Backup old dictionary
                                '  Clear PressedKeys
                                '  Waiting motor stop to suppress speed burst
                                '  Restore old PressedKeys
                                ' -------------------------------------------------------
                                Dim old As Generic.Dictionary(Of Int32, Int32)
                                old = New Generic.Dictionary(Of Int32, Int32)(PressedKeys)
                                PressedKeys.Clear()
                                StopLastMovementAndWaitMotorStop()
                                PressedKeys = New Generic.Dictionary(Of Int32, Int32)(old)
                                ' ------------------------------------------------------- 
                                '  And finally add the key
                                ' ------------------------------------------------------- 
                                PressedKeys.Add(e.KeyCode, e.KeyCode)
                            End If
                        End If
                    End If
                End If
            Case Keys.Space
                CNC_KeySpacePressed = True
        End Select
    End Sub
    Private Sub MyBase_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        '
        ' --------------------------------------------------- rearm slow jog
        SlowJogWaitingKeyUp = False
        '
        ' --------------------------------------------------- Jog with ARROWS and PAGE UP/DOWN
        If Pic_Toolpath.Focused Then
            Select Case e.KeyCode
                Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.PageUp, Keys.PageDown, Keys.A, Keys.S, Keys.B, Keys.N, Keys.Z, Keys.X
                    e.Handled = True
                    PressedKeys.Remove(e.KeyCode)
                    If Not CNC_GcodeRunning Then
                        ' ----------------------------------------------------- recalc view params if not zoomed
                        If CNC_GetZoom() < 1.5 Then
                            GraphicThread_DrawToolpathImage(True)
                        Else
                            GraphicThread_CenterViewArea()
                        End If
                    End If
            End Select
        End If
    End Sub

    Friend Sub CNC_EnableTimedUpdateAndUserInterface()
        If CNC_TimedUpdateEnabled = False Then
            CNC_TimedUpdateEnabled = True
            CNC_Dest = CNC_Tip
        End If
        UserInterfaceRedraw_Enable()
        CNC_KeySpacePressed = False
    End Sub

End Class
