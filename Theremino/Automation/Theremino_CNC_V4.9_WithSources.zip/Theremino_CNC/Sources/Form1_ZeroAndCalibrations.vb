﻿Partial Class Form1

    ' ==============================================================================================================
    '   ZERO SINGLE AXIS
    ' ==============================================================================================================
    Private Sub ZeroButtons_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                                    btn_ZeroX.ClickButtonArea, _
                                                                                    btn_ZeroY.ClickButtonArea, _
                                                                                    btn_ZeroZ.ClickButtonArea, _
                                                                                    btn_ZeroA.ClickButtonArea, _
                                                                                    btn_ZeroB.ClickButtonArea
        Dim b As MyButton
        b = CType(Sender, MyButton)
        SKIN_UpdateButtons_Form1()
        CNC_TimedUpdateEnabled = False
        txt_EditCoord.Visible = False
        CNC_ResetHardwareTo(b.Name, 0)
        GraphicThread_DrawToolpathImage(True)
        ShowCoords()
        GraphicThread_DrawToolPosition(True)
        CNC_CalcToolPositions()
        ShowToolCursors()
        b.Checked = False
        SKIN_UpdateButtons_Form1()
        Pic_Toolpath.Focus()
    End Sub
    Private Sub ZeroButtons_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                                    btn_ZeroX.MouseLeave, _
                                                                                    btn_ZeroY.MouseLeave, _
                                                                                    btn_ZeroZ.MouseLeave, _
                                                                                    btn_ZeroA.MouseLeave, _
                                                                                    btn_ZeroB.MouseLeave
        Dim b As MyButton
        b = CType(Sender, MyButton)
        b.Checked = False
        SKIN_UpdateButtons_Form1()
    End Sub

    ' ==============================================================================================================
    '   Disable TextBoxes when mouse leaving GroupBox_Motors
    ' ==============================================================================================================
    Private Sub MouseLeaving_GroupBox_Motors(ByVal sender As Object, ByVal e As System.EventArgs) Handles GroupBox_Gcode.MouseEnter, _
                                                                                                       GroupBox_Controls.MouseEnter, _
                                                                                                       GroupBox_Toolpath.MouseEnter
        If txt_EditCoord.Visible Then
            txt_EditCoord.Visible = False
            Pic_Toolpath.Focus()
        End If
        If txt_Rapid.Focused Or txt_Feed.Focused Or txt_Speed.Focused Or _
           txt_MaxError.Focused Or txt_CtrlJog.Focused Then
            Pic_Toolpath.Focus()
        End If
    End Sub

    ' ==================================================================================================
    '   COORDINATE EDIT
    ' ==================================================================================================
    Private Sub lbl_Coord_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) _
                                                                                Handles lbl_CoordX.MouseDown, _
                                                                                        lbl_CoordY.MouseDown, _
                                                                                        lbl_CoordZ.MouseDown, _
                                                                                        lbl_CoordA.MouseDown, _
                                                                                        lbl_CoordB.MouseDown
        If CNC_GcodeRunning Then Return
        If e.Button = Windows.Forms.MouseButtons.Left Then
            EditCoord(sender)
        Else
            OffsetCoord(sender)
        End If
    End Sub

    Private Sub EditCoord(ByVal sender As System.Object)
        Dim l As Label = CType(sender, Label)
        EditLabelName = l.Name
        txt_EditCoord.Location = l.Location
        txt_EditCoord.Size = l.Size
        txt_EditCoord.TextAlign = HorizontalAlignment.Center
        txt_EditCoord.Text = l.Text
        txt_EditCoord.Visible = True
        txt_EditCoord.Focus()
        txt_EditCoord.SelectionStart = 99
        txt_EditCoord.SelectionLength = 0
    End Sub

    Private EditLabelName As String
    Private Sub txt_EditCoord_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_EditCoord.KeyDown
        If e.KeyCode = Keys.Escape Then
            ' ------------------------------------------------ close edit box
            txt_EditCoord.Visible = False
            Pic_Toolpath.Focus()
        End If
        If e.KeyCode = Keys.Enter Then
            ' ------------------------------------------------ Reset Hardware To the new edited coordinate
            txt_EditCoord.Text = txt_EditCoord.Text.Trim
            txt_EditCoord.Text = txt_EditCoord.Text.Replace(",", ".")
            If txt_EditCoord.Text <> "" Then
                Dim coord As Double = Val(txt_EditCoord.Text)
                CNC_TimedUpdateEnabled = False
                CNC_ResetHardwareTo(EditLabelName, coord)
                GraphicThread_DrawToolpathImage(False)
                ShowCoords()
                'GraphicThread_DrawToolPosition(True)
                CNC_CalcToolPositions()
                ShowToolCursors()
            End If
            ' ------------------------------------------------ close edit box
            txt_EditCoord.Visible = False
            Pic_Toolpath.Focus()
        End If
    End Sub

    Private Sub OffsetCoord(ByVal sender As System.Object)
        Dim l As Label = CType(sender, Label)
        Dim selection As String
        selection = Form_MsgBox.Message_Select("Add 0.5 mm" + vbCr + "Add 0.4 mm" + vbCr + _
                                               "Add 0.3 mm" + vbCr + "Add 0.2 mm" + vbCr + "Add 0.1 mm" _
                                               + vbCr + "Do nothing" + vbCr + _
                                               "Sub 0.1 mm" + vbCr + "Sub 0.2 mm" + vbCr + "Sub 0.3 mm" _
                                               + vbCr + "Sub 0.4 mm" + vbCr + "Sub 0.5 mm", _
                                               "", 5, 15, _
                                               "Adjust coordinate " + l.Name(l.Name.Length - 1), "Bottom", True)
        Dim offset As Double
        Select Case selection
            Case "Add 0.5 mm" : offset = 0.5
            Case "Add 0.4 mm" : offset = 0.4
            Case "Add 0.3 mm" : offset = 0.3
            Case "Add 0.2 mm" : offset = 0.2
            Case "Add 0.1 mm" : offset = 0.1
            Case "Sub 0.1 mm" : offset = -0.1
            Case "Sub 0.2 mm" : offset = -0.2
            Case "Sub 0.3 mm" : offset = -0.3
            Case "Sub 0.4 mm" : offset = -0.4
            Case "Sub 0.5 mm" : offset = -0.5
        End Select
        If offset <> 0 Then
            Dim coord As Double = Val(l.Text) + offset
            CNC_TimedUpdateEnabled = False
            CNC_ResetHardwareTo(l.Name, coord)
            GraphicThread_DrawToolpathImage(False)
            ShowCoords()
            CNC_CalcToolPositions()
            ShowToolCursors()
        End If
    End Sub


    ' ==============================================================================================================
    '   Calibration panel commands
    ' ==============================================================================================================
    Private Sub btn_SetZetaHome_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_SetZetaHome.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        If Form_MsgBox.Message_YesNo("Set Z HOME position to " + _
                                     CNC_Tip.z.ToString("0.000", _
                                                        Globalization.CultureInfo.InvariantCulture) _
                                                        + " ?") = "YES" Then
            CNC_Home_Z = CNC_Tip.z
        End If
        btn_SetZetaHome.Checked = False
        SKIN_UpdateButtons_Form1()
        Pic_Toolpath.Focus()
    End Sub

    Private Sub btn_CalibrateXY_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CalibrateXY.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        ' ------------------------------------------------- if calibrating then stop
        If CNC_CalibrationStep <> CalibrationSteps.None Then
            StopCalibrations()
            Return
        End If
        ' -------------------------------------------------
        CNC_WaitExactStop()
        CNC_CalibrationStep = CalibrationSteps.X1
        CNC_Dest.x -= CNC_CalXyabMaxTravel
        StartCalibrations()
        ' -------------------------------------------------
        Pic_Toolpath.Focus()
    End Sub

    Private Sub btn_CalibrateAB_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CalibrateAB.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        ' ------------------------------------------------- if calibrating then stop
        If CNC_CalibrationStep <> CalibrationSteps.None Then
            StopCalibrations()
            Return
        End If
        ' -------------------------------------------------
        CNC_WaitExactStop()
        CNC_CalibrationStep = CalibrationSteps.A1
        CNC_Dest.a -= CNC_CalXyabMaxTravel
        StartCalibrations()
        ' -------------------------------------------------
        Pic_Toolpath.Focus()
    End Sub

    Private Sub btn_CalibrateZ_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CalibrateZ.ClickButtonArea
        SKIN_UpdateButtons_Form1()
        ' ------------------------------------------------- if calibrating then stop
        If CNC_CalibrationStep <> CalibrationSteps.None Then
            StopCalibrations()
            Return
        End If
        ' -------------------------------------------------
        CNC_WaitExactStop()
        CNC_CalibrationStep = CalibrationSteps.Z1
        CNC_Dest.z -= CNC_CalZMaxTravel
        StartCalibrations()
        ' -------------------------------------------------
        Pic_Toolpath.Focus()
    End Sub

    Private Sub btn_CalibrationSettings_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CalibrationSettings.ClickButtonArea
        If Form_Calibrations.Visible Then
            Form_Calibrations.Hide()
        Else
            Dim p As Point
            p.X = PanelBack2.Left + lbl_CoordX.Left + 50 - Form_Calibrations.Width
            p.Y = GroupBox_Motors.Top + 40
            p = Me.PointToScreen(p)
            Form_Calibrations.Opacity = 0
            Form_Calibrations.Location = p
            Form_Calibrations.Show(Me)
            Form_Calibrations.Refresh()
            Form_Calibrations.Opacity = 1
        End If
    End Sub

    ' ==============================================================================================================
    '   Calibration buttons functions
    ' ==============================================================================================================
    Private Sub StartCalibrations()
        EnableAllControls(False)
        btn_GcodeStart.Enabled = False
        btn_GcodePause.Enabled = False
        CNC_TimedUpdateEnabled = True
        UserInterfaceRedraw_Enable()
        CNC_KeySpacePressed = False
        CNC_EnsureSafeValuesToInputSlots()
    End Sub
    Private Sub StopCalibrations()
        EnableAllControls(True)
        btn_GcodeStart.Enabled = True
        btn_GcodePause.Enabled = True
        CNC_Dest = CNC_Tip
        CNC_CalibrationStep = CalibrationSteps.None
        CalibrationButtons_Uncheck()
        SKIN_UpdateButtons_Form1()
    End Sub
    Friend Sub CalibrationButtons_Enable()
        btn_SetZetaHome.Enabled = True
        If CNC_CalXyabSearchSpeed > 0 And CNC_CalXyabReturnSpeed > 0 And _
                                          CNC_CalXyabMaxTravel > 0 And _
                                          btn_InOutEnabled.Checked And _
                                          btn_HalEnabled.Checked Then
            btn_CalibrateXY.Enabled = True
            If GC_UsedA Or GC_UsedB Then
                btn_CalibrateAB.Enabled = True
            Else
                btn_CalibrateAB.Enabled = False
            End If
        Else
            btn_CalibrateXY.Enabled = False
            btn_CalibrateAB.Enabled = False
        End If
        If CNC_CalZSearchSpeed > 0 And CNC_CalZReturnSpeed > 0 And _
                                       CNC_CalZMaxTravel > 0 And _
                                       btn_InOutEnabled.Checked And _
                                       btn_HalEnabled.Checked Then
            btn_CalibrateZ.Enabled = True
        Else
            btn_CalibrateZ.Enabled = False
        End If
        btn_CalibrationSettings.Enabled = True
    End Sub
    Private Sub CalibrationButtons_Disable()
        btn_SetZetaHome.Enabled = False
        btn_CalibrateXY.Enabled = False
        btn_CalibrateAB.Enabled = False
        btn_CalibrateZ.Enabled = False
        btn_CalibrationSettings.Enabled = False
    End Sub
    Private Sub CalibrationButtons_Uncheck()
        btn_CalibrateXY.Checked = False
        btn_CalibrateAB.Checked = False
        btn_CalibrateZ.Checked = False
    End Sub

End Class
