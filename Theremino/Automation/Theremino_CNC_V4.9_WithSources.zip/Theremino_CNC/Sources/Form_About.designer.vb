﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_About
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_About))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label_OpenSite = New System.Windows.Forms.Label
        Me.Label_SendInfo = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Button_OK = New MyButton
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(467, 42)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Theremino CNC"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_OpenSite
        '
        Me.Label_OpenSite.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_OpenSite.BackColor = System.Drawing.Color.Transparent
        Me.Label_OpenSite.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_OpenSite.ForeColor = System.Drawing.Color.Blue
        Me.Label_OpenSite.Location = New System.Drawing.Point(21, 67)
        Me.Label_OpenSite.Name = "Label_OpenSite"
        Me.Label_OpenSite.Size = New System.Drawing.Size(151, 26)
        Me.Label_OpenSite.TabIndex = 5
        Me.Label_OpenSite.Text = "www.theremino.com"
        Me.Label_OpenSite.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_SendInfo
        '
        Me.Label_SendInfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_SendInfo.BackColor = System.Drawing.Color.Transparent
        Me.Label_SendInfo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SendInfo.ForeColor = System.Drawing.Color.Blue
        Me.Label_SendInfo.Location = New System.Drawing.Point(182, 67)
        Me.Label_SendInfo.Name = "Label_SendInfo"
        Me.Label_SendInfo.Size = New System.Drawing.Size(208, 26)
        Me.Label_SendInfo.TabIndex = 6
        Me.Label_SendInfo.Text = "engineering@theremino.com"
        Me.Label_SendInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Button_OK)
        Me.Panel1.Controls.Add(Me.Label_SendInfo)
        Me.Panel1.Controls.Add(Me.Label_OpenSite)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(-2, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(497, 108)
        Me.Panel1.TabIndex = 7
        '
        'Button_OK
        '
        Me.Button_OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_OK.BackColor = System.Drawing.Color.Transparent
        Me.Button_OK.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_OK.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.Button_OK.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.Button_OK.ColorFillBlendChecked = CBlendItems2
        Me.Button_OK.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.Button_OK.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.Button_OK.Corners.All = CType(9, Short)
        Me.Button_OK.Corners.LowerLeft = CType(9, Short)
        Me.Button_OK.Corners.LowerRight = CType(9, Short)
        Me.Button_OK.Corners.UpperLeft = CType(9, Short)
        Me.Button_OK.Corners.UpperRight = CType(9, Short)
        Me.Button_OK.DimFactorOver = 30
        Me.Button_OK.FillType = MyButton.eFillType.LinearVertical
        Me.Button_OK.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.Button_OK.FocalPoints.CenterPtX = 0.1578947!
        Me.Button_OK.FocalPoints.CenterPtY = 1.0!
        Me.Button_OK.FocalPoints.FocusPtX = 0.0!
        Me.Button_OK.FocalPoints.FocusPtY = 0.0!
        Me.Button_OK.FocalPointsChecked.CenterPtX = 1.0!
        Me.Button_OK.FocalPointsChecked.CenterPtY = 1.0!
        Me.Button_OK.FocalPointsChecked.FocusPtX = 0.0!
        Me.Button_OK.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_OK.FocusPtTracker = DesignerRectTracker2
        Me.Button_OK.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_OK.ForeColor = System.Drawing.Color.Black
        Me.Button_OK.Image = Nothing
        Me.Button_OK.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_OK.ImageIndex = 0
        Me.Button_OK.ImageSize = New System.Drawing.Size(16, 16)
        Me.Button_OK.Location = New System.Drawing.Point(407, 64)
        Me.Button_OK.Name = "Button_OK"
        Me.Button_OK.Shape = MyButton.eShape.Rectangle
        Me.Button_OK.SideImage = Nothing
        Me.Button_OK.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_OK.SideImageSize = New System.Drawing.Size(32, 32)
        Me.Button_OK.Size = New System.Drawing.Size(73, 32)
        Me.Button_OK.TabIndex = 257
        Me.Button_OK.Text = "OK"
        Me.Button_OK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_OK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_OK.TextMargin = New System.Windows.Forms.Padding(0)
        Me.Button_OK.TextShadow = System.Drawing.Color.Transparent
        '
        'Form_About
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(493, 106)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_About"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Theremino CNC - About"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label_OpenSite As System.Windows.Forms.Label
    Friend WithEvents Label_SendInfo As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button_OK As MyButton
End Class
