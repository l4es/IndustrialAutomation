﻿Public Class Form_About

    Private Sub Form_About_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = AppTitleAndVersion()
        Label1.BackgroundImage = Nothing
    End Sub

    Private Sub Button_OK_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles Button_OK.ClickButtonArea
        Close()
    End Sub

    Private Sub Label_OpenSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_OpenSite.Click
        Process.Start("http://www.theremino.com")
    End Sub

    Private Sub Label_SendInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_SendInfo.Click
        Send_Mail("engineering@theremino.com", "Info on ThereminoCNC", "Dear Theremino team,\n\n")
    End Sub

    Private Sub Send_Mail(ByVal sendto As String, ByVal subject As String, ByVal body As String)
        subject = subject.Replace(" ", "%20")
        body = body.Replace("\n", "%0d%0a")
        body = body.Replace(" ", "%20")
        Shell("Cmd /C START MAILTO:" & sendto & """?subject=" & subject & "&body=" & body & """")
    End Sub


    ' ==============================================================================================================
    '   CONTROLS HILIGHT ON MOUSE ENTER
    ' ==============================================================================================================
    Private Sub Buttons_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles Button_OK.MouseEnter
        SKIN_MouseEnteringButton(Sender)
    End Sub
    Private Sub Buttons_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles Button_OK.MouseLeave
        SKIN_MouseLeavingButton(Sender)
    End Sub
    Private Sub Labels_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles Label_OpenSite.MouseEnter, _
                                                                             Label_SendInfo.MouseEnter
        SKIN_MouseEnteringLabel(Sender)
    End Sub
    Private Sub Labels_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles Label_OpenSite.MouseLeave, _
                                                                             Label_SendInfo.MouseLeave
        SKIN_MouseLeavingLabel(Sender)
    End Sub

End Class