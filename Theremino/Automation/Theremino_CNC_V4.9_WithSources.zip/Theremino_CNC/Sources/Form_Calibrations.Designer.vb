﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Calibrations
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_CalXyabMaxTravel = New MyTextBox
        Me.lbl_Speed = New System.Windows.Forms.Label
        Me.lbl_Rapid = New System.Windows.Forms.Label
        Me.txt_CalXyabReturnSpeed = New MyTextBox
        Me.lbl_Feed = New System.Windows.Forms.Label
        Me.txt_CalXyabSearchSpeed = New MyTextBox
        Me.txt_CalXyabCompensation = New MyTextBox
        Me.lbl_ProbeThickness = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txt_CalZSearchSpeed = New MyTextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_CalZMaxTravel = New MyTextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_CalZReturnSpeed = New MyTextBox
        Me.txt_CalZCompensation = New MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_CalXyabMaxTravel
        '
        Me.txt_CalXyabMaxTravel.ArrowsIncrement = 10
        Me.txt_CalXyabMaxTravel.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalXyabMaxTravel.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalXyabMaxTravel.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalXyabMaxTravel.DimFactorGray = -10
        Me.txt_CalXyabMaxTravel.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalXyabMaxTravel.ForeColor = System.Drawing.Color.Black
        Me.txt_CalXyabMaxTravel.Increment = 1
        Me.txt_CalXyabMaxTravel.Location = New System.Drawing.Point(255, 102)
        Me.txt_CalXyabMaxTravel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalXyabMaxTravel.MaxValue = 99000
        Me.txt_CalXyabMaxTravel.MinValue = 0
        Me.txt_CalXyabMaxTravel.Name = "txt_CalXyabMaxTravel"
        Me.txt_CalXyabMaxTravel.NumericValue = 100
        Me.txt_CalXyabMaxTravel.NumericValueInteger = 100
        Me.txt_CalXyabMaxTravel.RectangleColor = System.Drawing.Color.White
        Me.txt_CalXyabMaxTravel.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalXyabMaxTravel.RoundingStep = 0
        Me.txt_CalXyabMaxTravel.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalXyabMaxTravel.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalXyabMaxTravel.SuppressZeros = True
        Me.txt_CalXyabMaxTravel.TabIndex = 563
        Me.txt_CalXyabMaxTravel.TabStop = False
        Me.txt_CalXyabMaxTravel.Text = "100"
        Me.txt_CalXyabMaxTravel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_Speed
        '
        Me.lbl_Speed.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Speed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Speed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Speed.Location = New System.Drawing.Point(11, 101)
        Me.lbl_Speed.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_Speed.Name = "lbl_Speed"
        Me.lbl_Speed.Size = New System.Drawing.Size(240, 32)
        Me.lbl_Speed.TabIndex = 566
        Me.lbl_Speed.Text = "Max travel (mm)"
        Me.lbl_Speed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_Rapid
        '
        Me.lbl_Rapid.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Rapid.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Rapid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Rapid.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_Rapid.Location = New System.Drawing.Point(11, 30)
        Me.lbl_Rapid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_Rapid.Name = "lbl_Rapid"
        Me.lbl_Rapid.Size = New System.Drawing.Size(240, 32)
        Me.lbl_Rapid.TabIndex = 564
        Me.lbl_Rapid.Text = "Search speed (mm/m)"
        Me.lbl_Rapid.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_CalXyabReturnSpeed
        '
        Me.txt_CalXyabReturnSpeed.ArrowsIncrement = 1
        Me.txt_CalXyabReturnSpeed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalXyabReturnSpeed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalXyabReturnSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalXyabReturnSpeed.DimFactorGray = -10
        Me.txt_CalXyabReturnSpeed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalXyabReturnSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_CalXyabReturnSpeed.Increment = 0.2
        Me.txt_CalXyabReturnSpeed.Location = New System.Drawing.Point(255, 66)
        Me.txt_CalXyabReturnSpeed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalXyabReturnSpeed.MaxValue = 9900
        Me.txt_CalXyabReturnSpeed.MinValue = 0
        Me.txt_CalXyabReturnSpeed.Name = "txt_CalXyabReturnSpeed"
        Me.txt_CalXyabReturnSpeed.NumericValue = 10
        Me.txt_CalXyabReturnSpeed.NumericValueInteger = 10
        Me.txt_CalXyabReturnSpeed.RectangleColor = System.Drawing.Color.White
        Me.txt_CalXyabReturnSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalXyabReturnSpeed.RoundingStep = 0
        Me.txt_CalXyabReturnSpeed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalXyabReturnSpeed.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalXyabReturnSpeed.SuppressZeros = True
        Me.txt_CalXyabReturnSpeed.TabIndex = 562
        Me.txt_CalXyabReturnSpeed.TabStop = False
        Me.txt_CalXyabReturnSpeed.Text = "10"
        Me.txt_CalXyabReturnSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_Feed
        '
        Me.lbl_Feed.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Feed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Feed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_Feed.Location = New System.Drawing.Point(11, 65)
        Me.lbl_Feed.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_Feed.Name = "lbl_Feed"
        Me.lbl_Feed.Size = New System.Drawing.Size(240, 32)
        Me.lbl_Feed.TabIndex = 565
        Me.lbl_Feed.Text = "Return speed (mm/m)"
        Me.lbl_Feed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_CalXyabSearchSpeed
        '
        Me.txt_CalXyabSearchSpeed.ArrowsIncrement = 10
        Me.txt_CalXyabSearchSpeed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalXyabSearchSpeed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalXyabSearchSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalXyabSearchSpeed.DimFactorGray = -10
        Me.txt_CalXyabSearchSpeed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalXyabSearchSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_CalXyabSearchSpeed.Increment = 2
        Me.txt_CalXyabSearchSpeed.Location = New System.Drawing.Point(255, 31)
        Me.txt_CalXyabSearchSpeed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalXyabSearchSpeed.MaxValue = 99000
        Me.txt_CalXyabSearchSpeed.MinValue = 0
        Me.txt_CalXyabSearchSpeed.Name = "txt_CalXyabSearchSpeed"
        Me.txt_CalXyabSearchSpeed.NumericValue = 100
        Me.txt_CalXyabSearchSpeed.NumericValueInteger = 100
        Me.txt_CalXyabSearchSpeed.RectangleColor = System.Drawing.Color.White
        Me.txt_CalXyabSearchSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalXyabSearchSpeed.RoundingStep = 0
        Me.txt_CalXyabSearchSpeed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalXyabSearchSpeed.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalXyabSearchSpeed.SuppressZeros = True
        Me.txt_CalXyabSearchSpeed.TabIndex = 561
        Me.txt_CalXyabSearchSpeed.TabStop = False
        Me.txt_CalXyabSearchSpeed.Text = "100"
        Me.txt_CalXyabSearchSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_CalXyabCompensation
        '
        Me.txt_CalXyabCompensation.ArrowsIncrement = 0.01
        Me.txt_CalXyabCompensation.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalXyabCompensation.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalXyabCompensation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalXyabCompensation.Decimals = 2
        Me.txt_CalXyabCompensation.DimFactorGray = -10
        Me.txt_CalXyabCompensation.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalXyabCompensation.ForeColor = System.Drawing.Color.Black
        Me.txt_CalXyabCompensation.Increment = 0.002
        Me.txt_CalXyabCompensation.Location = New System.Drawing.Point(255, 139)
        Me.txt_CalXyabCompensation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalXyabCompensation.MaxValue = 99
        Me.txt_CalXyabCompensation.MinValue = 0
        Me.txt_CalXyabCompensation.Name = "txt_CalXyabCompensation"
        Me.txt_CalXyabCompensation.NumericValue = 1
        Me.txt_CalXyabCompensation.NumericValueInteger = 1
        Me.txt_CalXyabCompensation.RectangleColor = System.Drawing.Color.White
        Me.txt_CalXyabCompensation.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalXyabCompensation.RoundingStep = 0
        Me.txt_CalXyabCompensation.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalXyabCompensation.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalXyabCompensation.TabIndex = 645
        Me.txt_CalXyabCompensation.TabStop = False
        Me.txt_CalXyabCompensation.Text = "1.00"
        Me.txt_CalXyabCompensation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_ProbeThickness
        '
        Me.lbl_ProbeThickness.BackColor = System.Drawing.Color.Transparent
        Me.lbl_ProbeThickness.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ProbeThickness.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_ProbeThickness.Location = New System.Drawing.Point(11, 138)
        Me.lbl_ProbeThickness.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_ProbeThickness.Name = "lbl_ProbeThickness"
        Me.lbl_ProbeThickness.Size = New System.Drawing.Size(240, 32)
        Me.lbl_ProbeThickness.TabIndex = 646
        Me.lbl_ProbeThickness.Text = "Compensation (mm)"
        Me.lbl_ProbeThickness.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.txt_CalXyabSearchSpeed)
        Me.GroupBox1.Controls.Add(Me.lbl_Feed)
        Me.GroupBox1.Controls.Add(Me.txt_CalXyabCompensation)
        Me.GroupBox1.Controls.Add(Me.txt_CalXyabReturnSpeed)
        Me.GroupBox1.Controls.Add(Me.lbl_ProbeThickness)
        Me.GroupBox1.Controls.Add(Me.lbl_Rapid)
        Me.GroupBox1.Controls.Add(Me.txt_CalXyabMaxTravel)
        Me.GroupBox1.Controls.Add(Me.lbl_Speed)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(5, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(363, 181)
        Me.GroupBox1.TabIndex = 647
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Calibrate XY AB"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox2.Controls.Add(Me.txt_CalZSearchSpeed)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txt_CalZMaxTravel)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txt_CalZReturnSpeed)
        Me.GroupBox2.Controls.Add(Me.txt_CalZCompensation)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(377, 2)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(363, 181)
        Me.GroupBox2.TabIndex = 648
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Calibrate Z"
        '
        'txt_CalZSearchSpeed
        '
        Me.txt_CalZSearchSpeed.ArrowsIncrement = 10
        Me.txt_CalZSearchSpeed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalZSearchSpeed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalZSearchSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalZSearchSpeed.DimFactorGray = -10
        Me.txt_CalZSearchSpeed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalZSearchSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_CalZSearchSpeed.Increment = 2
        Me.txt_CalZSearchSpeed.Location = New System.Drawing.Point(255, 31)
        Me.txt_CalZSearchSpeed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalZSearchSpeed.MaxValue = 99000
        Me.txt_CalZSearchSpeed.MinValue = 0
        Me.txt_CalZSearchSpeed.Name = "txt_CalZSearchSpeed"
        Me.txt_CalZSearchSpeed.NumericValue = 100
        Me.txt_CalZSearchSpeed.NumericValueInteger = 100
        Me.txt_CalZSearchSpeed.RectangleColor = System.Drawing.Color.White
        Me.txt_CalZSearchSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalZSearchSpeed.RoundingStep = 0
        Me.txt_CalZSearchSpeed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalZSearchSpeed.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalZSearchSpeed.SuppressZeros = True
        Me.txt_CalZSearchSpeed.TabIndex = 653
        Me.txt_CalZSearchSpeed.TabStop = False
        Me.txt_CalZSearchSpeed.Text = "100"
        Me.txt_CalZSearchSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label4.Location = New System.Drawing.Point(11, 30)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(240, 32)
        Me.Label4.TabIndex = 654
        Me.Label4.Text = "Search speed (mm/m)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_CalZMaxTravel
        '
        Me.txt_CalZMaxTravel.ArrowsIncrement = 10
        Me.txt_CalZMaxTravel.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalZMaxTravel.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalZMaxTravel.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalZMaxTravel.DimFactorGray = -10
        Me.txt_CalZMaxTravel.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalZMaxTravel.ForeColor = System.Drawing.Color.Black
        Me.txt_CalZMaxTravel.Increment = 1
        Me.txt_CalZMaxTravel.Location = New System.Drawing.Point(255, 102)
        Me.txt_CalZMaxTravel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalZMaxTravel.MaxValue = 99000
        Me.txt_CalZMaxTravel.MinValue = 0
        Me.txt_CalZMaxTravel.Name = "txt_CalZMaxTravel"
        Me.txt_CalZMaxTravel.NumericValue = 100
        Me.txt_CalZMaxTravel.NumericValueInteger = 100
        Me.txt_CalZMaxTravel.RectangleColor = System.Drawing.Color.White
        Me.txt_CalZMaxTravel.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalZMaxTravel.RoundingStep = 0
        Me.txt_CalZMaxTravel.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalZMaxTravel.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalZMaxTravel.SuppressZeros = True
        Me.txt_CalZMaxTravel.TabIndex = 651
        Me.txt_CalZMaxTravel.TabStop = False
        Me.txt_CalZMaxTravel.Text = "100"
        Me.txt_CalZMaxTravel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(11, 101)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(240, 32)
        Me.Label3.TabIndex = 652
        Me.Label3.Text = "Max travel (mm)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_CalZReturnSpeed
        '
        Me.txt_CalZReturnSpeed.ArrowsIncrement = 1
        Me.txt_CalZReturnSpeed.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalZReturnSpeed.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalZReturnSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalZReturnSpeed.DimFactorGray = -10
        Me.txt_CalZReturnSpeed.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalZReturnSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_CalZReturnSpeed.Increment = 0.2
        Me.txt_CalZReturnSpeed.Location = New System.Drawing.Point(255, 66)
        Me.txt_CalZReturnSpeed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalZReturnSpeed.MaxValue = 9900
        Me.txt_CalZReturnSpeed.MinValue = 0
        Me.txt_CalZReturnSpeed.Name = "txt_CalZReturnSpeed"
        Me.txt_CalZReturnSpeed.NumericValue = 10
        Me.txt_CalZReturnSpeed.NumericValueInteger = 10
        Me.txt_CalZReturnSpeed.RectangleColor = System.Drawing.Color.White
        Me.txt_CalZReturnSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalZReturnSpeed.RoundingStep = 0
        Me.txt_CalZReturnSpeed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalZReturnSpeed.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalZReturnSpeed.SuppressZeros = True
        Me.txt_CalZReturnSpeed.TabIndex = 647
        Me.txt_CalZReturnSpeed.TabStop = False
        Me.txt_CalZReturnSpeed.Text = "10"
        Me.txt_CalZReturnSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_CalZCompensation
        '
        Me.txt_CalZCompensation.ArrowsIncrement = 0.01
        Me.txt_CalZCompensation.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_CalZCompensation.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_CalZCompensation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CalZCompensation.Decimals = 2
        Me.txt_CalZCompensation.DimFactorGray = -10
        Me.txt_CalZCompensation.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CalZCompensation.ForeColor = System.Drawing.Color.Black
        Me.txt_CalZCompensation.Increment = 0.002
        Me.txt_CalZCompensation.Location = New System.Drawing.Point(255, 139)
        Me.txt_CalZCompensation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_CalZCompensation.MaxValue = 99
        Me.txt_CalZCompensation.MinValue = 0
        Me.txt_CalZCompensation.Name = "txt_CalZCompensation"
        Me.txt_CalZCompensation.NumericValue = 1
        Me.txt_CalZCompensation.NumericValueInteger = 1
        Me.txt_CalZCompensation.RectangleColor = System.Drawing.Color.White
        Me.txt_CalZCompensation.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_CalZCompensation.RoundingStep = 0
        Me.txt_CalZCompensation.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_CalZCompensation.Size = New System.Drawing.Size(93, 31)
        Me.txt_CalZCompensation.TabIndex = 649
        Me.txt_CalZCompensation.TabStop = False
        Me.txt_CalZCompensation.Text = "1.00"
        Me.txt_CalZCompensation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(11, 138)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 32)
        Me.Label1.TabIndex = 650
        Me.Label1.Text = "Compensation (mm)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label2.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label2.Location = New System.Drawing.Point(11, 65)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(240, 32)
        Me.Label2.TabIndex = 648
        Me.Label2.Text = "Return speed (mm/m)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form_Calibrations
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(744, 188)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_Calibrations"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Calibrations settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txt_CalXyabMaxTravel As MyTextBox
    Friend WithEvents lbl_Speed As System.Windows.Forms.Label
    Friend WithEvents lbl_Rapid As System.Windows.Forms.Label
    Friend WithEvents txt_CalXyabReturnSpeed As MyTextBox
    Friend WithEvents lbl_Feed As System.Windows.Forms.Label
    Friend WithEvents txt_CalXyabSearchSpeed As MyTextBox
    Friend WithEvents txt_CalXyabCompensation As MyTextBox
    Friend WithEvents lbl_ProbeThickness As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_CalZReturnSpeed As MyTextBox
    Friend WithEvents txt_CalZCompensation As MyTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_CalZMaxTravel As MyTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_CalZSearchSpeed As MyTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
