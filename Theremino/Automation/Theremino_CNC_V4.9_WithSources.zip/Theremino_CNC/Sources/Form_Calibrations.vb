﻿Public Class Form_Calibrations

    Private Sub Me_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            Me.Hide()
            e.Cancel = True
        End If
    End Sub

    'Private Sub Me_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
    '    If Me.Visible Then
    '        Dim position As Point
    '        position.X = Form1.PanelBack2.Left + Form1.GroupBox_Motors.Right - Form1.lbl_CoordX.Width - Me.ClientRectangle.Width
    '        position.Y = Form1.GroupBox_Motors.Top + 40
    '        position = Form1.PointToScreen(position)
    '        Me.Location = position


    '        'Dim p As Point = New Point(GroupBox_Calibrations.Left - Form_Calibrations.ClientRectangle.Width, _
    '        '                            Me.Size.Height - Me.ClientSize.Height + GroupBox_Toolpath.Bottom)
    '        'p = Me.PointToScreen(p)
    '        'Form_Calibrations.Top = p.Y
    '        'Form_Calibrations.Left = p.X
    '    End If
    'End Sub

    ' ==============================================================================================================
    '   Params 
    ' ==============================================================================================================
    Private Sub Params_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                            txt_CalXyabSearchSpeed.LostFocus, _
                                                                            txt_CalXyabReturnSpeed.LostFocus, _
                                                                            txt_CalXyabMaxTravel.LostFocus, _
                                                                            txt_CalXyabCompensation.LostFocus, _
                                                                            txt_CalZSearchSpeed.LostFocus, _
                                                                            txt_CalZReturnSpeed.LostFocus, _
                                                                            txt_CalZMaxTravel.LostFocus, _
                                                                            txt_CalZCompensation.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub Params_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                            txt_CalXyabSearchSpeed.TextChanged, _
                                                                            txt_CalXyabReturnSpeed.TextChanged, _
                                                                            txt_CalXyabMaxTravel.TextChanged, _
                                                                            txt_CalXyabCompensation.TextChanged, _
                                                                            txt_CalZSearchSpeed.TextChanged, _
                                                                            txt_CalZReturnSpeed.TextChanged, _
                                                                            txt_CalZMaxTravel.TextChanged, _
                                                                            txt_CalZCompensation.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        EventsAreEnabled = False
        SetAllParams()
        EventsAreEnabled = True
    End Sub

    Friend Sub SetAllParams()
        CNC_CalXyabSearchSpeed = txt_CalXyabSearchSpeed.NumericValueInteger
        CNC_CalXyabReturnSpeed = txt_CalXyabReturnSpeed.NumericValueInteger
        CNC_CalXyabMaxTravel = txt_CalXyabMaxTravel.NumericValueInteger
        CNC_CalXyabCompensation = CSng(txt_CalXyabCompensation.NumericValue)
        CNC_CalZSearchSpeed = txt_CalZSearchSpeed.NumericValueInteger
        CNC_CalZReturnSpeed = txt_CalZReturnSpeed.NumericValueInteger
        CNC_CalZMaxTravel = txt_CalZMaxTravel.NumericValueInteger
        CNC_CalZCompensation = CSng(txt_CalZCompensation.NumericValue)
        Form1.CalibrationButtons_Enable()
    End Sub

End Class