﻿Public Class Form_MsgBox

    Private DefaultText As String = "Theremino CNC - Message"
    Private Selection As String = ""
    Private TextSelectionEnabled As Boolean = False
    Private AutoCloseEnabled As Boolean = False

    Private Function BottomSpace() As Int32
        If WindowsDpiCoeff > 1 Then
            Return 95
        Else
            Return 80
        End If
    End Function

    Private Sub Form_MsgBox_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.C And e.Modifiers = Keys.Control Then
            Beep()
            Clipboard.SetData(System.Windows.Forms.DataFormats.Text, Label1.Text)
            MsgBox("OK - Message text has been copied to clipboard")
        End If
    End Sub

    ' ------------------------------------------------------------ MsgBox with "YES", "NO" and "CANCEL"
    Friend Function Message_YesNoCancel(ByVal text As String, _
                                          Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                          Optional ByVal FontSize As Int32 = 16, _
                                          Optional ByVal CaptionText As String = Nothing) As String
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        If Form1.Visible Then
            Me.StartPosition = FormStartPosition.CenterParent
        Else
            Me.StartPosition = FormStartPosition.CenterScreen
        End If
        If CaptionText = Nothing Then CaptionText = DefaultText
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 60)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + BottomSpace()
        Me.Width = Button_Cancel.Right + 20
        Button_YES.Text = "YES"
        Button_YES.Visible = True
        Button_NO.Visible = True
        Button_Cancel.Visible = True
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ' ------------------------------------------------------- hide and show dialog
        Panel2.Visible = False
        Me.ControlBox = False
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Message_YesNoCancel = Selection
    End Function


    ' ------------------------------------------------------------ Normal MsgBox with "YES" and "NO" selection
    Friend Function Message_YesNo(ByVal text As String, _
                                  Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                  Optional ByVal FontSize As Int32 = 16, _
                                  Optional ByVal CaptionText As String = Nothing) As String
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        If Form1.Visible Then
            Me.StartPosition = FormStartPosition.CenterParent
        Else
            Me.StartPosition = FormStartPosition.CenterScreen
        End If
        If CaptionText = Nothing Then CaptionText = DefaultText
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 60)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Label1.Text = text
        Me.Height = Label1.Bottom + BottomSpace()
        Me.Width = Label1.Right + 20
        Button_YES.Text = "YES"
        Button_YES.Visible = True
        Button_NO.Visible = True
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ' ------------------------------------------------------- hide and show dialog
        Panel2.Visible = False
        Me.ControlBox = False
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Form1.RefreshForm_OnlyForXP()
        Message_YesNo = Selection
    End Function


    ' ------------------------------------------------------------ MsgBox with "OK" selection
    Friend Function Message_OK(ByVal text As String, _
                               Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                               Optional ByVal FontSize As Int32 = 16, _
                               Optional ByVal CaptionText As String = Nothing) As String
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        If Form1.Visible Then
            Me.StartPosition = FormStartPosition.CenterParent
        Else
            Me.StartPosition = FormStartPosition.CenterScreen
        End If
        If CaptionText = Nothing Then CaptionText = DefaultText
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 60)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + BottomSpace()
        Me.Width = Label1.Right + 20
        Button_YES.Text = "OK"
        Button_YES.Visible = True
        Button_NO.Visible = False
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ' ------------------------------------------------------- hide and show dialog
        Panel2.Visible = False
        Me.ControlBox = False
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Form1.RefreshForm_OnlyForXP()
        Message_OK = Selection
    End Function


    ' ------------------------------------------------------------ Special MESSAGE ( can be closed programmatically )
    Friend Sub Message(ByVal text As String, _
                       Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                       Optional ByVal FontSize As Int32 = 16, _
                       Optional ByVal CopyButtonVisible As Boolean = False, _
                       Optional ByVal CaptionText As String = Nothing)
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        If Form1.Visible Then
            Me.StartPosition = FormStartPosition.CenterParent
        Else
            Me.StartPosition = FormStartPosition.CenterScreen
        End If
        If CaptionText = Nothing Then CaptionText = DefaultText
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 60)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 30
        Me.Width = Label1.Right + 20
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = CopyButtonVisible
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ' ------------------------------------------------------- show
        Panel2.Visible = False
        Me.ControlBox = False
        Me.Show()
        Me.Refresh()
        Form1.RefreshForm_OnlyForXP()
    End Sub


    ' ------------------------------- Simple MESSAGE ( can be closed programmatically )
    Friend Sub SimpleMessage(ByVal text As String, _
                             Optional ByVal FontSize As Int32 = 16, _
                             Optional ByVal CaptionText As String = "Message")
        ' -------------------------------------------------------
        If text = "" Then
            Me.Hide()
            Return
        End If
        Me.Label1.BackgroundImage = Nothing
        Me.Label1.Text = text
        SetLabelFontSize(Label1, FontSize)
        Label1.Cursor = Cursors.Hand
        Label1.TextAlign = ContentAlignment.TopLeft
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.Refresh()
        Me.Height = Label1.Bottom + 40
        If WindowsDpiCoeff > 1 Then Me.Height += 15
        Me.Width = Label1.Right + 20
        Me.Text = CaptionText
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ControlBox = False
        ' ------------------------------------------------------- hide and show dialog
        Me.Hide()
        Me.Show()
        Me.Refresh()
    End Sub


    ' ------------------------------------------------------------ Special MESSAGE with progressbar
    Friend Sub MessageWithProgressBar(ByVal text As String, _
                                      Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                      Optional ByVal FontSize As Int32 = 16, _
                                      Optional ByVal CopyButtonVisible As Boolean = False, _
                                      Optional ByVal CaptionText As String = Nothing)
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        If Form1.Visible Then
            Me.StartPosition = FormStartPosition.CenterParent
        Else
            Me.StartPosition = FormStartPosition.CenterScreen
        End If
        If CaptionText = Nothing Then CaptionText = DefaultText
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 60)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 30
        Me.Width = Label1.Right + 20
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = CopyButtonVisible
        PictureBox_FillBar.Visible = True
        TextSelectionEnabled = False
        AutoCloseEnabled = False
        ' ------------------------------------------------------- show
        Panel2.Visible = False
        Me.ControlBox = False
        Me.Show()
        Me.Refresh()
        Form1.RefreshForm_OnlyForXP()
    End Sub

    Friend Sub CloseProgressMessage()
        Me.Hide()
    End Sub


    ' ------------------------------------------------------------ Select text row ( can be closed programmatically )
    Friend Function Message_Select(ByVal text As String, _
                                   ByVal SelectionDefault As String, _
                                   ByVal SelectedLine As Int32, _
                                   Optional ByVal FontSize As Int32 = 16, _
                                   Optional ByVal CaptionText As String = "Select", _
                                   Optional ByVal VerticalPosition As String = "Top", _
                                   Optional ByVal AutoClose As Boolean = False) As String
        ' -------------------------------------------------------
        Me.Label1.BackgroundImage = Nothing
        Me.Label1.Text = text
        SetLabelFontSize(Label1, FontSize)
        Label1.Cursor = Cursors.Hand
        Label1.TextAlign = ContentAlignment.TopLeft
        Me.StartPosition = FormStartPosition.Manual
        Me.Refresh()
        Me.Height = Label1.Bottom + 40
        If WindowsDpiCoeff > 1 Then Me.Height += 15
        Me.Width = Label1.Right + 20
        Me.Left = Control.MousePosition.X - Me.Width \ 2
        Me.Top = Control.MousePosition.Y + 10
        If VerticalPosition = "Top" Then Me.Top -= 50
        If VerticalPosition = "Mid" Then Me.Top -= Me.Height \ 2 + FontSize
        If VerticalPosition = "Bottom" Then Me.Top -= Me.Height - 30
        Me.Text = CaptionText
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        TextSelectionEnabled = True
        AutoCloseEnabled = AutoClose
        If AutoClose Then
            ControlBox = False
        Else
            ControlBox = True
        End If
        ' ------------------------------------------------------- hide and show dialog
        Selection = SelectionDefault
        OldSelectedLine = SelectedLine
        ShowHideLineCursor()
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Form1.RefreshForm_OnlyForXP()
        Label1.Cursor = Cursors.Default
        Return Selection
    End Function


    ' =============================================================================
    '  Event Handlers
    ' =============================================================================
    Private Sub Button_YES_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_YES.Click
        Selection = "YES"
        Me.Hide()
    End Sub
    Private Sub Button_NO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_NO.Click
        Selection = "NO"
        Me.Hide()
    End Sub
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Selection = "CANCEL"
        Me.Hide()
    End Sub

    Private Sub Label1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseDown
        If Not TextSelectionEnabled Then Return
        Dim line As Int32 = GetSelectedLine(e.Y)
        Selection = GetLineText(line).Trim
        If Selection <> "" Then Me.Hide()
        ' -------------------------------------- wait MouseUp to avoid spurious clicks to Form1 controls  
        Do
            Application.DoEvents()
        Loop Until Control.MouseButtons = Windows.Forms.MouseButtons.None
    End Sub

    Private OldSelectedLine As Int32 = -1
    Private Sub Label1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseMove
        If Not TextSelectionEnabled Then Return
        Dim line As Int32 = GetSelectedLine(e.Y)
        If line <> OldSelectedLine Then
            OldSelectedLine = line
            ShowHideLineCursor()
        End If
    End Sub
    Friend Sub TestHide()
        If Not Me.Visible Then Return
        Dim r As Rectangle = Me.RectangleToScreen(Me.ClientRectangle)
        r.Inflate(50, 50)
        If Not r.Contains(Control.MousePosition) Then
            Panel2.Visible = False
            OldSelectedLine = -1
            If AutoCloseEnabled Then
                Me.Hide()
            End If
        End If
    End Sub
    Private Sub Label1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseEnter
        OldSelectedLine = -1
    End Sub
    Private Sub ShowHideLineCursor()
        With Panel2
            If GetLineText(OldSelectedLine).Trim <> "" Then
                .BackgroundImage = Nothing
                .Visible = True
                If WindowsDpiCoeff > 1 Then
                    .Top = CInt(OldSelectedLine * (Label1.Font.Height - 0.8) + 16)
                Else
                    .Top = OldSelectedLine * Label1.Font.Height + 16
                End If
                .Height = Label1.Font.Height
                .Width = 5
                .Left = 2
                .BackColor = Color.FromArgb(255, 255, 50)
            Else
                .Visible = False
            End If
        End With
    End Sub
    ' ------------------------------------------------------------------------------- helper functons
    Private Function GetSelectedLine(ByVal Y As Int32) As Int32
        If WindowsDpiCoeff > 1 Then
            GetSelectedLine = CInt((Y - 16) / (Label1.Font.Height - 0.8))
        Else
            GetSelectedLine = Y \ Label1.Font.Height
        End If
    End Function
    Private Function GetLineText(ByVal line As Int32) As String
        Dim s As String() = Split(Label1.Text, vbCr)
        If line >= LBound(s) And line <= UBound(s) Then
            Return s(line)
        Else
            Return ""
        End If
    End Function
    Private Sub SetLabelFontSize(ByRef lb As Label, ByVal size As Int32)
        Dim f As New Font("Arial", size)
        lb.Font = f
    End Sub

    ' ==============================================================================================================
    '   BUTTONS HILIGHT ON MOUSE ENTER
    ' ==============================================================================================================
    Private Sub Buttons_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles Button_YES.MouseEnter, _
                                                                            Button_NO.MouseEnter, _
                                                                            Button_Cancel.MouseEnter
        SKIN_MouseEnteringButton(Sender)
    End Sub
    Private Sub Buttons_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles Button_YES.MouseLeave, _
                                                                            Button_NO.MouseLeave, _
                                                                            Button_Cancel.MouseLeave
        SKIN_MouseLeavingButton(Sender)
    End Sub

End Class