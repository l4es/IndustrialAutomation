﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Options
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Options))
        Dim CBlendItems1 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems2 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker2 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Dim CBlendItems3 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim CBlendItems4 As Theremino_CNC.cBlendItems = New Theremino_CNC.cBlendItems
        Dim DesignerRectTracker4 As Theremino_CNC.DesignerRectTracker = New Theremino_CNC.DesignerRectTracker
        Me.lbl_JogSpeedNormal = New System.Windows.Forms.Label
        Me.lbl_FirstSlot = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txt_FirstSlot = New Theremino_CNC.MyTextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbl_JogSpeedShift = New System.Windows.Forms.Label
        Me.txt_JogSpeedShift = New Theremino_CNC.MyTextBox
        Me.txt_JogSpeedNormal = New Theremino_CNC.MyTextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txt_SpindleDelay = New Theremino_CNC.MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.btn_ShowRealTipPosition = New Theremino_CNC.MyButton
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.btn_CompensateAcceleration = New Theremino_CNC.MyButton
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_JogSpeedNormal
        '
        Me.lbl_JogSpeedNormal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_JogSpeedNormal.BackColor = System.Drawing.Color.Transparent
        Me.lbl_JogSpeedNormal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_JogSpeedNormal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_JogSpeedNormal.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_JogSpeedNormal.Location = New System.Drawing.Point(10, 22)
        Me.lbl_JogSpeedNormal.Name = "lbl_JogSpeedNormal"
        Me.lbl_JogSpeedNormal.Padding = New System.Windows.Forms.Padding(0, 0, 5, 0)
        Me.lbl_JogSpeedNormal.Size = New System.Drawing.Size(235, 26)
        Me.lbl_JogSpeedNormal.TabIndex = 564
        Me.lbl_JogSpeedNormal.Text = "Jog speed normal"
        Me.lbl_JogSpeedNormal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_FirstSlot
        '
        Me.lbl_FirstSlot.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_FirstSlot.BackColor = System.Drawing.Color.Transparent
        Me.lbl_FirstSlot.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_FirstSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_FirstSlot.Location = New System.Drawing.Point(10, 22)
        Me.lbl_FirstSlot.Name = "lbl_FirstSlot"
        Me.lbl_FirstSlot.Padding = New System.Windows.Forms.Padding(0, 0, 5, 0)
        Me.lbl_FirstSlot.Size = New System.Drawing.Size(235, 26)
        Me.lbl_FirstSlot.TabIndex = 565
        Me.lbl_FirstSlot.Text = "First Slot"
        Me.lbl_FirstSlot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.txt_FirstSlot)
        Me.GroupBox1.Controls.Add(Me.lbl_FirstSlot)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(322, 58)
        Me.GroupBox1.TabIndex = 647
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Slots"
        '
        'txt_FirstSlot
        '
        Me.txt_FirstSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_FirstSlot.ArrowsIncrement = 1
        Me.txt_FirstSlot.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_FirstSlot.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_FirstSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FirstSlot.DimFactorGray = -10
        Me.txt_FirstSlot.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FirstSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_FirstSlot.Increment = 0.2
        Me.txt_FirstSlot.Location = New System.Drawing.Point(247, 23)
        Me.txt_FirstSlot.MaxValue = 990
        Me.txt_FirstSlot.MinValue = 1
        Me.txt_FirstSlot.Name = "txt_FirstSlot"
        Me.txt_FirstSlot.NumericValue = 1
        Me.txt_FirstSlot.NumericValueInteger = 1
        Me.txt_FirstSlot.RectangleColor = System.Drawing.Color.White
        Me.txt_FirstSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_FirstSlot.RoundingStep = 0
        Me.txt_FirstSlot.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_FirstSlot.Size = New System.Drawing.Size(63, 25)
        Me.txt_FirstSlot.SuppressZeros = True
        Me.txt_FirstSlot.TabIndex = 562
        Me.txt_FirstSlot.TabStop = False
        Me.txt_FirstSlot.Text = "1"
        Me.txt_FirstSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox2.Controls.Add(Me.lbl_JogSpeedShift)
        Me.GroupBox2.Controls.Add(Me.txt_JogSpeedShift)
        Me.GroupBox2.Controls.Add(Me.lbl_JogSpeedNormal)
        Me.GroupBox2.Controls.Add(Me.txt_JogSpeedNormal)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(6, 74)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(322, 86)
        Me.GroupBox2.TabIndex = 648
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Jog speeds (% of Rapid)"
        '
        'lbl_JogSpeedShift
        '
        Me.lbl_JogSpeedShift.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_JogSpeedShift.BackColor = System.Drawing.Color.Transparent
        Me.lbl_JogSpeedShift.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_JogSpeedShift.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lbl_JogSpeedShift.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lbl_JogSpeedShift.Location = New System.Drawing.Point(10, 51)
        Me.lbl_JogSpeedShift.Name = "lbl_JogSpeedShift"
        Me.lbl_JogSpeedShift.Padding = New System.Windows.Forms.Padding(0, 0, 5, 0)
        Me.lbl_JogSpeedShift.Size = New System.Drawing.Size(235, 26)
        Me.lbl_JogSpeedShift.TabIndex = 566
        Me.lbl_JogSpeedShift.Text = "Jog speed with SHIFT"
        Me.lbl_JogSpeedShift.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_JogSpeedShift
        '
        Me.txt_JogSpeedShift.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_JogSpeedShift.ArrowsIncrement = 1
        Me.txt_JogSpeedShift.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_JogSpeedShift.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_JogSpeedShift.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_JogSpeedShift.DimFactorGray = -10
        Me.txt_JogSpeedShift.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_JogSpeedShift.ForeColor = System.Drawing.Color.Black
        Me.txt_JogSpeedShift.Increment = 0.2
        Me.txt_JogSpeedShift.Location = New System.Drawing.Point(247, 52)
        Me.txt_JogSpeedShift.MaxValue = 100
        Me.txt_JogSpeedShift.MinValue = 1
        Me.txt_JogSpeedShift.Name = "txt_JogSpeedShift"
        Me.txt_JogSpeedShift.NumericValue = 30
        Me.txt_JogSpeedShift.NumericValueInteger = 30
        Me.txt_JogSpeedShift.RectangleColor = System.Drawing.Color.White
        Me.txt_JogSpeedShift.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_JogSpeedShift.RoundingStep = 0
        Me.txt_JogSpeedShift.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_JogSpeedShift.Size = New System.Drawing.Size(63, 25)
        Me.txt_JogSpeedShift.SuppressZeros = True
        Me.txt_JogSpeedShift.TabIndex = 565
        Me.txt_JogSpeedShift.TabStop = False
        Me.txt_JogSpeedShift.Text = "30"
        Me.txt_JogSpeedShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_JogSpeedNormal
        '
        Me.txt_JogSpeedNormal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_JogSpeedNormal.ArrowsIncrement = 1
        Me.txt_JogSpeedNormal.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_JogSpeedNormal.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_JogSpeedNormal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_JogSpeedNormal.DimFactorGray = -10
        Me.txt_JogSpeedNormal.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_JogSpeedNormal.ForeColor = System.Drawing.Color.Black
        Me.txt_JogSpeedNormal.Increment = 0.2
        Me.txt_JogSpeedNormal.Location = New System.Drawing.Point(247, 23)
        Me.txt_JogSpeedNormal.MaxValue = 100
        Me.txt_JogSpeedNormal.MinValue = 1
        Me.txt_JogSpeedNormal.Name = "txt_JogSpeedNormal"
        Me.txt_JogSpeedNormal.NumericValue = 100
        Me.txt_JogSpeedNormal.NumericValueInteger = 100
        Me.txt_JogSpeedNormal.RectangleColor = System.Drawing.Color.White
        Me.txt_JogSpeedNormal.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_JogSpeedNormal.RoundingStep = 0
        Me.txt_JogSpeedNormal.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_JogSpeedNormal.Size = New System.Drawing.Size(63, 25)
        Me.txt_JogSpeedNormal.SuppressZeros = True
        Me.txt_JogSpeedNormal.TabIndex = 561
        Me.txt_JogSpeedNormal.TabStop = False
        Me.txt_JogSpeedNormal.Text = "100"
        Me.txt_JogSpeedNormal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox3.Controls.Add(Me.txt_SpindleDelay)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.GroupBox3.Location = New System.Drawing.Point(6, 169)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(322, 58)
        Me.GroupBox3.TabIndex = 649
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Spindle motor"
        '
        'txt_SpindleDelay
        '
        Me.txt_SpindleDelay.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SpindleDelay.ArrowsIncrement = 0.1
        Me.txt_SpindleDelay.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_SpindleDelay.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_SpindleDelay.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpindleDelay.Decimals = 1
        Me.txt_SpindleDelay.DimFactorGray = -10
        Me.txt_SpindleDelay.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpindleDelay.ForeColor = System.Drawing.Color.Black
        Me.txt_SpindleDelay.Increment = 0.02
        Me.txt_SpindleDelay.Location = New System.Drawing.Point(247, 23)
        Me.txt_SpindleDelay.MaxValue = 9
        Me.txt_SpindleDelay.MinValue = 0
        Me.txt_SpindleDelay.Name = "txt_SpindleDelay"
        Me.txt_SpindleDelay.NumericValue = 0
        Me.txt_SpindleDelay.RectangleColor = System.Drawing.Color.White
        Me.txt_SpindleDelay.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_SpindleDelay.RoundingStep = 0
        Me.txt_SpindleDelay.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SpindleDelay.Size = New System.Drawing.Size(63, 25)
        Me.txt_SpindleDelay.SuppressZeros = True
        Me.txt_SpindleDelay.TabIndex = 562
        Me.txt_SpindleDelay.TabStop = False
        Me.txt_SpindleDelay.Text = "0"
        Me.txt_SpindleDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(10, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(0, 0, 5, 0)
        Me.Label1.Size = New System.Drawing.Size(235, 26)
        Me.Label1.TabIndex = 565
        Me.Label1.Text = "Delay after Spindle ON (sec.)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox4.Controls.Add(Me.btn_ShowRealTipPosition)
        Me.GroupBox4.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(6, 236)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Size = New System.Drawing.Size(322, 58)
        Me.GroupBox4.TabIndex = 650
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "User interface"
        '
        'btn_ShowRealTipPosition
        '
        Me.btn_ShowRealTipPosition.BackColor = System.Drawing.Color.Transparent
        Me.btn_ShowRealTipPosition.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_ShowRealTipPosition.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ShowRealTipPosition.CenterPtTracker = DesignerRectTracker1
        Me.btn_ShowRealTipPosition.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ShowRealTipPosition.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ShowRealTipPosition.ColorFillBlendChecked = CBlendItems2
        Me.btn_ShowRealTipPosition.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_ShowRealTipPosition.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_ShowRealTipPosition.Corners.All = CType(7, Short)
        Me.btn_ShowRealTipPosition.Corners.LowerLeft = CType(7, Short)
        Me.btn_ShowRealTipPosition.Corners.LowerRight = CType(7, Short)
        Me.btn_ShowRealTipPosition.Corners.UpperLeft = CType(7, Short)
        Me.btn_ShowRealTipPosition.Corners.UpperRight = CType(7, Short)
        Me.btn_ShowRealTipPosition.DimFactorGray = -20
        Me.btn_ShowRealTipPosition.DimFactorOver = 30
        Me.btn_ShowRealTipPosition.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ShowRealTipPosition.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_ShowRealTipPosition.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ShowRealTipPosition.FocalPoints.CenterPtY = 1.0!
        Me.btn_ShowRealTipPosition.FocalPoints.FocusPtX = 0.0!
        Me.btn_ShowRealTipPosition.FocalPoints.FocusPtY = 0.0!
        Me.btn_ShowRealTipPosition.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_ShowRealTipPosition.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_ShowRealTipPosition.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ShowRealTipPosition.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ShowRealTipPosition.FocusPtTracker = DesignerRectTracker2
        Me.btn_ShowRealTipPosition.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ShowRealTipPosition.ForeColor = System.Drawing.Color.Black
        Me.btn_ShowRealTipPosition.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ShowRealTipPosition.Image = Nothing
        Me.btn_ShowRealTipPosition.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRealTipPosition.ImageIndex = 0
        Me.btn_ShowRealTipPosition.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ShowRealTipPosition.Location = New System.Drawing.Point(13, 22)
        Me.btn_ShowRealTipPosition.Name = "btn_ShowRealTipPosition"
        Me.btn_ShowRealTipPosition.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_ShowRealTipPosition.SideImage = Nothing
        Me.btn_ShowRealTipPosition.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRealTipPosition.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ShowRealTipPosition.Size = New System.Drawing.Size(297, 29)
        Me.btn_ShowRealTipPosition.TabIndex = 642
        Me.btn_ShowRealTipPosition.Text = "Show real tip position"
        Me.btn_ShowRealTipPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRealTipPosition.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ShowRealTipPosition.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_ShowRealTipPosition.TextShadow = System.Drawing.Color.Transparent
        Me.btn_ShowRealTipPosition.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox5.Controls.Add(Me.btn_CompensateAcceleration)
        Me.GroupBox5.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.Black
        Me.GroupBox5.Location = New System.Drawing.Point(6, 303)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Size = New System.Drawing.Size(322, 58)
        Me.GroupBox5.TabIndex = 651
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Low acceleration motors"
        '
        'btn_CompensateAcceleration
        '
        Me.btn_CompensateAcceleration.BackColor = System.Drawing.Color.Transparent
        Me.btn_CompensateAcceleration.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_CompensateAcceleration.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CompensateAcceleration.CenterPtTracker = DesignerRectTracker3
        Me.btn_CompensateAcceleration.CheckButton = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CompensateAcceleration.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CompensateAcceleration.ColorFillBlendChecked = CBlendItems4
        Me.btn_CompensateAcceleration.ColorFillSolid = System.Drawing.Color.Transparent
        Me.btn_CompensateAcceleration.ColorFillSolidChecked = System.Drawing.Color.Transparent
        Me.btn_CompensateAcceleration.Corners.All = CType(7, Short)
        Me.btn_CompensateAcceleration.Corners.LowerLeft = CType(7, Short)
        Me.btn_CompensateAcceleration.Corners.LowerRight = CType(7, Short)
        Me.btn_CompensateAcceleration.Corners.UpperLeft = CType(7, Short)
        Me.btn_CompensateAcceleration.Corners.UpperRight = CType(7, Short)
        Me.btn_CompensateAcceleration.DimFactorGray = -20
        Me.btn_CompensateAcceleration.DimFactorOver = 30
        Me.btn_CompensateAcceleration.FillType = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CompensateAcceleration.FillTypeChecked = Theremino_CNC.MyButton.eFillType.LinearVertical
        Me.btn_CompensateAcceleration.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CompensateAcceleration.FocalPoints.CenterPtY = 1.0!
        Me.btn_CompensateAcceleration.FocalPoints.FocusPtX = 0.0!
        Me.btn_CompensateAcceleration.FocalPoints.FocusPtY = 0.0!
        Me.btn_CompensateAcceleration.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_CompensateAcceleration.FocalPointsChecked.CenterPtY = 1.0!
        Me.btn_CompensateAcceleration.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CompensateAcceleration.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CompensateAcceleration.FocusPtTracker = DesignerRectTracker4
        Me.btn_CompensateAcceleration.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CompensateAcceleration.ForeColor = System.Drawing.Color.Black
        Me.btn_CompensateAcceleration.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CompensateAcceleration.Image = Nothing
        Me.btn_CompensateAcceleration.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CompensateAcceleration.ImageIndex = 0
        Me.btn_CompensateAcceleration.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CompensateAcceleration.Location = New System.Drawing.Point(13, 22)
        Me.btn_CompensateAcceleration.Name = "btn_CompensateAcceleration"
        Me.btn_CompensateAcceleration.Shape = Theremino_CNC.MyButton.eShape.Rectangle
        Me.btn_CompensateAcceleration.SideImage = Nothing
        Me.btn_CompensateAcceleration.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CompensateAcceleration.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CompensateAcceleration.Size = New System.Drawing.Size(297, 29)
        Me.btn_CompensateAcceleration.TabIndex = 642
        Me.btn_CompensateAcceleration.Text = "Compensate acceleration effects"
        Me.btn_CompensateAcceleration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CompensateAcceleration.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CompensateAcceleration.TextMargin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btn_CompensateAcceleration.TextShadow = System.Drawing.Color.Transparent
        Me.btn_CompensateAcceleration.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'Form_Options
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(334, 368)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_Options"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Options"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbl_JogSpeedNormal As System.Windows.Forms.Label
    Friend WithEvents txt_FirstSlot As MyTextBox
    Friend WithEvents lbl_FirstSlot As System.Windows.Forms.Label
    Friend WithEvents txt_JogSpeedNormal As MyTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_JogSpeedShift As System.Windows.Forms.Label
    Friend WithEvents txt_JogSpeedShift As Theremino_CNC.MyTextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_SpindleDelay As Theremino_CNC.MyTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_ShowRealTipPosition As Theremino_CNC.MyButton
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CompensateAcceleration As Theremino_CNC.MyButton
End Class
