﻿Public Class Form_Options

    Private Sub Me_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            Me.Hide()
            e.Cancel = True
        End If
    End Sub


    ' ==============================================================================================================
    '   Params 
    ' ==============================================================================================================
    Private Sub Params_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                            txt_FirstSlot.LostFocus, _
                                                                            txt_JogSpeedShift.LostFocus, _
                                                                            txt_JogSpeedNormal.LostFocus, _
                                                                            txt_SpindleDelay.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub Params_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                            txt_FirstSlot.TextChanged, _
                                                                            txt_JogSpeedShift.TextChanged, _
                                                                            txt_JogSpeedNormal.TextChanged, _
                                                                            txt_SpindleDelay.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        EventsAreEnabled = False
        SetAllParams()
        EventsAreEnabled = True
    End Sub

    Friend Sub SetAllParams()
        CNC_SetSlots(txt_FirstSlot.NumericValueInteger)
        CNC_JogSpeedShift = txt_JogSpeedShift.NumericValueInteger
        CNC_JogSpeedNormal = txt_JogSpeedNormal.NumericValueInteger
        CNC_SpindleDelay = txt_SpindleDelay.NumericValue
        ShowRealTipPosition = btn_ShowRealTipPosition.Checked
        CompensateAcceleration = btn_CompensateAcceleration.Checked
    End Sub

    Private Sub btn_ShowRealTipPosition_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ShowRealTipPosition.ClickButtonArea
        SetAllParams()
        Save_INI()
        SKIN_UpdateButtons_FormOptions()
    End Sub

    Private Sub btn_CompensateAcceleration_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CompensateAcceleration.ClickButtonArea
        SetAllParams()
        Save_INI()
        SKIN_UpdateButtons_FormOptions()
    End Sub

End Class