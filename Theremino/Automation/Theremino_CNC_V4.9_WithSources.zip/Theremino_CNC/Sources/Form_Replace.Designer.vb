﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Replace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Replace))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Me.chk_MatchCase = New System.Windows.Forms.CheckBox
        Me.txtReplace = New System.Windows.Forms.TextBox
        Me.lblReplace = New System.Windows.Forms.Label
        Me.txtFind = New System.Windows.Forms.TextBox
        Me.lblFind = New System.Windows.Forms.Label
        Me.cmdClose = New MyButton
        Me.cmdReplace = New MyButton
        Me.cmdFindDown = New MyButton
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.chkOnlyInSelection = New System.Windows.Forms.CheckBox
        Me.cmdFindUp = New MyButton
        Me.cmdReplaceAll = New MyButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'chk_MatchCase
        '
        Me.chk_MatchCase.AutoSize = True
        Me.chk_MatchCase.BackColor = System.Drawing.Color.Transparent
        Me.chk_MatchCase.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_MatchCase.Location = New System.Drawing.Point(15, 135)
        Me.chk_MatchCase.Name = "chk_MatchCase"
        Me.chk_MatchCase.Size = New System.Drawing.Size(123, 27)
        Me.chk_MatchCase.TabIndex = 7
        Me.chk_MatchCase.Text = "Match &case"
        Me.chk_MatchCase.UseVisualStyleBackColor = False
        '
        'txtReplace
        '
        Me.txtReplace.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReplace.Location = New System.Drawing.Point(114, 46)
        Me.txtReplace.MaxLength = 24
        Me.txtReplace.Multiline = True
        Me.txtReplace.Name = "txtReplace"
        Me.txtReplace.Size = New System.Drawing.Size(180, 28)
        Me.txtReplace.TabIndex = 6
        Me.txtReplace.Text = "0"
        Me.txtReplace.WordWrap = False
        '
        'lblReplace
        '
        Me.lblReplace.BackColor = System.Drawing.Color.Transparent
        Me.lblReplace.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReplace.Location = New System.Drawing.Point(6, 46)
        Me.lblReplace.Name = "lblReplace"
        Me.lblReplace.Size = New System.Drawing.Size(102, 28)
        Me.lblReplace.TabIndex = 6
        Me.lblReplace.Text = "Replace:"
        Me.lblReplace.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtFind
        '
        Me.txtFind.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFind.Location = New System.Drawing.Point(114, 10)
        Me.txtFind.MaxLength = 24
        Me.txtFind.Multiline = True
        Me.txtFind.Name = "txtFind"
        Me.txtFind.Size = New System.Drawing.Size(180, 28)
        Me.txtFind.TabIndex = 5
        Me.txtFind.Text = "0"
        Me.txtFind.WordWrap = False
        '
        'lblFind
        '
        Me.lblFind.BackColor = System.Drawing.Color.Transparent
        Me.lblFind.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFind.Location = New System.Drawing.Point(6, 10)
        Me.lblFind.Name = "lblFind"
        Me.lblFind.Size = New System.Drawing.Size(102, 28)
        Me.lblFind.TabIndex = 4
        Me.lblFind.Text = "Find:"
        Me.lblFind.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.Color.Transparent
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdClose.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdClose.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems2.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdClose.ColorFillBlendChecked = CBlendItems2
        Me.cmdClose.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.cmdClose.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.cmdClose.Corners.All = CType(6, Short)
        Me.cmdClose.Corners.LowerLeft = CType(6, Short)
        Me.cmdClose.Corners.LowerRight = CType(6, Short)
        Me.cmdClose.Corners.UpperLeft = CType(6, Short)
        Me.cmdClose.Corners.UpperRight = CType(6, Short)
        Me.cmdClose.FillType = MyButton.eFillType.LinearVertical
        Me.cmdClose.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.cmdClose.FocalPoints.CenterPtX = 0.4705882!
        Me.cmdClose.FocalPoints.CenterPtY = 0.4528302!
        Me.cmdClose.FocalPoints.FocusPtX = 0.0!
        Me.cmdClose.FocalPoints.FocusPtY = 0.0!
        Me.cmdClose.FocalPointsChecked.CenterPtX = 0.5!
        Me.cmdClose.FocalPointsChecked.CenterPtY = 0.5!
        Me.cmdClose.FocalPointsChecked.FocusPtX = 0.0!
        Me.cmdClose.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdClose.FocusPtTracker = DesignerRectTracker2
        Me.cmdClose.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Image = Nothing
        Me.cmdClose.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdClose.ImageIndex = 0
        Me.cmdClose.ImageSize = New System.Drawing.Size(16, 16)
        Me.cmdClose.Location = New System.Drawing.Point(192, 125)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Shape = MyButton.eShape.Rectangle
        Me.cmdClose.SideImage = Nothing
        Me.cmdClose.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdClose.SideImageSize = New System.Drawing.Size(48, 48)
        Me.cmdClose.Size = New System.Drawing.Size(102, 34)
        Me.cmdClose.TabIndex = 11
        Me.cmdClose.Text = "Close"
        Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdClose.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.cmdClose.TextMargin = New System.Windows.Forms.Padding(0)
        Me.cmdClose.TextShadow = System.Drawing.Color.Transparent
        '
        'cmdReplace
        '
        Me.cmdReplace.BackColor = System.Drawing.Color.Transparent
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdReplace.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdReplace.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems4.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdReplace.ColorFillBlendChecked = CBlendItems4
        Me.cmdReplace.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.cmdReplace.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.cmdReplace.Corners.All = CType(6, Short)
        Me.cmdReplace.Corners.LowerLeft = CType(6, Short)
        Me.cmdReplace.Corners.LowerRight = CType(6, Short)
        Me.cmdReplace.Corners.UpperLeft = CType(6, Short)
        Me.cmdReplace.Corners.UpperRight = CType(6, Short)
        Me.cmdReplace.Enabled = False
        Me.cmdReplace.FillType = MyButton.eFillType.LinearVertical
        Me.cmdReplace.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.cmdReplace.FocalPoints.CenterPtX = 0.5263158!
        Me.cmdReplace.FocalPoints.CenterPtY = 0.5333334!
        Me.cmdReplace.FocalPoints.FocusPtX = 0.0!
        Me.cmdReplace.FocalPoints.FocusPtY = 0.0!
        Me.cmdReplace.FocalPointsChecked.CenterPtX = 0.5!
        Me.cmdReplace.FocalPointsChecked.CenterPtY = 0.5!
        Me.cmdReplace.FocalPointsChecked.FocusPtX = 0.0!
        Me.cmdReplace.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdReplace.FocusPtTracker = DesignerRectTracker4
        Me.cmdReplace.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReplace.Image = Nothing
        Me.cmdReplace.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdReplace.ImageIndex = 0
        Me.cmdReplace.ImageSize = New System.Drawing.Size(16, 16)
        Me.cmdReplace.Location = New System.Drawing.Point(309, 86)
        Me.cmdReplace.Name = "cmdReplace"
        Me.cmdReplace.Shape = MyButton.eShape.Rectangle
        Me.cmdReplace.SideImage = Nothing
        Me.cmdReplace.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdReplace.SideImageSize = New System.Drawing.Size(48, 48)
        Me.cmdReplace.Size = New System.Drawing.Size(143, 34)
        Me.cmdReplace.TabIndex = 9
        Me.cmdReplace.Text = "Replace"
        Me.cmdReplace.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdReplace.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.cmdReplace.TextMargin = New System.Windows.Forms.Padding(0)
        Me.cmdReplace.TextShadow = System.Drawing.Color.Transparent
        '
        'cmdFindDown
        '
        Me.cmdFindDown.BackColor = System.Drawing.Color.Transparent
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdFindDown.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdFindDown.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems6.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdFindDown.ColorFillBlendChecked = CBlendItems6
        Me.cmdFindDown.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.cmdFindDown.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.cmdFindDown.Corners.All = CType(6, Short)
        Me.cmdFindDown.Corners.LowerLeft = CType(6, Short)
        Me.cmdFindDown.Corners.LowerRight = CType(6, Short)
        Me.cmdFindDown.Corners.UpperLeft = CType(6, Short)
        Me.cmdFindDown.Corners.UpperRight = CType(6, Short)
        Me.cmdFindDown.Enabled = False
        Me.cmdFindDown.FillType = MyButton.eFillType.LinearVertical
        Me.cmdFindDown.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.cmdFindDown.FocalPoints.CenterPtX = 0.5!
        Me.cmdFindDown.FocalPoints.CenterPtY = 0.5!
        Me.cmdFindDown.FocalPoints.FocusPtX = 0.0!
        Me.cmdFindDown.FocalPoints.FocusPtY = 0.0!
        Me.cmdFindDown.FocalPointsChecked.CenterPtX = 0.5!
        Me.cmdFindDown.FocalPointsChecked.CenterPtY = 0.5!
        Me.cmdFindDown.FocalPointsChecked.FocusPtX = 0.0!
        Me.cmdFindDown.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdFindDown.FocusPtTracker = DesignerRectTracker6
        Me.cmdFindDown.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFindDown.Image = Nothing
        Me.cmdFindDown.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdFindDown.ImageIndex = 0
        Me.cmdFindDown.ImageSize = New System.Drawing.Size(16, 16)
        Me.cmdFindDown.Location = New System.Drawing.Point(309, 47)
        Me.cmdFindDown.Name = "cmdFindDown"
        Me.cmdFindDown.Shape = MyButton.eShape.Rectangle
        Me.cmdFindDown.SideImage = Nothing
        Me.cmdFindDown.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdFindDown.SideImageSize = New System.Drawing.Size(48, 48)
        Me.cmdFindDown.Size = New System.Drawing.Size(143, 34)
        Me.cmdFindDown.TabIndex = 8
        Me.cmdFindDown.Text = "Find next"
        Me.cmdFindDown.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdFindDown.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.cmdFindDown.TextMargin = New System.Windows.Forms.Padding(0)
        Me.cmdFindDown.TextShadow = System.Drawing.Color.Transparent
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(15, 111)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(129, 27)
        Me.CheckBox1.TabIndex = 12
        Me.CheckBox1.Text = "Whole word"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'chkOnlyInSelection
        '
        Me.chkOnlyInSelection.AutoSize = True
        Me.chkOnlyInSelection.BackColor = System.Drawing.Color.Transparent
        Me.chkOnlyInSelection.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnlyInSelection.Location = New System.Drawing.Point(15, 87)
        Me.chkOnlyInSelection.Name = "chkOnlyInSelection"
        Me.chkOnlyInSelection.Size = New System.Drawing.Size(165, 27)
        Me.chkOnlyInSelection.TabIndex = 13
        Me.chkOnlyInSelection.Text = "Only in selection"
        Me.chkOnlyInSelection.UseVisualStyleBackColor = False
        '
        'cmdFindUp
        '
        Me.cmdFindUp.BackColor = System.Drawing.Color.Transparent
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdFindUp.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdFindUp.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems8.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdFindUp.ColorFillBlendChecked = CBlendItems8
        Me.cmdFindUp.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.cmdFindUp.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.cmdFindUp.Corners.All = CType(6, Short)
        Me.cmdFindUp.Corners.LowerLeft = CType(6, Short)
        Me.cmdFindUp.Corners.LowerRight = CType(6, Short)
        Me.cmdFindUp.Corners.UpperLeft = CType(6, Short)
        Me.cmdFindUp.Corners.UpperRight = CType(6, Short)
        Me.cmdFindUp.Enabled = False
        Me.cmdFindUp.FillType = MyButton.eFillType.LinearVertical
        Me.cmdFindUp.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.cmdFindUp.FocalPoints.CenterPtX = 0.5174825!
        Me.cmdFindUp.FocalPoints.CenterPtY = 0.5!
        Me.cmdFindUp.FocalPoints.FocusPtX = 0.0!
        Me.cmdFindUp.FocalPoints.FocusPtY = 0.0!
        Me.cmdFindUp.FocalPointsChecked.CenterPtX = 0.5!
        Me.cmdFindUp.FocalPointsChecked.CenterPtY = 0.5!
        Me.cmdFindUp.FocalPointsChecked.FocusPtX = 0.0!
        Me.cmdFindUp.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdFindUp.FocusPtTracker = DesignerRectTracker8
        Me.cmdFindUp.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFindUp.Image = Nothing
        Me.cmdFindUp.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdFindUp.ImageIndex = 0
        Me.cmdFindUp.ImageSize = New System.Drawing.Size(16, 16)
        Me.cmdFindUp.Location = New System.Drawing.Point(309, 8)
        Me.cmdFindUp.Name = "cmdFindUp"
        Me.cmdFindUp.Shape = MyButton.eShape.Rectangle
        Me.cmdFindUp.SideImage = Nothing
        Me.cmdFindUp.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdFindUp.SideImageSize = New System.Drawing.Size(48, 48)
        Me.cmdFindUp.Size = New System.Drawing.Size(143, 34)
        Me.cmdFindUp.TabIndex = 14
        Me.cmdFindUp.Text = "Find previous"
        Me.cmdFindUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdFindUp.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.cmdFindUp.TextMargin = New System.Windows.Forms.Padding(0)
        Me.cmdFindUp.TextShadow = System.Drawing.Color.Transparent
        '
        'cmdReplaceAll
        '
        Me.cmdReplaceAll.BackColor = System.Drawing.Color.Transparent
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdReplaceAll.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdReplaceAll.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems10.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.cmdReplaceAll.ColorFillBlendChecked = CBlendItems10
        Me.cmdReplaceAll.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.cmdReplaceAll.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.cmdReplaceAll.Corners.All = CType(6, Short)
        Me.cmdReplaceAll.Corners.LowerLeft = CType(6, Short)
        Me.cmdReplaceAll.Corners.LowerRight = CType(6, Short)
        Me.cmdReplaceAll.Corners.UpperLeft = CType(6, Short)
        Me.cmdReplaceAll.Corners.UpperRight = CType(6, Short)
        Me.cmdReplaceAll.Enabled = False
        Me.cmdReplaceAll.FillType = MyButton.eFillType.LinearVertical
        Me.cmdReplaceAll.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.cmdReplaceAll.FocalPoints.CenterPtX = 0.5!
        Me.cmdReplaceAll.FocalPoints.CenterPtY = 0.5!
        Me.cmdReplaceAll.FocalPoints.FocusPtX = 0.0!
        Me.cmdReplaceAll.FocalPoints.FocusPtY = 0.0!
        Me.cmdReplaceAll.FocalPointsChecked.CenterPtX = 0.5!
        Me.cmdReplaceAll.FocalPointsChecked.CenterPtY = 0.5!
        Me.cmdReplaceAll.FocalPointsChecked.FocusPtX = 0.0!
        Me.cmdReplaceAll.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.cmdReplaceAll.FocusPtTracker = DesignerRectTracker10
        Me.cmdReplaceAll.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReplaceAll.Image = Nothing
        Me.cmdReplaceAll.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdReplaceAll.ImageIndex = 0
        Me.cmdReplaceAll.ImageSize = New System.Drawing.Size(16, 16)
        Me.cmdReplaceAll.Location = New System.Drawing.Point(309, 125)
        Me.cmdReplaceAll.Name = "cmdReplaceAll"
        Me.cmdReplaceAll.Shape = MyButton.eShape.Rectangle
        Me.cmdReplaceAll.SideImage = Nothing
        Me.cmdReplaceAll.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdReplaceAll.SideImageSize = New System.Drawing.Size(48, 48)
        Me.cmdReplaceAll.Size = New System.Drawing.Size(143, 34)
        Me.cmdReplaceAll.TabIndex = 15
        Me.cmdReplaceAll.Text = "Replace all"
        Me.cmdReplaceAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cmdReplaceAll.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.cmdReplaceAll.TextMargin = New System.Windows.Forms.Padding(0)
        Me.cmdReplaceAll.TextShadow = System.Drawing.Color.Transparent
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.lblFind)
        Me.Panel1.Controls.Add(Me.cmdReplaceAll)
        Me.Panel1.Controls.Add(Me.lblReplace)
        Me.Panel1.Controls.Add(Me.cmdFindUp)
        Me.Panel1.Controls.Add(Me.cmdFindDown)
        Me.Panel1.Controls.Add(Me.chk_MatchCase)
        Me.Panel1.Controls.Add(Me.cmdReplace)
        Me.Panel1.Controls.Add(Me.txtReplace)
        Me.Panel1.Controls.Add(Me.chkOnlyInSelection)
        Me.Panel1.Controls.Add(Me.cmdClose)
        Me.Panel1.Controls.Add(Me.txtFind)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Location = New System.Drawing.Point(-1, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(459, 166)
        Me.Panel1.TabIndex = 16
        '
        'Form_Replace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(458, 165)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_Replace"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Find and Replace"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents chk_MatchCase As System.Windows.Forms.CheckBox
    Friend WithEvents lblReplace As System.Windows.Forms.Label
    Friend WithEvents lblFind As System.Windows.Forms.Label
    Friend WithEvents cmdClose As MyButton
    Friend WithEvents cmdReplace As MyButton
    Friend WithEvents cmdFindDown As MyButton
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkOnlyInSelection As System.Windows.Forms.CheckBox
    Friend WithEvents cmdFindUp As MyButton
    Friend WithEvents cmdReplaceAll As MyButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtReplace As System.Windows.Forms.TextBox
    Friend WithEvents txtFind As System.Windows.Forms.TextBox
End Class
