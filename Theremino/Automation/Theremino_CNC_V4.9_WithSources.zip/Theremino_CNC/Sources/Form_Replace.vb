﻿Public Class Form_Replace

    Private Sub Form_Replace_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            Me.Hide()
            e.Cancel = True
        End If
    End Sub


    ' ==============================================================================================================
    '   CONTROLS HILIGHT ON MOUSE ENTER
    ' ==============================================================================================================
    Private Sub Buttons_MouseEnter(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles cmdClose.MouseEnter, _
                                                                             cmdFindUp.MouseEnter, _
                                                                             cmdFindDown.MouseEnter, _
                                                                             cmdReplace.MouseEnter, _
                                                                             cmdReplaceAll.MouseEnter
        SKIN_MouseEnteringButton(Sender)
    End Sub
    Private Sub Buttons_MouseLeave(ByVal Sender As System.Object, ByVal e As System.EventArgs) _
                                                                     Handles cmdClose.MouseLeave, _
                                                                             cmdFindUp.MouseLeave, _
                                                                             cmdFindDown.MouseLeave, _
                                                                             cmdReplace.MouseLeave, _
                                                                             cmdReplaceAll.MouseLeave
        SKIN_MouseLeavingButton(Sender)
    End Sub

    '=====================================================================================
    ' VARIABLES
    '=====================================================================================
    Dim FindStartPosition As Integer
    Dim m_CodeBox As SyntaxRichTextBox

    '=====================================================================================
    ' PROPERTIES
    '=====================================================================================
    Public WriteOnly Property OwnerCodeBox() As SyntaxRichTextBox
        Set(ByVal Value As SyntaxRichTextBox)
            m_CodeBox = Value
        End Set
    End Property

    Private Function GetCompareMethod() As CompareMethod
        If chk_MatchCase.Checked Then
            Return CompareMethod.Binary
        Else
            Return CompareMethod.Text
        End If
    End Function

    Private Sub txt_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) _
                                                                                    Handles txtFind.KeyDown, _
                                                                                            txtReplace.KeyDown
        If e.KeyCode = Keys.F3 Then
            FindTextDownward()
            e.Handled = True
        End If
    End Sub

    Private Sub txt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) _
                                                                                    Handles txtFind.KeyPress, _
                                                                                            txtReplace.KeyPress
        If e.KeyChar = vbCr Then
            FindTextDownward()
            e.Handled = True
        End If
    End Sub

    Private Sub txtFind_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFind.TextChanged
        Dim en As Boolean = txtFind.Text <> ""
        cmdFindUp.Enabled = en
        cmdFindDown.Enabled = en
        cmdReplace.Enabled = en
        cmdReplaceAll.Enabled = en
    End Sub

    '=====================================================================================
    ' HELPER ROUTINES
    '=====================================================================================
    Private Sub FindTextUpward()
        Dim FoundAt As Integer
        FindStartPosition = m_CodeBox.SelectionStart - 1
        If FindStartPosition <= 0 Then '= -1 Then
            Beep()
            Exit Sub
        End If
        If chk_MatchCase.Checked Then
            FoundAt = InStrRev(m_CodeBox.Text, txtFind.Text, FindStartPosition, CompareMethod.Binary)
        Else
            FoundAt = InStrRev(m_CodeBox.Text, txtFind.Text, FindStartPosition, CompareMethod.Text)
        End If
        If FoundAt <> 0 Then
            m_CodeBox.Select(FoundAt - 1, txtFind.Text.Length)
        Else
            Beep()
        End If
    End Sub

    Private Sub FindTextDownward()
        Dim FoundAt As Integer
        FindStartPosition = m_CodeBox.SelectionStart + 2
        If FindStartPosition >= m_CodeBox.Text.Length Then
            Beep()
            Exit Sub
        End If
        If chk_MatchCase.Checked Then
            FoundAt = InStr(FindStartPosition, m_CodeBox.Text, txtFind.Text, CompareMethod.Binary)
        Else
            FoundAt = InStr(FindStartPosition, m_CodeBox.Text, txtFind.Text, CompareMethod.Text)
        End If
        If FoundAt <> 0 Then
            m_CodeBox.Select(FoundAt - 1, txtFind.Text.Length)
        Else
            Beep()
        End If
    End Sub

    '=====================================================================================
    ' EVENTS
    '=====================================================================================
    Private Sub cmdFindUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFindUp.MouseDown
        FindTextUpward()
        GraphicThread_DrawToolpathImage(False)
    End Sub
    Private Sub cmdFindDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFindDown.MouseDown
        FindTextDownward()
        GraphicThread_DrawToolpathImage(False)
    End Sub
    Private Sub cmdReplace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplace.Click
        Dim StartAt As Integer = m_CodeBox.SelectionStart
        If m_CodeBox.SelectedText = "" Then Return
        m_CodeBox.SelectedText = Replace(m_CodeBox.SelectedText, txtFind.Text, txtReplace.Text, , , GetCompareMethod)
        m_CodeBox.Select(StartAt, txtReplace.Text.Length)
        Form1.ReparseGcodeAndUpdateUserInterface()
    End Sub
    Private Sub cmdReplaceAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplaceAll.Click
        Dim SelectionStart As Integer = m_CodeBox.SelectionStart
        Dim SelectionLen As Integer = m_CodeBox.SelectionLength
        If Not chkOnlyInSelection.Checked Then m_CodeBox.SelectAll()
        If m_CodeBox.SelectedText = "" Then Return
        m_CodeBox.SelectedText = Replace(m_CodeBox.SelectedText, txtFind.Text, txtReplace.Text, , , GetCompareMethod)
        m_CodeBox.SelectionStart = SelectionStart
        m_CodeBox.SelectionLength = SelectionLen
        m_CodeBox.ScrollToCaret()
        Form1.ReparseGcodeAndUpdateUserInterface()
    End Sub
    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Me.Hide()
    End Sub

End Class