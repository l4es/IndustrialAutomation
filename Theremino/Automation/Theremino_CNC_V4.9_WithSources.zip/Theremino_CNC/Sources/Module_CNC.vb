﻿
Friend Class TemperatureController
    Public Shared Active As Boolean = False
    Public Enabled As Boolean = False
    Public SlotSensor As Int32
    Public SlotHeater As Int32
    Public Desired As Single
    Public PidGain As Single
    Public Measured As Single
    Public Nvalues As Int32
    Public Table(,) As Single
    Sub ResetTable()
        ReDim Table(1, -1)
        Enabled = False
    End Sub
    Sub AddTableLine(ByVal RawValue As Single, ByVal Temperature As Single)
        Nvalues = Table.GetLength(1)
        ReDim Preserve Table(1, Nvalues)
        Table(0, Nvalues) = RawValue
        Table(1, Nvalues) = Temperature
        Nvalues += 1
        If Nvalues >= 2 Then Enabled = True
    End Sub
    Function InterpolateRawValue(ByVal x As Single) As Single
        Dim i As Int32 = 1
        While i < Nvalues - 1 AndAlso Table(0, i) < x
            i = i + 1
        End While
        InterpolateRawValue = Table(1, i - 1) + _
                              ((x - Table(0, i - 1)) / _
                              (Table(0, i) - Table(0, i - 1))) * _
                              (Table(1, i) - Table(1, i - 1))
    End Function
    Function GetText() As String
        If Not Enabled Then Return " - - - "
        Return Measured.ToString("0.0", Globalization.CultureInfo.InvariantCulture).PadLeft(5)
    End Function
End Class


Module Module_CNC

    ' ------------------------------------------ enums
    Friend Enum CNC_FeedSpeedLockedTypes
        AllFromGcode
        FeedLocked
        SpeedLocked
        AllLocked
    End Enum

    Friend Enum CNC_LookAheadTypes
        None
        LookAhead
        LookAheadHiPrecision
        ExactStopAllMotors
    End Enum

    Friend Enum CalibrationSteps
        None
        X1
        X2
        X3
        Y1
        Y2
        Y3
        Z1
        Z2
        Z3
        A1
        A2
        A3
        B1
        B2
        B3
    End Enum
    Friend CNC_CalibrationStep As CalibrationSteps

    ' ------------------------------------------ gcode
    Friend CNC_GcodeParams As GCODE_PARAMS

    ' ------------------------------------------ slots
    Friend SlotDestX As Int32
    Friend SlotDX As Int32
    Friend SlotDestY As Int32
    Friend SlotDY As Int32
    Friend SlotDestZ As Int32
    Friend SlotDZ As Int32
    Friend SlotDestA As Int32
    Friend SlotDA As Int32
    Friend SlotDestB As Int32
    Friend SlotDB As Int32
    ' ------------------------------------------ outputs
    Friend SlotSpindleOnOff As Int32
    Friend SlotSpindleSpeed As Int32
    Friend SlotSpindleCW As Int32
    Friend SlotSpindleCCW As Int32
    Friend SlotToolNumber As Int32
    Friend SlotCooling1 As Int32
    Friend SlotCooling2 As Int32
    Friend SlotCooling3 As Int32
    Friend SlotCooling4 As Int32
    Friend SlotPalletClamp As Int32
    Friend SlotSpindleOrientation As Int32
    Friend SlotGearSpeed As Int32
    Friend SlotMainEnable As Int32
    Friend SlotAccessoryEnable As Int32
    ' ------------------------------------------ inputs
    Friend SlotEmergencyInput As Int32
    Friend SlotLimitsInput As Int32
    Friend SlotCalibrationInput As Int32
    Friend SlotSkipInput As Int32
    ' ------------------------------------------ Outputs - 3D Printers
    Friend SlotHoldingForce As Int32     'Vacuum pressure(Bar) or Magnetic Force or ON/OFF
    Friend SlotCoolingFans As Int32      'Speed or ON/OFF
    ' ------------------------------------------ Inputs-Outputs - 3D Printers
    Friend TempAmbient As TemperatureController = New TemperatureController
    Friend TempChamber As TemperatureController = New TemperatureController
    Friend TempPrintBed As TemperatureController = New TemperatureController
    Friend TempExtruder1 As TemperatureController = New TemperatureController
    Friend TempExtruder2 As TemperatureController = New TemperatureController
    ' ------------------------------------------ working positions
    Friend CNC_Dest As Vec5
    Friend CNC_Tip As Vec5
    Friend CNC_Home_Z As Double
    ' ------------------------------------------ hardware tip (different if IN-OUT disabled)
    Friend CNC_HardwareTip As Vec5
    Friend CNC_HardwareHome_Z As Double
    ' ------------------------------------------ 
    Friend CNC_KeySpacePressed As Boolean = False
    Friend CNC_ToolStop As Boolean
    Friend CNC_TestLowZ As Boolean
    Friend CNC_FeedMode As Feed_Modes
    Friend CNC_Rapid As Int32
    Friend CNC_Feed As Double
    Friend CNC_Speed As Double
    Friend CNC_FeedSpeedLockedType As CNC_FeedSpeedLockedTypes
    Friend CNC_LookAheadType As CNC_LookAheadTypes
    Friend CNC_InOutEnabled As Boolean
    ' ------------------------------------------ 
    Friend CNC_LoopTimeMillisec As Double = 1
    Friend CNC_TimeCoefficient As Double
    Friend CNC_MaxError As Double
    Friend CNC_JogStep As Double
    Friend CNC_JogSpeedShift As Double
    Friend CNC_JogSpeedNormal As Double
    Friend CNC_SpindleDelay As Double
    ' ------------------------------------------
    Friend CNC_ProbeThickness As Double
    ' ------------------------------------------ 
    Friend CNC_GcodeRunning As Boolean = False
    Friend CNC_WaitingTemperature As Boolean = False
    Friend CNC_LineInExecution As Int32 = -1
    Friend CNC_LineToBeExecuted As Int32 = -1
    Friend CNC_WarningZeta As Double = 1
    ' ------------------------------------------ 
    Friend CNC_CalXyabSearchSpeed As Int32
    Friend CNC_CalXyabReturnSpeed As Int32
    Friend CNC_CalXyabMaxTravel As Int32
    Friend CNC_CalXyabCompensation As Single
    Friend CNC_CalZSearchSpeed As Int32
    Friend CNC_CalZReturnSpeed As Int32
    Friend CNC_CalZMaxTravel As Int32
    Friend CNC_CalZCompensation As Single
    Friend CNC_CalFinalClearance As Single = 1 ' final movement fixed = 1 mm

    ' ==================================================================================================
    '   INIT
    ' ==================================================================================================
    Friend Sub CNC_Init(ByRef _ToolpathPic As PictureBox)
        ToolpathPic = _ToolpathPic
        CNC_SetFeedMode(Feed_Modes.None)
    End Sub

    'Friend Sub CNC_InitGcodeParams()
    '    CNC_GcodeParams.FeedMode = Feed_Modes.None
    '    CNC_GcodeParams.Coord = CNC_Tip
    'End Sub

    Friend Sub CNC_RestoreOutputSignals()
        With GCodeParsedLines(CNC_LineInExecution)
            If Not CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.AllLocked And _
               Not CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.SpeedLocked Then
                CNC_SetSpeed(.Speed)
            End If
            If GCodeParsedLines(CNC_LineInExecution).FeedMode = Feed_Modes.Work Then
                CNC_SetSpindleOnOff(1000)
            End If
            CNC_SetTool(.ToolNumber)
            CNC_SetCooling(GCodeParsedLines(CNC_LineInExecution))
            CNC_SetSpindleOrientation(.SpindleOrientation)
            CNC_SetGearSpeed(.GearSpeed)
            CNC_SetPalletClamp(.PalletClamp)
        End With
    End Sub

    Friend Sub CNC_SetTimeCoefficient(ByVal TimerSpeedMillisec As Double)
        ' ----------------------------------------------- correction  60 seconds per minute
        CNC_TimeCoefficient = TimerSpeedMillisec / 1000 / 60
        CNC_LoopTimeMillisec = TimerSpeedMillisec
    End Sub


    ' ==================================================================================================
    '   IN OUT - ALL FUNCTIONS ACCESSING IN-OUT ARE HERE
    ' ==================================================================================================
    Friend Sub CNC_SetSlots(ByVal FirstSlot As Int32)
        ' ------------------------------------------------------------------ Motors
        SlotDestX = FirstSlot                   'Slot 1 (if first slot = 1)
        SlotDX = FirstSlot + 1                  'Slot 2
        SlotDestY = FirstSlot + 2               'Slot 3
        SlotDY = FirstSlot + 3                  'Slot 4
        SlotDestZ = FirstSlot + 4               'Slot 5
        SlotDZ = FirstSlot + 5                  'Slot 6
        SlotDestA = FirstSlot + 6               'Slot 7
        SlotDA = FirstSlot + 7                  'Slot 8
        SlotDestB = FirstSlot + 8               'Slot 9
        SlotDB = FirstSlot + 9                  'Slot 10
        ' ------------------------------------------------------------------ Outputs
        SlotSpindleOnOff = FirstSlot + 10       'Slot 11
        SlotSpindleSpeed = FirstSlot + 11       'Slot 12
        SlotSpindleCW = FirstSlot + 12          'Slot 13
        SlotSpindleCCW = FirstSlot + 13         'Slot 14
        SlotToolNumber = FirstSlot + 14         'Slot 15
        SlotCooling1 = FirstSlot + 15           'Slot 16
        SlotCooling2 = FirstSlot + 16           'Slot 17
        SlotCooling3 = FirstSlot + 17           'Slot 18
        SlotCooling4 = FirstSlot + 18           'Slot 19
        SlotPalletClamp = FirstSlot + 19        'Slot 20
        SlotSpindleOrientation = FirstSlot + 20 'Slot 21
        SlotGearSpeed = FirstSlot + 21          'Slot 22
        SlotMainEnable = FirstSlot + 22         'Slot 23
        SlotAccessoryEnable = FirstSlot + 23    'Slot 24
        'Free 2 = FirstSlot + 24                'Slot 25
        'Free 3 = FirstSlot + 25                'Slot 26
        'Free 4 = FirstSlot + 26                'Slot 27
        'Free 5 = FirstSlot + 27                'Slot 28
        'Free 6 = FirstSlot + 28                'Slot 29
        'Free 7 = FirstSlot + 29                'Slot 30
        ' ------------------------------------------------------------------ Inputs
        SlotEmergencyInput = FirstSlot + 30     'Slot 31
        SlotLimitsInput = FirstSlot + 31        'Slot 32
        SlotCalibrationInput = FirstSlot + 32   'Slot 33
        SlotSkipInput = FirstSlot + 33          'Slot 34
        'Free 1 = FirstSlot + 34                'Slot 35
        'Free 2 = FirstSlot + 35                'Slot 36
        'Free 3 = FirstSlot + 36                'Slot 37
        'Free 4 = FirstSlot + 37                'Slot 38
        'Free 5 = FirstSlot + 38                'Slot 39
        'Free 6 = FirstSlot + 39                'Slot 40
        ' ------------------------------------------------------------------ Outputs - 3D Printers
        SlotHoldingForce = FirstSlot + 40         'Slot 41
        SlotCoolingFans = FirstSlot + 41          'Slot 42
        TempAmbient.SlotHeater = FirstSlot + 42   'Slot 43
        TempChamber.SlotHeater = FirstSlot + 43   'Slot 44
        TempPrintBed.SlotHeater = FirstSlot + 44  'Slot 45
        TempExtruder1.SlotHeater = FirstSlot + 45 'Slot 46
        TempExtruder2.SlotHeater = FirstSlot + 46 'Slot 47
        'Free 1 = FirstSlot + 47                  'Slot 48
        'Free 2 = FirstSlot + 48                  'Slot 49
        'Free 3 = FirstSlot + 49                  'Slot 50
        ' ------------------------------------------------------------------ Inputs - 3D Printers
        TempAmbient.SlotSensor = FirstSlot + 50   'Slot 51 
        TempChamber.SlotSensor = FirstSlot + 51   'Slot 52
        TempPrintBed.SlotSensor = FirstSlot + 52  'Slot 53
        TempExtruder1.SlotSensor = FirstSlot + 53 'Slot 54
        TempExtruder2.SlotSensor = FirstSlot + 54 'Slot 55
    End Sub

    Friend Sub CNC_WriteSlotValues()
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotDestX, CSng(CNC_Tip.x))
        Slots.WriteSlot(SlotDestY, CSng(CNC_Tip.y))
        Slots.WriteSlot(SlotDestZ, CSng(CNC_Tip.z))
        Slots.WriteSlot(SlotDestA, CSng(CNC_Tip.a))
        Slots.WriteSlot(SlotDestB, CSng(CNC_Tip.b))
    End Sub

    Friend Sub CNC_ResetAllAxis()
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotDestX, NAN_Reset)
        Slots.WriteSlot(SlotDestY, NAN_Reset)
        Slots.WriteSlot(SlotDestZ, NAN_Reset)
        Slots.WriteSlot(SlotDestA, NAN_Reset)
        Slots.WriteSlot(SlotDestB, NAN_Reset)
        Threading.Thread.Sleep(100)
    End Sub

    Friend Sub CNC_EnsureZeroToDeltaSlots()
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotDX, 0)
        Slots.WriteSlot(SlotDY, 0)
        Slots.WriteSlot(SlotDZ, 0)
        Slots.WriteSlot(SlotDA, 0)
        Slots.WriteSlot(SlotDB, 0)
    End Sub

    Friend Sub CNC_ResetHardwareTo(ByVal axis As String, ByVal coord As Double)
        Dim slot As Int32
        Select Case axis(axis.Length - 1)
            Case "X"c : slot = SlotDestX : CNC_Dest.x = coord : CNC_Tip.x = coord
            Case "Y"c : slot = SlotDestY : CNC_Dest.y = coord : CNC_Tip.y = coord
            Case "Z"c : slot = SlotDestZ : CNC_Dest.z = coord : CNC_Tip.z = coord
            Case "A"c : slot = SlotDestA : CNC_Dest.a = coord : CNC_Tip.a = coord
            Case "B"c : slot = SlotDestB : CNC_Dest.b = coord : CNC_Tip.b = coord
        End Select
        If CNC_InOutEnabled Then
            Slots.WriteSlot(slot, NAN_Reset)
            Threading.Thread.Sleep(150)
            Slots.WriteSlot(slot, CSng(coord))
        Else
            Threading.Thread.Sleep(150)
        End If
    End Sub

    Friend Sub CNC_SetFeedMode(ByVal f As Feed_Modes)
        CNC_FeedMode = f
        CNC_GcodeParams.FeedMode = f
        If Not CNC_InOutEnabled Then Return
        CNC_SetSpindleOnOff(If(CNC_FeedMode = Feed_Modes.Work, 1000, 0))
    End Sub

    Friend Sub CNC_SetRapid(ByVal rapid As Int32)
        If rapid < 10 Then rapid = 10
        CNC_Rapid = rapid
    End Sub

    Friend Sub CNC_SetFeed(ByVal feed As Int32)
        If feed < 10 Then feed = 10
        CNC_Feed = feed
    End Sub

    Friend Sub CNC_SetSpeed(ByVal speed As Int32)
        CNC_Speed = speed
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotSpindleSpeed, speed)
    End Sub

    Friend Sub CNC_SetTool(ByVal ToolNumber As Int32)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotToolNumber, ToolNumber)
    End Sub

    Friend Sub CNC_SetSpindleOnOff(ByVal value As Single)
        If Not CNC_InOutEnabled Then Return
        ' ------------------------------------------------------ if delay is specified
        If CNC_SpindleDelay > 0 Then
            ' -------------------------------------------------- if starting
            If value <> 0 Then
                ' ---------------------------------------------- if not already moving
                If Slots.ReadSlot(SlotSpindleOnOff) = 0 Then
                    ' ------------------------------------------ then start spindle
                    Slots.WriteSlot(SlotSpindleOnOff, value)
                    ' ------------------------------------------ and wait
                    Dim txt As String
                    txt = "Waiting " + _
                          CNC_SpindleDelay.ToString(Globalization.CultureInfo.InvariantCulture) + _
                          " seconds for spindle startup" + vbCrLf + vbCrLf + _
                          "( as specified in the ""Options"" menu )"
                    frm1.SimpleMessageCrossThread(txt)
                    SleepMyThread(CInt(CNC_SpindleDelay * 1000))
                    frm1.SimpleMessageCrossThread("")
                End If
            End If
        End If
        ' ------------------------------------------------------- normal start and stop 
        Slots.WriteSlot(SlotSpindleOnOff, value)
    End Sub

    Friend Sub CNC_SetSpindle_CW_CCW(ByVal gcp As GCODE_PARAMS)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotSpindleCW, gcp.SpindleCW)
        Slots.WriteSlot(SlotSpindleCCW, gcp.SpindleCCW)
    End Sub

    Friend Sub CNC_ResetSpindleOutputs(ByVal AlsoSlotSpindleSpeed As Boolean)
        Slots.WriteSlot(SlotSpindleOnOff, 0)
        If AlsoSlotSpindleSpeed Then
            Slots.WriteSlot(SlotSpindleSpeed, 0)
        End If
        Slots.WriteSlot(SlotSpindleCW, 0)
        Slots.WriteSlot(SlotSpindleCCW, 0)
    End Sub

    Friend Sub CNC_SetCooling(ByVal gcp As GCODE_PARAMS)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotCooling1, gcp.Cooling1)
        Slots.WriteSlot(SlotCooling2, gcp.Cooling2)
        Slots.WriteSlot(SlotCooling3, gcp.Cooling3)
        Slots.WriteSlot(SlotCooling4, gcp.Cooling4)
    End Sub

    Friend Sub CNC_ResetCoolings()
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotCooling1, 0)
        Slots.WriteSlot(SlotCooling2, 0)
        Slots.WriteSlot(SlotCooling3, 0)
        Slots.WriteSlot(SlotCooling4, 0)
    End Sub

    Friend Sub CNC_SetSpindleOrientation(ByVal SpindleOrientation As Single)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotSpindleOrientation, SpindleOrientation)
    End Sub

    Friend Sub CNC_SetGearSpeed(ByVal GearSpeed As Int32)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotGearSpeed, GearSpeed)
    End Sub

    Friend Sub CNC_SetPalletClamp(ByVal PalletClamp As Int32)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotPalletClamp, PalletClamp)
    End Sub

    Friend Sub CNC_SetMainEnableOutput(ByVal enable As Boolean)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotMainEnable, If(enable, 1000, 0))
    End Sub

    Friend Sub CNC_SetAccessoryEnableOutput(ByVal enable As Boolean)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotAccessoryEnable, If(enable, 1000, 0))
    End Sub

    Friend Sub CNC_SetCoolingFansState(ByVal enable As Boolean)
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotCoolingFans, If(enable, 1000, 0))
    End Sub


    Friend Function CNC_MaxDelta() As Single
        If Not CNC_InOutEnabled Then Return 0
        Dim vmax As Single = 0
        Dim v As Single
        v = Math.Abs(Slots.ReadSlot_NoNan(SlotDX))
        If v > vmax Then vmax = v
        v = Math.Abs(Slots.ReadSlot_NoNan(SlotDY))
        If v > vmax Then vmax = v
        v = Math.Abs(Slots.ReadSlot_NoNan(SlotDZ))
        If v > vmax Then vmax = v
        v = Math.Abs(Slots.ReadSlot_NoNan(SlotDA))
        If v > vmax Then vmax = v
        v = Math.Abs(Slots.ReadSlot_NoNan(SlotDB))
        If v > vmax Then vmax = v
        Return vmax
    End Function

    Friend Function CNC_CalcRealTipPosition(ByVal tip As Vec5) As Vec5
        If Not CNC_InOutEnabled Then Return tip
        tip.x -= Slots.ReadSlot_NoNan(SlotDX)
        tip.y -= Slots.ReadSlot_NoNan(SlotDY)
        tip.z -= Slots.ReadSlot_NoNan(SlotDZ)
        tip.a -= Slots.ReadSlot_NoNan(SlotDA)
        tip.b -= Slots.ReadSlot_NoNan(SlotDB)
        Return tip
    End Function

    Friend Function CNC_TestEmergencyInput() As Boolean
        If Not CNC_InOutEnabled Then Return False
        Return Slots.ReadSlot_NoNan(SlotEmergencyInput) > 500
    End Function

    Friend Function CNC_TestLimitInputs() As Boolean
        If Not CNC_InOutEnabled Then Return False
        If CNC_CalibrationStep <> CalibrationSteps.None Then Return False
        Return Slots.ReadSlot_NoNan(SlotLimitsInput) > 500
    End Function

    Friend Function CNC_TestCalibrationInputs() As Boolean
        If Not CNC_InOutEnabled Then Return True
        Return Slots.ReadSlot_NoNan(SlotLimitsInput) > 500 Or _
               Slots.ReadSlot_NoNan(SlotCalibrationInput) < 500
    End Function

    ' --------------------------------------------------------------------------------
    '  SkipInput is valid only one time and is rearmed when value decreases below 500 
    ' --------------------------------------------------------------------------------
    Private SkipEnabled As Boolean = True
    Friend Function CNC_TestSkipInput() As Boolean
        If Not CNC_InOutEnabled Then Return False
        If Slots.ReadSlot_NoNan(SlotSkipInput) > 500 Then
            If SkipEnabled Then
                SkipEnabled = False
                Return True
            End If
        Else
            SkipEnabled = True
        End If
    End Function

    Friend Sub CNC_EnsureSafeValuesToInputSlots()
        If Not CNC_InOutEnabled Then Return
        Slots.WriteSlot(SlotEmergencyInput, 0)
        Slots.WriteSlot(SlotLimitsInput, 0)
        Slots.WriteSlot(SlotCalibrationInput, 1000)
        Slots.WriteSlot(SlotSkipInput, 0)
        SkipEnabled = True
    End Sub

    ' ==================================================================================================
    '   JOG
    ' ==================================================================================================
    Friend Sub SetDestinationFromPboxXY(ByVal x As Int32, ByVal y As Int32)
        CNC_Dest = CNC_DestFromXY(x, y)
    End Sub
    Private Sub JogX(ByVal delta As Double)
        CNC_Dest.x += delta
    End Sub
    Private Sub JogY(ByVal delta As Double)
        CNC_Dest.y += delta
    End Sub
    Private Sub JogZ(ByVal delta As Double)
        CNC_Dest.z += delta
    End Sub
    Private Sub JogA(ByVal delta As Double)
        CNC_Dest.a += delta
    End Sub
    Private Sub JogB(ByVal delta As Double)
        CNC_Dest.b += delta
    End Sub

    Friend Sub CNC_Jog(ByVal key As Int32, ByVal mm As Double)
        Select Case key
            Case Keys.Left
                JogX(-mm)
            Case Keys.Right
                JogX(mm)
            Case Keys.Up
                JogY(mm)
            Case Keys.Down
                JogY(-mm)
            Case Keys.PageUp, Keys.X
                JogZ(mm)
            Case Keys.PageDown, Keys.Z
                JogZ(-mm)
            Case Keys.A
                JogA(-mm)
            Case Keys.S
                JogA(mm)
            Case Keys.B
                JogB(-mm)
            Case Keys.N
                JogB(mm)
        End Select
    End Sub

    ' ==================================================================================================
    '   READ TEMPERATURE TABLES FROM FILE
    ' ==================================================================================================
    Friend Sub CNC_ReadTemperatureTables()
        ' ---------------------------------------------------------
        TempAmbient.ResetTable()
        TempChamber.ResetTable()
        TempPrintBed.ResetTable()
        TempExtruder1.ResetTable()
        TempExtruder2.ResetTable()
        ' ---------------------------------------------------------
        Dim tpc As TemperatureController = New TemperatureController
        Dim lines() As String
        lines = IO.File.ReadAllLines(Application.StartupPath + "\TemperatureTables.txt")
        For Each line As String In lines
            line = ReplaceMultipleSpacesAndTrim(line)
            line = line.Replace(",", ".")
            If line = "" Then Continue For
            If line.StartsWith("'") Then Continue For
            If line.StartsWith("Sensor", StringComparison.OrdinalIgnoreCase) Then
                If line.EndsWith("TempAmbient", StringComparison.OrdinalIgnoreCase) Then
                    tpc = TempAmbient
                    Continue For
                End If
                If line.EndsWith("TempChamber", StringComparison.OrdinalIgnoreCase) Then
                    tpc = TempChamber
                    Continue For
                End If
                If line.EndsWith("TempPrintBed", StringComparison.OrdinalIgnoreCase) Then
                    tpc = TempPrintBed
                    Continue For
                End If
                If line.EndsWith("TempExtruder1", StringComparison.OrdinalIgnoreCase) Then
                    tpc = TempExtruder1
                    Continue For
                End If
                If line.EndsWith("TempExtruder2", StringComparison.OrdinalIgnoreCase) Then
                    tpc = TempExtruder2
                    Continue For
                End If
            End If
            ' -----------------------------------------------------
            Dim s() As String = line.Split(" "c)
            If s.Length <> 2 Then Return
            Select Case s(0).ToUpper
                Case "DEFAULTTEMP"
                    tpc.Desired = CSng(Val(s(1)))
                Case "PIDGAIN"
                    tpc.PidGain = CSng(Val(s(1)))
                Case Else
                    tpc.AddTableLine(CSng(Val(s(0))), CSng(Val(s(1))))
            End Select
        Next
    End Sub

End Module
