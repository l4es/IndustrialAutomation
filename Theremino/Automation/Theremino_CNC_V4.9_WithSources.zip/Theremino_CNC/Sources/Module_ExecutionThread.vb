﻿Module Module_ExecutionThread

    ' ----------------------------- this enables the access to Form1 from another thread
    Friend frm1 As Form1 = Form1

    ' ==================================================================================================
    '   EXECUTION THREAD
    ' ==================================================================================================
    Friend Const LoopMilliseconds As Int32 = 5
    Friend GcodeTime As Stopwatch = New Stopwatch
    Friend CNC_TimedUpdateEnabled As Boolean = True
    Private ExecutionThread As System.Threading.Thread
    Friend Sub ExecutionThread_Start()
        ExecutionThread = New System.Threading.Thread(AddressOf MainExecutionThread)
        ExecutionThread.Start()
        ExecutionThread.Priority = System.Threading.ThreadPriority.Highest
        RestartThreadLoopMeter()
    End Sub
    Friend Sub ExecutionThread_Stop()
        If ExecutionThread Is Nothing Then Return
        ExecutionThread.Abort()
        ExecutionThread.Join()
        ExecutionThread = Nothing
    End Sub
    Private Sub MainExecutionThread()
        CNC_SetTimeCoefficient(LoopMilliseconds)
        Do
            ' ------------------------------------------------------- 
            System.Threading.Thread.Sleep(LoopMilliseconds)
            ' -------------------------------------------------------
            TimerRepetition_TestMeter()
            ' -------------------------------------------------------
            If CNC_TimedUpdateEnabled Then
                CNC_TimedUpdate()
                CNC_ControlAllTemperatures()
                frm1.CNC_TestPressedKeys()
                Joy_ExecMovements()
            End If
        Loop
    End Sub

    ' ----------------------------------------------------------------------- Loop Time Meter - Restart
    Friend Sub RestartThreadLoopMeter()
        Thread_TimeOld = -1
        Thread_StopWatch.Start()
    End Sub

    ' ----------------------------------------------------------------------- Loop Time Meter 
    Private Thread_LoopTime As Double
    Private Thread_LoopTimeMax As Double = Double.MinValue
    Private Thread_LoopTimeMin As Double = Double.MaxValue
    Private Thread_TimeOld As Double = -1
    Private Thread_TimeNew As Double
    Private Thread_StopWatch As Stopwatch = New Stopwatch
    Private Sub TimerRepetition_TestMeter()
        Thread_TimeNew = Thread_StopWatch.Elapsed.TotalMilliseconds
        If Thread_TimeOld > 0 Then
            ' --------------------------------------------------------------- measure ThreadLoopTime
            Thread_LoopTime = Thread_TimeNew - Thread_TimeOld
            If Thread_LoopTime = 0 Then Thread_LoopTime = 1
            ' --------------------------------------------------------------- correct Time Coefficient
            CNC_SetTimeCoefficient(Thread_LoopTime)
            ' ---------------------------------------------------------------
            'If Thread_LoopTime > Thread_LoopTimeMax Then Thread_LoopTimeMax = Thread_LoopTime
            'If Thread_LoopTime < Thread_LoopTimeMin Then Thread_LoopTimeMin = Thread_LoopTime
            'If My.Computer.Keyboard.CtrlKeyDown Then
            '    Thread_LoopTimeMax = Double.MinValue
            '    Thread_LoopTimeMin = Double.MaxValue
            'End If
        End If
        Thread_TimeOld = Thread_TimeNew
    End Sub


    ' ==================================================================================================
    '   TIMED UPDATE 
    '   This function is called every some mS (constant "LoopMilliseconds" in the Thread creation)
    ' ==================================================================================================
    Friend Sub CNC_TimedUpdate()
        ' ------------------------------------------------------------- Emergency Key-SPACE or Switches 
        If TestEmergency() Then Exit Sub
        ' ------------------------------------------------------------- GCODE ADVANCEMENT
        If CNC_GcodeRunning And Not CNC_WaitingTemperature Then
            ' --------------------------------------------------------- Execute one or more Gcode lines
            Do
                ' ------------------------------------------------------------- Emergency Key-SPACE or Switches 
                If TestEmergency() Then Exit Sub
                ' ----------------------------------------------------- Exit if executing CIP or not enabled
                If CNC_CipExecution Or Not CNC_TimedUpdateEnabled Then Exit Do
                ' ----------------------------------------------------- Exit if motors are moving
                If CNC_MaxDelta() > 0.05 Then
                    Exit Do
                End If
                ' ----------------------------------------------------- Exit if the destination is not reached
                If CNC_LookAheadType = CNC_LookAheadTypes.None Then
                    If CNC_Dest.Subtract(CNC_Tip).Length > CNC_MaxError Then Exit Do
                Else
                    If CNC_Dest.Subtract(CNC_Tip).Length > 0 Then Exit Do
                End If
                ' ----------------------------------------------------- gcode end ?
                If CNC_LineToBeExecuted >= GCodeParsedLines.Length Then
                    CNC_LineToBeExecuted = GCodeParsedLines.Length - 1
                    CNC_TimedUpdateEnabled = False
                    CNC_GcodeRunning = False
                    frm1.StopRunningStateCrossThread("end of program")
                    Exit Sub
                End If
                ' ----------------------------------------------------- read line
                CNC_LineInExecution = CNC_LineToBeExecuted
                CNC_GcodeParams = GCodeParsedLines(CNC_LineToBeExecuted)
                CNC_LineToBeExecuted += 1
                ' ----------------------------------------------------- exec commands 
                Select Case CNC_GcodeParams.LastCMD
                    Case "G04"
                        SleepMyThread(CInt(CNC_GcodeParams.DwellTime * 1000))
                        RestartThreadLoopMeter()
                    Case "G92"
                        Dim coord As Double = Val(Mid(CNC_GcodeParams.LastCMD_Params, 2))
                        CNC_ResetHardwareTo("A", coord)
                    Case "TOOL"
                        CNC_SetTool(CNC_GcodeParams.ToolNumber)
                        ExtruderSelected = CNC_GcodeParams.ToolNumber
                        If CNC_ToolStop Then
                            CNC_TimedUpdateEnabled = False
                            CNC_GcodeRunning = False
                            frm1.StopRunningStateCrossThread("tool change")
                            Exit Sub
                        End If
                    Case "COOLING"
                        CNC_SetCooling(CNC_GcodeParams)
                    Case "PALLET_CLAMP"
                        CNC_SetPalletClamp(CNC_GcodeParams.PalletClamp)
                    Case "SPINDLE_ORIENTATION"
                        CNC_SetSpindleOrientation(CNC_GcodeParams.SpindleOrientation)
                    Case "GEAR_SPEED"
                        CNC_SetGearSpeed(CNC_GcodeParams.GearSpeed)
                    Case "PAUSE"
                        frm1.StopRunningStateCrossThread("pause")
                        Exit Sub

                    Case "DISABLE_ALL"
                        frm1.DisableAllCrossThread("M84")
                    Case "FANS_ON"
                        CNC_SetCoolingFansState(True)
                    Case "FANS_OFF"
                        CNC_SetCoolingFansState(False)
                    Case "EXTRUDER_TEMP"
                        CNC_SetSelectedExtruderTemperature(CNC_GcodeParams.LastCMD_Params)
                    Case "EXTRUDER_TEMP_WAIT"
                        CNC_SetSelectedExtruderTemperature(CNC_GcodeParams.LastCMD_Params)
                        CNC_WaitingTemperature = True
                    Case "CHAMBER_TEMP"
                        TempChamber.Desired = CSng(Val(CNC_GcodeParams.LastCMD_Params))
                    Case "PRINT_BED_TEMP"
                        TempPrintBed.Desired = CSng(Val(CNC_GcodeParams.LastCMD_Params))

                    Case "END"
                        CNC_TimedUpdateEnabled = False
                        CNC_GcodeRunning = False
                        frm1.StopRunningStateCrossThread("end of program")
                        Exit Sub
                End Select
                ' ----------------------------------------------------- set feed and speed
                If Not CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.AllLocked Then
                    If CNC_GcodeParams.UpdatedFeed Then
                        If Not CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.FeedLocked Then
                            CNC_Feed = CNC_GcodeParams.Feed
                        End If
                    End If
                    If CNC_GcodeParams.UpdatedSpeed Then
                        If Not CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.SpeedLocked Then
                            CNC_SetSpeed(CNC_GcodeParams.Speed)
                        End If
                    End If
                End If
                CNC_SetFeedMode(CNC_GcodeParams.FeedMode)
                CNC_SetSpindle_CW_CCW(CNC_GcodeParams)
                ' ----------------------------------------------------- Circular Interpolations start
                If CNC_GcodeParams.cip.Valid Then
                    CNC_CipExecute = True
                    Exit Do
                End If
                ' ----------------------------------------------------- Look Ahead
                Select Case CNC_LookAheadType
                    Case CNC_LookAheadTypes.LookAhead : CNC_LookAhead()
                    Case CNC_LookAheadTypes.LookAheadHiPrecision : CNC_LookAhead()
                    Case CNC_LookAheadTypes.ExactStopAllMotors : CNC_WaitExactStop()
                End Select
                ' ----------------------------------------------------- Goto Home
                If CNC_GcodeParams.LastCMD = "HOME" Then
                    CNC_Dest.x = 0
                    CNC_Dest.y = 0
                    If GC_UsedZ Then CNC_Dest.z = CNC_Home_Z
                    If GC_UsedA Then CNC_Dest.a = 0
                    If GC_UsedB Then CNC_Dest.b = 0
                Else
                    ' ------------------------------------------------- Set Destination
                    If CNC_GcodeParams.UpdatedX Then CNC_Dest.x = CNC_GcodeParams.Coord.x
                    If CNC_GcodeParams.UpdatedY Then CNC_Dest.y = CNC_GcodeParams.Coord.y
                    If CNC_GcodeParams.UpdatedZ Then CNC_Dest.z = CNC_GcodeParams.Coord.z
                    If CNC_GcodeParams.UpdatedA Then CNC_Dest.a = CNC_GcodeParams.Coord.a
                    If CNC_GcodeParams.UpdatedB Then CNC_Dest.b = CNC_GcodeParams.Coord.b
                End If
            Loop
        End If
        ' ------------------------------------------------------------- Circular G02/G03 or linear G00/G01
        If CNC_CipExecute Then
            CNC_CircularInterpolation()
        Else
            CNC_LinearInterpolation()
        End If
        ' ------------------------------------------------------------- Update tool position
        GraphicThread_DrawToolPosition(False)
        CNC_WriteSlotValues()
    End Sub


    ' ==================================================================================================
    '   LOOK AHEAD
    ' ==================================================================================================
    Friend CNC_LookAhead_LastSegment As Vec5

    Private Sub CNC_LookAhead()
        ' --------------------------------------------------------------------- THIS coord - OLD destination
        Dim ThisSegment As Vec5 = CNC_GcodeParams.Coord.Subtract(CNC_Dest)
        ' ---------------------------------------------------------------------
        If ThisSegment.IsValidVector Then
            ' ----------------------------------------------------------------- 
            If CNC_LookAhead_LastSegment.IsValidVector Then
                ' ------------------------------------------------------------- calculate DOT PRODUCT
                Dim dp As Double = Vec5.DotProductNormalized(CNC_LookAhead_LastSegment, ThisSegment)
                ' -------------------------------------------------------------
                ' dp =  1 : the two vectors are pointing in the same direction 
                ' dp =  0 : the two vectors are at right angles 
                ' dp = -1 : the two vectors are pointing in opposite directions 
                ' ------------------------------------------------------------- DEBUG
                'Dim s As String = ""
                's += CNC_LineInExecution.ToString + "  "
                's += CNC_Dest.ToString + "      "
                's += CNC_GcodeParams.Coord.ToString + "      "
                'Debug.Print(s)
                ' ------------------------------------------------------------- calculate MaxErr
                Dim MaxErr As Double
                If dp < 0.9999999 Then
                    If dp > 0 Then
                        ' Maybe the correct trigonometric formula could use tangent,
                        ' but this simple formula, does the work very well 
                        MaxErr = CNC_MaxError / (1 - dp)
                    Else
                        If CNC_LookAheadType = CNC_LookAheadTypes.LookAheadHiPrecision Then
                            ' Complete stop for angles of 90 degree or more 
                            MaxErr = 0
                        Else
                            MaxErr = CNC_MaxError
                        End If
                    End If
                    ' --------------------------------------------------------- wait motor position < MaxErr
                    While CNC_MaxDelta() > MaxErr And CNC_TimedUpdateEnabled
                        If TestEmergency() Then Exit Sub
                        SleepMyThread(5)
                        RestartThreadLoopMeter()
                    End While
                End If
            End If
            ' ----------------------------------------------------------------- update last segment
            CNC_LookAhead_LastSegment = ThisSegment
        End If
    End Sub

    Friend Sub CNC_WaitExactStop()
        While CNC_MaxDelta() > 0 And CNC_TimedUpdateEnabled
            If TestEmergency() Then Exit Sub
            SleepMyThread(5)
            RestartThreadLoopMeter()
        End While
    End Sub

    Private Function TestEmergency() As Boolean
        If CNC_KeySpacePressed Or CNC_TestEmergencyInput() Then
            frm1.StopRunningStateCrossThread("emergency stop")
            CNC_ResetAllAxis()
            Return True
        End If
        If CNC_TestLimitInputs() Then
            frm1.StopRunningStateCrossThread("limit switches")
            Return True
        End If
        Return False
    End Function


    ' ==================================================================================================
    '   LINEAR INTERPOLATION
    ' ==================================================================================================
    Friend CompensateAcceleration As Boolean
    Friend CNC_Distance As Double
    Private CNC_Distance3D As Vec5
    Private CNC_DistanceStep As Double

    Private Sub CNC_LinearInterpolation()
        ' --------------------------------------------------------------------- calc distance
        CNC_Distance3D = CNC_Dest.Subtract(CNC_Tip)
        CNC_Distance = CNC_Distance3D.Length
        ' --------------------------------------------------------------------- calc effective feed
        If CNC_CalibrationStep <> CalibrationSteps.None Then
            CNC_DistanceStep = CalibrationSpeed() * CNC_TimeCoefficient
        Else
            If CNC_FeedMode = Feed_Modes.Work Then
                CNC_DistanceStep = CNC_Feed * CNC_TimeCoefficient
            Else
                CNC_DistanceStep = CNC_Rapid * CNC_TimeCoefficient
                If CNC_Distance3D.MaxLength > 0 Then
                    CNC_DistanceStep *= CNC_Distance3D.Length / CNC_Distance3D.MaxLength
                End If
            End If
        End If
        ' --------------------------------------------------------------------- test if the destination is reached
        If CNC_DistanceStep >= CNC_Distance Then
            ' ----------------------------------------------------------------- limit the last step
            CNC_DistanceStep = CNC_Distance
        End If
        ' --------------------------------------------------------------------- test max error for low acceleration steppers
        If CompensateAcceleration Then
            If CNC_FeedMode = Feed_Modes.Work Then
                Dim maxerr As Double = Math.Max(CNC_MaxError, 0.02)
                If CNC_MaxDelta() > maxerr Then
                    CNC_DistanceStep *= maxerr / CNC_MaxDelta()
                End If
            End If
        End If
        ' --------------------------------------------------------------------- move to the new tip position
        CNC_Tip = CNC_Tip.Add(CNC_Distance3D.Normalized.Mul(CNC_DistanceStep))
        ' --------------------------------------------------------------------- eventually skip the interpolation remaining part
        If CNC_TestSkipInput() Then
            CNC_Dest = CNC_Tip
        End If
    End Sub


    ' ==================================================================================================
    '   CIRCULAR INTERPOLATION
    ' ==================================================================================================
    Friend CNC_CipExecute As Boolean
    Friend CNC_CipExecution As Boolean
    Private CNC_CipAngle As Double
    Private CNC_CipStepsize As Double

    Private Sub CNC_CircularInterpolation()
        With CNC_GcodeParams
            If CNC_CipExecution Then
                ' ------------------------------------------------------------- CIP END
                If (CNC_CipStepsize > 0 And CNC_CipAngle >= .cip.EndAngle) Or _
                   (CNC_CipStepsize < 0 And CNC_CipAngle <= .cip.EndAngle) Then
                    CNC_CipAngle = .cip.EndAngle
                    CNC_CipExecution = False
                    CNC_CipExecute = False
                End If
                CNC_Tip.x = .cip.Center.x + .cip.Radius * Math.Cos(CNC_CipAngle)
                CNC_Tip.y = .cip.Center.y + .cip.Radius * Math.Sin(CNC_CipAngle)
                CNC_CipAngle += CNC_CipStepsize
            Else
                ' ------------------------------------------------------------- CIP START
                CNC_DistanceStep = CNC_Feed * CNC_TimeCoefficient
                CNC_CipStepsize = CNC_DistanceStep * Math.Sign(.cip.EndAngle - .cip.StartAngle) / .cip.Radius
                CNC_CipAngle = .cip.StartAngle + CNC_CipStepsize
                CNC_Dest.x = .cip.Center.x + .cip.Radius * Math.Cos(.cip.EndAngle)
                CNC_Dest.y = .cip.Center.y + .cip.Radius * Math.Sin(.cip.EndAngle)
                CNC_CipExecution = True
            End If
        End With
    End Sub


    ' ==================================================================================================
    '   CALIBRATIONS
    ' ==================================================================================================
    Private Function CalibrationSpeed() As Single
        Select Case CNC_CalibrationStep
            ' --------------------------------------------------------- XY
            Case CalibrationSteps.X1
                If CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.X2
                    CNC_Dest.x += CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabSearchSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.X2
                If Not CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.X3
                    CNC_Dest.x += CNC_CalFinalClearance
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabReturnSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.X3
                If CNC_Dest.IsEqualTo(CNC_Tip) Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.Y1
                    CNC_Dest.y -= CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_Rapid
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.Y1
                If CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.Y2
                    CNC_Dest.y += CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabSearchSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.Y2
                If Not CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.Y3
                    CNC_Dest.y += CNC_CalFinalClearance
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabReturnSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.Y3
                If CNC_Dest.IsEqualTo(CNC_Tip) Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.None
                    CalibrationSpeed = 0
                    CalibrationCompleted("XY")
                Else
                    CalibrationSpeed = CNC_Rapid
                    TestCalibrationPosition()
                End If
                ' --------------------------------------------------------- Z
            Case CalibrationSteps.Z1
                If CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.Z2
                    CNC_Dest.z += CNC_CalZMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalZSearchSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.Z2
                If Not CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.Z3
                    CNC_Dest.z += CNC_CalFinalClearance
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalZReturnSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.Z3
                If CNC_Dest.IsEqualTo(CNC_Tip) Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.None
                    CalibrationSpeed = 0
                    CalibrationCompleted("Z")
                Else
                    CalibrationSpeed = CNC_Rapid
                    TestCalibrationPosition()
                End If
                ' --------------------------------------------------------- AB
            Case CalibrationSteps.A1
                If CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.A2
                    CNC_Dest.a += CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabSearchSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.A2
                If Not CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.A3
                    CNC_Dest.a += CNC_CalFinalClearance
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabReturnSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.A3
                If CNC_Dest.IsEqualTo(CNC_Tip) Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.B1
                    CNC_Dest.b -= CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_Rapid
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.B1
                If CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.B2
                    CNC_Dest.b += CNC_CalXyabMaxTravel
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabSearchSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.B2
                If Not CNC_TestCalibrationInputs() Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.B3
                    CNC_Dest.b += CNC_CalFinalClearance
                    CalibrationSpeed = 0
                Else
                    CalibrationSpeed = CNC_CalXyabReturnSpeed
                    TestCalibrationPosition()
                End If
            Case CalibrationSteps.B3
                If CNC_Dest.IsEqualTo(CNC_Tip) Then
                    CNC_Dest = CNC_Tip
                    CNC_WriteSlotValues()
                    CNC_WaitExactStop()
                    CNC_CalibrationStep = CalibrationSteps.None
                    CalibrationSpeed = 0
                    CalibrationCompleted("AB")
                Else
                    CalibrationSpeed = CNC_Rapid
                    TestCalibrationPosition()
                End If
        End Select
    End Function

    Private Sub CalibrationCompleted(ByVal axes As String)
        '
        My.Computer.Audio.Play(My.Resources.CalibrationOK, AudioPlayMode.Background)
        MessageBox.Show("Calibration completed - Press OK", "Message from Theremino CNC")
        '
        Select Case axes
            Case "XY"
                CNC_Tip.x = CNC_CalXyabCompensation + CNC_CalFinalClearance
                CNC_Tip.y = CNC_CalXyabCompensation + CNC_CalFinalClearance
            Case "Z"
                CNC_Tip.z = CNC_CalZCompensation + CNC_CalFinalClearance
            Case "AB"
                CNC_Tip.a = CNC_CalXyabCompensation + CNC_CalFinalClearance
                CNC_Tip.b = CNC_CalXyabCompensation + CNC_CalFinalClearance
        End Select
        CNC_Dest = CNC_Tip
        CNC_ResetAllAxis()
        CNC_WriteSlotValues()
        My.Computer.Audio.Play(My.Resources.CalibrationOK, AudioPlayMode.Background)
        frm1.StopRunningStateCrossThread("")
        ' -----------------------------------------------------------------
        ' The SendKeys.Flush() corrects a very strange problem:
        ' - After executing calibration
        ' - in the function "CNC_TestPressedKeys"
        ' - the test "My.Computer.Keyboard.ShiftKeyDown" is always false
        ' -----------------------------------------------------------------
        SendKeys.Flush()
        ' -----------------------------------------------------------------
    End Sub

    Private Sub TestCalibrationPosition()
        If CNC_Dest.IsEqualTo(CNC_Tip) Then
            CNC_CalibrationStep = CalibrationSteps.None
            frm1.StopRunningStateCrossThread("")
            My.Computer.Audio.Play(My.Resources.CalibrationError, AudioPlayMode.Background)
            frm1.MessageCrossThread("Calibration aborted" + vbCr + _
                                    "'Max Travel' distance has been exceeded")
        End If
    End Sub


    ' ==================================================================================================
    '   TEMPERATURES
    ' ==================================================================================================
    Private ExtruderSelected As Int32

    Private Sub CNC_SetSelectedExtruderTemperature(ByVal value As String)
        Dim temp As Single = CSng(Val(value))
        If ExtruderSelected = 1 Then TempExtruder1.Desired = temp
        If ExtruderSelected = 2 Then TempExtruder2.Desired = temp
    End Sub

    Private Sub CNC_ControlAllTemperatures()
        If Not TemperatureController.Active Then Return
        ' ------------------------------------------------- temperature controllers
        ControlTemperature(TempAmbient)
        ControlTemperature(TempChamber)
        ControlTemperature(TempPrintBed)
        ControlTemperature(TempExtruder1)
        ControlTemperature(TempExtruder2)
        ' ------------------------------------------------- wait extruder temperature
        If CNC_WaitingTemperature Then
            Dim deltatemp As Single
            If ExtruderSelected = 1 Then deltatemp = TempExtruder1.Desired - TempExtruder1.Measured
            If ExtruderSelected = 2 Then deltatemp = TempExtruder2.Desired - TempExtruder2.Measured
            If Math.Abs(deltatemp) < 0.2 Then
                CNC_WaitingTemperature = False
            End If
        End If
    End Sub

    Private Sub ControlTemperature(ByRef controller As TemperatureController)
        With controller
            If Not .Enabled Then Return
            ' --------------------------------------------
            Dim v As Single = Slots.ReadSlot_NoNan(.SlotSensor)
            ' --------------------------------------------
            If .Table.Length > 0 Then
                .Measured = .InterpolateRawValue(v)
            End If
            ' --------------------------------------------
            v = 499.9F + .PidGain * (.Desired - .Measured)
            If v > 1000 Then v = 1000
            If v < 0 Then v = 0
            Slots.WriteSlot(.SlotHeater, v)
        End With
    End Sub

End Module



