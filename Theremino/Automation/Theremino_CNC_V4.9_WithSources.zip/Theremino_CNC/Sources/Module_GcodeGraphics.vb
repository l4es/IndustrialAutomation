﻿Module Module_GcodeGraphics

    ' =========================================================================
    '   TOOLPATH IMAGE
    ' =========================================================================
    Friend ViewType As ViewTypes = ViewTypes.Up

    Friend ToolpathPic As PictureBox

    Private ToolpathImage As Image
    Private ToolpathGfx As Graphics
    Private ToolpathBackColor As Color

    Private gMinX As Double
    Private gMinY As Double
    Private gMinZ As Double
    Private gMaxX As Double
    Private gMaxY As Double
    Private gMaxZ As Double

    Private gMargin As Int32 = 4
    Private gSizeX As Int32
    Private gSizeY As Int32
    Private gPosX As Double
    Private gPosY As Double
    Private gScale As Double
    Private gScaleBase As Double

    Private ToolPenFirstSegment As Pen
    Private ToolPenRapid As Pen
    Private ToolPenWork As Pen
    Private ToolPenRapidMilled As Pen
    Private ToolPenWorkMilled As Pen

    Friend Sub CNC_UpdatePenColors()
        ToolpathBackColor = ToolpathPic.BackColor
        ' -----------------------------------------------------
        ToolPenFirstSegment = New Pen(ToolPenFirstSegment_Color, ToolPenFirstSegment_Size)
        ToolPenRapid = New Pen(ToolPenRapid_Color, ToolPenRapid_Size)
        ToolPenWork = New Pen(ToolPenWork_Color, ToolPenWork_Size)
        ToolPenRapidMilled = New Pen(ToolPenRapidMilled_Color, ToolPenRapidMilled_Size)
        ToolPenWorkMilled = New Pen(ToolPenWorkMilled_Color, ToolPenWorkMilled_Size)
    End Sub

    ' ==================================================================================================
    '   VIEW TYPES
    ' ==================================================================================================
    Friend Enum ViewTypes
        Up
        Front
        Side
        Frontal
        Isometric
        Oblique
        AB_Up
        AB_Isometric
        AB_Oblique
    End Enum

    ' ViewAxes
    ' ---------------------------------------- simplified
    ' xy xz yz za ab xyz
    ' ---------------------------------------- 2 (10 disp)
    ' xy xz xa xb yz ya yb za zb ab
    ' ---------------------------------------- 3 (10 disp)
    ' xyz xya xyb xza xzb xab yza yzb yab zab
    ' ---------------------------------------- 4 (5 disp)
    ' xyza xyzb xyab xzab yzab
    ' ---------------------------------------- 5 (1 disp)
    ' xyzab

    Private Function ViewTypesCount() As Int32
        Return [Enum].GetNames(GetType(ViewTypes)).Length
    End Function
    Private Function ViewTypesName(ByVal i As Int32) As String
        Return [Enum].GetName(GetType(ViewTypes), i)
    End Function
    Private Function ViewTypeFromString(ByVal s As String) As ViewTypes
        For i As Int32 = 0 To ViewTypesCount() - 1
            If ViewTypesName(i) = s Then
                Return CType(i, ViewTypes)
            End If
        Next
    End Function

    Friend Sub CNC_SelectViewType()
        Dim s As String = ""
        Dim n As Int32 = 5
        If GC_UsedA Or GC_UsedB Then n = 8
        For i As Int32 = 0 To n
            s += ViewTypesName(i) + vbCrLf
        Next
        Dim newType As ViewTypes
        newType = ViewTypeFromString(Form_MsgBox.Message_Select(s, _
                                                                ViewType.ToString, _
                                                                ViewType, _
                                                                15, _
                                                                "View Types", , _
                                                                True))
        If newType <> ViewType Then
            ViewType = newType
            EventsAreEnabled = False
            CNC_InitViewParams()
            GraphicThread_DrawToolpathImage(True)
            EventsAreEnabled = True
        End If
    End Sub

    Private kxx As Double
    Private kxy As Double
    Private kyx As Double
    Private kyy As Double
    Private kzx As Double
    Private kzy As Double
    Private kax As Double
    Private kay As Double
    Private kbx As Double
    Private kby As Double

    Friend Sub CNC_InitViewParams()
        Select Case ViewType
            Case ViewTypes.Up
                kxx = 1
                kxy = 0
                kyx = 0
                kyy = 1
                kzx = 0
                kzy = 0
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.Front
                kxx = 1
                kxy = 0
                kyx = 0
                kyy = 0
                kzx = 0
                kzy = 1
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.Side
                kxx = 0
                kxy = 0
                kyx = 1
                kyy = 0
                kzx = 0
                kzy = 1
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.Frontal
                kxx = 1
                kxy = 0
                kyx = 0
                kyy = 0.8
                kzx = 0
                kzy = 0.5
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.Isometric
                kxx = 1.1
                kxy = 0
                kyx = -0.1
                kyy = 0.816
                kzx = 0
                kzy = 0.816
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.Oblique
                kxx = 1
                kxy = 0.1
                kyx = -0.1
                kyy = 0.7
                kzx = -0.05
                kzy = 0.6
                kax = 0
                kay = 0
                kbx = 0
                kby = 0
            Case ViewTypes.AB_Up
                kxx = 0
                kxy = 0
                kyx = 0
                kyy = 0
                kzx = 0
                kzy = 0
                kax = 1
                kay = 0
                kbx = 0
                kby = 1
            Case ViewTypes.AB_Isometric
                kxx = 0
                kxy = 0
                kyx = 0
                kyy = 0
                kzx = 0
                kzy = 0.816
                kax = 1.1
                kay = 0
                kbx = -0.1
                kby = 0.816
            Case ViewTypes.AB_Oblique
                kxx = 0
                kxy = 0
                kyx = 0
                kyy = 0
                kzx = -0.05
                kzy = 0.6
                kax = 1
                kay = 0.1
                kbx = -0.1
                kby = 0.7
        End Select
        Form1.ToolStripButton_View.Text = "View: " + ViewTypesName(ViewType)
    End Sub


    ' ==================================================================================================
    '   3D CONVERSION FUNCTIONS 
    ' ==================================================================================================
    Private Function CoordToPixelX(ByVal coord As Vec5) As Double
        Dim x As Double = kxx * coord.x + kyx * coord.y + kzx * coord.z + kax * coord.a + kbx * coord.b
        Return gPosX + x * gScale
    End Function
    Private Function CoordToPixelY(ByVal coord As Vec5) As Double
        Dim y As Double = kxy * coord.x + kyy * coord.y + kzy * coord.z + kay * coord.a + kby * coord.b
        Return gPosY - y * gScale
    End Function

    Private Function CoordToX(ByVal coord As Vec5) As Double
        Return kxx * coord.x + kyx * coord.y + kzx * coord.z + kax * coord.a + kbx * coord.b
    End Function
    Private Function CoordToY(ByVal coord As Vec5) As Double
        Return kxy * coord.x + kyy * coord.y + kzy * coord.z + kay * coord.a + kby * coord.b
    End Function

    Friend Function CNC_DestFromXY(ByVal pixelx As Double, ByVal pixely As Double) As Vec5
        If Math.Abs(gMaxX - gMinX) < 0.000001 Or Math.Abs(gMaxY - gMinY) < 0.000001 Then
            Return CNC_Dest
        End If
        CNC_DestFromXY = CNC_Dest
        Dim x As Double = (pixelx - gPosX) / gScale
        Dim y As Double = (gPosY - pixely) / gScale
        Select Case ViewType
            Case ViewTypes.Up
                CNC_DestFromXY.x = x / kxx
                CNC_DestFromXY.y = y / kyy
            Case ViewTypes.Front
                CNC_DestFromXY.x = x / kxx
                CNC_DestFromXY.z = y / kzy
            Case ViewTypes.Side
                CNC_DestFromXY.y = x / kyx
                CNC_DestFromXY.z = y / kzy
            Case ViewTypes.Frontal
                CNC_DestFromXY.x = x / kxx
                CNC_DestFromXY.y = y / kyy - CNC_Dest.z * kzy / kyy
            Case ViewTypes.Isometric
                ' -------------------------------------------------------------- isometric formula is not correct
                ' CNC_DestFromXY.x = x / kxx - y * kyx * kxx + CNC_Dest.z * kyx / kxx
                ' CNC_DestFromXY.y = y / kyy - x * kxy / kyy - CNC_Dest.z * kzy / kyy
                ' -------------------------------------------------------------- replaced with iterative function
                DestFromXY_IterativeCorrector(CNC_DestFromXY, pixelx, pixely)
            Case ViewTypes.Oblique
                ' -------------------------------------------------------------- oblique formula is not correct
                'CNC_DestFromXY.x = x / kxx - y * kyx / kxx + CNC_Dest.z * kzx / kyy * 0.5
                'CNC_DestFromXY.y = y / kyy - x * kxy / kyy - CNC_Dest.z * kzy / kyy
                ' -------------------------------------------------------------- replaced with iterative function
                DestFromXY_IterativeCorrector(CNC_DestFromXY, pixelx, pixely)
            Case ViewTypes.AB_Up
                CNC_DestFromXY.a = x / kax
                CNC_DestFromXY.b = y / kby
            Case ViewTypes.AB_Isometric
                ' -------------------------------------------------------------- isometric formula is not correct
                ' -------------------------------------------------------------- replaced with iterative function
                DestFromXY_IterativeCorrector_AB(CNC_DestFromXY, pixelx, pixely)
            Case ViewTypes.AB_Oblique
                ' -------------------------------------------------------------- isometric formula is not correct
                ' -------------------------------------------------------------- replaced with iterative function
                DestFromXY_IterativeCorrector_AB(CNC_DestFromXY, pixelx, pixely)
        End Select
    End Function

    Private Sub DestFromXY_IterativeCorrector(ByRef dest As Vec5, ByVal x As Double, ByVal y As Double)
        Dim deltax As Double = 0
        Dim deltay As Double = 0
        Do
            dest.x -= deltax / gScale / 1000
            dest.y += deltay / gScale / 1000
            deltax = CoordToPixelX(dest) - x
            deltay = CoordToPixelY(dest) - y
        Loop Until Math.Abs(deltax) < 0.5 And Math.Abs(deltay) < 0.5
    End Sub

    Private Sub DestFromXY_IterativeCorrector_AB(ByRef dest As Vec5, ByVal x As Double, ByVal y As Double)
        Dim deltaa As Double = 0
        Dim deltab As Double = 0
        Do
            dest.a -= deltaa / gScale / 1000
            dest.b += deltab / gScale / 1000
            deltaa = CoordToPixelX(dest) - x
            deltab = CoordToPixelY(dest) - y
        Loop Until Math.Abs(deltaa) < 0.5 And Math.Abs(deltab) < 0.5
    End Sub

    Friend Function CNC_FindNearestSegment(ByVal x As Double, ByVal y As Double) As Int32
        If GCodeParsedLines.Length = 0 Then Return 0
        Dim MinDist As Double = Double.MaxValue
        Dim Line As Int32
        Dim dist As Double
        Dim i As Int32
        Dim x1 As Double = Double.MinValue
        Dim y1 As Double
        Dim x2 As Double
        Dim y2 As Double
        For i = 0 To GcodeLines.Length - 1
            With GCodeParsedLines(i)
                If .LastCMD = "" Then Continue For
                ' ------------------------------------------------------- circular interpolations G02 / G03
                If .cip.Valid Then
                    ' ---------------------------------------------------
                    Dim stepsize As Double = 0.2 * Math.Sign(.cip.EndAngle - .cip.StartAngle)
                    ' --------------------------------------------------- 
                    Dim c As Vec5 = .Coord
                    For deg As Double = .cip.StartAngle To .cip.EndAngle Step stepsize
                        ' ----------------------------------------------- move to the new position
                        c.x = .cip.Center.x + .cip.Radius * Math.Cos(deg)
                        c.y = .cip.Center.y + .cip.Radius * Math.Sin(deg)
                        ' -----------------------------------------------
                        x2 = CoordToPixelX(c)
                        y2 = CoordToPixelY(c)
                        If x1 > Double.MinValue Then
                            dist = Distance_PointToSegment_2D(x, y, x1, y1, x2, y2)
                            If dist < MinDist Then
                                MinDist = dist
                                Line = i
                            End If
                        End If
                        x1 = x2
                        y1 = y2
                    Next
                End If
                ' ------------------------------------------------------- linear interpolation and last CIP segment
                x2 = CoordToPixelX(.Coord)
                y2 = CoordToPixelY(.Coord)
                If x1 > Double.MinValue Then
                    dist = Distance_PointToSegment_2D(x, y, x1, y1, x2, y2)
                    If dist < MinDist Then
                        MinDist = dist
                        Line = i
                    End If
                End If
                x1 = x2
                y1 = y2
                ' ------------------------------------------------------- 
                If .LastCMD = "END" Then Exit For
            End With
        Next
        Return Line
    End Function

    Friend Function CNC_CalcTotalTime() As Double
        If GCodeParsedLines.Length = 0 Then Return 0
        Dim TotalTimeMin As Double = 0
        Dim oldc As Vec5 = CNC_Tip
        ' -------------------------------------------------------
        For i As Int32 = 0 To GCodeParsedLines.Length - 1
            With GCodeParsedLines(i)
                If .LastCMD = "" Then Continue For
                ' ------------------------------------------------------- 
                Dim feed As Double
                If .FeedMode = Feed_Modes.Work Then
                    feed = .Feed
                    If feed = 0 Or _
                        CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.FeedLocked Or _
                        CNC_FeedSpeedLockedType = CNC_FeedSpeedLockedTypes.AllLocked Then feed = CNC_Feed
                Else
                    feed = CNC_Rapid
                End If
                ' ------------------------------------------------------- circular interpolations G02 / G03
                If .cip.Valid Then
                    ' ---------------------------------------------------
                    Dim stepsize As Double = 0.2 * Math.Sign(.cip.EndAngle - .cip.StartAngle)
                    ' --------------------------------------------------- 
                    Dim c As Vec5 = .Coord
                    For deg As Double = .cip.StartAngle To .cip.EndAngle Step stepsize
                        ' ----------------------------------------------- move to the new position
                        c.x = .cip.Center.x + .cip.Radius * Math.Cos(deg)
                        c.y = .cip.Center.y + .cip.Radius * Math.Sin(deg)
                        ' -----------------------------------------------
                        TotalTimeMin += oldc.Dist(c) / feed
                        oldc = c
                    Next
                End If
                ' ------------------------------------------------------- linear interpolation and last CIP segment
                TotalTimeMin += oldc.Dist(.Coord) / feed
                oldc = .Coord
                ' ------------------------------------------------------- 
                If .LastCMD = "END" Then Exit For
            End With
        Next
        Return TotalTimeMin * 60
    End Function


    ' ==================================================================================================
    '   DRAW TOOLPATH IMAGE
    ' ==================================================================================================
    Private Sub DrawToolpathImage(ByVal DrawFirstSegment As Boolean)
        ' --------------------------------------------------------------- for extremely rare cases of async execution
#If Not Debug Then
        Try
#End If
#If DEBUG Then
        Dim sw As Stopwatch = New Stopwatch
        sw.Start()
#End If
        ' --------------------------------------------------------------- init vars
        Dim p1 As Pen
        Dim x As Single
        Dim y As Single
        Dim z As Single
        Dim oldx As Single
        Dim oldy As Single
        Dim oldz As Single = CSng(CNC_Tip.z)
        ' --------------------------------------------------------------- clear background
        ToolpathGfx.Clear(ToolpathBackColor)
        ' ---------------------------------------------------------------
        If CNC_LineInExecution >= GCodeParsedLines.Length Then
            ToolpathPic.Invalidate()
            Return
        End If
        ' --------------------------------------------------------------- first segment
        If DrawFirstSegment Then
            oldx = CSng(CoordToPixelX(CNC_Tip))
            oldy = CSng(CoordToPixelY(CNC_Tip))
            x = CSng(CoordToPixelX(GCodeParsedLines(CNC_LineInExecution).Coord))
            y = CSng(CoordToPixelY(GCodeParsedLines(CNC_LineInExecution).Coord))
            ToolpathGfx.DrawLine(ToolPenFirstSegment, oldx, oldy, x, y)
        End If
        ' ----------------------------------------------------------- oldxy for line 0
        oldx = CSng(CoordToPixelX(GCodeParsedLines(0).Coord))
        oldy = CSng(CoordToPixelY(GCodeParsedLines(0).Coord))
        ' --------------------------------------------------------------- 
        Dim gcp As GCODE_PARAMS = New GCODE_PARAMS
        Dim oldgcp As GCODE_PARAMS = gcp
        ' --------------------------------------------------------------- 
        With gcp
            Dim gcline As Int32 = 0
            Do
                '
                If gcline >= GCodeParsedLines.Length Then Exit Do
                ' ------------------------------------------------------- visualize with MaxError
                'While gcp.Coord.Subtract(oldgcp.Coord).Length <= CNC_MaxError
                '    gcp = GCodeParsedLines(gcLine)
                '    gcLine += 1
                'End While
                ' ------------------------------------------------------- visualize without MaxError
                gcp = GCodeParsedLines(gcline)
                ' -------------------------------------------------------
                gcline += 1
                '
                If .LastCMD = "END" Then Exit Do
                ' ------------------------------------------------------- pen selection
                If gcline > CNC_LineInExecution + 1 Then
                    If .FeedMode = Feed_Modes.Rapid Then
                        p1 = ToolPenRapid
                    Else
                        p1 = ToolPenWork
                    End If
                Else
                    If .FeedMode = Feed_Modes.Rapid Then
                        p1 = ToolPenRapidMilled
                    Else
                        p1 = ToolPenWorkMilled
                    End If
                End If
                ' ------------------------------------------------------- circular interpolations G02 / G03
                With gcp.cip
                    If gcp.cip.Valid Then
                        ' -----------------------------------------------
                        Dim stepsize As Double
                        ' ----------------------------------------------- 1
                        'stepsize = Math.Sqrt(4 / .Radius / gScale)
                        'LimitPositiveNumber(stepsize, 0.1, 0.4)
                        'stepsize *= Math.Sign(.EndAngle - .StartAngle)
                        ' ----------------------------------------------- 2
                        stepsize = 20 / .Radius / gScale
                        LimitPositiveNumber(stepsize, 0.05, 0.4)
                        stepsize *= Math.Sign(.EndAngle - .StartAngle)
                        ' ----------------------------------------------- 
                        Dim c As Vec5 = gcp.Coord
                        For deg As Double = .StartAngle To .EndAngle Step stepsize
                            ' -------------------------------------------
                            c.x = .Center.x + .Radius * Math.Cos(deg)
                            c.y = .Center.y + .Radius * Math.Sin(deg)
                            ' -------------------------------------------
                            x = CSng(CoordToPixelX(c))
                            y = CSng(CoordToPixelY(c))
                            If x <> oldx Or y <> oldy Then
                                ToolpathGfx.DrawLine(p1, oldx, oldy, x, y)
                                oldx = x
                                oldy = y
                            End If
                        Next
                    End If
                End With
                ' ------------------------------------------------------- linear interpolation (and final GCP segment)
                x = CSng(CoordToPixelX(.Coord))
                y = CSng(CoordToPixelY(.Coord))
                If x <> oldx Or y <> oldy Then
                    ToolpathGfx.DrawLine(p1, oldx, oldy, x, y)
                    oldx = x
                    oldy = y
                End If
                ' ------------------------------------------------------- mark holes
                z = CSng(.Coord.z)
                If z < 0 And oldz >= 0 Then
                    ToolpathGfx.DrawEllipse(Pens.Green, x - 2, y - 2, 4, 4)
                End If
                oldz = z
                ' -------------------------------------------------------
                oldgcp = gcp
            Loop
        End With
        ' ---------------------------------------------------------------
        '#If DEBUG Then
        '        ToolpathGfx.DrawString(sw.ElapsedMilliseconds.ToString("0 mS"), _
        '                               New Font("Arial", 16), _
        '                               Brushes.Black, 4, gSizeY - 24)
        '#End If
#If Not Debug Then
        Catch
        End Try
#End If
        ' ---------------------------------------------------------------
        ToolpathPic.Invalidate()
        ' ---------------------------------------------------------------
        OldToolX = Double.MinValue
        OldToolY = Double.MinValue
        ' ---------------------------------------------------------------
    End Sub


    ' ==================================================================================================
    '   INIT TOOL POSITION
    ' ==================================================================================================
    Friend ShowRealTipPosition As Boolean
    Friend ToolPositionX As Single
    Friend ToolPositionY As Single
    Friend UserInterfaceTipPosition As Vec5
    Friend Sub CNC_CalcToolPositions()
        If ShowRealTipPosition Then
            UserInterfaceTipPosition = CNC_CalcRealTipPosition(CNC_Tip)
        Else
            UserInterfaceTipPosition = CNC_Tip
        End If
        ' ------------------------------------------------------- 
        ToolPositionX = CSng(CoordToPixelX(UserInterfaceTipPosition))
        ToolPositionY = CSng(CoordToPixelY(UserInterfaceTipPosition))
    End Sub

    ' ==================================================================================================
    '   DRAW TOOL POSITION
    ' ==================================================================================================
    Private OldToolX As Single
    Private OldToolY As Single
    Private Sub DrawToolPosition()
        CNC_CalcToolPositions()
        If ToolPositionX <> OldToolX OrElse ToolPositionY <> OldToolY Then
            If OldToolX > Double.MinValue Then
                Select Case CNC_FeedMode
                    Case Feed_Modes.Rapid
                        ToolpathGfx.DrawLine(ToolPenRapidMilled, OldToolX, OldToolY, ToolPositionX, ToolPositionY)
                    Case Feed_Modes.Work
                        ToolpathGfx.DrawLine(ToolPenWorkMilled, OldToolX, OldToolY, ToolPositionX, ToolPositionY)
                End Select
            End If
            OldToolX = ToolPositionX
            OldToolY = ToolPositionY
        End If
        ' ---------------------------------------------------------
        If CNC_GcodeRunning Then
            If ToolPositionX < 0 Or ToolPositionX > gSizeX Or _
               ToolPositionY < 0 Or ToolPositionY > gSizeY Then
                CenterViewArea()
                OldToolX = Double.MinValue
            End If
        End If
    End Sub

    Private Sub CenterViewArea()
        ' ------------------------------------------------------------- 
        Dim posx As Double = ToolPositionX
        Dim posy As Double = ToolPositionY
        ' -------------------------------------------------------------
        NewPosX = ((gPosX - posx) * (gScale - gScaleBase)) / gScale - gMinX * gScaleBase + gMargin
        NewPosY = (gPosY * (gScale - gScaleBase) + posy * gScaleBase) / gScale + gMinY * gScaleBase + gSizeY - posy - gMargin
        ' -------------------------------------------------------------
        SetScaleAndPosition(gScale, NewPosX, NewPosY)
        ' -------------------------------------------------------------
        If CNC_GcodeRunning Then
            DrawToolpathImage(False)
        Else
            DrawToolpathImage(True)
        End If
    End Sub

    ' ==================================================================================================
    '   INIT TOOLPATH IMAGE AND GRAPHICS
    ' ==================================================================================================
    Private Sub InitToolpathImageAndGraphics()
        If ToolpathPic.ClientSize.Width < 1 Or ToolpathPic.ClientSize.Height < 1 Then Return
        gSizeX = ToolpathPic.ClientSize.Width
        gSizeY = ToolpathPic.ClientSize.Height
        ' ------------------------------------------------------------ using a bitmap for best performance
        If ToolpathImage Is Nothing OrElse _
                                   ToolpathImage.Width <> gSizeX OrElse _
                                   ToolpathImage.Height <> gSizeY Then
            ToolpathImage = New Bitmap(gSizeX, gSizeY)
        End If
        ' ------------------------------------------------------------ "Graphics.FromImage" for best performance
        ToolpathGfx = Graphics.FromImage(ToolpathImage)
        ToolpathGfx.Clear(Color.FromArgb(255, 255, 230))
        ToolpathGfx.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
        ' ------------------------------------------------------------
        ToolpathPic.Image = ToolpathImage
    End Sub

    ' ==================================================================================================
    '   DRAW MESSAGE ON TOOLPATH IMAGE
    ' ==================================================================================================
    Friend Sub CNC_DrawMessage(ByVal text As String)
        ' --------------------------------------------------------------- clear background
        ToolpathGfx.Clear(ToolpathBackColor)
        ' --------------------------------------------------------------- message
        ToolpathGfx.DrawString(text, _
                               New Font("Tahoma", 14, FontStyle.Regular), _
                               New SolidBrush(ToolpathPic.ForeColor), _
                               10, 10)
        ToolpathPic.Invalidate()
        ' --------------------------------------------------------------- hide cursors
        Form1.UserInterfaceRedraw_Disable()
        Form1.InitToolCursors()
    End Sub

    ' ==================================================================================================
    '   CALC VIEW PARAMS
    ' ==================================================================================================
    Private Sub CalcViewParams()
        If GCodeParsedLines Is Nothing Then Return
        ' ------------------------------------------------------ init vars
        Dim px As Double
        Dim py As Double
        gMinX = Double.MaxValue
        gMinY = Double.MaxValue
        gMaxX = Double.MinValue
        gMaxY = Double.MinValue
        ' ------------------------------------------------------ prepare min-max with tip position
        px = CoordToX(CNC_Tip)
        py = CoordToY(CNC_Tip)
        If px < gMinX Then gMinX = px
        If py < gMinY Then gMinY = py
        If px > gMaxX Then gMaxX = px
        If py > gMaxY Then gMaxY = py
        ' ------------------------------------------------------ init gcode params
        For i As Int32 = 0 To GCodeParsedLines.Length - 1
            With GCodeParsedLines(i)
                If .LastCMD = "" Then Continue For
                ' ------------------------------------------------------- circular interpolations G02 / G03
                If .cip.Valid Then
                    ' ---------------------------------------------------
                    Dim stepsize As Double = 0.2 * Math.Sign(.cip.EndAngle - .cip.StartAngle)
                    ' --------------------------------------------------- 
                    Dim c As Vec5 = .Coord
                    For deg As Double = .cip.StartAngle To .cip.EndAngle Step stepsize
                        ' ----------------------------------------------- move to the new position
                        c.x = .cip.Center.x + .cip.Radius * Math.Cos(deg)
                        c.y = .cip.Center.y + .cip.Radius * Math.Sin(deg)
                        ' -----------------------------------------------
                        px = CSng(CoordToX(c))
                        py = CSng(CoordToY(c))
                        If px < gMinX Then gMinX = px
                        If py < gMinY Then gMinY = py
                        If px > gMaxX Then gMaxX = px
                        If py > gMaxY Then gMaxY = py
                    Next
                End If
                ' ------------------------------------------------------- linear interpolation and last CIP segment
                px = CoordToX(.Coord)
                py = CoordToY(.Coord)
                If px < gMinX Then gMinX = px
                If py < gMinY Then gMinY = py
                If px > gMaxX Then gMaxX = px
                If py > gMaxY Then gMaxY = py
                ' ---------------------------------------------- 
                If .LastCMD = "END" Then Exit For
            End With
        Next
        ' ------------------------------------------------------ scale
        Dim sx As Double = gSizeX - gMargin * 2
        Dim sy As Double = gSizeY - gMargin * 2
        sx /= (gMaxX - gMinX)
        sy /= (gMaxY - gMinY)
        gScaleBase = Math.Min(sx, sy)
        If Double.IsInfinity(gScaleBase) Then gScaleBase = 1
        gScale = gScaleBase
        ' ------------------------------------------------------ position
        gPosX = -gMinX * gScale + gMargin
        gPosY = +gMinY * gScale - gMargin + gSizeY
    End Sub

    Private Sub SetScaleAndPosition(ByVal scale As Double, ByVal px As Double, ByVal py As Double)
        gScale = scale
        gPosX = px
        gPosY = py
        ' ------------------------------------------------------- limit rhe position
        Dim gPX As Double = -gMinX * gScale + gMargin
        Dim gPY As Double = +gMinY * gScale - gMargin + gSizeY
        Dim z As Double = gScale / gScaleBase - 1
        If gPosX > gPX Then gPosX = gPX
        If gPosX < gPX - gSizeX * z Then gPosX = gPX - gSizeX * z
        If gPosY > gPY + gSizeY * z Then gPosY = gPY + gSizeY * z
        If gPosY < gPY Then gPosY = gPY
    End Sub

    Friend Function CNC_GetZoom() As Double
        Return gScale / gScaleBase
    End Function


    ' ==================================================================================================
    '   GRAPHIC THREAD
    ' ==================================================================================================
    Private Flag_InitToolPathImage As Boolean = False
    Private Flag_SetScaleAndPosition As Boolean = False
    Private Flag_CalcViewParams As Boolean = False
    Private Flag_DrawToolPosition As Boolean = False
    Private Flag_CenterViewArea As Boolean = False
    Private Flag_DrawToolPath As Boolean = False
    Private GraphicThread As System.Threading.Thread
    Private NewScale As Double
    Private NewPosX As Double
    Private NewPosY As Double

    Private Sub GraphicThreadLoop()
        Do
            System.Threading.Thread.Sleep(1)
            ' -------------------------------------------------------------
            If Flag_InitToolPathImage Then
                InitToolpathImageAndGraphics()
                Flag_InitToolPathImage = False
            End If
            ' -------------------------------------------------------------
            If Flag_SetScaleAndPosition Then
                SetScaleAndPosition(NewScale, NewPosX, NewPosY)
                ' ----------------------------------------- only if changed
                Static gposx_old As Double = Double.MinValue
                Static gposy_old As Double
                Static gscale_old As Double
                If gPosX <> gposx_old Or gPosY <> gposy_old Or gScale <> gscale_old Then
                    gposx_old = gPosX
                    gposy_old = gPosY
                    gscale_old = gScale
                    DrawToolpathImage(True)
                End If
                ' ---------------------------------------------------------
                Flag_SetScaleAndPosition = False
            End If
            ' -------------------------------------------------------------
            If Flag_DrawToolPosition Then
                DrawToolPosition()
                Flag_DrawToolPosition = False
            End If
            ' -------------------------------------------------------------
            If Flag_CenterViewArea Then
                CenterViewArea()
                Flag_CenterViewArea = False
            End If
            ' -------------------------------------------------------------
            If Flag_DrawToolPath Then
                If Flag_CalcViewParams Then CalcViewParams()
                DrawToolpathImage(True)
                Flag_DrawToolPath = False
            End If
        Loop
    End Sub

    ' ==================================================================================================
    '   GRAPHIC THREAD - Public functions
    ' ==================================================================================================
    Friend LockObject As Object = New Object

    Friend Sub GraphicThread_Start()
        If GraphicThread IsNot Nothing Then Return
        GraphicThread = New System.Threading.Thread(AddressOf GraphicThreadLoop)
        GraphicThread.Start()
        GraphicThread.Priority = System.Threading.ThreadPriority.Normal
    End Sub
    Friend Sub GraphicThread_Stop()
        If GraphicThread Is Nothing Then Return
        GraphicThread.Abort()
        GraphicThread.Join()
        GraphicThread = Nothing
    End Sub
    Friend Sub GraphicThread_InitToolPathImageAndGraphics()
        Flag_InitToolPathImage = True
        Do
            Threading.Thread.Sleep(10)
        Loop Until Flag_InitToolPathImage = False
    End Sub
    Friend Sub GraphicThread_DrawToolpathImage(ByVal CalcViewParams As Boolean)
        ' -------------------------------------------- 
        If Form1.WindowState = FormWindowState.Minimized Then Return
        If ToolpathGfx Is Nothing Then Return
        ' --------------------------------------------
        Flag_CalcViewParams = CalcViewParams
        Flag_DrawToolPath = True
    End Sub
    Friend Sub GraphicThread_WaitToolpathImageCompletion()
        Do
            Threading.Thread.Sleep(10)
        Loop Until Flag_DrawToolPath = False
    End Sub
    Friend Sub GraphicThread_DrawToolPosition(ByVal WaitCompletion As Boolean)
        Flag_DrawToolPosition = True
        If WaitCompletion Then
            Do
                Threading.Thread.Sleep(10)
            Loop Until Flag_DrawToolPosition = False
        End If
    End Sub

    Friend Sub GraphicThread_CenterViewArea()
        Flag_CenterViewArea = True
    End Sub
    ' -----------------------------------------------------------------
    '  Traslate toolpath image with left mouse button
    ' -----------------------------------------------------------------
    Private StartMouseX As Double
    Private StartMouseY As Double
    Private StartPosX As Double
    Private StartPosY As Double
    Friend Sub GraphicThread_SetStartPosition(ByVal mousex As Double, ByVal mousey As Double)
        StartMouseX = mousex
        StartMouseY = mousey
        StartPosX = gPosX
        StartPosY = gPosY
    End Sub
    Friend Sub GraphicThread_SetDeltaPosition(ByVal mousex As Double, ByVal mousey As Double)
        NewScale = gScale
        NewPosX = StartPosX + (mousex - StartMouseX)
        NewPosY = StartPosY + (mousey - StartMouseY)
        ' ------------------------------------------------
        Flag_SetScaleAndPosition = True
    End Sub

    ' -----------------------------------------------------------------
    '  Toolpath image - SetZoomAndPosition
    ' -----------------------------------------------------------------
    Friend Sub GraphicThread_SetZoomAndPosition(ByVal zoomfactor As Single, ByVal posx As Double, ByVal posy As Double)
        NewScale = gScale * zoomfactor
        ' ------------------------------------------------------------- Max and Min scale
        Dim max As Double = gScaleBase * 100
        Dim min As Double = gScaleBase
        If NewScale > max Then NewScale = max
        If NewScale < min Then NewScale = min
        ' ------------------------------------------------------------- Zoom centered
        If posx < 0 Then
            posx = gSizeX / 2
            posy = gSizeY / 2
        End If
        ' ------------------------------------------------------------- New positions
        NewPosX = posx + (gPosX - posx) * NewScale / gScale
        NewPosY = posy + (gPosY - posy) * NewScale / gScale
        ' -------------------------------------------------------------
        Flag_SetScaleAndPosition = True
    End Sub

    Friend Sub GraphicThread_ShowTestValues(ByVal zoomfactor As Single, ByVal posx As Double, ByVal posy As Double)
        DebugWindow_SetText("")
        DebugWindow_AppendText("posX", posx.ToString("0"))
        DebugWindow_AppendText("posY", posy.ToString("0"))
        DebugWindow_AppendText("gSizeX", gSizeX.ToString("0"))
        DebugWindow_AppendText("gSizeY", gSizeY.ToString("0"))
        DebugWindow_AppendText("")
        DebugWindow_AppendText("gPosX", gPosX.ToString("0"))
        DebugWindow_AppendText("gPosY", gPosY.ToString("0"))
        DebugWindow_AppendText("GminX GmaxX", gMinX.ToString("0.0") + " " + gMaxX.ToString("0.0"))
        DebugWindow_AppendText("GminY GmaxY", gMinY.ToString("0.0") + " " + gMaxY.ToString("0.0"))
        DebugWindow_AppendText("gMargin", gMargin.ToString("0.0"))
        DebugWindow_AppendText("gScale", gScale.ToString("0.000"))
        DebugWindow_AppendText("gScaleBase", gScaleBase.ToString("0.000"))
        DebugWindow_Show()
    End Sub


    ' =========================================================================
    '   CALCULATIONS
    ' =========================================================================

    ' -------------------------------------------------------- GCODE TO PIXELS
    ' GCodeToPixelX = gPosX + x(gcode) * gScale 
    ' GCodeToPixelY = gPosY - -y)gcode) * gScale 

    ' -------------------------------------------------------- CALC VIEW PARAMS
    ' gScaleBase = MIN of the following
    '   (gSizeX - gMargin * 2) / (gMaxX - gMinX)
    '   (gSizeY - gMargin * 2) / (gMaxY - gMinY)

    ' gPosX = -gMinX * gScale + gMargin
    ' gPosY = +gMinY * gScale - gMargin + gSizeY

    ' -------------------------------------------------------- SET SCALE AND POSITION
    ' gScale = scale
    ' gPosX = px
    ' gPosY = py
    ' -------------------------------------------------------- limit the position
    ' Dim gPX As Double = -gMinX * gScale + gMargin
    ' Dim gPY As Double = +gMinY * gScale - gMargin + gSizeY
    ' Dim z As Double = gScale / gScaleBase - 1
    ' If gPosX > gPX Then gPosX = gPX
    ' If gPosX < gPX - gSizeX * z Then gPosX = gPX - gSizeX * z
    ' If gPosY > gPY + gSizeY * z Then gPosY = gPY + gSizeY * z
    ' If gPosY < gPY Then gPosY = gPY

    ' -------------------------------------------------------- SET ZOOM
    ' NewScale = gScale * zoomfactor
    ' --------------------------------------------------------
    ' LIMIT gScale from GscaleBase to GscaleBase * 10 
    ' ------------------------------------------------------------- Zoom and Z
    ' Dim oldzoom As Double = gScale / gScaleBase
    ' Dim zoom As Double = NewScale / gScaleBase
    ' Dim z As Double = NewScale / gScaleBase - 1

    ' ------------------------------------------------------------- PRE
    ' Dim dx As Double
    ' Dim dy As Double
    ' dx = (posx - gPosX) / oldzoom - posx + gMargin - gMinX * gScaleBase
    ' dy = (posy - gPosY) / oldzoom - posy - gMargin + gMinY * gScaleBase + gSizeY
    ' posx += dx
    ' posy += dy

    ' ------------------------------------------------------------- OK base
    ' NewPosX = -posx * z + gMargin * zoom - gMinX * NewScale
    ' NewPosY = -posy * z - gMargin * zoom + gMinY * NewScale + gSizeY * zoom

    ' ------------------------------------------------------------- POST
    ' NewPosX -= dx
    ' NewPosY -= dy

End Module
