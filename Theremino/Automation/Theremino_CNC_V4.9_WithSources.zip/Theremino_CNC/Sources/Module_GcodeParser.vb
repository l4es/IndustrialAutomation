﻿
Imports System.Collections.Generic

Module Module_GcodeParser

    Friend Enum Feed_Modes As Int32
        None
        Rapid
        Work
    End Enum

    Friend Enum Feed_Types As Int32
        Normal      ' G94
        InverseTime ' G93
    End Enum

    Friend Structure GCODE_PARAMS
        Dim Coord As Vec5
        Dim FeedMode As Feed_Modes
        Dim Feed As Double
        Dim FeedType As Feed_Types
        Dim Speed As Int32
        Dim SpindleCW As Int32
        Dim SpindleCCW As Int32
        Dim DwellTime As Single
        Dim ToolNumber As Int32
        Dim Cooling1 As Int32
        Dim Cooling2 As Int32
        Dim Cooling3 As Int32
        Dim Cooling4 As Int32
        Dim PalletClamp As Int32
        Dim SpindleOrientation As Single
        Dim GearSpeed As Int32
        Dim LastCMD As String
        Dim LastCMD_Params As String
        Dim UpdatedX As Boolean
        Dim UpdatedY As Boolean
        Dim UpdatedZ As Boolean
        Dim UpdatedA As Boolean
        Dim UpdatedB As Boolean
        ' ----------------------------------------------- single gcode line params and flags
        Dim cip As CircularInterpolationParams
        Dim UpdatedFeed As Boolean
        Dim UpdatedSpeed As Boolean
    End Structure

    Friend Structure CircularInterpolationParams
        Dim Valid As Boolean
        Dim DeltaX As Double
        Dim DeltaY As Double
        Dim DeltaZ As Double
        Dim Radius As Double
        Dim RadiusSpecified As Boolean
        Dim Center As Vec5
        Dim StartAngle As Double
        Dim EndAngle As Double
    End Structure

    Friend GcodeLines() As String = {"- - -"}
    Friend GCodeParsedLines(-1) As GCODE_PARAMS

    Friend GC_MaxCoord As Vec5
    Friend GC_MinCoord As Vec5
    Friend GC_InvalidCodes As String

    Friend GC_UsedZ As Boolean
    Friend GC_UsedA As Boolean
    Friend GC_UsedB As Boolean

    Friend GC_NameA As String
    Friend GC_NameB As String

    Friend Sub PARSER_ParseGcode(Optional ByVal TestInvalidGcodes As Boolean = False)
        'Dim sw As Stopwatch = New Stopwatch
        'sw.Start()
        ' --------------------------------------------------
        ReDim GCodeParsedLines(GcodeLines.Length - 1)
        ' -------------------------------------------------- init min and max
        GC_MinCoord.InitWithValue(Double.MaxValue)
        GC_MaxCoord.InitWithValue(Double.MinValue)
        GC_InvalidCodes = ""
        ' -------------------------------------------------- init gcode params
        Dim gcp As GCODE_PARAMS = New GCODE_PARAMS
        With gcp
            .LastCMD = ""
            .FeedMode = Feed_Modes.Rapid
            .Feed = 0
            ' ---------------------------
            .Coord.x = 0
            .Coord.y = 0
            .Coord.z = 0
            .Coord.a = 0
            .Coord.b = 0
            ' ---------------------------------------------- global flags - initiated only one time
            .UpdatedX = False
            .UpdatedY = False
            .UpdatedZ = False
            .UpdatedA = False
            .UpdatedB = False
        End With
        ' -------------------------------------------------- parse all lines
        For i As Int32 = 0 To GcodeLines.Length - 1
            ' ---------------------------------------------- limit single line commands to a single line
            Select Case gcp.LastCMD
                Case "TOOL", "PAUSE", "G04"
                    gcp.LastCMD = ""
            End Select
            ' ----------------------------------------------
            ReadGcodeLine(gcp, i)
            GCodeParsedLines(i) = gcp
            UpdateMinMax(gcp)
            ' ---------------------------------------------- fill final lines (after END) with the last params
            If gcp.LastCMD = "END" Then
                For j As Int32 = i To GcodeLines.Length - 1
                    GCodeParsedLines(j) = gcp
                Next
                Exit For
            End If
        Next
        ' -------------------------------------------------- reset not found axes to normal values
        If GC_MinCoord.x = Double.MaxValue Then GC_MinCoord.x = 0
        If GC_MaxCoord.x = Double.MinValue Then GC_MaxCoord.x = 0
        If GC_MinCoord.y = Double.MaxValue Then GC_MinCoord.y = 0
        If GC_MaxCoord.y = Double.MinValue Then GC_MaxCoord.y = 0
        If GC_MinCoord.z = Double.MaxValue Then GC_MinCoord.z = 0
        If GC_MaxCoord.z = Double.MinValue Then GC_MaxCoord.z = 0
        If GC_MinCoord.a = Double.MaxValue Then GC_MinCoord.a = 0
        If GC_MaxCoord.a = Double.MinValue Then GC_MaxCoord.a = 0
        If GC_MinCoord.b = Double.MaxValue Then GC_MinCoord.b = 0
        If GC_MaxCoord.b = Double.MinValue Then GC_MaxCoord.b = 0
        ' -------------------------------------------------- prepare Used and Updated flags
        GC_UsedZ = gcp.UpdatedZ
        GC_UsedA = gcp.UpdatedA
        GC_UsedB = gcp.UpdatedB
        With gcp
            .UpdatedX = False
            .UpdatedY = False
            .UpdatedZ = False
            .UpdatedA = False
            .UpdatedB = False
        End With
        ' -------------------------------------------------- fill initial lines with the first valid coords
        For i As Int32 = 0 To GcodeLines.Length - 1
            ReadGcodeLine(gcp, i)
            If gcp.UpdatedX And gcp.UpdatedY Then
                If Not GC_UsedZ Or gcp.UpdatedZ Then
                    If Not GC_UsedA Or gcp.UpdatedA Then
                        If Not GC_UsedB Or gcp.UpdatedB Then
                            For j As Int32 = 0 To i
                                With GCodeParsedLines(j)
                                    If Not .UpdatedX Then .Coord.x = gcp.Coord.x
                                    If Not .UpdatedY Then .Coord.y = gcp.Coord.y
                                    If Not .UpdatedZ Then .Coord.z = gcp.Coord.z
                                    If Not .UpdatedA Then .Coord.a = gcp.Coord.a
                                    If Not .UpdatedB Then .Coord.b = gcp.Coord.b
                                End With
                            Next
                            Exit For
                        End If
                    End If
                End If
            End If
        Next
        ' --------------------------------------------------
        'Form1.Text = sw.ElapsedMilliseconds.ToString
    End Sub

    Private Sub UpdateMinMax(ByVal gcp As GCODE_PARAMS)
        With gcp.Coord
            If gcp.UpdatedX Then
                If .x < GC_MinCoord.x Then GC_MinCoord.x = .x
                If .x > GC_MaxCoord.x Then GC_MaxCoord.x = .x
            End If
            If gcp.UpdatedY Then
                If .y < GC_MinCoord.y Then GC_MinCoord.y = .y
                If .y > GC_MaxCoord.y Then GC_MaxCoord.y = .y
            End If
            If gcp.UpdatedZ Then
                If .z < GC_MinCoord.z Then GC_MinCoord.z = .z
                If .z > GC_MaxCoord.z Then GC_MaxCoord.z = .z
            End If
            If gcp.UpdatedA Then
                If .a < GC_MinCoord.a Then GC_MinCoord.a = .a
                If .a > GC_MaxCoord.a Then GC_MaxCoord.a = .a
            End If
            If gcp.UpdatedB Then
                If .b < GC_MinCoord.b Then GC_MinCoord.b = .b
                If .b > GC_MaxCoord.b Then GC_MaxCoord.b = .b
            End If
        End With
    End Sub

    Private Sub ReadGcodeLine(ByRef gcp As GCODE_PARAMS, ByVal line As Int32)
        '
        ' -------------------------------------------------------------- single gcode line flags - initiated every line
        gcp.UpdatedFeed = False
        gcp.UpdatedSpeed = False
        ' -------------------------------------------------------------- single gcode line params
        Dim oldgcp As GCODE_PARAMS = gcp
        gcp.cip.DeltaX = 0
        gcp.cip.DeltaY = 0
        gcp.cip.DeltaZ = 0
        gcp.cip.Radius = 0
        gcp.cip.RadiusSpecified = False
        gcp.cip.Valid = False
        ' --------------------------------------------------------------
        Dim l As List(Of String) = SplitTokens(GcodeLines(line))
        For Each s As String In l
            If s.Length > 0 Then
                Select Case s.Substring(0, 1)
                    Case "(", "{", ";", ":", "%"
                        Exit For
                    Case "G"
                        Select Case s
                            Case "G0", "G00"
                                gcp.FeedMode = Feed_Modes.Rapid
                                gcp.LastCMD = "G00"
                            Case "G1", "G01"
                                gcp.FeedMode = Feed_Modes.Work
                                gcp.LastCMD = "G01"
                            Case "G2", "G02"                            ' Circular interpolation, clockwise
                                gcp.FeedMode = Feed_Modes.Work
                                gcp.LastCMD = "G02"
                                ' ----------------------- invalid code
                                'AddInvalidCode(s)
                            Case "G3", "G03"                            ' Circular interpolation, counterclockwise
                                gcp.FeedMode = Feed_Modes.Work
                                gcp.LastCMD = "G03"
                                ' ----------------------- invalid code
                                'AddInvalidCode(s)
                            Case "G4", "G04"                            ' dwell time from U(seconds) or P(millisec)
                                gcp.LastCMD = "G04"
                            Case "G5", "G05"
                                gcp.LastCMD = "PAUSE"
                            Case "G17", "G21", "G40", "G49", "G61", "G64", "G71", "G80", "G90", "G91.1"
                                ' ---- valid codes (nothing to do) ----
                                ' G17 = XY plane
                                ' G21 and G71 = millimeters mode
                                ' G40 = Cutter compensation off 
                                ' G49 = Tool length compensation cancel
                                ' G61 = Exact stop (manual in Theremino CNC)
                                ' G64 = Default cutting mode (cancels G61)
                                ' G80 = Cancel canned cycle
                                ' G90 = Absolute coordinate positioning
                                ' G91.1 = Normal incremental mode for I, J & K offsets
                            Case "G28"
                                gcp.FeedMode = Feed_Modes.Rapid
                                gcp.LastCMD = "HOME"
                            Case "G92"
                                gcp.LastCMD = "G92"
                                gcp.LastCMD_Params = ""
                                If l.Count = 2 Then
                                    If l(1).StartsWith("E") Then
                                        gcp.LastCMD_Params = l(1)
                                    Else
                                        AddInvalidCode("G92_" + l(1).Replace(" ", ""))
                                        gcp.LastCMD = ""
                                    End If
                                Else
                                    AddInvalidCode("G92")
                                    gcp.LastCMD = ""
                                End If
                            Case "G93"
                                gcp.FeedType = Feed_Types.InverseTime
                            Case "G94"
                                gcp.FeedType = Feed_Types.Normal
                            Case Else
                                gcp.FeedMode = Feed_Modes.None
                                ' ----------------------- invalid codes
                                AddInvalidCode(s)
                        End Select
                    Case "F"
                        ' --------------------------------------------- Normal Feed Mode (F = mm/min)
                        gcp.Feed = Val(Mid(s, 2))
                        gcp.UpdatedFeed = True
                    Case "S"
                        gcp.Speed = CInt(Val(Mid(s, 2)))
                        gcp.UpdatedSpeed = True
                    Case "X"
                        gcp.Coord.x = Val(Mid(s, 2))
                        gcp.UpdatedX = True
                    Case "Y"
                        gcp.Coord.y = Val(Mid(s, 2))
                        gcp.UpdatedY = True
                    Case "Z"
                        gcp.Coord.z = Val(Mid(s, 2))
                        gcp.UpdatedZ = True
                    Case "A"
                        gcp.Coord.a = Val(Mid(s, 2))
                        gcp.UpdatedA = True
                        GC_NameA = "A"
                    Case "B"
                        gcp.Coord.b = Val(Mid(s, 2))
                        gcp.UpdatedB = True
                        GC_NameB = "B"
                    Case "E"
                        gcp.Coord.a = Val(Mid(s, 2))
                        gcp.UpdatedA = True
                        GC_NameA = "E"
                    Case "U"
                        If gcp.LastCMD = "G04" Then
                            gcp.DwellTime = CSng(Val(Mid(s, 2)))  ' dwell time in seconds
                        Else
                            gcp.Coord.a = Val(Mid(s, 2))
                            gcp.UpdatedA = True
                            GC_NameA = "U"
                        End If
                    Case "V"
                        gcp.Coord.b = Val(Mid(s, 2))
                        gcp.UpdatedB = True
                        GC_NameB = "V"
                    Case "C"
                        'Axis C (rotation on Z axis) defines spindle orientation in degree
                        gcp.SpindleOrientation = CSng(Val(Mid(s, 2)))
                        Exit For
                    Case "I"
                        'Defines arc center in X axis for G02 or G03 arc commands
                        gcp.cip.DeltaX = Val(Mid(s, 2))
                    Case "J"
                        'Defines arc center in Y axis for G02 or G03 arc commands
                        gcp.cip.DeltaY = Val(Mid(s, 2))
                    Case "K"
                        'Defines arc center in Z axis for G02 or G03 arc commands
                        gcp.cip.DeltaZ = Val(Mid(s, 2))
                        AddInvalidCode(s)
                    Case "M"
                        Select Case s
                            Case "M0", "M1", "M00", "M01", "M31"
                                gcp.LastCMD = "PAUSE"
                                Exit For
                            Case "M2", "M02", "M30", "M99"
                                gcp.LastCMD = "END"
                                Exit For
                            Case "M3", "M03"
                                gcp.LastCMD = "SPINDLE_CW"
                                gcp.SpindleCW = 1000
                            Case "M4", "M04"
                                gcp.LastCMD = "SPINDLE_CCW"
                                gcp.SpindleCCW = 1000
                            Case "M5", "M05"
                                gcp.LastCMD = "SPINDLE_OFF"
                                gcp.SpindleCW = 0
                                gcp.SpindleCCW = 0
                            Case "M13"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling1 = 1000
                                gcp.SpindleCW = 1000
                            Case "M14"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling1 = 1000
                                gcp.SpindleCCW = 1000
                            Case "M06", "M6"
                                gcp.LastCMD = "TOOL"
                                'No ExitFor (waiting U or P param)
                            Case "M07", "M7"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling1 = 1000
                                Exit For
                            Case "M08", "M8"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling2 = 1000
                                Exit For
                            Case "M09", "M9"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling1 = 0
                                gcp.Cooling2 = 0
                                gcp.Cooling3 = 0
                                gcp.Cooling4 = 0
                                Exit For
                            Case "M10"
                                gcp.LastCMD = "PALLET_CLAMP"
                                gcp.PalletClamp = 1000
                                Exit For
                            Case "M11"
                                gcp.LastCMD = "PALLET_CLAMP"
                                gcp.PalletClamp = 0
                                Exit For
                            Case "M19"
                                gcp.LastCMD = "SPINDLE_ORIENTATION"
                                'No ExitFor (waiting C param)
                            Case "M41", "M42", "M43", "M44"
                                gcp.LastCMD = "GEAR_SPEED"
                                gcp.GearSpeed = CInt(Val(Mid(s, 2))) - 40
                                Exit For
                            Case "M50"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling3 = 1000
                                Exit For
                            Case "M51"
                                gcp.LastCMD = "COOLING"
                                gcp.Cooling4 = 1000
                                Exit For
                            Case "M84"
                                gcp.LastCMD = "DISABLE_ALL"
                                Exit For
                            Case "M106"
                                gcp.LastCMD = "FANS_ON"
                                Exit For
                            Case "M107"
                                gcp.LastCMD = "FANS_OFF"
                                Exit For
                            Case "M104"
                                If l.Count > 1 Then
                                    gcp.LastCMD = "EXTRUDER_TEMP"
                                    gcp.LastCMD_Params = Mid(l(1), 2)
                                End If
                                Exit For
                            Case "M109"
                                If l.Count > 1 Then
                                    gcp.LastCMD = "EXTRUDER_TEMP_WAIT"
                                    gcp.LastCMD_Params = Mid(l(1), 2)
                                End If
                                Exit For
                            Case "M141"
                                If l.Count > 1 Then
                                    gcp.LastCMD = "CHAMBER_TEMP"
                                    gcp.LastCMD_Params = Mid(l(1), 2)
                                End If
                                Exit For
                            Case "M140"
                                If l.Count > 1 Then
                                    gcp.LastCMD = "PRINT_BED_TEMP"
                                    gcp.LastCMD_Params = Mid(l(1), 2)
                                End If
                                Exit For
                            Case "M117"
                                gcp.LastCMD = "MESSAGE"
                                Exit For
                            Case "M82", "M105"
                                ' ---- valid codes (nothing to do) ----
                                '  M82 = Set extruder to absolute mode
                                ' M105 = Read the current temperature
                                Exit For
                            Case Else
                                ' ----------------------- invalid codes
                                AddInvalidCode(s)
                        End Select
                    Case "N"
                        ' line numbers
                    Case "O"
                        ' program name
                    Case "P"
                        ' dwell time in milliseconds
                        gcp.DwellTime = CSng(Val(Mid(s, 2)) / 1000)
                    Case "R"
                        'Defines size of arc radius for G02 or G03 arc commands
                        gcp.cip.Radius = Val(Mid(s, 2))
                        gcp.cip.RadiusSpecified = True
                    Case "T"
                        ' -------------------------------- tool change
                        gcp.ToolNumber = CInt(Val(Mid(s, 2)))
                    Case Else
                        ' -------------------------------- invalid codes
                        AddInvalidCode(s)
                End Select
            End If
        Next
        ' --------------------------------------------------------------------- CIP (Circular Interpolation Params)
        If gcp.LastCMD = "G02" Or gcp.LastCMD = "G03" Then
            With gcp.cip
                ' ------------------------------------------------------------- R is prevalent on I/J/K
                If .RadiusSpecified Then
                    CalcCenter(.Center.x, .Center.y, _
                                oldgcp.Coord.x, oldgcp.Coord.y, _
                                gcp.Coord.x, gcp.Coord.y, _
                                .Radius, gcp.LastCMD = "G02")
                    If Double.IsNaN(.Center.x) Or Double.IsNaN(.Center.y) Then
                        gcp.cip.Valid = False
                        Return
                    End If
                Else
                    .Center = gcp.Coord
                    .Center.x = oldgcp.Coord.x + .DeltaX
                    .Center.y = oldgcp.Coord.y + .DeltaY
                    .Radius = gcp.Coord.Subtract(.Center).Length
                End If
                ' ------------------------------------------------------------- calc StartAngle
                .StartAngle = Math.Atan2(oldgcp.Coord.y - .Center.y, _
                                         oldgcp.Coord.x - .Center.x)
                ' ------------------------------------------------------------- calc EndAngle
                .EndAngle = Math.Atan2(gcp.Coord.y - .Center.y, _
                                       gcp.Coord.x - .Center.x)
                ' ------------------------------------------------------------- 
                If gcp.LastCMD = "G02" Then
                    ' --------------------------------------------------------- correct for clockwise
                    If .StartAngle <= .EndAngle Then .StartAngle += Math.PI * 2
                Else
                    ' --------------------------------------------------------- correct for counterclockwise
                    If .StartAngle >= .EndAngle Then .EndAngle += Math.PI * 2
                End If
                ' ------------------------------------------------------------- eventually correct both angles 
                CorrectAngles_0_360_degree(.StartAngle, .EndAngle)
                ' ------------------------------------------------------------- set valid cip (Circular Interp Params)
                gcp.cip.Valid = True
            End With
        End If
        ' --------------------------------------------------------------------- Inverse Time Mode correction
        If gcp.FeedType = Feed_Types.InverseTime Then
            Dim dist As Double = gcp.Coord.Dist(oldgcp.Coord)
            If dist > 0 Then
                If gcp.UpdatedFeed Then
                    If gcp.Feed > 0 Then
                        ' ----------------------------------- F = 1 / move time in minutes (F=2 means 30sec per row)
                        ' ----------------------------------- Feed = multidimensional distance / (1 / Feed) 
                        ' ----------------------------------- So finally: Feed = distance * move time 
                        gcp.Feed *= dist
                    Else
                        AddInvalidCode(vbCr + "G93 error - Invalid Feed at line: " + (line + 1).ToString)
                    End If
                Else
                    AddInvalidCode(vbCr + "G93 error - Feed not specified at line: " + (line + 1).ToString)
                End If
            End If
        End If
    End Sub

    ' -----------------------------------------------------------------
    ' from http://mathforum.org/library/drmath/view/53027.html
    ' -----------------------------------------------------------------
    Private Sub CalcCenter(ByRef cx As Double, ByRef cy As Double, _
                           ByVal x1 As Double, ByVal y1 As Double, _
                           ByVal x2 As Double, ByVal y2 As Double, _
                           ByVal radius As Double, ByVal complementar As Boolean)

        Dim x3 As Double = (x1 + x2) / 2
        Dim y3 As Double = (y1 + y2) / 2

        Dim d As Double = Math.Sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)

        Dim dx As Double = Math.Sqrt(radius ^ 2 - (d / 2) ^ 2) * (y1 - y2) / d
        Dim dy As Double = Math.Sqrt(radius ^ 2 - (d / 2) ^ 2) * (x2 - x1) / d

        If complementar Then
            cx = x3 - dx
            cy = y3 - dy
        Else
            cx = x3 + dx
            cy = y3 + dy
        End If
    End Sub

    Private Sub CorrectAngles_0_360_degree(ByRef angle1 As Double, ByRef angle2 As Double)
        If angle1 < 0 Or angle2 < 0 Then
            angle1 += Math.PI * 2
            angle2 += Math.PI * 2
        End If
        If angle1 > 2 * Math.PI Or angle2 > 2 * Math.PI Then
            angle1 -= Math.PI * 2
            angle2 -= Math.PI * 2
        End If
    End Sub

    Friend Sub PARSER_TestInvalidCodes()
        If GC_InvalidCodes <> "" Then
            Dim s As String = ""
            If GC_InvalidCodes.Contains("G20 ") Or _
               GC_InvalidCodes.Contains("G70 ") Then
                s += "WARNING : " + vbCr + _
                     "Codes G20 and G70 stand for ""Inch"" coordinates." + vbCr + _
                     "Consider to use the command ""Convert to mm"" in the ""Tools"" menu" + vbCr + vbCr
            End If
            If GC_InvalidCodes.Contains("G2 ") Or _
               GC_InvalidCodes.Contains("G3 ") Or _
               GC_InvalidCodes.Contains("G02 ") Or _
               GC_InvalidCodes.Contains("G03 ") Then
                s += "WARNING : " + vbCr + _
                     "Codes G02, G03 are circular interpolations" + vbCr + _
                     "with an undefined number of segments." + vbCr + _
                     "Please set the CAM postprocessor to use G01 instead." + vbCr + vbCr
            End If
            If GC_InvalidCodes.Contains("G91 ") Then
                s += "WARNING : " + vbCr + _
                     "The code G91 means ""Relative mode""" + vbCr + _
                     "Please set the CAM postprocessor to use ""Absolute mode""." + vbCr + vbCr
            End If
            If GC_InvalidCodes.Contains("G98 ") Or _
               GC_InvalidCodes.Contains("G83 ") Then
                s += "WARNING : " + vbCr + _
                     "The codes G98 and G83 are for ""Drilling Cycles""" + vbCr + _
                     "Please set the CAM postprocessor to not use them." + vbCr + vbCr
            End If
            s += "Invalid codes: " + GC_InvalidCodes
            ' -------------------------------------------------------
            If s.Length > 900 Then
                s = Strings.Left(s, 900) + "..."
            End If
            ' -------------------------------------------------------
            Form_MsgBox.Message_OK(s, , , )
        End If
    End Sub

    Private Sub AddInvalidCode(ByVal s As String)
        If GC_InvalidCodes.Length > 999 Then Return
        If Not GC_InvalidCodes.Contains(s) Then
            GC_InvalidCodes += s + " "
        End If
    End Sub

    ' ---------------------------------------------------- test chars for GCode tokenizing
    Private testChars As String = "+-. 0123456789" & vbTab
    Private Function SplitTokens(ByVal l As String) As List(Of String)
        SplitTokens = New List(Of String)
        l = l.ToUpper
        l = l.Replace(",", ".")
        Dim i As Int32 = 1
        Dim j As Int32 = 2
        Do
            If j > l.Length OrElse Not testChars.Contains(Mid(l, j, 1)) Then
                SplitTokens.Add(Mid(l, i, j - i).Trim)
                If j > l.Length Then Exit Do
                i = j
                j = i + 1
            Else
                j += 1
            End If
        Loop
    End Function


    ' ============================================================================================
    '  Modify Gcode
    ' ============================================================================================
    Friend Sub PARSER_ModifyGcode(ByVal firstline As Int32, ByVal lastline As Int32, ByVal Operation As String)
        'Dim sw As Stopwatch = New Stopwatch
        'sw.Start()
        ' ----------------------------------------------------------------
        Dim sizeX As Double = GC_MaxCoord.x - GC_MinCoord.x
        Dim sizeY As Double = GC_MaxCoord.y - GC_MinCoord.y
        ' ----------------------------------------------------------------
        For i As Int32 = firstline To lastline
            ' ------------------------------------------------------------
            CompleteLineWithAllCoordinates(i, Operation)
            ' ------------------------------------------------------------
            Dim l As List(Of String) = SplitTokens(GcodeLines(i))
            Dim modified As Boolean = False
            Dim s As String = ""
            For Each token As String In l
                If token.Length > 0 Then
                    Select Case token.Substring(0, 1)
                        Case "(", ";", ":", "%"
                            ' ----------------------------------- restore comments to modified lines
                            If modified Then
                                s += GcodeLines(i).Substring(GcodeLines(i).IndexOf(token.Substring(0, 1)))
                            End If
                            Exit For
                        Case "F"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    If GCodeParsedLines(i).FeedType = Feed_Types.Normal Then
                                        ReplaceTokenValue(token, GCodeParsedLines(i).Feed * 25.4)
                                    End If
                            End Select
                        Case "X"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.x * 25.4)
                                Case "TRANSLATE_TO_ZERO_XY", "TRANSLATE_TO_ZERO_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.x - GC_MinCoord.x)
                                Case "ROTATE_LEFT_XY", "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, sizeY - GCodeParsedLines(i).Coord.y)
                                Case "ROTATE_RIGHT_XY", "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.y)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.x)
                            End Select
                            modified = True
                        Case "Y"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.y * 25.4)
                                Case "TRANSLATE_TO_ZERO_XY", "TRANSLATE_TO_ZERO_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.y - GC_MinCoord.y)
                                Case "ROTATE_LEFT_XY", "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.x)
                                Case "ROTATE_RIGHT_XY", "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, sizeX - GCodeParsedLines(i).Coord.x)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.y)
                            End Select
                            modified = True
                        Case "Z"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.z * 25.4)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.z)
                            End Select
                            modified = True
                        Case "A", "U"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.a * 25.4)
                                Case "TRANSLATE_TO_ZERO_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.a - GC_MinCoord.a)
                                Case "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, sizeY - GCodeParsedLines(i).Coord.b)
                                Case "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.b)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.a)
                            End Select
                            modified = True
                        Case "B", "V"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.b * 25.4)
                                Case "TRANSLATE_TO_ZERO_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.b - GC_MinCoord.b)
                                Case "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.a)
                                Case "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, sizeX - GCodeParsedLines(i).Coord.a)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).Coord.b)
                            End Select
                            modified = True
                        Case "I"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaX * 25.4)
                                Case "ROTATE_LEFT_XY", "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, -GCodeParsedLines(i).cip.DeltaY)
                                Case "ROTATE_RIGHT_XY", "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaY)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaX)
                            End Select
                            modified = True
                        Case "J"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaY * 25.4)
                                Case "ROTATE_LEFT_XY", "ROTATE_LEFT_XYAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaX)
                                Case "ROTATE_RIGHT_XY", "ROTATE_RIGHT_XYAB"
                                    ReplaceTokenValue(token, -GCodeParsedLines(i).cip.DeltaX)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaY)
                            End Select
                            modified = True
                        Case "K"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaZ * 25.4)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.DeltaZ)
                            End Select
                            modified = True
                        Case "R"
                            Select Case Operation
                                Case "CONVERT_TO_MM_XYZ", "CONVERT_TO_MM_XYZAB"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.Radius * 25.4)
                                Case "NORMALIZE"
                                    ReplaceTokenValue(token, GCodeParsedLines(i).cip.Radius)
                            End Select
                            modified = True
                        Case "N"
                            Select Case Operation
                                Case "NORMALIZE"
                                    token = ""
                            End Select
                            modified = True
                    End Select
                End If
                s += token + " "
            Next
            If modified Then
                GcodeLines(i) = s.TrimEnd
            End If
            If Operation = "NORMALIZE" Then
                GcodeLines(i) = GcodeLines(i).Trim
            End If
        Next
        ' ---------------------------------------------------------------- Correct MCUSTOCK and G20/G70 codes
        For i As Int32 = firstline To lastline
            If GcodeLines(i).StartsWith("(MCUSTOCK") Then
                Dim s As String = GcodeLines(i)
                Dim zpos As Int32 = s.ToUpper.IndexOf("Z"c)
                Dim zlen As Int32 = s.ToUpper.IndexOf(" "c, zpos) - zpos
                Dim z As String = s.Substring(zpos, zlen)
                If Operation.StartsWith("CONVERT_TO_MM") Then
                    GcodeLines(i) = "(MCUSTOCK " + "X" + (sizeX * 25.4).ToString("0.000 ", ci) _
                               + "Y" + (sizeY * 25.4).ToString("0.000 ", ci) _
                               + z + " OTL OX0 OY0 OZ0)"
                End If
                If Operation.StartsWith("ROTATE") Then
                    GcodeLines(i) = "(MCUSTOCK " + "X" + (-sizeY).ToString("0.000 ", ci) _
                               + "Y" + sizeX.ToString("0.000 ", ci) _
                               + z + " OTL OX0 OY0 OZ0)"
                End If
                Exit For
            End If
            If Operation.StartsWith("CONVERT_TO_MM") Then
                GcodeLines(i) = GcodeLines(i).Replace("G70", "G71")
                GcodeLines(i) = GcodeLines(i).Replace("G20", "G21")
            End If
        Next
        ' --------------------------------------------------
        'Form1.Text = sw.ElapsedMilliseconds.ToString
    End Sub

    Private fi As String = "0.000"
    Private ci As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture
    Private Sub ReplaceTokenValue(ByRef token As String, ByVal value As Double)
        token = Left(token, 1) + value.ToString(fi, ci)
        token = token.Replace("U", "A")
        token = token.Replace("u", "A")
        token = token.Replace("V", "B")
        token = token.Replace("v", "B")
    End Sub
 
    ' ============================================================================================
    '  ROTATIONS
    ' ============================================================================================
    ' -------------------------------------------------------------------
    '  To rotate correctly a Gcode each line that specifies a coordinate 
    '  must also specify the complementary coordinate 
    ' -------------------------------------------------------------------
    Private Sub CompleteLineWithAllCoordinates(ByVal i As Int32, ByVal operation As String)
        Select Case operation
            Case "ROTATE_LEFT_XY", "ROTATE_RIGHT_XY", "NORMALIZE"
                Dim s As String = StripComments(GcodeLines(i).ToUpper)
                ' -------------------------------------------------- only if there is a single coordinate
                If s.Contains("X") <> s.Contains("Y") Then
                    With GCodeParsedLines(i)
                        s = GetCommandPart(GcodeLines(i))
                        Complete_XYZ(i, s)
                        Complete_RIJ(i, s)
                    End With
                    GcodeLines(i) = s
                End If
            Case "ROTATE_LEFT_XYAB", "ROTATE_RIGHT_XYAB", "NORMALIZE"
                ' -------------------------------------------------- only if there is a single coordinate
                Dim s As String = StripComments(GcodeLines(i).ToUpper)
                If s.Contains("X") <> s.Contains("Y") Or s.Contains("A") <> s.Contains("B") Then
                    With GCodeParsedLines(i)
                        s = GetCommandPart(GcodeLines(i))
                        Complete_XYZ(i, s)
                        Complete_AB(i, s)
                        Complete_RIJ(i, s)
                    End With
                    GcodeLines(i) = s
                End If
        End Select
    End Sub

    Private Sub Complete_XYZ(ByVal i As Int32, ByRef s As String)
        With GCodeParsedLines(i)
            If .UpdatedX Then s += " X" + .Coord.x.ToString(fi, ci)
            If .UpdatedY Then s += " Y" + .Coord.y.ToString(fi, ci)
            If .UpdatedZ Then s += " Z" + .Coord.z.ToString(fi, ci)
        End With
    End Sub

    Private Sub Complete_AB(ByVal i As Int32, ByRef s As String)
        With GCodeParsedLines(i)
            If .UpdatedA Then s += " A" + .Coord.a.ToString(fi, ci)
            If .UpdatedB Then s += " B" + .Coord.b.ToString(fi, ci)
        End With
    End Sub

    Private Sub Complete_RIJ(ByVal i As Int32, ByRef s As String)
        With GCodeParsedLines(i)
            If .cip.Valid Then
                If .cip.RadiusSpecified Then
                    s += " R" + .cip.Radius.ToString(fi, ci)
                Else
                    s += " I" + .cip.DeltaX.ToString(fi, ci)
                    s += " J" + .cip.DeltaY.ToString(fi, ci)
                End If
            End If
        End With
    End Sub

    Private Sub AddFeedSpeed(ByVal i As Int32, ByRef s As String)
        With GCodeParsedLines(i)
            If .UpdatedFeed Then s += " F" + .Feed.ToString(fi, ci)
            If .UpdatedSpeed Then s += " S" + .Speed.ToString(fi, ci)
        End With
    End Sub

    Private Function StripComments(ByVal s As String) As String
        Dim i As Int32 = s.IndexOf("(")
        If i >= 0 Then
            s = s.Substring(0, i)
        End If
        Return s
    End Function

    Private Function GetCommandPart(ByVal s As String) As String
        Dim i1 As Int32 = s.IndexOf("X")
        Dim i2 As Int32 = s.IndexOf("Y")
        If i1 < 0 Then i1 = 99999
        If i2 < 0 Then i2 = 99999
        If i2 < i1 Then i1 = i2
        If i1 < 99999 Then
            s = s.Substring(0, i1)
        End If
        Return s
    End Function

End Module
