﻿Imports Microsoft.DirectX.DirectInput
Imports System.Math

' DirectX DLLs are to be added from GAC 2902 with SpecificVersion=True and CopyLocal=True
' Project/References/Add/Browse/
' C:\WINDOWS\assembly\GAC\Microsoft.DirectX\1.0.2902.0__31bf3856ad364e35\Microsoft.DirectX.dll
' C:\WINDOWS\assembly\GAC\Microsoft.DirectX.DirectInput\1.0.2902.0__31bf3856ad364e35\Microsoft.DirectX.DirectInput.dll

Module Module_Joystick

    Private DEV As Device
    Private JoyState As JoystickState
    Private buttons() As Byte
    Private pov As Int32
    Private dx As Single
    Private dy As Single
    Private dz As Single
    Private da As Single
    Private db As Single
    Private bH As Boolean
    Private bV As Boolean
    Private LowSpeed As Boolean
    Private Speed As Double
    Private PovEnabled As Boolean = True
    Private JoyCommand As String = ""
    Friend JOY_DeadZone As Int32 = 2
    Friend JOY_Inversions As String = "Type1"

    Friend Sub JOY_Open()
        JOY_Close()
        Dim gameControllerList As DeviceList
        gameControllerList = Manager.GetDevices(DeviceClass.GameControl, _
                                                EnumDevicesFlags.AttachedOnly)
        If gameControllerList.Count > 0 Then
            For Each devInstance As DeviceInstance In gameControllerList
                DEV = New Device(devInstance.InstanceGuid)
                'DEV.SetCooperativeLevel(Form1, _
                '                        CooperativeLevelFlags.Background Or _
                '                        CooperativeLevelFlags.NonExclusive)
                DEV.Properties.SetSaturation(ParameterHow.ByDevice, 0, 10000)
                DEV.Properties.SetDeadZone(ParameterHow.ByDevice, 0, 1000)
                DEV.SetDataFormat(DeviceDataFormat.Joystick)
                DEV.Acquire()
                Exit For
            Next
        End If
    End Sub

    Friend Sub JOY_TestPovInitialStatus()
        If DEV Is Nothing Then Return
        If Not ReadJoyState() Then Return
        pov = JoyState.GetPointOfView(0)
        If pov >= 0 Then
            CNC_DrawMessage("Found a Gamepad with POV always active." + vbCrLf + "POV buttons are disabled.")
            PovEnabled = False
        End If
    End Sub

    Friend Sub JOY_Close()
        If DEV IsNot Nothing Then
            DEV.Unacquire()
            DEV = Nothing
        End If
    End Sub

    Friend Sub JOY_TimedExecution()
        ' ------------------------------------------------------------
        If DEV Is Nothing Then Return
        If Not ReadJoyState() Then Return
        ' ------------------------------------------------------------ Buttons
        buttons = JoyState.GetButtons
        pov = JoyState.GetPointOfView(0)
        If buttons(0) <> 0 Then
            If JoyCommand = "" Then
                If Form1.btn_InOutEnabled.Enabled Then
                    JoyCommand = "ToggleInOut"
                    Form1.btn_InOutEnabled.Checked = Not Form1.btn_InOutEnabled.Checked
                    Form1.btn_InOutEnabled_CheckedChanged()
                    CNC_SetMainEnableOutput(CNC_InOutEnabled)
                    SKIN_UpdateButtons_Form1()
                    Form1.CalibrationButtons_Enable()
                    JoyCommand = "Executed"
                End If
            End If
        ElseIf buttons(1) <> 0 Then
            If JoyCommand = "" Then
                JoyCommand = "Start"
                Form1.StartRunningState()
                SKIN_UpdateButtons_Form1()
                JoyCommand = "Executed"
            End If
        ElseIf buttons(2) <> 0 Then
            If JoyCommand = "" Then
                JoyCommand = "Stop"
                Form1.StopRunningState("Gamepad stop")
                SKIN_UpdateButtons_Form1()
                JoyCommand = "Executed"
            End If
        ElseIf buttons(3) <> 0 Then
            If JoyCommand = "" Then
                JoyCommand = "Rewind"
                Form1.RewindGcode()
                SKIN_UpdateButtons_Form1()
                JoyCommand = "Executed"
            End If
        ElseIf buttons(8) <> 0 Then
            If JoyCommand = "" Then
                JoyCommand = "DeadBand"
                Select Case JOY_DeadZone
                    Case 0 : JOY_DeadZone = 1
                    Case 1 : JOY_DeadZone = 2
                    Case 2 : JOY_DeadZone = 5
                    Case 5 : JOY_DeadZone = 10
                    Case 10 : JOY_DeadZone = 20
                        'Case 20 : JOY_DeadZone = 50
                        'Case 50 : JOY_DeadZone = 100
                    Case Else : JOY_DeadZone = 0
                End Select
                DEV.Properties.SetDeadZone(ParameterHow.ByDevice, 0, JOY_DeadZone * 100)
                CNC_DrawMessage("New dead zone for the Gamepad Sticks = " + _
                                                    JOY_DeadZone.ToString + "%")
                JoyCommand = "Executed"
            End If
        ElseIf buttons(9) <> 0 Then
            If JoyCommand = "" Then
                JoyCommand = "AxisInversions"
                Select Case JOY_Inversions
                    Case "Type1"
                        JOY_Inversions = "Type2"
                        CNC_DrawMessage("New inversion for the gamepad sticks = Type2" + _
                                        vbCrLf + vbCrLf + _
                                        "For Saitek P2900 and similar" + vbCrLf + _
                                        "  Left stick: Normal" + vbCrLf + _
                                        "  Right stick: HV exchanged")
                    Case "Type2"
                        JOY_Inversions = "Type3"
                        CNC_DrawMessage("New inversion for the gamepad sticks = Type3" + _
                                        vbCrLf + vbCrLf + _
                                        "For RC controllers" + vbCrLf + _
                                        "  Left stick: H inverted" + vbCrLf + _
                                        "  Right stick: HV exchanged + V inverted")
                    Case Else
                        JOY_Inversions = "Type1"
                        CNC_DrawMessage("New inversion for the gamepad sticks = Type1" + _
                                        vbCrLf + vbCrLf + _
                                        "For normal GamePads")
                End Select
               
                JoyCommand = "Executed"
            End If
        ElseIf buttons(4) <> 0 AndAlso buttons(5) <> 0 _
                               AndAlso buttons(6) <> 0 _
                               AndAlso buttons(7) <> 0 Then
            If JoyCommand = "" Then
                If Not CNC_GcodeRunning And Not Form1.btn_GcodePause.Checked Then
                    JoyCommand = "Goto home"
                    Form1.CNC_GotoHome()
                    JoyCommand = "Executed"
                End If
            End If
        ElseIf pov = 4500 Or pov = 0 Or pov = 31500 Then
            If JoyCommand = "" AndAlso PovEnabled Then
                JoyCommand = "Zoom+"
                GraphicThread_SetZoomAndPosition(1.1, -1, -1)
                JoyCommand = ""
            End If
        ElseIf pov = 13500 Or pov = 18000 Or pov = 22500 Then
            If JoyCommand = "" AndAlso PovEnabled Then
                JoyCommand = "Zoom-"
                GraphicThread_SetZoomAndPosition(0.9, -1, -1)
                JoyCommand = ""
            End If
        Else
            If JoyCommand = "Executed" Then JoyCommand = ""
        End If
        If CNC_GcodeRunning Or Form1.btn_GcodePause.Checked Then Return
        ' ------------------------------------------------------------ Hor/Vert and Speed
        bH = False
        bV = False
        LowSpeed = False
        If buttons(4) <> 0 Then bH = True
        If buttons(5) <> 0 Then bH = True : LowSpeed = True
        If buttons(6) <> 0 Then bV = True
        If buttons(7) <> 0 Then bV = True : LowSpeed = True
        ' ------------------------------------------------------------ Sticks
        dx = 0
        dy = 0
        dz = 0
        da = 0
        db = 0
        Select Case JOY_Inversions
            Case "Type2"  ' Saitek P2900 (Right: HV exchanged)
                If bH Then dx = NormalizeStickValue(JoyState.X)
                If bV Then dy = -NormalizeStickValue(JoyState.Y)
                If bV Then dz = -NormalizeStickValue(JoyState.Z)
                If GC_UsedA Then
                    If bH Then da = NormalizeStickValue(JoyState.Rz)
                End If
            Case "Type3"  ' RC controller (Left: H inverted / Right: HV exch. + V inv.)
                If bH Then dx = -NormalizeStickValue(JoyState.X)
                If bV Then dy = -NormalizeStickValue(JoyState.Y)
                If bV Then dz = NormalizeStickValue(JoyState.Z)
                If GC_UsedA Then
                    If bH Then da = NormalizeStickValue(JoyState.Rz)
                End If
            Case Else
                If bH Then dx = NormalizeStickValue(JoyState.X)
                If bV Then dy = -NormalizeStickValue(JoyState.Y)
                If bV Then dz = -NormalizeStickValue(JoyState.Rz)
                If GC_UsedA Then
                    If bH Then da = NormalizeStickValue(JoyState.Z)
                End If
        End Select
        ' ------------------------------------------------------------ Using B in place of Z
        If Not GC_UsedZ AndAlso (GC_UsedA And GC_UsedB) Then
            db = dz
            dz = 0
        End If
        ' ------------------------------------------------------------ Execution
        If LowSpeed Then
            Speed = 6 / (1000 / 5) / 60 ' 6 mm/min = 0.1 mm/sec
        Else
            Speed = CNC_Rapid / (1000 / 5) / 60
        End If
        ' ------------------------------------------------------------ Enable movements
        If dx <> 0 Or dy <> 0 Or dz <> 0 Or da <> 0 Or db <> 0 Then
            Form1.CNC_EnableTimedUpdateAndUserInterface()
            Form1.ActivateTest_ForRedrawAfterStop()
        End If
        ' ------------------------------------------------------------ Debug
        'Static odx, ody, odz, oda, odb As Single
        'Static obh, obv As Boolean
        'If dx <> odx Or dy <> ody Or dz <> odz Or da <> oda Or db <> odb _
        '                                       Or bH <> obh Or bV <> obv Then
        '    odx = dx : ody = dy : odz = dz : oda = da : odb = db : obh = bH : obv = bV
        '    DebugWindow_SetText("")
        '    DebugWindow_AppendText("dx", dx.ToString("0.000"))
        '    DebugWindow_AppendText("dy", dy.ToString("0.000"))
        '    DebugWindow_AppendText("dz", dz.ToString("0.000"))
        '    DebugWindow_AppendText("da", da.ToString("0.000"))
        '    DebugWindow_AppendText("db", db.ToString("0.000"))
        '    DebugWindow_AppendText("bh", bH.ToString())
        '    DebugWindow_AppendText("bv", bV.ToString())
        '    DebugWindow_Show()
        'End If
    End Sub

    Friend Sub Joy_ExecMovements()
        If dx <> 0 Then CNC_Dest.x += dx * Speed
        If dy <> 0 Then CNC_Dest.y += dy * Speed
        If dz <> 0 Then CNC_Dest.z += dz * Speed
        If da <> 0 Then CNC_Dest.a += da * Speed
        If db <> 0 Then CNC_Dest.b += db * Speed
    End Sub

    Private Function ReadJoyState() As Boolean
        Try
            JoyState = DEV.CurrentJoystickState
            Return True
        Catch
            JOY_Close()
            Return False
        End Try
    End Function

    Private Function NormalizeStickValue(ByVal n As Single) As Single
        n -= 32767
        If n < 300 And n > -300 Then Return 0
        n /= 32767.0F
        If n < -1 Then n = -1
        If n > 1 Then n = 1
        ' ----------------------------------------- cubical response
        n = n * n * n
        ' ----------------------------------------- quadratical response
        'n = CSng(Sign(n) * n * n)
        Return n
    End Function


    ' ------------------------------------------------------------ Pov
    'If da = 0 Then da = NormalizePovValue_H(JoyState.GetPointOfView(0))
    'If db = 0 Then db = NormalizePovValue_V(JoyState.GetPointOfView(0))
    ' ------------------------------------------------------------ Trimmers
    'If da = 0 Then da = NormalizeStickValue(JoyState.Rx)
    'If db = 0 then db = NormalizeStickValue(JoyState.Ry)

    'Private Function NormalizePovValue_V(ByVal n As Int32) As Single
    '    Select Case n
    '        Case 0, 4500, 31500 : Return 1
    '        Case 13500, 18000, 22500 : Return -1
    '    End Select
    '    Return 0
    'End Function

    'Private Function NormalizePovValue_H(ByVal n As Int32) As Single
    '    Select Case n
    '        Case 4500, 9000, 13500 : Return 1
    '        Case 22500, 27000, 31500 : Return -1
    '    End Select
    '    Return 0
    'End Function


    ' Control               Meaning     Array position
    ' -------------------------------------------------
    ' Left Stick            X, Y
    ' Right Stick           Z, Rz
    ' Trimmers              Rx, Ry
    ' POV Buttons           Pov
    ' Button 1              Btn 1       0
    ' Button 2              Btn 2       1
    ' Button 3              Btn 3       2
    ' Button 4              Btn 4       3
    ' Left bumper bottom    Btn 5       4
    ' Right bumper bottom   Btn 6       5
    ' Left bumper top       Btn 7       6
    ' Right bumper top      Btn 8       7
    ' Button "Select"       Btn 9       8
    ' Button "Start"        Btn 10      9
    ' Left stick button     Btn 11      10
    ' Light stick button    Btn 12      11

End Module
