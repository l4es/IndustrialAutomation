﻿
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False
    Friend StartupSplitterPosition As Int32 = 500
    Friend StartupWindowState As FormWindowState = FormWindowState.Normal

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   Files
    ' =======================================================================================================
    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function
    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function
    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function
    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function
    Public Function GetPath(ByVal str As String) As String
        Try
            Return IO.Path.GetDirectoryName(str) & "\"
        Catch
            Return str
        End Try
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
    End Sub

    Friend Sub LimitFormPosition_CompletelyVisible(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
            .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
            .Width = Math.Max(.Width, 32)               ' at least 32x24
            .Height = Math.Max(.Height, 24)             ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
            .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
            .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
            .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
        End With
    End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function



    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Friend Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = s.Trim
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    'Friend Sub SaveConfigurationAs()
    '    Dim sfd As SaveFileDialog = New SaveFileDialog()
    '    sfd.DefaultExt = ".txt"
    '    sfd.Filter = "Configuration file (*.txt)|*txt"
    '    'sfd.FileName = AssemblyName() & "_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
    '    sfd.FileName = "ARM_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
    '    If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
    '        Save_INI(sfd.FileName)
    '    End If
    'End Sub

    'Friend Sub LoadConfiguration()
    '    Dim ofd As OpenFileDialog = New OpenFileDialog
    '    ofd.Filter = "Configuration file (*.txt)|*txt"
    '    If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
    '        Load_INI(ofd.FileName)
    '    End If
    'End Sub

    Friend Sub Save_INI()
        If CNC_InOutEnabled Then CNC_HardwareTip = CNC_Tip

        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            f.WriteLine(TabString("Form1_SplitterPosition", Form1.PanelSplitter.Left))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Menu"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("ControlTemperatures", Form1.Menu_ControlTemperatures.Checked))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Colors and Views"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("SelectedSkin", SelectedSkinName))
            f.WriteLine(TabString("ViewType", ViewType))
            f.WriteLine(TabString("ZoomFactor", Form1.RTB.ZoomFactor.ToString("0.00", Globalization.CultureInfo.InvariantCulture)))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Gcode"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("GcodeFile", GcodeFile_PathAndName))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Work params"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("InOutEnabled", Form1.btn_InOutEnabled.Checked))
            f.WriteLine(TabString("HalEnabled", Form1.btn_HalEnabled.Checked))
            f.WriteLine(TabString("ToolStop", Form1.btn_ToolStop.Checked))
            f.WriteLine(TabString("Rapid", Form1.txt_Rapid.NumericValueInteger))
            f.WriteLine(TabString("Feed", Form1.txt_Feed.NumericValueInteger))
            f.WriteLine(TabString("Speed", Form1.txt_Speed.NumericValueInteger))
            f.WriteLine(TabString("FeedSpeedLocked", CNC_FeedSpeedLockedType))
            f.WriteLine(TabString("LookAhead", CNC_LookAheadType))
            f.WriteLine(TabString("TestLowZ", Form1.btn_TestLowZ.Checked))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Movements"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("MaxError", Form1.txt_MaxError.NumericValue, "0.000"))
            f.WriteLine(TabString("CtrlJog", Form1.txt_CtrlJog.NumericValue, "0.00"))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Options"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("FirstSlot", Form_Options.txt_FirstSlot.NumericValueInteger))
            f.WriteLine(TabString("JogSpeedShift", Form_Options.txt_JogSpeedShift.NumericValueInteger))
            f.WriteLine(TabString("JogSpeedNormal", Form_Options.txt_JogSpeedNormal.NumericValueInteger))
            f.WriteLine(TabString("SpindleDelay", Form_Options.txt_SpindleDelay.NumericValue))
            f.WriteLine(TabString("ShowRealTipPosition", Form_Options.btn_ShowRealTipPosition.Checked))
            f.WriteLine(TabString("CompensateAcceleration", Form_Options.btn_CompensateAcceleration.Checked))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" TipPositions"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("TipX", CNC_HardwareTip.x))
            f.WriteLine(TabString("TipY", CNC_HardwareTip.y))
            f.WriteLine(TabString("TipZ", CNC_HardwareTip.z))
            f.WriteLine(TabString("TipA", CNC_HardwareTip.a))
            f.WriteLine(TabString("TipB", CNC_HardwareTip.b))
            f.WriteLine(TabString("HomeZ", CNC_HardwareHome_Z))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Calibrations"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("CalXyabSearchSpeed", Form_Calibrations.txt_CalXyabSearchSpeed.NumericValueInteger))
            f.WriteLine(TabString("CalXyabReturnSpeed", Form_Calibrations.txt_CalXyabReturnSpeed.NumericValueInteger))
            f.WriteLine(TabString("CalXyabMaxTravel", Form_Calibrations.txt_CalXyabMaxTravel.NumericValueInteger))
            f.WriteLine(TabString("CalXyabCompensation", Form_Calibrations.txt_CalXyabCompensation.NumericValue, "0.00"))
            f.WriteLine(TabString("CalZSearchSpeed", Form_Calibrations.txt_CalZSearchSpeed.NumericValueInteger))
            f.WriteLine(TabString("CalZReturnSpeed", Form_Calibrations.txt_CalZReturnSpeed.NumericValueInteger))
            f.WriteLine(TabString("CalZMaxTravel", Form_Calibrations.txt_CalZMaxTravel.NumericValueInteger))
            f.WriteLine(TabString("CalZCompensation", Form_Calibrations.txt_CalZCompensation.NumericValue, "0.00"))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Joystick"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("JOY_DeadZone", JOY_DeadZone))
            f.WriteLine(TabString("JOY_Inversions", JOY_Inversions))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub

    Friend Sub Load_INI()
        ' ------------------------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")

        If My.Computer.FileSystem.FileExists(iniFileName) Then

            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = Val_Int(l)
                    Case "Form1_Left" : Form1.Left = Val_Int(l)
                    Case "Form1_Width" : Form1.Width = Val_Int(l)
                    Case "Form1_Height" : Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : StartupWindowState = CType((Val(l)), FormWindowState)
                    Case "Form1_SplitterPosition" : StartupSplitterPosition = Val_Int(l)
                    Case "ZoomFactor" : Form1.SetZoomFactor(Val_Single(l))
                        ' --------------------------------------------------------------- Menu
                    Case "ControlTemperatures" : Form1.Menu_ControlTemperatures.Checked = l = "True"
                        ' --------------------------------------------------------------- Skin and Views
                    Case "SelectedSkin" : SelectedSkinName = l
                    Case "ViewType" : ViewType = CType(l, ViewTypes)
                        ' --------------------------------------------------------------- Gcode
                    Case "GcodeFile" : GcodeFile_PathAndName = l
                        ' --------------------------------------------------------------- Work params
                    Case "InOutEnabled" : Form1.btn_InOutEnabled.Checked = l = "True"
                    Case "HalEnabled" : Form1.btn_HalEnabled.Checked = l = "True"
                    Case "ToolStop" : Form1.btn_ToolStop.Checked = l = "True"
                    Case "Rapid" : Form1.txt_Rapid.NumericValueInteger = Val_Int(l)
                    Case "Feed" : Form1.txt_Feed.NumericValueInteger = Val_Int(l)
                    Case "Speed" : Form1.txt_Speed.NumericValueInteger = Val_Int(l)
                    Case "FeedSpeedLocked" : CNC_FeedSpeedLockedType = CType(Val(l), CNC_FeedSpeedLockedTypes)
                    Case "LookAhead" : CNC_LookAheadType = CType(Val(l), CNC_LookAheadTypes)
                    Case "TestLowZ" : Form1.btn_TestLowZ.Checked = l = "True"
                        ' --------------------------------------------------------------- Movements
                    Case "MaxError" : Form1.txt_MaxError.NumericValue = Val_Double(l)
                    Case "CtrlJog" : Form1.txt_CtrlJog.NumericValue = Val_Double(l)
                        ' --------------------------------------------------------------- Options
                    Case "FirstSlot" : Form_Options.txt_FirstSlot.NumericValueInteger = Val_Int(l)
                    Case "JogSpeedShift" : Form_Options.txt_JogSpeedShift.NumericValueInteger = Val_Int(l)
                    Case "JogSpeedNormal" : Form_Options.txt_JogSpeedNormal.NumericValueInteger = Val_Int(l)
                    Case "SpindleDelay" : Form_Options.txt_SpindleDelay.NumericValue = Val_Double(l)
                    Case "ShowRealTipPosition" : Form_Options.btn_ShowRealTipPosition.Checked = l = "True"
                    Case "CompensateAcceleration" : Form_Options.btn_CompensateAcceleration.Checked = l = "True"
                        ' --------------------------------------------------------------- TipPosition
                    Case "TipX" : CNC_HardwareTip.x = Val_Double(l)
                    Case "TipY" : CNC_HardwareTip.y = Val_Double(l)
                    Case "TipZ" : CNC_HardwareTip.z = Val_Double(l)
                    Case "TipA" : CNC_HardwareTip.a = Val_Double(l)
                    Case "TipB" : CNC_HardwareTip.b = Val_Double(l)
                    Case "HomeZ" : CNC_HardwareHome_Z = Val_Double(l)
                        ' --------------------------------------------------------------- Calibrations
                    Case "CalXyabSearchSpeed" : Form_Calibrations.txt_CalXyabSearchSpeed.NumericValueInteger = Val_Int(l)
                    Case "CalXyabReturnSpeed" : Form_Calibrations.txt_CalXyabReturnSpeed.NumericValueInteger = Val_Int(l)
                    Case "CalXyabMaxTravel" : Form_Calibrations.txt_CalXyabMaxTravel.NumericValueInteger = Val_Int(l)
                    Case "CalXyabCompensation" : Form_Calibrations.txt_CalXyabCompensation.NumericValue = Val_Single(l)
                    Case "CalZSearchSpeed" : Form_Calibrations.txt_CalZSearchSpeed.NumericValueInteger = Val_Int(l)
                    Case "CalZReturnSpeed" : Form_Calibrations.txt_CalZReturnSpeed.NumericValueInteger = Val_Int(l)
                    Case "CalZMaxTravel" : Form_Calibrations.txt_CalZMaxTravel.NumericValueInteger = Val_Int(l)
                    Case "CalZCompensation" : Form_Calibrations.txt_CalZCompensation.NumericValue = Val_Single(l)
                        ' --------------------------------------------------------------- Joystick
                    Case "JOY_DeadZone" : JOY_DeadZone = Val_Int(l)
                    Case "JOY_Inversions" : JOY_Inversions = l
                End Select
            Loop
            f.Close()
        End If
        If Form1.btn_InOutEnabled.Checked Then
            CNC_Tip = CNC_HardwareTip
            CNC_Home_Z = CNC_HardwareHome_Z
        End If
        LimitFormPosition(Form1)
    End Sub


    ' ==================================================================================================
    '  SAVE LOAD -- GCODE
    ' ==================================================================================================
    Friend GcodeFile_PathAndName As String = ""
    Friend GcodeModified As Boolean = False

    Friend Sub SaveGcode_IfChanged()
        If GcodeModified Then
            SaveGcode(GcodeFile_PathAndName)
        End If
    End Sub

    Friend Sub SaveGcode(Optional ByVal fileName As String = "")
        If fileName = "" Then
            SaveGcodeDialog()
            Return
        End If
        Try
            Form1.RTB.SaveFile(fileName, RichTextBoxStreamType.PlainText)
            GcodeFile_PathAndName = fileName
            Form1.ShowGcodeName()
            Form1.SetGcodeModifiedFlag(False)
        Catch
        End Try
    End Sub


    ' ================================================================================
    '  LOAD GCODE ALSO OUTSIDE GCODE FOLDER
    ' ================================================================================
    Friend Sub LoadGcode(Optional ByVal fileName As String = "", Optional ByVal TestInvalidCodes As Boolean = False)
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        'If fileName = "" Then fileName = GcodeFile_PathAndName
        GcodeFile_PathAndName = fileName
        ' -------------------------------------------------------------------------------
        If Not FileExists(GcodeFile_PathAndName) Then
            GcodeFile_PathAndName = FindFileInGcodeFolders(GcodeFile_PathAndName)
        End If
        ' -----------------------------------------------------------
        Form1.Pic_Toolpath.Enabled = False
        SetCursor_Hourglass()
        ' -------------------------------------------------------------------------------
        If FileExists(GcodeFile_PathAndName) Then
            Dim allfile As String = IO.File.ReadAllText(GcodeFile_PathAndName)
            allfile = allfile.Replace(vbCr + vbCr, vbCr)
            allfile = allfile.Replace(vbCrLf, vbCr)
            GcodeLines = Split(allfile, vbCr)
        Else
            GcodeLines = New String() {" "}
        End If
        ' ---------------------------------------------------------------------------
        Form1.RTB.Lines = GcodeLines
        Form1.SetGcodeModifiedFlag(False)
        CNC_LineInExecution = 0
        CNC_LineToBeExecuted = 0
        CNC_Dest = CNC_Tip
        GraphicThread_InitToolPathImageAndGraphics()
        PARSER_ParseGcode(TestInvalidCodes)
        GraphicThread_DrawToolpathImage(True)
        Form1.ShowGcodeLine()
        Form1.ShowGcodeTotalLines()
        Form1.ShowGcodeTotalTime()
        Form1.EnableCoordinates()
        Form1.CalibrationButtons_Enable()
        Form1.ShowGcodeName()
        Form1.ResetGcodeTime()
        SetCursor_Default()
        Form1.Pic_Toolpath.Enabled = True
    End Sub

    'Private Function FileIsInGcodeFolder(ByVal filename As String) As Boolean
    '    If filename.StartsWith(Windows.Forms.Application.StartupPath + "\GCodes", StringComparison.InvariantCultureIgnoreCase) Then
    '        Return True
    '    Else
    '        Return False
    '    End If
    'End Function

    Private Function FindFileInGcodeFolders(ByVal PathAndName As String) As String
        Dim name As String = IO.Path.GetFileName(PathAndName)
        If name = "" Then Return ""
        Dim FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim wildcards() As String = {"*.gc", "*.nc", "*.ncc", "*.dnc", "*.tap", "*.iso", "*.txt"}
        Dim s As String = Application.StartupPath & "\GCodes\"
        FileNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchAllSubDirectories, wildcards)
        For Each str As String In FileNames
            If str.EndsWith(name) Then
                Return str
            End If
        Next
        Return ""
    End Function

    Private Function PrepareSaveLoadFolder() As String
        PrepareSaveLoadFolder = ""
        If My.Computer.FileSystem.FileExists(GcodeFile_PathAndName) Then
            PrepareSaveLoadFolder = GetPath(GcodeFile_PathAndName)
        End If
        If Not FolderExists(PrepareSaveLoadFolder) Then
            PrepareSaveLoadFolder = Windows.Forms.Application.StartupPath & "\GCodes"
        End If
        PrepareSaveLoadFolder = PlatformAdjustedFileName(PrepareSaveLoadFolder)
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- PROGRAMS -- DIALOGS
    ' ==================================================================================================
    Friend Sub SaveGcodeDialog()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.InitialDirectory = PrepareSaveLoadFolder()
        ' ------------------------------------------------------------
        sfd.FileName = IO.Path.GetFileName(GcodeFile_PathAndName)
        sfd.DefaultExt = ".txt"
        ' ------------------------------------------------------------ better dialog
        sfd.ShowHelp = True
        ' ------------------------------------------------------------
        'SFD.RestoreDirectory = False
        sfd.AutoUpgradeEnabled = True
        sfd.Title = "Save script file"
        sfd.ValidateNames = False
        sfd.AddExtension = True
        sfd.Filter = "All files (*.*)|*.*"
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            ' ---------------------------------------------------------
            '  When using old dialogs with "ofd.ShowHelp" 
            '  this eliminates the "invalid chars in path" error
            ' ---------------------------------------------------------
            Try
                SaveGcode(sfd.FileName)
            Catch
            End Try
        End If
    End Sub

    Friend Sub LoadGcodeDialog()
        If Not TestGcodeModified() Then
            Return
        End If
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ofd.InitialDirectory = PrepareSaveLoadFolder()
        ' ------------------------------------------------------------ left part of filename not visible
        ofd.FileName = IO.Path.GetFileName(GcodeFile_PathAndName)
        ofd.DefaultExt = ".txt"
        ' ------------------------------------------------------------ filename completely visible but no extension
        'ofd.FileName = IO.Path.GetFileNameWithoutExtension(GcodeFile_PathAndName)
        'ofd.DefaultExt = IO.Path.GetExtension(GcodeFile_PathAndName)
        ' ------------------------------------------------------------ filename completely visible and better dialog
        ofd.ShowHelp = True
        ' ------------------------------------------------------------
        'ofd.RestoreDirectory = True
        ofd.AutoUpgradeEnabled = True
        ofd.Title = "Load program file"
        ofd.ValidateNames = False
        ofd.Multiselect = True
        ofd.Filter = "All files (*.*)|*.*"
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Form1.RefreshForm_OnlyForXP()
            EventsAreEnabled = False
            ' ---------------------------------------------------------
            '  When using old dialogs with "ofd.ShowHelp" 
            '  this detects and corrects "invalid chars in path" 
            ' ---------------------------------------------------------
            Try
                ofd.FileName = ofd.FileName
            Catch
                ofd.FileName = ""
            End Try
            ' ---------------------------------------------------------
            LoadGcode(ofd.FileName, True)
            Save_INI()
            EventsAreEnabled = True
            ' ---------------------------------------------------- test invalid codes
            PARSER_TestInvalidCodes()
        End If
    End Sub

    Friend Function TestGcodeModified() As Boolean
        While GcodeModified
            Select Case Form_MsgBox.Message_YesNoCancel("Gcode modified. Save it?", ContentAlignment.MiddleLeft)
                Case "YES"
                    SaveGcode_IfChanged()
                Case "NO"
                    Form1.SetGcodeModifiedFlag(False)
                    Return True
                Case Else
                    Return False
            End Select
        End While
        Return True
    End Function


    ' ==================================================================================================
    '  SAVE IMAGE
    ' ==================================================================================================
    Public Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)

        extension = LCase(extension)
        filename = RemoveExtension(filename)
        filename += "." & extension
        '
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, Quality)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub
    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function
    Friend Sub File_Kill(ByVal filename As String)
        If My.Computer.FileSystem.FileExists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
        End If
    End Sub
    Friend Sub SaveImage(ByVal cnt As Control)
        Dim img As Image = GetImage(cnt)
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.Filter = "Portable network graphics (*.png)|*png|JPEG image (*.jpg)|*.jpg"
        sfd.FileName = IO.Path.GetFileNameWithoutExtension(GcodeFile_PathAndName)
        sfd.InitialDirectory = Application.StartupPath + "\Images"
        sfd.ShowHelp = True
        sfd.Title = "Save Toolpath Image"
        sfd.ValidateNames = False
        ' ------------------------------------------------------------
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            SaveImage(img, sfd.FileName, If(sfd.FilterIndex = 2, "jpg", "png"), 100)
        End If
    End Sub
    Friend Function GetImage(ByVal cnt As Control) As Bitmap
        Dim s As Size = cnt.Size
        Dim bmp As Bitmap = New Bitmap(s.Width, s.Height)
        cnt.DrawToBitmap(bmp, New Rectangle(0, 0, s.Width, s.Height))
        Return bmp
    End Function


End Module
