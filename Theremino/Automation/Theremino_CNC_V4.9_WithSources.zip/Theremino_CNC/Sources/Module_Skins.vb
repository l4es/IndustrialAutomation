﻿Imports System.Drawing.Imaging

Module Skins

    ' =========================================================================
    '   SKINS
    ' =========================================================================
    Private StyleLabels As BorderStyle
    Private StyleCoords As BorderStyle
    Private ImageLabels As Image
    Private ImageButtons As Image
    Private ImageButtonsPressed As Image
    Private ImageZeroButtons As Image
    Private ImageZeroButtonsPressed As Image
    Private ImageBack As Image
    Private ButtonHiLightFactor As Int32 = 10
    Private ButtonDisabledDimFactor As Int32 = -20
    Private ColorCrossCursor As Color
    Private ColorPanelBack As Color
    Private ColorPanelFront As Color
    Private ColorButtonsText As Color
    Private ColorButtonsTextChecked As Color
    Private ColorTextBoxBack As Color
    Private ColorTextBoxFront As Color
    Private ColorTextBoxOver As Color
    Private ColorLabelFront As Color
    Private ColorGcodeBack As Color
    Private ColorGcodeFront As Color
    Private ColorSplitter As Color

    Private ImageButtonsHover As Image
    Private ImageZeroButtonsHover As Image
    Private ImageLabelsHover As Image
    Private ImageButtonsHoverPressed As Image

    Friend SkinHasButtonsImages As Boolean
    Friend SelectedSkinName As String
    Private SkinFound As Boolean
    Private SkinPath As String
    Private SkinNames As String

    Friend ToolPenFirstSegment_Color As Color = Color.OrangeRed
    Friend ToolPenRapid_Color As Color = Color.OrangeRed
    Friend ToolPenWork_Color As Color = Color.Black
    Friend ToolPenRapidMilled_Color As Color = Color.Green
    Friend ToolPenWorkMilled_Color As Color = Color.Red

    Friend ToolPenFirstSegment_Size As Int32 = 2
    Friend ToolPenRapid_Size As Int32 = 1
    Friend ToolPenWork_Size As Int32 = 1
    Friend ToolPenRapidMilled_Size As Int32 = 2
    Friend ToolPenWorkMilled_Size As Int32 = 2

    Private Sub Load_SkinNames()
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim line As String
        Dim l As String
        SkinPath = PlatformAdjustedFileName(Application.StartupPath & "\Skins\")
        Dim FileName As String = SkinPath + "Skins.txt"
        ' -------------------------------------------------------------------------------
        If My.Computer.FileSystem.FileExists(FileName) Then
            SkinNames = ""
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(FileName)
            Do While Not f.EndOfStream
                line = f.ReadLine()
                l = line
                If ExtractParamName(l) = "Skin" Then
                    SkinNames += l + vbCrLf
                End If
            Loop
            f.Close()
        End If
    End Sub

    Private Sub Load_Skin()
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim line As String
        Dim l As String
        SkinPath = PlatformAdjustedFileName(Application.StartupPath & "\Skins\")
        Dim FileName As String = SkinPath + "Skins.txt"
        ' -------------------------------------------------------------------------------
        If My.Computer.FileSystem.FileExists(FileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(FileName)
            Do While Not f.EndOfStream
                line = f.ReadLine()
                l = line
                ' ------------------------------------------- find skin number
                If Not SkinFound Then
                    If ExtractParamName(l) = "Skin" Then
                        If l = SelectedSkinName Then
                            SkinFound = True
                        End If
                    End If
                    Continue Do
                End If
                ' ------------------------------------------- load the skin
                Select Case ExtractParamName(l)
                    Case "Skin" : Exit Do
                        '
                    Case "StyleLabels" : StyleLabels = DecodeBorderStyle(l)
                    Case "StyleCoords" : StyleCoords = DecodeBorderStyle(l)
                    Case "ImageButtons" : ImageButtons = LoadImage(l)
                    Case "ImageButtonsPressed" : ImageButtonsPressed = LoadImage(l)
                    Case "ImageZeroButtons" : ImageZeroButtons = LoadImage(l)
                    Case "ImageZeroButtonsPressed" : ImageZeroButtonsPressed = LoadImage(l)
                    Case "ImageLabels" : ImageLabels = LoadImage(l)
                    Case "ImageBack" : ImageBack = LoadImage(l)
                        '
                    Case "ColorCrossCursor" : ColorCrossCursor = DecodeColor(l)
                    Case "ColorPanelBack" : ColorPanelBack = DecodeColor(l)
                    Case "ColorPanelFront" : ColorPanelFront = DecodeColor(l)
                    Case "ColorTextBoxBack" : ColorTextBoxBack = DecodeColor(l)
                    Case "ColorTextBoxFront" : ColorTextBoxFront = DecodeColor(l)
                    Case "ColorTextBoxOver" : ColorTextBoxOver = DecodeColor(l)
                    Case "ColorLabelFront" : ColorLabelFront = DecodeColor(l)
                    Case "ColorGcodeBack" : ColorGcodeBack = DecodeColor(l)
                    Case "ColorGcodeFront" : ColorGcodeFront = DecodeColor(l)
                    Case "ColorSplitter" : ColorSplitter = DecodeColor(l)
                        '
                    Case "ButtonHiLightFactor" : ButtonHiLightFactor = CInt(Val(l))
                    Case "ButtonDisabledDimFactor" : ButtonDisabledDimFactor = CInt(Val(l))
                        '
                    Case "ColorButtonsText" : ColorButtonsText = DecodeColor(l)
                    Case "ColorButtonsTextChecked" : ColorButtonsTextChecked = DecodeColor(l)

                    Case "ToolPenFirstSegment_Color" : ToolPenFirstSegment_Color = DecodeColor(l)
                    Case "ToolPenRapid_Color" : ToolPenRapid_Color = DecodeColor(l)
                    Case "ToolPenWork_Color" : ToolPenWork_Color = DecodeColor(l)
                    Case "ToolPenRapidMilled_Color" : ToolPenRapidMilled_Color = DecodeColor(l)
                    Case "ToolPenWorkMilled_Color" : ToolPenWorkMilled_Color = DecodeColor(l)

                    Case "ToolPenFirstSegment_Size" : ToolPenFirstSegment_Size = CInt(Val(l))
                    Case "ToolPenRapid_Size" : ToolPenRapid_Size = CInt(Val(l))
                    Case "ToolPenWork_Size" : ToolPenWork_Size = CInt(Val(l))
                    Case "ToolPenRapidMilled_Size" : ToolPenRapidMilled_Size = CInt(Val(l))
                    Case "ToolPenWorkMilled_Size" : ToolPenWorkMilled_Size = CInt(Val(l))

                    Case Else
                        If l <> "" Then
                            Form_MsgBox.Message_OK("Unrecognized skin line : " + vbCr + line, , , "Skin loader")
                        End If
                End Select
            Loop
            f.Close()
        End If
        ImageButtonsHover = ImageHiLight(ImageButtons, ButtonHiLightFactor)
        ImageZeroButtonsHover = ImageHiLight(ImageZeroButtons, ButtonHiLightFactor)
        ImageLabelsHover = ImageHiLight(ImageLabels, ButtonHiLightFactor)
        ImageButtonsHoverPressed = ImageHiLight(ImageButtonsPressed, ButtonHiLightFactor)
    End Sub
    Private Function DecodeBorderStyle(ByVal s As String) As Windows.Forms.BorderStyle
        Select Case s.ToLower
            Case "fixedsingle" : Return BorderStyle.FixedSingle
            Case "fixed3d" : Return BorderStyle.Fixed3D
            Case "none" : Return BorderStyle.None
            Case Else : Form_MsgBox.Message_OK("Unrecognized border style : " + s, , , "Skin loader")
        End Select
    End Function
    Private Function LoadImage(ByVal imageName As String) As Image
        If imageName = "Nothing" Or imageName = "" Then
            Return Nothing
        End If
        Dim FileName As String = SkinPath & "Images\" & imageName
        If FileExists(FileName) Then
            Return Image.FromFile(FileName)
        Else
            Form_MsgBox.Message_OK("Image not found : " + vbCr + imageName, , , "Skin loader")
            Return Nothing
        End If
    End Function
    Private Function DecodeColor(ByVal s As String) As Color
        Dim col() As String = Split(s, " ")
        If col.Length = 3 Then
            DecodeColor = Color.FromArgb(CInt(Val(col(0))), CInt(Val(col(1))), CInt(Val(col(2))))
        Else
            DecodeColor = Color.FromName(s)
            If DecodeColor.A = 0 Then
                Form_MsgBox.Message_OK("Unrecognized color : " + vbCr + s, , , "Skin loader")
                DecodeColor = Color.Gray
            End If
        End If
    End Function

    Private Function SelectedSkinNumber() As Int32
        Dim sk() As String = Split(SkinNames, vbCrLf)
        For i As Int32 = 0 To Sk.length - 1
            If sk(i).StartsWith(SelectedSkinName) Then
                Return i
            End If
        Next
        Return -1
    End Function

    Friend Sub SKIN_SelectSkin()
        Load_SkinNames()
        Dim newname As String = Form_MsgBox.Message_Select(SkinNames, SelectedSkinName, _
                                                           SelectedSkinNumber, 15, "Skin selection", , True)
        If newname <> SelectedSkinName Then
            SelectedSkinName = newname
            EventsAreEnabled = False
            SKIN_SetUserInterfaceColors()
            EventsAreEnabled = True
            GraphicThread_DrawToolpathImage(False)
        End If
    End Sub

    Friend Sub SKIN_SetUserInterfaceColors()
        SkinFound = False
        Load_Skin()
        If Not SkinFound Then
            SelectedSkinName = ""
            SkinFound = False
            Load_Skin()
        End If
        If SkinFound Then
            Form1.ToolStripButton_Skin.Text = "Skin: " + SelectedSkinName
            SkinHasButtonsImages = ImageButtons IsNot Nothing
            SetColors(Form1)
            SetColors(Form_MsgBox)
            SetColors(Form_About)
            SetColors(Form_Replace)
            SetColors(Form_Calibrations)
            SetColors(Form_Options)
        Else
            Form1.ToolStripButton_Skin.Text = "No skins"
        End If
        CNC_UpdatePenColors()
    End Sub

    Private BitmapSizeCorrection As Double = 1.01

    Private Sub SetColors(ByVal container As Control)
        If TypeOf (container) Is Form Then
            container.BackColor = ColorPanelBack
        End If
        For Each c As Control In container.Controls
            Select Case True
                Case TypeOf (c) Is Panel
                    If c.Name.StartsWith("PanelCursor") Then
                        c.BackColor = ColorCrossCursor
                        c.ForeColor = ColorCrossCursor
                    ElseIf c.Name.StartsWith("PanelBack") Then
                        c.BackColor = ColorPanelBack
                        c.ForeColor = ColorPanelFront
                    ElseIf c.Name = "PanelSplitter" Then
                        c.BackColor = ColorSplitter
                        c.ForeColor = ColorPanelFront
                    Else
                        c.BackColor = ColorPanelBack
                        c.ForeColor = ColorPanelFront
                        c.BackgroundImage = ImageBack
                    End If
                Case TypeOf (c) Is GroupBox
                    c.BackColor = ColorPanelBack
                    c.ForeColor = ColorPanelFront
                    c.BackgroundImage = ImageBack
                Case TypeOf (c) Is MyTextBox
                    c.BackColor = ColorTextBoxBack
                    c.ForeColor = ColorTextBoxFront
                    CType(c, MyTextBox).BackColor_Over = ColorTextBoxOver
                Case TypeOf (c) Is TextBox
                    c.BackColor = ColorTextBoxBack
                    c.ForeColor = ColorTextBoxFront
                Case TypeOf (c) Is RichTextBox
                    c.BackColor = ColorGcodeBack
                    c.ForeColor = ColorGcodeFront
                Case TypeOf (c) Is PictureBox
                    c.BackColor = ColorGcodeBack
                    c.ForeColor = ColorGcodeFront
                Case TypeOf (c) Is Label
                    If c.Name.StartsWith("lbl_Coord") OrElse c.Name.StartsWith("lbl_Temp") Then
                        CType(c, Label).BorderStyle = StyleCoords
                        c.BackColor = ColorTextBoxBack
                        c.ForeColor = ColorTextBoxFront
                    Else
                        CType(c, Label).BorderStyle = StyleLabels
                        c.ForeColor = ColorLabelFront
                    End If
                    c.BackgroundImage = ImageLabels
                    c.BackgroundImageLayout = ImageLayout.Stretch
                Case TypeOf (c) Is ToolStrip
                    If c.Name.StartsWith("StatusStrip") Then
                        c.BackColor = ColorGcodeBack
                        c.ForeColor = ColorGcodeFront
                    End If
                Case TypeOf (c) Is MyButton
                    Dim b As MyButton
                    b = CType(c, MyButton)
                    b.DimFactorGray = ButtonDisabledDimFactor
                    b.DimFactorOver = ButtonHiLightFactor
                    b.ForeColor = ColorButtonsText
                    b.ForeColorChecked = ColorButtonsTextChecked
                    If ImageButtons IsNot Nothing Then
                        Dim s As Size = b.Size
                        s.Width = CInt(s.Width * BitmapSizeCorrection)
                        s.Height = CInt(s.Height * BitmapSizeCorrection)
                        b.ImageSize = s
                        b.BorderShow = False
                    Else
                        b.BorderShow = True
                    End If
                    If b.Name.StartsWith("btn_Zero") Then
                        If b.Checked Then
                            b.Image = ImageZeroButtonsPressed
                        Else
                            b.Image = ImageZeroButtons
                        End If
                    Else
                        If b.Checked Then
                            b.Image = ImageButtonsPressed
                        Else
                            b.Image = ImageButtons
                        End If
                    End If
                Case TypeOf (c) Is SplitContainer
                    c.BackColor = ColorSplitter
                Case Else
            End Select
            SetColors(c)
        Next
    End Sub

    Friend Sub SKIN_UpdateControlBaseColors(ByVal c As Control)
        c.BackColor = ColorGcodeBack
        c.ForeColor = ColorGcodeFront
    End Sub

    Friend Sub SKIN_UpdateButtons_Form1()
        If Not SkinFound Then Return
        UpdateButtons(Form1)
    End Sub
    Friend Sub SKIN_UpdateButtons_FormOptions()
        If Not SkinFound Then Return
        UpdateButtons(Form_Options)
    End Sub
    Private Sub UpdateButtons(ByVal container As Control)
        For Each c As Control In container.Controls
            Select Case True
                Case TypeOf (c) Is MyButton
                    Dim b As MyButton
                    b = CType(c, MyButton)
                    Dim s As Size = b.Size
                    s.Width = CInt(s.Width * BitmapSizeCorrection)
                    s.Height = CInt(s.Height * BitmapSizeCorrection)
                    b.ImageSize = s
                    UpdateButtonImage(b)
            End Select
            UpdateButtons(c)
        Next
    End Sub

    Private Sub UpdateButtonImage(ByVal b As MyButton)
        If b.Name.StartsWith("btn_Zero") Then
            If b.Checked Then
                b.Image = ImageZeroButtonsPressed
            Else
                b.Image = ImageZeroButtons
            End If
        Else
            If b.Checked Then
                b.Image = ImageButtonsPressed
            Else
                b.Image = ImageButtons
            End If
        End If
        b.Refresh()
    End Sub

    Private Sub UpdateButtonImage_Hover(ByVal b As MyButton)
        If b.Name.StartsWith("btn_Zero") Then
            If b.Checked Then
                b.Image = ImageZeroButtonsPressed
            Else
                b.Image = ImageZeroButtonsHover
            End If
        Else
            If b.Checked Then
                b.Image = ImageButtonsHoverPressed
            Else
                b.Image = ImageButtonsHover
            End If
        End If
        b.Refresh()
    End Sub

    Friend Sub SKIN_MouseEnteringButton(ByRef obj As Object)
        If Not SkinHasButtonsImages Then Return
        UpdateButtonImage_Hover(CType(obj, MyButton))
    End Sub
    Friend Sub SKIN_MouseLeavingButton(ByRef obj As Object)
        If Not SkinHasButtonsImages Then Return
        UpdateButtonImage(CType(obj, MyButton))
    End Sub

    Friend Sub SKIN_MouseEnteringLabel(ByRef obj As Object)
        If Not SkinHasButtonsImages Then Return
        CType(obj, Label).BackgroundImage = ImageLabelsHover
    End Sub
    Friend Sub SKIN_MouseLeavingLabel(ByRef obj As Object)
        If Not SkinHasButtonsImages Then Return
        CType(obj, Label).BackgroundImage = ImageLabels
    End Sub

    Friend Function ImageHiLight(ByVal img As Image, Optional ByVal brg As Single = 10) As Image
        Dim w As Integer = img.Width
        Dim h As Integer = img.Height
        ' ---------------------------------------------------- ImageAttributes object
        brg /= 300
        Dim imgAttr As New ImageAttributes()
        imgAttr.SetColorMatrix(New ColorMatrix(New Single()() _
                                               {New Single() {1, 0, 0, 0, 0}, _
                                                New Single() {0, 1, 0, 0, 0}, _
                                                New Single() {0, 0, 1, 0, 0}, _
                                                New Single() {0, 0, 0, 1, 0}, _
                                                New Single() {brg, brg, brg, 0, 1}}))
        ' ---------------------------------------------------- init imgOut
        ImageHiLight = New Bitmap(w, h)
        ' ---------------------------------------------------- do the work
        Dim g As Graphics = Graphics.FromImage(ImageHiLight)
        Dim rec As Rectangle = New Rectangle(0, 0, w, h)
        g.DrawImage(img, rec, 0, 0, w, h, GraphicsUnit.Pixel, imgAttr)
    End Function

    Friend Sub SplitterHiLight(ByVal p As Panel, ByVal HiLight As Boolean)
        If HiLight Then
            p.BackColor = CorrectColor(ColorSplitter, 30)
        Else
            p.BackColor = ColorSplitter
        End If
    End Sub

    Private Function CorrectColor(ByVal Col As Color, ByVal Amount As Single) As Color
        Dim r As Single = Col.R + Amount
        Dim g As Single = Col.G + Amount
        Dim b As Single = Col.B + Amount
        If r > 255 Then r = 255
        If g > 255 Then g = 255
        If b > 255 Then b = 255
        If r < 0 Then r = 0
        If g < 0 Then g = 0
        If b < 0 Then b = 0
        Return Color.FromArgb(Col.A, CInt(r), CInt(g), CInt(b))
    End Function

End Module
