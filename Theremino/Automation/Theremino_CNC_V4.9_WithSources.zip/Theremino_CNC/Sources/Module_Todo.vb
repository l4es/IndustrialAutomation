﻿Module Module_Todo

    ' ============================================================================
    '   TODO - MAIN TODO LIST
    ' ============================================================================
    '  Publish version 4.7

    ' --------------------------------------------------------------- important
    '  Restore GCode line with SaveLoad
    '  Selected line to mid of window after UNDO/REDO

    '  XYAB GotoZero / GotoMax / View 3D
    '  Goto Zero/Home/Bottom/Top with XY-AB gcodes
    '  Disable right mouse movements with XY-AB gcodes

    ' --------------------------------------------------------------- secondary
    '  M00/01/82/84 and M101 to M190 for 3D printers
    '  Form1 buttons by timer

    ' --------------------------------------------------------------- bad ideas
    '  Form Partials to Exec Partials
    '  rotations on oblique 3D
    '  offsets with G53, G54, G55, G56, G57, G58, G59
    '  G98 G83 - canned cycles (test with 110mm tube section)

    ' ============================================================================
    '   DONE
    ' ============================================================================
    ' --------------------------------------------- version 4.7
    ' Added message "Calibration completed - Press OK"
    ' --------------------------------------------- version 4.6
    ' Selected line in the middle of the GCode text
    ' Slot 34 (SlotSkipInput) skips the present line
    ' Low acceleration compensator (Help - Options Menu and Appendix 26)
    ' Restored MainEnableOutput (Slot23) at the application startup
    ' M84 disables the button "IN OUT enabled" and the Slot 23 (machine general enable)
    ' Emergency Slot and Space Bar disabling all as expected 
    ' 
    ' --------------------------------------------- version 4.5
    ' Changed HAL with version 7.0

    ' --------------------------------------------- version 4.4
    '  Menu Options and Panel Options with:
    '  First Slot
    '  Jog speed normal = nn% of RAPID
    '  Jog speed SHIFT = nn% of RAPID 
    '  Jog speed ALT = 0.001
    '  Jog speed CTRL = Main window CTRL-Jog speed
    '
    '  Open and Save files also on Net Locations
    '
    '  Delay for slow spindle motors
    '
    '  Increased speed stability while Jogging
    '
    '  Remember G02 from preceding lines (gcode test Riccelli)
    '
    '  Documentation page 44 - Slot 27 to 33

    '  --------------------------------------------- old versions
    '  Menu for 3D printers
    '  Show 3D printers sensors temperatures 
    '  Complete skin control for toolpath colors and sizes 
    '  jog autocentering toolpath while zoomed
    '  Disabled buttons during calibrations
    '  Start line imprecisions
    '  Help for DirectX errors
    '  Disable Zoom for Gamepads with Pow always ON
    '  In out slots for 3D printers
    '  Invert Gamepad Z and RZ
    '  Translate zoomed image with left button
    '  zoom errors with gcode not zeroed
    '  Joystick
    '  disable joystick JOG while running and pause and not picturebox enabled
    '  Axis "E" automatically converted to "A"
    '  Zero buttons with updated names for axis "E", "U" and "V"
    '  Errors are limited to 900 chars
    '  Increased load speed of files with many errors
    '  G28 home
    '  M03 M04 M05 M13 M14 for spindle
    '  Spindle clockwise anticlockwise output
    '  CTRL-F = Find
    '  Speed also negative
    '  Calibrations - compensations and zero
    '  Calibrations - WaitExactStop
    '  "IN OUT enabled" with changed coordinates not moving motors
    '  Calibrations - clearance return
    '  Start calibrations only if IN-OUT-enabled and HAL-enabled
    '  do not reset EnableOUT when starting with "IN OUT enabled" off 
    '  Keys Z and X for Z axis on keyboards without PageUp/Down
    '  Disable also "IN OUT enabled" and "HAL enabled" buttons
    '  Zoom buttons also for the ToolPath
    '  MessageBox not closing
    '  MessageBox titles errors
    '  Calibrations
    '  New output "enable"
    '  help calibrations form
    '  close panels by UI timer
    '  calibrations form
    '  help 125% (125% aware)
    '  test ABZ bursts
    '  ViewTypes-AB listed only if AB are used
    '  messages bottom alignement
    '  Start line imprecision (Note 1)
    '  ensured zero to unused axis
    '  help - out disable signal
    '  speed bursts with JOG and Goto buttons  
    '  error - if deleting all file + ENTER
    '  error - invalid chars in file
    '  Files also outside the application folder
    '  Look Ahead Hi-Precision for sharp turns
    '  file not found that changes RTB zoom
    '  Speed stabilization
    '  reorder forms
    '  moving to zero before first movement line 
    '  Zeta movements in the first GCode lines
    '  Gcode cursor non visible after rewind
    '  M06 stops in the following lines
    '  view axes A and B
    '  M10-M11 M13-M14 M19 M32 to M45
    '  G04 and G05
    '  M06 tool changes
    '  calibrations and Z-Home only if not running
    '  Cross cursor displaced with 125%
    '  Split errors with 125%
    '  first line to effective start point
    '  cursor on coordinates with 125%
    '  look ahead
    '  errors with rotate not normalized
    '  total time
    '  circular interpolations G2 and G3
    '  rotate left and right for G2 and G3
    '  rotation errors on some files
    '  ReplaceTokenValue respecting the number of decimals
    '  uncomment removing only one comment
    '  redraw after right mouse JOG
    '  tools commands with AB axis
    '  translate to zero not working
    '  start button depressing to pause
    '  disable right mouse jog when Gcode is empty
    '  first coordinate errors on some files
    '  inline comments while using tools
    '  replace not working outside the selection
    '  correct right mouse on 3D errors 
    '  Start without Rewind moves Z axis to Zero
    '  start stop jogging
    '  stop while changing views
    '  not parsing if not necessary
    '  zoom on XP
    '  emergency and switches - immediate reset
    '  A - S   = Jog axis A
    '  B - N   = Jog axis B
    '  press skin not activating buttons
    '  hilight buttons on mouse enter/exit
    '  redraw thread 
    '  STOP while editing - OK
    '  activate on move? - removed definitively
    '  GCode editing fast redraw
    '  Up / Down and ToolStop not working after CTRL-Z
    '  GCode first lines without comments
    '  GCode first lines without "F"
    '  GCode first lines with Z only
    '  Rewind after double clik on a GCODE line
    '  warning for jog and right click wit Z low
    '  disable GCode edit and change position while PAUSED
    '  disable toolpath double click while PAUSED
    '  disable "Edit coordinates" with left button while running
    '  Test low Z
    '  disable "Edit skin file" while running
    '  goto 0 0
    '  set oldline when selecting RTB gcode line
    '  correct toolpath double click with View Oblique
    '  implement ismetric View
    '  restart with saved axis values
    '  disable GCode contextual menu while gcode running
    '  implement offsets with right button on coordinates
    '  test offsets with right button on coordinates
    '  test offsets with left button
    '  cursors always visible
    '  contextual UNDO and REDO
    '  can not delete completely the GCode text
    '  wrong selection after indent, comment and replace
    '  activate application after start with HAL
    '  undo not working with Find and Replace
    '  left and right rotations
    '  replace splitter with panels
    '  rotations with translation to zero
    '  mark center positions of holes
    '  sizes when opening minimized
    '  test for invalid GCodes
    '  no errors also if Gcode is not loaded
    '  menu Tools and Skins
    '  conversion from inch
    '  scroll to see selection after UNDO-REDO
    '  update cross cursor after UNDO-REDO

    ' --------------------------------------------- NOTES
    '  (Note 1)
    '  Start line imprecision
    '  Starting line not congruent with toolpath hilighted segments
    '    Sub RTB_SelectionChanged
    '    Sub Pic_ToolPath_MouseDoubleClick
    '    Sub DrawToolpathImage



    ' ==================================================================================================
    '   3D PRINTERS - M-CODES and G-CODES to be implemented
    ' ==================================================================================================
    ' M101 - Turn extruder 1 ON
    ' M103 - Turn all extruders OFF (Extruder Retraction)
    ' M108 - Extrusion speed (only used by CubeX)
    ' M113 - Set extruder PWM (only used by CubeX)(Example: M113 S0.7 - extruder motor current = 70%)
    ' M142 - Set holding pressure (Example: M142 S1 – pressure = 1 bar)
    ' M190 - Wait the bed temperature
    '  G91 - Relative coords

    ' ==================================================================================================
    '   3D PRINTERS - M-CODES and G-CODES implemented
    ' ==================================================================================================
    '  M82 - Set extruder to absolute mode (this is the default in repetier)
    '  M84 - Disable motors
    ' M105 - Read the current temperature (nothing to do)
    ' M106 - Fan ON 
    ' M107 - Fan OFF
    ' M104 - Set extruder temperature (Example: M104 S190 - temperature = 190°C)
    ' M109 - Set extruder temperature and wait (Example: M109 S215 - temperature = 215°C)
    ' M140 - Set print bed temperature (Example M140 S190 temperature = 190°C) 
    ' M141 - Set chamber temperature (Example: M141 S90 - temperature = 90°C)
    ' G92 - Set coordinates (without physical movements)
    '        Example: G92 X10 E90 sets X=10 and Extrusion=90 
    '        Without parameters all the axis are set to zero


    ' ==================================================================================================
    '   3D PRINTERS - IMPLEMENTED IN OUT channels
    ' ==================================================================================================

    '1 2  = x
    '3 4  = y
    '5 6  = z
    '7 8  = extruder 1
    '9 10 = extruder 2

    'Pwm out
    '---------------------
    'Holding force  - Vacuum pressure(Bar) or Magnetic Force or ON/OFF
    'Cooling fans   - Speed or ON/OFF
    'Ambient air    - Heating Power or ON/OFF
    'Chamber air    - Heating Power or ON/OFF
    'Print bed      - Heating Power or ON/OFF
    'Extruder 1     - Heating Power or ON/OFF
    'Extruder 2     - Heating Power or ON/OFF

    'ADC in - temperature
    '---------------------
    'Ambient air    - Temperature
    'Chamber air    - Temperature
    'Print bed      - Temperature
    'Extruder 1     - Temperature
    'Extruder 2     - Temperature

End Module
