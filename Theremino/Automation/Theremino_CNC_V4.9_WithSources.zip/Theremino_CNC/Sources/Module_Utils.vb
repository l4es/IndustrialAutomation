
Imports System.Math

Module Module_Utils

    ' =======================================================================================
    '  Utils
    ' =======================================================================================
    Friend WindowsDpiCoeff As Single = 1

    ' =========================================================================================
    '  WordWrap 
    ' -----------------------------------------------------------------------------------------
    '   - il wrap avviene prevalentemente in corrispondenza di spazi o altri caratteri speciali
    '   - se nessun punto valido viene trovato allora vengono spezzate anche le parole
    '      in modo che "MaxLen" non venga mai superato 
    ' =========================================================================================
    Friend Function WordWrap(ByVal strText As String, ByVal MaxLen As Int32) As String
        WordWrap = ""
        Dim lastSplitPoint As Int32 = 0
        Dim LineLen As Int32 = 0
        '
        For i As Int32 = 0 To strText.Length - 1
            '
            Dim ch As Char = strText(i)
            '
            If InStr(" ~`!@#$%^&*()_-+={}[]|\:;""'<>,.?/", ch) > 0 Then
                lastSplitPoint = i
            End If
            '
            If LineLen >= MaxLen - 1 Then
                ' ------------------------------------------ se e' possibile spezzo un po' prima
                If i - lastSplitPoint < LineLen / 2 Then
                    WordWrap = Left(WordWrap, WordWrap.Length - (i - lastSplitPoint - 1)) & vbCr
                    i = lastSplitPoint
                Else
                    ' -------------------------------------- altrimenti taglio la parola dove capita
                    WordWrap += ch & vbCr
                End If
                ' ------------------------------------------ aggiorno la lunghezza
                LineLen = 0
            Else
                ' ------------------------------------------ se la riga e' ancora corta accodo il nuovo carattere
                WordWrap += ch
                ' ------------------------------------------ e aggiorno la lunghezza
                If ch = vbCr Then
                    LineLen = 0
                Else
                    LineLen += 1
                End If
            End If
        Next
    End Function


    ' =======================================================================================
    '  Utils
    ' =======================================================================================
    Friend Sub SleepMyThread(ByVal TimeMillisec As Int32)
        System.Threading.Thread.Sleep(TimeMillisec)
    End Sub

    Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
        With pbox
            If .ClientSize.Width < 1 Or .ClientSize.Height < 1 Then Return
            .Image = New Bitmap(.ClientSize.Width, .ClientSize.Height)
        End With
    End Sub

    'Friend Sub Swap(ByRef n1 As Double, ByRef n2 As Double)
    '    Dim dummy As Double = n1
    '    n1 = n2
    '    n2 = dummy
    'End Sub

    Friend Function SecondsToMinSec(ByVal seconds As Double) As String
        Dim m As Int32 = CInt(Math.Floor(seconds / 60))
        Return m.ToString("00") + ":" + (seconds - m * 60).ToString("00")
    End Function

    Friend Sub LimitSignedNumber(ByRef SignedNumber As Double, _
                             ByVal MinAbsValue As Double, ByVal MaxAbsValue As Double)
        If Math.Abs(SignedNumber) > MaxAbsValue Then SignedNumber = MaxAbsValue * Math.Sign(SignedNumber)
        If Math.Abs(SignedNumber) < MinAbsValue Then SignedNumber = MinAbsValue * Math.Sign(SignedNumber)
    End Sub

    Friend Sub LimitPositiveNumber(ByRef PositiveNumber As Double, _
                         ByVal MinValue As Double, ByVal MaxValue As Double)
        If PositiveNumber > MaxValue Then PositiveNumber = MaxValue
        If PositiveNumber < MinValue Then PositiveNumber = MinValue
    End Sub

    Friend Function ReplaceMultipleSpacesAndTrim(ByVal s As String) As String
        s = s.Replace(vbTab, " ")
        While s.Contains("  ")
            s = s.Replace("  ", " ")
        End While
        Return s.Trim
    End Function


    ' =========================================================================
    '  WINDOWS SCHEDULER PRECISION
    ' ========================================================================= 
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Friend Sub ShedulerMaxPrecision()
        If OperatingSystemIsWindows Then
            timeBeginPeriod(1)
        End If
    End Sub
    Friend Sub ShedulerDefaultPrecision()
        If OperatingSystemIsWindows Then
            timeEndPeriod(1)
        End If
    End Sub


    ' =======================================================================================================
    '   FadeIn and FadeOut 
    ' =======================================================================================================
    Friend Sub Forms_FadeTo(ByVal FinalValue As Double, ByVal TimeMillisec As Double)
        If TimeMillisec < 1 Then TimeMillisec = 1
        Dim v As Double
        Dim k As Double
        Dim sw As Stopwatch = New Stopwatch
        Dim StartValue As Double = Form1.Opacity
        Application.DoEvents()
        System.Threading.Thread.Sleep(1)
        sw.Start()
        Do
            k = sw.Elapsed.TotalMilliseconds / TimeMillisec
            If k > 1 Then k = 1
            v = StartValue + (FinalValue - StartValue) * k
            Form1.Opacity = v
            System.Threading.Thread.Sleep(30)
            'Debug.Print(v.ToString)
        Loop Until k >= 1
    End Sub

    ' =======================================================================================================
    '   CURSOR - HOURGLASS and DEFAULT
    ' =======================================================================================================
    Friend Sub SetCursor_Hourglass()
        Application.UseWaitCursor = True
        Cursor.Current = Cursors.WaitCursor
        Application.DoEvents()
    End Sub
    Friend Sub SetCursor_Default()
        Application.UseWaitCursor = False
        Cursor.Current = Cursors.Default
        Application.DoEvents()
    End Sub

    ' =======================================================================================================
    '   DEBUG MESSAGES
    ' =======================================================================================================
    Private DebugCmd As String = ""
    Private DebugText As String
    Friend Sub DebugWindowUpdate()
        Select Case DebugCmd.ToUpper
            Case "OPEN"
                DebugWindow_Open()
                Form1.txt_Debug.Text = DebugText
                DebugText = ""
                DebugCmd = ""
            Case "CLOSE"
                DebugWindow_Close()
                DebugText = ""
                DebugCmd = ""
        End Select
    End Sub
    Private Sub DebugWindow_Open()
        With Form1
            If Not .txt_Debug.Visible Then
                .RTB.Top = 300
                .RTB.Height = .btn_ZoomPlus.Top - .RTB.Top - 6
                '.RTB.Height = .GroupBox_Gcode.ClientSize.Height - .RTB.Top - 28
                .txt_Debug.Top = 19
                .txt_Debug.Left = 12
                .txt_Debug.Height = .RTB.Top - 24
                .txt_Debug.Width = .RTB.Width
                .txt_Debug.Visible = True
            End If
        End With
    End Sub
    Private Sub DebugWindow_Close()
        With Form1
            If .txt_Debug.Visible Then
                .txt_Debug.Visible = False
                .RTB.Top = 19
                .RTB.Height = .btn_ZoomPlus.Top - 26
                '.RTB.Height = .GroupBox_Gcode.ClientSize.Height - 52
            End If
        End With
    End Sub
    Friend Sub DebugWindow_Show()
        DebugCmd = "OPEN"
    End Sub
    Friend Sub DebugWindow_Hide()
        DebugCmd = "CLOSE"
    End Sub
    Friend Sub DebugWindow_SetText(ByVal text As String)
        DebugText = text
    End Sub
    Friend Sub DebugWindow_AppendText(ByVal text As String)
        DebugText += text + vbCrLf
    End Sub
    Friend Sub DebugWindow_AppendText(ByVal text1 As String, ByVal text2 As String)
        DebugText += text1 + "    " + text2 + vbCrLf
    End Sub

End Module





