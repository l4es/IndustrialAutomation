﻿Module Module_Vectors

    Private ci As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

    '' ==================================================================================================
    ''   Vector 3D
    '' ==================================================================================================
    'Friend Structure Vec3
    '    Dim x As Double
    '    Dim y As Double
    '    Dim z As Double
    '    Function Dist(ByVal other As Vec3) As Double
    '        Dist = Math.Sqrt((other.x - x) ^ 2 + (other.y - y) ^ 2 + (other.z - z) ^ 2)
    '    End Function
    '    Function Add(ByVal other As Vec3) As Vec3
    '        Add.x = x + other.x
    '        Add.y = y + other.y
    '        Add.z = z + other.z
    '    End Function
    '    Function Subtract(ByVal other As Vec3) As Vec3
    '        Subtract.x = x - other.x
    '        Subtract.y = y - other.y
    '        Subtract.z = z - other.z
    '    End Function
    '    Function Mul(ByVal factor As Double) As Vec3
    '        Mul.x = x * factor
    '        Mul.y = y * factor
    '        Mul.z = z * factor
    '    End Function
    '    Function Length() As Double
    '        Return Math.Sqrt(x ^ 2 + y ^ 2 + z ^ 2)
    '    End Function
    '    Function LengthXY() As Double
    '        Return Math.Sqrt(x ^ 2 + y ^ 2)
    '    End Function
    '    Function OrthoZ() As Vec3
    '        OrthoZ.x = y
    '        OrthoZ.y = -x
    '        OrthoZ.z = z
    '    End Function
    '    Function Normalized() As Vec3
    '        Dim l As Double = Me.Length()
    '        If l > 0 Then
    '            Normalized = Me.Mul(1 / l)
    '        End If
    '    End Function
    '    Function IsValidVector() As Boolean
    '        If x <> 0 OrElse y <> 0 OrElse z <> 0 Then
    '            Return True
    '        Else
    '            Return False
    '        End If
    '    End Function
    '    ' --------------------------------------------------------------------------------
    '    ' DotProductNormalized return values are from 1 to -1
    '    ' --------------------------------------------------------------------------------
    '    ' return value = 1  : the two input vectors are pointing in the same direction 
    '    ' return value = 0  : the two input vectors are at right angles 
    '    ' return value = -1 : the two input vectors are pointing in opposite directions 
    '    ' --------------------------------------------------------------------------------
    '    Shared Function DotProductNormalized(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
    '        Return (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z) / (v1.Length * v2.Length)
    '    End Function
    '    Shared Function DotProduct(ByVal v1 As Vec3, ByVal v2 As Vec3) As Double
    '        Return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
    '    End Function
    'End Structure

    'Friend Function NewVec3(ByVal x As Double, ByVal y As Double, ByVal z As Double) As Vec3
    '    NewVec3.x = x
    '    NewVec3.y = y
    '    NewVec3.z = z
    'End Function

    ''Friend Function NewVec3() As Vec3
    ''    ' no need to set each member to zero because the
    ''    ' default value for all the numeric types is zero
    ''End Function


    ' ==================================================================================================
    '   Vector 5D
    ' ==================================================================================================
    Friend Structure Vec5
        Dim x As Double
        Dim y As Double
        Dim z As Double
        Dim a As Double
        Dim b As Double
        Sub InitWithValue(ByVal v As Double)
            x = v
            y = v
            z = v
            a = v
            b = v
        End Sub
        Function Add(ByVal other As Vec5) As Vec5
            Add.x = x + other.x
            Add.y = y + other.y
            Add.z = z + other.z
            Add.a = a + other.a
            Add.b = b + other.b
        End Function
        Function Subtract(ByVal other As Vec5) As Vec5
            Subtract.x = x - other.x
            Subtract.y = y - other.y
            Subtract.z = z - other.z
            Subtract.a = a - other.a
            Subtract.b = b - other.b
        End Function
        Function Mul(ByVal factor As Double) As Vec5
            Mul.x = x * factor
            Mul.y = y * factor
            Mul.z = z * factor
            Mul.a = a * factor
            Mul.b = b * factor
        End Function
        Function Dist(ByVal other As Vec5) As Double
            Dist = Math.Sqrt((other.x - x) ^ 2 + _
                             (other.y - y) ^ 2 + _
                             (other.z - z) ^ 2 + _
                             (other.a - a) ^ 2 + _
                             (other.b - b) ^ 2)
        End Function
        Function MaxDist(ByVal other As Vec5) As Double
            MaxDist = Math.Abs(other.x - x)
            MaxDist = Math.Max(MaxDist, Math.Abs(other.y - y))
            MaxDist = Math.Max(MaxDist, Math.Abs(other.z - z))
            MaxDist = Math.Max(MaxDist, Math.Abs(other.a - a))
            MaxDist = Math.Max(MaxDist, Math.Abs(other.b - b))
        End Function
        Function Length() As Double
            Return Math.Sqrt(x ^ 2 + y ^ 2 + z ^ 2 + a ^ 2 + b ^ 2)
        End Function
        'Function LengthXYZ() As Double
        '    Return Math.Sqrt(x ^ 2 + y ^ 2 + z ^ 2)
        'End Function
        'Function LengthXY() As Double
        '    Return Math.Sqrt(x ^ 2 + y ^ 2)
        'End Function
        Function OrthoZ() As Vec5
            OrthoZ.x = y
            OrthoZ.y = -x
            OrthoZ.z = z
            OrthoZ.a = a
            OrthoZ.b = b
        End Function
        Function MaxLength() As Double
            MaxLength = Math.Abs(x)
            If Math.Abs(y) > MaxLength Then MaxLength = Math.Abs(y)
            If Math.Abs(z) > MaxLength Then MaxLength = Math.Abs(z)
            If Math.Abs(a) > MaxLength Then MaxLength = Math.Abs(a)
            If Math.Abs(b) > MaxLength Then MaxLength = Math.Abs(b)
        End Function
        Function Normalized() As Vec5
            Dim l As Double = Me.Length()
            If l > 0 Then
                Normalized = Me.Mul(1 / l)
            End If
        End Function
        Function IsValidVector() As Boolean
            If x <> 0 OrElse y <> 0 OrElse z <> 0 OrElse a <> 0 OrElse b <> 0 Then
                Return True
            Else
                Return False
            End If
        End Function
        Function IsEqualTo(ByVal other As Vec5) As Boolean
            Return x = other.x And _
                   y = other.y And _
                   z = other.z And _
                   a = other.a And _
                   b = other.b
        End Function
        Overrides Function ToString() As String
            Return x.ToString("0.0 ", ci) + _
                   y.ToString("0.0 ", ci) + _
                   z.ToString("0.0 ", ci) + _
                   a.ToString("0.0 ", ci) + _
                   b.ToString("0.0 ", ci)
        End Function
        ' --------------------------------------------------------------------------------
        ' DotProductNormalized return values are from 1 to -1
        ' --------------------------------------------------------------------------------
        ' return value = 1  : the two input vectors are pointing in the same direction 
        ' return value = 0  : the two input vectors are at right angles 
        ' return value = -1 : the two input vectors are pointing in opposite directions 
        ' --------------------------------------------------------------------------------
        Shared Function DotProductNormalized(ByVal v1 As Vec5, ByVal v2 As Vec5) As Double
            Return (v1.x * v2.x + _
                    v1.y * v2.y + _
                    v1.z * v2.z + _
                    v1.a * v2.a + _
                    v1.b * v2.b) / (v1.Length * v2.Length)
        End Function
        Shared Function DotProduct(ByVal v1 As Vec5, ByVal v2 As Vec5) As Double
            Return v1.x * v2.x + _
                   v1.y * v2.y + _
                   v1.z * v2.z + _
                   v1.a * v2.a + _
                   v1.b * v2.b
        End Function
    End Structure
    Friend Function NewVec5(ByVal x As Double, _
                            ByVal y As Double, _
                            ByVal z As Double, _
                            ByVal a As Double, _
                            ByVal b As Double) As Vec5
        NewVec5.x = x
        NewVec5.y = y
        NewVec5.z = z
        NewVec5.a = a
        NewVec5.b = b
    End Function
    'Friend Function NewVec5() As Vec5
    '    ' no need to set each member to zero because the
    '    ' default value for all the numeric types is zero
    'End Function



    ' ==================================================================================================
    '  LineToPointDistance2D - Minimal distance POINT to SEGMENT and POINT to LINE
    ' ==================================================================================================
    Private Function Dot2D(ByVal x0 As Double, ByVal y0 As Double, _
                           ByVal x1 As Double, ByVal y1 As Double, _
                           ByVal x2 As Double, ByVal y2 As Double) As Double
        Return (x1 - x0) * (x2 - x1) + (y1 - y0) * (y2 - y1)
    End Function

    Private Function Cross2D(ByVal x0 As Double, ByVal y0 As Double, _
                             ByVal x1 As Double, ByVal y1 As Double, _
                             ByVal x2 As Double, ByVal y2 As Double) As Double
        Return (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0)
    End Function

    Private Function Dist2D(ByVal x1 As Double, ByVal y1 As Double, _
                            ByVal x2 As Double, ByVal y2 As Double) As Double
        Return Math.Sqrt((x1 - x2) ^ 2 + (y1 - y2) ^ 2)
    End Function

    Friend Function Distance_PointToSegment_2D(ByVal x0 As Double, ByVal y0 As Double, _
                                               ByVal x1 As Double, ByVal y1 As Double, _
                                               ByVal x2 As Double, ByVal y2 As Double) As Double
        If (Dot2D(x1, y1, x2, y2, x0, y0) > 0) Then Return Dist2D(x2, y2, x0, y0)
        If (Dot2D(x2, y2, x1, y1, x0, y0) > 0) Then Return Dist2D(x1, y1, x0, y0)
        Return Math.Abs(Cross2D(x1, y1, x2, y2, x0, y0) / Dist2D(x1, y1, x2, y2))
    End Function

    Friend Function Distance_PointToLine_2D(ByVal x0 As Double, ByVal y0 As Double, _
                                            ByVal x1 As Double, ByVal y1 As Double, _
                                            ByVal x2 As Double, ByVal y2 As Double) As Double
        Return Math.Abs(Cross2D(x1, y1, x2, y2, x0, y0) / Dist2D(x1, y1, x2, y2))
    End Function

End Module