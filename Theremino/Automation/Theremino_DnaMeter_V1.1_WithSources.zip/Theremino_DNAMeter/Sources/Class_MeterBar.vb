﻿Imports System.Drawing.Drawing2D

Public Class MeterBar

    Private WithEvents pbox As PictureBox = New PictureBox()
    Private m_graphics As Graphics
    Private m_fillbrush As LinearGradientBrush
    Private m_backbrush As Brush
    Private m_colors As Int32
    Private m_vertical As Boolean
    Private m_value As Single
    Private w As Int32
    Private h As Int32
    Private Shared m_textfontV As Font = New Font("Arial", 12)
    Private Shared m_textfontH As Font = New Font("Arial", 12)


    Friend Sub New(ByRef p As PictureBox, ByVal colors As Int32)
        If p Is Nothing Then Return

        pbox = p
        pbox.BackColor = Color.FromArgb(60, 70, 80)

        m_colors = colors

        w = pbox.ClientRectangle.Width
        h = pbox.ClientRectangle.Height
        m_vertical = If(h > w, True, False)

        SetAspect()
    End Sub

    Friend Sub Destroy()

    End Sub

    Private Sub SetAspect()
        InitPictureboxImage(pbox)
        If pbox.Image Is Nothing Then Return
        m_graphics = Graphics.FromImage(pbox.Image)
        m_backbrush = New SolidBrush(pbox.BackColor)
        If m_vertical Then
            Select Case m_colors
                Case 1 : m_fillbrush = CreateFillBrush(pbox, 90, 1)
                Case 2 : m_fillbrush = CreateFillBrush(pbox, 90, 2)
                Case 3 : m_fillbrush = CreateFillBrush(pbox, 0, 3)
                Case 4 : m_fillbrush = CreateFillBrush(pbox, 0, 4)
                Case 5 : m_fillbrush = CreateFillBrush(pbox, 0, 5)
            End Select
            m_graphics.FillRectangle(m_backbrush, 2, 1, w - 3, h - 2)
        Else
            Select Case m_colors
                Case 1 : m_fillbrush = CreateFillBrush(pbox, 180, 1)
                Case 2 : m_fillbrush = CreateFillBrush(pbox, 180, 2)
                Case 3 : m_fillbrush = CreateFillBrush(pbox, 90, 3)
                Case 4 : m_fillbrush = CreateFillBrush(pbox, 90, 4)
                Case 5 : m_fillbrush = CreateFillBrush(pbox, 90, 5)
            End Select
            m_graphics.FillRectangle(m_backbrush, 1, 1, w - 2, h - 2)
        End If
    End Sub

    Friend Sub ShowValue()
        If m_graphics Is Nothing Then Return
        If m_fillbrush Is Nothing Then Return
        If m_vertical Then
            Dim y As Single = pbox.ClientSize.Height * (1 - m_value / 1000.0F) + 1
            m_graphics.FillRectangle(m_backbrush, 2, 1, w - 3, y - 1)
            m_graphics.FillRectangle(m_fillbrush, 2, y, w - 3, h - 1)
            Dim s As String = CInt(m_value).ToString("0")
            m_graphics.DrawString(s, m_textfontV, Brushes.Yellow, 8 + 2 * (3 - s.Length), 4)
        Else
            Dim x As Single = pbox.ClientSize.Width * (m_value / 1000.0F) + 1
            m_graphics.FillRectangle(m_fillbrush, 1, 1, x - 1, h - 2)
            m_graphics.FillRectangle(m_backbrush, x, 1, w - 1, h - 2)
            Dim s As String = m_value.ToString("0.0", Globalization.CultureInfo.InvariantCulture)
            m_graphics.DrawString(s, m_textfontH, Brushes.Yellow, w - 17 - 6 * s.Length, 3)
        End If
        pbox.Refresh()
    End Sub

    Friend Sub SetValue(ByVal value As Single)
        If value < 0 Then value = 0
        If value > 1000 Then value = 1000
        If value <> m_value Then
            m_value = value
            ShowValue()
        End If
    End Sub

End Class
