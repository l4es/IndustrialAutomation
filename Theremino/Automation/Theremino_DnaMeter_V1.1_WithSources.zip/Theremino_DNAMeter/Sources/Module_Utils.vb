﻿Imports System.Drawing.Drawing2D

Module Module_Utils

    Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
        With pbox
            If .ClientSize.Height < 1 Then Return
            If .Image Is Nothing OrElse .Image.Width <> .ClientSize.Width _
                                 OrElse .Image.Height <> .ClientSize.Height Then
                .Image = New Bitmap(.ClientRectangle.Width, _
                                    .ClientRectangle.Height, _
                                    Imaging.PixelFormat.Format24bppRgb)
            End If
        End With
    End Sub

    Friend Function CreateFillBrush(ByVal pbox As PictureBox, _
                                    ByVal angle As Single, _
                                    ByVal blend As Int32) As LinearGradientBrush
        If pbox.ClientRectangle.Width < 1 Or _
           pbox.ClientRectangle.Height < 1 Then
            Return Nothing
        End If
        CreateFillBrush = New LinearGradientBrush(pbox.ClientRectangle, _
                                                  Color.Black, _
                                                  Color.Black, _
                                                  angle)
        Dim myBlend As ColorBlend = New ColorBlend()
        Select Case blend
            Case 1 ' multicolor
                myBlend.Positions = New Single() {0.0F, 0.4F, 0.5F, 0.6F, 1.0F}
                myBlend.Colors = New Color() {Color.FromArgb(255, 0, 0), _
                                              Color.FromArgb(255, 230, 0), _
                                              Color.FromArgb(250, 250, 0), _
                                              Color.FromArgb(230, 230, 0), _
                                              Color.FromArgb(0, 100, 0)}

            Case 2 ' multicolor reverse
                myBlend.Positions = New Single() {0.0F, 0.4F, 0.5F, 0.6F, 1.0F}
                myBlend.Colors = New Color() {Color.FromArgb(0, 200, 0), _
                                              Color.FromArgb(230, 230, 0), _
                                              Color.FromArgb(250, 250, 0), _
                                              Color.FromArgb(255, 230, 0), _
                                              Color.FromArgb(255, 0, 0)}
            Case 3 ' green
                myBlend.Positions = New Single() {0.0F, 0.4F, 0.5F, 0.9F, 1.0F}
                myBlend.Colors = New Color() {Color.FromArgb(200, 250, 150), _
                                              Color.FromArgb(80, 150, 100), _
                                              Color.FromArgb(80, 150, 0), _
                                              Color.FromArgb(80, 150, 0), _
                                              Color.FromArgb(250, 0, 0)}
            Case 4 ' red
                myBlend.Positions = New Single() {0.0F, 0.4F, 0.5F, 0.9F, 1.0F}
                myBlend.Colors = New Color() {Color.FromArgb(255, 200, 160), _
                                              Color.FromArgb(255, 150, 0), _
                                              Color.FromArgb(250, 120, 0), _
                                              Color.FromArgb(230, 80, 0), _
                                              Color.FromArgb(60, 0, 0)}
            Case 5 ' blue
                myBlend.Positions = New Single() {0.0F, 0.4F, 0.5F, 0.9F, 1.0F}
                myBlend.Colors = New Color() {Color.FromArgb(110, 190, 220), _
                                              Color.FromArgb(60, 130, 180), _
                                              Color.FromArgb(0, 120, 160), _
                                              Color.FromArgb(0, 100, 140), _
                                              Color.FromArgb(0, 20, 80)}
        End Select
        CreateFillBrush.InterpolationColors = myBlend
    End Function

    ' =======================================================================================================
    '   REDIM PRESERVE BIDIMENSIONAL STRING ARRAY
    ' =======================================================================================================
    Friend Sub RedimPreserve_2D_Array(ByRef ar(,) As String, ByVal rowUpperIdx As Int32, ByVal colUpperIdx As Int32)
        Dim newArray(rowUpperIdx, colUpperIdx) As String
        Dim minRows As Integer = Math.Min(rowUpperIdx + 1, ar.GetLength(0))
        Dim minCols As Integer = Math.Min(colUpperIdx + 1, ar.GetLength(1))
        For i As Int32 = 0 To minRows - 1
            For j As Int32 = 0 To minCols - 1
                newArray(i, j) = ar(i, j)
            Next
        Next
        ar = newArray
    End Sub

    ' =======================================================================================================
    '   FadeIn and FadeOut 
    ' =======================================================================================================
    Friend Sub Forms_FadeTo(ByVal FinalValue As Double, ByVal TimeMillisec As Double)
        If TimeMillisec < 1 Then TimeMillisec = 1
        Dim v As Double
        Dim k As Double
        Dim date1 As Date
        '
        Dim StartValue As Double = frmDNAMeter.Opacity
        '
        Application.DoEvents()
        System.Threading.Thread.Sleep(1)
        date1 = Date.Now
        Do
            k = Date.Now.Subtract(date1).TotalMilliseconds / TimeMillisec
            If k > 1 Then k = 1
            v = StartValue + (FinalValue - StartValue) * k
            If FinalValue = 0 Then
                v = v * 0.5
            End If
            frmDNAMeter.Opacity = v
            System.Threading.Thread.Sleep(20)
            'Debug.Print(v.ToString)
        Loop Until k >= 1
    End Sub

End Module
