﻿Imports System.Windows.Forms

Module Utils_LocaleNames

    Private ls(1, -1) As String

    ' ===============================================================================================
    '  MESSAGES - Default Values
    ' ===============================================================================================
    Friend Language As String = "ENG"

    Friend Msg_Ready As String = "Ready"
    Friend Msg_FluorescenceTest As String = "Fluorescence test"
    Friend Msg_AddReferenceSample As String = "Set Reference Sample"
    Friend Msg_DeleteAllReferences As String = "Delete References"
    Friend Msg_About_1 As String = "DNA Meter"
    Friend Msg_About_2 As String = "Fluorometer to measure DNA concentration"
    Friend Msg_ManualTest As String = "Manual test - Warning: A long test can change led temperatures"
    Friend Msg_Error As String = "Error"
    Friend Msg_NotStabilized_1 As String = "Measure not stabilized"
    Friend Msg_NotStabilized_2 As String = "Please test HAL configuration and hardware"
    Friend Msg_NotStabilized_3 As String = "Please configure HAL pins 1 and 2 with ""Response speed = 30"""
    Friend Msg_NoReferenceSample As String = "Reference Sample Setting not Complete"
    Friend Msg_NotValidReferenceSampleHigh As String = "Reference Sample not valid (too high fluorescence)"
    Friend Msg_NotValidReferenceSampleLow As String = "Reference Sample not valid (too low fluorescence)"

    Friend Sub SetLocales()
        ' ------------------------------------- read the file
        ReadLocaleFile()
        ' ------------------------------------- rename
        RenameControls(frmDNAMeter)
        ' ------------------------------------- release the array
        ReDim ls(-1, -1)
    End Sub

    Private Sub ReadLocaleFile()
        Dim locfilename As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\Language_" & Language & ".txt")
        If Not FileExists(locfilename) Then
            locfilename = PlatformAdjustedFileName(Application.StartupPath & "\Docs\Language_ENG.txt")
        End If
        If FileExists(locfilename) Then
            Dim i As Int32 = -1
            Dim s0 As String
            Dim s1 As String
            '
            Dim f As IO.StreamReader
            f = New System.IO.StreamReader(locfilename, System.Text.Encoding.Default)
            '
            Do While Not f.EndOfStream
                s1 = f.ReadLine
                s1 = Trim(s1.Replace(vbTab, " "))
                s0 = ExtractParamName(s1)
                If s0.Length > 1 And s1.Length > 1 Then
                    If s0.StartsWith("Msg_") Then
                        AddMessage(s0, s1)
                    Else
                        i += 1
                        RedimPreserve_2D_Array(ls, 1, i)
                        ls(0, i) = s0
                        ls(1, i) = s1
                    End If
                End If
            Loop
            f.Close()
        End If
    End Sub

    Private Sub AddMessage(ByVal s0 As String, ByVal s1 As String)
        Select Case s0
            Case "Msg_Ready" : Msg_Ready = s1
            Case "Msg_FluorescenceTest" : Msg_FluorescenceTest = s1
            Case "Msg_AddReferenceSample" : Msg_AddReferenceSample = s1
            Case "Msg_DeleteAllReferences" : Msg_DeleteAllReferences = s1
            Case "Msg_About_1" : Msg_About_1 = s1
            Case "Msg_About_2" : Msg_About_2 = s1
            Case "Msg_ManualTest" : Msg_ManualTest = s1
            Case "Msg_Error" : Msg_Error = s1
            Case "Msg_NotStabilized_1" : Msg_NotStabilized_1 = s1
            Case "Msg_NotStabilized_2" : Msg_NotStabilized_2 = s1
            Case "Msg_NotStabilized_3" : Msg_NotStabilized_3 = s1
            Case "Msg_NoReferenceSample" : Msg_NoReferenceSample = s1
            Case "Msg_NotValidReferenceSampleHigh" : Msg_NotValidReferenceSampleHigh = s1
            Case "Msg_NotValidReferenceSampleLow" : Msg_NotValidReferenceSampleLow = s1
        End Select
    End Sub

    ' ===============================================================================================
    '  RENAME CONTROLS
    ' ===============================================================================================
    Private Sub RenameControls(ByVal container As Control)
        '
        For i As Int32 = 0 To ls.GetLength(1) - 1
            If container.Name = ls(0, i) Then
                container.Text = ls(1, i)
            End If
        Next
        '
        For Each ctrl As Control In container.Controls
            For i As Int32 = 0 To ls.GetLength(1) - 1

                If ctrl.Name = ls(0, i) Then
                    ctrl.Text = ls(1, i)
                End If

                If TypeOf ctrl Is ToolStrip Then
                    Dim ts As ToolStrip = DirectCast(ctrl, ToolStrip)
                    RenameToolStripItems(ts)
                End If

                If TypeOf ctrl Is MenuStrip Then
                    Dim ms As MenuStrip = DirectCast(ctrl, MenuStrip)
                    RenameMenuStripItems(ms)
                End If
            Next
            ' ---------------------------- Recursively call this function for any container controls.
            If container.HasChildren Then
                RenameControls(ctrl)
            End If
        Next
    End Sub

    Private Sub RenameToolStripItems(ByRef ts As ToolStrip)
        For i As Int32 = 0 To ls.GetLength(1) - 1
            For j As Int32 = 0 To ts.Items.Count - 1
                If ts.Items(j).Name = ls(0, i) Then
                    ts.Items(j).Text = " " & ls(1, i)
                End If
            Next
        Next
    End Sub

    Private Sub RenameMenuStripItems(ByRef ms As MenuStrip)
        For i As Int32 = 0 To ls.GetLength(1) - 1
            For j As Int32 = 0 To ms.Items.Count - 1
                If ms.Items(j).Name = ls(0, i) Then
                    ms.Items(j).Text = " " & ls(1, i)
                End If
                Dim tsmi As ToolStripMenuItem = DirectCast(ms.Items(j), ToolStripMenuItem)
                For k As Int32 = 0 To tsmi.DropDownItems.Count - 1
                    If tsmi.DropDownItems(k).Name = ls(0, i) Then
                        tsmi.DropDownItems(k).Text = " " & ls(1, i)
                    End If
                Next
            Next
        Next
    End Sub

End Module
