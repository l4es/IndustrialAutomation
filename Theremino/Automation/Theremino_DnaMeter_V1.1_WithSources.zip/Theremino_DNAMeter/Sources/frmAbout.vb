﻿Public Class frmAbout

    Private Sub frmAbout_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Text = AppTitleAndVersion("Theremino - Fluorometer for DNA quantitation")
        Label2.Text = AppTitleAndVersion("Theremino DNA Meter")
    End Sub

    Private Sub frmAbout_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Label_Info.Text = Msg_About_1 & vbCrLf & Msg_About_2
        frmDNAMeter.Visible = False
        frmDNAMeter.Refresh()
    End Sub

    Private Sub Button_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_OK.Click
        Close()
    End Sub

    Private Sub frmAbout_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        frmDNAMeter.Visible = True
    End Sub

    Private Sub Label_ThereminoSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_ThereminoSite.Click
        Process.Start("http://www.theremino.com")
    End Sub

    Private Sub Label_PhysicsOpenLabSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_PhysicsOpenLabSite.Click
        Process.Start("http://physicsopenlab.org")
    End Sub

    Private Sub Label_MuseSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_MuseSite.Click
        Process.Start("http://www.muse.it")
    End Sub

    Private Sub Labels_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                                        Label_ThereminoSite.MouseEnter, _
                                                                                        Label_PhysicsOpenLabSite.MouseEnter, _
                                                                                        Label_MuseSite.MouseEnter
        Dim lb As Label = DirectCast(sender, Label)
        lb.BackColor = Color.FromArgb(250, 240, 255)
    End Sub

    Private Sub Labels_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                                        Label_ThereminoSite.MouseLeave, _
                                                                                        Label_PhysicsOpenLabSite.MouseLeave, _
                                                                                        Label_MuseSite.MouseLeave
        Dim lb As Label = DirectCast(sender, Label)
        lb.BackColor = Color.Transparent
    End Sub

End Class