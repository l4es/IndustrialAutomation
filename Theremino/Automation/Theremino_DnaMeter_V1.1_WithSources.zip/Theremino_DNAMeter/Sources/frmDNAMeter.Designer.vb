﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDNAMeter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDNAMeter))
        Me.picPhotodiodeSignal = New System.Windows.Forms.PictureBox
        Me.Label_DNAConcentration = New System.Windows.Forms.Label
        Me.txt_BaseSlot = New MyTextBox
        Me.chk_FrontLed = New System.Windows.Forms.CheckBox
        Me.Label_BaseSlot = New System.Windows.Forms.Label
        Me.GroupBox_Hardware = New System.Windows.Forms.GroupBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox_DNAMeter = New System.Windows.Forms.GroupBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.btn_DeleteAllReferences = New System.Windows.Forms.Button
        Me.lblRef2Conc = New System.Windows.Forms.Label
        Me.lblRef2LightValue = New System.Windows.Forms.Label
        Me.lblRef1Conc = New System.Windows.Forms.Label
        Me.txtRef2 = New MyTextBox
        Me.txtRef1 = New MyTextBox
        Me.lblRef2 = New System.Windows.Forms.Label
        Me.lblRef1 = New System.Windows.Forms.Label
        Me.btn_SetReferenceFluo2 = New System.Windows.Forms.Button
        Me.lblRef1LightValue = New System.Windows.Forms.Label
        Me.btn_SetReferenceFluo1 = New System.Windows.Forms.Button
        Me.btn_DNAMeasure = New System.Windows.Forms.Button
        Me.picConcentrazioneDNA = New System.Windows.Forms.PictureBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.GroupBox_Meters = New System.Windows.Forms.GroupBox
        Me.Label_Photodiode = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        CType(Me.picPhotodiodeSignal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Hardware.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox_DNAMeter.SuspendLayout()
        CType(Me.picConcentrazioneDNA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox_Meters.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'picPhotodiodeSignal
        '
        Me.picPhotodiodeSignal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picPhotodiodeSignal.BackColor = System.Drawing.Color.Khaki
        Me.picPhotodiodeSignal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picPhotodiodeSignal.Location = New System.Drawing.Point(100, 28)
        Me.picPhotodiodeSignal.Name = "picPhotodiodeSignal"
        Me.picPhotodiodeSignal.Size = New System.Drawing.Size(504, 28)
        Me.picPhotodiodeSignal.TabIndex = 0
        Me.picPhotodiodeSignal.TabStop = False
        '
        'Label_DNAConcentration
        '
        Me.Label_DNAConcentration.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_DNAConcentration.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_DNAConcentration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DNAConcentration.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_DNAConcentration.Location = New System.Drawing.Point(364, 21)
        Me.Label_DNAConcentration.Name = "Label_DNAConcentration"
        Me.Label_DNAConcentration.Size = New System.Drawing.Size(56, 13)
        Me.Label_DNAConcentration.TabIndex = 2
        Me.Label_DNAConcentration.Text = "DNA ug/l"
        Me.Label_DNAConcentration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_BaseSlot
        '
        Me.txt_BaseSlot.ArrowsIncrement = 1
        Me.txt_BaseSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_BaseSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BaseSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BaseSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BaseSlot.Increment = 0.2
        Me.txt_BaseSlot.Location = New System.Drawing.Point(95, 236)
        Me.txt_BaseSlot.MaxValue = 990
        Me.txt_BaseSlot.MinValue = 1
        Me.txt_BaseSlot.Multiline = True
        Me.txt_BaseSlot.Name = "txt_BaseSlot"
        Me.txt_BaseSlot.NumericValue = 1
        Me.txt_BaseSlot.NumericValueInteger = 1
        Me.txt_BaseSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BaseSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BaseSlot.RoundingStep = 0
        Me.txt_BaseSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BaseSlot.Size = New System.Drawing.Size(40, 15)
        Me.txt_BaseSlot.SuppressZeros = True
        Me.txt_BaseSlot.TabIndex = 13
        Me.txt_BaseSlot.Text = "1"
        Me.txt_BaseSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_FrontLed
        '
        Me.chk_FrontLed.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_FrontLed.BackColor = System.Drawing.Color.Snow
        Me.chk_FrontLed.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chk_FrontLed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_FrontLed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_FrontLed.Location = New System.Drawing.Point(27, 204)
        Me.chk_FrontLed.Name = "chk_FrontLed"
        Me.chk_FrontLed.Size = New System.Drawing.Size(106, 22)
        Me.chk_FrontLed.TabIndex = 11
        Me.chk_FrontLed.Text = "LED"
        Me.chk_FrontLed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_FrontLed.UseVisualStyleBackColor = False
        '
        'Label_BaseSlot
        '
        Me.Label_BaseSlot.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_BaseSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BaseSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_BaseSlot.Location = New System.Drawing.Point(20, 238)
        Me.Label_BaseSlot.Name = "Label_BaseSlot"
        Me.Label_BaseSlot.Size = New System.Drawing.Size(69, 13)
        Me.Label_BaseSlot.TabIndex = 12
        Me.Label_BaseSlot.Text = "Base Slot"
        Me.Label_BaseSlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_Hardware
        '
        Me.GroupBox_Hardware.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Hardware.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_Hardware.Controls.Add(Me.Label_BaseSlot)
        Me.GroupBox_Hardware.Controls.Add(Me.chk_FrontLed)
        Me.GroupBox_Hardware.Controls.Add(Me.txt_BaseSlot)
        Me.GroupBox_Hardware.Controls.Add(Me.PictureBox5)
        Me.GroupBox_Hardware.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Hardware.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_Hardware.Name = "GroupBox_Hardware"
        Me.GroupBox_Hardware.Size = New System.Drawing.Size(154, 261)
        Me.GroupBox_Hardware.TabIndex = 16
        Me.GroupBox_Hardware.TabStop = False
        Me.GroupBox_Hardware.Text = "Hardware"
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox5.BackColor = System.Drawing.Color.Honeydew
        Me.PictureBox5.BackgroundImage = Global.Theremino_DnaMeter.My.Resources.Resources.LedOff
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox5.ErrorImage = Global.Theremino_DnaMeter.My.Resources.Resources.LedOff
        Me.PictureBox5.InitialImage = Nothing
        Me.PictureBox5.Location = New System.Drawing.Point(15, 21)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(127, 208)
        Me.PictureBox5.TabIndex = 15
        Me.PictureBox5.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.GroupBox_DNAMeter)
        Me.Panel1.Location = New System.Drawing.Point(13, 35)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(444, 271)
        Me.Panel1.TabIndex = 17
        '
        'GroupBox_DNAMeter
        '
        Me.GroupBox_DNAMeter.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_DNAMeter.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label5)
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label4)
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label3)
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label2)
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label1)
        Me.GroupBox_DNAMeter.Controls.Add(Me.btn_DeleteAllReferences)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef2Conc)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef2LightValue)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef1Conc)
        Me.GroupBox_DNAMeter.Controls.Add(Me.txtRef2)
        Me.GroupBox_DNAMeter.Controls.Add(Me.txtRef1)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef2)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef1)
        Me.GroupBox_DNAMeter.Controls.Add(Me.btn_SetReferenceFluo2)
        Me.GroupBox_DNAMeter.Controls.Add(Me.lblRef1LightValue)
        Me.GroupBox_DNAMeter.Controls.Add(Me.btn_SetReferenceFluo1)
        Me.GroupBox_DNAMeter.Controls.Add(Me.btn_DNAMeasure)
        Me.GroupBox_DNAMeter.Controls.Add(Me.picConcentrazioneDNA)
        Me.GroupBox_DNAMeter.Controls.Add(Me.Label_DNAConcentration)
        Me.GroupBox_DNAMeter.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_DNAMeter.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_DNAMeter.Name = "GroupBox_DNAMeter"
        Me.GroupBox_DNAMeter.Size = New System.Drawing.Size(434, 261)
        Me.GroupBox_DNAMeter.TabIndex = 17
        Me.GroupBox_DNAMeter.TabStop = False
        Me.GroupBox_DNAMeter.Text = "DNA Quantitation"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(310, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 20)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "ug/l"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(310, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 20)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Value"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(310, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 20)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Value"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(310, 167)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 20)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "ug/l"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(310, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 20)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "ug/l"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_DeleteAllReferences
        '
        Me.btn_DeleteAllReferences.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_DeleteAllReferences.Location = New System.Drawing.Point(42, 191)
        Me.btn_DeleteAllReferences.Name = "btn_DeleteAllReferences"
        Me.btn_DeleteAllReferences.Size = New System.Drawing.Size(194, 51)
        Me.btn_DeleteAllReferences.TabIndex = 12
        Me.btn_DeleteAllReferences.Text = "Delete Reference Data"
        Me.btn_DeleteAllReferences.UseVisualStyleBackColor = True
        '
        'lblRef2Conc
        '
        Me.lblRef2Conc.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef2Conc.BackColor = System.Drawing.Color.Cornsilk
        Me.lblRef2Conc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef2Conc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.lblRef2Conc.Location = New System.Drawing.Point(250, 170)
        Me.lblRef2Conc.Name = "lblRef2Conc"
        Me.lblRef2Conc.Size = New System.Drawing.Size(55, 14)
        Me.lblRef2Conc.TabIndex = 28
        Me.lblRef2Conc.Text = "0"
        Me.lblRef2Conc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRef2LightValue
        '
        Me.lblRef2LightValue.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef2LightValue.BackColor = System.Drawing.Color.Cornsilk
        Me.lblRef2LightValue.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef2LightValue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.lblRef2LightValue.Location = New System.Drawing.Point(250, 152)
        Me.lblRef2LightValue.Name = "lblRef2LightValue"
        Me.lblRef2LightValue.Size = New System.Drawing.Size(55, 14)
        Me.lblRef2LightValue.TabIndex = 27
        Me.lblRef2LightValue.Text = "0"
        Me.lblRef2LightValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRef1Conc
        '
        Me.lblRef1Conc.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef1Conc.BackColor = System.Drawing.Color.Cornsilk
        Me.lblRef1Conc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef1Conc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.lblRef1Conc.Location = New System.Drawing.Point(250, 114)
        Me.lblRef1Conc.Name = "lblRef1Conc"
        Me.lblRef1Conc.Size = New System.Drawing.Size(55, 14)
        Me.lblRef1Conc.TabIndex = 26
        Me.lblRef1Conc.Text = "0"
        Me.lblRef1Conc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtRef2
        '
        Me.txtRef2.ArrowsIncrement = 1
        Me.txtRef2.BackColor = System.Drawing.Color.MintCream
        Me.txtRef2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txtRef2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRef2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRef2.ForeColor = System.Drawing.Color.Red
        Me.txtRef2.Increment = 0.2
        Me.txtRef2.Location = New System.Drawing.Point(250, 135)
        Me.txtRef2.MaxValue = 990
        Me.txtRef2.MinValue = 0
        Me.txtRef2.Multiline = True
        Me.txtRef2.Name = "txtRef2"
        Me.txtRef2.NumericValue = 100
        Me.txtRef2.NumericValueInteger = 100
        Me.txtRef2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txtRef2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txtRef2.RoundingStep = 0
        Me.txtRef2.ShadowColor = System.Drawing.Color.LightGray
        Me.txtRef2.Size = New System.Drawing.Size(55, 14)
        Me.txtRef2.SuppressZeros = True
        Me.txtRef2.TabIndex = 25
        Me.txtRef2.Text = "100"
        Me.txtRef2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtRef1
        '
        Me.txtRef1.ArrowsIncrement = 1
        Me.txtRef1.BackColor = System.Drawing.Color.MintCream
        Me.txtRef1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txtRef1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRef1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRef1.ForeColor = System.Drawing.Color.Red
        Me.txtRef1.Increment = 0.2
        Me.txtRef1.Location = New System.Drawing.Point(250, 78)
        Me.txtRef1.MaxValue = 990
        Me.txtRef1.MinValue = 0
        Me.txtRef1.Multiline = True
        Me.txtRef1.Name = "txtRef1"
        Me.txtRef1.NumericValue = 0
        Me.txtRef1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txtRef1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txtRef1.RoundingStep = 0
        Me.txtRef1.ShadowColor = System.Drawing.Color.LightGray
        Me.txtRef1.Size = New System.Drawing.Size(55, 14)
        Me.txtRef1.SuppressZeros = True
        Me.txtRef1.TabIndex = 24
        Me.txtRef1.Text = "0"
        Me.txtRef1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblRef2
        '
        Me.lblRef2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef2.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.lblRef2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef2.ForeColor = System.Drawing.Color.Red
        Me.lblRef2.Location = New System.Drawing.Point(310, 132)
        Me.lblRef2.Name = "lblRef2"
        Me.lblRef2.Size = New System.Drawing.Size(40, 20)
        Me.lblRef2.TabIndex = 22
        Me.lblRef2.Text = "ug/l"
        Me.lblRef2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRef1
        '
        Me.lblRef1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef1.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.lblRef1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef1.ForeColor = System.Drawing.Color.Red
        Me.lblRef1.Location = New System.Drawing.Point(36, 66)
        Me.lblRef1.Name = "lblRef1"
        Me.lblRef1.Size = New System.Drawing.Size(0, 0)
        Me.lblRef1.TabIndex = 21
        Me.lblRef1.Text = "ug/l"
        Me.lblRef1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_SetReferenceFluo2
        '
        Me.btn_SetReferenceFluo2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_SetReferenceFluo2.Location = New System.Drawing.Point(42, 134)
        Me.btn_SetReferenceFluo2.Name = "btn_SetReferenceFluo2"
        Me.btn_SetReferenceFluo2.Size = New System.Drawing.Size(194, 51)
        Me.btn_SetReferenceFluo2.TabIndex = 17
        Me.btn_SetReferenceFluo2.Text = "   Set Reference Sample    High DNA Concentration"
        Me.btn_SetReferenceFluo2.UseVisualStyleBackColor = True
        '
        'lblRef1LightValue
        '
        Me.lblRef1LightValue.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRef1LightValue.BackColor = System.Drawing.Color.Cornsilk
        Me.lblRef1LightValue.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRef1LightValue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.lblRef1LightValue.Location = New System.Drawing.Point(250, 96)
        Me.lblRef1LightValue.Name = "lblRef1LightValue"
        Me.lblRef1LightValue.Size = New System.Drawing.Size(55, 14)
        Me.lblRef1LightValue.TabIndex = 16
        Me.lblRef1LightValue.Text = "0"
        Me.lblRef1LightValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_SetReferenceFluo1
        '
        Me.btn_SetReferenceFluo1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_SetReferenceFluo1.Location = New System.Drawing.Point(42, 78)
        Me.btn_SetReferenceFluo1.Name = "btn_SetReferenceFluo1"
        Me.btn_SetReferenceFluo1.Size = New System.Drawing.Size(194, 51)
        Me.btn_SetReferenceFluo1.TabIndex = 13
        Me.btn_SetReferenceFluo1.Text = "   Set Reference Sample     Low DNA Concentration"
        Me.btn_SetReferenceFluo1.UseVisualStyleBackColor = True
        '
        'btn_DNAMeasure
        '
        Me.btn_DNAMeasure.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_DNAMeasure.Location = New System.Drawing.Point(42, 21)
        Me.btn_DNAMeasure.Name = "btn_DNAMeasure"
        Me.btn_DNAMeasure.Size = New System.Drawing.Size(194, 51)
        Me.btn_DNAMeasure.TabIndex = 11
        Me.btn_DNAMeasure.Text = "Start DNA Measure"
        Me.btn_DNAMeasure.UseVisualStyleBackColor = True
        '
        'picConcentrazioneDNA
        '
        Me.picConcentrazioneDNA.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picConcentrazioneDNA.BackColor = System.Drawing.Color.Khaki
        Me.picConcentrazioneDNA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picConcentrazioneDNA.Location = New System.Drawing.Point(365, 40)
        Me.picConcentrazioneDNA.Name = "picConcentrazioneDNA"
        Me.picConcentrazioneDNA.Size = New System.Drawing.Size(55, 201)
        Me.picConcentrazioneDNA.TabIndex = 9
        Me.picConcentrazioneDNA.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.GroupBox_Hardware)
        Me.Panel2.Location = New System.Drawing.Point(475, 35)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(164, 271)
        Me.Panel2.TabIndex = 18
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.GroupBox_Meters)
        Me.Panel3.Location = New System.Drawing.Point(13, 318)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(626, 90)
        Me.Panel3.TabIndex = 19
        '
        'GroupBox_Meters
        '
        Me.GroupBox_Meters.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Meters.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_Meters.Controls.Add(Me.Label_Photodiode)
        Me.GroupBox_Meters.Controls.Add(Me.picPhotodiodeSignal)
        Me.GroupBox_Meters.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Meters.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_Meters.Name = "GroupBox_Meters"
        Me.GroupBox_Meters.Size = New System.Drawing.Size(616, 80)
        Me.GroupBox_Meters.TabIndex = 17
        Me.GroupBox_Meters.TabStop = False
        Me.GroupBox_Meters.Text = "Meters"
        '
        'Label_Photodiode
        '
        Me.Label_Photodiode.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_Photodiode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Photodiode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_Photodiode.Location = New System.Drawing.Point(6, 28)
        Me.Label_Photodiode.Name = "Label_Photodiode"
        Me.Label_Photodiode.Size = New System.Drawing.Size(88, 28)
        Me.Label_Photodiode.TabIndex = 9
        Me.Label_Photodiode.Text = "Photodiode"
        Me.Label_Photodiode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(655, 24)
        Me.MenuStrip1.TabIndex = 154
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_ENG, Me.Menu_Language_ITA})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_ENG
        '
        Me.Menu_Language_ENG.Name = "Menu_Language_ENG"
        Me.Menu_Language_ENG.Size = New System.Drawing.Size(113, 22)
        Me.Menu_Language_ENG.Text = "English"
        '
        'Menu_Language_ITA
        '
        Me.Menu_Language_ITA.Name = "Menu_Language_ITA"
        Me.Menu_Language_ITA.Size = New System.Drawing.Size(113, 22)
        Me.Menu_Language_ITA.Text = "Italiano"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.ToolStripSeparator4, Me.Menu_Help_OpenProgramFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(188, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program Help"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(185, 6)
        '
        'Menu_Help_OpenProgramFolder
        '
        Me.Menu_Help_OpenProgramFolder.Name = "Menu_Help_OpenProgramFolder"
        Me.Menu_Help_OpenProgramFolder.Size = New System.Drawing.Size(188, 22)
        Me.Menu_Help_OpenProgramFolder.Text = "Open Program Folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'StatusStrip2
        '
        Me.StatusStrip2.AutoSize = False
        Me.StatusStrip2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1})
        Me.StatusStrip2.Location = New System.Drawing.Point(0, 427)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(655, 33)
        Me.StatusStrip2.SizingGrip = False
        Me.StatusStrip2.TabIndex = 156
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(10, Byte), Integer))
        Me.StatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust
        Me.StatusLabel1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(654, 28)
        Me.StatusLabel1.Text = "Ready"
        '
        'frmDNAMeter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.BackgroundImage = Global.Theremino_DnaMeter.My.Resources.Resources.DNABack
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(655, 460)
        Me.Controls.Add(Me.StatusStrip2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmDNAMeter"
        Me.Opacity = 0
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino DNA Meter"
        CType(Me.picPhotodiodeSignal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Hardware.ResumeLayout(False)
        Me.GroupBox_Hardware.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox_DNAMeter.ResumeLayout(False)
        Me.GroupBox_DNAMeter.PerformLayout()
        CType(Me.picConcentrazioneDNA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.GroupBox_Meters.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picPhotodiodeSignal As System.Windows.Forms.PictureBox
    Friend WithEvents Label_DNAConcentration As System.Windows.Forms.Label
    Friend WithEvents Label_BaseSlot As System.Windows.Forms.Label
    Friend WithEvents chk_FrontLed As System.Windows.Forms.CheckBox
    Friend WithEvents txt_BaseSlot As MyTextBox
    Friend WithEvents GroupBox_Hardware As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_DNAMeter As System.Windows.Forms.GroupBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_Meters As System.Windows.Forms.GroupBox
    Friend WithEvents Label_Photodiode As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents picConcentrazioneDNA As System.Windows.Forms.PictureBox
    Friend WithEvents btn_DNAMeasure As System.Windows.Forms.Button
    Friend WithEvents btn_SetReferenceFluo1 As System.Windows.Forms.Button
    Friend WithEvents btn_DeleteAllReferences As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents lblRef1LightValue As System.Windows.Forms.Label
    Friend WithEvents btn_SetReferenceFluo2 As System.Windows.Forms.Button
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip2 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblRef1 As System.Windows.Forms.Label
    Friend WithEvents lblRef2 As System.Windows.Forms.Label
    Friend WithEvents txtRef1 As MyTextBox
    Friend WithEvents txtRef2 As MyTextBox
    Friend WithEvents lblRef1Conc As System.Windows.Forms.Label
    Friend WithEvents lblRef2Conc As System.Windows.Forms.Label
    Friend WithEvents lblRef2LightValue As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
