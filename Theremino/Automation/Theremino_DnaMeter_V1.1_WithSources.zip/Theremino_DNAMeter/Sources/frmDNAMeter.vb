﻿
Public Class frmDNAMeter

    ' ============================================================================================
    '  Constants and Variables 
    ' ============================================================================================
    Private FrontLedSlot As Int32
    Private PhotodiodeSensorSlot As Int32

    Private FrontLedOn As Boolean = False

    Private MeterBarSignal As MeterBar
    Private MeterBarDNA As MeterBar

    Private ValuesStability As Single
    Private LightValueOld As Single
    Private LightValue As Single

    Private ReferenceFluorescent1Value As Single = -1
    Private ReferenceFluorescent1Concentration As Single = -1
    Private ReferenceFluorescent2Value As Single = -1
    Private ReferenceFluorescent2Concentration As Single = -1

    Private SampleDNALightValue As Single
    Private SampleDNAConcentration As Single

    ' ============================================================================================
    '   User interface events 
    ' ============================================================================================
    Private Sub frmDNAMeter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Visible = False
        Me.Opacity = 0
        ' --------------------------------------------
        Load_INI()
        'ToolStrip1.Renderer = New ToolStripButtonRenderer
        StartThereminoHAL()
        SetLocales()
        SetParams()
        UpdateUserInterface()
        Text = AppTitleAndVersion("Theremino - Fluorometer for DNA Quantitation")
        MeterBarSignal = New MeterBar(picPhotodiodeSignal, 4)
        MeterBarDNA = New MeterBar(picConcentrazioneDNA, 2)
        ' ------------------------------------------- FadeIn
        Me.Visible = True
        Forms_FadeTo(1, 400)
        Timer1.Interval = 15
        Timer1.Start()
        ' -------------------------------------------
        EventsAreEnabled = True
    End Sub
    Private Sub frmDNAMeter_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Forms_FadeTo(0, 500)
        Me.Refresh()
        Save_INI()
        StopThereminoHAL()
    End Sub
    Private Sub frmDNAMeter_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub
    Private Sub UpdateUserInterface()
        SetLedOnOff()
        PrintStatus(1)
        PrintReference1()
        PrintReference2()
        Refresh()
    End Sub

    ' =========================================================================
    '   THEREMINO HAL - START STOP -
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        Dim HalPath As String = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
        If Not FileExists(HalPath) Then HalPath = Application.StartupPath & "\Theremino_HAL.exe"
        If Not FileExists(HalPath) Then Return
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(HalPath)
        psi.FileName = HalPath
        HalProcess = Process.Start(psi)
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing AndAlso Not HalProcess.HasExited Then
            Try
                HalProcess.CloseMainWindow()
            Finally
            End Try
        End If
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(150, 150, 150), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub

    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        Me.Close()
    End Sub

    ' =======================================================================================
    '   MENU LANGUAGE
    ' =======================================================================================
    Private Sub Menu_Language_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language.DropDownOpening
        For Each item As ToolStripMenuItem In Menu_Language.DropDownItems
            If item.Name.EndsWith(Language, StringComparison.InvariantCultureIgnoreCase) Then
                item.Select()
            End If
        Next
    End Sub
    Private Sub Menu_Language_ENG_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ENG.Click
        Language = "ENG"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ITA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ITA.Click
        Language = "ITA"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        OpenLocalizedHelp("Theremino_DNAMeter", ".pdf")
    End Sub
    Private Sub Menu_Help_OpenProgramFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_OpenProgramFolder.Click
        Process.Start(Application.StartupPath)
    End Sub
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")
        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & Language & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        frmAbout.ShowDialog(Me)
    End Sub

    ' =======================================================================================
    '   PARAMS
    ' =======================================================================================
    Private Sub Params_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_BaseSlot.MouseLeave
        SetParams()
        Save_INI()
    End Sub
    Private Sub SetParams()
        PhotodiodeSensorSlot = txt_BaseSlot.NumericValueInteger
        FrontLedSlot = PhotodiodeSensorSlot + 1
    End Sub

    ' =======================================================================================
    '   HARDWARE CONTROLS
    ' =======================================================================================
    Private Sub chk_FrontLed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_FrontLed.CheckedChanged
        FrontLedOn = chk_FrontLed.Checked
        SetLedOnOff()
    End Sub
    Private Sub SetLedOnOff()
        Slots.WriteSlot(FrontLedSlot, If(FrontLedOn, 1000, 0))
        ' Switch Hardware Image 
        If FrontLedOn Then
            PictureBox5.BackgroundImage = My.Resources.LedOn
        Else
            PictureBox5.BackgroundImage = My.Resources.LedOff
        End If
        ' Switch Status
        If FrontLedOn Then
            PrintStatus(3)
        Else
            PrintStatus(1)
        End If
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        SmoothValue_Pow(LightValue, Slots.ReadSlot_NoNan(PhotodiodeSensorSlot), 100)
        MeterBarSignal.SetValue(LightValue)
        ' ------------------------------------------------------------ stability
        Dim s1 As Single = Math.Abs(LightValue - LightValueOld) / (LightValue + 100)
        ValuesStability = s1
        LightValueOld = LightValue
    End Sub
    Private Sub SmoothValue_Pow(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        Dim delta As Single = new_value - value
        Dim delta_sgn As Single = Math.Sign(delta)
        Dim delta_abs As Single = Math.Abs(delta)
        Dim delta_pow As Single
        delta_pow = CSng((0.003F * speed * delta_abs) ^ 2)
        If delta_pow >= delta_abs Then
            value = new_value
        Else
            value += delta_sgn * delta_pow
        End If
    End Sub

    ' =======================================================================================
    '  DNA measure
    ' =======================================================================================
    ' -- to change for DNA calculation --
    Private Sub btn_DNAMeasure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_DNAMeasure.Click
        PrintReference1()
        PrintReference2()
        If ReferenceFluorescent1Value >= 0 And _
           ReferenceFluorescent1Concentration >= 0 And _
           ReferenceFluorescent2Value >= 0 And _
           ReferenceFluorescent2Concentration >= 0 Then
            DisableControls()
            MeterBarDNA.SetValue(0)
            Dim m As Single = ReadLightValue()
            SampleDNALightValue = m
            ' pendenza retta luce / concentrazione
            Dim p As Single = (ReferenceFluorescent2Concentration - ReferenceFluorescent1Concentration) / (ReferenceFluorescent2Value - ReferenceFluorescent1Value)
            ' calcolo concentrazione DNA
            SampleDNAConcentration = p * (SampleDNALightValue - ReferenceFluorescent1Value) + ReferenceFluorescent1Concentration
            MeterBarDNA.SetValue(SampleDNAConcentration)
            EnableControls()
        Else
            PrintStatus(4)
        End If
    End Sub

    ' ---- Reference low DNA concentration ----
    Private Sub btn_SetReferenceFluo1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SetReferenceFluo1.Click
        PrintReference1()
        PrintReference2()
        If MsgBox(Msg_AddReferenceSample, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            DisableControls()
            MeterBarDNA.SetValue(0)
            Dim m As Single = ReadLightValue()
            If m < 100 Then
                ' Valori OK
                ReferenceFluorescent1Value = m
                ReferenceFluorescent1Concentration = txtRef1.NumericValueInteger
                UpdateUserInterface()
            Else
                ' Valori troppo alti
                PrintStatus(5)
            End If
            EnableControls()
        End If
    End Sub

    ' ---- Reference High concentration ----
    Private Sub btn_SetReferenceFluo2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SetReferenceFluo2.Click
        PrintReference1()
        PrintReference2()
        If MsgBox(Msg_AddReferenceSample, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            DisableControls()
            MeterBarDNA.SetValue(0)
            Dim m As Single = ReadLightValue()
            If m > 200 Then
                ' Valori OK
                ReferenceFluorescent2Value = m
                ReferenceFluorescent2Concentration = txtRef2.NumericValueInteger
                UpdateUserInterface()
            Else
                ' Valori troppo bassi
                PrintStatus(6)
            End If
            EnableControls()
        End If
    End Sub

    Private Sub btn_DeleteAllReferences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_DeleteAllReferences.Click
        If MsgBox(Msg_DeleteAllReferences, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            DisableControls()
            MeterBarDNA.SetValue(0)
            chk_FrontLed.Checked = False
            ReferenceFluorescent1Value = -1
            ReferenceFluorescent2Value = -1
            ReferenceFluorescent1Concentration = -1
            ReferenceFluorescent2Concentration = -1
            UpdateUserInterface()
            EnableControls()
        End If
    End Sub

    Friend Sub PrintReference1()
        lblRef1LightValue.Text = CStr(ReferenceFluorescent1Value)
        lblRef1Conc.Text = CStr(ReferenceFluorescent1Concentration)
    End Sub

    Friend Sub PrintReference2()
        lblRef2LightValue.Text = CStr(ReferenceFluorescent2Value)
        lblRef2Conc.Text = CStr(ReferenceFluorescent2Concentration)
    End Sub

    Private Function ReadLightValue() As Single
        Dim m As Single
        ' -----------------------------------------
        chk_FrontLed.Checked = True
        PrintStatus(2)
        WaitStability()
        m = LightValue
        ' -----------------------------------------
        chk_FrontLed.Checked = False
        Return m
    End Function

    Private Sub WaitStability()
        Dim counter As Int32 = 0
        ValuesStability = 100
        System.Threading.Thread.Sleep(15)
        For i As Int32 = 1 To 300
            Application.DoEvents()
            System.Threading.Thread.Sleep(15)
            If ValuesStability > 0.001 Then
                counter = 0
            Else
                counter += 1
                If counter > 40 Then
                    'Debug.Print(ValuesStability.ToString)
                    Return
                End If
            End If
        Next
        MsgBox(Msg_NotStabilized_1 & vbCrLf & vbCrLf & _
               Msg_NotStabilized_2 & vbCrLf & _
               Msg_NotStabilized_3, MsgBoxStyle.Critical)
    End Sub

    Private Function Percentual(ByVal v1 As Single, ByVal v2 As Single) As Single
        Return 2 * Math.Abs(v1 - v2) / (v1 + v2)
    End Function

    Private Sub DisableControls()
        For Each c As Control In Me.Controls
            If c.Name.Contains("Menu") Then
                c.Enabled = False
            End If
        Next
        For Each c As Control In Me.GroupBox_DNAMeter.Controls
            c.Enabled = False
        Next
        For Each c As Control In Me.GroupBox_Hardware.Controls
            c.Enabled = False
        Next
    End Sub

    Private Sub EnableControls()
        For Each c As Control In Me.Controls
            If c.Name.Contains("Menu") Then
                c.Enabled = True
            End If
        Next
        For Each c As Control In Me.GroupBox_DNAMeter.Controls
            c.Enabled = True
        Next
        For Each c As Control In Me.GroupBox_Hardware.Controls
            c.Enabled = True
        Next
    End Sub

    Private Sub PrintStatus(ByVal status As Int32, _
                            Optional ByVal q As Single = 0)

        Dim colors As String = ""

        Select Case status
            Case 1
                StatusLabel1.Text = Msg_Ready
            Case 2
                StatusLabel1.Text = Msg_FluorescenceTest
                colors = "UV"
            Case 3
                StatusLabel1.Text = Msg_ManualTest
                colors = "warning"
            Case 4
                StatusLabel1.Text = Msg_NoReferenceSample
                colors = "error"
            Case 5
                StatusLabel1.Text = Msg_NotValidReferenceSampleHigh
                colors = "error"
            Case 6
                StatusLabel1.Text = Msg_NotValidReferenceSampleLow
                colors = "error"
        End Select

        Select Case colors
            Case "zero"
                StatusLabel1.BackColor = Color.FromArgb(40, 40, 40)
                StatusLabel1.ForeColor = Color.FromArgb(255, 255, 220)
            Case "UV"
                StatusLabel1.BackColor = Color.FromArgb(60, 0, 120)
                StatusLabel1.ForeColor = Color.FromArgb(255, 100, 40) '(220, 180, 255)
            Case "warning"
                StatusLabel1.BackColor = Color.FromArgb(60, 0, 120) '(60, 40, 20)
                StatusLabel1.ForeColor = Color.FromArgb(255, 210, 0)
            Case "error"
                StatusLabel1.BackColor = Color.FromArgb(100, 0, 0)
                StatusLabel1.ForeColor = Color.FromArgb(255, 255, 0)
            Case ""
                StatusLabel1.BackColor = Color.FromArgb(50, 60, 10)
                StatusLabel1.ForeColor = Color.FromArgb(240, 255, 0)
        End Select
    End Sub

    Private Sub StatusStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)

    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help.Click

    End Sub
End Class