﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker13 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems13 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems14 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker14 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker11 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems11 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems12 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker12 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker9 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems9 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems10 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker10 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker1 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems2 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker2 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems3 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems4 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker4 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker5 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems5 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems6 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker6 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim DesignerRectTracker7 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Dim CBlendItems7 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim CBlendItems8 As Theremino_DopplerMeter.cBlendItems = New Theremino_DopplerMeter.cBlendItems
        Dim DesignerRectTracker8 As Theremino_DopplerMeter.DesignerRectTracker = New Theremino_DopplerMeter.DesignerRectTracker
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pbox_Scope = New System.Windows.Forms.PictureBox
        Me.pbox_Spectrum = New System.Windows.Forms.PictureBox
        Me.lbl_MaxDb = New System.Windows.Forms.Label
        Me.lbl_MinDb = New System.Windows.Forms.Label
        Me.lbl_MaxFreq = New System.Windows.Forms.Label
        Me.lbl_MinFreq = New System.Windows.Forms.Label
        Me.GroupBox_Spectrum = New System.Windows.Forms.GroupBox
        Me.lbl_SpeedDw = New System.Windows.Forms.Label
        Me.lbl_SpeedUp = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox_AudioOut = New System.Windows.Forms.GroupBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox_Scope = New System.Windows.Forms.GroupBox
        Me.tbar_ScopeTime = New System.Windows.Forms.TrackBar
        Me.tbar_ScopeVoltage = New System.Windows.Forms.TrackBar
        Me.GroupBox_Bands = New System.Windows.Forms.GroupBox
        Me.pbox_SpectrumHistory = New System.Windows.Forms.PictureBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbl_SlotSpeed = New System.Windows.Forms.Label
        Me.lbl_SlotSignal = New System.Windows.Forms.Label
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.Tools_SaveTotal = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveSpectrum = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveSpectrumLog = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_OpenSaveFolder = New System.Windows.Forms.ToolStripButton
        Me.txt_SlotSpeed = New Theremino_DopplerMeter.MyTextBox
        Me.txt_SlotSignal = New Theremino_DopplerMeter.MyTextBox
        Me.chk_Run = New Theremino_DopplerMeter.MyButton
        Me.txt_UltrasoundFrequency = New Theremino_DopplerMeter.MyTextBox
        Me.cmb_RadarType = New Theremino_DopplerMeter.MyComboBox
        Me.txt_MicrowaveFrequency = New Theremino_DopplerMeter.MyTextBox
        Me.chk_ScopeNeg = New Theremino_DopplerMeter.MyButton
        Me.cmb_AudioInDevices = New Theremino_DopplerMeter.MyComboBox
        Me.btn_AudioInputs = New Theremino_DopplerMeter.MyButton
        Me.btn_Clear = New Theremino_DopplerMeter.MyButton
        Me.txt_SpecSpeedDw = New Theremino_DopplerMeter.MyTextBox
        Me.chk_SpecAutoScale = New Theremino_DopplerMeter.MyButton
        Me.chk_SpecLogY = New Theremino_DopplerMeter.MyButton
        Me.chk_SpecLogX = New Theremino_DopplerMeter.MyButton
        Me.txt_SpecSpeedUp = New Theremino_DopplerMeter.MyTextBox
        Me.cmb_Spec_Window = New Theremino_DopplerMeter.MyComboBox
        Me.txt_SpecMaxDb = New Theremino_DopplerMeter.MyTextBox
        Me.txt_SpecMinDb = New Theremino_DopplerMeter.MyTextBox
        Me.txt_SpecMinFreq = New Theremino_DopplerMeter.MyTextBox
        Me.txt_SpecMaxFreq = New Theremino_DopplerMeter.MyTextBox
        CType(Me.pbox_Scope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox_Spectrum, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Spectrum.SuspendLayout()
        Me.GroupBox_AudioOut.SuspendLayout()
        Me.GroupBox_Scope.SuspendLayout()
        CType(Me.tbar_ScopeTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbar_ScopeVoltage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Bands.SuspendLayout()
        CType(Me.pbox_SpectrumHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'pbox_Scope
        '
        Me.pbox_Scope.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pbox_Scope.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_Scope.Location = New System.Drawing.Point(9, 18)
        Me.pbox_Scope.Name = "pbox_Scope"
        Me.pbox_Scope.Size = New System.Drawing.Size(237, 176)
        Me.pbox_Scope.TabIndex = 1
        Me.pbox_Scope.TabStop = False
        '
        'pbox_Spectrum
        '
        Me.pbox_Spectrum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pbox_Spectrum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_Spectrum.Location = New System.Drawing.Point(119, 16)
        Me.pbox_Spectrum.Name = "pbox_Spectrum"
        Me.pbox_Spectrum.Size = New System.Drawing.Size(321, 203)
        Me.pbox_Spectrum.TabIndex = 2
        Me.pbox_Spectrum.TabStop = False
        '
        'lbl_MaxDb
        '
        Me.lbl_MaxDb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MaxDb.Location = New System.Drawing.Point(9, 26)
        Me.lbl_MaxDb.Name = "lbl_MaxDb"
        Me.lbl_MaxDb.Size = New System.Drawing.Size(54, 13)
        Me.lbl_MaxDb.TabIndex = 22
        Me.lbl_MaxDb.Text = "Max dB"
        Me.lbl_MaxDb.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_MinDb
        '
        Me.lbl_MinDb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MinDb.Location = New System.Drawing.Point(9, 44)
        Me.lbl_MinDb.Name = "lbl_MinDb"
        Me.lbl_MinDb.Size = New System.Drawing.Size(54, 13)
        Me.lbl_MinDb.TabIndex = 24
        Me.lbl_MinDb.Text = "Min dB"
        Me.lbl_MinDb.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_MaxFreq
        '
        Me.lbl_MaxFreq.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MaxFreq.Location = New System.Drawing.Point(9, 65)
        Me.lbl_MaxFreq.Name = "lbl_MaxFreq"
        Me.lbl_MaxFreq.Size = New System.Drawing.Size(54, 13)
        Me.lbl_MaxFreq.TabIndex = 26
        Me.lbl_MaxFreq.Text = "Max freq."
        Me.lbl_MaxFreq.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_MinFreq
        '
        Me.lbl_MinFreq.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MinFreq.Location = New System.Drawing.Point(9, 84)
        Me.lbl_MinFreq.Name = "lbl_MinFreq"
        Me.lbl_MinFreq.Size = New System.Drawing.Size(54, 13)
        Me.lbl_MinFreq.TabIndex = 28
        Me.lbl_MinFreq.Text = "Min freq."
        Me.lbl_MinFreq.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox_Spectrum
        '
        Me.GroupBox_Spectrum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Spectrum.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_Spectrum.Controls.Add(Me.btn_Clear)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecSpeedDw)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_SpeedDw)
        Me.GroupBox_Spectrum.Controls.Add(Me.chk_SpecAutoScale)
        Me.GroupBox_Spectrum.Controls.Add(Me.chk_SpecLogY)
        Me.GroupBox_Spectrum.Controls.Add(Me.chk_SpecLogX)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecSpeedUp)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_SpeedUp)
        Me.GroupBox_Spectrum.Controls.Add(Me.Label5)
        Me.GroupBox_Spectrum.Controls.Add(Me.cmb_Spec_Window)
        Me.GroupBox_Spectrum.Controls.Add(Me.pbox_Spectrum)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecMaxDb)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_MaxDb)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecMinDb)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_MinFreq)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_MinDb)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecMinFreq)
        Me.GroupBox_Spectrum.Controls.Add(Me.txt_SpecMaxFreq)
        Me.GroupBox_Spectrum.Controls.Add(Me.lbl_MaxFreq)
        Me.GroupBox_Spectrum.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Spectrum.Location = New System.Drawing.Point(265, 178)
        Me.GroupBox_Spectrum.MinimumSize = New System.Drawing.Size(310, 145)
        Me.GroupBox_Spectrum.Name = "GroupBox_Spectrum"
        Me.GroupBox_Spectrum.Size = New System.Drawing.Size(448, 225)
        Me.GroupBox_Spectrum.TabIndex = 4
        Me.GroupBox_Spectrum.TabStop = False
        Me.GroupBox_Spectrum.Text = "Spectrum"
        '
        'lbl_SpeedDw
        '
        Me.lbl_SpeedDw.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_SpeedDw.Location = New System.Drawing.Point(6, 122)
        Me.lbl_SpeedDw.Name = "lbl_SpeedDw"
        Me.lbl_SpeedDw.Size = New System.Drawing.Size(54, 13)
        Me.lbl_SpeedDw.TabIndex = 138
        Me.lbl_SpeedDw.Text = "Speed dw"
        Me.lbl_SpeedDw.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_SpeedUp
        '
        Me.lbl_SpeedUp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_SpeedUp.Location = New System.Drawing.Point(6, 103)
        Me.lbl_SpeedUp.Name = "lbl_SpeedUp"
        Me.lbl_SpeedUp.Size = New System.Drawing.Size(54, 13)
        Me.lbl_SpeedUp.TabIndex = 133
        Me.lbl_SpeedUp.Text = "Speed up"
        Me.lbl_SpeedUp.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(9, 184)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 131
        Me.Label5.Text = "Sampling windows"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_AudioOut
        '
        Me.GroupBox_AudioOut.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_AudioOut.Controls.Add(Me.cmb_AudioInDevices)
        Me.GroupBox_AudioOut.Controls.Add(Me.btn_AudioInputs)
        Me.GroupBox_AudioOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_AudioOut.Location = New System.Drawing.Point(4, 28)
        Me.GroupBox_AudioOut.Name = "GroupBox_AudioOut"
        Me.GroupBox_AudioOut.Size = New System.Drawing.Size(255, 49)
        Me.GroupBox_AudioOut.TabIndex = 1
        Me.GroupBox_AudioOut.TabStop = False
        Me.GroupBox_AudioOut.Text = "Source selection"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(18, 45)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(141, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Microwave frequency (GHz)"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox_Scope
        '
        Me.GroupBox_Scope.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Scope.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_Scope.Controls.Add(Me.chk_ScopeNeg)
        Me.GroupBox_Scope.Controls.Add(Me.tbar_ScopeTime)
        Me.GroupBox_Scope.Controls.Add(Me.tbar_ScopeVoltage)
        Me.GroupBox_Scope.Controls.Add(Me.pbox_Scope)
        Me.GroupBox_Scope.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Scope.Location = New System.Drawing.Point(4, 178)
        Me.GroupBox_Scope.MaximumSize = New System.Drawing.Size(255, 280)
        Me.GroupBox_Scope.MinimumSize = New System.Drawing.Size(227, 183)
        Me.GroupBox_Scope.Name = "GroupBox_Scope"
        Me.GroupBox_Scope.Size = New System.Drawing.Size(255, 225)
        Me.GroupBox_Scope.TabIndex = 2
        Me.GroupBox_Scope.TabStop = False
        Me.GroupBox_Scope.Text = "AudioIn scope"
        '
        'tbar_ScopeTime
        '
        Me.tbar_ScopeTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbar_ScopeTime.AutoSize = False
        Me.tbar_ScopeTime.Location = New System.Drawing.Point(156, 192)
        Me.tbar_ScopeTime.Maximum = 9
        Me.tbar_ScopeTime.Name = "tbar_ScopeTime"
        Me.tbar_ScopeTime.Size = New System.Drawing.Size(92, 29)
        Me.tbar_ScopeTime.TabIndex = 41
        Me.tbar_ScopeTime.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tbar_ScopeTime.Value = 4
        '
        'tbar_ScopeVoltage
        '
        Me.tbar_ScopeVoltage.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tbar_ScopeVoltage.AutoSize = False
        Me.tbar_ScopeVoltage.Location = New System.Drawing.Point(9, 192)
        Me.tbar_ScopeVoltage.Maximum = 11
        Me.tbar_ScopeVoltage.Name = "tbar_ScopeVoltage"
        Me.tbar_ScopeVoltage.Size = New System.Drawing.Size(92, 29)
        Me.tbar_ScopeVoltage.TabIndex = 40
        Me.tbar_ScopeVoltage.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tbar_ScopeVoltage.Value = 3
        '
        'GroupBox_Bands
        '
        Me.GroupBox_Bands.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Bands.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_Bands.Controls.Add(Me.pbox_SpectrumHistory)
        Me.GroupBox_Bands.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Bands.Location = New System.Drawing.Point(398, 28)
        Me.GroupBox_Bands.Name = "GroupBox_Bands"
        Me.GroupBox_Bands.Size = New System.Drawing.Size(315, 144)
        Me.GroupBox_Bands.TabIndex = 3
        Me.GroupBox_Bands.TabStop = False
        Me.GroupBox_Bands.Text = "Spectrum history"
        '
        'pbox_SpectrumHistory
        '
        Me.pbox_SpectrumHistory.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pbox_SpectrumHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_SpectrumHistory.Location = New System.Drawing.Point(13, 22)
        Me.pbox_SpectrumHistory.Name = "pbox_SpectrumHistory"
        Me.pbox_SpectrumHistory.Size = New System.Drawing.Size(294, 114)
        Me.pbox_SpectrumHistory.TabIndex = 3
        Me.pbox_SpectrumHistory.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txt_UltrasoundFrequency)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.cmb_RadarType)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txt_MicrowaveFrequency)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(4, 81)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(255, 91)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Controls"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(18, 65)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(141, 13)
        Me.Label7.TabIndex = 239
        Me.Label7.Text = "Ultrasound frequency (KHz)"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(19, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 13)
        Me.Label6.TabIndex = 237
        Me.Label6.Text = "Doppler radar type"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox2.Controls.Add(Me.txt_SlotSpeed)
        Me.GroupBox2.Controls.Add(Me.lbl_SlotSpeed)
        Me.GroupBox2.Controls.Add(Me.txt_SlotSignal)
        Me.GroupBox2.Controls.Add(Me.lbl_SlotSignal)
        Me.GroupBox2.Controls.Add(Me.chk_Run)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(265, 28)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(127, 144)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Output controls"
        '
        'lbl_SlotSpeed
        '
        Me.lbl_SlotSpeed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_SlotSpeed.Location = New System.Drawing.Point(12, 56)
        Me.lbl_SlotSpeed.Name = "lbl_SlotSpeed"
        Me.lbl_SlotSpeed.Size = New System.Drawing.Size(60, 13)
        Me.lbl_SlotSpeed.TabIndex = 136
        Me.lbl_SlotSpeed.Text = "Slot speed"
        Me.lbl_SlotSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_SlotSignal
        '
        Me.lbl_SlotSignal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_SlotSignal.Location = New System.Drawing.Point(12, 30)
        Me.lbl_SlotSignal.Name = "lbl_SlotSignal"
        Me.lbl_SlotSignal.Size = New System.Drawing.Size(60, 13)
        Me.lbl_SlotSignal.TabIndex = 137
        Me.lbl_SlotSignal.Text = "Slot signal"
        Me.lbl_SlotSignal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tools_SaveTotal, Me.ToolStripSeparator2, Me.Tools_SaveSpectrum, Me.ToolStripSeparator1, Me.Tools_SaveSpectrumLog, Me.ToolStripSeparator3, Me.Tools_OpenSaveFolder})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(720, 25)
        Me.ToolStrip1.TabIndex = 74
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tools_SaveTotal
        '
        Me.Tools_SaveTotal.Image = CType(resources.GetObject("Tools_SaveTotal.Image"), System.Drawing.Image)
        Me.Tools_SaveTotal.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveTotal.Name = "Tools_SaveTotal"
        Me.Tools_SaveTotal.Size = New System.Drawing.Size(114, 22)
        Me.Tools_SaveTotal.Text = "Save total image"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveSpectrum
        '
        Me.Tools_SaveSpectrum.Image = CType(resources.GetObject("Tools_SaveSpectrum.Image"), System.Drawing.Image)
        Me.Tools_SaveSpectrum.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveSpectrum.Name = "Tools_SaveSpectrum"
        Me.Tools_SaveSpectrum.Size = New System.Drawing.Size(140, 22)
        Me.Tools_SaveSpectrum.Text = "Save spectrum image"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveSpectrumLog
        '
        Me.Tools_SaveSpectrumLog.Image = CType(resources.GetObject("Tools_SaveSpectrumLog.Image"), System.Drawing.Image)
        Me.Tools_SaveSpectrumLog.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveSpectrumLog.Name = "Tools_SaveSpectrumLog"
        Me.Tools_SaveSpectrumLog.Size = New System.Drawing.Size(124, 22)
        Me.Tools_SaveSpectrumLog.Text = "Save spectrum log"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_OpenSaveFolder
        '
        Me.Tools_OpenSaveFolder.Image = CType(resources.GetObject("Tools_OpenSaveFolder.Image"), System.Drawing.Image)
        Me.Tools_OpenSaveFolder.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_OpenSaveFolder.Name = "Tools_OpenSaveFolder"
        Me.Tools_OpenSaveFolder.Size = New System.Drawing.Size(116, 22)
        Me.Tools_OpenSaveFolder.Text = "Open save folder"
        '
        'txt_SlotSpeed
        '
        Me.txt_SlotSpeed.ArrowsIncrement = 1
        Me.txt_SlotSpeed.BackColor = System.Drawing.Color.MintCream
        Me.txt_SlotSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotSpeed.DimFactorGray = -65
        Me.txt_SlotSpeed.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotSpeed.Increment = 0.1
        Me.txt_SlotSpeed.Location = New System.Drawing.Point(77, 54)
        Me.txt_SlotSpeed.MaxValue = 999
        Me.txt_SlotSpeed.MinValue = -1
        Me.txt_SlotSpeed.Name = "txt_SlotSpeed"
        Me.txt_SlotSpeed.NumericValue = 2
        Me.txt_SlotSpeed.NumericValueInteger = 2
        Me.txt_SlotSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotSpeed.RoundingStep = 0
        Me.txt_SlotSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotSpeed.Size = New System.Drawing.Size(32, 16)
        Me.txt_SlotSpeed.TabIndex = 138
        Me.txt_SlotSpeed.Text = "2"
        Me.txt_SlotSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotSignal
        '
        Me.txt_SlotSignal.ArrowsIncrement = 1
        Me.txt_SlotSignal.BackColor = System.Drawing.Color.MintCream
        Me.txt_SlotSignal.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotSignal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotSignal.DimFactorGray = -65
        Me.txt_SlotSignal.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotSignal.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotSignal.Increment = 0.1
        Me.txt_SlotSignal.Location = New System.Drawing.Point(77, 29)
        Me.txt_SlotSignal.MaxValue = 999
        Me.txt_SlotSignal.MinValue = -1
        Me.txt_SlotSignal.Name = "txt_SlotSignal"
        Me.txt_SlotSignal.NumericValue = 1
        Me.txt_SlotSignal.NumericValueInteger = 1
        Me.txt_SlotSignal.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotSignal.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotSignal.RoundingStep = 0
        Me.txt_SlotSignal.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotSignal.Size = New System.Drawing.Size(32, 16)
        Me.txt_SlotSignal.TabIndex = 139
        Me.txt_SlotSignal.Text = "1"
        Me.txt_SlotSignal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_Run
        '
        Me.chk_Run.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Run.CenterPtTracker = DesignerRectTracker13
        Me.chk_Run.CheckButton = True
        Me.chk_Run.Checked = True
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Run.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Run.ColorFillBlendChecked = CBlendItems14
        Me.chk_Run.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Run.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Run.Corners.All = CType(6, Short)
        Me.chk_Run.Corners.LowerLeft = CType(6, Short)
        Me.chk_Run.Corners.LowerRight = CType(6, Short)
        Me.chk_Run.Corners.UpperLeft = CType(6, Short)
        Me.chk_Run.Corners.UpperRight = CType(6, Short)
        Me.chk_Run.DimFactorOver = 30
        Me.chk_Run.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_Run.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_Run.FocalPoints.CenterPtX = 1.0!
        Me.chk_Run.FocalPoints.CenterPtY = 1.0!
        Me.chk_Run.FocalPoints.FocusPtX = 0.0!
        Me.chk_Run.FocalPoints.FocusPtY = 0.0!
        Me.chk_Run.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Run.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Run.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Run.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Run.FocusPtTracker = DesignerRectTracker14
        Me.chk_Run.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Run.Image = Nothing
        Me.chk_Run.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Run.ImageIndex = 0
        Me.chk_Run.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Run.Location = New System.Drawing.Point(15, 103)
        Me.chk_Run.Name = "chk_Run"
        Me.chk_Run.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.chk_Run.SideImage = Nothing
        Me.chk_Run.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Run.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Run.Size = New System.Drawing.Size(92, 27)
        Me.chk_Run.TabIndex = 135
        Me.chk_Run.Text = "Run"
        Me.chk_Run.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Run.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Run.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Run.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_UltrasoundFrequency
        '
        Me.txt_UltrasoundFrequency.ArrowsIncrement = 0.1
        Me.txt_UltrasoundFrequency.BackColor = System.Drawing.Color.MintCream
        Me.txt_UltrasoundFrequency.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_UltrasoundFrequency.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_UltrasoundFrequency.Decimals = 2
        Me.txt_UltrasoundFrequency.DimFactorGray = -65
        Me.txt_UltrasoundFrequency.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_UltrasoundFrequency.ForeColor = System.Drawing.Color.Black
        Me.txt_UltrasoundFrequency.Increment = 0.01
        Me.txt_UltrasoundFrequency.Location = New System.Drawing.Point(165, 64)
        Me.txt_UltrasoundFrequency.MaxValue = 999
        Me.txt_UltrasoundFrequency.MinValue = 0.1
        Me.txt_UltrasoundFrequency.Name = "txt_UltrasoundFrequency"
        Me.txt_UltrasoundFrequency.NumericValue = 40
        Me.txt_UltrasoundFrequency.NumericValueInteger = 40
        Me.txt_UltrasoundFrequency.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_UltrasoundFrequency.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_UltrasoundFrequency.RoundingStep = 0
        Me.txt_UltrasoundFrequency.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_UltrasoundFrequency.Size = New System.Drawing.Size(72, 16)
        Me.txt_UltrasoundFrequency.TabIndex = 238
        Me.txt_UltrasoundFrequency.Text = "40.0"
        Me.txt_UltrasoundFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmb_RadarType
        '
        Me.cmb_RadarType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_RadarType.ArrowColor = System.Drawing.Color.DarkGray
        Me.cmb_RadarType.BackColor = System.Drawing.Color.FloralWhite
        Me.cmb_RadarType.BackColor_Focused = System.Drawing.Color.FloralWhite
        Me.cmb_RadarType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_RadarType.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_RadarType.BorderSize = 1
        Me.cmb_RadarType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_RadarType.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.cmb_RadarType.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.cmb_RadarType.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.cmb_RadarType.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmb_RadarType.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.cmb_RadarType.DropDownHeight = 500
        Me.cmb_RadarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_RadarType.DropDownWidth = 105
        Me.cmb_RadarType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_RadarType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_RadarType.ForeColor = System.Drawing.Color.Black
        Me.cmb_RadarType.IntegralHeight = False
        Me.cmb_RadarType.ItemHeight = 11
        Me.cmb_RadarType.Items.AddRange(New Object() {"Microwaves", "Ultrasounds"})
        Me.cmb_RadarType.Location = New System.Drawing.Point(132, 20)
        Me.cmb_RadarType.Name = "cmb_RadarType"
        Me.cmb_RadarType.ShadowColor = System.Drawing.Color.LightGray
        Me.cmb_RadarType.Size = New System.Drawing.Size(105, 17)
        Me.cmb_RadarType.TabIndex = 236
        Me.cmb_RadarType.TextPosition = 1
        '
        'txt_MicrowaveFrequency
        '
        Me.txt_MicrowaveFrequency.ArrowsIncrement = 0.1
        Me.txt_MicrowaveFrequency.BackColor = System.Drawing.Color.MintCream
        Me.txt_MicrowaveFrequency.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MicrowaveFrequency.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MicrowaveFrequency.Decimals = 3
        Me.txt_MicrowaveFrequency.DimFactorGray = -65
        Me.txt_MicrowaveFrequency.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MicrowaveFrequency.ForeColor = System.Drawing.Color.Black
        Me.txt_MicrowaveFrequency.Increment = 0.01
        Me.txt_MicrowaveFrequency.Location = New System.Drawing.Point(165, 44)
        Me.txt_MicrowaveFrequency.MaxValue = 999
        Me.txt_MicrowaveFrequency.MinValue = 0.1
        Me.txt_MicrowaveFrequency.Name = "txt_MicrowaveFrequency"
        Me.txt_MicrowaveFrequency.NumericValue = 10.525
        Me.txt_MicrowaveFrequency.NumericValueInteger = 11
        Me.txt_MicrowaveFrequency.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MicrowaveFrequency.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MicrowaveFrequency.RoundingStep = 0
        Me.txt_MicrowaveFrequency.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MicrowaveFrequency.Size = New System.Drawing.Size(72, 16)
        Me.txt_MicrowaveFrequency.TabIndex = 12
        Me.txt_MicrowaveFrequency.Text = "10.525"
        Me.txt_MicrowaveFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_ScopeNeg
        '
        Me.chk_ScopeNeg.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_ScopeNeg.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_ScopeNeg.CenterPtTracker = DesignerRectTracker11
        Me.chk_ScopeNeg.CheckButton = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_ScopeNeg.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_ScopeNeg.ColorFillBlendChecked = CBlendItems12
        Me.chk_ScopeNeg.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_ScopeNeg.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_ScopeNeg.Corners.All = CType(6, Short)
        Me.chk_ScopeNeg.Corners.LowerLeft = CType(6, Short)
        Me.chk_ScopeNeg.Corners.LowerRight = CType(6, Short)
        Me.chk_ScopeNeg.Corners.UpperLeft = CType(6, Short)
        Me.chk_ScopeNeg.Corners.UpperRight = CType(6, Short)
        Me.chk_ScopeNeg.DimFactorOver = 30
        Me.chk_ScopeNeg.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_ScopeNeg.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_ScopeNeg.FocalPoints.CenterPtX = 1.0!
        Me.chk_ScopeNeg.FocalPoints.CenterPtY = 1.0!
        Me.chk_ScopeNeg.FocalPoints.FocusPtX = 0.0!
        Me.chk_ScopeNeg.FocalPoints.FocusPtY = 0.0!
        Me.chk_ScopeNeg.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_ScopeNeg.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_ScopeNeg.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_ScopeNeg.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_ScopeNeg.FocusPtTracker = DesignerRectTracker12
        Me.chk_ScopeNeg.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ScopeNeg.Image = Nothing
        Me.chk_ScopeNeg.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ScopeNeg.ImageIndex = 0
        Me.chk_ScopeNeg.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_ScopeNeg.Location = New System.Drawing.Point(111, 201)
        Me.chk_ScopeNeg.Name = "chk_ScopeNeg"
        Me.chk_ScopeNeg.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.chk_ScopeNeg.SideImage = Nothing
        Me.chk_ScopeNeg.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ScopeNeg.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_ScopeNeg.Size = New System.Drawing.Size(39, 18)
        Me.chk_ScopeNeg.TabIndex = 42
        Me.chk_ScopeNeg.Text = "Neg."
        Me.chk_ScopeNeg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ScopeNeg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_ScopeNeg.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_ScopeNeg.TextShadow = System.Drawing.Color.Transparent
        '
        'cmb_AudioInDevices
        '
        Me.cmb_AudioInDevices.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_AudioInDevices.ArrowColor = System.Drawing.Color.DarkGray
        Me.cmb_AudioInDevices.BackColor = System.Drawing.Color.FloralWhite
        Me.cmb_AudioInDevices.BackColor_Focused = System.Drawing.Color.FloralWhite
        Me.cmb_AudioInDevices.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_AudioInDevices.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_AudioInDevices.BorderSize = 1
        Me.cmb_AudioInDevices.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_AudioInDevices.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.cmb_AudioInDevices.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.cmb_AudioInDevices.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.cmb_AudioInDevices.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmb_AudioInDevices.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.cmb_AudioInDevices.DropDownHeight = 500
        Me.cmb_AudioInDevices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_AudioInDevices.DropDownWidth = 180
        Me.cmb_AudioInDevices.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_AudioInDevices.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_AudioInDevices.ForeColor = System.Drawing.Color.Black
        Me.cmb_AudioInDevices.IntegralHeight = False
        Me.cmb_AudioInDevices.ItemHeight = 11
        Me.cmb_AudioInDevices.Items.AddRange(New Object() {"Auto"})
        Me.cmb_AudioInDevices.Location = New System.Drawing.Point(11, 22)
        Me.cmb_AudioInDevices.Name = "cmb_AudioInDevices"
        Me.cmb_AudioInDevices.ShadowColor = System.Drawing.Color.LightGray
        Me.cmb_AudioInDevices.Size = New System.Drawing.Size(141, 17)
        Me.cmb_AudioInDevices.TabIndex = 235
        Me.cmb_AudioInDevices.TextPosition = 1
        '
        'btn_AudioInputs
        '
        Me.btn_AudioInputs.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_AudioInputs.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AudioInputs.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.btn_AudioInputs.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.btn_AudioInputs.ColorFillBlendChecked = CBlendItems10
        Me.btn_AudioInputs.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_AudioInputs.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_AudioInputs.Corners.All = CType(6, Short)
        Me.btn_AudioInputs.Corners.LowerLeft = CType(6, Short)
        Me.btn_AudioInputs.Corners.LowerRight = CType(6, Short)
        Me.btn_AudioInputs.Corners.UpperLeft = CType(6, Short)
        Me.btn_AudioInputs.Corners.UpperRight = CType(6, Short)
        Me.btn_AudioInputs.DimFactorOver = 30
        Me.btn_AudioInputs.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.btn_AudioInputs.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.btn_AudioInputs.FocalPoints.CenterPtX = 1.0!
        Me.btn_AudioInputs.FocalPoints.CenterPtY = 1.0!
        Me.btn_AudioInputs.FocalPoints.FocusPtX = 0.0!
        Me.btn_AudioInputs.FocalPoints.FocusPtY = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AudioInputs.FocusPtTracker = DesignerRectTracker10
        Me.btn_AudioInputs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AudioInputs.Image = Nothing
        Me.btn_AudioInputs.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.ImageIndex = 0
        Me.btn_AudioInputs.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_AudioInputs.Location = New System.Drawing.Point(158, 21)
        Me.btn_AudioInputs.Name = "btn_AudioInputs"
        Me.btn_AudioInputs.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.btn_AudioInputs.SideImage = Nothing
        Me.btn_AudioInputs.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_AudioInputs.Size = New System.Drawing.Size(79, 18)
        Me.btn_AudioInputs.TabIndex = 234
        Me.btn_AudioInputs.Text = "Audio inputs"
        Me.btn_AudioInputs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_AudioInputs.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_AudioInputs.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Clear
        '
        Me.btn_Clear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Clear.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_Clear.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Clear.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.btn_Clear.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.btn_Clear.ColorFillBlendChecked = CBlendItems2
        Me.btn_Clear.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Clear.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Clear.Corners.All = CType(1, Short)
        Me.btn_Clear.Corners.LowerLeft = CType(1, Short)
        Me.btn_Clear.Corners.LowerRight = CType(1, Short)
        Me.btn_Clear.Corners.UpperLeft = CType(1, Short)
        Me.btn_Clear.Corners.UpperRight = CType(1, Short)
        Me.btn_Clear.DimFactorOver = 30
        Me.btn_Clear.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.btn_Clear.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.btn_Clear.FocalPoints.CenterPtX = 1.0!
        Me.btn_Clear.FocalPoints.CenterPtY = 1.0!
        Me.btn_Clear.FocalPoints.FocusPtX = 0.0!
        Me.btn_Clear.FocalPoints.FocusPtY = 0.0!
        Me.btn_Clear.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Clear.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Clear.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Clear.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Clear.FocusPtTracker = DesignerRectTracker2
        Me.btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear.Image = Nothing
        Me.btn_Clear.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Clear.ImageIndex = 0
        Me.btn_Clear.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Clear.Location = New System.Drawing.Point(402, 16)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.btn_Clear.SideImage = Nothing
        Me.btn_Clear.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Clear.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Clear.Size = New System.Drawing.Size(36, 17)
        Me.btn_Clear.TabIndex = 235
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Clear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Clear.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Clear.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_SpecSpeedDw
        '
        Me.txt_SpecSpeedDw.ArrowsIncrement = 1
        Me.txt_SpecSpeedDw.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecSpeedDw.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecSpeedDw.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecSpeedDw.DimFactorGray = -65
        Me.txt_SpecSpeedDw.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecSpeedDw.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecSpeedDw.Increment = 0.02
        Me.txt_SpecSpeedDw.Location = New System.Drawing.Point(65, 120)
        Me.txt_SpecSpeedDw.MaxValue = 100
        Me.txt_SpecSpeedDw.MinValue = 0
        Me.txt_SpecSpeedDw.Name = "txt_SpecSpeedDw"
        Me.txt_SpecSpeedDw.NumericValue = 100
        Me.txt_SpecSpeedDw.NumericValueInteger = 100
        Me.txt_SpecSpeedDw.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecSpeedDw.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecSpeedDw.RoundingStep = 0
        Me.txt_SpecSpeedDw.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecSpeedDw.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecSpeedDw.TabIndex = 137
        Me.txt_SpecSpeedDw.Text = "100"
        Me.txt_SpecSpeedDw.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_SpecAutoScale
        '
        Me.chk_SpecAutoScale.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecAutoScale.CenterPtTracker = DesignerRectTracker3
        Me.chk_SpecAutoScale.CheckButton = True
        Me.chk_SpecAutoScale.Checked = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_SpecAutoScale.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_SpecAutoScale.ColorFillBlendChecked = CBlendItems4
        Me.chk_SpecAutoScale.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_SpecAutoScale.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_SpecAutoScale.Corners.All = CType(6, Short)
        Me.chk_SpecAutoScale.Corners.LowerLeft = CType(6, Short)
        Me.chk_SpecAutoScale.Corners.LowerRight = CType(6, Short)
        Me.chk_SpecAutoScale.Corners.UpperLeft = CType(6, Short)
        Me.chk_SpecAutoScale.Corners.UpperRight = CType(6, Short)
        Me.chk_SpecAutoScale.DimFactorOver = 30
        Me.chk_SpecAutoScale.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecAutoScale.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecAutoScale.FocalPoints.CenterPtX = 1.0!
        Me.chk_SpecAutoScale.FocalPoints.CenterPtY = 1.0!
        Me.chk_SpecAutoScale.FocalPoints.FocusPtX = 0.0!
        Me.chk_SpecAutoScale.FocalPoints.FocusPtY = 0.0!
        Me.chk_SpecAutoScale.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_SpecAutoScale.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_SpecAutoScale.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_SpecAutoScale.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecAutoScale.FocusPtTracker = DesignerRectTracker4
        Me.chk_SpecAutoScale.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_SpecAutoScale.Image = Nothing
        Me.chk_SpecAutoScale.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecAutoScale.ImageIndex = 0
        Me.chk_SpecAutoScale.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_SpecAutoScale.Location = New System.Drawing.Point(17, 164)
        Me.chk_SpecAutoScale.Name = "chk_SpecAutoScale"
        Me.chk_SpecAutoScale.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.chk_SpecAutoScale.SideImage = Nothing
        Me.chk_SpecAutoScale.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecAutoScale.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_SpecAutoScale.Size = New System.Drawing.Size(92, 16)
        Me.chk_SpecAutoScale.TabIndex = 136
        Me.chk_SpecAutoScale.Text = "Auto scale"
        Me.chk_SpecAutoScale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecAutoScale.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_SpecAutoScale.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_SpecAutoScale.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_SpecLogY
        '
        Me.chk_SpecLogY.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecLogY.CenterPtTracker = DesignerRectTracker5
        Me.chk_SpecLogY.CheckButton = True
        Me.chk_SpecLogY.Checked = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_SpecLogY.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_SpecLogY.ColorFillBlendChecked = CBlendItems6
        Me.chk_SpecLogY.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_SpecLogY.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_SpecLogY.Corners.All = CType(6, Short)
        Me.chk_SpecLogY.Corners.LowerLeft = CType(6, Short)
        Me.chk_SpecLogY.Corners.LowerRight = CType(6, Short)
        Me.chk_SpecLogY.Corners.UpperLeft = CType(6, Short)
        Me.chk_SpecLogY.Corners.UpperRight = CType(6, Short)
        Me.chk_SpecLogY.DimFactorOver = 30
        Me.chk_SpecLogY.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecLogY.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecLogY.FocalPoints.CenterPtX = 1.0!
        Me.chk_SpecLogY.FocalPoints.CenterPtY = 1.0!
        Me.chk_SpecLogY.FocalPoints.FocusPtX = 0.0!
        Me.chk_SpecLogY.FocalPoints.FocusPtY = 0.0!
        Me.chk_SpecLogY.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_SpecLogY.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_SpecLogY.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_SpecLogY.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecLogY.FocusPtTracker = DesignerRectTracker6
        Me.chk_SpecLogY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_SpecLogY.Image = Nothing
        Me.chk_SpecLogY.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogY.ImageIndex = 0
        Me.chk_SpecLogY.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_SpecLogY.Location = New System.Drawing.Point(65, 142)
        Me.chk_SpecLogY.Name = "chk_SpecLogY"
        Me.chk_SpecLogY.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.chk_SpecLogY.SideImage = Nothing
        Me.chk_SpecLogY.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogY.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_SpecLogY.Size = New System.Drawing.Size(44, 16)
        Me.chk_SpecLogY.TabIndex = 135
        Me.chk_SpecLogY.Text = "Log Y"
        Me.chk_SpecLogY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogY.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_SpecLogY.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_SpecLogY.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_SpecLogX
        '
        Me.chk_SpecLogX.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecLogX.CenterPtTracker = DesignerRectTracker7
        Me.chk_SpecLogX.CheckButton = True
        Me.chk_SpecLogX.Checked = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_SpecLogX.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_SpecLogX.ColorFillBlendChecked = CBlendItems8
        Me.chk_SpecLogX.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_SpecLogX.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_SpecLogX.Corners.All = CType(6, Short)
        Me.chk_SpecLogX.Corners.LowerLeft = CType(6, Short)
        Me.chk_SpecLogX.Corners.LowerRight = CType(6, Short)
        Me.chk_SpecLogX.Corners.UpperLeft = CType(6, Short)
        Me.chk_SpecLogX.Corners.UpperRight = CType(6, Short)
        Me.chk_SpecLogX.DimFactorOver = 30
        Me.chk_SpecLogX.FillType = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecLogX.FillTypeChecked = Theremino_DopplerMeter.MyButton.eFillType.LinearVertical
        Me.chk_SpecLogX.FocalPoints.CenterPtX = 1.0!
        Me.chk_SpecLogX.FocalPoints.CenterPtY = 1.0!
        Me.chk_SpecLogX.FocalPoints.FocusPtX = 0.0!
        Me.chk_SpecLogX.FocalPoints.FocusPtY = 0.0!
        Me.chk_SpecLogX.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_SpecLogX.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_SpecLogX.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_SpecLogX.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SpecLogX.FocusPtTracker = DesignerRectTracker8
        Me.chk_SpecLogX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_SpecLogX.Image = Nothing
        Me.chk_SpecLogX.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogX.ImageIndex = 0
        Me.chk_SpecLogX.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_SpecLogX.Location = New System.Drawing.Point(17, 142)
        Me.chk_SpecLogX.Name = "chk_SpecLogX"
        Me.chk_SpecLogX.Shape = Theremino_DopplerMeter.MyButton.eShape.Rectangle
        Me.chk_SpecLogX.SideImage = Nothing
        Me.chk_SpecLogX.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogX.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_SpecLogX.Size = New System.Drawing.Size(44, 16)
        Me.chk_SpecLogX.TabIndex = 134
        Me.chk_SpecLogX.Text = "Log X"
        Me.chk_SpecLogX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SpecLogX.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_SpecLogX.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_SpecLogX.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_SpecSpeedUp
        '
        Me.txt_SpecSpeedUp.ArrowsIncrement = 1
        Me.txt_SpecSpeedUp.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecSpeedUp.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecSpeedUp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecSpeedUp.DimFactorGray = -65
        Me.txt_SpecSpeedUp.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecSpeedUp.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecSpeedUp.Increment = 0.02
        Me.txt_SpecSpeedUp.Location = New System.Drawing.Point(65, 101)
        Me.txt_SpecSpeedUp.MaxValue = 100
        Me.txt_SpecSpeedUp.MinValue = 1
        Me.txt_SpecSpeedUp.Name = "txt_SpecSpeedUp"
        Me.txt_SpecSpeedUp.NumericValue = 100
        Me.txt_SpecSpeedUp.NumericValueInteger = 100
        Me.txt_SpecSpeedUp.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecSpeedUp.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecSpeedUp.RoundingStep = 0
        Me.txt_SpecSpeedUp.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecSpeedUp.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecSpeedUp.TabIndex = 64
        Me.txt_SpecSpeedUp.Text = "100"
        Me.txt_SpecSpeedUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmb_Spec_Window
        '
        Me.cmb_Spec_Window.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmb_Spec_Window.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Spec_Window.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Spec_Window.BackColor = System.Drawing.Color.MintCream
        Me.cmb_Spec_Window.BackColor_Focused = System.Drawing.Color.MintCream
        Me.cmb_Spec_Window.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_Spec_Window.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_Spec_Window.BorderSize = 1
        Me.cmb_Spec_Window.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Spec_Window.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Spec_Window.DropDown_BackSelected = System.Drawing.Color.LightBlue
        Me.cmb_Spec_Window.DropDown_BorderColor = System.Drawing.Color.Gainsboro
        Me.cmb_Spec_Window.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Spec_Window.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_Spec_Window.DropDownHeight = 400
        Me.cmb_Spec_Window.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Spec_Window.DropDownWidth = 60
        Me.cmb_Spec_Window.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_Spec_Window.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Spec_Window.ForeColor = System.Drawing.Color.Black
        Me.cmb_Spec_Window.IntegralHeight = False
        Me.cmb_Spec_Window.ItemHeight = 12
        Me.cmb_Spec_Window.Location = New System.Drawing.Point(12, 200)
        Me.cmb_Spec_Window.MaxDropDownItems = 99
        Me.cmb_Spec_Window.Name = "cmb_Spec_Window"
        Me.cmb_Spec_Window.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Spec_Window.Size = New System.Drawing.Size(99, 18)
        Me.cmb_Spec_Window.TabIndex = 67
        Me.cmb_Spec_Window.TextPosition = 2
        '
        'txt_SpecMaxDb
        '
        Me.txt_SpecMaxDb.ArrowsIncrement = 1
        Me.txt_SpecMaxDb.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecMaxDb.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecMaxDb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecMaxDb.DimFactorGray = -65
        Me.txt_SpecMaxDb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecMaxDb.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecMaxDb.Increment = 0.1
        Me.txt_SpecMaxDb.Location = New System.Drawing.Point(65, 24)
        Me.txt_SpecMaxDb.MaxValue = 0
        Me.txt_SpecMaxDb.MinValue = -120
        Me.txt_SpecMaxDb.Name = "txt_SpecMaxDb"
        Me.txt_SpecMaxDb.NumericValue = 0
        Me.txt_SpecMaxDb.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecMaxDb.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecMaxDb.RoundingStep = 0
        Me.txt_SpecMaxDb.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecMaxDb.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecMaxDb.TabIndex = 60
        Me.txt_SpecMaxDb.Text = "0"
        Me.txt_SpecMaxDb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SpecMinDb
        '
        Me.txt_SpecMinDb.ArrowsIncrement = 1
        Me.txt_SpecMinDb.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecMinDb.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecMinDb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecMinDb.DimFactorGray = -65
        Me.txt_SpecMinDb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecMinDb.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecMinDb.Increment = 0.1
        Me.txt_SpecMinDb.Location = New System.Drawing.Point(65, 43)
        Me.txt_SpecMinDb.MaxValue = 0
        Me.txt_SpecMinDb.MinValue = -120
        Me.txt_SpecMinDb.Name = "txt_SpecMinDb"
        Me.txt_SpecMinDb.NumericValue = -100
        Me.txt_SpecMinDb.NumericValueInteger = -100
        Me.txt_SpecMinDb.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecMinDb.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecMinDb.RoundingStep = 0
        Me.txt_SpecMinDb.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecMinDb.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecMinDb.TabIndex = 61
        Me.txt_SpecMinDb.Text = "-100"
        Me.txt_SpecMinDb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SpecMinFreq
        '
        Me.txt_SpecMinFreq.ArrowsIncrement = 1
        Me.txt_SpecMinFreq.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecMinFreq.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecMinFreq.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecMinFreq.DimFactorGray = -65
        Me.txt_SpecMinFreq.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecMinFreq.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecMinFreq.Increment = 1
        Me.txt_SpecMinFreq.Location = New System.Drawing.Point(65, 82)
        Me.txt_SpecMinFreq.MaxValue = 22000
        Me.txt_SpecMinFreq.MinValue = 1
        Me.txt_SpecMinFreq.Name = "txt_SpecMinFreq"
        Me.txt_SpecMinFreq.NumericValue = 50
        Me.txt_SpecMinFreq.NumericValueInteger = 50
        Me.txt_SpecMinFreq.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecMinFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecMinFreq.RoundingStep = 0
        Me.txt_SpecMinFreq.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecMinFreq.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecMinFreq.TabIndex = 63
        Me.txt_SpecMinFreq.Text = "50"
        Me.txt_SpecMinFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SpecMaxFreq
        '
        Me.txt_SpecMaxFreq.ArrowsIncrement = 1
        Me.txt_SpecMaxFreq.BackColor = System.Drawing.Color.MintCream
        Me.txt_SpecMaxFreq.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SpecMaxFreq.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SpecMaxFreq.DimFactorGray = -65
        Me.txt_SpecMaxFreq.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SpecMaxFreq.ForeColor = System.Drawing.Color.Black
        Me.txt_SpecMaxFreq.Increment = 1
        Me.txt_SpecMaxFreq.Location = New System.Drawing.Point(65, 63)
        Me.txt_SpecMaxFreq.MaxValue = 22000
        Me.txt_SpecMaxFreq.MinValue = 1
        Me.txt_SpecMaxFreq.Name = "txt_SpecMaxFreq"
        Me.txt_SpecMaxFreq.NumericValue = 1000
        Me.txt_SpecMaxFreq.NumericValueInteger = 1000
        Me.txt_SpecMaxFreq.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SpecMaxFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SpecMaxFreq.RoundingStep = 0
        Me.txt_SpecMaxFreq.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SpecMaxFreq.Size = New System.Drawing.Size(46, 16)
        Me.txt_SpecMaxFreq.TabIndex = 62
        Me.txt_SpecMaxFreq.Text = "1000"
        Me.txt_SpecMaxFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(720, 407)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox_Bands)
        Me.Controls.Add(Me.GroupBox_Scope)
        Me.Controls.Add(Me.GroupBox_AudioOut)
        Me.Controls.Add(Me.GroupBox_Spectrum)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(640, 446)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino DopplerMeter"
        CType(Me.pbox_Scope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox_Spectrum, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Spectrum.ResumeLayout(False)
        Me.GroupBox_Spectrum.PerformLayout()
        Me.GroupBox_AudioOut.ResumeLayout(False)
        Me.GroupBox_Scope.ResumeLayout(False)
        CType(Me.tbar_ScopeTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbar_ScopeVoltage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Bands.ResumeLayout(False)
        CType(Me.pbox_SpectrumHistory, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents pbox_Scope As System.Windows.Forms.PictureBox
    Friend WithEvents pbox_Spectrum As System.Windows.Forms.PictureBox
    Friend WithEvents lbl_MaxDb As System.Windows.Forms.Label
    Friend WithEvents txt_SpecMaxDb As MyTextBox
    Friend WithEvents lbl_MinDb As System.Windows.Forms.Label
    Friend WithEvents txt_SpecMinDb As MyTextBox
    Friend WithEvents lbl_MaxFreq As System.Windows.Forms.Label
    Friend WithEvents txt_SpecMaxFreq As MyTextBox
    Friend WithEvents lbl_MinFreq As System.Windows.Forms.Label
    Friend WithEvents txt_SpecMinFreq As MyTextBox
    Friend WithEvents GroupBox_Spectrum As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_AudioOut As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Scope As System.Windows.Forms.GroupBox
    Friend WithEvents txt_MicrowaveFrequency As MyTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbar_ScopeVoltage As System.Windows.Forms.TrackBar
    Friend WithEvents tbar_ScopeTime As System.Windows.Forms.TrackBar
    Friend WithEvents GroupBox_Bands As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_Spec_Window As MyComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_SpecSpeedUp As MyTextBox
    Friend WithEvents lbl_SpeedUp As System.Windows.Forms.Label
    Friend WithEvents chk_ScopeNeg As MyButton
    Friend WithEvents chk_SpecLogY As MyButton
    Friend WithEvents chk_SpecLogX As MyButton
    Friend WithEvents pbox_SpectrumHistory As System.Windows.Forms.PictureBox
    Friend WithEvents chk_Run As MyButton
    Friend WithEvents chk_SpecAutoScale As MyButton
    Friend WithEvents txt_SpecSpeedDw As MyTextBox
    Friend WithEvents lbl_SpeedDw As System.Windows.Forms.Label
    Friend WithEvents cmb_AudioInDevices As MyComboBox
    Friend WithEvents btn_AudioInputs As MyButton
    Friend WithEvents cmb_RadarType As MyComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_UltrasoundFrequency As MyTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_SlotSpeed As Theremino_DopplerMeter.MyTextBox
    Friend WithEvents lbl_SlotSpeed As System.Windows.Forms.Label
    Friend WithEvents txt_SlotSignal As Theremino_DopplerMeter.MyTextBox
    Friend WithEvents lbl_SlotSignal As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents Tools_SaveSpectrumLog As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Tools_SaveSpectrum As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tools_SaveTotal As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Tools_OpenSaveFolder As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_Clear As Theremino_DopplerMeter.MyButton

End Class
