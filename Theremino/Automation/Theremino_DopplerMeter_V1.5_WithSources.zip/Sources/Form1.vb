﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        Text = AppTitleAndVersion("")
        ' --------------------------------------------------------
        Combo_InitFromEnum(cmb_Spec_Window, GetType(FHT.WindowTypes))
        Combo_SetIndex(cmb_Spec_Window, 15)
        ' --------------------------------------------------------
        Combo_SetIndex(cmb_RadarType, 0)
        Combo_SetIndex(cmb_AudioInDevices, 0)
        Load_INI()
        FillRadarTypeCombo()
        FillAudioDevicesCombo()
        ' --------------------------------------------------------
        Scope.Initialize(pbox_Scope, SelectedAudioIn)
        Spectrum.Initialize(pbox_Spectrum, SelectedAudioIn)
        ' --------------------------------------------------------
        ScopeTrim()
        SetAllSpectrumParams()
        SetSpeedCoefficient()
        ' --------------------------------------------------------
        Scope.Initialize(pbox_Scope, SelectedAudioIn)
        Spectrum.Initialize(pbox_Spectrum, SelectedAudioIn)
        ' -------------------------------------------------------- TIMER START
        Timer1.Interval = 50
        Timer1.Start()
        ' -------------------------------------------------------- CPU Affinity test
        'Dim Proc As Process = Process.GetCurrentProcess()
        'For i As Int32 = 0 To Proc.Threads.Count
        '    Dim Thread As ProcessThread = Proc.Threads(0)
        '    Dim AffinityMask As Int32 = 2  ' use only flagged processors, despite availability
        '    Thread.ProcessorAffinity = CType(AffinityMask, IntPtr)
        'Next
        ' --------------------------------------------------------
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Scope.CloseAll()
        Spectrum.CloseAll()
        Save_INI()
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        UpdateAll()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        UpdateAll()
    End Sub

    Private Sub UpdateAll()
        ReportString = ""
        ' ----------------------------------------------------- scope update
        Scope.Update(pbox_Scope, chk_ScopeNeg.Checked)
        ' ----------------------------------------------------- spectrum update
        Spectrum.Update()
        ' ----------------------------------------------------- spectrum autoscale
        If chk_SpecAutoScale.Checked Then
            txt_SpecMaxDb.NumericValue = Spectrum.GetDbMax
            txt_SpecMinDb.NumericValue = Spectrum.GetDbMin
        End If
        ' ----------------------------------------------------- report string
        If ReportString <> "" Then Text = ReportString
    End Sub


    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    'Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
    '    Dim bounds As New Rectangle(0, 0, _
    '                                MenuStrip1.Width, MenuStrip1.Height)
    '    Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
    '                                                   Color.FromArgb(230, 230, 230), _
    '                                                   Color.FromArgb(200, 200, 200), _
    '                                                   Drawing2D.LinearGradientMode.Horizontal)
    '    e.Graphics.FillRectangle(brush, bounds)
    'End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub

    ' =======================================================================================
    '   TOOLSTRIP
    ' =======================================================================================
    Private Sub Tools_SaveTotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_SaveTotal.Click
        Tools_SaveTotal.Visible = False
        Tools_SaveTotal.Visible = True
        Me.Refresh()
        SaveImage("DopplerMeter_", Me)
        Beep()
    End Sub
    Private Sub Tools_SaveSpectrum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_SaveSpectrum.Click
        Tools_SaveSpectrum.Visible = False
        Tools_SaveSpectrum.Visible = True
        Me.Refresh()
        SaveImage("DopplerMeter_", pbox_Spectrum)
        Beep()
    End Sub
    Private Sub Tools_SaveSpectrumLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_SaveSpectrumLog.Click
        SaveSpectrumLog()
        Beep()
    End Sub
    Private Sub Tools_OpenSaveFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_OpenSaveFolder.Click
        OpenSaveFolder()
    End Sub
    Private Sub ToolStrip1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStrip1.MouseEnter
        Me.Focus() ' with this the toolstrip responds always at the first click
    End Sub

    ' ===================================================================================================
    '  SELECT AUDIO INPUT 
    ' ===================================================================================================
    Friend SelectedAudioIn As Int32 = 0
    Private Sub cmb_AudioInDevices_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_AudioInDevices.DropDown
        cmb_AudioInDevices.ItemHeight = 16
        FillAudioDevicesCombo()
    End Sub
    Private Sub cmb_AudioInDevices_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_AudioInDevices.DropDownClosed
        cmb_AudioInDevices.ItemHeight = 11
    End Sub
    Private Sub cmb_AudioInDevices_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_AudioInDevices.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        SelectedAudioIn = cmb_AudioInDevices.SelectedIndex
        Scope.Initialize(pbox_Scope, SelectedAudioIn)
        Spectrum.Initialize(pbox_Spectrum, SelectedAudioIn)
    End Sub
    Private Sub FillAudioDevicesCombo()
        Dim sa As String() = WaveNative.GetDevNames
        If sa.Length = 0 Then ReDim sa(0) : sa(0) = ""
        cmb_AudioInDevices.Items.Clear()
        For i As Int32 = 0 To sa.Length - 1
            cmb_AudioInDevices.Items.Add(ExtractDeviceName(sa(i)))
        Next
        Combo_SetIndex(cmb_AudioInDevices, SelectedAudioIn)
    End Sub

    ' ===================================================================================================
    '  SELECT RADAR TYPE
    ' ===================================================================================================
    Friend SelectedRadarType As Int32 = 0
    Private Sub cmb_RadarType_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_RadarType.DropDown
        cmb_RadarType.ItemHeight = 16
        FillRadarTypeCombo()
    End Sub
    Private Sub cmb_RadarType_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_RadarType.DropDownClosed
        cmb_RadarType.ItemHeight = 11
        SelectedRadarType = cmb_RadarType.SelectedIndex
        SetSpeedCoefficient()
    End Sub
    Private Sub FillRadarTypeCombo()
        Combo_SetIndex(cmb_RadarType, SelectedRadarType)
    End Sub

    ' ===================================================================================================
    '  AUDIO IN HELPERS
    ' ===================================================================================================
    Private Function ExtractDeviceName(ByVal s As String) As String
        If s = Nothing Then Return ""
        Dim i As Int32 = InStr(s, "(") - 1
        If i > 1 Then s = s.Remove(i)
        Return s.Trim
    End Function
    Private Sub btn_AudioInputs_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_AudioInputs.ClickButtonArea
        Open_AudioInputs()
    End Sub


    ' ===================================================================================================
    '  USER PARAMS 
    ' ===================================================================================================

    Private Sub SaveParamsOnLostFocus(ByVal sender As System.Object, _
                                      ByVal e As System.EventArgs) _
                                            Handles txt_MicrowaveFrequency.LostFocus, _
                                                    tbar_ScopeVoltage.LostFocus, _
                                                    tbar_ScopeTime.LostFocus, _
                                                    chk_ScopeNeg.LostFocus, _
                                                    txt_SlotSignal.LostFocus, _
                                                    txt_SlotSpeed.LostFocus, _
                                                    txt_SpecMaxDb.LostFocus, _
                                                    txt_SpecMinDb.LostFocus, _
                                                    txt_SpecMaxFreq.LostFocus, _
                                                    txt_SpecMinFreq.LostFocus, _
                                                    txt_SpecSpeedUp.LostFocus, _
                                                    txt_SpecSpeedDw.LostFocus, _
                                                    chk_SpecLogX.LostFocus, _
                                                    chk_SpecLogY.LostFocus, _
                                                    chk_SpecAutoScale.LostFocus, _
                                                    cmb_Spec_Window.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub SetSpectrumParams(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                           Handles txt_MicrowaveFrequency.TextChanged, _
                                                   txt_SpecMaxDb.TextChanged, _
                                                   txt_SpecMinDb.TextChanged, _
                                                   txt_SpecMaxFreq.TextChanged, _
                                                   txt_SpecMinFreq.TextChanged, _
                                                   txt_SpecSpeedUp.TextChanged, _
                                                   txt_SpecSpeedDw.TextChanged, _
                                                   chk_SpecLogX.CheckedChanged, _
                                                   chk_SpecLogY.CheckedChanged, _
                                                   chk_SpecAutoScale.CheckedChanged, _
                                                   cmb_Spec_Window.SelectionChangeCommitted
        If Not EventsAreEnabled Then Return
        SetAllSpectrumParams()
        'GroupBox_Scope.Focus()
    End Sub


    Private Sub SetAllSpectrumParams()
        Spectrum.SetScaleParams(pbox_Spectrum, _
                                32768, _
                                CSng(txt_SpecMaxFreq.NumericValue), _
                                CSng(txt_SpecMinFreq.NumericValue), _
                                CSng(txt_SpecMaxDb.NumericValue), _
                                CSng(txt_SpecMinDb.NumericValue), _
                                chk_SpecLogX.Checked, _
                                chk_SpecLogY.Checked, _
                                txt_SpecSpeedUp.NumericValueInteger / 100.0F, _
                                txt_SpecSpeedDw.NumericValueInteger / 1000.0F, _
                                chk_SpecAutoScale.Checked, _
                                False, _
                                CType(cmb_Spec_Window.SelectedIndex, FHT.WindowTypes))
        Spectrum.Update()
    End Sub

    Private Sub txt_SlotParams_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                      Handles txt_SlotSignal.TextChanged, _
                                                              txt_SlotSpeed.TextChanged

        Spectrum.SetSlotParams(txt_SlotSignal.NumericValueInteger, _
                               txt_SlotSpeed.NumericValueInteger)
    End Sub

    Private Sub txt_MicrowaveFrequency_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_MicrowaveFrequency.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        SetSpeedCoefficient()
    End Sub

    Const LightSpeed_kmsec As Single = 299792
    Const SoundSpeed_msec As Single = 343

    Private Sub SetSpeedCoefficient()
        If SelectedRadarType = 0 Then
            Spectrum.HertzToKmh = CSng(3.6 / 2000000.0 * _
                                       LightSpeed_kmsec / txt_MicrowaveFrequency.NumericValue)
        Else
            Spectrum.HertzToKmh = CSng(3.6 / 2000.0 * _
                                       SoundSpeed_msec / txt_UltrasoundFrequency.NumericValue)
        End If
    End Sub

    Private Sub Gen_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SpecMaxFreq.TextChanged, _
                                                                                                           txt_SpecMinFreq.TextChanged
        If Not EventsAreEnabled Then Return
        Dim txt As MyTextBox
        txt = DirectCast(sender, MyTextBox)
        If txt.NumericValue >= 1000 Then
            txt.Decimals = 0
            txt.ArrowsIncrement = 100
            txt.Increment = 100
            txt.RoundingStep = 100
        ElseIf txt.NumericValue >= 100 Then
            txt.Decimals = 0
            txt.ArrowsIncrement = 10
            txt.Increment = 10
            txt.RoundingStep = 10
        Else
            txt.Decimals = 0
            txt.ArrowsIncrement = 1
            txt.Increment = 1
            txt.RoundingStep = 0
        End If
    End Sub

    Private Sub btn_Clear_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Clear.ClickButtonArea
        Spectrum.ClearSpectrum()
    End Sub

    ' ===================================================================================================
    '  SCOPE PARAMS 
    ' ===================================================================================================
    Private Sub tbar_ScopeParams_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                        Handles tbar_ScopeVoltage.Scroll, _
                                                                                tbar_ScopeTime.Scroll
        If Not EventsAreEnabled Then Return
        ScopeTrim()
    End Sub
    Private Sub ScopeTrim()
        Scope.SetVoltage(VoltageFromTrackBar(tbar_ScopeVoltage.Value))
        Scope.SetTime(TimeFromTrackBar(tbar_ScopeTime.Value))
    End Sub
    Private Function VoltageFromTrackBar(ByVal n As Int32) As Single
        Select Case n
            Case 0 : Return 500
            Case 1 : Return 250
            Case 2 : Return 200
            Case 3 : Return 100
            Case 4 : Return 50
            Case 5 : Return 25
            Case 6 : Return 20
            Case 7 : Return 10
            Case 8 : Return 5
            Case 9 : Return 2.5
            Case 10 : Return 2
            Case 11 : Return 1
        End Select
    End Function
    Private Function TimeFromTrackBar(ByVal n As Int32) As Single
        Select Case n
            Case 0 : Return 100
            Case 1 : Return 50
            Case 2 : Return 20
            Case 3 : Return 10
            Case 4 : Return 5
            Case 5 : Return 2
            Case 6 : Return 1
            Case 7 : Return 0.5
            Case 8 : Return 0.2
            Case 9 : Return 0.1
        End Select
    End Function

End Class
