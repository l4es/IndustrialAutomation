﻿Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function

    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function

    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function

    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function

    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function

    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Int32
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function

    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function



    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================

    Friend Sub Save_INI()
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            '
            f.WriteLine("")
            f.WriteLine(" Controls")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("SelectedAudioIn", Form1.SelectedAudioIn))
            f.WriteLine(TabString("SelectedRadarType", Form1.SelectedRadarType))
            f.WriteLine(TabString("MicrowaveFrequency", Form1.txt_MicrowaveFrequency.Text))
            '
            f.WriteLine("")
            f.WriteLine(" Scope")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("ScopeVoltage", Form1.tbar_ScopeVoltage.Value))
            f.WriteLine(TabString("ScopeTime", Form1.tbar_ScopeTime.Value))
            f.WriteLine(TabString("ScopeNeg", Form1.chk_ScopeNeg.Checked.ToString))
            '
            f.WriteLine("")
            f.WriteLine(" Output controls")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("SlotSignal", Form1.txt_SlotSignal.Text))
            f.WriteLine(TabString("SlotSpeed", Form1.txt_SlotSpeed.Text))
            '
            f.WriteLine("")
            f.WriteLine(" Spectrum history")
            f.WriteLine("===========================================")

            '
            f.WriteLine("")
            f.WriteLine(" Spectrum")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("SpecMaxDb", Form1.txt_SpecMaxDb.Text))
            f.WriteLine(TabString("SpecMinDb", Form1.txt_SpecMinDb.Text))
            f.WriteLine(TabString("SpecMaxFreq", Form1.txt_SpecMaxFreq.Text))
            f.WriteLine(TabString("SpecMinFreq", Form1.txt_SpecMinFreq.Text))
            f.WriteLine(TabString("SpecSpeedUp", Form1.txt_SpecSpeedUp.Text))
            f.WriteLine(TabString("SpecSpeedDw", Form1.txt_SpecSpeedDw.Text))
            f.WriteLine(TabString("SpecLogX", Form1.chk_SpecLogX.Checked.ToString))
            f.WriteLine(TabString("SpecLogY", Form1.chk_SpecLogY.Checked.ToString))
            f.WriteLine(TabString("SpecAutoScale", Form1.chk_SpecAutoScale.Checked.ToString))
            f.WriteLine(TabString("Spec_Window", Form1.cmb_Spec_Window.Text))
            '
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub



    Friend Sub Load_INI()
        ' ------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        If My.Computer.FileSystem.FileExists(iniFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = CInt(Val(l))
                    Case "Form1_Left" : Form1.Left = CInt(Val(l))
                    Case "Form1_Width" : Form1.Width = CInt(Val(l))
                    Case "Form1_Height" : Form1.Height = CInt(Val(l))
                    Case "Form1_WindowState" : Form1.WindowState = CType((Val(l)), FormWindowState)
                        ' ----------------------------------------------------------------- controls
                    Case "SelectedAudioIn" : Form1.SelectedAudioIn = Val_Int(l)
                    Case "SelectedRadarType" : Form1.SelectedRadarType = Val_Int(l)
                    Case "MicrowaveFrequency" : Form1.txt_MicrowaveFrequency.Text = l
                        ' ----------------------------------------------------------------- scope
                    Case "ScopeVoltage" : Form1.tbar_ScopeVoltage.Value = Val_Int(l)
                    Case "ScopeTime" : Form1.tbar_ScopeTime.Value = Val_Int(l)
                    Case "ScopeNeg" : Form1.chk_ScopeNeg.Checked = l = "True"
                        ' ----------------------------------------------------------------- output controls
                    Case "SlotSignal" : Form1.txt_SlotSignal.Text = l
                    Case "SlotSpeed" : Form1.txt_SlotSpeed.Text = l
                        ' ----------------------------------------------------------------- spectrum
                    Case "SpecMaxDb" : Form1.txt_SpecMaxDb.Text = l
                    Case "SpecMinDb" : Form1.txt_SpecMinDb.Text = l
                    Case "SpecMaxFreq" : Form1.txt_SpecMaxFreq.Text = l
                    Case "SpecMinFreq" : Form1.txt_SpecMinFreq.Text = l
                    Case "SpecSpeedUp" : Form1.txt_SpecSpeedUp.Text = l
                    Case "SpecSpeedDw" : Form1.txt_SpecSpeedDw.Text = l
                    Case "SpecLogX" : Form1.chk_SpecLogX.Checked = l = "True"
                    Case "SpecLogY" : Form1.chk_SpecLogY.Checked = l = "True"
                    Case "SpecAutoScale" : Form1.chk_SpecAutoScale.Checked = l = "True"
                    Case "Spec_Window" : Form1.cmb_Spec_Window.Text = l
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
    End Sub


    ' ==================================================================================================
    '  SAVE IMAGE - Low level functions
    ' ==================================================================================================
    Private LogDirectory As String = Application.StartupPath + "\Logs\"
    Private Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)
        ' ---------------------------------------------------------------------
        extension = LCase(extension)
        filename = LogDirectory + _
                   IO.Path.GetFileNameWithoutExtension(filename) + "." + extension
        ' ---------------------------------------------------------------------
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, Quality)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function


    ' ==================================================================================================
    '  OpenSaveFolder and SaveImage
    ' ==================================================================================================
    Friend Sub OpenSaveFolder()
        My.Computer.FileSystem.CreateDirectory(LogDirectory)
        Process.Start(LogDirectory)
    End Sub
    Friend Sub SaveImage(ByVal Prefix As String, ByVal cnt As Control)
        Dim img As Image = GetImage(cnt)
        My.Computer.FileSystem.CreateDirectory(LogDirectory)
        SaveImage(img, Prefix & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss"), "jpg", 100)
    End Sub
    'Friend Sub SaveImage(ByVal Prefix As String, ByVal cnt As Control)
    '    Dim img As Image = GetImage(cnt)
    '    Dim sfd As SaveFileDialog = New SaveFileDialog()
    '    My.Computer.FileSystem.CreateDirectory(LogDirectory)
    '    sfd.InitialDirectory = LogDirectory
    '    sfd.Filter = "JPEG image (*.jpg)|*.jpg|Portable network graphics (*.png)|*png"
    '    sfd.FileName = Prefix & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
    '    If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
    '        SaveImage(img, sfd.FileName, If(sfd.FilterIndex = 1, "jpg", "png"), 100)
    '    End If
    'End Sub
    Private Function GetImage(ByVal cnt As Control) As Bitmap
        Dim s As Size = cnt.Size
        Dim bmp As Bitmap = New Bitmap(s.Width, s.Height)
        cnt.DrawToBitmap(bmp, New Rectangle(0, 0, s.Width, s.Height))
        Return bmp
    End Function

    ' ==================================================================================================
    '  Save spectrum log
    ' ==================================================================================================
    Sub SaveSpectrumLog()
        Dim filename As String = LogDirectory + "DopplerMeter_Log_" + _
                                 Date.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".txt"
        My.Computer.FileSystem.CreateDirectory(LogDirectory)
        Dim f As System.IO.StreamWriter
        f = IO.File.CreateText(filename)
        '
        f.WriteLine("---------------------------------")
        f.WriteLine(" Doppler Meter - Spectrum LOG    ")
        f.WriteLine("---------------------------------")
        If Form1.SelectedRadarType = 0 Then
            f.WriteLine(" Sensor type: Microwave doppler")
            f.WriteLine(" Sensor Frequency: " + _
                        Form1.txt_MicrowaveFrequency.Text + " GHz")
        Else
            f.WriteLine(" Sensor type: Ultrasound doppler")
            f.WriteLine(" Sensor Frequency: " + _
                        Form1.txt_UltrasoundFrequency.Text + " KHz")
        End If
        f.WriteLine("                                 ")
        f.WriteLine("                                 ")
        f.WriteLine("  Hz        Km/h      Decibel    ")
        f.WriteLine("---------------------------------")
        '
        Dim align As Int32() = New Int32() {1, 12, 22}
        Dim s As String
        Dim buffer As Single() = Spectrum.GetBandBuffer
        For i As Int32 = 0 To buffer.Length - 1
            s = Spectrum.GetLogLine(i)
            AlignCsvString(s, align)
            's = s.Replace(",", "") ' <<< space separated fields
            s = s.Trim(","c)        ' <<< comma separated fields
            f.WriteLine(s)
        Next
        f.Close()
    End Sub

    Private Sub AlignCsvString(ByRef s As String, ByVal Tabs() As Int32)
        Dim sa() As String
        sa = Split(s, ",")
        s = sa(0).Trim
        For j As Int32 = 1 To sa.Length - 1
            s &= "," & Strings.StrDup(Math.Max(0, Tabs(j - 1) - s.Length), " ") & sa(j).Trim
        Next
    End Sub

End Module
