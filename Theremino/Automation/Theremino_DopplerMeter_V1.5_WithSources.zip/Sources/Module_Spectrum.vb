﻿Module Spectrum

    Private m_FourierSamples As Int32 = 4096 '8192
    Private m_SamplesPerSec As Int32 = 22050

    Private m_Channels As Int32 = 1
    Private m_NumBuffers As Int32 = 4 ' 4
    Private m_LenBuffers As Int32 = 256 ' 512

    Private m_BackColor As Color = Color.FromArgb(30, 90, 120)
    Private m_scalePen As Pen = New Pen(Color.FromArgb(35, 48, 60))
    Private m_tracePen As Pen = New Pen(Color.FromArgb(240, 255, 255))
    Private m_TextBrush As Brush = Brushes.Azure
    Private m_leftborder As Int32 = 28
    Private m_downborder As Int32 = 16

    Private m_ddx As Int32
    Private m_ddy As Int32
    Private m_dispx As Int32
    Private m_dispy As Int32

    Private m_pbox As PictureBox

    Private m_slotsignal As Int32
    Private m_slotspeed As Int32

    Private m_fmin As Single
    Private m_fmax As Single
    Private m_dbmin As Single
    Private m_dbmax As Single
    Private m_xlog As Boolean
    Private m_ylog As Boolean
    Private m_windowtype As FHT.WindowTypes

    Private Const kdb As Double = 8.685889638

    Private m_fifo As FIFO = New FIFO(200000)
    Private m_fht As FHT = New FHT
    Private m_Recorder As AudioIn
    Private m_InputBuffer() As Int16

    Private Sub DataArrived(ByRef data() As Int16)
        m_fifo.AddArray(data)
    End Sub

    Friend Sub Initialize(ByVal pbox As PictureBox, _
                          Optional ByVal InputDeviceIndex As Int32 = -1)
        CloseAll()
        m_Recorder = New AudioIn()
        m_Recorder.InputOn(InputDeviceIndex, _
                           m_SamplesPerSec, _
                           m_Channels, _
                           m_LenBuffers, _
                           m_NumBuffers, _
                           New AudioIn.BufferDoneEventHandler(AddressOf DataArrived))
        ReDim m_InputBuffer(m_FourierSamples - 1)
    End Sub

    Friend Sub CloseAll()
        If m_Recorder IsNot Nothing Then
            m_Recorder.InputOff()
            m_Recorder = Nothing
        End If
    End Sub

    Friend Sub SetScaleParams(ByVal pbox As PictureBox, _
                              ByVal samplespersec As Int32, _
                              ByVal fmax As Single, _
                              ByVal fmin As Single, _
                              ByVal dbmax As Single, _
                              ByVal dbmin As Single, _
                              ByVal xlog As Boolean, _
                              ByVal ylog As Boolean, _
                              ByVal speedUp As Single, _
                              ByVal speedDw As Single, _
                              ByVal autoscale As Boolean, _
                              ByVal agc As Boolean, _
                              ByVal windowtype As FHT.WindowTypes)

        m_pbox = pbox
        m_SamplesPerSec = samplespersec
        m_fmax = fmax
        m_fmin = fmin
        m_dbmax = dbmax
        m_dbmin = dbmin
        m_xlog = xlog
        m_ylog = ylog
        'm_agc = agc
        m_windowtype = windowtype

        m_fht.SetScaleParams(pbox, _
                             samplespersec, _
                             fmax, _
                             fmin, _
                             dbmax, _
                             dbmin, _
                             xlog, _
                             ylog, _
                             speedUp, _
                             speedDw, _
                             autoscale, _
                             windowtype)
    End Sub

    Friend Sub SetSlotParams(ByVal slotsignal As Int32, _
                             ByVal slotspeed As Int32)
        m_slotsignal = slotsignal
        m_slotspeed = slotspeed
    End Sub

    Private Sub CreateGrid(ByVal g As Graphics)
        '
        g.DrawLine(m_scalePen, m_leftborder, m_dispy, m_ddx, m_dispy)
        g.DrawLine(m_scalePen, m_leftborder, 0, m_leftborder, m_dispy)
        '
        Dim s As String
        Dim max, min As Double
        Dim px As Int32
        Dim klog As Double = (m_dispx - 1) / Math.Log(m_fmax / m_fmin)
        Dim fontsize As Int32 = m_ddx \ 40
        If fontsize > 7 Then fontsize = 7
        If fontsize < 4 Then fontsize = 4
        Dim xFont As Font = New Font("Arial", fontsize)
        fontsize = m_ddy \ 40
        If fontsize > 7 Then fontsize = 7
        If fontsize < 4 Then fontsize = 4
        Dim yFont As Font = New Font("Arial", fontsize)
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit
        '
        If m_xlog And m_fmax / m_fmin >= 10 Then
            ' ---------------------------------------------------------------------- X AXIS LOG
            Dim decmin As Double = 100000
            Dim decmax As Double = 0.01
            While decmin > m_fmin : decmin /= 10 : End While
            While decmax < m_fmax : decmax *= 10 : End While
            Dim f As Double = decmin
            While f <= decmax
                For i As Int32 = 1 To 9
                    Dim x As Double = klog * Math.Log(f * i / m_fmin)
                    If x >= 0 AndAlso x <= m_dispx Then
                        px = CInt(Math.Floor(m_leftborder + x + 0.5))
                        If i = 1 Then
                            g.DrawLine(m_scalePen, px, 0, px, m_ddy - m_downborder + 4)
                            If (px > m_ddx - 18) Then px = m_ddx - 18
                            If (f = 0.1) Then
                                g.DrawString(".1 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                            ElseIf f = 1 Then
                                g.DrawString("1 Hz", xFont, m_TextBrush, px - 4, m_ddy - 12)
                            ElseIf (f = 10) Then
                                g.DrawString("10 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                            ElseIf (f = 100) Then
                                g.DrawString("100 Hz", xFont, m_TextBrush, px - 12, m_ddy - 12)
                            ElseIf (f = 1000) Then
                                g.DrawString("1 KHz", xFont, m_TextBrush, px - 10, m_ddy - 12)
                            ElseIf (f = 10000) Then
                                g.DrawString("10 KHz", xFont, m_TextBrush, px - 14, m_ddy - 12)
                            End If
                        ElseIf i = 2 Then
                            g.DrawLine(m_scalePen, px, 0, px, m_ddy - m_downborder + 4)
                            If m_fmax / m_fmin < 200 Then
                                If (px > m_ddx - 18) Then px = m_ddx - 18
                                If (f = 0.1) Then
                                    g.DrawString(".2 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                                ElseIf f = 1 Then
                                    g.DrawString("2 Hz", xFont, m_TextBrush, px - 4, m_ddy - 12)
                                ElseIf (f = 10) Then
                                    g.DrawString("20 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                                ElseIf (f = 100) Then
                                    g.DrawString("200 Hz", xFont, m_TextBrush, px - 12, m_ddy - 12)
                                ElseIf (f = 1000) Then
                                    g.DrawString("2 KHz", xFont, m_TextBrush, px - 10, m_ddy - 12)
                                ElseIf (f = 10000) Then
                                    g.DrawString("20 KHz", xFont, m_TextBrush, px - 14, m_ddy - 12)
                                End If
                            End If
                        ElseIf i = 5 Then
                            g.DrawLine(m_scalePen, px, 0, px, m_ddy - m_downborder + 4)
                            If m_fmax / m_fmin < 100 Then
                                If (px > m_ddx - 18) Then px = m_ddx - 18
                                If (f = 0.1) Then
                                    g.DrawString(".5 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                                ElseIf f = 1 Then
                                    g.DrawString("5 Hz", xFont, m_TextBrush, px - 4, m_ddy - 12)
                                ElseIf (f = 10) Then
                                    g.DrawString("50 Hz", xFont, m_TextBrush, px - 8, m_ddy - 12)
                                ElseIf (f = 100) Then
                                    g.DrawString("500 Hz", xFont, m_TextBrush, px - 12, m_ddy - 12)
                                ElseIf (f = 1000) Then
                                    g.DrawString("5 KHz", xFont, m_TextBrush, px - 10, m_ddy - 12)
                                End If
                            End If
                        Else
                            g.DrawLine(m_scalePen, px, 0, px, m_ddy - m_downborder)
                        End If
                    End If
                Next
                f *= 10
            End While
        Else
            ' ---------------------------------------------------------------------- X AXIS LIN
            Dim nstep As Int32
            Dim deltaf As Double = m_fmax - m_fmin
            Dim stepsize As Double = 0.1
            '
            If deltaf > 0 Then
                nstep = 13
                If m_fmax >= 10000 Then nstep = 10
                If m_xlog AndAlso m_fmax / m_fmin > 2 AndAlso m_fmax >= 1000 Then nstep = 8
                '
                While deltaf / stepsize > nstep
                    stepsize *= 2
                    If deltaf / stepsize > nstep Then stepsize *= 2.5
                    If deltaf / stepsize > nstep Then stepsize *= 2
                End While
                '
                max = Math.Ceiling(m_fmax / stepsize + 0.5) * stepsize
                min = Math.Floor(m_fmin / stepsize + 0.5) * stepsize
                Dim f As Double = min
                While f <= max
                    If f >= m_fmin And f <= m_fmax Then
                        If m_xlog Then
                            px = m_leftborder + CInt(Math.Floor(klog * Math.Log(f / m_fmin)))
                        Else
                            px = m_leftborder + CInt(Math.Floor((m_dispx - 1) * (f - m_fmin) / deltaf))
                        End If

                        g.DrawLine(m_scalePen, px, 0, px, m_ddy - m_downborder + 4)
                        If px < m_ddx - 10 Then
                            If (Int(f) = f) Then
                                g.DrawString(f.ToString("0"), xFont, m_TextBrush, px - 10, m_ddy - 12)
                            Else
                                g.DrawString(f.ToString("0.0"), xFont, m_TextBrush, px - 10, m_ddy - 12)
                            End If
                        End If
                    End If
                    f += stepsize
                End While
            End If
            '
            nstep = 4
            If m_xlog Then nstep = 3
            If deltaf / stepsize < nstep Then
                s = m_fmax.ToString("0.0")
                If m_fmax >= 10000 Then
                    g.DrawString(s, xFont, m_TextBrush, m_ddx - 36, m_ddy - 12)
                ElseIf m_fmax >= 1000 Then
                    g.DrawString(s, xFont, m_TextBrush, m_ddx - 28, m_ddy - 12)
                Else
                    g.DrawString(s, xFont, m_TextBrush, m_ddx - 24, m_ddy - 12)
                End If
            End If
        End If
        '
        If m_ylog Then
            ' ---------------------------------------------------------------------- Y AXIS LOG
            Dim deltadb As Double = m_dbmax - m_dbmin
            Dim stepsize As Double = 0.1
            Dim nstep As Int32 = 20
            While deltadb / stepsize > nstep
                stepsize *= 2
                If deltadb / stepsize > nstep Then stepsize *= 2.5
                If deltadb / stepsize > nstep Then stepsize *= 2
            End While
            max = Math.Ceiling(m_dbmax / stepsize + 0.5) * stepsize
            min = Math.Floor(m_dbmin / stepsize + 0.5) * stepsize
            Dim db As Double = min
            While db <= max
                If db >= m_dbmin And db <= m_dbmax Then
                    Dim y As Int32 = CInt(Math.Floor(m_dispy - (m_dispy * (db - m_dbmin) / (m_dbmax - m_dbmin)) + 0.5))
                    g.DrawLine(m_scalePen, m_leftborder - 4, y, m_ddx, y)
                    If y > 14 Then
                        If y > m_dispy - 2 Then y = m_dispy - 2
                        If Math.Floor(db) = db Then
                            s = db.ToString("0")
                        Else
                            s = db.ToString("0.0")
                        End If
                        g.DrawString(s, yFont, m_TextBrush, 3, y - 6)
                    End If
                End If
                db += stepsize
            End While
            g.DrawString("dB", yFont, m_TextBrush, 5, 0)
        Else
            ' ---------------------------------------------------------------------- Y AXIS LIN
            Dim mvmin As Double = 2 * Math.Exp(m_dbmin / kdb) * 1000
            Dim mvmax As Double = 2 * Math.Exp(m_dbmax / kdb) * 1000
            Dim deltamv As Double = mvmax - mvmin
            Dim stepsize As Double = 0.001
            Dim nstep As Int32 = 20
            While deltamv / stepsize > nstep
                stepsize *= 2
                If deltamv / stepsize > nstep Then stepsize *= 2.5
                If deltamv / stepsize > nstep Then stepsize *= 2
            End While
            '
            max = Math.Ceiling(mvmax / stepsize + 0.5) * stepsize
            min = Math.Floor(mvmin / stepsize + 0.5) * stepsize
            Dim mv As Double = min
            While mv <= max
                If mv >= mvmin And mv <= mvmax Then
                    Dim y As Int32 = CInt(Math.Floor((m_dispy - (m_dispy * (mv - mvmin) / (mvmax - mvmin)) + 0.5)))
                    g.DrawLine(m_scalePen, m_leftborder - 4, y, m_ddx, y)
                    If y >= 16 Then
                        If y > m_dispy - 2 Then y = m_dispy - 2
                        If Math.Floor(mv) = mv Then
                            s = mv.ToString("0")
                        ElseIf Math.Abs(Math.Floor(mv * 10 + 0.5) - mv * 10) < 0.0001 Then
                            s = mv.ToString("0.0")
                        ElseIf Math.Abs(Math.Floor(mv * 100 + 0.5) - mv * 100) < 0.0001 Then
                            s = mv.ToString("0.00")
                        Else
                            s = mv.ToString("0.000")
                        End If
                        g.DrawString(s, yFont, m_TextBrush, 3, y - 6)
                    End If
                End If
                mv += stepsize
            End While
            g.DrawString("mV", yFont, m_TextBrush, 4, 0)
        End If
    End Sub

    Friend Function GetDbMax() As Single
        Return m_fht.m_dbmax
    End Function
    Friend Function GetDbMin() As Single
        Return m_fht.m_dbmin
    End Function

    Friend Sub ClearSpectrum()
        Array.Clear(m_fht.BandsBuffer, 0, m_fht.BandsBuffer.Length)
    End Sub

    Friend Function GetBandBuffer() As Single()
        Return m_fht.BandsBuffer
    End Function

    Friend Sub Update()
        'Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()

        If Form1.chk_Run.Checked Then

            InitPictureboxImage(m_pbox)

            If m_pbox.Image.Width <> m_ddx OrElse _
                                    m_pbox.Image.Height <> m_ddy Then

                m_ddx = m_pbox.Image.Width
                m_ddy = m_pbox.Image.Height
                m_dispx = m_ddx - m_leftborder
                m_dispy = m_ddy - m_downborder
            End If

            Dim g As Graphics = Graphics.FromImage(m_pbox.Image)
            g.Clear(m_BackColor)

            If m_dbmin >= m_dbmax Or m_fmin >= m_fmax Or m_fmax >= m_SamplesPerSec \ 2 Then
                g.DrawString("Invalid params", New Font("Arial", 11), m_TextBrush, 10, 10)
                m_pbox.Invalidate()
                Return
            End If

            CreateGrid(g)

            m_fifo.SetReadIndex(m_fifo.GetWriteIndex - m_InputBuffer.Length)
            'm_fifo.GetArray(m_InputBuffer)
            m_fifo.GetArrayZeroCorrected(m_InputBuffer)
            m_fht.ExecuteFHT(m_InputBuffer, m_windowtype)
            m_fht.ExtractBands(m_dispx)

            Dim s As String
            Dim f As Font = New Font("Tahoma", 10)
            Dim ix As Int32
            Dim x As Single
            Dim y As Single
            Dim oldx As Single = -1
            Dim oldy As Single
            Dim oldy2 As Single
            Dim maxvalue_y As Single = -1
            Dim maxvalue_x As Single
            For ix = 0 To m_dispx - 1
                x = ix + m_leftborder
                y = m_fht.BandsBuffer(ix)
                ' ------------------------------------------------------- maxvalue X and Y
                If y > maxvalue_y Then
                    maxvalue_y = y
                    maxvalue_x = x
                End If
                ' ------------------------------------------------------- display y
                y = m_dispy - m_dispy * y
                ' ------------------------------------------------------- draw spectrum
                If oldx >= 0 Then
                    g.DrawLine(m_tracePen, oldx, oldy, x, y)
                End If
                ' ------------------------------------------------------- draw speed values
                If oldy <= oldy2 AndAlso oldy <= y Then
                    If m_dispy - oldy > 20 AndAlso IsMaxPoint(ix - 1) Then
                        g.DrawEllipse(Pens.Yellow, oldx - 4, oldy - 4, 8, 8)
                        s = FreqToSpeed(XtoFreq(oldx)).ToString("0.0 km/h")
                        If oldx + 40 > m_dispx Then oldx = oldx - 70
                        g.DrawString(s, f, Brushes.Yellow, oldx + 4, oldy - 12)
                    End If
                End If
                ' -------------------------------------------------------
                oldy2 = oldy
                oldy = y
                oldx = x
            Next
            m_pbox.Invalidate()
            ' ----------------------------------------------------------- draw spectrum history
            DrawSpectrumHistory()
            ' ----------------------------------------------------------- output to slots
            If m_slotsignal >= 0 Then
                Slots.WriteSlot(m_slotsignal, maxvalue_y * 1000)
            End If
            If m_slotspeed >= 0 Then
                Slots.WriteSlot(m_slotspeed, FreqToSpeed(XtoFreq(maxvalue_x)))
            End If
        End If
        '
        'ReportString = "Spectrum Update time: " & (sw1.Elapsed.TotalMilliseconds * 1000).ToString("0") & " uS"
    End Sub

    Private Function IsMaxPoint(ByVal ix As Int32) As Boolean
        Const clearance As Int32 = 20
        If ix < 15 Then Return False
        Dim v As Single = m_fht.BandsBuffer(ix)
        Dim testStart As Int32 = Math.Max(ix - clearance, 0)
        Dim testEnd As Int32 = Math.Min(ix + clearance, m_fht.BandsBuffer.Length - 1)
        For i As Int32 = testStart To testEnd
            If m_fht.BandsBuffer(i) >= v AndAlso i <> ix Then Return False
        Next
        Return True
    End Function

    Private Function XtoFreq(ByVal x As Single) As Single
        If m_xlog Then
            Return CSng(Math.Exp((x - m_leftborder) / m_dispx * (Math.Log(m_fmax) - Math.Log(m_fmin)) + Math.Log(m_fmin)))
        Else
            Return (x - m_leftborder) * (m_fmax - m_fmin) / (m_dispx) + m_fmin
        End If
    End Function

    Friend HertzToKmh As Single
    Private Function FreqToSpeed(ByVal f As Single) As Single
        Return f * HertzToKmh
    End Function

    Friend Function GetLogLine(ByVal x As Int32) As String
        Dim fp As System.IFormatProvider = Globalization.CultureInfo.InvariantCulture
        Dim hz As Single = XtoFreq(x + m_leftborder)
        Dim kmh As Single = FreqToSpeed(hz)
        Dim db As Single = m_dbmin + (m_dbmax - m_dbmin) * m_fht.BandsBuffer(x)
        Return "," + hz.ToString("0.000", fp) + _
               "," + kmh.ToString("0.000", fp) + _
               "," + db.ToString("0.000", fp)
    End Function

    'Friend Function GetLogLine(ByVal x As Int32) As String
    '    Dim fp As System.IFormatProvider = Globalization.CultureInfo.InvariantCulture
    '    Dim hz As Single = XtoFreq(x + m_leftborder)
    '    Dim kmh As Single = FreqToSpeed(hz)
    '    Dim db As Single = m_dbmin + (m_dbmax - m_dbmin) * m_fht.BandsBuffer(x)
    '    Return hz.ToString("0.00", fp) + "," + _
    '           kmh.ToString("0.00", fp) + "," + _
    '           db.ToString("0.00", fp)
    'End Function


    ' =============================================================================
    '  SPECTRUM HISTORY
    ' =============================================================================

    Private Sub DrawSpectrumHistory()
        Dim pb As PictureBox = Form1.pbox_SpectrumHistory
        InitPictureboxImage(pb)
        If pb.Image Is Nothing Then Return
        Dim g As Graphics = Graphics.FromImage(pb.Image)
        Dim c As Single
        Dim y As Single = pb.ClientSize.Height - 1
        For ix As Int32 = 0 To m_dispx - 1
            c = m_fht.BandsBuffer(ix)
            g.DrawLine(New Pen(RainbowColor_DarkBlueToRed(c)), ix, y, ix, y - 1)
        Next
        g.DrawImage(CType(pb.Image.Clone, Image), 0, -1)
        pb.Invalidate()
    End Sub

    Private Function RainbowColor_BlueToRed(ByVal value As Single) As Color
        '
        Dim n As Int32 = CInt(1023 * value)
        ' ------------------------------------------------------------ Map n (0..1023) to color bands
        If (n < 256) Then
            ' -------------------------------------------------------- Blue to Aqua    (0, 0, 255)   to (0, 255, 255) 
            RainbowColor_BlueToRed = Color.FromArgb(0, n, 255)
        ElseIf (n < 512) Then
            ' -------------------------------------------------------- Aqua to Green   (0, 255, 255) to (0, 255, 0) 
            RainbowColor_BlueToRed = Color.FromArgb(0, 255, 255 - (n - 256))
        ElseIf (n < 768) Then
            ' -------------------------------------------------------- Green to Yellow (0, 255, 0)   to (255, 255, 0)
            RainbowColor_BlueToRed = Color.FromArgb(n - 512, 255, 0)
        Else
            ' -------------------------------------------------------- Yellow to Red   (255, 255, 0) to (255, 0, 0)
            RainbowColor_BlueToRed = Color.FromArgb(255, 255 - (n - 768), 0)
        End If
    End Function


    Private Function RainbowColor_DarkBlueToRed(ByVal value As Single) As Color
        '
        Dim n As Int32 = CInt(1023 * value)
        ' ------------------------------------------------------------ Map n (0..1023) to color bands
        If (n < 256) Then
            ' -------------------------------------------------------- Blue to Aqua    (0, 0, 255)   to (0, 255, 255) 
            RainbowColor_DarkBlueToRed = Color.FromArgb(0, n, 128 + n \ 2)
        ElseIf (n < 512) Then
            ' -------------------------------------------------------- Aqua to Green   (0, 255, 255) to (0, 255, 0) 
            RainbowColor_DarkBlueToRed = Color.FromArgb(0, 255, 255 - (n - 256))
        ElseIf (n < 768) Then
            ' -------------------------------------------------------- Green to Yellow (0, 255, 0)   to (255, 255, 0)
            RainbowColor_DarkBlueToRed = Color.FromArgb(n - 512, 255, 0)
        Else
            ' -------------------------------------------------------- Yellow to Red   (255, 255, 0) to (255, 0, 0)
            RainbowColor_DarkBlueToRed = Color.FromArgb(255, 255 - (n - 768), 0)
        End If
    End Function


    Private Function RainbowColor_BlackToRed(ByVal value As Single) As Color
        '
        Dim n As Int32 = CInt(1279 * value)
        ' ------------------------------------------------------------ Map n (0..1023) to color bands
        If (n < 256) Then
            ' -------------------------------------------------------- Black to Blue   (0, 0, 0)     to (0, 0, 255) 
            RainbowColor_BlackToRed = Color.FromArgb(0, 0, n)
        ElseIf (n < 512) Then
            ' -------------------------------------------------------- Blue to Aqua    (0, 0, 255)   to (0, 255, 255) 
            RainbowColor_BlackToRed = Color.FromArgb(0, n - 256, 255)
        ElseIf (n < 768) Then
            ' -------------------------------------------------------- Aqua to Green   (0, 255, 255) to (0, 255, 0) 
            RainbowColor_BlackToRed = Color.FromArgb(0, 255, 255 - (n - 512))
        ElseIf (n < 1024) Then
            ' -------------------------------------------------------- Green to Yellow (0, 255, 0)   to (255, 255, 0)
            RainbowColor_BlackToRed = Color.FromArgb(n - 768, 255, 0)
        Else
            ' -------------------------------------------------------- Yellow to Red   (255, 255, 0) to (255, 0, 0)
            RainbowColor_BlackToRed = Color.FromArgb(255, 255 - (n - 1024), 0)
        End If
    End Function


End Module
