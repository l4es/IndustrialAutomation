
Public Class MilliTimer

    ' ====================================================================================================
    ' This function affects a global Windows setting 
    ' Windows uses the lowest value (that is, highest resolution) requested by any process
    ' Setting a higher resolution can improve the accuracy of time-out intervals in wait functions
    ' However, it can also reduce system performance, because the thread scheduler switches tasks more often 
    ' High resolutions can also prevent the CPU power management system from entering power-saving modes 
    ' Setting a higher resolution does not improve the accuracy of the high-resolution performance counter
    ' ====================================================================================================
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private SystemResolution As Integer = 1

    ' ------------------------------------------------------------------------- EVENTS
    Friend Event MilliTimerElapsed As MicroTimerElapsedEventHandler
    Friend Delegate Sub MicroTimerElapsedEventHandler()

    ' ------------------------------------------------------------------------- CLASS MEMBERS
    Private mThreadTimer As System.Threading.Thread
    Private mTimerMilliSecInterval As Double
    Private mIgnoreEventIfLateBy As Double = Double.MaxValue
    Private mStopTimerFlag As Boolean

    ' ------------------------------------------------------------------------- 
    Friend Sub New(Optional ByVal Interval As Double = 100)
        Me.Interval = Interval
    End Sub

    Friend Property Interval() As Double
        Get
            Return mTimerMilliSecInterval
        End Get
        Set(ByVal value As Double)
            If value < 1 Then value = 1
            mTimerMilliSecInterval = value
        End Set
    End Property

    Public Property IgnoreEventIfLateBy() As Double
        Get
            Return mIgnoreEventIfLateBy
        End Get
        Set(ByVal value As Double)
            If value = 0 Then
                mIgnoreEventIfLateBy = Double.MaxValue
            Else
                mIgnoreEventIfLateBy = value
            End If
        End Set
    End Property

    Friend Sub Start()
        If mThreadTimer IsNot Nothing Then Return
        timeBeginPeriod(1)
        mStopTimerFlag = False
        mThreadTimer = New Threading.Thread(AddressOf NotificationTimer)
        mThreadTimer.IsBackground = True
        mThreadTimer.Priority = Threading.ThreadPriority.Highest
        mThreadTimer.Start()
    End Sub

    Friend Sub [Stop]()
        If mThreadTimer Is Nothing Then Return
        timeEndPeriod(1)
        mStopTimerFlag = True
        Do : Application.DoEvents() : SleepMyThread(10) : Loop While mThreadTimer.IsAlive
        mThreadTimer.Join()
        mThreadTimer = Nothing
    End Sub

    'Private Sub NotificationTimer()
    '    Dim stw As Diagnostics.Stopwatch = New Diagnostics.Stopwatch
    '    stw.Start()
    '    While Not mStopTimerFlag
    '        While (stw.Elapsed.TotalMilliseconds + 0.5 < mTimerMilliSecInterval)
    '            Threading.Thread.Sleep(1)
    '        End While
    '        stw.Reset()
    '        stw.Start()
    '        RaiseEvent MilliTimerElapsed()
    '    End While
    'End Sub

    'Private Sub NotificationTimer()
    '    Dim stw As Diagnostics.Stopwatch = New Diagnostics.Stopwatch
    '    stw.Start()
    '    While Not mStopTimerFlag
    '        If stw.Elapsed.TotalMilliseconds > mTimerMilliSecInterval Then
    '            stw.Reset()
    '            stw.Start()
    '            RaiseEvent MilliTimerElapsed()
    '        Else
    '            Threading.Thread.Sleep(1)
    '        End If
    '    End While
    'End Sub

    'Private Sub NotificationTimer()
    '    While Not mStopTimerFlag
    '        RaiseEvent MilliTimerElapsed()
    '        Threading.Thread.Sleep(CInt(mTimerMilliSecInterval))
    '    End While
    'End Sub

    Private Sub NotificationTimer()
        Dim nTimerCount As Integer = 0
        Dim NextNotification As Double = 0
        Dim ElapsedMillisec As Double
        '
        Dim stw As Diagnostics.Stopwatch = New Diagnostics.Stopwatch
        stw.Start()
        While Not mStopTimerFlag

            nTimerCount += 1
            NextNotification += Interval

            Do
                Threading.Thread.Sleep(1)
                ElapsedMillisec = stw.Elapsed.TotalMilliseconds
            Loop While ElapsedMillisec < NextNotification

            Dim lTimerLateBy As Double = ElapsedMillisec - (nTimerCount * Interval)

            If lTimerLateBy < IgnoreEventIfLateBy Then
                RaiseEvent MilliTimerElapsed()
            End If

        End While
        stw.Stop()
    End Sub

    ' ----------------------------------------------------------------------
    '  Double data Type capacity
    ' ----------------------------------------------------------------------
    '  Max integer stored without rounding errors:  +9'007'199'254'740'992
    '  ( this number is 300'000 years in milliseconds )
    ' ----------------------------------------------------------------------

End Class


