﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox_Motors = New System.Windows.Forms.GroupBox
        Me.txt_PixelsX = New MyTextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.txt_PixelsPerMM = New MyTextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txt_PixelsY = New MyTextBox
        Me.GroupBox_Toolpath = New System.Windows.Forms.GroupBox
        Me.Pic_GcodeViewer = New System.Windows.Forms.PictureBox
        Me.GroupBox_Gcode = New System.Windows.Forms.GroupBox
        Me.RTB = New System.Windows.Forms.RichTextBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_LoadVectorFile = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SaveGcode = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_LoadVectorFiles = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_SaveGcode = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.GroupBox_Motors.SuspendLayout()
        Me.GroupBox_Toolpath.SuspendLayout()
        CType(Me.Pic_GcodeViewer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Gcode.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox_Motors
        '
        Me.GroupBox_Motors.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Motors.BackColor = System.Drawing.Color.FromArgb(CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.GroupBox_Motors.BackgroundImage = CType(resources.GetObject("GroupBox_Motors.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox_Motors.Controls.Add(Me.txt_PixelsX)
        Me.GroupBox_Motors.Controls.Add(Me.Label16)
        Me.GroupBox_Motors.Controls.Add(Me.txt_PixelsPerMM)
        Me.GroupBox_Motors.Controls.Add(Me.Label15)
        Me.GroupBox_Motors.Controls.Add(Me.txt_PixelsY)
        Me.GroupBox_Motors.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Motors.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.GroupBox_Motors.Location = New System.Drawing.Point(3, 338)
        Me.GroupBox_Motors.Name = "GroupBox_Motors"
        Me.GroupBox_Motors.Size = New System.Drawing.Size(298, 85)
        Me.GroupBox_Motors.TabIndex = 150
        Me.GroupBox_Motors.TabStop = False
        Me.GroupBox_Motors.Text = "Image dimensions"
        '
        'txt_PixelsX
        '
        Me.txt_PixelsX.ArrowsIncrement = 100
        Me.txt_PixelsX.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txt_PixelsX.BackColor_Over = System.Drawing.Color.Blue
        Me.txt_PixelsX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_PixelsX.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_PixelsX.ForeColor = System.Drawing.Color.Gold
        Me.txt_PixelsX.Increment = 10
        Me.txt_PixelsX.Location = New System.Drawing.Point(102, 54)
        Me.txt_PixelsX.MaxValue = 9000
        Me.txt_PixelsX.MinValue = 10
        Me.txt_PixelsX.Name = "txt_PixelsX"
        Me.txt_PixelsX.NumericValue = 1024
        Me.txt_PixelsX.NumericValueInteger = 1024
        Me.txt_PixelsX.RectangleColor = System.Drawing.Color.White
        Me.txt_PixelsX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_PixelsX.RoundingStep = 0
        Me.txt_PixelsX.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_PixelsX.Size = New System.Drawing.Size(70, 25)
        Me.txt_PixelsX.SuppressZeros = True
        Me.txt_PixelsX.TabIndex = 211
        Me.txt_PixelsX.Text = "1024"
        Me.txt_PixelsX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Silver
        Me.Label16.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label16.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(19, 56)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(77, 19)
        Me.Label16.TabIndex = 212
        Me.Label16.Text = "Pixels X/Y"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_PixelsPerMM
        '
        Me.txt_PixelsPerMM.ArrowsIncrement = 10
        Me.txt_PixelsPerMM.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txt_PixelsPerMM.BackColor_Over = System.Drawing.Color.Blue
        Me.txt_PixelsPerMM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_PixelsPerMM.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_PixelsPerMM.ForeColor = System.Drawing.Color.Gold
        Me.txt_PixelsPerMM.Increment = 1
        Me.txt_PixelsPerMM.Location = New System.Drawing.Point(133, 25)
        Me.txt_PixelsPerMM.MaxValue = 100
        Me.txt_PixelsPerMM.MinValue = 1
        Me.txt_PixelsPerMM.Name = "txt_PixelsPerMM"
        Me.txt_PixelsPerMM.NumericValue = 10
        Me.txt_PixelsPerMM.NumericValueInteger = 10
        Me.txt_PixelsPerMM.RectangleColor = System.Drawing.Color.White
        Me.txt_PixelsPerMM.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_PixelsPerMM.RoundingStep = 0
        Me.txt_PixelsPerMM.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_PixelsPerMM.Size = New System.Drawing.Size(56, 25)
        Me.txt_PixelsPerMM.SuppressZeros = True
        Me.txt_PixelsPerMM.TabIndex = 209
        Me.txt_PixelsPerMM.Text = "10"
        Me.txt_PixelsPerMM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Silver
        Me.Label15.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label15.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(19, 27)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(109, 19)
        Me.Label15.TabIndex = 210
        Me.Label15.Text = "Pixels per mm"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_PixelsY
        '
        Me.txt_PixelsY.ArrowsIncrement = 100
        Me.txt_PixelsY.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txt_PixelsY.BackColor_Over = System.Drawing.Color.Blue
        Me.txt_PixelsY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_PixelsY.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_PixelsY.ForeColor = System.Drawing.Color.Gold
        Me.txt_PixelsY.Increment = 10
        Me.txt_PixelsY.Location = New System.Drawing.Point(174, 54)
        Me.txt_PixelsY.MaxValue = 9000
        Me.txt_PixelsY.MinValue = 100
        Me.txt_PixelsY.Name = "txt_PixelsY"
        Me.txt_PixelsY.NumericValue = 800
        Me.txt_PixelsY.NumericValueInteger = 800
        Me.txt_PixelsY.RectangleColor = System.Drawing.Color.White
        Me.txt_PixelsY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_PixelsY.RoundingStep = 0
        Me.txt_PixelsY.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_PixelsY.Size = New System.Drawing.Size(62, 25)
        Me.txt_PixelsY.SuppressZeros = True
        Me.txt_PixelsY.TabIndex = 207
        Me.txt_PixelsY.Text = "800"
        Me.txt_PixelsY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_Toolpath
        '
        Me.GroupBox_Toolpath.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Toolpath.BackColor = System.Drawing.Color.FromArgb(CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.GroupBox_Toolpath.BackgroundImage = CType(resources.GetObject("GroupBox_Toolpath.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox_Toolpath.Controls.Add(Me.Pic_GcodeViewer)
        Me.GroupBox_Toolpath.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Toolpath.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.GroupBox_Toolpath.Location = New System.Drawing.Point(3, 8)
        Me.GroupBox_Toolpath.Name = "GroupBox_Toolpath"
        Me.GroupBox_Toolpath.Size = New System.Drawing.Size(450, 415)
        Me.GroupBox_Toolpath.TabIndex = 149
        Me.GroupBox_Toolpath.TabStop = False
        Me.GroupBox_Toolpath.Text = " Toolpath "
        '
        'Pic_GcodeViewer
        '
        Me.Pic_GcodeViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pic_GcodeViewer.BackColor = System.Drawing.Color.AliceBlue
        Me.Pic_GcodeViewer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_GcodeViewer.Location = New System.Drawing.Point(8, 20)
        Me.Pic_GcodeViewer.Name = "Pic_GcodeViewer"
        Me.Pic_GcodeViewer.Size = New System.Drawing.Size(433, 389)
        Me.Pic_GcodeViewer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_GcodeViewer.TabIndex = 153
        Me.Pic_GcodeViewer.TabStop = False
        '
        'GroupBox_Gcode
        '
        Me.GroupBox_Gcode.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Gcode.BackColor = System.Drawing.Color.FromArgb(CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.GroupBox_Gcode.BackgroundImage = CType(resources.GetObject("GroupBox_Gcode.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox_Gcode.Controls.Add(Me.RTB)
        Me.GroupBox_Gcode.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Gcode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.GroupBox_Gcode.Location = New System.Drawing.Point(3, 8)
        Me.GroupBox_Gcode.Name = "GroupBox_Gcode"
        Me.GroupBox_Gcode.Size = New System.Drawing.Size(298, 323)
        Me.GroupBox_Gcode.TabIndex = 210
        Me.GroupBox_Gcode.TabStop = False
        Me.GroupBox_Gcode.Text = " Gcode "
        '
        'RTB
        '
        Me.RTB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RTB.BackColor = System.Drawing.Color.AliceBlue
        Me.RTB.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RTB.ForeColor = System.Drawing.Color.Black
        Me.RTB.HideSelection = False
        Me.RTB.Location = New System.Drawing.Point(8, 19)
        Me.RTB.Name = "RTB"
        Me.RTB.Size = New System.Drawing.Size(282, 298)
        Me.RTB.TabIndex = 225
        Me.RTB.Text = ""
        Me.RTB.WordWrap = False
        '
        'Timer1
        '
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(764, 30)
        Me.MenuStrip1.TabIndex = 212
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_LoadVectorFile, Me.Menu_File_SaveGcode, Me.ToolStripSeparator6, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(53, 26)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_LoadVectorFile
        '
        Me.Menu_File_LoadVectorFile.Image = CType(resources.GetObject("Menu_File_LoadVectorFile.Image"), System.Drawing.Image)
        Me.Menu_File_LoadVectorFile.Name = "Menu_File_LoadVectorFile"
        Me.Menu_File_LoadVectorFile.Size = New System.Drawing.Size(215, 26)
        Me.Menu_File_LoadVectorFile.Text = "Load vector file"
        '
        'Menu_File_SaveGcode
        '
        Me.Menu_File_SaveGcode.Image = CType(resources.GetObject("Menu_File_SaveGcode.Image"), System.Drawing.Image)
        Me.Menu_File_SaveGcode.Name = "Menu_File_SaveGcode"
        Me.Menu_File_SaveGcode.Size = New System.Drawing.Size(215, 26)
        Me.Menu_File_SaveGcode.Text = "Save GCode as"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(212, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(215, 26)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(61, 26)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(204, 26)
        Me.Menu_Help_ProgramHelp.Text = "Program helps"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(72, 26)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_LoadVectorFiles, Me.ToolStripSeparator3, Me.ToolStripButton_SaveGcode, Me.ToolStripSeparator7})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 30)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(764, 29)
        Me.ToolStrip1.TabIndex = 213
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_LoadVectorFiles
        '
        Me.ToolStripButton_LoadVectorFiles.Image = CType(resources.GetObject("ToolStripButton_LoadVectorFiles.Image"), System.Drawing.Image)
        Me.ToolStripButton_LoadVectorFiles.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_LoadVectorFiles.Name = "ToolStripButton_LoadVectorFiles"
        Me.ToolStripButton_LoadVectorFiles.Size = New System.Drawing.Size(160, 26)
        Me.ToolStripButton_LoadVectorFiles.Text = "Load vector file"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 29)
        '
        'ToolStripButton_SaveGcode
        '
        Me.ToolStripButton_SaveGcode.Image = CType(resources.GetObject("ToolStripButton_SaveGcode.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveGcode.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveGcode.Name = "ToolStripButton_SaveGcode"
        Me.ToolStripButton_SaveGcode.Size = New System.Drawing.Size(165, 26)
        Me.ToolStripButton_SaveGcode.Text = "Save GCode as"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 29)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1, Me.StatusLabel2, Me.StatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 479)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(764, 23)
        Me.StatusStrip1.TabIndex = 214
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(150, 18)
        Me.StatusLabel1.Text = "Status Label 1"
        '
        'StatusLabel2
        '
        Me.StatusLabel2.AutoSize = False
        Me.StatusLabel2.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel2.Name = "StatusLabel2"
        Me.StatusLabel2.Size = New System.Drawing.Size(150, 18)
        Me.StatusLabel2.Text = "Status Label 2"
        '
        'StatusLabel3
        '
        Me.StatusLabel3.AutoSize = False
        Me.StatusLabel3.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel3.Name = "StatusLabel3"
        Me.StatusLabel3.Size = New System.Drawing.Size(449, 18)
        Me.StatusLabel3.Spring = True
        Me.StatusLabel3.Text = "Status Label 3"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.BackColor = System.Drawing.Color.DarkGray
        Me.SplitContainer1.ForeColor = System.Drawing.Color.Black
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 53)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.LightGray
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox_Motors)
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox_Gcode)
        Me.SplitContainer1.Panel1MinSize = 32
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.LightGray
        Me.SplitContainer1.Panel2.Controls.Add(Me.GroupBox_Toolpath)
        Me.SplitContainer1.Panel2MinSize = 32
        Me.SplitContainer1.Size = New System.Drawing.Size(764, 428)
        Me.SplitContainer1.SplitterDistance = 304
        Me.SplitContainer1.TabIndex = 215
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(764, 502)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(780, 540)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino - GcodeToImage"
        Me.GroupBox_Motors.ResumeLayout(False)
        Me.GroupBox_Motors.PerformLayout()
        Me.GroupBox_Toolpath.ResumeLayout(False)
        CType(Me.Pic_GcodeViewer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Gcode.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox_Motors As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Toolpath As System.Windows.Forms.GroupBox
    Friend WithEvents Pic_GcodeViewer As System.Windows.Forms.PictureBox
    Friend WithEvents txt_PixelsY As MyTextBox
    Friend WithEvents GroupBox_Gcode As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txt_PixelsX As MyTextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txt_PixelsPerMM As MyTextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_LoadVectorFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SaveGcode As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_LoadVectorFiles As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton_SaveGcode As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents RTB As System.Windows.Forms.RichTextBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents StatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
End Class
