﻿
Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ShowWindowTitle()
        ' ----------------------------------------------------
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ----------------------------------------------------
        GCReader = New GcodeReader(Pic_GcodeViewer)
        ' ---------------------------------------------------- init and load
        Load_INI()
        ' ---------------------------------------------------- 
        SetAllParams()
        Load_Gcode()
        ' ---------------------------------------------------- workaround for split container bug
        SplitContainer1.Panel1MinSize = 300
        SplitContainer1.Panel2MinSize = 450
        ' ----------------------------------------------------
        Pic_GcodeViewer.Focus()
        EventsAreEnabled = True
        Refresh()
        Me.Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not TestGcodeModified() Then
            e.Cancel = True
            Return
        End If
        EventsAreEnabled = False
        Timer1.Enabled = False
        Save_INI()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Exit Sub
        GCReader.DisplayToolpath()
        Save_INI()
    End Sub

    'Private Sub Form1_ResizeEnd(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ResizeEnd
    '    If Not EventsAreEnabled Then Exit Sub
    '    GCReader.DisplayToolpath()
    'End Sub

    Friend Sub ShowWindowTitle()
        Text = AppTitleAndVersion()
    End Sub


    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(180, 180, 180), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub

    ' ==============================================================================================================
    '   Split container
    ' ==============================================================================================================
    Private Sub SplitContainer1_SplitterMoved(ByVal sender As Object, ByVal e As System.Windows.Forms.SplitterEventArgs) Handles SplitContainer1.SplitterMoved
        If Not EventsAreEnabled Then Exit Sub
        GCReader.DisplayToolpath()
    End Sub

    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_LoadGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_LoadVectorFile.Click
        LoadGcodeDialog()
    End Sub
    Private Sub Menu_File_SaveGcodeAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_SaveGcode.Click
        SaveGcodeDialog()
    End Sub
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        Me.Close()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        Process.Start(Application.StartupPath & "\Docs")
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog()
    End Sub

    ' =======================================================================================
    '   TOOLBAR
    ' =======================================================================================
    Private Sub ToolStripButton_LoadGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_LoadVectorFiles.Click
        LoadGcodeDialog()
    End Sub
    Private Sub ToolStripButton_SaveGcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_SaveGcode.Click
        SaveGcodeDialog()
    End Sub

    ' ==============================================================================================================
    '   Params 
    ' ==============================================================================================================
    Private Sub Params_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_PixelsPerMM.LostFocus, _
                                                                            txt_PixelsX.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub SpeedParams_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_PixelsPerMM.TextChanged, _
                                                                            txt_PixelsX.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        EventsAreEnabled = False
        SetAllParams()
        EventsAreEnabled = True
    End Sub

    Private Sub SetAllParams()

    End Sub

    ' ==============================================================================================================
    '   RICH TEXT BOX EDIT
    ' ==============================================================================================================
    Private Sub RTB_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RTB.SelectionChanged
        If Not EventsAreEnabled Then Return
        GCReader.SetGcodeLine(RTB.GetLineFromCharIndex(RTB.SelectionStart))
        ShowGcodeLine()
    End Sub
    Private Sub RTB_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RTB.TextChanged
        If Not EventsAreEnabled Then Return
        GCReader.GcodeLines = RTB.Lines
        GCReader.ReadGcodeMinMax()
        GCReader.DrawGcodeToBaseImage()
        ShowGcodeTotalLines()
        GcodeModified = True
    End Sub

    ' ====================================================================================================
    '  TIMER
    ' ====================================================================================================
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        TimedDisplay()
    End Sub

    ' ==============================================================================================================
    '   USER INTERFACE INFO - TIMED DISPLAY
    ' ==============================================================================================================
    Friend Sub TimedDisplay()
        ShowGcodeLine()
    End Sub

    ' ==============================================================================================================
    '   USER INTERFACE INFO
    ' ==============================================================================================================
    Friend Sub ShowGcodeLine()
        Static old As Int32 = Int32.MinValue
        If GCReader.GetGcodeLine <> old Then
            old = GCReader.GetGcodeLine
            StatusLabel1.Text = "Line: " + (old + 1).ToString
        End If
    End Sub
    Friend Sub ShowGcodeTotalLines()
        Static old As Int32 = Int32.MinValue
        If GCReader.GetGcodeLinesCount <> old Then
            old = GCReader.GetGcodeLinesCount
            StatusLabel2.Text = "Total lines: " + old.ToString
        End If
    End Sub
    Friend Sub ShowGcodeName()
        Static old As String = ""
        If LastFile_PathAndName <> old Then
            old = LastFile_PathAndName
            StatusLabel3.Text = "File: " + IO.Path.GetFileName(old)
        End If
    End Sub
    'Friend Sub ShowSelectedLine()
    '    Static old As Int32 = Int32.MinValue
    '    If GCReader.GetGcodeLine <> old Then
    '        old = GCReader.GetGcodeLine
    '        If old < RTB.Lines.Length Then
    '            RTB.SelectionStart = RTB.GetFirstCharIndexFromLine(old)
    '            RTB.SelectionLength = RTB.Lines(old).Length
    '        End If
    '    End If
    'End Sub


    ' ==============================================================================================================
    '   Mouse Jog
    ' ==============================================================================================================
    'Private Sub PictureBox_Test_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pic_GcodeViewer.MouseDown
    '    If GCReader.GcodeRunning Then Return
    '    If e.Button = Windows.Forms.MouseButtons.Right Then
    '        StartTimers()
    '        GCReader.SetPositionFromPboxXY(e.X, e.Y)
    '    End If
    '    Pic_GcodeViewer.Focus()
    'End Sub


End Class