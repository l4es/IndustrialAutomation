﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_MsgBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_MsgBox))
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Me.Label1 = New System.Windows.Forms.Label
        Me.PictureBox_FillBar = New System.Windows.Forms.PictureBox
        Me.Button_NO = New MyButton
        Me.Button_YES = New MyButton
        Me.Button_Cancel = New MyButton
        Me.Panel1 = New System.Windows.Forms.Panel
        CType(Me.PictureBox_FillBar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gold
        Me.Label1.Location = New System.Drawing.Point(11, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Label1"
        '
        'PictureBox_FillBar
        '
        Me.PictureBox_FillBar.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox_FillBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PictureBox_FillBar.Image = CType(resources.GetObject("PictureBox_FillBar.Image"), System.Drawing.Image)
        Me.PictureBox_FillBar.Location = New System.Drawing.Point(0, 91)
        Me.PictureBox_FillBar.Name = "PictureBox_FillBar"
        Me.PictureBox_FillBar.Size = New System.Drawing.Size(395, 23)
        Me.PictureBox_FillBar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_FillBar.TabIndex = 224
        Me.PictureBox_FillBar.TabStop = False
        '
        'Button_NO
        '
        Me.Button_NO.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_NO.BackColor = System.Drawing.Color.Transparent
        Me.Button_NO.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_NO.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.Button_NO.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.Button_NO.ColorFillBlendChecked = CBlendItems4
        Me.Button_NO.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.Button_NO.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.Button_NO.Corners.All = CType(9, Short)
        Me.Button_NO.Corners.LowerLeft = CType(9, Short)
        Me.Button_NO.Corners.LowerRight = CType(9, Short)
        Me.Button_NO.Corners.UpperLeft = CType(9, Short)
        Me.Button_NO.Corners.UpperRight = CType(9, Short)
        Me.Button_NO.DimFactorOver = 30
        Me.Button_NO.FillType = MyButton.eFillType.LinearVertical
        Me.Button_NO.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.Button_NO.FocalPoints.CenterPtX = 0.1578947!
        Me.Button_NO.FocalPoints.CenterPtY = 1.0!
        Me.Button_NO.FocalPoints.FocusPtX = 0.0!
        Me.Button_NO.FocalPoints.FocusPtY = 0.0!
        Me.Button_NO.FocalPointsChecked.CenterPtX = 1.0!
        Me.Button_NO.FocalPointsChecked.CenterPtY = 1.0!
        Me.Button_NO.FocalPointsChecked.FocusPtX = 0.0!
        Me.Button_NO.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = True
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_NO.FocusPtTracker = DesignerRectTracker4
        Me.Button_NO.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_NO.ForeColor = System.Drawing.Color.Black
        Me.Button_NO.Image = Nothing
        Me.Button_NO.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_NO.ImageIndex = 0
        Me.Button_NO.ImageSize = New System.Drawing.Size(16, 16)
        Me.Button_NO.Location = New System.Drawing.Point(138, 76)
        Me.Button_NO.Name = "Button_NO"
        Me.Button_NO.Shape = MyButton.eShape.Rectangle
        Me.Button_NO.SideImage = Nothing
        Me.Button_NO.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_NO.SideImageSize = New System.Drawing.Size(32, 32)
        Me.Button_NO.Size = New System.Drawing.Size(120, 29)
        Me.Button_NO.TabIndex = 228
        Me.Button_NO.Text = "NO"
        Me.Button_NO.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button_NO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_NO.TextMargin = New System.Windows.Forms.Padding(0)
        Me.Button_NO.TextShadow = System.Drawing.Color.Transparent
        '
        'Button_YES
        '
        Me.Button_YES.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_YES.BackColor = System.Drawing.Color.Transparent
        Me.Button_YES.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_YES.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.Button_YES.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.Button_YES.ColorFillBlendChecked = CBlendItems6
        Me.Button_YES.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.Button_YES.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.Button_YES.Corners.All = CType(9, Short)
        Me.Button_YES.Corners.LowerLeft = CType(9, Short)
        Me.Button_YES.Corners.LowerRight = CType(9, Short)
        Me.Button_YES.Corners.UpperLeft = CType(9, Short)
        Me.Button_YES.Corners.UpperRight = CType(9, Short)
        Me.Button_YES.DimFactorOver = 30
        Me.Button_YES.FillType = MyButton.eFillType.LinearVertical
        Me.Button_YES.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.Button_YES.FocalPoints.CenterPtX = 0.1578947!
        Me.Button_YES.FocalPoints.CenterPtY = 1.0!
        Me.Button_YES.FocalPoints.FocusPtX = 0.0!
        Me.Button_YES.FocalPoints.FocusPtY = 0.0!
        Me.Button_YES.FocalPointsChecked.CenterPtX = 1.0!
        Me.Button_YES.FocalPointsChecked.CenterPtY = 1.0!
        Me.Button_YES.FocalPointsChecked.FocusPtX = 0.0!
        Me.Button_YES.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_YES.FocusPtTracker = DesignerRectTracker6
        Me.Button_YES.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_YES.ForeColor = System.Drawing.Color.Black
        Me.Button_YES.Image = Nothing
        Me.Button_YES.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_YES.ImageIndex = 0
        Me.Button_YES.ImageSize = New System.Drawing.Size(16, 16)
        Me.Button_YES.Location = New System.Drawing.Point(12, 76)
        Me.Button_YES.Name = "Button_YES"
        Me.Button_YES.Shape = MyButton.eShape.Rectangle
        Me.Button_YES.SideImage = Nothing
        Me.Button_YES.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_YES.SideImageSize = New System.Drawing.Size(32, 32)
        Me.Button_YES.Size = New System.Drawing.Size(120, 29)
        Me.Button_YES.TabIndex = 229
        Me.Button_YES.Text = "YES"
        Me.Button_YES.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button_YES.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_YES.TextMargin = New System.Windows.Forms.Padding(0)
        Me.Button_YES.TextShadow = System.Drawing.Color.Transparent
        '
        'Button_Cancel
        '
        Me.Button_Cancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_Cancel.BackColor = System.Drawing.Color.Transparent
        Me.Button_Cancel.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_Cancel.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.Button_Cancel.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.Button_Cancel.ColorFillBlendChecked = CBlendItems8
        Me.Button_Cancel.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.Button_Cancel.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.Button_Cancel.Corners.All = CType(9, Short)
        Me.Button_Cancel.Corners.LowerLeft = CType(9, Short)
        Me.Button_Cancel.Corners.LowerRight = CType(9, Short)
        Me.Button_Cancel.Corners.UpperLeft = CType(9, Short)
        Me.Button_Cancel.Corners.UpperRight = CType(9, Short)
        Me.Button_Cancel.DimFactorOver = 30
        Me.Button_Cancel.FillType = MyButton.eFillType.LinearVertical
        Me.Button_Cancel.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.Button_Cancel.FocalPoints.CenterPtX = 0.1578947!
        Me.Button_Cancel.FocalPoints.CenterPtY = 1.0!
        Me.Button_Cancel.FocalPoints.FocusPtX = 0.0!
        Me.Button_Cancel.FocalPoints.FocusPtY = 0.0!
        Me.Button_Cancel.FocalPointsChecked.CenterPtX = 1.0!
        Me.Button_Cancel.FocalPointsChecked.CenterPtY = 1.0!
        Me.Button_Cancel.FocalPointsChecked.FocusPtX = 0.0!
        Me.Button_Cancel.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = True
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Button_Cancel.FocusPtTracker = DesignerRectTracker8
        Me.Button_Cancel.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Cancel.ForeColor = System.Drawing.Color.Black
        Me.Button_Cancel.Image = Nothing
        Me.Button_Cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_Cancel.ImageIndex = 0
        Me.Button_Cancel.ImageSize = New System.Drawing.Size(16, 16)
        Me.Button_Cancel.Location = New System.Drawing.Point(264, 76)
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.Button_Cancel.Shape = MyButton.eShape.Rectangle
        Me.Button_Cancel.SideImage = Nothing
        Me.Button_Cancel.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button_Cancel.SideImageSize = New System.Drawing.Size(32, 32)
        Me.Button_Cancel.Size = New System.Drawing.Size(120, 29)
        Me.Button_Cancel.TabIndex = 230
        Me.Button_Cancel.Text = "CANCEL"
        Me.Button_Cancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button_Cancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_Cancel.TextMargin = New System.Windows.Forms.Padding(0)
        Me.Button_Cancel.TextShadow = System.Drawing.Color.Transparent
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Button_Cancel)
        Me.Panel1.Controls.Add(Me.Button_YES)
        Me.Panel1.Controls.Add(Me.Button_NO)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(395, 114)
        Me.Panel1.TabIndex = 231
        '
        'Form_MsgBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(395, 114)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox_FillBar)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_MsgBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Message"
        Me.TopMost = True
        CType(Me.PictureBox_FillBar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox_FillBar As System.Windows.Forms.PictureBox
    Friend WithEvents Button_NO As MyButton
    Friend WithEvents Button_YES As MyButton
    Friend WithEvents Button_Cancel As MyButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
