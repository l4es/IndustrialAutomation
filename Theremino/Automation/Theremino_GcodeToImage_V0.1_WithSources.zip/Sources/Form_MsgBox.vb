﻿Public Class Form_MsgBox

    Private Selection As String = ""

    ' ------------------------------------------------------------ MsgBox with "YES", "NO" and "CANCEL"
    Public Function Message_YesNoCancel(ByVal text As String, _
                                          Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                          Optional ByVal FontSize As Int32 = 16, _
                                          Optional ByVal CaptionText As String = "Message") As String

        ' -------------------------------------------------------
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 30)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 20
        Button_YES.Text = "YES"
        Button_YES.Visible = True
        Button_NO.Visible = True
        Button_Cancel.Visible = True
        PictureBox_FillBar.Visible = False
        ' ------------------------------------------------------- hide and show dialog
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Message_YesNoCancel = Selection
    End Function



    ' ------------------------------------------------------------ Normal MsgBox with "YES" and "NO" selection
    Public Function Message_YesNo(ByVal text As String, _
                                  Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                  Optional ByVal FontSize As Int32 = 16, _
                                  Optional ByVal CaptionText As String = "Message") As String
        ' -------------------------------------------------------
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 30)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Label1.Text = text
        Me.Height = Label1.Bottom + 60
        Button_YES.Text = "YES"
        Button_YES.Visible = True
        Button_NO.Visible = True
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        ' ------------------------------------------------------- hide and show dialog
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Message_YesNo = Selection
    End Function

    ' ------------------------------------------------------------ MsgBox with "OK" selection

    Public Function Message_OK(ByVal text As String, _
                               Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                               Optional ByVal FontSize As Int32 = 16, _
                               Optional ByVal CaptionText As String = "Message") As String
        ' ------------------------------------------------------- 
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 30)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 60
        Button_YES.Text = "OK"
        Button_YES.Visible = True
        Button_NO.Visible = False
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        ' ------------------------------------------------------- hide and show dialog
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Message_OK = Selection
    End Function


    ' ------------------------------------------------------------ Special MESSAGE ( can be closed programmatically )
    Public Sub Message(ByVal text As String, _
                       Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                       Optional ByVal FontSize As Int32 = 16, _
                       Optional ByVal CopyButtonVisible As Boolean = False, _
                       Optional ByVal CaptionText As String = "Message")
        ' -------------------------------------------------------
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 30)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 30
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = CopyButtonVisible
        PictureBox_FillBar.Visible = False
        ' ------------------------------------------------------- show
        Me.Show()
        Me.Refresh()
    End Sub


    ' ------------------------------------------------------------ Special MESSAGE with progressbar
    Public Sub MessageWithProgressBar(ByVal text As String, _
                                      Optional ByVal align As ContentAlignment = ContentAlignment.TopLeft, _
                                      Optional ByVal FontSize As Int32 = 16, _
                                      Optional ByVal CopyButtonVisible As Boolean = False, _
                                      Optional ByVal CaptionText As String = "Message")

        ' ------------------------------------------------------- restore minimal dimension
        Label1.Text = ""
        Me.AutoSize = False
        Me.AutoSize = True
        ' -------------------------------------------------------
        Me.Text = CaptionText
        text = Replace(text, "VisualBasic", "VB")
        text = WordWrap(text, 30)
        SetLabelFontSize(Label1, FontSize)
        Label1.TextAlign = align
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 30
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = CopyButtonVisible
        PictureBox_FillBar.Visible = True
        ' ------------------------------------------------------- show
        Me.Show()
        Me.Refresh()
    End Sub


    ' ------------------------------------------------------------ Select text row ( can be closed programmatically )
    Public Function Message_Select(ByVal text As String, _
                                Optional ByVal FontSize As Int32 = 16, _
                                Optional ByVal CaptionText As String = "Select") As String

        ' ------------------------------------------------------- restore minimal dimension
        Label1.Text = ""
        Me.AutoSize = False
        Me.AutoSize = True
        ' -------------------------------------------------------
        Me.Text = CaptionText
        SetLabelFontSize(Label1, FontSize)
        Label1.Cursor = Cursors.Hand
        Label1.TextAlign = ContentAlignment.TopLeft
        Me.Label1.Text = text
        Me.Height = Label1.Bottom + 20
        Button_YES.Visible = False
        Button_NO.Visible = False
        Button_Cancel.Visible = False
        PictureBox_FillBar.Visible = False
        ' ------------------------------------------------------- hide and show dialog
        Me.Hide()
        Me.ShowDialog()
        Me.Refresh()
        Label1.Cursor = Cursors.Default
        Return Selection
    End Function

    ' ------------------------------------------------------------ Close MESSAGES
    Public Sub CloseMessage()
        Me.Hide()
    End Sub

    ' =============================================================================
    '  Event Handlers
    ' =============================================================================
    Private Sub Button_YES_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_YES.Click
        Selection = "YES"
        Me.Hide()
    End Sub
    Private Sub Button_NO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_NO.Click
        Selection = "NO"
        Me.Hide()
    End Sub
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_cancel.Click
        Selection = "CANCEL"
        Me.Hide()
    End Sub

    Private Sub Label1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseDown
        Dim line As Int32 = GetSelectedLine(Label1, e.Y)
        Selection = GetLineText(Label1, line)
        Me.Hide()
    End Sub


    ' ------------------------------------------------------------------------------- helper functons
    Private Function GetSelectedLine(ByVal l As Label, ByVal Y As Int32) As Int32
        Return Y \ l.Font.Height
    End Function

    Private Function GetLineText(ByVal l As Label, ByVal line As Int32) As String
        Dim s As String() = Split(Label1.Text, vbCr)
        If line >= LBound(s) And line <= UBound(s) Then
            Return s(line)
        Else
            Return ""
        End If
    End Function

    Private Sub SetLabelFontSize(ByRef lb As Label, ByVal size As Int32)
        Dim f As New Font("Arial", size)
        lb.Font = f
    End Sub

End Class