﻿
Imports System.Math
Imports System.Collections.Generic


Module Module_GcodeReader

    ' ==================================================================================================
    '   Gcode Reader
    ' ==================================================================================================
    Friend GCReader As GcodeReader

    ' ==================================================================================================
    '   CLASS GCODE READER
    ' ==================================================================================================
    Friend Class GcodeReader

        Private Enum Feed_Modes As Int32
            None
            Rapid
            Work
        End Enum

        Private mMinX As Double
        Private mMinY As Double
        Private mMinZ As Double
        Private mMaxX As Double
        Private mMaxY As Double
        Private mMaxZ As Double

        Private gMarginX As Int32 = 4
        Private gMarginY As Int32 = 4
        Private gSizeX As Int32
        Private gSizeY As Int32
        Private gZeroX As Double
        Private gZeroY As Double
        Private gscale As Double = 1

        Friend WorkSpeedLocked As Boolean = True

        Private ToolpathPic As PictureBox
        Private ToolpathGfx As Graphics

        Private Ready As Boolean
        Private mFeedMode As Feed_Modes
        Private mFeedRapid As Double
        Friend mFeedWork As Double
        Private mMaxError As Double

        Friend GcodeLines() As String = {"- - -"}

        ' ------------------------------------------ working positions
        Friend Dest As Vec5
        Friend Tip As Vec5

        Friend Sub New(ByRef _ToolpathPic As PictureBox)
            ToolpathPic = _ToolpathPic
            mFeedMode = Feed_Modes.None
        End Sub

        ' ==================================================================================================
        '   DISPLAY TOOLPATH
        ' ==================================================================================================
        Private Function XtoPixel(ByVal x As Double) As Int32
            If Double.IsNaN(x) Then x = 0
            Return CInt((x - gZeroX) * gscale) + gMarginX
        End Function
        Private Function YtoPixel(ByVal y As Double) As Int32
            If Double.IsNaN(y) Then y = 0
            Return CInt(gSizeY - (y - gZeroY) * gscale) - gMarginY
        End Function
        Private Function PixelToX(ByVal px As Int32) As Double
            Return ((px - gMarginX) / gscale) + gZeroX
        End Function
        Private Function PixelToY(ByVal py As Int32) As Double
            Return (gSizeY - (py + gMarginY)) / gscale + gZeroY
        End Function

        Friend Sub DisplayToolpath()
            If ToolpathPic.ClientSize.Width < 1 Then Return
            If LastFile_PathAndName.EndsWith(".wmf", StringComparison.InvariantCultureIgnoreCase) Or _
               LastFile_PathAndName.EndsWith(".emf", StringComparison.InvariantCultureIgnoreCase) Then Return
            InitPboxImageAndGraphics()
            ReadGcodeMinMax()
            DrawGcodeToBaseImage()
            ToolpathGfx.DrawImage(BaseImage, 0, 0)
        End Sub

        Private Sub InitPboxImageAndGraphics()
            gSizeX = ToolpathPic.ClientSize.Width
            gSizeY = ToolpathPic.ClientSize.Height
            ' ------------------------------------------------------------------------ using a bitmap for best performance
            If ToolpathPic.Image Is Nothing OrElse _
               ToolpathPic.Image.Width <> gSizeX OrElse _
               ToolpathPic.Image.Height <> gSizeY Then
                InitPictureboxImage(ToolpathPic)
            End If
            ' ------------------------------------------------------------------------ "Graphics.FromImage" for best performance
            ToolpathGfx = Graphics.FromImage(ToolpathPic.Image)
            ToolpathGfx.Clear(Color.FromArgb(255, 255, 230))
        End Sub

        ' ==================================================================================================
        '   DRAW GCODE TO BASE IMAGE
        ' ==================================================================================================
        Private BaseImage As Image

        Friend Sub DrawGcodeToBaseImage()
            '
            If Form1.WindowState = FormWindowState.Minimized Then Return
            If ToolpathGfx Is Nothing Then Return
            ' -------------------------------------------- CLEAR image and prepare background
            ToolpathGfx.Clear(ToolpathPic.BackColor)
            'DrawScale()
            ' -------------------------------------------- 
            If GcodeLines Is Nothing Then Return
            ' -------------------------------------------- init vars
            Dim p1 As Pen = New Pen(Color.Red, 1)
            Dim p2 As Pen = New Pen(ToolpathPic.ForeColor, 2)
            Dim x As Int32
            Dim y As Int32
            Dim oldx As Int32
            Dim oldy As Int32
            ' -------------------------------------------- init gcode params
            Dim PrivateGcodeParams As GCODE_PARAMS
            With PrivateGcodeParams
                .Line = 0
                .FeedMode = Feed_Modes.Rapid
                .Coord.x = Tip.x
                .Coord.y = Tip.y
                .Coord.z = Tip.z
                ' -------------------------------------------- invalidate old position
                oldx = -99999
                While .Line < GcodeLines.Length
                    If GcodeLines(.Line).Trim.StartsWith("END", StringComparison.InvariantCultureIgnoreCase) Then
                        Exit While
                    End If
                    ' ---------------------------------------- 
                    ReadGcodeLine(False, PrivateGcodeParams)
                    x = XtoPixel(.Coord.x)
                    y = YtoPixel(.Coord.y)
                    ' ---------------------------------------- 
                    If x <> oldx OrElse y <> oldy Then
                        If oldx > -99999 Then
                            If .FeedMode = Feed_Modes.Rapid Then
                                ToolpathGfx.DrawLine(p1, oldx, oldy, x, y)
                            Else
                                ToolpathGfx.DrawLine(p2, oldx, oldy, x, y)
                            End If
                        End If
                        oldx = x
                        oldy = y
                    End If
                End While
            End With
            'ToolpathGfx.DrawLine(p1, oldx, oldy, x, y)
            ' -------------------------------------------- 
            ToolpathPic.Refresh()
            BaseImage = CType(ToolpathPic.Image.Clone, Image)
            ' -------------------------------------------- 
            'OldToolX = -9999999
        End Sub

        'Private ToolPenWork As Pen = New Pen(Color.Red, 3)
        'Private ToolPenRapid As Pen = New Pen(Color.Green, 3)
        'Private OldToolX As Int32
        'Private OldToolY As Int32
        'Friend Sub DrawToolPosition()
        '    Dim x As Int32 = XtoPixel(Tip.x)
        '    Dim y As Int32 = YtoPixel(Tip.y)
        '    If x <> OldToolX OrElse y <> OldToolY AndAlso OldToolX > -9999999 Then
        '        If mFeedMode = Feed_Modes.Rapid Then
        '            ToolpathGfx.DrawLine(ToolPenRapid, OldToolX, OldToolY, x, y)
        '        Else
        '            ToolpathGfx.DrawLine(ToolPenWork, OldToolX, OldToolY, x, y)
        '        End If
        '        ToolpathPic.Refresh()
        '    End If
        '    OldToolX = x
        '    OldToolY = y
        'End Sub

        Friend Sub ReadGcodeMinMax()
            'Dim st As Stopwatch = New Stopwatch
            'st.Start()
            If Form1.WindowState = FormWindowState.Minimized Then Return
            'If GcodeRunning Then Return
            If GcodeLines Is Nothing Then Return
            ' -------------------------------------------- init vars
            Dim minx As Double = Double.MaxValue
            Dim miny As Double = Double.MaxValue
            Dim minz As Double = Double.MaxValue
            Dim maxx As Double = Double.MinValue
            Dim maxy As Double = Double.MinValue
            Dim maxz As Double = Double.MinValue
            ' -------------------------------------------- init gcode params
            Dim PrivateGcodeParams As GCODE_PARAMS
            With PrivateGcodeParams
                .Line = 0
                .FeedMode = Feed_Modes.Rapid
                .Coord.x = Tip.x
                .Coord.y = Tip.y
                .Coord.z = Tip.z
                ' --------------------------------------------
                While .Line < GcodeLines.Length
                    If GcodeLines(.Line).Trim.StartsWith("END", StringComparison.InvariantCultureIgnoreCase) Then
                        Exit While
                    End If
                    ' ---------------------------------------- 
                    ReadGcodeLine(False, PrivateGcodeParams)
                    If .Coord.x < minx Then minx = .Coord.x
                    If .Coord.y < miny Then miny = .Coord.y
                    If .Coord.z < minz Then minz = .Coord.z
                    If .Coord.x > maxx Then maxx = .Coord.x
                    If .Coord.y > maxy Then maxy = .Coord.y
                    If .Coord.z > maxz Then maxz = .Coord.z
                End While
            End With
            ' -------------------------------------------- min and max
            mMinX = minx
            mMinY = miny
            mMinZ = minz
            mMaxX = maxx
            mMaxY = maxy
            mMaxZ = maxz
            ' -------------------------------------------- scale
            Dim sx As Double = (gSizeX - gMarginX * 2) / (mMaxX - mMinX)
            Dim sy As Double = (gSizeY - gMarginY * 2) / (mMaxY - mMinY)
            gscale = Math.Min(sx, sy)
            If Double.IsInfinity(gscale) Then gscale = 1
            ' -------------------------------------------- zero
            gZeroX = mMinX
            gZeroY = mMinY
            ' -------------------------------------------- tool pens
            'ToolPenWork = New Pen(Color.Green, CInt(0.2 * gscale))
            'ToolPenRapid = New Pen(Color.Red, CInt(0.2 * gscale))
            ' -------------------------------------------- 
            'Form1.Text = st.ElapsedMilliseconds.ToString
        End Sub


        ' ==================================================================================================
        '   ReadGcodeLine
        ' ==================================================================================================
        Private LastToken As String = ""
        Private Sub ReadGcodeLine(ByVal HardwareEnabled As Boolean, ByRef GcParams As GCODE_PARAMS)
            Dim l As List(Of String) = SplitTokens(GcodeLines(GcParams.Line))
            GcParams.Line += 1
            If l(0) = "{" Then Return
            Dim v As Double
            For Each s As String In l
                If s <> "" Then
                    Select Case s.Substring(0, 1)
                        Case "G"
                            Select Case s
                                Case "G0", "G00"
                                    GcParams.FeedMode = Feed_Modes.Rapid
                                Case "G1", "G01"
                                    GcParams.FeedMode = Feed_Modes.Work
                                Case "G2", "G02", "G3", "G03", "G17" ' interpolations
                                    GcParams.FeedMode = Feed_Modes.Work
                                Case "G21" ' interpolations
                                    GcParams.FeedMode = Feed_Modes.Work
                                Case "G04" ' pause with "F"
                                    ' required to not change FeedMode
                                Case Else
                                    GcParams.FeedMode = Feed_Modes.None
                            End Select
                        Case "F"
                            If HardwareEnabled Then
                                If LastToken = "G04" Then
                                    Dim TimeSeconds As Double = Val(Mid(s, 2))
                                    Dim sw As Stopwatch = New Stopwatch
                                    sw.Start()
                                    Do
                                        Application.DoEvents()
                                        SleepMyThread(10)
                                    Loop Until sw.Elapsed.TotalSeconds > TimeSeconds Or Not GcodeRunning
                                Else
                                    If Not WorkSpeedLocked Then
                                        Dim newFeed As Double = Val(Mid(s, 2))
                                        If newFeed >= 10 Then mFeedWork = newFeed
                                    End If
                                End If
                            End If
                        Case "X"
                            If GcParams.FeedMode <> Feed_Modes.None Then
                                GcParams.Coord.x = Val(Mid(s, 2)) '* Scale.x + Origin.x
                            End If
                        Case "Y"
                            If GcParams.FeedMode <> Feed_Modes.None Then
                                GcParams.Coord.y = Val(Mid(s, 2)) '* Scale.y + Origin.y
                            End If
                        Case "Z"
                            If GcParams.FeedMode <> Feed_Modes.None Then
                                v = Val(Mid(s, 2))
                                GcParams.Coord.z = v '* Scale.z + Origin.z
                            End If
                        Case "A"
                            If GcParams.FeedMode <> Feed_Modes.None Then
                                v = Val(Mid(s, 2))
                                GcParams.Coord.a = v '* Scale.a + Origin.a
                            End If
                        Case "B"
                            If GcParams.FeedMode <> Feed_Modes.None Then
                                v = Val(Mid(s, 2))
                                GcParams.Coord.b = v '* Scale.b + Origin.b
                            End If
                        Case "("
                            ' ----------------------- comments
                            Exit For
                        Case "N"
                            ' ----------------------- line numbers
                        Case Else
                            ' ----------------------- unknown codes
                    End Select
                    LastToken = s
                End If
            Next
        End Sub

        ' ---------------------------------------------------- test chars for GCode tokenizing
        Private testChars As String = "+-. 0123456789" & vbTab
        Private Function SplitTokens(ByVal l As String) As List(Of String)
            SplitTokens = New List(Of String)
            l = l.ToUpper
            l = l.Replace(",", ".")
            Dim i As Int32 = 1
            Dim j As Int32 = 2
            Do
                If j > l.Length OrElse Not testChars.Contains(Mid(l, j, 1)) Then
                    SplitTokens.Add(Mid(l, i, j - i).Trim)
                    If j > l.Length Then Exit Do
                    i = j
                    j = i + 1
                Else
                    j += 1
                End If
            Loop
        End Function

        Friend Sub SetGcodeLine(ByVal line As Int32)
            If line > GcodeLines.Length Then line = GcodeLines.Length
            GcodeParams.Line = line
        End Sub

        Friend Function GetGcodeLine() As Int32
            Return GcodeParams.Line
        End Function

        Friend Function GetGcodeLinesCount() As Int32
            Return GcodeLines.Length()
        End Function

        Friend Sub SetFeedMode_None()
            mFeedMode = Feed_Modes.None
        End Sub

        ' ==================================================================================================
        '   GCODE PARAMS
        ' ==================================================================================================
        Private Structure GCODE_PARAMS
            Dim Line As Int32
            Dim Coord As Vec5
            Dim FeedMode As Feed_Modes
        End Structure
        Private GcodeParams As GCODE_PARAMS

        Friend GcodeRunning As Boolean = False

    End Class

End Module
