﻿
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   Files
    ' =======================================================================================================
    Private Function FileIsInAppFolders(ByVal filename As String) As Boolean
        If filename.StartsWith(Application.StartupPath, StringComparison.InvariantCultureIgnoreCase) Then
            Return True
        Else
            Return False
        End If
    End Function
    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function
    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function
    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function
    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function
    Public Function GetPath(ByVal str As String) As String
        Try
            Return IO.Path.GetDirectoryName(str) & "\"
        Catch
            Return str
        End Try
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function



    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = s.Trim
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    'Friend Sub SaveConfigurationAs()
    '    Dim sfd As SaveFileDialog = New SaveFileDialog()
    '    sfd.DefaultExt = ".txt"
    '    sfd.Filter = "Configuration file (*.txt)|*txt"
    '    'sfd.FileName = AssemblyName() & "_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
    '    sfd.FileName = "ARM_INI_" & Date.Now.ToString("yyyy_MM_dd_HH_mm_ss")
    '    If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
    '        Save_INI(sfd.FileName)
    '    End If
    'End Sub

    'Friend Sub LoadConfiguration()
    '    Dim ofd As OpenFileDialog = New OpenFileDialog
    '    ofd.Filter = "Configuration file (*.txt)|*txt"
    '    If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
    '        Load_INI(ofd.FileName)
    '    End If
    'End Sub

    Friend Sub Save_INI()
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            f.WriteLine(TabString("Form1_SplitterDistance", Form1.SplitContainer1.SplitterDistance))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Precision"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("FeedRapid", Form1.txt_PixelsPerMM.NumericValueInteger))
            f.WriteLine(TabString("FeedNormal", Form1.txt_PixelsX.NumericValueInteger))
            f.WriteLine(TabString("JogStep", Form1.txt_PixelsY.NumericValue, "0.0"))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" LastFile"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("LastFile", LastFile_PathAndName))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")

        If My.Computer.FileSystem.FileExists(iniFileName) Then

            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = Val_Int(l)
                    Case "Form1_Left" : Form1.Left = Val_Int(l)
                    Case "Form1_Width" : Form1.Width = Val_Int(l)
                    Case "Form1_Height" : Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : Form1.WindowState = CType((Val(l)), FormWindowState)
                    Case "Form1_SplitterDistance" : Form1.SplitContainer1.SplitterDistance = Val_Int(l)
                        ' --------------------------------------------------------------- Speed
                    Case "FeedRapid" : Form1.txt_PixelsPerMM.NumericValueInteger = Val_Int(l)
                    Case "FeedNormal" : Form1.txt_PixelsX.NumericValueInteger = Val_Int(l)
                    Case "JogStep" : Form1.txt_PixelsY.NumericValue = Val_Double(l)
                        ' --------------------------------------------------------------- LastFile
                    Case "LastFile" : LastFile_PathAndName = l
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
    End Sub


    ' ==================================================================================================
    '  SAVE LOAD -- GCODE
    ' ==================================================================================================
    Friend LastFile_PathAndName As String = ""
    Friend GcodeModified As Boolean = False

    Friend Sub SaveGcode_IfChanged()
        If GcodeModified Then
            Save_Gcode(LastFile_PathAndName)
        End If
    End Sub

    Friend Sub Save_Gcode(Optional ByVal fileName As String = "")
        If fileName = "" Then
            SaveGcodeDialog()
            Return
        End If
        Try
            Form1.RTB.SaveFile(fileName, RichTextBoxStreamType.PlainText)
            LastFile_PathAndName = fileName
            Form1.ShowGcodeName()
            GcodeModified = False
        Catch
        End Try
    End Sub

    Friend Sub Load_Gcode(Optional ByVal fileName As String = "")
        ' -------------------------------------------------------------------------------
        'SaveGcode_IfChanged()
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        If fileName = "" Then fileName = LastFile_PathAndName
        ' -------------------------------------------------------------------------------
        If Not My.Computer.FileSystem.FileExists(fileName) Then
            fileName = FindFileInAppFolders(fileName)
        End If
        ' -------------------------------------------------------------------------------
        If My.Computer.FileSystem.FileExists(fileName) Then
            ' ------------------------------------------------------------------------------- 
            LastFile_PathAndName = fileName
            Form1.ShowWindowTitle()
            If Not FileIsInAppFolders(fileName) Then
                MsgBox("Warning the program path is outside the application folders")
            End If
            Form1.Pic_GcodeViewer.Image = Nothing
            ' ------------------------------------------------------------------------------- WMF
            If fileName.EndsWith(".wmf", StringComparison.InvariantCultureIgnoreCase) Then
                Form1.Pic_GcodeViewer.Load(fileName)
                Form1.RTB.Text = "File is WMF"
                GCReader.GcodeLines = Form1.RTB.Lines
                ' --------------------------------------------------------------------------- EMF
            ElseIf fileName.EndsWith(".emf", StringComparison.InvariantCultureIgnoreCase) Then
                Form1.Pic_GcodeViewer.Load(fileName)
                Form1.RTB.Text = "File is EMF"
                GCReader.GcodeLines = Form1.RTB.Lines
                ' --------------------------------------------------------------------------- DXF
            ElseIf fileName.EndsWith(".dxf", StringComparison.InvariantCultureIgnoreCase) Then
                Form1.Pic_GcodeViewer.Load(fileName)
                Form1.RTB.Text = "File is DXF"
                GCReader.GcodeLines = Form1.RTB.Lines
            Else
                ' --------------------------------------------------------------------------- GCODE LOAD 1
                'GCReader.GcodeLines = IO.File.ReadAllLines(GcodeFile_PathAndName )
                ' --------------------------------------------------------------------------- GCODE LOAD 2
                Dim allfile As String = IO.File.ReadAllText(LastFile_PathAndName)
                allfile = allfile.Replace(vbCr + vbCr, vbCr)
                allfile = allfile.Replace(vbCrLf, vbCr)
                GCReader.GcodeLines = Split(allfile, vbCr)
                ' ---------------------------------------------------------------------------
                Form1.RTB.Lines = GCReader.GcodeLines
                GcodeModified = False
                GCReader.SetGcodeLine(0)
                GCReader.SetFeedMode_None()
                GCReader.DisplayToolpath()
                'GCReader.DrawGcodeToBaseImage()
            End If
            ' ------------------------------------------------------------------------------- 
            Form1.ShowGcodeLine()
            Form1.ShowGcodeTotalLines()
            Form1.ShowGcodeName()
        End If
    End Sub

    Private Function FindFileInAppFolders(ByVal fname As String) As String
        fname = IO.Path.GetFileName(fname)
        Dim FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim wildcards() As String = {"*.*"}
        Dim s As String = Application.StartupPath & "\"
        FileNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchAllSubDirectories, wildcards)
        For Each str As String In FileNames
            If str.EndsWith(fname) Then
                Return str
            End If
        Next
        Return ""
    End Function

    Friend Function TestGcodeModified() As Boolean
        While GcodeModified
            Select Case Form_MsgBox.Message_YesNoCancel("Gcode modified. Save it?", ContentAlignment.MiddleLeft)
                Case "YES"
                    SaveGcodeDialog()
                Case "NO"
                    GcodeModified = False
                    Return True
                Case "CANCEL"
                    Return False
            End Select
        End While
        Return True
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- PROGRAMS -- DIALOGS
    ' ==================================================================================================
    Friend Sub SaveGcodeDialog()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.InitialDirectory = PrepareSaveLoadFolder()
        sfd.FileName = IO.Path.GetFileName(LastFile_PathAndName)
        'SFD.RestoreDirectory = False
        sfd.AutoUpgradeEnabled = True
        sfd.Title = "Save script file"
        sfd.ValidateNames = False
        sfd.DefaultExt = ".txt"
        sfd.AddExtension = True
        sfd.Filter = "All files (*.*)|*.*"
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Save_Gcode(sfd.FileName)
        End If
    End Sub

    Friend Sub LoadGcodeDialog()
        If Not TestGcodeModified() Then
            Return
        End If
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ofd.InitialDirectory = PrepareSaveLoadFolder()
        ofd.FileName = IO.Path.GetFileName(LastFile_PathAndName)
        'OFD.RestoreDirectory = True
        ofd.AutoUpgradeEnabled = True
        ofd.Title = "Load program file"
        ofd.ValidateNames = False
        ofd.Multiselect = True
        ofd.Filter = "All files (*.*)|*.*"
        ofd.DefaultExt = ".txt"
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            EventsAreEnabled = False
            Load_Gcode(ofd.FileName)
            EventsAreEnabled = True
        End If
    End Sub

    Private Function PrepareSaveLoadFolder() As String
        PrepareSaveLoadFolder = ""
        If My.Computer.FileSystem.FileExists(LastFile_PathAndName) Then
            PrepareSaveLoadFolder = GetPath(LastFile_PathAndName)
        End If
        If Not FolderExists(PrepareSaveLoadFolder) Or Not FileIsInAppFolders(PrepareSaveLoadFolder) Then
            PrepareSaveLoadFolder = Windows.Forms.Application.StartupPath & "\GCodes"
        End If
        PrepareSaveLoadFolder = PlatformAdjustedFileName(PrepareSaveLoadFolder)
    End Function

End Module
