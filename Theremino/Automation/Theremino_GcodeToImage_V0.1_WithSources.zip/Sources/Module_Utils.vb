
Imports System.Math

Module Module_Utils


    ' =========================================================================================
    '  WordWrap 
    ' -----------------------------------------------------------------------------------------
    '   - il wrap avviene prevalentemente in corrispondenza di spazi o altri caratteri speciali
    '   - se nessun punto valido viene trovato allora vengono spezzate anche le parole
    '      in modo che "MaxLen" non venga mai superato 
    ' =========================================================================================
    Friend Function WordWrap(ByVal strText As String, ByVal MaxLen As Int32) As String
        '
        WordWrap = ""
        Dim lastSplitPoint As Int32 = 0
        Dim LineLen As Int32 = 0
        '
        For i As Int32 = 0 To strText.Length - 1
            '
            Dim ch As Char = strText(i)
            '
            If InStr(" ~`!@#$%^&*()_-+={}[]|\:;""'<>,.?/", ch) > 0 Then
                lastSplitPoint = i
            End If
            '
            If LineLen >= MaxLen - 1 Then
                ' ------------------------------------------ se e' possibile spezzo un po' prima
                If i - lastSplitPoint < LineLen / 2 Then
                    WordWrap = Left(WordWrap, WordWrap.Length - (i - lastSplitPoint - 1)) & vbCr
                    i = lastSplitPoint
                Else
                    ' -------------------------------------- altrimenti taglio la parola dove capita
                    WordWrap += ch & vbCr
                End If
                ' ------------------------------------------ aggiorno la lunghezza
                LineLen = 0
            Else
                ' ------------------------------------------ se la riga e' ancora corta accodo il nuovo carattere
                WordWrap += ch
                ' ------------------------------------------ e aggiorno la lunghezza
                If ch = vbCr Then
                    LineLen = 0
                Else
                    LineLen += 1
                End If
            End If
        Next
    End Function





    ' =======================================================================================
    '  Utils
    ' =======================================================================================
    Friend Sub SleepMyThread(ByVal TimeMillisec As Int32)
        System.Threading.Thread.Sleep(TimeMillisec)
    End Sub

    Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
        With pbox
            If .ClientSize.Width < 1 Then Return
            .Image = New Bitmap(.ClientSize.Width, .ClientSize.Height)
        End With
    End Sub

    ' =============================================================================================
    '  ASYNC KEY and MOUSE STATE
    ' =============================================================================================
    Private Const PRESSED_NOW As Int32 = &H8000
    Private Const PRESSED_AFTER_PREVIOUS_CALL As Int32 = &H1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Int32) As Int16
    'Friend Function KeyFromPreviousCall(ByVal k As Int32) As Boolean
    '    KeyPrevious = (GetAsyncKeyState(k) And PRESSED_AFTER_PREVIOUS_CALL) <> 0
    'End Function
    Friend Function Key(ByVal k As Keys) As Boolean
        Key = (GetAsyncKeyState(k) And PRESSED_NOW) <> 0
    End Function
    'Friend Sub WaitMouseOff()
    '    While Key(Keys.LButton) Or Key(Keys.MButton) Or Key(Keys.RButton)
    '        SleepMyThread(1)
    '    End While
    'End Sub
    'Friend Sub WaitKeyOff(ByVal WaitKey As Long)
    '    Do
    '        SleepMyThread(1)
    '    Loop Until Not Key(WaitKey)
    'End Sub

End Module





