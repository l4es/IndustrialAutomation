﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems2 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker2 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker5 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems5 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems6 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker6 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker7 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems7 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems8 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker8 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker9 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems9 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems10 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker10 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker11 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems11 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems12 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker12 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker13 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems13 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems14 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker14 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker3 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems3 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems4 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker4 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Me.btn_LoadImage = New CustomControlsLib.MyButton
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.btn_Resize = New CustomControlsLib.MyButton
        Me.btn_Vectorize = New CustomControlsLib.MyButton
        Me.btn_Rosenfeld2 = New CustomControlsLib.MyButton
        Me.btn_Rosenfeld = New CustomControlsLib.MyButton
        Me.btn_ReloadImage = New CustomControlsLib.MyButton
        Me.Pbox1 = New System.Windows.Forms.PictureBox
        Me.btn_TestHexagons = New CustomControlsLib.MyButton
        Me.GroupBox9.SuspendLayout()
        CType(Me.Pbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_LoadImage
        '
        Me.btn_LoadImage.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_LoadImage.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadImage.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_LoadImage.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_LoadImage.ColorFillBlendChecked = CBlendItems2
        Me.btn_LoadImage.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_LoadImage.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_LoadImage.Corners.All = CType(6, Short)
        Me.btn_LoadImage.Corners.LowerLeft = CType(6, Short)
        Me.btn_LoadImage.Corners.LowerRight = CType(6, Short)
        Me.btn_LoadImage.Corners.UpperLeft = CType(6, Short)
        Me.btn_LoadImage.Corners.UpperRight = CType(6, Short)
        Me.btn_LoadImage.DimFactorOver = 30
        Me.btn_LoadImage.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_LoadImage.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_LoadImage.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_LoadImage.FocalPoints.CenterPtY = 1.0!
        Me.btn_LoadImage.FocalPoints.FocusPtX = 0.0!
        Me.btn_LoadImage.FocalPoints.FocusPtY = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadImage.FocusPtTracker = DesignerRectTracker2
        Me.btn_LoadImage.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LoadImage.Image = Nothing
        Me.btn_LoadImage.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.ImageIndex = 0
        Me.btn_LoadImage.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_LoadImage.Location = New System.Drawing.Point(6, 430)
        Me.btn_LoadImage.Name = "btn_LoadImage"
        Me.btn_LoadImage.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_LoadImage.SideImage = Nothing
        Me.btn_LoadImage.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_LoadImage.Size = New System.Drawing.Size(62, 32)
        Me.btn_LoadImage.TabIndex = 216
        Me.btn_LoadImage.Text = "Load Image"
        Me.btn_LoadImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_LoadImage.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_LoadImage.TextShadow = System.Drawing.Color.Transparent
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox9.Controls.Add(Me.btn_TestHexagons)
        Me.GroupBox9.Controls.Add(Me.btn_Resize)
        Me.GroupBox9.Controls.Add(Me.btn_Vectorize)
        Me.GroupBox9.Controls.Add(Me.btn_Rosenfeld2)
        Me.GroupBox9.Controls.Add(Me.btn_Rosenfeld)
        Me.GroupBox9.Controls.Add(Me.btn_ReloadImage)
        Me.GroupBox9.Controls.Add(Me.btn_LoadImage)
        Me.GroupBox9.Controls.Add(Me.Pbox1)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(8, 9)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(690, 470)
        Me.GroupBox9.TabIndex = 149
        Me.GroupBox9.TabStop = False
        '
        'btn_Resize
        '
        Me.btn_Resize.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Resize.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Resize.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Resize.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Resize.ColorFillBlendChecked = CBlendItems6
        Me.btn_Resize.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Resize.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Resize.Corners.All = CType(6, Short)
        Me.btn_Resize.Corners.LowerLeft = CType(6, Short)
        Me.btn_Resize.Corners.LowerRight = CType(6, Short)
        Me.btn_Resize.Corners.UpperLeft = CType(6, Short)
        Me.btn_Resize.Corners.UpperRight = CType(6, Short)
        Me.btn_Resize.DimFactorOver = 30
        Me.btn_Resize.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Resize.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Resize.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Resize.FocalPoints.CenterPtY = 1.0!
        Me.btn_Resize.FocalPoints.FocusPtX = 0.0!
        Me.btn_Resize.FocalPoints.FocusPtY = 0.0!
        Me.btn_Resize.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Resize.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Resize.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Resize.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Resize.FocusPtTracker = DesignerRectTracker6
        Me.btn_Resize.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Resize.Image = Nothing
        Me.btn_Resize.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Resize.ImageIndex = 0
        Me.btn_Resize.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Resize.Location = New System.Drawing.Point(179, 430)
        Me.btn_Resize.Name = "btn_Resize"
        Me.btn_Resize.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_Resize.SideImage = Nothing
        Me.btn_Resize.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Resize.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Resize.Size = New System.Drawing.Size(58, 32)
        Me.btn_Resize.TabIndex = 227
        Me.btn_Resize.Text = "Resize"
        Me.btn_Resize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Resize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Resize.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Resize.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Vectorize
        '
        Me.btn_Vectorize.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Vectorize.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Vectorize.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Vectorize.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Vectorize.ColorFillBlendChecked = CBlendItems8
        Me.btn_Vectorize.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Vectorize.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Vectorize.Corners.All = CType(6, Short)
        Me.btn_Vectorize.Corners.LowerLeft = CType(6, Short)
        Me.btn_Vectorize.Corners.LowerRight = CType(6, Short)
        Me.btn_Vectorize.Corners.UpperLeft = CType(6, Short)
        Me.btn_Vectorize.Corners.UpperRight = CType(6, Short)
        Me.btn_Vectorize.DimFactorOver = 30
        Me.btn_Vectorize.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Vectorize.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Vectorize.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Vectorize.FocalPoints.CenterPtY = 1.0!
        Me.btn_Vectorize.FocalPoints.FocusPtX = 0.0!
        Me.btn_Vectorize.FocalPoints.FocusPtY = 0.0!
        Me.btn_Vectorize.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Vectorize.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Vectorize.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Vectorize.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Vectorize.FocusPtTracker = DesignerRectTracker8
        Me.btn_Vectorize.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Vectorize.Image = Nothing
        Me.btn_Vectorize.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Vectorize.ImageIndex = 0
        Me.btn_Vectorize.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Vectorize.Location = New System.Drawing.Point(492, 430)
        Me.btn_Vectorize.Name = "btn_Vectorize"
        Me.btn_Vectorize.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_Vectorize.SideImage = Nothing
        Me.btn_Vectorize.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Vectorize.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Vectorize.Size = New System.Drawing.Size(69, 32)
        Me.btn_Vectorize.TabIndex = 226
        Me.btn_Vectorize.Text = "Vectorize"
        Me.btn_Vectorize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Vectorize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Vectorize.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Vectorize.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Rosenfeld2
        '
        Me.btn_Rosenfeld2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Rosenfeld2.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld2.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Rosenfeld2.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Rosenfeld2.ColorFillBlendChecked = CBlendItems10
        Me.btn_Rosenfeld2.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld2.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld2.Corners.All = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.LowerLeft = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.LowerRight = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.UpperLeft = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.UpperRight = CType(6, Short)
        Me.btn_Rosenfeld2.DimFactorOver = 30
        Me.btn_Rosenfeld2.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld2.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld2.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Rosenfeld2.FocalPoints.CenterPtY = 1.0!
        Me.btn_Rosenfeld2.FocalPoints.FocusPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPoints.FocusPtY = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld2.FocusPtTracker = DesignerRectTracker10
        Me.btn_Rosenfeld2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Rosenfeld2.Image = Nothing
        Me.btn_Rosenfeld2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.ImageIndex = 0
        Me.btn_Rosenfeld2.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Rosenfeld2.Location = New System.Drawing.Point(410, 430)
        Me.btn_Rosenfeld2.Name = "btn_Rosenfeld2"
        Me.btn_Rosenfeld2.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_Rosenfeld2.SideImage = Nothing
        Me.btn_Rosenfeld2.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Rosenfeld2.Size = New System.Drawing.Size(66, 32)
        Me.btn_Rosenfeld2.TabIndex = 223
        Me.btn_Rosenfeld2.Text = "Rosenfeld 2"
        Me.btn_Rosenfeld2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Rosenfeld2.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Rosenfeld2.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Rosenfeld
        '
        Me.btn_Rosenfeld.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Rosenfeld.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld.CenterPtTracker = DesignerRectTracker11
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Rosenfeld.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Rosenfeld.ColorFillBlendChecked = CBlendItems12
        Me.btn_Rosenfeld.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld.Corners.All = CType(6, Short)
        Me.btn_Rosenfeld.Corners.LowerLeft = CType(6, Short)
        Me.btn_Rosenfeld.Corners.LowerRight = CType(6, Short)
        Me.btn_Rosenfeld.Corners.UpperLeft = CType(6, Short)
        Me.btn_Rosenfeld.Corners.UpperRight = CType(6, Short)
        Me.btn_Rosenfeld.DimFactorOver = 30
        Me.btn_Rosenfeld.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Rosenfeld.FocalPoints.CenterPtY = 1.0!
        Me.btn_Rosenfeld.FocalPoints.FocusPtX = 0.0!
        Me.btn_Rosenfeld.FocalPoints.FocusPtY = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld.FocusPtTracker = DesignerRectTracker12
        Me.btn_Rosenfeld.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Rosenfeld.Image = Nothing
        Me.btn_Rosenfeld.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.ImageIndex = 0
        Me.btn_Rosenfeld.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Rosenfeld.Location = New System.Drawing.Point(333, 430)
        Me.btn_Rosenfeld.Name = "btn_Rosenfeld"
        Me.btn_Rosenfeld.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_Rosenfeld.SideImage = Nothing
        Me.btn_Rosenfeld.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Rosenfeld.Size = New System.Drawing.Size(71, 32)
        Me.btn_Rosenfeld.TabIndex = 222
        Me.btn_Rosenfeld.Text = "Rosenfeld 1"
        Me.btn_Rosenfeld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Rosenfeld.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Rosenfeld.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_ReloadImage
        '
        Me.btn_ReloadImage.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ReloadImage.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ReloadImage.CenterPtTracker = DesignerRectTracker13
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ReloadImage.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ReloadImage.ColorFillBlendChecked = CBlendItems14
        Me.btn_ReloadImage.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ReloadImage.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ReloadImage.Corners.All = CType(6, Short)
        Me.btn_ReloadImage.Corners.LowerLeft = CType(6, Short)
        Me.btn_ReloadImage.Corners.LowerRight = CType(6, Short)
        Me.btn_ReloadImage.Corners.UpperLeft = CType(6, Short)
        Me.btn_ReloadImage.Corners.UpperRight = CType(6, Short)
        Me.btn_ReloadImage.DimFactorOver = 30
        Me.btn_ReloadImage.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_ReloadImage.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_ReloadImage.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ReloadImage.FocalPoints.CenterPtY = 1.0!
        Me.btn_ReloadImage.FocalPoints.FocusPtX = 0.0!
        Me.btn_ReloadImage.FocalPoints.FocusPtY = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ReloadImage.FocusPtTracker = DesignerRectTracker14
        Me.btn_ReloadImage.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ReloadImage.Image = Nothing
        Me.btn_ReloadImage.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.ImageIndex = 0
        Me.btn_ReloadImage.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ReloadImage.Location = New System.Drawing.Point(75, 430)
        Me.btn_ReloadImage.Name = "btn_ReloadImage"
        Me.btn_ReloadImage.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_ReloadImage.SideImage = Nothing
        Me.btn_ReloadImage.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ReloadImage.Size = New System.Drawing.Size(62, 32)
        Me.btn_ReloadImage.TabIndex = 218
        Me.btn_ReloadImage.Text = "Reload Image"
        Me.btn_ReloadImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ReloadImage.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ReloadImage.TextShadow = System.Drawing.Color.Transparent
        '
        'Pbox1
        '
        Me.Pbox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pbox1.BackColor = System.Drawing.Color.AliceBlue
        Me.Pbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Pbox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pbox1.Location = New System.Drawing.Point(7, 15)
        Me.Pbox1.Name = "Pbox1"
        Me.Pbox1.Size = New System.Drawing.Size(675, 409)
        Me.Pbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pbox1.TabIndex = 153
        Me.Pbox1.TabStop = False
        '
        'btn_TestHexagons
        '
        Me.btn_TestHexagons.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_TestHexagons.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestHexagons.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TestHexagons.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_TestHexagons.ColorFillBlendChecked = CBlendItems4
        Me.btn_TestHexagons.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_TestHexagons.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_TestHexagons.Corners.All = CType(6, Short)
        Me.btn_TestHexagons.Corners.LowerLeft = CType(6, Short)
        Me.btn_TestHexagons.Corners.LowerRight = CType(6, Short)
        Me.btn_TestHexagons.Corners.UpperLeft = CType(6, Short)
        Me.btn_TestHexagons.Corners.UpperRight = CType(6, Short)
        Me.btn_TestHexagons.DimFactorOver = 30
        Me.btn_TestHexagons.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_TestHexagons.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_TestHexagons.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_TestHexagons.FocalPoints.CenterPtY = 1.0!
        Me.btn_TestHexagons.FocalPoints.FocusPtX = 0.0!
        Me.btn_TestHexagons.FocalPoints.FocusPtY = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestHexagons.FocusPtTracker = DesignerRectTracker4
        Me.btn_TestHexagons.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TestHexagons.Image = Nothing
        Me.btn_TestHexagons.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.ImageIndex = 0
        Me.btn_TestHexagons.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_TestHexagons.Location = New System.Drawing.Point(594, 430)
        Me.btn_TestHexagons.Name = "btn_TestHexagons"
        Me.btn_TestHexagons.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_TestHexagons.SideImage = Nothing
        Me.btn_TestHexagons.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TestHexagons.Size = New System.Drawing.Size(69, 32)
        Me.btn_TestHexagons.TabIndex = 228
        Me.btn_TestHexagons.Text = "Test hexagons"
        Me.btn_TestHexagons.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_TestHexagons.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_TestHexagons.TextShadow = System.Drawing.Color.Transparent
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(706, 486)
        Me.Controls.Add(Me.GroupBox9)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(714, 520)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino - ImageToGcode"
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.Pbox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_LoadImage As CustomControlsLib.MyButton
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Pbox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_ReloadImage As CustomControlsLib.MyButton
    Friend WithEvents btn_Rosenfeld As CustomControlsLib.MyButton
    Friend WithEvents btn_Rosenfeld2 As CustomControlsLib.MyButton
    Friend WithEvents btn_Vectorize As CustomControlsLib.MyButton
    Friend WithEvents btn_Resize As CustomControlsLib.MyButton
    Friend WithEvents btn_TestHexagons As CustomControlsLib.MyButton
End Class
