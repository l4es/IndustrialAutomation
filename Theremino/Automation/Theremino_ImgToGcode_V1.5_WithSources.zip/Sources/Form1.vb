﻿

Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        Load_INI()
        OpenImage(Pbox1)
        Me.Text = AppTitleAndVersion("Theremino - Img to Gcode")
        EventsAreEnabled = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        EventsAreEnabled = False
        Save_INI()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub btn_LoadImage_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_LoadImage.ClickButtonArea
        OpenImageDialog()
        Save_INI()
        OpenImage(Pbox1)
    End Sub
    Private Sub btn_ReloadImage_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ReloadImage.ClickButtonArea
        OpenImage(Pbox1)
    End Sub
    Private Sub btn_Resize_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Resize.ClickButtonArea
        ResizeMainBitmao()
    End Sub
    Private Sub btn_Rosenfeld_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Rosenfeld.ClickButtonArea
        ImageToRosenfeld()
    End Sub
    Private Sub btn_Rosenfeld2_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Rosenfeld2.ClickButtonArea
        ImageToRosenfeld_2()
    End Sub
    Private Sub btn_Vectorize_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Vectorize.ClickButtonArea
        Vectorize(ImageFile)
    End Sub

    Private Sub btn_TestHexagons_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_TestHexagons.ClickButtonArea
        CreateTestExagons(Application.StartupPath & "\media\Test_Hexagons.gc")
    End Sub

    Private Sub Pbox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pbox1.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Left Then
            'Dim x As Int32 = (e.X * Pbox1.BackgroundImage.Width) \ Pbox1.Width
            'Dim y As Int32 = (e.Y * Pbox1.BackgroundImage.Height) \ Pbox1.Height
            'FindBorder(x, y)
        Else
            'FindBorder_Undo()
        End If
    End Sub

    Private Sub OpenImageDialog()
        ImageFile = PlatformAdjustedFileName(ImageFile, Application.StartupPath & "/../media/")
        Dim ofd As OpenFileDialog = New OpenFileDialog
        ofd.Filter = "Image files (*.jpeg;*.gif;*.png;*.bmp;*.tiff)|*.jpeg;*.jpg;*.gif;*.png;*.bmp;*.tiff;*.tif|All files (*.*)|*.*"
        If IO.File.Exists(ImageFile) Then
            ofd.InitialDirectory = IO.Path.GetDirectoryName(ImageFile)
            ofd.FileName = ImageFile
        Else
            ofd.InitialDirectory = PlatformAdjustedFileName(Application.StartupPath & "\..\media")
            ofd.FileName = ""
        End If
        ImageFile = PlatformAdjustedFileName(ImageFile)
        ofd.ShowDialog()
        ImageFile = ofd.FileName
    End Sub


End Class