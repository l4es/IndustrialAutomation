﻿Imports System.Collections.Generic
Imports System.Math

Module Module_Gcode

    Const TOOL_DIAM As Single = 0.5
    Const Z_UP As Single = 0.5
    Const Z_DOWN As Single = -0.2
    Const FEED As Single = 100
    Const RAPID_FEED As Single = 250
    Const SPEED As Single = 20000

    Const krad As Double = Math.PI / 180

    Friend Sub GcodeFromVectorList(ByVal vl As VectorList, _
                                    ByVal bmp As Bitmap, _
                                    ByVal FileName As String)

        Dim w As Int32 = bmp.Width
        Dim h As Int32 = bmp.Height
        Dim kx As Single = 25.4F / bmp.HorizontalResolution
        Dim ky As Single = 25.4F / bmp.VerticalResolution

        ' --------------------------------------------------------
        SetFileName(FileName)
        SetMaxValues(250, 60)
        SetStock(w * kx, h * ky, 10)
        SetRapidFeed(RAPID_FEED)
        SetTool(TOOL_DIAM, 100)
        Start()
        ' --------------------------------------------------------
        SetFeed(FEED)
        SetSpeed(SPEED)
        ' --------------------------------------------------------
        Dim x As Single
        Dim y As Single
        Dim FirstPoint As Boolean
        ' --------------------------------------------------------
        For Each vec As Vector In vl.vectors
            FirstPoint = True
            For Each p As Point In vec.points
                x = p.X * kx
                y = (h - p.Y) * ky
                If FirstPoint Then
                    MoveTo(Z_UP)
                    RapidTo(x, y)
                    MoveTo(Z_DOWN)
                    FirstPoint = False
                Else
                    MoveTo(x, y, Z_DOWN)
                End If
            Next
        Next
        ' --------------------------------------------------------
        Finish()
    End Sub



    Friend Sub CreateTestExagons(ByVal FileName As String)

        Dim w As Int32 = 20
        Dim h As Int32 = 20

        ' --------------------------------------------------------
        SetFileName(FileName)
        SetMaxValues(250, 60)
        SetStock(w, h, 10)
        SetRapidFeed(250)
        SetTool(1, 100)
        Start()
        ' --------------------------------------------------------
        SetFeed(100)
        SetSpeed(20000)
        ' --------------------------------------------------------
        Dim x As Single
        Dim y As Single
        Dim FirstPoint As Boolean
        ' --------------------------------------------------------
        For diam As Int32 = 10 To 20 Step 5
            FirstPoint = True
            For angle As Int32 = 0 To 360 Step 60
                x = w / 2.0F + diam / 2.0F * CSng(Cos(angle * krad))
                y = h / 2.0F + diam / 2.0F * CSng(Sin(angle * krad))
                If FirstPoint Then
                    MoveTo(2)
                    RapidTo(x, y)
                    MoveTo(-1)
                    FirstPoint = False
                Else
                    MoveTo(x, y, -1)
                End If
            Next
        Next
        ' --------------------------------------------------------
        Finish()
    End Sub



    ' =========================================================================
    '   GCODE GENERATION
    ' =========================================================================

    Private CoordFormat As String = "0.000"

    Private FileName As String

    Private old_X As Double
    Private old_Y As Double
    Private old_Z As Double

    Private TotTime As Double
    Private TotRapid As Double
    Private TotMove As Double

    Private MaxFeedX As Double
    Private MaxFeedY As Double
    Private MaxFeedZ As Double

    Private RampX As Double
    Private RampY As Double
    Private RampZ As Double

    Private WorkFeed As Double
    Private WorkSpeed As Double
    Private RapidFeed As Double

    Private ToolDiam As Double
    Private ToolAngle As Double

    Private stock_dx As Double
    Private stock_dy As Double
    Private stock_dz As Double

    Private stock_ox As Double
    Private stock_oy As Double
    Private stock_oz As Double

    Private Gcode As List(Of String)



    ' =======================================================================================
    '   Private functions
    ' =======================================================================================

    Private Sub Start()
        Gcode = New List(Of String)

        TotTime = 0
        TotMove = 0
        TotRapid = 0
        Gcode.Clear()
        Gcode.Add("")
        Gcode.Add("(MCUSTOCK X" & FormatNum(stock_dx) & _
                        " Y" & FormatNum(stock_dy) & _
                        " Z" & FormatNum(stock_dz) & _
                        " OTL" & _
                        " OX" & FormatNum(stock_ox) & _
                        " OY" & FormatNum(stock_oy) & _
                        " OZ" & FormatNum(stock_oz) & ")")
        Gcode.Add("")
        Gcode.Add("G21")
        Gcode.Add("G90")
        Gcode.Add("G40")
        Gcode.Add("M03")
        Gcode.Add("")
        Gcode.Add("(MCUTOOL T13 D" & FormatNum(ToolDiam) & " F3 L30 A" & FormatNum(ToolAngle) & ")")
        Gcode.Add("M06 T13")
        Gcode.Add("")
    End Sub

    Private Sub Finish()
        Gcode.Add("")
        Gcode.Add("(==============================)")
        Gcode.Add("( END OF PROGRAM               )")
        Gcode.Add("M05")
        MoveTo(2)
        RapidTo(0, 0, 5)
        Gcode.Add("M30")
        Gcode.Add("M02")
        Gcode.Add("(==============================)")
        Gcode.Add("")
        Gcode.Add("(======= STATISTICS =======)")
        Gcode.Add("( Total Rapid " & TotRapid.ToString("0") & " mm")
        Gcode.Add("( Total Move " & TotMove.ToString("0") & " mm")
        Gcode.Add("")
        Gcode.Add("( Total estimated time:")
        '
        Dim h As Integer = CInt(Floor(TotTime / 3600))
        TotTime -= h * 3600
        Dim m As Integer = CInt(Floor(TotTime / 60.0))
        TotTime -= m * 60
        Dim sec As Integer = CInt(TotTime)
        '
        If h > 0 Then Gcode.Add("( " & h.ToString & " hours")
        If m > 0 Then Gcode.Add("( " & m.ToString & " min.")
        Gcode.Add("( " & sec.ToString & " sec.")
        Gcode.Add("")
        '
        ' ----------------------------------------------------------- delete old file and write new file
        File_KillFile(FileName)
        Dim file As IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(FileName, _
                                                                                False, _
                                                                                System.Text.Encoding.ASCII)
        For Each s As String In Gcode
            file.WriteLine(s & vbCr)
        Next
        file.Close()
        '
        ' ----------------------------------------------------------- start Gcode visualizer application
        Process.Start(FileName)
    End Sub

    Private Sub SetFileName(ByVal _FileName As String)
        FileName = IO.Path.GetDirectoryName(_FileName) & "\" & IO.Path.GetFileNameWithoutExtension(_FileName) & ".gc"
    End Sub

    Private Sub SetMaxValues(ByVal MaxFeed As Double, ByVal Ramp As Double)
        MaxFeedX = MaxFeed
        MaxFeedY = MaxFeed
        MaxFeedZ = MaxFeed
        RampX = Ramp
        RampY = Ramp
        RampZ = Ramp
    End Sub

    Private Sub SetStock(ByVal x As Double, ByVal y As Double, ByVal z As Double)
        stock_dx = x
        stock_dy = y
        stock_dz = z
    End Sub

    Private Sub SetRapidFeed(ByVal _RapidFeed As Double)
        RapidFeed = _RapidFeed
    End Sub

    Private Sub SetFeed(ByVal _WorkFeed As Double)
        WorkFeed = _WorkFeed
        Gcode.Add("F " & WorkFeed.ToString)
    End Sub

    Private Sub SetSpeed(ByVal _WorkSpeed As Double)
        WorkSpeed = _WorkSpeed
        Gcode.Add("S " & WorkSpeed.ToString)
    End Sub

    Private Sub SetTool(ByVal _ToolDiam As Double, ByVal _ToolAngle As Double)
        ToolDiam = _ToolDiam
        ToolAngle = _ToolAngle
    End Sub

    Private Sub RapidTo(ByVal x As Double, ByVal y As Double, ByVal z As Double)
        If x <> old_X Or y <> old_Y Or z <> old_Z Then
            '
            Dim delta As Double
            '
            If Abs(z - old_Z) > Abs(x - old_X) And Abs(z - old_Z) > Abs(y - old_Y) Then
                delta = Abs(z - old_Z)
                TotTime += CalcTime(delta, MaxFeedZ, RampZ)
            Else
                If Abs(x - old_X) > Abs(y - old_Y) Then
                    delta = Abs(x - old_X)
                    TotTime += CalcTime(delta, MaxFeedX, RampX)
                Else
                    delta = Abs(y - old_Y)
                    TotTime += CalcTime(delta, MaxFeedY, RampY)
                End If
            End If
            '
            'TotRapid += delta
            TotRapid += Dist(x, old_X, y, old_Y, z, old_Z)
            '
            old_X = x
            old_Y = y
            old_Z = z
            '
            Gcode.Add("G00 X" & FormatNum(x) & " Y" & FormatNum(y) & " Z" & FormatNum(z))
        End If
    End Sub

    Private Sub RapidTo(ByVal x As Double, ByVal y As Double)
        If x <> old_X Or y <> old_Y Then
            '
            Dim delta As Double
            '
            If Abs(x - old_X) > Abs(y - old_Y) Then
                delta = Abs(x - old_X)
                TotTime += CalcTime(delta, MaxFeedX, RampX)
            Else
                delta = Abs(y - old_Y)
                TotTime += CalcTime(delta, MaxFeedY, RampY)
            End If
            '
            'TotRapid += delta
            TotRapid += Dist(x, old_X, y, old_Y)
            '
            old_X = x
            old_Y = y
            '
            Gcode.Add("G00 X" & FormatNum(x) & " Y" & FormatNum(y))
        End If
    End Sub

    Private Sub RapidTo(ByVal z As Double)
        '
        Dim delta As Double
        '
        If z <> old_Z Then
            delta = Abs(z - old_Z)
            TotTime += CalcTime(delta, MaxFeedZ, RampZ)
            TotRapid += delta
            '
            old_Z = z
            '
            Gcode.Add("G00 Z" & FormatNum(z))
        End If
    End Sub

    Private Sub MoveTo(ByVal x As Double, ByVal y As Double, ByVal z As Double)
        If x <> old_X Or y <> old_Y Or z <> old_Z Then
            '
            Dim delta As Double
            '
            If Abs(z - old_Z) > Abs(x - old_X) And Abs(z - old_Z) > Abs(y - old_Y) Then
                delta = Abs(z - old_Z)
                TotTime += CalcTime(delta, MaxFeedZ, RampZ)
            Else
                If Abs(x - old_X) > Abs(y - old_Y) Then
                    delta = Abs(x - old_X)
                    TotTime += CalcTime(delta, WorkFeed, RampX)
                Else
                    delta = Abs(y - old_Y)
                    TotTime += CalcTime(delta, WorkFeed, RampY)
                End If
            End If
            '
            'TotMove += delta
            TotMove += Dist(x, old_X, y, old_Y, z, old_Z)
            '
            old_X = x
            old_Y = y
            old_Z = z
            '
            Gcode.Add("G01 X" & FormatNum(x) & " Y" & FormatNum(y) & " Z" & FormatNum(z))
        End If
    End Sub

    Private Sub MoveTo(ByVal x As Double, ByVal y As Double)
        If x <> old_X Or y <> old_Y Then
            '
            Dim delta As Double
            '
            If Abs(x - old_X) > Abs(y - old_Y) Then
                delta = Abs(x - old_X)
                TotTime += CalcTime(delta, WorkFeed, RampX)
            Else
                delta = Abs(y - old_Y)
                TotTime += CalcTime(delta, WorkFeed, RampY)
            End If
            '
            'TotMove += delta
            TotMove += Dist(x, old_X, y, old_Y)
            '
            old_X = x
            old_Y = y
            '
            Gcode.Add("G01 X" & FormatNum(x) & " Y" & FormatNum(y))
        End If
    End Sub

    Private Sub MoveTo(ByVal z As Double)
        '
        Dim delta As Double
        '
        If z <> old_Z Then
            delta = Abs(z - old_Z)
            TotTime += CalcTime(delta, WorkFeed, RampZ)
            TotRapid += delta
            '
            old_Z = z
            '
            Gcode.Add("G01 Z" & FormatNum(z))
        End If
    End Sub


    ' =======================================================================================
    '   helper functions
    ' =======================================================================================

    Private Function Dist(ByVal x1 As Double, ByVal x2 As Double, ByVal y1 As Double, ByVal y2 As Double, ByVal z1 As Double, ByVal z2 As Double) As Double
        Return Math.Sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2 + (z2 - z1) ^ 2)
    End Function

    Private Function Dist(ByVal x1 As Double, ByVal x2 As Double, ByVal y1 As Double, ByVal y2 As Double) As Double
        Return Math.Sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
    End Function

    Private Function CalcTime(ByVal delta As Double, ByVal feed As Double, ByVal ramp As Double) As Double
        Dim t As Double = (delta * 60.0) / feed
        If delta > 0 Then t += 0.42 * (feed / 60.0) / ramp
        Return t
    End Function

    Private Sub File_KillFile(ByRef FileName As String)
        On Error Resume Next
        If Not My.Computer.FileSystem.FileExists(FileName) Then Exit Sub
        SetAttr(FileName, FileAttribute.Normal)
        Kill(FileName)
    End Sub

    Private Function FormatNum(ByVal n As Double) As String
        Return n.ToString(CoordFormat).Replace(",", ".")
    End Function

End Module
