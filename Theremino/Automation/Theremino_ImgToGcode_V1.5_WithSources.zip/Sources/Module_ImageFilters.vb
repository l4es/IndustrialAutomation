﻿
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D


Module Module_ImageFilters

    ' ========================================================
    '  RESIZE AND CORRECT DPI TO RESTORE THE SAME PRINT SIZE
    ' ========================================================
    Friend Function ImageResize(ByRef bmp1 As Image, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32) As Image
        If bmp1 Is Nothing Then Return Nothing
        Dim bmp2 As Bitmap = New Bitmap(w, h)
        bmp2.SetResolution(bmp1.HorizontalResolution * w / bmp1.Width, bmp1.VerticalResolution * h / bmp1.Height)
        Dim g As Graphics = Graphics.FromImage(bmp2)
        SetQuality(g, quality)
        g.DrawImage(bmp1, 0, 0, w, h)
        Return bmp2
    End Function

    Friend Function BmpResize(ByRef bmp1 As Bitmap, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32) As Bitmap
        If bmp1 Is Nothing Then Return Nothing
        Dim bmp2 As Bitmap = New Bitmap(w, h)
        bmp2.SetResolution(bmp1.HorizontalResolution * w / bmp1.Width, bmp1.VerticalResolution * h / bmp1.Height)
        Dim g As Graphics = Graphics.FromImage(bmp2)
        SetQuality(g, quality)
        g.DrawImage(bmp1, 0, 0, w, h)
        Return bmp2
    End Function

    'Friend Sub ImageResizeInPlace(ByRef bmp1 As Image, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32)
    '    If bmp1 Is Nothing Then Exit Sub
    '    Dim bmp2 As Bitmap = New Bitmap(w, h)
    '    bmp2.SetResolution(bmp1.HorizontalResolution * w / bmp1.Width, bmp1.VerticalResolution * h / bmp1.Height)
    '    Dim g As Graphics = Graphics.FromImage(bmp2)
    '    SetQuality(g, quality)
    '    g.DrawImage(bmp1, 0, 0, w, h)
    '    bmp1 = bmp2
    'End Sub


    ' ========================================================
    '  BMP Change Format to 24bit
    ' ========================================================
    Friend Function BmpChangeTo24Bit(ByRef bmp0 As Bitmap) As Bitmap
        If bmp0 Is Nothing Then Return Nothing
        Dim w As Int32 = Bmp0.Width
        Dim h As Int32 = Bmp0.Height
        Dim bmp1 As Bitmap = New Bitmap(w, h, Imaging.PixelFormat.Format24bppRgb)
        bmp1.SetResolution(Bmp0.HorizontalResolution, Bmp0.VerticalResolution)
        Dim g As Graphics = Graphics.FromImage(bmp1)
        'g.InterpolationMode = InterpolationMode.NearestNeighbor
        g.DrawImage(bmp0, 0, 0, w, h)
        Return bmp1
    End Function



    ' ================================================================================
    '  QUALITY
    ' ================================================================================
    Private Sub SetQuality(ByVal g As Graphics, ByVal nQuality As Int32)
        Select Case nQuality
            Case 1
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.NearestNeighbor
            Case 2
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Low
            Case 3
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Bilinear
            Case 4
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.HighQualityBilinear
            Case 5
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.NearestNeighbor
            Case 6
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Bicubic
            Case 7
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.Bicubic
            Case 8
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.HighQualityBilinear
            Case 9
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.HighQualityBicubic
                ' --------------------------------------------------------------- ( zero or > 9 ) 
            Case Else
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Low
        End Select
    End Sub

End Module