

Module Module_Rosenfeld

    ' Azriel Rosenfeld
    ' ROSENFELD ALGORITHM 8-CONNECTED

    Private Sub ThinnerRosenfeld(ByRef img1() As Byte, ByVal lx As Int32, ByVal ly As Int32)
        '
        Dim shori As Boolean
        '
        Dim n(9) As Byte
        Dim nrnd As Byte
        Dim n48 As Byte
        Dim n26 As Byte
        Dim n24 As Byte
        Dim n46 As Byte
        Dim n68 As Byte
        Dim n82 As Byte
        Dim n123 As Byte
        Dim n345 As Byte
        Dim n567 As Byte
        Dim n781 As Byte
        '
        Dim a() As Int32 = {0, -1, 1, 0, 0}
        Dim b() As Int32 = {0, 0, 0, 1, -1}
        Dim i As Int32
        Dim j As Int32
        Dim ii As Int32
        Dim jj As Int32
        Dim k As Int32
        Dim kk As Int32
        Dim kk1 As Int32
        Dim kk2 As Int32
        Dim kk3 As Int32
        Dim size As Int32 = lx * ly
        '
        Dim img2(size - 1) As Byte
        For i = 0 To size - 1
            img2(i) = img1(i)
        Next
        '
        Do
            '
            shori = False
            '
            For k = 1 To 4
                '
                For i = 1 To lx - 2
                    '
                    ii = i + a(k)
                    '
                    For j = 1 To ly - 2
                        '
                        kk = i * ly + j
                        If img1(kk) = 0 Then Continue For
                        '
                        jj = j + b(k)
                        kk1 = ii * ly + jj
                        If img1(kk1) <> 0 Then Continue For
                        '
                        kk1 = kk - ly - 1
                        kk2 = kk1 + 1
                        kk3 = kk2 + 1
                        n(3) = img1(kk1)
                        n(2) = img1(kk2)
                        n(1) = img1(kk3)
                        kk1 = kk - 1
                        kk3 = kk + 1
                        n(4) = img1(kk1)
                        n(8) = img1(kk3)
                        kk1 = kk + ly - 1
                        kk2 = kk1 + 1
                        kk3 = kk2 + 1
                        n(5) = img1(kk1)
                        n(6) = img1(kk2)
                        n(7) = img1(kk3)
                        '
                        nrnd = n(1) + n(2) + n(3) + n(4) + n(5) + n(6) + n(7) + n(8)
                        If nrnd <= 1 Then Continue For
                        '
                        n48 = n(4) + n(8)
                        n26 = n(2) + n(6)
                        n24 = n(2) + n(4)
                        n46 = n(4) + n(6)
                        n68 = n(6) + n(8)
                        n82 = n(8) + n(2)
                        n123 = n(1) + n(2) + n(3)
                        n345 = n(3) + n(4) + n(5)
                        n567 = n(5) + n(6) + n(7)
                        n781 = n(7) + n(8) + n(1)
                        '
                        If n(2) = 1 AndAlso n48 = 0 AndAlso n567 > 0 Then Continue For
                        If n(6) = 1 AndAlso n48 = 0 AndAlso n123 > 0 Then Continue For
                        If n(8) = 1 AndAlso n26 = 0 AndAlso n345 > 0 Then Continue For
                        If n(4) = 1 AndAlso n26 = 0 AndAlso n781 > 0 Then Continue For
                        '
                        If n(5) = 1 AndAlso n46 = 0 Then Continue For
                        If n(7) = 1 AndAlso n68 = 0 Then Continue For
                        If n(1) = 1 AndAlso n82 = 0 Then Continue For
                        If n(3) = 1 AndAlso n24 = 0 Then Continue For
                        '
                        img2(kk) = 0
                        shori = True
                    Next
                Next
                '
                For i = 0 To size - 1
                    img1(i) = img2(i)
                Next
                '
            Next
            '
        Loop While shori
        '
    End Sub


    Friend Sub Apply_ThinnerRosenfeld(ByRef bmp As Bitmap)

        Dim w As Int32 = bmp.Width
        Dim h As Int32 = bmp.Height

        Dim i As Int32
        Dim j As Int32

        Dim c As Color

        Dim ba(w * h - 1) As Byte

        Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()

        For i = 0 To h - 1
            For j = 0 To w - 1
                c = bmp.GetPixel(j, i)
                'If c.R < 200 Or c.G < 200 Or c.B < 200 Then
                If c.R < 200 Then
                    ba(i * w + j) = 1
                Else
                    ba(i * w + j) = 0
                End If
            Next
        Next

        Form1.Text = (sw1.ElapsedMilliseconds).ToString
        sw1.Reset()
        sw1.Start()

        ThinnerRosenfeld(ba, h, w)

        Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString
        sw1.Reset()
        sw1.Start()

        For i = 0 To h - 1
            For j = 0 To w - 1
                If ba(i * w + j) = 1 Then
                    bmp.SetPixel(j, i, Color.Black)
                Else
                    bmp.SetPixel(j, i, Color.White)
                End If
            Next
        Next

        Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString

    End Sub

End Module