﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("heremino_ImgToGcode")> 
<Assembly: AssemblyDescription("Image To Gcode")> 
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("ImgToGcode")> 
<Assembly: AssemblyCopyright("No Copyright - Theremino System")> 
<Assembly: AssemblyTrademark("Theremino System")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("475f6f79-54db-42e9-a762-b9842197e443")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.5")> 
<Assembly: AssemblyFileVersion("1.5")> 
