﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Me.btn_LoadImage = New MyButton
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.btn_TestHexagons = New MyButton
        Me.Pbox1 = New System.Windows.Forms.PictureBox
        Me.chk_WeightedDw = New System.Windows.Forms.CheckBox
        Me.txt_Threshold = New MyTextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txt_Up = New MyTextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_Resolution = New MyTextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_ToolSize = New MyTextBox
        Me.txt_Feed = New MyTextBox
        Me.txt_Down = New MyTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label_ServoSlot = New System.Windows.Forms.Label
        Me.btn_CreateGcode = New MyButton
        Me.btn_Rosenfeld2 = New MyButton
        Me.btn_Rosenfeld = New MyButton
        Me.btn_ReloadImage = New MyButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label_Resolution = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.txt_Blur = New MyTextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.cmb_VectorizationType = New MyComboBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txt_Rapids = New MyTextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txt_Width = New MyTextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txt_Height = New MyTextBox
        Me.chk_UseImageSize = New System.Windows.Forms.CheckBox
        Me.chk_UseImageAspect = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox9.SuspendLayout()
        CType(Me.Pbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_LoadImage
        '
        Me.btn_LoadImage.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadImage.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_LoadImage.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_LoadImage.ColorFillBlendChecked = CBlendItems2
        Me.btn_LoadImage.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_LoadImage.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_LoadImage.Corners.All = CType(6, Short)
        Me.btn_LoadImage.Corners.LowerLeft = CType(6, Short)
        Me.btn_LoadImage.Corners.LowerRight = CType(6, Short)
        Me.btn_LoadImage.Corners.UpperLeft = CType(6, Short)
        Me.btn_LoadImage.Corners.UpperRight = CType(6, Short)
        Me.btn_LoadImage.DimFactorOver = 30
        Me.btn_LoadImage.FillType = MyButton.eFillType.LinearVertical
        Me.btn_LoadImage.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_LoadImage.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_LoadImage.FocalPoints.CenterPtY = 1.0!
        Me.btn_LoadImage.FocalPoints.FocusPtX = 0.0!
        Me.btn_LoadImage.FocalPoints.FocusPtY = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_LoadImage.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadImage.FocusPtTracker = DesignerRectTracker2
        Me.btn_LoadImage.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LoadImage.ForeColor = System.Drawing.Color.Black
        Me.btn_LoadImage.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_LoadImage.Image = Nothing
        Me.btn_LoadImage.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.ImageIndex = 0
        Me.btn_LoadImage.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_LoadImage.Location = New System.Drawing.Point(9, 18)
        Me.btn_LoadImage.Name = "btn_LoadImage"
        Me.btn_LoadImage.Shape = MyButton.eShape.Rectangle
        Me.btn_LoadImage.SideImage = Nothing
        Me.btn_LoadImage.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_LoadImage.Size = New System.Drawing.Size(124, 20)
        Me.btn_LoadImage.TabIndex = 216
        Me.btn_LoadImage.Text = "Load Image"
        Me.btn_LoadImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadImage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_LoadImage.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_LoadImage.TextShadow = System.Drawing.Color.Transparent
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox9.Controls.Add(Me.btn_TestHexagons)
        Me.GroupBox9.Controls.Add(Me.Pbox1)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(155, 4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(663, 535)
        Me.GroupBox9.TabIndex = 149
        Me.GroupBox9.TabStop = False
        '
        'btn_TestHexagons
        '
        Me.btn_TestHexagons.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestHexagons.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TestHexagons.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_TestHexagons.ColorFillBlendChecked = CBlendItems4
        Me.btn_TestHexagons.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_TestHexagons.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_TestHexagons.Corners.All = CType(6, Short)
        Me.btn_TestHexagons.Corners.LowerLeft = CType(6, Short)
        Me.btn_TestHexagons.Corners.LowerRight = CType(6, Short)
        Me.btn_TestHexagons.Corners.UpperLeft = CType(6, Short)
        Me.btn_TestHexagons.Corners.UpperRight = CType(6, Short)
        Me.btn_TestHexagons.DimFactorOver = 30
        Me.btn_TestHexagons.FillType = MyButton.eFillType.LinearVertical
        Me.btn_TestHexagons.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_TestHexagons.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_TestHexagons.FocalPoints.CenterPtY = 1.0!
        Me.btn_TestHexagons.FocalPoints.FocusPtX = 0.0!
        Me.btn_TestHexagons.FocalPoints.FocusPtY = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_TestHexagons.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestHexagons.FocusPtTracker = DesignerRectTracker4
        Me.btn_TestHexagons.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TestHexagons.ForeColor = System.Drawing.Color.Black
        Me.btn_TestHexagons.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_TestHexagons.Image = Nothing
        Me.btn_TestHexagons.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.ImageIndex = 0
        Me.btn_TestHexagons.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_TestHexagons.Location = New System.Drawing.Point(16, 494)
        Me.btn_TestHexagons.Name = "btn_TestHexagons"
        Me.btn_TestHexagons.Shape = MyButton.eShape.Rectangle
        Me.btn_TestHexagons.SideImage = Nothing
        Me.btn_TestHexagons.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TestHexagons.Size = New System.Drawing.Size(42, 26)
        Me.btn_TestHexagons.TabIndex = 228
        Me.btn_TestHexagons.Text = "Test1"
        Me.btn_TestHexagons.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestHexagons.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_TestHexagons.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_TestHexagons.TextShadow = System.Drawing.Color.Transparent
        Me.btn_TestHexagons.Visible = False
        '
        'Pbox1
        '
        Me.Pbox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pbox1.BackColor = System.Drawing.Color.AliceBlue
        Me.Pbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Pbox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pbox1.Location = New System.Drawing.Point(7, 9)
        Me.Pbox1.Name = "Pbox1"
        Me.Pbox1.Size = New System.Drawing.Size(649, 518)
        Me.Pbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pbox1.TabIndex = 153
        Me.Pbox1.TabStop = False
        '
        'chk_WeightedDw
        '
        Me.chk_WeightedDw.AutoSize = True
        Me.chk_WeightedDw.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_WeightedDw.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_WeightedDw.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk_WeightedDw.Location = New System.Drawing.Point(20, 40)
        Me.chk_WeightedDw.Name = "chk_WeightedDw"
        Me.chk_WeightedDw.Size = New System.Drawing.Size(113, 17)
        Me.chk_WeightedDw.TabIndex = 244
        Me.chk_WeightedDw.Text = "Weighted down"
        Me.chk_WeightedDw.UseVisualStyleBackColor = True
        '
        'txt_Threshold
        '
        Me.txt_Threshold.ArrowsIncrement = 1
        Me.txt_Threshold.BackColor = System.Drawing.Color.MintCream
        Me.txt_Threshold.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Threshold.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Threshold.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Threshold.Increment = 0.2
        Me.txt_Threshold.Location = New System.Drawing.Point(105, 21)
        Me.txt_Threshold.MaxValue = 254
        Me.txt_Threshold.MinValue = 1
        Me.txt_Threshold.Multiline = True
        Me.txt_Threshold.Name = "txt_Threshold"
        Me.txt_Threshold.NumericValue = 128
        Me.txt_Threshold.NumericValueInteger = 128
        Me.txt_Threshold.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Threshold.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Threshold.RoundingStep = 0
        Me.txt_Threshold.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Threshold.Size = New System.Drawing.Size(30, 15)
        Me.txt_Threshold.SuppressZeros = True
        Me.txt_Threshold.TabIndex = 243
        Me.txt_Threshold.Text = "128"
        Me.txt_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(40, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 242
        Me.Label6.Text = "Threshold"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Up
        '
        Me.txt_Up.ArrowsIncrement = 0.1
        Me.txt_Up.BackColor = System.Drawing.Color.MintCream
        Me.txt_Up.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Up.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Up.Decimals = 1
        Me.txt_Up.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Up.Increment = 0.02
        Me.txt_Up.Location = New System.Drawing.Point(103, 18)
        Me.txt_Up.MaxValue = 20
        Me.txt_Up.MinValue = 0.1
        Me.txt_Up.Multiline = True
        Me.txt_Up.Name = "txt_Up"
        Me.txt_Up.NumericValue = 1
        Me.txt_Up.NumericValueInteger = 1
        Me.txt_Up.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Up.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Up.RoundingStep = 0
        Me.txt_Up.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Up.Size = New System.Drawing.Size(35, 15)
        Me.txt_Up.SuppressZeros = True
        Me.txt_Up.TabIndex = 240
        Me.txt_Up.Text = "1"
        Me.txt_Up.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(42, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 239
        Me.Label4.Text = "Up (mm)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Resolution
        '
        Me.txt_Resolution.ArrowsIncrement = 100
        Me.txt_Resolution.BackColor = System.Drawing.Color.MintCream
        Me.txt_Resolution.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Resolution.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Resolution.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Resolution.Increment = 100
        Me.txt_Resolution.Location = New System.Drawing.Point(92, 82)
        Me.txt_Resolution.MaxValue = 2000
        Me.txt_Resolution.MinValue = 0
        Me.txt_Resolution.Multiline = True
        Me.txt_Resolution.Name = "txt_Resolution"
        Me.txt_Resolution.NumericValue = 640
        Me.txt_Resolution.NumericValueInteger = 640
        Me.txt_Resolution.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Resolution.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Resolution.RoundingStep = 0
        Me.txt_Resolution.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Resolution.Size = New System.Drawing.Size(41, 15)
        Me.txt_Resolution.SuppressZeros = True
        Me.txt_Resolution.TabIndex = 238
        Me.txt_Resolution.Text = "640"
        Me.txt_Resolution.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(16, 83)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 237
        Me.Label3.Text = "Resolution"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ToolSize
        '
        Me.txt_ToolSize.ArrowsIncrement = 0.1
        Me.txt_ToolSize.BackColor = System.Drawing.Color.MintCream
        Me.txt_ToolSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ToolSize.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ToolSize.Decimals = 1
        Me.txt_ToolSize.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ToolSize.Increment = 0.02
        Me.txt_ToolSize.Location = New System.Drawing.Point(103, 59)
        Me.txt_ToolSize.MaxValue = 10
        Me.txt_ToolSize.MinValue = 0.1
        Me.txt_ToolSize.Multiline = True
        Me.txt_ToolSize.Name = "txt_ToolSize"
        Me.txt_ToolSize.NumericValue = 0.8
        Me.txt_ToolSize.NumericValueInteger = 1
        Me.txt_ToolSize.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ToolSize.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ToolSize.RoundingStep = 0
        Me.txt_ToolSize.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ToolSize.Size = New System.Drawing.Size(35, 15)
        Me.txt_ToolSize.SuppressZeros = True
        Me.txt_ToolSize.TabIndex = 236
        Me.txt_ToolSize.Text = "0.8"
        Me.txt_ToolSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Feed
        '
        Me.txt_Feed.ArrowsIncrement = 1
        Me.txt_Feed.BackColor = System.Drawing.Color.MintCream
        Me.txt_Feed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Feed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Feed.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Feed.Increment = 0.2
        Me.txt_Feed.Location = New System.Drawing.Point(103, 82)
        Me.txt_Feed.MaxValue = 999
        Me.txt_Feed.MinValue = 1
        Me.txt_Feed.Multiline = True
        Me.txt_Feed.Name = "txt_Feed"
        Me.txt_Feed.NumericValue = 250
        Me.txt_Feed.NumericValueInteger = 250
        Me.txt_Feed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Feed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Feed.RoundingStep = 0
        Me.txt_Feed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Feed.Size = New System.Drawing.Size(35, 15)
        Me.txt_Feed.SuppressZeros = True
        Me.txt_Feed.TabIndex = 235
        Me.txt_Feed.Text = "250"
        Me.txt_Feed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Down
        '
        Me.txt_Down.ArrowsIncrement = 0.1
        Me.txt_Down.BackColor = System.Drawing.Color.MintCream
        Me.txt_Down.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Down.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Down.Decimals = 1
        Me.txt_Down.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Down.Increment = 0.02
        Me.txt_Down.Location = New System.Drawing.Point(103, 36)
        Me.txt_Down.MaxValue = -0.1
        Me.txt_Down.MinValue = -20
        Me.txt_Down.Multiline = True
        Me.txt_Down.Name = "txt_Down"
        Me.txt_Down.NumericValue = -1
        Me.txt_Down.NumericValueInteger = -1
        Me.txt_Down.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Down.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Down.RoundingStep = 0
        Me.txt_Down.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Down.Size = New System.Drawing.Size(35, 15)
        Me.txt_Down.SuppressZeros = True
        Me.txt_Down.TabIndex = 234
        Me.txt_Down.Text = "-1"
        Me.txt_Down.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 233
        Me.Label2.Text = "Feed (mm/m.)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(25, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 232
        Me.Label1.Text = "Down (mm)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_ServoSlot
        '
        Me.Label_ServoSlot.BackColor = System.Drawing.Color.Transparent
        Me.Label_ServoSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ServoSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label_ServoSlot.Location = New System.Drawing.Point(5, 60)
        Me.Label_ServoSlot.Name = "Label_ServoSlot"
        Me.Label_ServoSlot.Size = New System.Drawing.Size(98, 13)
        Me.Label_ServoSlot.TabIndex = 229
        Me.Label_ServoSlot.Text = "Tool size (mm)"
        Me.Label_ServoSlot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_CreateGcode
        '
        Me.btn_CreateGcode.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CreateGcode.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_CreateGcode.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_CreateGcode.ColorFillBlendChecked = CBlendItems6
        Me.btn_CreateGcode.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_CreateGcode.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_CreateGcode.Corners.All = CType(6, Short)
        Me.btn_CreateGcode.Corners.LowerLeft = CType(6, Short)
        Me.btn_CreateGcode.Corners.LowerRight = CType(6, Short)
        Me.btn_CreateGcode.Corners.UpperLeft = CType(6, Short)
        Me.btn_CreateGcode.Corners.UpperRight = CType(6, Short)
        Me.btn_CreateGcode.DimFactorOver = 30
        Me.btn_CreateGcode.FillType = MyButton.eFillType.LinearVertical
        Me.btn_CreateGcode.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_CreateGcode.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_CreateGcode.FocalPoints.CenterPtY = 1.0!
        Me.btn_CreateGcode.FocalPoints.FocusPtX = 0.0!
        Me.btn_CreateGcode.FocalPoints.FocusPtY = 0.0!
        Me.btn_CreateGcode.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_CreateGcode.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_CreateGcode.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CreateGcode.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CreateGcode.FocusPtTracker = DesignerRectTracker6
        Me.btn_CreateGcode.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CreateGcode.ForeColor = System.Drawing.Color.Black
        Me.btn_CreateGcode.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_CreateGcode.Image = Nothing
        Me.btn_CreateGcode.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CreateGcode.ImageIndex = 0
        Me.btn_CreateGcode.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CreateGcode.Location = New System.Drawing.Point(10, 120)
        Me.btn_CreateGcode.Name = "btn_CreateGcode"
        Me.btn_CreateGcode.Shape = MyButton.eShape.Rectangle
        Me.btn_CreateGcode.SideImage = Nothing
        Me.btn_CreateGcode.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CreateGcode.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CreateGcode.Size = New System.Drawing.Size(124, 20)
        Me.btn_CreateGcode.TabIndex = 226
        Me.btn_CreateGcode.Text = "Create GCode"
        Me.btn_CreateGcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CreateGcode.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CreateGcode.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_CreateGcode.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Rosenfeld2
        '
        Me.btn_Rosenfeld2.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld2.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Rosenfeld2.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Rosenfeld2.ColorFillBlendChecked = CBlendItems8
        Me.btn_Rosenfeld2.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld2.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld2.Corners.All = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.LowerLeft = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.LowerRight = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.UpperLeft = CType(6, Short)
        Me.btn_Rosenfeld2.Corners.UpperRight = CType(6, Short)
        Me.btn_Rosenfeld2.DimFactorOver = 30
        Me.btn_Rosenfeld2.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld2.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld2.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Rosenfeld2.FocalPoints.CenterPtY = 1.0!
        Me.btn_Rosenfeld2.FocalPoints.FocusPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPoints.FocusPtY = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Rosenfeld2.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld2.FocusPtTracker = DesignerRectTracker8
        Me.btn_Rosenfeld2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Rosenfeld2.ForeColor = System.Drawing.Color.Black
        Me.btn_Rosenfeld2.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Rosenfeld2.Image = Nothing
        Me.btn_Rosenfeld2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.ImageIndex = 0
        Me.btn_Rosenfeld2.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Rosenfeld2.Location = New System.Drawing.Point(10, 40)
        Me.btn_Rosenfeld2.Name = "btn_Rosenfeld2"
        Me.btn_Rosenfeld2.Shape = MyButton.eShape.Rectangle
        Me.btn_Rosenfeld2.SideImage = Nothing
        Me.btn_Rosenfeld2.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Rosenfeld2.Size = New System.Drawing.Size(124, 18)
        Me.btn_Rosenfeld2.TabIndex = 223
        Me.btn_Rosenfeld2.Text = "Rosenfeld type 2"
        Me.btn_Rosenfeld2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Rosenfeld2.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Rosenfeld2.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Rosenfeld
        '
        Me.btn_Rosenfeld.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Rosenfeld.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Rosenfeld.ColorFillBlendChecked = CBlendItems10
        Me.btn_Rosenfeld.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Rosenfeld.Corners.All = CType(6, Short)
        Me.btn_Rosenfeld.Corners.LowerLeft = CType(6, Short)
        Me.btn_Rosenfeld.Corners.LowerRight = CType(6, Short)
        Me.btn_Rosenfeld.Corners.UpperLeft = CType(6, Short)
        Me.btn_Rosenfeld.Corners.UpperRight = CType(6, Short)
        Me.btn_Rosenfeld.DimFactorOver = 30
        Me.btn_Rosenfeld.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_Rosenfeld.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_Rosenfeld.FocalPoints.CenterPtY = 1.0!
        Me.btn_Rosenfeld.FocalPoints.FocusPtX = 0.0!
        Me.btn_Rosenfeld.FocalPoints.FocusPtY = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Rosenfeld.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rosenfeld.FocusPtTracker = DesignerRectTracker10
        Me.btn_Rosenfeld.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Rosenfeld.ForeColor = System.Drawing.Color.Black
        Me.btn_Rosenfeld.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Rosenfeld.Image = Nothing
        Me.btn_Rosenfeld.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.ImageIndex = 0
        Me.btn_Rosenfeld.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Rosenfeld.Location = New System.Drawing.Point(10, 19)
        Me.btn_Rosenfeld.Name = "btn_Rosenfeld"
        Me.btn_Rosenfeld.Shape = MyButton.eShape.Rectangle
        Me.btn_Rosenfeld.SideImage = Nothing
        Me.btn_Rosenfeld.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Rosenfeld.Size = New System.Drawing.Size(124, 18)
        Me.btn_Rosenfeld.TabIndex = 222
        Me.btn_Rosenfeld.Text = "Rosenfeld type 1"
        Me.btn_Rosenfeld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rosenfeld.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Rosenfeld.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Rosenfeld.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_ReloadImage
        '
        Me.btn_ReloadImage.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ReloadImage.CenterPtTracker = DesignerRectTracker11
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ReloadImage.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ReloadImage.ColorFillBlendChecked = CBlendItems12
        Me.btn_ReloadImage.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ReloadImage.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ReloadImage.Corners.All = CType(6, Short)
        Me.btn_ReloadImage.Corners.LowerLeft = CType(6, Short)
        Me.btn_ReloadImage.Corners.LowerRight = CType(6, Short)
        Me.btn_ReloadImage.Corners.UpperLeft = CType(6, Short)
        Me.btn_ReloadImage.Corners.UpperRight = CType(6, Short)
        Me.btn_ReloadImage.DimFactorOver = 30
        Me.btn_ReloadImage.FillType = MyButton.eFillType.LinearVertical
        Me.btn_ReloadImage.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_ReloadImage.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_ReloadImage.FocalPoints.CenterPtY = 1.0!
        Me.btn_ReloadImage.FocalPoints.FocusPtX = 0.0!
        Me.btn_ReloadImage.FocalPoints.FocusPtY = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ReloadImage.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ReloadImage.FocusPtTracker = DesignerRectTracker12
        Me.btn_ReloadImage.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ReloadImage.ForeColor = System.Drawing.Color.Black
        Me.btn_ReloadImage.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_ReloadImage.Image = Nothing
        Me.btn_ReloadImage.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.ImageIndex = 0
        Me.btn_ReloadImage.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ReloadImage.Location = New System.Drawing.Point(9, 41)
        Me.btn_ReloadImage.Name = "btn_ReloadImage"
        Me.btn_ReloadImage.Shape = MyButton.eShape.Rectangle
        Me.btn_ReloadImage.SideImage = Nothing
        Me.btn_ReloadImage.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ReloadImage.Size = New System.Drawing.Size(124, 20)
        Me.btn_ReloadImage.TabIndex = 218
        Me.btn_ReloadImage.Text = "Reload Image"
        Me.btn_ReloadImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ReloadImage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ReloadImage.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ReloadImage.TextShadow = System.Drawing.Color.Transparent
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox2.Controls.Add(Me.Label_Resolution)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txt_Blur)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txt_Resolution)
        Me.GroupBox2.Controls.Add(Me.btn_ReloadImage)
        Me.GroupBox2.Controls.Add(Me.btn_LoadImage)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox2.Location = New System.Drawing.Point(4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(145, 120)
        Me.GroupBox2.TabIndex = 151
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Image"
        '
        'Label_Resolution
        '
        Me.Label_Resolution.BackColor = System.Drawing.Color.Transparent
        Me.Label_Resolution.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Resolution.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label_Resolution.Location = New System.Drawing.Point(94, 66)
        Me.Label_Resolution.Name = "Label_Resolution"
        Me.Label_Resolution.Size = New System.Drawing.Size(39, 13)
        Me.Label_Resolution.TabIndex = 242
        Me.Label_Resolution.Text = "640"
        Me.Label_Resolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(15, 66)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 13)
        Me.Label10.TabIndex = 241
        Me.Label10.Text = "Original res."
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Blur
        '
        Me.txt_Blur.ArrowsIncrement = 0.1
        Me.txt_Blur.BackColor = System.Drawing.Color.MintCream
        Me.txt_Blur.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Blur.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Blur.Decimals = 1
        Me.txt_Blur.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Blur.Increment = 0.02
        Me.txt_Blur.Location = New System.Drawing.Point(92, 99)
        Me.txt_Blur.MaxValue = 99
        Me.txt_Blur.MinValue = 0
        Me.txt_Blur.Multiline = True
        Me.txt_Blur.Name = "txt_Blur"
        Me.txt_Blur.NumericValue = 0
        Me.txt_Blur.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Blur.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Blur.RoundingStep = 0
        Me.txt_Blur.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Blur.Size = New System.Drawing.Size(41, 15)
        Me.txt_Blur.SuppressZeros = True
        Me.txt_Blur.TabIndex = 240
        Me.txt_Blur.Text = "0"
        Me.txt_Blur.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(15, 100)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 13)
        Me.Label9.TabIndex = 239
        Me.Label9.Text = "Blur"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox3.Controls.Add(Me.btn_Rosenfeld2)
        Me.GroupBox3.Controls.Add(Me.btn_Rosenfeld)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox3.Location = New System.Drawing.Point(4, 130)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(145, 66)
        Me.GroupBox3.TabIndex = 152
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Skeletrization"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox4.Controls.Add(Me.cmb_VectorizationType)
        Me.GroupBox4.Controls.Add(Me.chk_WeightedDw)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.txt_Threshold)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox4.Location = New System.Drawing.Point(5, 200)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(144, 85)
        Me.GroupBox4.TabIndex = 153
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Vectorization"
        '
        'cmb_VectorizationType
        '
        Me.cmb_VectorizationType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_VectorizationType.ArrowColor = System.Drawing.Color.Gray
        Me.cmb_VectorizationType.BackColor = System.Drawing.Color.FloralWhite
        Me.cmb_VectorizationType.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.cmb_VectorizationType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_VectorizationType.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_VectorizationType.BorderSize = 1
        Me.cmb_VectorizationType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_VectorizationType.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.cmb_VectorizationType.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.cmb_VectorizationType.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.cmb_VectorizationType.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmb_VectorizationType.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.cmb_VectorizationType.DropDownHeight = 318
        Me.cmb_VectorizationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_VectorizationType.DropDownWidth = 80
        Me.cmb_VectorizationType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_VectorizationType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_VectorizationType.ForeColor = System.Drawing.Color.Black
        Me.cmb_VectorizationType.IntegralHeight = False
        Me.cmb_VectorizationType.ItemHeight = 13
        Me.cmb_VectorizationType.Items.AddRange(New Object() {"Parallel vertical", "Parallel horizzontal", "Follow  borders"})
        Me.cmb_VectorizationType.Location = New System.Drawing.Point(10, 60)
        Me.cmb_VectorizationType.Name = "cmb_VectorizationType"
        Me.cmb_VectorizationType.ShadowColor = System.Drawing.Color.LightGray
        Me.cmb_VectorizationType.Size = New System.Drawing.Size(124, 19)
        Me.cmb_VectorizationType.TabIndex = 245
        Me.cmb_VectorizationType.TextPosition = 2
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.txt_Rapids)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.txt_Up)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.Label_ServoSlot)
        Me.GroupBox5.Controls.Add(Me.txt_ToolSize)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.txt_Feed)
        Me.GroupBox5.Controls.Add(Me.btn_CreateGcode)
        Me.GroupBox5.Controls.Add(Me.txt_Down)
        Me.GroupBox5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox5.Location = New System.Drawing.Point(5, 391)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(144, 147)
        Me.GroupBox5.TabIndex = 152
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "G Code"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(2, 101)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 241
        Me.Label5.Text = "Rapids (mm/m.)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Rapids
        '
        Me.txt_Rapids.ArrowsIncrement = 1
        Me.txt_Rapids.BackColor = System.Drawing.Color.MintCream
        Me.txt_Rapids.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Rapids.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Rapids.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Rapids.Increment = 0.2
        Me.txt_Rapids.Location = New System.Drawing.Point(103, 100)
        Me.txt_Rapids.MaxValue = 999
        Me.txt_Rapids.MinValue = 1
        Me.txt_Rapids.Multiline = True
        Me.txt_Rapids.Name = "txt_Rapids"
        Me.txt_Rapids.NumericValue = 500
        Me.txt_Rapids.NumericValueInteger = 500
        Me.txt_Rapids.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Rapids.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Rapids.RoundingStep = 0
        Me.txt_Rapids.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Rapids.Size = New System.Drawing.Size(35, 15)
        Me.txt_Rapids.SuppressZeros = True
        Me.txt_Rapids.TabIndex = 242
        Me.txt_Rapids.Text = "500"
        Me.txt_Rapids.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(12, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 13)
        Me.Label7.TabIndex = 243
        Me.Label7.Text = "Width (mm)"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Width
        '
        Me.txt_Width.ArrowsIncrement = 1
        Me.txt_Width.BackColor = System.Drawing.Color.MintCream
        Me.txt_Width.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Width.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Width.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Width.Increment = 0.2
        Me.txt_Width.Location = New System.Drawing.Point(103, 20)
        Me.txt_Width.MaxValue = 999
        Me.txt_Width.MinValue = 0
        Me.txt_Width.Multiline = True
        Me.txt_Width.Name = "txt_Width"
        Me.txt_Width.NumericValue = 120
        Me.txt_Width.NumericValueInteger = 120
        Me.txt_Width.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Width.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Width.RoundingStep = 0
        Me.txt_Width.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Width.Size = New System.Drawing.Size(35, 15)
        Me.txt_Width.SuppressZeros = True
        Me.txt_Width.TabIndex = 244
        Me.txt_Width.Text = "120"
        Me.txt_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(12, 40)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 13)
        Me.Label8.TabIndex = 245
        Me.Label8.Text = "Height (mm)"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Height
        '
        Me.txt_Height.ArrowsIncrement = 1
        Me.txt_Height.BackColor = System.Drawing.Color.MintCream
        Me.txt_Height.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Height.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Height.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Height.Increment = 0.2
        Me.txt_Height.Location = New System.Drawing.Point(103, 39)
        Me.txt_Height.MaxValue = 999
        Me.txt_Height.MinValue = 0
        Me.txt_Height.Multiline = True
        Me.txt_Height.Name = "txt_Height"
        Me.txt_Height.NumericValue = 70
        Me.txt_Height.NumericValueInteger = 70
        Me.txt_Height.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Height.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Height.RoundingStep = 0
        Me.txt_Height.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Height.Size = New System.Drawing.Size(35, 15)
        Me.txt_Height.SuppressZeros = True
        Me.txt_Height.TabIndex = 246
        Me.txt_Height.Text = "70"
        Me.txt_Height.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_UseImageSize
        '
        Me.chk_UseImageSize.AutoSize = True
        Me.chk_UseImageSize.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_UseImageSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_UseImageSize.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk_UseImageSize.Location = New System.Drawing.Point(22, 75)
        Me.chk_UseImageSize.Name = "chk_UseImageSize"
        Me.chk_UseImageSize.Size = New System.Drawing.Size(110, 17)
        Me.chk_UseImageSize.TabIndex = 247
        Me.chk_UseImageSize.Text = "Use image size"
        Me.chk_UseImageSize.UseVisualStyleBackColor = True
        '
        'chk_UseImageAspect
        '
        Me.chk_UseImageAspect.AutoSize = True
        Me.chk_UseImageAspect.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_UseImageAspect.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_UseImageAspect.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk_UseImageAspect.Location = New System.Drawing.Point(6, 57)
        Me.chk_UseImageAspect.Name = "chk_UseImageAspect"
        Me.chk_UseImageAspect.Size = New System.Drawing.Size(126, 17)
        Me.chk_UseImageAspect.TabIndex = 248
        Me.chk_UseImageAspect.Text = "Use image aspect"
        Me.chk_UseImageAspect.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox1.Controls.Add(Me.chk_UseImageAspect)
        Me.GroupBox1.Controls.Add(Me.txt_Width)
        Me.GroupBox1.Controls.Add(Me.chk_UseImageSize)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txt_Height)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox1.Location = New System.Drawing.Point(5, 289)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(144, 98)
        Me.GroupBox1.TabIndex = 154
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Out dimensions"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(824, 544)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(840, 582)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino - ImageToGcode"
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.Pbox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_LoadImage As MyButton
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Pbox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_ReloadImage As MyButton
    Friend WithEvents btn_Rosenfeld As MyButton
    Friend WithEvents btn_Rosenfeld2 As MyButton
    Friend WithEvents btn_CreateGcode As MyButton
    Friend WithEvents btn_TestHexagons As MyButton
    Friend WithEvents Label_ServoSlot As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_Feed As MyTextBox
    Friend WithEvents txt_Down As MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_ToolSize As MyTextBox
    Friend WithEvents txt_Resolution As MyTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_Up As MyTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_Threshold As MyTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents chk_WeightedDw As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_Rapids As MyTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_Height As MyTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_Width As MyTextBox
    Friend WithEvents chk_UseImageSize As System.Windows.Forms.CheckBox
    Friend WithEvents chk_UseImageAspect As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_VectorizationType As MyComboBox
    Friend WithEvents txt_Blur As MyTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label_Resolution As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
