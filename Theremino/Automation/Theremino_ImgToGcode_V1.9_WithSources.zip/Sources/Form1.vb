﻿
Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        Load_INI()
        cmb_VectorizationType_Init()
        Me.Text = AppTitleAndVersion()
        EnsureFileInAppFolders()
        ReopenImage()
        SetParams()
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        EventsAreEnabled = False
        Save_INI()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub SetDefaultFocus()
        Label_Resolution.Focus()
    End Sub

    Private Sub btn_LoadImage_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_LoadImage.ClickButtonArea
        EnsureFileInAppFolders()
        OpenImageDialog()
        Save_INI()
        ReopenImage()
        SetParams()
        SetDefaultFocus()
    End Sub
    Private Sub btn_ReloadImage_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ReloadImage.ClickButtonArea
        ReopenImage()
        SetParams()
        SetDefaultFocus()
    End Sub
    Private Sub btn_Rosenfeld_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Rosenfeld.ClickButtonArea
        ImageToRosenfeld()
        SetDefaultFocus()
    End Sub
    Private Sub btn_Rosenfeld2_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Rosenfeld2.ClickButtonArea
        ImageToRosenfeld_2()
        SetDefaultFocus()
    End Sub
    Private Sub btn_CreateGcode_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CreateGcode.ClickButtonArea
        CreateGcode(ImageFile, txt_Threshold.NumericValueInteger)
        SetDefaultFocus()
    End Sub

    Private Sub btn_TestHexagons_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_TestHexagons.ClickButtonArea
        CreateTestExagons(Application.StartupPath & "\media\Test_Hexagons.gc")
    End Sub

    Private Sub OpenImageDialog()
        ImageFile = PlatformAdjustedFileName(ImageFile, Application.StartupPath & "/../media/")
        Dim ofd As OpenFileDialog = New OpenFileDialog
        ofd.Filter = "Image files (*.jpeg;*.gif;*.png;*.bmp;*.tiff;*.emf;*.wmf)|*.jpeg;*.jpg;*.gif;*.png;*.bmp;*.tiff;*.emf;*.wmf;*.tif|All files (*.*)|*.*"
        If IO.File.Exists(ImageFile) Then
            ofd.InitialDirectory = IO.Path.GetDirectoryName(ImageFile)
            ofd.FileName = ImageFile
        Else
            ofd.InitialDirectory = PlatformAdjustedFileName(Application.StartupPath & "\Media")
            ofd.FileName = ""
        End If
        ImageFile = PlatformAdjustedFileName(ImageFile)
        ofd.ShowDialog()
        ImageFile = ofd.FileName
    End Sub

    Private Sub ReopenImage()
        OpenImage(Pbox1, txt_Resolution.NumericValueInteger, CSng(txt_Blur.NumericValue))
    End Sub

    Private Sub txt_Resolution_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_Resolution.TextChanged
        If Not EventsAreEnabled Then Return
        If txt_Resolution.NumericValueInteger < 32 Then Return
        ReopenImage()
    End Sub

    Private Sub txt_Blur_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_Blur.TextChanged
        If Not EventsAreEnabled Then Return
        ReopenImage()
    End Sub

    Private Sub Params_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_Resolution.LostFocus, _
                                                                                  txt_Blur.LostFocus, _
                                                                                  txt_Threshold.LostFocus, _
                                                                                  chk_WeightedDw.LostFocus, _
                                                                                  txt_Width.LostFocus, _
                                                                                  txt_Height.LostFocus, _
                                                                                  chk_UseImageAspect.LostFocus, _
                                                                                  chk_UseImageSize.LostFocus, _
                                                                                  txt_Up.LostFocus, _
                                                                                  txt_Down.LostFocus, _
                                                                                  txt_ToolSize.LostFocus, _
                                                                                  txt_Feed.LostFocus, _
                                                                                  txt_Rapids.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub Params_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                            Handles txt_Threshold.TextChanged, _
                                                                                    chk_WeightedDw.CheckedChanged, _
                                                                                    chk_UseImageAspect.CheckedChanged, _
                                                                                    chk_UseImageSize.CheckedChanged, _
                                                                                    txt_Up.TextChanged, _
                                                                                    txt_ToolSize.TextChanged, _
                                                                                    txt_Down.TextChanged, _
                                                                                    txt_Feed.TextChanged, _
                                                                                    txt_Rapids.TextChanged
        If Not EventsAreEnabled Then Return
        SetParams()
    End Sub

    Private Sub SetParams()
        Gcode_UseImageAspect = chk_UseImageAspect.Checked
        Gcode_UseImageSize = chk_UseImageSize.Checked
        If chk_UseImageSize.Checked Then
            chk_UseImageAspect.Checked = True
            txt_Width.NumericValue = GetOutWidth()
            txt_Height.NumericValue = GetOutHeight()
            chk_UseImageAspect.Enabled = False
            txt_Width.Enabled = False
            txt_Height.Enabled = False
        Else
            SetGcodeWidth(txt_Width.NumericValueInteger)
            SetGcodeHeight(txt_Height.NumericValueInteger)
            chk_UseImageAspect.Enabled = True
            txt_Width.Enabled = True
            txt_Height.Enabled = True
        End If
        Gcode_WeightedDw = chk_WeightedDw.Checked
        Gcode_Zup = CSng(txt_Up.NumericValue)
        Gcode_Zdown = CSng(txt_Down.NumericValue)
        Gcode_ToolSize = CSng(txt_ToolSize.NumericValue)
        Gcode_Feed = txt_Feed.NumericValueInteger
        Gcode_Rapids = txt_Rapids.NumericValueInteger
        VectorizationType = cmb_VectorizationType.SelectedIndex
    End Sub

    Private Sub txt_Width_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                      Handles txt_Width.TextChanged
        If Not EventsAreEnabled Then Return
        SetGcodeWidth(txt_Width.NumericValueInteger)
        EventsAreEnabled = False
        txt_Height.NumericValue = GetOutHeight()
        txt_Height.Refresh()
        EventsAreEnabled = True
    End Sub
    Private Sub txt_Height_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                       Handles txt_Height.TextChanged
        If Not EventsAreEnabled Then Return
        SetGcodeHeight(txt_Height.NumericValueInteger)
        EventsAreEnabled = False
        txt_Width.NumericValue = GetOutWidth()
        txt_Width.Refresh()
        EventsAreEnabled = True
    End Sub


    ' ======================================================================
    '   COMBO cmb_VectorizationType
    ' ======================================================================
    Private Sub cmb_VectorizationType_Init()
        cmb_VectorizationType.ItemHeight = 12
    End Sub
    Private Sub cmb_VectorizationType_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_VectorizationType.DropDown
        cmb_VectorizationType.ItemHeight = 16
    End Sub
    Private Sub cmb_VectorizationType_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_VectorizationType.DropDownClosed
        cmb_VectorizationType_Init()
    End Sub
    Private Sub cmb_VectorizationType_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_VectorizationType.SelectionChangeCommitted
        SetParams()
    End Sub

End Class