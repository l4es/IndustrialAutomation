﻿
' --------------------------------------------------------------------------------------------
'  IMAGE OPERATIONS
' --------------------------------------------------------------------------------------------
' 1) Edge detection / Boundary / Outline ( Canny )
'     params = GSD / Low / Hi
'
' 2) Raster Thinning ( Rosenfeld or Stentiford )
'
' 3) Vector Extraction 
'     params = Smooth polylines (max displacement) / Reduce polylines (max displacement)
' --------------------------------------------------------------------------------------------

Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Imports System.Math
Imports System.Drawing.Drawing2D


Module Module_ImageOperations

    Private pbox As PictureBox
    Friend MainBitmap As Bitmap

    Friend Sub OpenImage(ByVal _pbox As PictureBox, Optional ByVal Resolution As Int32 = 0, Optional ByVal Blur As Single = 0)
        Dim bmp As Bitmap
        If _pbox Is Nothing Then Return
        pbox = _pbox
        Try
            bmp = New Bitmap(ImageFile)
        Catch
            Return
        End Try
        ' --------------------------------------------- 
        Form1.Label_Resolution.Text = bmp.Width.ToString
        ' --------------------------------------------- convert to 24 bits per pixel
        bmp = BmpChangeTo24Bit(bmp)
        ' --------------------------------------------- resize
        If Resolution > 0 Then
            ResizeBitmap(bmp, Resolution)
        End If
        ' --------------------------------------------- resize
        BlurBitmap(bmp, Blur)
        ' ---------------------------------------------
        MainBitmap = bmp
        pbox.BackgroundImage = MainBitmap
        Form1.txt_Resolution.NumericValueInteger = MainBitmap.Width
        pbox.Invalidate()
        ' ---------------------------------------------
        Dim ci As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture
        Form1.Text = AppTitleAndVersion() & " - " & IO.Path.GetFileName(ImageFile)
    End Sub

    Friend Sub ResizeBitmap(ByRef bmp As Bitmap, ByVal Resolution As Int32)
        ' -------------------------------------------------- create a resized bitmap with the same DPI 
        Dim w As Int32 = bmp.Width
        Dim h As Int32 = bmp.Height
        Dim k As Single = CSng(Resolution) / w
        bmp = BmpResize(bmp, CInt(w * k), CInt(h * k), 9)
    End Sub

    Friend Sub BlurBitmap(ByRef bmp As Bitmap, ByVal BlurPixels As Single)
        If BlurPixels <= 0 Then Return
        ' ---------------------------------------------
        Dim w As Int32 = bmp.Width
        Dim h As Int32 = bmp.Height
        Dim w2 As Int32 = CInt(w / (BlurPixels + 1))
        Dim h2 As Int32 = CInt(h / (BlurPixels + 1))
        If w2 < 2 Then w2 = 2
        If h2 < 2 Then h2 = 2
        ' --------------------------------------------- low-resolution
        Dim bmp2 As New Bitmap(w2, h2)
        Dim g As Graphics = Graphics.FromImage(bmp2)
        g.InterpolationMode = InterpolationMode.HighQualityBilinear
        g.DrawImage(bmp, 0, 0, w2, h2)
        ' --------------------------------------------- hi resolution blurred
        g = Graphics.FromImage(bmp)
        g.Clear(Color.White)
        g.InterpolationMode = InterpolationMode.HighQualityBilinear
        g.DrawImage(bmp2, 0, 0, w, h)
    End Sub


    ' ========================================================================================================
    '  ROSENFELD
    ' ========================================================================================================
    Friend Sub ImageToRosenfeld()
        Apply_ThinnerRosenfeld(MainBitmap)
        pbox.Refresh()
        'Dim DocFolder As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\"
        'SaveImage(Bmp, DocFolder & "TEST.png", "png", 100)
    End Sub

    Friend Sub ImageToRosenfeld_2()
        Apply_ThinnerRosenfeld_2(MainBitmap)
        pbox.Refresh()
    End Sub


    ' ========================================================================================================
    '  CreateGcode
    ' ========================================================================================================
    Friend Sub CreateGcode(ByVal filename As String, ByVal Threshold As Int32)
        'OpenImage(pbox)
        BmpToGcode(MainBitmap, filename, Threshold)
        pbox.BackgroundImage = MainBitmap
        pbox.Refresh()
    End Sub


    ' ========================================================================================================
    '   BITMAP to/from BINARY ARRAY  ( Binary Array is inflated with a white border )
    ' ========================================================================================================

    Friend Sub Bitmap_to_BinaryArray(ByVal Bmp As Bitmap, ByRef ba As Boolean(,), ByVal Threshold As Integer)
        '
        ' -------------------------------------------------------------- inflated Result Array
        ReDim ba(Bmp.Width + 1, Bmp.Height + 1)
        '
        ' -------------------------------------------------------------- Fill inflated array
        Dim H As Int32 = Bmp.Height
        Dim W As Int32 = Bmp.Width
        Dim BmpData As BitmapData = Bmp.LockBits(New Rectangle(0, 0, W, H), _
                                                 ImageLockMode.ReadOnly, _
                                                 PixelFormat.Format24bppRgb)
        Dim Stride As Int32 = BmpData.Stride
        Dim BmpPtr As IntPtr = BmpData.Scan0
        Dim dxy As Int32
        Dim dy As Int32 = 0
        For y As Int32 = 0 To H - 1
            dxy = dy
            For x As Int32 = 0 To W - 1
                Dim b As Byte = Marshal.ReadByte(BmpPtr, dxy + 0)
                Dim g As Byte = Marshal.ReadByte(BmpPtr, dxy + 1)
                Dim r As Byte = Marshal.ReadByte(BmpPtr, dxy + 2)
                If GrayFromColors(r, g, b) < Threshold Then
                    ba(x + 1, y + 1) = True
                Else
                    ba(x + 1, y + 1) = False
                End If
                dxy += 3
            Next
            dy = dy + Stride
        Next
        Bmp.UnlockBits(BmpData)
        '
        ' -------------------------------------------------------------- Add a white Border
        For x As Integer = 0 To ba.GetLength(0) - 1
            ba(x, 0) = False
            ba(x, ba.GetLength(1) - 1) = False
        Next
        For y As Integer = 0 To ba.GetLength(1) - 1
            ba(0, y) = False
            ba(ba.GetLength(0) - 1, y) = False
        Next
    End Sub

    Friend Sub BinaryArray_to_Bitmap(ByVal ba As Boolean(,), ByRef Bmp As Bitmap)
        '
        ' -------------------------------------------------- -2 to ignore the border
        Dim W As Int32 = ba.GetLength(0) - 2
        Dim H As Int32 = ba.GetLength(1) - 2

        Bmp = New Bitmap(W, H)
        Dim BmpData As BitmapData = Bmp.LockBits(New Rectangle(0, 0, W, H), _
                                                  ImageLockMode.WriteOnly, _
                                                  PixelFormat.Format24bppRgb)
        Dim Stride As Int32 = BmpData.Stride
        Dim BmpPtr As IntPtr = BmpData.Scan0
        Dim dxy As Int32
        Dim dy As Int32 = 0
        For y As Int32 = 0 To H - 1
            dxy = dy
            For x As Int32 = 0 To W - 1
                ' ------------------------------ test i+1 and j+1 to ignore the border
                If ba(x + 1, y + 1) Then
                    Marshal.WriteByte(BmpPtr, dxy + 0, 0)
                    Marshal.WriteByte(BmpPtr, dxy + 1, 0)
                    Marshal.WriteByte(BmpPtr, dxy + 2, 0)
                Else
                    Marshal.WriteByte(BmpPtr, dxy + 0, 255)
                    Marshal.WriteByte(BmpPtr, dxy + 1, 255)
                    Marshal.WriteByte(BmpPtr, dxy + 2, 255)
                End If
                dxy += 3
            Next
            dy = dy + Stride
        Next
        Bmp.UnlockBits(BmpData)
    End Sub





    ' ========================================================================================================
    '   BITMAP to/from BYTE ARRAY  ( ByteArray is inflated with a white border )
    ' ========================================================================================================

    Friend Sub Bitmap_to_ByteArray(ByVal Bmp As Bitmap, ByRef ba As Byte(,), ByVal Threshold As Integer)
        '
        ' -------------------------------------------------------------- inflated Result Array
        ReDim ba(Bmp.Width + 1, Bmp.Height + 1)
        '
        ' -------------------------------------------------------------- Fill inflated array
        Dim H As Int32 = Bmp.Height
        Dim W As Int32 = Bmp.Width
        Dim BmpData As BitmapData = Bmp.LockBits(New Rectangle(0, 0, W, H), _
                                                 ImageLockMode.ReadOnly, _
                                                 PixelFormat.Format24bppRgb)
        Dim Stride As Int32 = BmpData.Stride
        Dim BmpPtr As IntPtr = BmpData.Scan0
        Dim dxy As Int32
        Dim dy As Int32 = 0
        For y As Int32 = 0 To H - 1
            dxy = dy
            For x As Int32 = 0 To W - 1
                Dim b1 As Byte = Marshal.ReadByte(BmpPtr, dxy + 0)
                Dim b2 As Byte = Marshal.ReadByte(BmpPtr, dxy + 1)
                Dim b3 As Byte = Marshal.ReadByte(BmpPtr, dxy + 2)
                If Math.Max(Math.Max(b1, b2), b3) < Threshold Then
                    ba(x + 1, y + 1) = 1
                Else
                    ba(x + 1, y + 1) = 0
                End If
                dxy += 3
            Next
            dy = dy + Stride
        Next
        Bmp.UnlockBits(BmpData)
        '
        ' -------------------------------------------------------------- Add a white Border
        For x As Integer = 0 To ba.GetLength(0) - 1
            ba(x, 0) = 0
            ba(x, ba.GetLength(1) - 1) = 0
        Next
        For y As Integer = 0 To ba.GetLength(1) - 1
            ba(0, y) = 0
            ba(ba.GetLength(0) - 1, y) = 0
        Next
    End Sub

    Friend Sub ByteArray_to_Bitmap(ByVal ba As Byte(,), ByRef Bmp As Bitmap)
        '
        ' -------------------------------------------------- -2 to ignore the border
        Dim W As Int32 = ba.GetLength(0) - 2
        Dim H As Int32 = ba.GetLength(1) - 2
        ' ----------------------------------------------------------------------- get bitmap data
        Dim BmpData As BitmapData = Bmp.LockBits(New Rectangle(0, 0, W, H), _
                                                  ImageLockMode.WriteOnly, _
                                                  PixelFormat.Format24bppRgb)
        ' ----------------------------------------------------------------------- fill the bitmap
        Dim Stride As Int32 = BmpData.Stride
        Dim BmpPtr As IntPtr = BmpData.Scan0
        Dim dxy As Int32
        Dim dy As Int32 = 0
        For y As Int32 = 0 To H - 1
            dxy = dy
            For x As Int32 = 0 To W - 1
                ' ------------------------------ test i+1 and j+1 to ignore the border
                If ba(x + 1, y + 1) <> 0 Then
                    Marshal.WriteByte(BmpPtr, dxy + 0, 0)
                    Marshal.WriteByte(BmpPtr, dxy + 1, 0)
                    Marshal.WriteByte(BmpPtr, dxy + 2, 0)
                Else
                    Marshal.WriteByte(BmpPtr, dxy + 0, 255)
                    Marshal.WriteByte(BmpPtr, dxy + 1, 255)
                    Marshal.WriteByte(BmpPtr, dxy + 2, 255)
                End If
                dxy += 3
            Next
            dy = dy + Stride
        Next
        Bmp.UnlockBits(BmpData)
    End Sub


End Module
