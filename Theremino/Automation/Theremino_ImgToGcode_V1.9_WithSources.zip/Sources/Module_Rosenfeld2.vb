﻿Module Module_Rosenfeld2

    ' Azriel Rosenfeld
    ' ROSENFELD ALGORITHM 8-CONNECTED

    Private Sub ThinnerRosenfeld(ByRef img1(,) As Byte)
        '
        Dim lx As Int32 = img1.GetLength(0)
        Dim ly As Int32 = img1.GetLength(1)
        Dim shori As Boolean
        '
        Dim n(9) As Byte
        Dim nrnd As Byte
        Dim n48 As Byte
        Dim n26 As Byte
        Dim n24 As Byte
        Dim n46 As Byte
        Dim n68 As Byte
        Dim n82 As Byte
        Dim n123 As Byte
        Dim n345 As Byte
        Dim n567 As Byte
        Dim n781 As Byte
        '
        Dim a() As Int32 = {0, -1, 1, 0, 0}
        Dim b() As Int32 = {0, 0, 0, 1, -1}
        Dim x As Int32
        Dim y As Int32
        Dim k As Int32
        '
        Dim img2(lx - 1, ly - 1) As Byte
        'For x = 0 To lx + 1
        '    For y = 0 To ly + 1
        '        img2(x, y) = img1(x, y)
        '    Next
        'Next
        Array.Copy(img1, img2, img2.Length)
        '
        Do
            '
            shori = False
            '
            For k = 1 To 4
                '
                For x = 1 To lx - 2
                    '
                    For y = 1 To ly - 2
                        '
                        If img1(x, y) = 0 Then Continue For
                        '
                        If img1(x + b(k), y + a(k)) <> 0 Then Continue For
                        '
                        n(3) = img1(x - 1, y - 1)
                        n(2) = img1(x, y - 1)
                        n(1) = img1(x + 1, y - 1)

                        n(4) = img1(x - 1, y)
                        n(8) = img1(x + 1, y)
                        '
                        n(5) = img1(x - 1, y + 1)
                        n(6) = img1(x, y + 1)
                        n(7) = img1(x + 1, y + 1)
                        '
                        nrnd = n(1) + n(2) + n(3) + n(4) + n(5) + n(6) + n(7) + n(8)
                        If nrnd <= 1 Then Continue For
                        '
                        n48 = n(4) + n(8)
                        n26 = n(2) + n(6)
                        n24 = n(2) + n(4)
                        n46 = n(4) + n(6)
                        n68 = n(6) + n(8)
                        n82 = n(8) + n(2)
                        n123 = n(1) + n(2) + n(3)
                        n345 = n(3) + n(4) + n(5)
                        n567 = n(5) + n(6) + n(7)
                        n781 = n(7) + n(8) + n(1)
                        '
                        If n(2) = 1 AndAlso n48 = 0 AndAlso n567 > 0 Then Continue For
                        If n(6) = 1 AndAlso n48 = 0 AndAlso n123 > 0 Then Continue For
                        If n(8) = 1 AndAlso n26 = 0 AndAlso n345 > 0 Then Continue For
                        If n(4) = 1 AndAlso n26 = 0 AndAlso n781 > 0 Then Continue For
                        '
                        If n(5) = 1 AndAlso n46 = 0 Then Continue For
                        If n(7) = 1 AndAlso n68 = 0 Then Continue For
                        If n(1) = 1 AndAlso n82 = 0 Then Continue For
                        If n(3) = 1 AndAlso n24 = 0 Then Continue For
                        '
                        img2(x, y) = 0
                        shori = True
                    Next
                Next
                '
                'For x = 0 To lx + 1
                '    For y = 0 To ly + 1
                '        img1(x, y) = img2(x, y)
                '    Next
                'Next
                Array.Copy(img2, img1, img1.Length)
                '
            Next
            '
        Loop While shori
        '
    End Sub


    Friend Sub Apply_ThinnerRosenfeld_2(ByRef bmp As Bitmap)

        Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()

        Dim w As Int32 = bmp.Width
        Dim h As Int32 = bmp.Height

        '
        ' -------------------------------------------------------------- inflated Result Array

        Dim ba(w + 1, h + 1) As Byte

        'Dim c As Color
        'For x As Int32 = 0 To w - 1
        '    For y As Int32 = 0 To h - 1
        '        c = bmp.GetPixel(x, y)
        '        'If c.R < 200 Or c.G < 200 Or c.B < 200 Then
        '        If c.R < 200 Then
        '            ba(x + 1, y + 1) = 1
        '        Else
        '            ba(x + 1, y + 1) = 0
        '        End If
        '    Next
        'Next

        Bitmap_to_ByteArray(bmp, ba, 200)

        ' -------------------------------------------------------------- White Border
        For x As Integer = 0 To w + 1
            ba(x, 0) = 1
            ba(x, h + 1) = 1
        Next
        For y As Integer = 1 To h + 1
            ba(0, y) = 1
            ba(w + 1, y) = 1
        Next

        'Form1.Text = (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()

        ThinnerRosenfeld(ba)

        'Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()

        'For x As Int32 = 0 To w - 1
        '    For y As Int32 = 0 To h - 1
        '        If ba(x + 1, y + 1) = 1 Then
        '            bmp.SetPixel(x, y, Color.Black)
        '        Else
        '            bmp.SetPixel(x, y, Color.White)
        '        End If
        '    Next
        'Next

        ByteArray_to_Bitmap(ba, bmp)

        'Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()

    End Sub

End Module
