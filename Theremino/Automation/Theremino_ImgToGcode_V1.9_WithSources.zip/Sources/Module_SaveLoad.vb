﻿Imports System.Drawing.Imaging


Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False

    Friend ImageFile As String
    Friend AscFile As String

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub Save_INI()
        '
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine("")
            f.WriteLine("===========================================")
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM BOUNDS
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" ImgToGcode"))
            f.WriteLine("===========================================")
            f.WriteLine(TabString("ImageFile", ImageFile))
            f.WriteLine(TabString("AscFile", AscFile))
            '
            f.WriteLine(TabString("Resolution", Form1.txt_Resolution.NumericValueInteger))
            f.WriteLine(TabString("Blur", Form1.txt_Blur.NumericValue))
            '
            f.WriteLine(TabString("Threshold", Form1.txt_Threshold.NumericValueInteger))
            f.WriteLine(TabString("WeightedDw", Form1.chk_WeightedDw.Checked))
            f.WriteLine(TabString("VectorizationType", Form1.cmb_VectorizationType.SelectedIndex))
            '
            f.WriteLine(TabString("Width", Form1.txt_Width.NumericValueInteger))
            f.WriteLine(TabString("Height", Form1.txt_Height.NumericValueInteger))
            f.WriteLine(TabString("UseImageAspect", Form1.chk_UseImageAspect.Checked))
            f.WriteLine(TabString("UseImageSize", Form1.chk_UseImageSize.Checked))
            '
            f.WriteLine(TabString("Up", Form1.txt_Up.NumericValue))
            f.WriteLine(TabString("Down", Form1.txt_Down.NumericValue))
            f.WriteLine(TabString("ToolSize", Form1.txt_ToolSize.NumericValue))
            f.WriteLine(TabString("Feed", Form1.txt_Feed.NumericValueInteger))
            f.WriteLine(TabString("Rapids", Form1.txt_Rapids.NumericValueInteger))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------- defaults
        '
        Form1.cmb_VectorizationType.SelectedIndex = 2
        ' -------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' ------------------------------------------------------------------------------- 
        Dim l As String
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        If My.Computer.FileSystem.FileExists(iniFileName) Then

            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = Val_Int(l)
                    Case "Form1_Left" : Form1.Left = Val_Int(l)
                    Case "Form1_Width" : Form1.Width = Val_Int(l)
                    Case "Form1_Height" : Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : Form1.WindowState = CType((Val(l)), FormWindowState)
                        ' ------------------------------------------------------------------------------
                    Case "ImageFile" : ImageFile = l
                    Case "AscFile" : AscFile = l
                        '
                    Case "Resolution" : Form1.txt_Resolution.NumericValueInteger = Val_Int(l)
                    Case "Blur" : Form1.txt_Blur.NumericValue = Val_Single(l)
                        '
                    Case "Threshold" : Form1.txt_Threshold.NumericValueInteger = Val_Int(l)
                    Case "WeightedDw" : Form1.chk_WeightedDw.Checked = l = "True"
                    Case "VectorizationType" : Form1.cmb_VectorizationType.SelectedIndex = Val_Int(l)
                        '
                    Case "Width" : Form1.txt_Width.NumericValueInteger = Val_Int(l)
                    Case "Height" : Form1.txt_Height.NumericValueInteger = Val_Int(l)
                    Case "UseImageAspect" : Form1.chk_UseImageAspect.Checked = l = "True"
                    Case "UseImageSize" : Form1.chk_UseImageSize.Checked = l = "True"
                        '
                    Case "Up" : Form1.txt_Up.NumericValue = Val_Single(l)
                    Case "Down" : Form1.txt_Down.NumericValue = Val_Single(l)
                    Case "ToolSize" : Form1.txt_ToolSize.NumericValue = Val_Single(l)
                    Case "Feed" : Form1.txt_Feed.NumericValueInteger = Val_Int(l)
                    Case "Rapids" : Form1.txt_Rapids.NumericValueInteger = Val_Int(l)
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
    End Sub


    ' ==================================================================================================
    '  SAVE IMAGE
    ' ==================================================================================================
    Public Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)

        extension = LCase(extension)
        filename = RemoveExtension(filename)
        filename += "." & extension
        '
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, 100)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function

    Friend Sub File_Kill(ByVal filename As String)
        If My.Computer.FileSystem.FileExists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
        End If
    End Sub

    Friend Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str)
    End Function

    ' ==================================================================================================
    '  ENSURE FILE IN APP FOLDERS
    ' ==================================================================================================
    Friend Sub EnsureFileInAppFolders()
        If Not My.Computer.FileSystem.FileExists(ImageFile) Or _
                                    ImageFile.StartsWith("\\") Then
            ImageFile = FindFileInAppFolders(ImageFile)
        End If
    End Sub

    Private Function FindFileInAppFolders(ByVal PathAndName As String) As String
        Dim name As String = IO.Path.GetFileName(PathAndName)
        Dim s As String = Application.StartupPath & "\Media\"
        If name = "" Then Return s
        Dim FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim wildcards() As String = {"*.bmp", "*.jpg", "*.png", "*.gif", "*.emf", "*.wmf", "*.tiff"}
        FileNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchAllSubDirectories, wildcards)
        For Each str As String In FileNames
            If str.EndsWith(name) Then
                Return str
            End If
        Next
        Return s
    End Function


End Module
