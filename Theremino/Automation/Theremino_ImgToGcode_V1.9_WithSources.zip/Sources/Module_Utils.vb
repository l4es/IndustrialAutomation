﻿
Module Module_Utils

    ' ==============================================================================================================
    '   COLOR FUNCTIONS
    ' ==============================================================================================================
    Private Const Kred As Single = 0.299F
    Private Const Kgreen As Single = 0.587F
    Private Const Kblue As Single = 0.114F
    Friend Function GrayFromColor(ByVal c As Color) As Int32
        Return CInt(c.G * Kgreen + c.R * Kred + c.B * Kblue)
    End Function

    Friend Function GrayFromColors(ByVal r As Int32, ByVal g As Int32, ByVal b As Int32) As Int32
        Return CInt(g * Kgreen + r * Kred + b * Kblue)
    End Function


    ' ==============================================================================================================
    '   COMBO FUNCTIONS
    ' ==============================================================================================================
    Friend Sub Combo_Init(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            .Items.Clear()
            .Items.Add(str)
            .SelectedIndex = 0
        End With
        EventsAreEnabled = old
    End Sub

    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub

    Friend Function Combo_GetValue(ByVal combo As ComboBox) As String
        If combo.SelectedIndex < 0 Then Return ""
        Return combo.Items(combo.SelectedIndex).ToString()
    End Function

    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByVal index As Int32)
        If combo.Items.Count < 1 Then Exit Sub
        If index < 0 Then index = 0
        If index > combo.Items.Count - 1 Then index = combo.Items.Count - 1
        combo.SelectedIndex = index
    End Sub


End Module






