﻿
Imports System.Collections.Generic

Module Module_Vectorize

    Friend VectorizationType As Int32

    Friend Class Vector
        Friend points As List(Of Point)
        Friend Sub New()
            points = New List(Of Point)
        End Sub
    End Class

    Friend Class VectorList
        Friend vectors As List(Of Vector)
        Friend Sub New()
            vectors = New List(Of Vector)
        End Sub
    End Class

    Private vl As VectorList
    Private ba(-1, -1) As Boolean
    Private sizeX As Integer
    Private sizeY As Integer


    Friend Sub BmpToGcode(ByRef bmp As Bitmap, ByVal filename As String, ByVal Threshold As Int32)
        '
        'Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()
        sizeX = bmp.Width
        sizeY = bmp.Height
        ' ----------------------------------------------------------------- 
        'Dim x As Int32
        'Dim y As Int32
        'Dim c As Color
        'ReDim ba(sizeX - 1, sizeY - 1)
        'For y = 0 To sizeY - 1
        '    For x = 0 To sizeX - 1
        '        c = bmp.GetPixel(x, y)
        '        'If c.R < 200 Or c.G < 200 Or c.B < 200 Then
        '        If c.R < 200 Then
        '            ba(x, y) = True
        '        Else
        '            ba(x, y) = False
        '        End If
        '    Next
        'Next
        ' ----------------------------------------------------------------- BITMAP TO BYNARY ARRAY
        Bitmap_to_BinaryArray(bmp, ba, Threshold)
        ' ----------------------------------------------------------------- 
        'Form1.Text = (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()
        ' ----------------------------------------------------------------- CREATE VECTORS
        Select Case VectorizationType
            Case 0 : CreateVectors_Vertical()
            Case 1 : CreateVectors_Horizzontal()
            Case 2 : CreateVectors_FollowBorders()
        End Select
        ' ----------------------------------------------------------------- CONNECT AND SIMPLIFY
        ConnectVectors()
        'SimplifyVectors()
        OptimizeRapids(0, sizeY)
        ' ----------------------------------------------------------------- GCODE
        GcodeFromVectorList(vl, filename)
        ' ----------------------------------------------------------------- 
        'Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()
        ' ----------------------------------------------------------------- 
        'For y = 0 To sizeY - 1
        '    For x = 0 To sizeX - 1
        '        If ba(x, y) Then
        '            bmp.SetPixel(x, y, Color.Black)
        '        Else
        '            bmp.SetPixel(x, y, Color.White)
        '        End If
        '    Next
        'Next
        'BinaryArray_to_Bitmap(ba, bmp)
        ' ----------------------------------------------------------------- 
        'Form1.Text &= " " & (sw1.ElapsedMilliseconds).ToString
        'sw1.Reset()
        'sw1.Start()
    End Sub

    Private Sub CreateVectors_Vertical()
        vl = New VectorList
        For x As Int32 = 1 To sizeX - 2
            Dim vec As Vector = New Vector
            For y As Int32 = 1 To sizeY - 2
                If ba(x, y) Then
                    vec.points.Add(New Point(x, y))
                Else
                    If vec.points.Count > 0 Then
                        vl.vectors.Add(vec)
                        vec = New Vector
                    End If
                End If
            Next
            If vec.points.Count > 0 Then
                vl.vectors.Add(vec)
                vec = New Vector
            End If
        Next
    End Sub
    Private Sub CreateVectors_Horizzontal()
        vl = New VectorList
        For y As Int32 = 1 To sizeY - 2
            Dim vec As Vector = New Vector
            For x As Int32 = 1 To sizeX - 2
                If ba(x, y) Then
                    vec.points.Add(New Point(x, y))
                Else
                    If vec.points.Count > 0 Then
                        vl.vectors.Add(vec)
                        vec = New Vector
                    End If
                End If
            Next
            If vec.points.Count > 0 Then
                vl.vectors.Add(vec)
                vec = New Vector
            End If
        Next
    End Sub

    Private Sub CreateVectors_FollowBorders()
        vl = New VectorList
        For x As Int32 = 1 To sizeX - 2
            For y As Int32 = 1 To sizeY - 2
                If ba(x, y) Then
                    FollowNewVector(x, y)
                End If
            Next
        Next
    End Sub

    Private Sub FollowNewVector(ByVal x As Int32, ByVal y As Int32)
        Dim vec As Vector = New Vector
        vec.points.Add(New Point(x, y))
        ba(x, y) = False
        While FindNextPoint(x, y)
            vec.points.Add(New Point(x, y))
            ba(x, y) = False
        End While
        vl.vectors.Add(vec)
    End Sub

    Private Function FindNextPoint(ByRef x As Int32, ByRef y As Int32) As Boolean
        x += 1
        If ba(x, y) Then Return True
        y -= 1
        If ba(x, y) Then Return True
        x -= 1
        If ba(x, y) Then Return True
        x -= 1
        If ba(x, y) Then Return True
        y += 1
        If ba(x, y) Then Return True
        y += 1
        If ba(x, y) Then Return True
        x += 1
        If ba(x, y) Then Return True
        x += 1
        If ba(x, y) Then Return True
        Return False
    End Function

    Private Sub ConnectVectors()
        Dim i1 As Int32
        Dim i2 As Int32
        i1 = 0
        While i1 < vl.vectors.Count -1
            Dim StartPoint1 As Point = vl.vectors(i1).points(0)
            Dim EndPoint1 As Point = vl.vectors(i1).points(vl.vectors(i1).points.Count - 1)
            i2 = i1 + 1
            While i2 < vl.vectors.Count
                Dim StartPoint2 As Point = vl.vectors(i2).points(0)
                Dim EndPoint2 As Point = vl.vectors(i2).points(vl.vectors(i2).points.Count - 1)
                If AdiacentPoints(EndPoint1, StartPoint2) Then
                    vl.vectors(i1).points.AddRange(vl.vectors(i2).points)
                    vl.vectors.Remove(vl.vectors(i2))
                    i1 -= 1
                    Exit While
                End If

                If AdiacentPoints(EndPoint1, EndPoint2) Then
                    vl.vectors(i2).points.Reverse()
                    vl.vectors(i1).points.AddRange(vl.vectors(i2).points)
                    vl.vectors.Remove(vl.vectors(i2))
                    i1 -= 1
                    Exit While
                End If

                If AdiacentPoints(StartPoint1, StartPoint2) Then
                    vl.vectors(i1).points.Reverse()
                    vl.vectors(i1).points.AddRange(vl.vectors(i2).points)
                    vl.vectors.Remove(vl.vectors(i2))
                    i1 -= 1
                    Exit While
                End If

                If AdiacentPoints(StartPoint1, EndPoint2) Then
                    vl.vectors(i1).points.Reverse()
                    vl.vectors(i2).points.Reverse()
                    vl.vectors(i1).points.AddRange(vl.vectors(i2).points)
                    vl.vectors.Remove(vl.vectors(i2))
                    i1 -= 1
                    Exit While
                End If
                i2 += 1
            End While
            i1 += 1
        End While
    End Sub

    Private Function AdiacentPoints(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        If Math.Abs(p1.X - p2.X) <= 1 And Math.Abs(p1.Y - p2.Y) <= 1 Then
            Return True
        Else
            Return False
        End If
    End Function

    'Private Sub SimplifyVectors()
    '    ' ----------------------------------------------------------- remove by distance
    '    'Dim oldpoint As Point
    '    'Dim i As Int32
    '    'For Each vec As Vector In vl.vectors
    '    '    oldpoint.X = 0
    '    '    oldpoint.Y = 0
    '    '    i = 1
    '    '    While i < vec.points.Count - 1
    '    '        Dim p As Point = vec.points(i)
    '    '        If PointDistance(oldpoint, p) < 5 Then
    '    '            vec.points.Remove(p)
    '    '            i -= 1
    '    '        Else
    '    '            oldpoint = p
    '    '        End If
    '    '        i += 1
    '    '    End While
    '    'Next

    '    ' ----------------------------------------------------------- remove one each two
    '    'Dim i As Int32
    '    'For Each vec As Vector In vl.vectors
    '    '    i = 1
    '    '    While i < vec.points.Count - 1
    '    '        Dim p As Point = vec.points(i)
    '    '        If i Mod (2) <> 0 Then
    '    '            vec.points.Remove(p)
    '    '        End If
    '    '        i += 1
    '    '    End While
    '    'Next
    'End Sub

    Private Sub OptimizeRapids(Optional ByVal x As Int32 = 0, Optional ByVal y As Int32 = 0)
        Dim dummy As Vector
        For i As Int32 = 0 To vl.vectors.Count - 1
            Dim ix As Int32 = FindNearestVectorIndex(x, y, i)
            If ix < Int32.MaxValue Then
                If ix < 0 Then
                    ix = -ix - 1
                    vl.vectors(ix).points.Reverse()
                End If
                dummy = vl.vectors(i)
                vl.vectors(i) = vl.vectors(ix)
                vl.vectors(ix) = dummy
                With vl.vectors(i).points(vl.vectors(i).points.Count - 1)
                    x = .X
                    y = .Y
                End With
            End If
        Next
    End Sub

    Private Function FindNearestVectorIndex(ByVal x As Int32, ByVal y As Int32, ByVal startIndex As Int32) As Int32
        Dim p As Point = New Point(x, y)
        Dim BestIndex As Int32 = Int32.MaxValue
        Dim BestDist As Double = Double.MaxValue
        Dim dist As Double
        For i As Int32 = startIndex To vl.vectors.Count - 1
            Dim vec As Vector = vl.vectors(i)
            ' ------------------------------------------------------------ compare start points
            dist = PointDistance(p, vec.points(0))
            If dist < BestDist Then
                BestDist = dist
                BestIndex = i
            End If
            ' ------------------------------------------------------------ compare end points
            dist = PointDistance(p, vec.points(vec.points.Count - 1))
            If dist < BestDist Then
                BestDist = dist
                BestIndex = -1 - i ' for end points return a negative index starting with -1
            End If
        Next
        Return BestIndex
    End Function

    Private Function PointDistance(ByVal p1 As Point, ByVal p2 As Point) As Double
        Return Math.Sqrt((p1.X - p2.X) ^ 2 + (p1.Y - p2.Y) ^ 2)
    End Function


End Module
