﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.label4 = New System.Windows.Forms.Label
        Me.btn_Vectorize = New System.Windows.Forms.Button
        Me.label7 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.checkBox_Points = New System.Windows.Forms.CheckBox
        Me.checkBox_Traces = New System.Windows.Forms.CheckBox
        Me.checkBox_Fillings = New System.Windows.Forms.CheckBox
        Me.lbl_size = New System.Windows.Forms.Label
        Me.lbl_Threshold = New System.Windows.Forms.Label
        Me.trackBar_Threshold = New System.Windows.Forms.TrackBar
        Me.trackBar_Size = New System.Windows.Forms.TrackBar
        Me.btn_Load = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chk_ShowBitmap = New System.Windows.Forms.CheckBox
        Me.lbl_ThresholdValue = New System.Windows.Forms.Label
        Me.lbl_SizeValue = New System.Windows.Forms.Label
        Me.btn_SaveEmf = New System.Windows.Forms.Button
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ProgressBar1 = New System.Windows.Forms.ToolStripProgressBar
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chk_ShowVector = New System.Windows.Forms.CheckBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btn_SaveFidoCad = New System.Windows.Forms.Button
        Me.txt_CornerThreshold = New Theremino_ImgToVectors.MyTextBox
        Me.txt_ErrorTolerance = New Theremino_ImgToVectors.MyTextBox
        Me.txt_AreaMin = New Theremino_ImgToVectors.MyTextBox
        CType(Me.trackBar_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trackBar_Size, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.Color.Black
        Me.label4.Location = New System.Drawing.Point(18, 26)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(88, 15)
        Me.label4.TabIndex = 94
        Me.label4.Text = "Area min. (pix.)"
        '
        'btn_Vectorize
        '
        Me.btn_Vectorize.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_Vectorize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_Vectorize.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.btn_Vectorize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.btn_Vectorize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Vectorize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Vectorize.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Vectorize.ForeColor = System.Drawing.Color.Black
        Me.btn_Vectorize.Location = New System.Drawing.Point(146, 26)
        Me.btn_Vectorize.Name = "btn_Vectorize"
        Me.btn_Vectorize.Size = New System.Drawing.Size(72, 57)
        Me.btn_Vectorize.TabIndex = 4
        Me.btn_Vectorize.Text = "Vectorize"
        Me.btn_Vectorize.UseVisualStyleBackColor = False
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.ForeColor = System.Drawing.Color.Black
        Me.label7.Location = New System.Drawing.Point(7, 67)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(100, 15)
        Me.label7.TabIndex = 96
        Me.label7.Text = "Corner threshold"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.ForeColor = System.Drawing.Color.Black
        Me.label6.Location = New System.Drawing.Point(18, 47)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(88, 15)
        Me.label6.TabIndex = 95
        Me.label6.Text = "Error tolerance"
        '
        'checkBox_Points
        '
        Me.checkBox_Points.AutoSize = True
        Me.checkBox_Points.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkBox_Points.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkBox_Points.ForeColor = System.Drawing.Color.Black
        Me.checkBox_Points.Location = New System.Drawing.Point(13, 65)
        Me.checkBox_Points.Name = "checkBox_Points"
        Me.checkBox_Points.Size = New System.Drawing.Size(61, 19)
        Me.checkBox_Points.TabIndex = 12
        Me.checkBox_Points.Text = "Points"
        Me.checkBox_Points.UseVisualStyleBackColor = True
        '
        'checkBox_Traces
        '
        Me.checkBox_Traces.AutoSize = True
        Me.checkBox_Traces.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkBox_Traces.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkBox_Traces.ForeColor = System.Drawing.Color.Black
        Me.checkBox_Traces.Location = New System.Drawing.Point(10, 45)
        Me.checkBox_Traces.Name = "checkBox_Traces"
        Me.checkBox_Traces.Size = New System.Drawing.Size(64, 19)
        Me.checkBox_Traces.TabIndex = 11
        Me.checkBox_Traces.Text = "Traces"
        Me.checkBox_Traces.UseVisualStyleBackColor = True
        '
        'checkBox_Fillings
        '
        Me.checkBox_Fillings.AutoSize = True
        Me.checkBox_Fillings.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkBox_Fillings.Checked = True
        Me.checkBox_Fillings.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBox_Fillings.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkBox_Fillings.ForeColor = System.Drawing.Color.Black
        Me.checkBox_Fillings.Location = New System.Drawing.Point(8, 25)
        Me.checkBox_Fillings.Name = "checkBox_Fillings"
        Me.checkBox_Fillings.Size = New System.Drawing.Size(66, 19)
        Me.checkBox_Fillings.TabIndex = 10
        Me.checkBox_Fillings.Text = "Fillings"
        Me.checkBox_Fillings.UseVisualStyleBackColor = True
        '
        'lbl_size
        '
        Me.lbl_size.AutoSize = True
        Me.lbl_size.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_size.ForeColor = System.Drawing.Color.Black
        Me.lbl_size.Location = New System.Drawing.Point(232, 19)
        Me.lbl_size.Name = "lbl_size"
        Me.lbl_size.Size = New System.Drawing.Size(28, 14)
        Me.lbl_size.TabIndex = 92
        Me.lbl_size.Text = "Size"
        '
        'lbl_Threshold
        '
        Me.lbl_Threshold.AutoSize = True
        Me.lbl_Threshold.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Threshold.ForeColor = System.Drawing.Color.Black
        Me.lbl_Threshold.Location = New System.Drawing.Point(98, 19)
        Me.lbl_Threshold.Name = "lbl_Threshold"
        Me.lbl_Threshold.Size = New System.Drawing.Size(55, 14)
        Me.lbl_Threshold.TabIndex = 90
        Me.lbl_Threshold.Text = "Threshold"
        '
        'trackBar_Threshold
        '
        Me.trackBar_Threshold.AutoSize = False
        Me.trackBar_Threshold.Location = New System.Drawing.Point(85, 33)
        Me.trackBar_Threshold.Maximum = 255
        Me.trackBar_Threshold.Name = "trackBar_Threshold"
        Me.trackBar_Threshold.Size = New System.Drawing.Size(118, 24)
        Me.trackBar_Threshold.TabIndex = 2
        Me.trackBar_Threshold.TickStyle = System.Windows.Forms.TickStyle.None
        Me.trackBar_Threshold.Value = 200
        '
        'trackBar_Size
        '
        Me.trackBar_Size.AutoSize = False
        Me.trackBar_Size.Location = New System.Drawing.Point(222, 33)
        Me.trackBar_Size.Maximum = 100
        Me.trackBar_Size.Name = "trackBar_Size"
        Me.trackBar_Size.Size = New System.Drawing.Size(118, 24)
        Me.trackBar_Size.TabIndex = 5
        Me.trackBar_Size.TickStyle = System.Windows.Forms.TickStyle.None
        Me.trackBar_Size.Value = 60
        '
        'btn_Load
        '
        Me.btn_Load.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_Load.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_Load.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.btn_Load.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.btn_Load.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Load.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Load.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Load.ForeColor = System.Drawing.Color.Black
        Me.btn_Load.Location = New System.Drawing.Point(9, 26)
        Me.btn_Load.Name = "btn_Load"
        Me.btn_Load.Size = New System.Drawing.Size(72, 57)
        Me.btn_Load.TabIndex = 1
        Me.btn_Load.Text = "Load file"
        Me.btn_Load.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.chk_ShowBitmap)
        Me.GroupBox1.Controls.Add(Me.lbl_ThresholdValue)
        Me.GroupBox1.Controls.Add(Me.btn_Load)
        Me.GroupBox1.Controls.Add(Me.trackBar_Threshold)
        Me.GroupBox1.Controls.Add(Me.lbl_Threshold)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox1.Location = New System.Drawing.Point(8, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(207, 90)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Load image file"
        '
        'chk_ShowBitmap
        '
        Me.chk_ShowBitmap.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_ShowBitmap.BackColor = System.Drawing.Color.WhiteSmoke
        Me.chk_ShowBitmap.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.chk_ShowBitmap.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.chk_ShowBitmap.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.chk_ShowBitmap.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.chk_ShowBitmap.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_ShowBitmap.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ShowBitmap.ForeColor = System.Drawing.Color.Black
        Me.chk_ShowBitmap.Location = New System.Drawing.Point(90, 58)
        Me.chk_ShowBitmap.Name = "chk_ShowBitmap"
        Me.chk_ShowBitmap.Size = New System.Drawing.Size(105, 25)
        Me.chk_ShowBitmap.TabIndex = 3
        Me.chk_ShowBitmap.Text = "Show Bitmap"
        Me.chk_ShowBitmap.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ShowBitmap.UseVisualStyleBackColor = False
        '
        'lbl_ThresholdValue
        '
        Me.lbl_ThresholdValue.AutoSize = True
        Me.lbl_ThresholdValue.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ThresholdValue.ForeColor = System.Drawing.Color.Black
        Me.lbl_ThresholdValue.Location = New System.Drawing.Point(155, 18)
        Me.lbl_ThresholdValue.Name = "lbl_ThresholdValue"
        Me.lbl_ThresholdValue.Size = New System.Drawing.Size(21, 15)
        Me.lbl_ThresholdValue.TabIndex = 91
        Me.lbl_ThresholdValue.Text = "00"
        '
        'lbl_SizeValue
        '
        Me.lbl_SizeValue.AutoSize = True
        Me.lbl_SizeValue.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_SizeValue.ForeColor = System.Drawing.Color.Black
        Me.lbl_SizeValue.Location = New System.Drawing.Point(260, 18)
        Me.lbl_SizeValue.Name = "lbl_SizeValue"
        Me.lbl_SizeValue.Size = New System.Drawing.Size(16, 15)
        Me.lbl_SizeValue.TabIndex = 93
        Me.lbl_SizeValue.Text = "..."
        '
        'btn_SaveEmf
        '
        Me.btn_SaveEmf.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_SaveEmf.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_SaveEmf.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.btn_SaveEmf.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.btn_SaveEmf.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_SaveEmf.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SaveEmf.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveEmf.ForeColor = System.Drawing.Color.Black
        Me.btn_SaveEmf.Location = New System.Drawing.Point(84, 25)
        Me.btn_SaveEmf.Name = "btn_SaveEmf"
        Me.btn_SaveEmf.Size = New System.Drawing.Size(142, 25)
        Me.btn_SaveEmf.TabIndex = 13
        Me.btn_SaveEmf.Text = "Save EMF file"
        Me.btn_SaveEmf.UseVisualStyleBackColor = False
        '
        'pictureBox1
        '
        Me.pictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pictureBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pictureBox1.Location = New System.Drawing.Point(6, 98)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(798, 355)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox1.TabIndex = 1
        Me.pictureBox1.TabStop = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1, Me.ProgressBar1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 457)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(811, 26)
        Me.StatusStrip1.TabIndex = 100
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.Margin = New System.Windows.Forms.Padding(3, 3, 0, 2)
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(52, 21)
        Me.StatusLabel1.Text = "Working"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(3, 5, 3, 2)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(650, 19)
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.txt_CornerThreshold)
        Me.GroupBox2.Controls.Add(Me.chk_ShowVector)
        Me.GroupBox2.Controls.Add(Me.lbl_size)
        Me.GroupBox2.Controls.Add(Me.txt_ErrorTolerance)
        Me.GroupBox2.Controls.Add(Me.btn_Vectorize)
        Me.GroupBox2.Controls.Add(Me.label4)
        Me.GroupBox2.Controls.Add(Me.label6)
        Me.GroupBox2.Controls.Add(Me.txt_AreaMin)
        Me.GroupBox2.Controls.Add(Me.trackBar_Size)
        Me.GroupBox2.Controls.Add(Me.lbl_SizeValue)
        Me.GroupBox2.Controls.Add(Me.label7)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox2.Location = New System.Drawing.Point(221, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(343, 90)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Transform image to vectors"
        '
        'chk_ShowVector
        '
        Me.chk_ShowVector.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_ShowVector.BackColor = System.Drawing.Color.WhiteSmoke
        Me.chk_ShowVector.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.chk_ShowVector.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.chk_ShowVector.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.chk_ShowVector.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.chk_ShowVector.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_ShowVector.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ShowVector.ForeColor = System.Drawing.Color.Black
        Me.chk_ShowVector.Location = New System.Drawing.Point(229, 58)
        Me.chk_ShowVector.Name = "chk_ShowVector"
        Me.chk_ShowVector.Size = New System.Drawing.Size(105, 25)
        Me.chk_ShowVector.TabIndex = 6
        Me.chk_ShowVector.Text = "Show Vector"
        Me.chk_ShowVector.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_ShowVector.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.checkBox_Fillings)
        Me.GroupBox3.Controls.Add(Me.checkBox_Points)
        Me.GroupBox3.Controls.Add(Me.btn_SaveFidoCad)
        Me.GroupBox3.Controls.Add(Me.checkBox_Traces)
        Me.GroupBox3.Controls.Add(Me.btn_SaveEmf)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox3.Location = New System.Drawing.Point(570, 2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(234, 90)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Save vectors to file"
        '
        'btn_SaveFidoCad
        '
        Me.btn_SaveFidoCad.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_SaveFidoCad.Enabled = False
        Me.btn_SaveFidoCad.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_SaveFidoCad.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow
        Me.btn_SaveFidoCad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.btn_SaveFidoCad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_SaveFidoCad.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SaveFidoCad.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveFidoCad.ForeColor = System.Drawing.Color.Black
        Me.btn_SaveFidoCad.Location = New System.Drawing.Point(84, 56)
        Me.btn_SaveFidoCad.Name = "btn_SaveFidoCad"
        Me.btn_SaveFidoCad.Size = New System.Drawing.Size(142, 25)
        Me.btn_SaveFidoCad.TabIndex = 14
        Me.btn_SaveFidoCad.Text = "Save FidoCad file"
        Me.btn_SaveFidoCad.UseVisualStyleBackColor = False
        '
        'txt_CornerThreshold
        '
        Me.txt_CornerThreshold.ArrowsIncrement = 0.01
        Me.txt_CornerThreshold.BackColor = System.Drawing.Color.GhostWhite
        Me.txt_CornerThreshold.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_CornerThreshold.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CornerThreshold.Decimals = 2
        Me.txt_CornerThreshold.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CornerThreshold.ForeColor = System.Drawing.Color.Black
        Me.txt_CornerThreshold.Increment = 0.002
        Me.txt_CornerThreshold.Location = New System.Drawing.Point(105, 65)
        Me.txt_CornerThreshold.MaxValue = 9
        Me.txt_CornerThreshold.MinValue = 0
        Me.txt_CornerThreshold.Multiline = True
        Me.txt_CornerThreshold.Name = "txt_CornerThreshold"
        Me.txt_CornerThreshold.NumericValue = 1
        Me.txt_CornerThreshold.NumericValueInteger = 1
        Me.txt_CornerThreshold.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_CornerThreshold.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_CornerThreshold.RoundingStep = 0
        Me.txt_CornerThreshold.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_CornerThreshold.Size = New System.Drawing.Size(31, 17)
        Me.txt_CornerThreshold.SuppressZeros = True
        Me.txt_CornerThreshold.TabIndex = 9
        Me.txt_CornerThreshold.Text = "1"
        Me.txt_CornerThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ErrorTolerance
        '
        Me.txt_ErrorTolerance.ArrowsIncrement = 0.1
        Me.txt_ErrorTolerance.BackColor = System.Drawing.Color.GhostWhite
        Me.txt_ErrorTolerance.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ErrorTolerance.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ErrorTolerance.Decimals = 1
        Me.txt_ErrorTolerance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ErrorTolerance.ForeColor = System.Drawing.Color.Black
        Me.txt_ErrorTolerance.Increment = 0.02
        Me.txt_ErrorTolerance.Location = New System.Drawing.Point(105, 45)
        Me.txt_ErrorTolerance.MaxValue = 99
        Me.txt_ErrorTolerance.MinValue = 0
        Me.txt_ErrorTolerance.Multiline = True
        Me.txt_ErrorTolerance.Name = "txt_ErrorTolerance"
        Me.txt_ErrorTolerance.NumericValue = 1
        Me.txt_ErrorTolerance.NumericValueInteger = 1
        Me.txt_ErrorTolerance.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ErrorTolerance.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ErrorTolerance.RoundingStep = 0
        Me.txt_ErrorTolerance.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ErrorTolerance.Size = New System.Drawing.Size(31, 17)
        Me.txt_ErrorTolerance.SuppressZeros = True
        Me.txt_ErrorTolerance.TabIndex = 8
        Me.txt_ErrorTolerance.Text = "1"
        Me.txt_ErrorTolerance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_AreaMin
        '
        Me.txt_AreaMin.ArrowsIncrement = 1
        Me.txt_AreaMin.BackColor = System.Drawing.Color.GhostWhite
        Me.txt_AreaMin.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AreaMin.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AreaMin.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AreaMin.ForeColor = System.Drawing.Color.Black
        Me.txt_AreaMin.Increment = 0.2
        Me.txt_AreaMin.Location = New System.Drawing.Point(105, 25)
        Me.txt_AreaMin.MaxValue = 999
        Me.txt_AreaMin.MinValue = 0
        Me.txt_AreaMin.Multiline = True
        Me.txt_AreaMin.Name = "txt_AreaMin"
        Me.txt_AreaMin.NumericValue = 1
        Me.txt_AreaMin.NumericValueInteger = 1
        Me.txt_AreaMin.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AreaMin.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AreaMin.RoundingStep = 0
        Me.txt_AreaMin.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AreaMin.Size = New System.Drawing.Size(31, 17)
        Me.txt_AreaMin.SuppressZeros = True
        Me.txt_AreaMin.TabIndex = 7
        Me.txt_AreaMin.Text = "1"
        Me.txt_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(811, 483)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.pictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(827, 522)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino ImgToVectors"
        CType(Me.trackBar_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trackBar_Size, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents btn_Vectorize As System.Windows.Forms.Button
    Private WithEvents lbl_size As System.Windows.Forms.Label
    Private WithEvents lbl_Threshold As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents btn_Load As System.Windows.Forms.Button
    Private WithEvents lbl_ThresholdValue As System.Windows.Forms.Label
    Private WithEvents btn_SaveEmf As System.Windows.Forms.Button
    Private WithEvents lbl_SizeValue As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents checkBox_Points As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox_Traces As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox_Fillings As System.Windows.Forms.CheckBox
    Friend WithEvents trackBar_Threshold As System.Windows.Forms.TrackBar
    Friend WithEvents trackBar_Size As System.Windows.Forms.TrackBar
    Friend WithEvents txt_CornerThreshold As MyTextBox
    Friend WithEvents txt_ErrorTolerance As MyTextBox
    Friend WithEvents txt_AreaMin As MyTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents btn_SaveFidoCad As System.Windows.Forms.Button
    Friend WithEvents chk_ShowBitmap As System.Windows.Forms.CheckBox
    Friend WithEvents chk_ShowVector As System.Windows.Forms.CheckBox
End Class
