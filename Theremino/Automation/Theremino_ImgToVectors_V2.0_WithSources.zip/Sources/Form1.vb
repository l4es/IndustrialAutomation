﻿
Imports System.Collections
Imports System.Windows.Forms

Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Load_INI()
        StatusLabel1.Visible = False
        ProgressBar1.Visible = False
        lbl_ThresholdValue.Text = trackBar_Threshold.Value.ToString
        RasterToVectors.AreaMin = txt_AreaMin.NumericValueInteger
        RasterToVectors.CornerThreshold = txt_CornerThreshold.NumericValue
        RasterToVectors.ErrorTolerance = txt_ErrorTolerance.NumericValue
        btn_Vectorize.Enabled = False
        btn_SaveEmf.Enabled = False
        OpenImage(ImageFile)
        Me.Text = AppTitleAndVersion("Theremino - Img to Vectors")
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Exit Sub
        Save_INI()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub trackBar_Threshold_Scroll(ByVal sender As Object, ByVal e As EventArgs) Handles trackBar_Threshold.Scroll
        If Not EventsAreEnabled Then Return
        lbl_ThresholdValue.Text = trackBar_Threshold.Value.ToString
        RefreshMatrix()
        RefreshPicture()
    End Sub

    Private Sub trackBar_Zoom_Scroll(ByVal sender As Object, ByVal e As EventArgs) Handles trackBar_Size.Scroll
        If Not EventsAreEnabled Then Return
        RefreshPicture()
    End Sub
    Private Sub Fillings_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles checkBox_Fillings.CheckedChanged
        If Not EventsAreEnabled Then Return
        RefreshPicture()
    End Sub
    Private Sub Traces_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles checkBox_Traces.CheckedChanged
        If Not EventsAreEnabled Then Return
        RefreshPicture()
    End Sub
    Private Sub Points_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles checkBox_Points.CheckedChanged
        If Not EventsAreEnabled Then Return
        RefreshPicture()
    End Sub

    Private Sub txt_AreaMin_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_AreaMin.TextChanged
        If Not EventsAreEnabled Then Return
        RequireNewVectorization()
    End Sub
    Private Sub txt_ErrorTolerance_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_ErrorTolerance.TextChanged
        If Not EventsAreEnabled Then Return
        RequireNewVectorization()
    End Sub
    Private Sub txt_CornerThreshold_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_CornerThreshold.TextChanged
        If Not EventsAreEnabled Then Return
        RequireNewVectorization()
    End Sub

    Private Sub RequireNewVectorization()
        chk_ShowBitmap.Checked = True
    End Sub


    Private Sub ShowVector_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chk_ShowVector.CheckedChanged
        If Not EventsAreEnabled Then Return
        If chk_ShowVector.Checked Then
            chk_ShowBitmap.Checked = False
        Else
            chk_ShowBitmap.Checked = True
        End If
        RefreshPicture()
    End Sub
    Private Sub ShowBitmap_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chk_ShowBitmap.CheckedChanged
        If chk_ShowBitmap.Checked Then
            chk_ShowVector.Checked = False
            lbl_Threshold.Enabled = True
            lbl_ThresholdValue.Enabled = True
            trackBar_Threshold.Enabled = True
            lbl_size.Enabled = False
            lbl_SizeValue.Enabled = False
            trackBar_Size.Enabled = False
            btn_SaveEmf.Enabled = False
            btn_SaveFidoCad.Enabled = False
        Else
            chk_ShowVector.Checked = True
            lbl_Threshold.Enabled = False
            lbl_ThresholdValue.Enabled = False
            trackBar_Threshold.Enabled = False
            lbl_size.Enabled = True
            lbl_SizeValue.Enabled = True
            trackBar_Size.Enabled = True
        End If
        If Not EventsAreEnabled Then Return
        RefreshPicture()
    End Sub


    Private Sub RefreshPicture()
        If Matrix Is Nothing Then Return
        SizeFactor = (321.0F + 15.01F * trackBar_Size.Value) / Matrix.GetLength(0)

        Dim w As Int32 = CInt((Matrix.GetLength(0) - 2) * SizeFactor)
        Dim h As Int32 = CInt((Matrix.GetLength(1) - 2) * SizeFactor)
        lbl_SizeValue.Text = w.ToString & " x " & h.ToString

        If pictureBox1.Image IsNot Nothing Then pictureBox1.Image.Dispose()
        If chk_ShowBitmap.Checked Then
            SizeFactor = 1
            'pictureBox1.Width = CInt(B.Width * factor)
            'pictureBox1.Height = CInt(B.Height * factor)
            Dim B As Bitmap = RasterToVectors.BinaryBitmap_to_Bitmap(Matrix)
            pictureBox1.Image = B
        Else
            'pictureBox1.Width = B.Width
            'pictureBox1.Height = B.Height
            Dim B As New Bitmap(w, h, Imaging.PixelFormat.Format32bppArgb)
            pictureBox1.Image = B
            B.SetResolution(Bitmap.HorizontalResolution * SizeFactor, Bitmap.VerticalResolution * SizeFactor)
            Dim g As Graphics = Graphics.FromImage(pictureBox1.Image)
            g.Clear(Color.White)
            DrawListToGraphics(g, _
                               False, _
                               checkBox_Fillings.Checked, _
                               checkBox_Traces.Checked, _
                               checkBox_Points.Checked)
        End If
    End Sub

    Private Sub RefreshMatrix()
        If Bitmap Is Nothing Then Return
        Matrix = RasterToVectors.Bitmap_to_BinaryBitmap(Bitmap, trackBar_Threshold.Value)
    End Sub

    Private Sub btn_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Load.Click
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ofd.Filter = "Image files (*.jpeg;*.gif;*.png;*.bmp;*.tiff)|*.jpeg;*.jpg;*.gif;*.png;*.bmp;*.tiff;*.tif|All files (*.*)|*.*"
        If IO.File.Exists(ImageFile) Then
            ofd.InitialDirectory = IO.Path.GetDirectoryName(ImageFile)
            ofd.FileName = ImageFile
        Else
            ImageFile = Application.StartupPath & "\Vector Images\"
            ofd.InitialDirectory = IO.Path.GetDirectoryName(ImageFile)
            'ofd.FileName = ImageFile
        End If
        If ofd.ShowDialog() = DialogResult.OK Then
            If Bitmap IsNot Nothing Then Bitmap.Dispose()
            OpenImage(ofd.FileName)
        End If
    End Sub

    Private Sub OpenImage(ByVal newName As String)
        Try
            Bitmap = New Bitmap(newName)
            ImageFile = newName
            GroupBox1.Enabled = False
            GroupBox1.Refresh()
            ListOfCurvesArray = Nothing
            EventsAreEnabled = False
            chk_ShowBitmap.Checked = True
            chk_ShowVector.Checked = False
            RefreshMatrix()
            RefreshPicture()
            btn_Vectorize.Enabled = True
            btn_SaveEmf.Enabled = False
            btn_SaveFidoCad.Enabled = False
            GroupBox1.Enabled = True
            GroupBox1.Refresh()
            EventsAreEnabled = True
        Catch
        End Try
    End Sub


    ' ========================================================================================================
    '  RASTER TO VECTORS
    ' ========================================================================================================
    Private Sub btn_Vectorize_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_Vectorize.Click
        If Bitmap Is Nothing Then Return
        EventsAreEnabled = False

        StatusLabel1.Visible = True
        ProgressBar1.Visible = True

        GroupBox1.Enabled = False
        GroupBox2.Enabled = False
        GroupBox3.Enabled = False
        GroupBox1.Refresh()
        Refresh()
        '
        RasterToVectors.AreaMin = txt_AreaMin.NumericValueInteger
        RasterToVectors.CornerThreshold = txt_CornerThreshold.NumericValue
        RasterToVectors.ErrorTolerance = txt_ErrorTolerance.NumericValue 'if <> 0 then replace Bezier-segments by single segment
        '
        ListOfCurvesArray = New ArrayList()
        Matrix = RasterToVectors.Bitmap_to_BinaryBitmap(Bitmap, trackBar_Threshold.Value)
        RasterToVectors.BynaryBitmap_ToListOfCurves(Matrix, ListOfCurvesArray)

        chk_ShowVector.Checked = True
        chk_ShowBitmap.Checked = False
        RefreshMatrix()
        RefreshPicture()
        '
        ProgressBar1.Value = 0
        StatusLabel1.Visible = False
        ProgressBar1.Visible = False

        btn_SaveEmf.Enabled = True
        btn_SaveFidoCad.Enabled = True
        GroupBox1.Enabled = True
        GroupBox2.Enabled = True
        GroupBox3.Enabled = True
        EventsAreEnabled = True
    End Sub

    Private Sub btn_SaveEmf_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveEmf.Click
        If ListOfCurvesArray Is Nothing Then Return
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.Filter = "Enhanced meta file (*.emf)|*.emf|" & _
                     "Jpeg image (*.jpg)|*.jpg|" & _
                     "Portable network graphics (*.png)|*.png"
        sfd.FileName = IO.Path.GetFileNameWithoutExtension(ImageFile)
        sfd.FilterIndex = SaveFormat
        sfd.AddExtension = True
        If sfd.ShowDialog() = DialogResult.OK Then
            SaveFormat = sfd.FilterIndex
            Select Case SaveFormat
                Case 1
                    Dim g As Graphics = Graphics.FromImage(pictureBox1.Image)
                    DrawGraphicsPathToMetafile(g, sfd.FileName, _
                                               False, _
                                               checkBox_Fillings.Checked, _
                                               checkBox_Traces.Checked, _
                                               checkBox_Points.Checked)
                Case 2
                    SaveImage(pictureBox1.Image, sfd.FileName, "jpg", 100)
                Case 3
                    pictureBox1.Image.Save(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png)
            End Select
        End If
    End Sub

    Private Sub btn_SaveFidoCad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveFidoCad.Click
        If ListOfCurvesArray Is Nothing Then Return
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.Filter = "FidoCad file (*.fcd)|*.fcd|" & _
                     "Text file (*.txt)|*.txt|" & _
                     "All files (*.*)|*.*"
        sfd.FileName = IO.Path.GetFileNameWithoutExtension(ImageFile)
        sfd.FilterIndex = SaveFormat
        sfd.AddExtension = True
        If sfd.ShowDialog() = DialogResult.OK Then
       
            Dim g As Graphics = Graphics.FromImage(pictureBox1.Image)
            DrawListToFidocadFile(sfd.FileName, _
                                  checkBox_Fillings.Checked, _
                                  checkBox_Traces.Checked, _
                                  checkBox_Points.Checked)
        End If
    End Sub

  
End Class