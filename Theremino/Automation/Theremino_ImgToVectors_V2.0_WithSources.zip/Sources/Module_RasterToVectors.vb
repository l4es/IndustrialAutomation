
' This module works only enabling the flag "Remove integer overflow checks"
' In "Project" / "Options" / "Compile" / "Advanced compile options" 

Imports System.Collections.Generic
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Runtime.InteropServices
Imports System.Drawing.Drawing2D


Public Module RasterToVectors

    Friend Matrix As Boolean(,)
    Friend ListOfCurvesArray As ArrayList
    Friend Bitmap As Bitmap
    Friend SizeFactor As Single = 1

    Private Const CORNER As Integer = 1
    Private Const CURVETO As Integer = 2
    Private COS179 As Double = Math.Cos(179 * Math.PI / 180)

    Friend AreaMin As Integer = 1          ' area of largest path to be ignored
    Friend CornerThreshold As Double = 1   ' corner threshold
    Friend ErrorTolerance As Double = 1    ' curve optimization tolerance (if zero then no optimization)

    ' ----------------------------------------------------------------------------------------------
    ' OptimizeCurves
    ' optimize the path p, replacing sequences of Bezier segments by a single segment when possible
    ' ----------------------------------------------------------------------------------------------

    Private Enum Direction
        North
        East
        South
        West
    End Enum

    ' ------------------------------------------------ Kind of Curve : Line or Bezier
    Friend Enum CurveKind
        Line
        Bezier
    End Enum

    ' ------------------------------------------------ Holds the information about produced curves
    Friend Structure Curve
        Public Kind As CurveKind        ' Bezier or Line
        Public A As dPoint              ' Startpoint
        Public ControlPointA As dPoint  ' ControlPoint
        Public ControlPointB As dPoint  ' ControlPoint
        Public B As dPoint              ' Endpoint
        '
        Public Sub New(ByVal Kind As CurveKind, _
                       ByVal A As dPoint, _
                       ByVal ControlPointA As dPoint, _
                       ByVal ControlPointB As dPoint, _
                       ByVal B As dPoint)
            Me.Kind = Kind
            Me.A = A
            Me.B = B
            Me.ControlPointA = ControlPointA
            Me.ControlPointB = ControlPointB
            Me.B = B
        End Sub
    End Structure

    Private Class Path
        Public area As Integer
        Public MonotonIntervals As ArrayList
        Public pt As iPoint()
        Public Lon As Integer()
        Public Sums As SumStruct()
        Public po As Integer()
        Public Curves As privcurve
        Public OptimizedCurves As privcurve
        Public FCurves As privcurve
    End Class

    Private Structure iPoint
        Public x As Integer
        Public y As Integer
        Public Sub New(ByVal x As Integer, ByVal y As Integer)
            Me.x = x
            Me.y = y
        End Sub
    End Structure

    Friend Structure dPoint
        Public x As Double
        Public y As Double
        Public Sub New(ByVal x As Double, ByVal y As Double)
            Me.x = x
            Me.y = y
        End Sub
    End Structure

    Private Structure SumStruct
        Public x As Integer
        Public y As Integer
        Public xy As Integer
        Public x2 As Integer
        Public y2 As Integer
    End Structure

    Private Class privcurve
        Public n As Integer                 ' number of segments 
        Public tag As Integer()             ' tag[n]: CORNER or CURVETO 
        Public ControlPoints As dPoint(,)   ' c[n][i]: control points --- c[n][0] is unused for tag[n] = CORNER 
        Public vertex As dPoint()           ' for CORNER, this equals c[1] --- (*c)[3]; /* c[n][i]: control points. 
        Public alpha As Double()            ' only for CURVETO 
        Public alpha0 As Double()           ' "uncropped" alpha parameter - for debug output only 
        Public beta As Double()
        Public Sub New(ByVal Count As Integer)
            n = Count
            tag = New Integer(n - 1) {}
            ControlPoints = New dPoint(n - 1, 2) {}
            vertex = New dPoint(n - 1) {}
            alpha = New Double(n - 1) {}
            alpha0 = New Double(n - 1) {}
            beta = New Double(n - 1) {}
        End Sub
    End Class

    ' ----------------------------------------------------------------- calculate the bezier curve point 
    Private Function bezier(ByVal t As Double, _
                                   ByVal p0 As dPoint, _
                                   ByVal p1 As dPoint, _
                                   ByVal p2 As dPoint, _
                                   ByVal p3 As dPoint) As dPoint
        Dim s As Double = 1 - t
        Dim res As dPoint
        '
        res.x = s * s * s * p0.x + 3 * (s * s * t) * p1.x + 3 * (t * t * s) * p2.x + t * t * t * p3.x
        res.y = s * s * s * p0.y + 3 * (s * s * t) * p1.y + 3 * (t * t * s) * p2.y + t * t * t * p3.y
        '
        Return res
    End Function

    ' calculate the point t in [0..1] on the (convex) bezier curve
    ' (p0,p1,p2,p3) which is tangent to q1-q0. Return -1.0 if there is no solution in [0..1]
    Private Function tangent(ByVal p0 As dPoint, _
                                    ByVal p1 As dPoint, _
                                    ByVal p2 As dPoint, _
                                    ByVal p3 As dPoint, _
                                    ByVal q0 As dPoint, _
                                    ByVal q1 As dPoint) As Double

        Dim A__1 As Double, B__2 As Double, C__3 As Double
        Dim a__4 As Double, b__5 As Double, c__6 As Double
        Dim d As Double, s As Double, r1 As Double, r2 As Double

        ' (1-t)^2 A + 2(1-t)t B + t^2 C = 0 
        ' a t^2 + b t + c = 0 

        A__1 = cprod(p0, p1, q0, q1)
        B__2 = cprod(p1, p2, q0, q1)
        C__3 = cprod(p2, p3, q0, q1)

        a__4 = A__1 - 2 * B__2 + C__3
        b__5 = -2 * A__1 + 2 * B__2
        c__6 = A__1

        d = b__5 * b__5 - 4 * a__4 * c__6

        If a__4 = 0 OrElse d < 0 Then
            Return -1
        End If

        s = Math.Sqrt(d)

        r1 = (-b__5 + s) / (2 * a__4)
        r2 = (-b__5 - s) / (2 * a__4)

        If r1 >= 0 AndAlso r1 <= 1 Then
            Return r1
        ElseIf r2 >= 0 AndAlso r2 <= 1 Then
            Return r2
        Else
            Return -1
        End If
    End Function

    ' ------------------------------------------------------------- calculate distance between two points 
    Private Function ddist(ByVal p As dPoint, ByVal q As dPoint) As Double
        Return Math.Sqrt((p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y))
    End Function

    ' ------------------------------------------------------------- calculate p1 x p2 
    Private Function xprod(ByVal p1 As iPoint, ByVal p2 As iPoint) As Integer
        Return p1.x * p2.y - p1.y * p2.x
    End Function

    ' ------------------------------------------------------------- calculate p1 x p2 
    Private Function xprod(ByVal p1 As dPoint, ByVal p2 As dPoint) As Double
        Return p1.x * p2.y - p1.y * p2.x
    End Function

    ' ------------------------------------------------------------- calculate (p1-p0)x(p3-p2) 
    Private Function cprod(ByVal p0 As dPoint, ByVal p1 As dPoint, ByVal p2 As dPoint, ByVal p3 As dPoint) As Double
        Dim x1 As Double, y1 As Double, x2 As Double, y2 As Double
        x1 = p1.x - p0.x
        y1 = p1.y - p0.y
        x2 = p3.x - p2.x
        y2 = p3.y - p2.y
        Return x1 * y2 - x2 * y1
    End Function

    ' ------------------------------------------------------------- calculate (p1-p0)*(p2-p0) 
    Private Function iprod(ByVal p0 As dPoint, ByVal p1 As dPoint, ByVal p2 As dPoint) As Double
        Dim x1 As Double, y1 As Double, x2 As Double, y2 As Double
        x1 = p1.x - p0.x
        y1 = p1.y - p0.y
        x2 = p2.x - p0.x
        y2 = p2.y - p0.y
        Return x1 * x2 + y1 * y2
    End Function

    ' ------------------------------------------------------------- calculate (p1-p0)*(p3-p2) 
    Private Function iprod1(ByVal p0 As dPoint, ByVal p1 As dPoint, ByVal p2 As dPoint, ByVal p3 As dPoint) As Double
        Dim x1 As Double, y1 As Double, x2 As Double, y2 As Double
        x1 = p1.x - p0.x
        y1 = p1.y - p0.y
        x2 = p3.x - p2.x
        y2 = p3.y - p2.y
        Return x1 * x2 + y1 * y2
    End Function

    ' -------------------------------------------------------------------------------------------- 
    ' return a direction that is 90 degrees counterclockwise from p2-p0,
    ' but restricted to one of the major directions (n, nw, w, etc) 
    ' -------------------------------------------------------------------------------------------- 
    Private Function dorth_infty(ByVal p0 As dPoint, ByVal p2 As dPoint) As iPoint
        Dim r As iPoint
        r.y = sign(p2.x - p0.x)
        r.x = -sign(p2.y - p0.y)
        Return r
    End Function

    ' range over the straight line segment [a,b] when lambda ranges over [0,1] 
    Private Function interval(ByVal lambda As Double, ByVal a As dPoint, ByVal b As dPoint) As dPoint
        Dim res As dPoint
        res.x = a.x + lambda * (b.x - a.x)
        res.y = a.y + lambda * (b.y - a.y)
        Return res
    End Function

    ' return (p1-p0)x(p2-p0), the area of the parallelogram 
    Private Function dpara(ByVal p0 As dPoint, ByVal p1 As dPoint, ByVal p2 As dPoint) As Double
        Dim x1 As Double, y1 As Double, x2 As Double, y2 As Double
        x1 = p1.x - p0.x
        y1 = p1.y - p0.y
        x2 = p2.x - p0.x
        y2 = p2.y - p0.y
        Return x1 * y2 - x2 * y1
    End Function

    ' ddenom/dpara have the property that the square of radius 1 centered
    ' at p1 intersects the line p0p2 iff |dpara(p0,p1,p2)| <= ddenom(p0,p2) 
    Private Function ddenom(ByVal p0 As dPoint, ByVal p2 As dPoint) As Double
        Dim r As iPoint = dorth_infty(p0, p2)
        Return r.y * (p2.x - p0.x) - r.x * (p2.y - p0.y)
    End Function

    ' return 1 if a <= b < c < a, in a cyclic sense (mod n) 
    Private Function cyclic(ByVal a As Integer, ByVal b As Integer, ByVal c As Integer) As Boolean
        If a <= c Then
            Return (a <= b AndAlso b < c)
        Else
            Return (a <= b OrElse b < c)
        End If
    End Function

    ' determine the center and slope of the line i..j. Assume i<j. 
    ' Needs "sum" components of p to be set. 
    Private Sub pointslope(ByVal pp As Path, ByVal i As Integer, ByVal j As Integer, ByRef ctr As dPoint, ByRef dir As dPoint)
        ' ------------------------------------------- assume i<j 
        Dim n As Integer = pp.pt.Length
        Dim sums As SumStruct() = pp.Sums
        '
        Dim x As Double, y As Double, x2 As Double, xy As Double, y2 As Double
        Dim k As Double
        Dim a As Double, b As Double, c As Double, lambda2 As Double, l As Double
        Dim r As Integer = 0
        ' ------------------------------------------- rotations from i to j 
        While j >= n
            j -= n
            r += 1
        End While
        While i >= n
            i -= n
            r -= 1
        End While
        While j < 0
            j += n
            r -= 1
        End While
        While i < 0
            i += n
            r += 1
        End While

        x = sums(j + 1).x - sums(i).x + r * sums(n).x
        y = sums(j + 1).y - sums(i).y + r * sums(n).y
        x2 = sums(j + 1).x2 - sums(i).x2 + r * sums(n).x2
        xy = sums(j + 1).xy - sums(i).xy + r * sums(n).xy
        y2 = sums(j + 1).y2 - sums(i).y2 + r * sums(n).y2
        k = j + 1 - i + r * n

        ctr.x = x / k
        ctr.y = y / k

        a = (x2 - CDbl(x) * x / k) / k
        b = (xy - CDbl(x) * y / k) / k
        c = (y2 - CDbl(y) * y / k) / k

        lambda2 = (a + c + Math.Sqrt((a - c) * (a - c) + 4 * b * b)) / 2

        ' ------------------------------ larger e.value 

        ' ------------------------------ now find e.vector for lambda2 
        a -= lambda2
        c -= lambda2

        If Math.Abs(a) >= Math.Abs(c) Then
            l = Math.Sqrt(a * a + b * b)
            If l <> 0 Then
                dir.x = -b / l
                dir.y = a / l
            End If
        Else
            l = Math.Sqrt(c * c + b * b)
            If l <> 0 Then
                dir.x = -c / l
                dir.y = b / l
            End If
        End If
        ' ------------------------------- sometimes this can happen when k=4 (the two eigenvalues coincide) 
        If l = 0 Then
            dir.x = 0
            dir.y = 0
        End If
    End Sub

    ' ---------------------------------------------------------------------------------------------------
    '  integer arithmetic
    ' ---------------------------------------------------------------------------------------------------
    Private Function sign(ByVal x As Integer) As Integer
        Return (If((x) > 0, 1, If((x) < 0, -1, 0)))
    End Function
    Private Function sign(ByVal x As Double) As Integer
        Return (If((x) > 0, 1, If((x) < 0, -1, 0)))
    End Function
    Private Function abs(ByVal a As Integer) As Integer
        Return (If((a) > 0, (a), -(a)))
    End Function
    Private Function min(ByVal a As Integer, ByVal b As Integer) As Integer
        Return (If((a) < (b), (a), (b)))
    End Function
    Private Function max(ByVal a As Integer, ByVal b As Integer) As Integer
        Return (If((a) > (b), (a), (b)))
    End Function
    Private Function sq(ByVal a As Integer) As Integer
        Return ((a) * (a))
    End Function
    Private Function cu(ByVal a As Integer) As Integer
        Return ((a) * (a) * (a))
    End Function
    Private Function [mod](ByVal a As Integer, ByVal n As Integer) As Integer
        Return If(a >= n, a Mod n, If(a >= 0, a, n - 1 - (-1 - a) Mod n))
    End Function
    Private Function floordiv(ByVal a As Integer, ByVal n As Integer) As Integer
        Return If(a >= 0, a \ n, -1 - (-1 - a) \ n)
    End Function

    ' ---------------------------------------------------------------------------------------------------
    ' The MonotonInterval defines a structure related to an iPoint array.
    ' For each index i,j with 
    ' from &lt;= i &lt; j &lt;= to 
    ' in a cyclic sense is iPointArray[i].y &lt;= iPointArray[j].y if Increasing is true,
    ' else is iPointArray[i].y &gt;= iPointArray[j].y.
    ' ---------------------------------------------------------------------------------------------------
    Private Class MonotonInterval
        Public Increasing As Boolean
        Public from As Integer
        Public [to] As Integer
        Public CurrentID As Integer
        Public Sub ResetCurrentID(ByVal modulo As Integer)
            If Not Increasing Then
                CurrentID = [mod](Min() + 1, modulo)
            Else
                CurrentID = Min()
            End If
        End Sub
        Public Sub New(ByVal Increasing As Boolean, ByVal from As Integer, ByVal [to] As Integer)
            Me.Increasing = Increasing
            Me.from = from
            Me.[to] = [to]
        End Sub
        Public Function Min() As Integer
            If Increasing Then
                Return from
            End If
            Return [to]
        End Function
        Public Function MinY(ByVal Pts As iPoint()) As Integer
            Return Pts(Min()).y
        End Function
        Public Function MaxY(ByVal Pts As iPoint()) As Integer
            Return Pts(Max()).y
        End Function
        Public Function Max() As Integer
            If Not Increasing Then
                Return from
            End If
            Return [to]
        End Function
    End Class


    ' ===================================================================================================
    '  STAGE 1
    ' ===================================================================================================

    ' --------------------------------------------------------------------------------------------
    ' Searches a x and a y such that source[x,y] = true and source[x+1,y] false.
    ' If this not exists, false will be returned else the result is true. 
    ' --------------------------------------------------------------------------------------------
    ' "source" Is a Binary Matrix, which is produced by BitMapToBinary
    ' "x" = x index in the source Matrix
    ' "y" = y index in the source Matrix
    ' --------------------------------------------------------------------------------------------
    Private Function FindNext(ByVal Matrix As Boolean(,), ByRef x As Integer, ByRef y As Integer) As Boolean
        For y = 1 To Matrix.GetLength(1) - 2
            For x = 0 To Matrix.GetLength(0) - 2
                If Not Matrix(x + 1, y) Then
                    ' black found
                    Return True
                End If
            Next
        Next
        x = -1
        Return False
    End Function

    ' --------------------------------------------------------------------------------------------
    ' Searches a x and a y inside the Path P such that source[x,y] = true and source[x+1,y] false.
    ' If this not exists, false will be returned else the result is true. 
    ' --------------------------------------------------------------------------------------------
    ' "source" Is a Binary Matrix, which is produced by BitMapToBinary
    ' "x" = x index in the source Matrix
    ' "y" = y index in the source Matrix
    ' --------------------------------------------------------------------------------------------
    Private Function FindNext(ByVal Matrix As Boolean(,), ByRef x As Integer, ByRef y As Integer, ByVal P As Path) As Boolean
        Dim i As Integer = 0
        Dim n As Integer = P.pt.Length
        Dim MonotonIntervals As ArrayList = P.MonotonIntervals
        If MonotonIntervals.Count = 0 Then
            Return False
        End If
        Dim MI As MonotonInterval = DirectCast(MonotonIntervals(0), MonotonInterval)
        MI.ResetCurrentID(n)
        y = P.pt(MI.CurrentID).y
        Dim CurrentIntervals As ArrayList = New ArrayList()
        CurrentIntervals.Add(MI)
        MI.CurrentID = MI.Min()

        While (i + 1 < MonotonIntervals.Count) AndAlso (DirectCast(MonotonIntervals(i + 1), MonotonInterval).MinY(P.pt) = y)
            MI = DirectCast(MonotonIntervals(i + 1), MonotonInterval)
            MI.ResetCurrentID(n)
            CurrentIntervals.Add(MI)
            i += 1
        End While

        While CurrentIntervals.Count > 0
            For k As Integer = 0 To CurrentIntervals.Count - 2
                Dim x1 As Integer = P.pt(DirectCast(CurrentIntervals(k), MonotonInterval).CurrentID).x + 1
                Dim x2 As Integer = P.pt(DirectCast(CurrentIntervals(k + 1), MonotonInterval).CurrentID).x

                For x = x1 To x2
                    If Not Matrix(x, y) Then
                        x -= 1
                        Return True
                    End If
                Next
                k += 1
            Next

            y += 1
            For j As Integer = CurrentIntervals.Count - 1 To 0 Step -1

                Dim M As MonotonInterval = DirectCast(CurrentIntervals(j), MonotonInterval)

                If y > M.MaxY(P.pt) Then
                    CurrentIntervals.RemoveAt(j)
                    Continue For
                End If
                Dim CID As Integer = M.CurrentID
                Do
                    If M.Increasing Then
                        CID = [mod](CID + 1, n)
                    Else
                        CID = [mod](CID - 1, n)
                    End If
                Loop While P.pt(CID).y < y
                M.CurrentID = CID
            Next
            ' Add Items of MonotonIntervals with Miny==y
            While (i + 1 < MonotonIntervals.Count) AndAlso (DirectCast(MonotonIntervals(i + 1), MonotonInterval).MinY(P.pt) = y)
                Dim NewInt As MonotonInterval = DirectCast(MonotonIntervals(i + 1), MonotonInterval)
                Dim j As Integer = 0
                ' search the correct x-Position
                Dim _x As Integer = P.pt(NewInt.Min()).x
                While (j < CurrentIntervals.Count) AndAlso (_x > P.pt(DirectCast(CurrentIntervals(j), MonotonInterval).CurrentID).x)
                    j += 1
                End While
                CurrentIntervals.Insert(j, NewInt)
                NewInt.ResetCurrentID(n)
                i += 1
            End While
        End While
        Return False
    End Function

    ' -----------------------------------------------------------------------------------------------
    '  Apply quadratic form Q to vector w = (w.x,w.y) 
    ' -----------------------------------------------------------------------------------------------
    Private Function QuadraticForm(ByVal Q As Double(,), ByVal w As dPoint) As Double
        Dim v As Double() = {w.x, w.y, 1}
        Dim i As Integer, j As Integer
        Dim sum As Double = 0
        For i = 0 To 2
            For j = 0 To 2
                sum += v(i) * Q(i, j) * v(j)
            Next
        Next
        Return sum
    End Function


    ' -----------------------------------------------------------------------------------------------
    ' Compute a path in the binary matrix.
    ' Start path at the point (x0,x1), which must be an upper left corner of the path
    ' Also compute the area enclosed by the path. 
    ' Return a new path_t object, or NULL on error (note that a legitimate path cannot have length 0) 
    ' We omit turnpolicies and sign
    ' -----------------------------------------------------------------------------------------------
    Private Function FindPath(ByVal Matrix As Boolean(,), ByVal Start As iPoint) As Path
        Dim L As ArrayList = New ArrayList()
        Dim Dir As Direction = Direction.North
        Dim x As Integer
        Dim y As Integer
        Dim area As Integer = 0
        Dim diry As Integer = -1
        x = Start.x
        y = Start.y
        Do
            ' area += x * diry;
            L.Add(New iPoint(x, y))
            Dim _y As Integer = y
            FindNextTrace(Matrix, x, y, Dir)
            diry = _y - y
            area += x * diry
        Loop While (x <> Start.x) OrElse (y <> Start.y)

        If L.Count = 0 Then
            Return Nothing
        End If
        Dim result As Path = New Path()
        result.pt = New iPoint(L.Count - 1) {}
        result.area = area

        For i As Integer = 0 To L.Count - 1
            result.pt(i) = CType(L(i), iPoint)
        Next

        ' ---------------------------------- Shift 1 to be compatible with the other functions
        If result.pt.Length > 0 Then
            Dim P As iPoint = result.pt(result.pt.Length - 1)
            For i As Integer = result.pt.Length - 1 To 0 Step -1
                If i > 0 Then
                    result.pt(i) = result.pt(i - 1)
                Else
                    result.pt(0) = P
                End If
            Next
        End If

        result.MonotonIntervals = GetMonotonIntervals(result.pt)

        Return result
    End Function

    Private Sub FindNextTrace(ByVal Matrix As Boolean(,), ByRef x As Integer, ByRef y As Integer, ByRef Dir As Direction)
        Select Case Dir
            Case Direction.West
                If True Then
                    If Not Matrix(x + 1, y + 1) Then
                        y += 1
                        Dir = Direction.North

                    ElseIf Not Matrix(x + 1, y) Then
                        x += 1
                        Dir = Direction.West
                    Else
                        y -= 1
                        Dir = Direction.South
                    End If
                    Exit Select
                End If
            Case Direction.South
                If True Then
                    If Not Matrix(x + 1, y) Then
                        x += 1
                        Dir = Direction.West
                    ElseIf Not Matrix(x, y) Then
                        y -= 1
                        Dir = Direction.South
                    Else
                        x -= 1
                        Dir = Direction.East
                    End If
                    Exit Select
                End If
            Case Direction.East
                If True Then
                    If Not Matrix(x, y) Then
                        y -= 1
                        Dir = Direction.South

                    ElseIf Not Matrix(x, y + 1) Then
                        x -= 1
                        Dir = Direction.East
                    Else
                        y += 1
                        Dir = Direction.North
                    End If
                    Exit Select
                End If
            Case Direction.North
                If True Then
                    If Not Matrix(x, y + 1) Then
                        x -= 1
                        Dir = Direction.East
                    ElseIf Not Matrix(x + 1, y + 1) Then
                        y += 1
                        Dir = Direction.North
                    Else
                        x += 1
                        Dir = Direction.West
                    End If
                    Exit Select
                End If
        End Select
    End Sub

    Private Function GetMonotonIntervals(ByVal Pts As iPoint()) As ArrayList
        Dim result As ArrayList = New ArrayList()
        Dim n As Integer = Pts.Length
        If n = 0 Then
            Return result
        End If
        Dim L As ArrayList = New ArrayList()

        '----- Start with Strong Monoton (Pts[i].y < Pts[i+1].y) or (Pts[i].y > Pts[i+1].y)
        Dim FirstStrongMonoton As Integer = 0
        While Pts(FirstStrongMonoton).y = Pts(FirstStrongMonoton + 1).y
            FirstStrongMonoton += 1
        End While
        Dim Up As Boolean = (Pts(FirstStrongMonoton).y < Pts(FirstStrongMonoton + 1).y)
        Dim Interval As MonotonInterval = New MonotonInterval(Up, FirstStrongMonoton, FirstStrongMonoton)
        L.Add(Interval)
        Dim i As Integer = FirstStrongMonoton
        Do
            ' Interval.to = i;
            If (Pts(i).y = Pts([mod](i + 1, n)).y) OrElse (Up = (Pts(i).y < Pts([mod](i + 1, n)).y)) Then
                Interval.[to] = i
            Else
                Up = (Pts(i).y < Pts([mod](i + 1, n)).y)
                Interval = New MonotonInterval(Up, i, i)
                L.Add(Interval)
            End If
            i = [mod](i + 1, n)
        Loop While i <> FirstStrongMonoton

        If (L.Count \ 2) * 2 <> L.Count Then
            ' Connect the Last with first 
            Dim M0 As MonotonInterval = DirectCast(L(0), MonotonInterval)
            Dim ML As MonotonInterval = DirectCast(L(L.Count - 1), MonotonInterval)
            M0.from = ML.from
            L.RemoveAt(L.Count - 1)
        End If

        '----- order now by the min y - value of interval to result 
        ' and as second Key by the x-value
        '
        While L.Count > 0
            Dim M As MonotonInterval = DirectCast(L(0), MonotonInterval)
            i = 0
            ' order by y-value
            While (i < result.Count) AndAlso (Pts(M.Min()).y > Pts(DirectCast(result(i), MonotonInterval).Min()).y)
                i += 1
            End While
            ' order by x- value as second Key
            While (i < result.Count) AndAlso (Pts(M.Min()).y = Pts(DirectCast(result(i), MonotonInterval).Min()).y) AndAlso (Pts(M.Min()).x > (Pts(DirectCast(result(i), MonotonInterval).Min()).x))
                i += 1
            End While
            result.Insert(i, M)
            L.RemoveAt(0)
        End While
        Return result
    End Function

    Private Sub Xor_Path(ByVal Matrix As Boolean(,), ByVal P As Path)
        Dim i As Integer = 0
        Dim n As Integer = P.pt.Length
        Dim MonotonIntervals As ArrayList = P.MonotonIntervals
        If MonotonIntervals.Count = 0 Then
            Return
        End If
        Dim MI As MonotonInterval = DirectCast(MonotonIntervals(0), MonotonInterval)
        MI.ResetCurrentID(n)
        Dim y As Integer = P.pt(MI.CurrentID).y
        Dim CurrentIntervals As ArrayList = New ArrayList()
        CurrentIntervals.Add(MI)
        MI.CurrentID = MI.Min()

        While (i + 1 < MonotonIntervals.Count) AndAlso (DirectCast(MonotonIntervals(i + 1), MonotonInterval).MinY(P.pt) = y)
            MI = DirectCast(MonotonIntervals(i + 1), MonotonInterval)
            MI.ResetCurrentID(n)
            CurrentIntervals.Add(MI)
            i += 1
        End While

        While CurrentIntervals.Count > 0
            ' invertLine
            For k As Integer = 0 To CurrentIntervals.Count - 2
                Dim x1 As Integer = P.pt(DirectCast(CurrentIntervals(k), MonotonInterval).CurrentID).x + 1
                Dim x2 As Integer = P.pt(DirectCast(CurrentIntervals(k + 1), MonotonInterval).CurrentID).x
                For x As Integer = x1 To x2
                    Matrix(x, y) = Not Matrix(x, y)
                Next
                k += 1
            Next

            y += 1
            For j As Integer = CurrentIntervals.Count - 1 To 0 Step -1

                Dim M As MonotonInterval = DirectCast(CurrentIntervals(j), MonotonInterval)

                If y > M.MaxY(P.pt) Then
                    CurrentIntervals.RemoveAt(j)
                    Continue For
                End If
                Dim CID As Integer = M.CurrentID
                Do
                    If M.Increasing Then
                        CID = [mod](CID + 1, n)
                    Else
                        CID = [mod](CID - 1, n)
                    End If
                Loop While P.pt(CID).y < y
                M.CurrentID = CID
            Next
            ' Add Items of MonotonIntervals with Down.y==y
            While (i + 1 < MonotonIntervals.Count) AndAlso (DirectCast(MonotonIntervals(i + 1), MonotonInterval).MinY(P.pt) = y)
                Dim NewInt As MonotonInterval = DirectCast(MonotonIntervals(i + 1), MonotonInterval)
                Dim j As Integer = 0
                ' search the correct x-Position
                Dim _x As Integer = P.pt(NewInt.Min()).x
                While (j < CurrentIntervals.Count) AndAlso (_x > P.pt(DirectCast(CurrentIntervals(j), MonotonInterval).CurrentID).x)
                    j += 1
                End While
                CurrentIntervals.Insert(j, NewInt)
                NewInt.ResetCurrentID(n)
                i += 1
            End While
        End While
    End Sub


    ' --------------------------------------------------------------------------------------------
    '  Preparation: fill in the sum* fields of a path (used for later rapid summing)
    ' --------------------------------------------------------------------------------------------
    '  pp = Path for which the preparation will be done
    ' --------------------------------------------------------------------------------------------
    Private Sub Calc_Sums(ByVal pp As Path)
        Dim i As Integer, x As Integer, y As Integer
        Dim n As Integer = pp.pt.Length
        pp.Sums = New SumStruct(n) {}
        ' --------------------------------------------------- origin 
        Dim x0 As Integer = pp.pt(0).x
        Dim y0 As Integer = pp.pt(0).y
        ' --------------------------------------------------- preparatory computation for later fast summing
        pp.Sums(0).x = 0
        pp.Sums(0).y = 0
        pp.Sums(0).x2 = 0
        pp.Sums(0).xy = 0
        pp.Sums(0).y2 = 0
        For i = 0 To n - 1
            x = pp.pt(i).x - x0
            y = pp.pt(i).y - y0
            pp.Sums(i + 1).x = pp.Sums(i).x + x
            pp.Sums(i + 1).y = pp.Sums(i).y + y
            pp.Sums(i + 1).x2 = pp.Sums(i).x2 + x * x
            pp.Sums(i + 1).xy = pp.Sums(i).xy + x * y
            pp.Sums(i + 1).y2 = pp.Sums(i).y2 + y * y
        Next
    End Sub


    ' ===================================================================================================
    '  STAGE 2
    '  calculate the optimal polygon
    ' ===================================================================================================

    ' Penality of an edge from i to j in the given path. This needs the "lon" and "sum*" data. 
    ' ---------------------------------------------------------------------------------------------------
    Private Function Penality(ByVal pp As Path, ByVal i As Integer, ByVal j As Integer) As Double
        Dim n As Integer = pp.pt.Length
        Dim x As Double, y As Double, x2 As Double, xy As Double, y2 As Double
        Dim k As Double
        Dim a As Double, b As Double, c As Double, s As Double
        Dim px As Double, py As Double, ex As Double, ey As Double
        Dim sums As SumStruct() = pp.Sums
        Dim pt As iPoint() = pp.pt
        ' ---------------------------------------------------- assume 0 <= i < j <= n  
        Dim r As Integer = 0
        ' ---------------------------------------------------- rotations from i to j 
        If j >= n Then
            j -= n
            r += 1
        End If
        '
        x = sums(j + 1).x - sums(i).x + r * sums(n).x
        y = sums(j + 1).y - sums(i).y + r * sums(n).y
        x2 = sums(j + 1).x2 - sums(i).x2 + r * sums(n).x2
        xy = sums(j + 1).xy - sums(i).xy + r * sums(n).xy
        y2 = sums(j + 1).y2 - sums(i).y2 + r * sums(n).y2
        k = j + 1 - i + r * n
        '
        px = (pt(i).x + pt(j).x) / 2 - pt(0).x
        py = (pt(i).y + pt(j).y) / 2 - pt(0).y
        ey = (pt(j).x - pt(i).x)
        ex = -(pt(j).y - pt(i).y)
        '
        a = ((x2 - 2 * x * px) / k + px * px)
        b = ((xy - x * py - y * px) / k + px * py)
        c = ((y2 - 2 * y * py) / k + py * py)
        '
        s = ex * ex * a + 2 * ex * ey * b + ey * ey * c
        '
        Return Math.Sqrt(s)
    End Function

    Private Sub Calc_Lon(ByVal pp As Path)
        '
        Dim i As Integer, j As Integer, k As Integer, k1 As Integer
        Dim a As Integer, b As Integer, c As Integer, d As Integer
        Dim ct As Integer() = {0, 0, 0, 0}
        Dim dir As Integer
        Dim constraint(1) As iPoint
        Dim cur As iPoint
        Dim off As iPoint
        Dim dk As iPoint
        ' --------------------------------------------- direction of k-k1 
        Dim pt As iPoint() = pp.pt
        Dim n As Integer = pt.Length
        Dim Pivot(n - 1) As Integer
        Dim nc(n - 1) As Integer
        '
        ' Initialize the nc data structure. 
        ' Point from each point to the furthest future point to which it is connected by a vertical or horizontal segment. 
        ' We take advantage of the fact that there is always a direction change at 0 (due to the path decomposition) 
        ' But even if this were not so, there is no harm, as correctness does not depend on the word "furthest" above  
        '
        ' necessarily i < n-1 in this case 
        k = 0
        For i = n - 1 To 0 Step -1
            If pt(i).x <> pt(k).x AndAlso pt(i).y <> pt(k).y Then
                k = i + 1
            End If
            nc(i) = k
        Next

        ReDim pp.Lon(n - 1)

        ' determine pivot points: 
        ' for each i, let pivk[i] be the furthest k such that all j with i < j < k lie on a line connecting i,k 
        For i = n - 1 To 0 Step -1
            '
            ct(0) = 0
            ct(1) = 0
            ct(2) = 0
            ct(3) = 0
            '
            ' keep track of "directions" that have occurred 
            '
            dir = (3 + 3 * (pt([mod](i + 1, n)).x - pt(i).x) + (pt([mod](i + 1, n)).y - pt(i).y)) \ 2
            ct(dir) += 1
            '
            constraint(0).x = 0
            constraint(0).y = 0
            constraint(1).x = 0
            constraint(1).y = 0
            '
            ' find the next k such that no straight line from i to k 
            '
            k = nc(i)
            k1 = i
            '
            While True
                dir = (3 + 3 * sign(pt(k).x - pt(k1).x) + sign(pt(k).y - pt(k1).y)) \ 2
                ct(dir) += 1
                '
                ' if all four "directions" have occurred, cut this path 
                '
                If (ct(0) = 1) AndAlso (ct(1) = 1) AndAlso (ct(2) = 1) AndAlso (ct(3) = 1) Then
                    Pivot(i) = k1
                    Continue For 'GoTo foundk
                End If
                '
                cur.x = pt(k).x - pt(i).x
                cur.y = pt(k).y - pt(i).y
                '
                ' see if current constraint is violated 
                '
                If xprod(constraint(0), cur) < 0 OrElse xprod(constraint(1), cur) > 0 Then
                    Exit While ' GoTo constraint_viol
                End If
                '
                ' else, update constraint 
                '
                ' no constraint 
                '
                If abs(cur.x) <= 1 AndAlso abs(cur.y) <= 1 Then
                Else
                    off.x = cur.x + (If((cur.y >= 0 AndAlso (cur.y > 0 OrElse cur.x < 0)), 1, -1))
                    off.y = cur.y + (If((cur.x <= 0 AndAlso (cur.x < 0 OrElse cur.y < 0)), 1, -1))
                    If xprod(constraint(0), off) >= 0 Then
                        constraint(0) = off
                    End If
                    off.x = cur.x + (If((cur.y <= 0 AndAlso (cur.y < 0 OrElse cur.x < 0)), 1, -1))
                    off.y = cur.y + (If((cur.x >= 0 AndAlso (cur.x > 0 OrElse cur.y < 0)), 1, -1))
                    If xprod(constraint(1), off) <= 0 Then
                        constraint(1) = off
                    End If
                End If
                k1 = k
                k = nc(k1)
                If Not cyclic(k, i, k1) Then
                    Exit While
                End If

            End While
            ' exit from constraint_violated
            '
            ' k1 was the last "corner" satisfying the current constraint, and
            '                   k is the first one violating it. We now need to find the last
            '                   point along k1..k which satisfied the constraint. 
            '
            dk.x = sign(pt(k).x - pt(k1).x)
            dk.y = sign(pt(k).y - pt(k1).y)
            cur.x = pt(k1).x - pt(i).x
            cur.y = pt(k1).y - pt(i).y
            '
            ' find largest integer j such that xprod(constraint[0], cur+j*dk)
            '                   >= 0 and xprod(constraint[1], cur+j*dk) <= 0. Use bilinearity
            '                   of xprod. 
            '
            a = xprod(constraint(0), cur)
            b = xprod(constraint(0), dk)
            c = xprod(constraint(1), cur)
            d = xprod(constraint(1), dk)
            '
            ' find largest integer j such that a+j*b>=0 and c+j*d<=0. This
            '                   can be solved with integer arithmetic. 
            '
            j = Integer.MaxValue
            If b < 0 Then
                j = floordiv(a, -b)
            End If
            If d > 0 Then
                j = min(j, floordiv(-c, d))
            End If
            Pivot(i) = [mod](k1 + j, n)
        Next
        '
        ' clean up: for each i, let lon[i] be the largest k such that for
        '               all i' with i<=i'<k, i'<k<=pivk[i']. 
        '
        j = Pivot(n - 1)
        pp.Lon(n - 1) = j
        '
        For i = n - 2 To 0 Step -1
            If cyclic(i + 1, Pivot(i), j) Then
                j = Pivot(i)
            End If

            pp.Lon(i) = j
        Next
        '
        i = n - 1
        While cyclic([mod](i + 1, n), j, pp.Lon(i))
            pp.Lon(i) = j
            i -= 1
        End While

    End Sub



    ' find the optimal polygon. Fill in the m and po components. Return 1
    '            on failure with errno set, else 0. Non-cyclic version: assumes i=0
    '            is in the polygon. Fixme: ### implement cyclic version. 

    Private Sub BestPolygon(ByVal pp As Path)
        Dim i As Integer, j As Integer, m As Integer, k As Integer
        Dim n As Integer = pp.pt.Length
        Dim pen(n) As Double    ' pen[n+1]: penalty vector 
        Dim prev(n) As Integer  ' prev[n+1]: best path pointer vector 
        Dim clip0(n) As Integer ' clip0[n]: longest segment pointer, non-cyclic 
        Dim clip1(n) As Integer ' clip1[n+1]: backwards segment pointer, non-cyclic 
        Dim seg0(n) As Integer  ' seg0[m+1]: forward segment bounds, m<=n 
        Dim seg1(n) As Integer  ' seg1[m+1]: backward segment bounds, m<=n 
        '
        Dim thispen As Double
        Dim best As Double
        Dim c As Integer
        ' -------------------------------------------------- calculate clipped paths 
        For i = 0 To n - 1
            c = [mod](pp.Lon([mod](i - 1, n)) - 1, n)

            If c = i Then
                c = [mod](i + 1, n)
            End If
            If c < i Then
                clip0(i) = n
            Else
                clip0(i) = c
            End If
        Next
        ' ------------------------------------------ calculate backwards path clipping, 
        '                                                       non-cyclic. j <= clip0[i] iff
        '                                                       clip1[j] <= i, for i,j=0..n. 
        j = 1
        For i = 0 To n - 1
            While j <= clip0(i)
                clip1(j) = i
                j += 1
            End While
        Next
        ' ----------------------------------------- calculate seg0[j] = longest path from 0 with j segments 
        i = 0
        j = 0
        While i < n
            seg0(j) = i
            i = clip0(i)
            j += 1
        End While
        seg0(j) = n
        m = j
        ' ----------------------------------------- calculate seg1[j] = longest path to n with m-j segments 

        i = n
        For j = m To 1 Step -1
            seg1(j) = i
            i = clip1(i)
        Next
        seg1(0) = 0

        ' ----------------------------------------- now find the shortest path with m segments, based on penalty3 
        '
        ' note: the outer 2 loops jointly have at most n interations, thus
        '            the worst-case behavior here is quadratic. In practice, it is
        '            close to linear since the inner loop tends to be short. 
        '
        pen(0) = 0
        For j = 1 To m
            For i = seg1(j) To seg0(j)
                best = -1
                For k = seg0(j - 1) To clip1(i) Step -1
                    thispen = Penality(pp, k, i) + pen(k)
                    If best < 0 OrElse thispen < best Then
                        prev(i) = k
                        best = thispen
                    End If
                Next
                pen(i) = best
            Next
        Next
        ' ------------------------------------------- read off shortest path 
        Dim B(m - 1) As Integer
        ReDim pp.po(m - 1)
        i = n
        j = m - 1
        While i > 0
            i = prev(i)
            B(j) = i
            j -= 1
        End While
        '
        '   if ((m > 0) && ( mod(pp.Lon[m - 1]-1,n)<= B[1]))
        '   {// reduce
        '       B[0] = B[m - 1];
        '       pp.po = new int[m - 1];
        '       for (i = 0; i < m - 1; i++)
        '           pp.po[i] = B[i];
        '   }
        '   else
        '             
        '
        pp.po = B
    End Sub


    ' ===================================================================================================
    '  STAGE 3
    '  vertex adjustment 
    ' ===================================================================================================

    ' Adjust vertices of optimal polygon: calculate the intersection of
    '           the two "optimal" line segments, then move it into the unit square
    '           if it lies outside. Return 1 with errno set on error; 0 on
    '           success. 

    ' calculate "optimal" point-slope representation for each line
    '     segment 

    Private Sub Adjust_Vertices(ByVal pp As Path)
        Dim m As Integer = pp.po.Length
        Dim po As Integer() = pp.po
        Dim pt As iPoint() = pp.pt
        Dim n As Integer = pt.Length
        '
        Dim x0 As Integer = pt(0).x
        Dim y0 As Integer = pt(0).y
        '
        Dim ctr(m - 1) As dPoint            ' ctr[m] 
        Dim dir(m - 1) As dPoint            ' dir[m] 
        Dim q__1(m - 1, 2, 2) As Double     ' quadform_t *q = NULL  ( q[m] )
        Dim v(2) As Double
        Dim d As Double
        Dim i As Integer, j As Integer, k As Integer, l As Integer
        Dim s As dPoint
        pp.Curves = New privcurve(m)
        ' ---------------------------------- calculate "optimal" point-slope representation for each line segment 
        For i = 0 To m - 1
            j = po([mod](i + 1, m))
            j = [mod](j - po(i), n) + po(i)
            pointslope(pp, po(i), j, ctr(i), dir(i))
        Next
        '
        ' represent each line segment as a singular quadratic form; the
        '                 distance of a point (x,y) from the line segment will be
        '                 (x,y,1)Q(x,y,1)^t, where Q=q[i]. 
        '
        For i = 0 To m - 1
            d = dir(i).x * dir(i).x + dir(i).y * dir(i).y

            If d = 0 Then
                For j = 0 To 2
                    For k = 0 To 2
                        q__1(i, j, k) = 0
                    Next
                Next
            Else
                v(0) = dir(i).y
                v(1) = -dir(i).x
                v(2) = -v(1) * ctr(i).y - v(0) * ctr(i).x
                For l = 0 To 2
                    For k = 0 To 2
                        q__1(i, l, k) = v(l) * v(k) / d
                    Next
                Next
            End If
        Next
        '
        ' now calculate the "intersections" of consecutive segments.
        '               Instead of using the actual intersection, we find the point
        '               within a given unit square which minimizes the square distance to
        '               the two lines. 
        '
        For i = 0 To m - 1
            Dim Q__2(2, 2) As Double
            Dim w As dPoint
            Dim dx As Double, dy As Double
            Dim det As Double
            Dim min As Double, cand As Double  ' minimum and candidate for minimum of quad. form 
            Dim xmin As Double, ymin As Double ' coordinates of minimum 
            Dim z As Integer
            ' ------------------------------------ let s be the vertex, in coordinates relative to x0/y0 
            s.x = pt(po(i)).x - x0
            s.y = pt(po(i)).y - y0
            ' ------------------------------------ intersect segments i-1 and i 
            j = [mod](i - 1, m)
            ' ------------------------------------ add quadratic forms 
            For l = 0 To 2
                For k = 0 To 2
                    Q__2(l, k) = q__1(j, l, k) + q__1(i, l, k)
                Next
            Next
            While True
                ' -------------------------------- minimize the quadratic form Q on the unit square 
                ' find intersection 
                det = Q__2(0, 0) * Q__2(1, 1) - Q__2(0, 1) * Q__2(1, 0)
                If det <> 0 Then
                    w.x = (-Q__2(0, 2) * Q__2(1, 1) + Q__2(1, 2) * Q__2(0, 1)) / det
                    w.y = (Q__2(0, 2) * Q__2(1, 0) - Q__2(1, 2) * Q__2(0, 0)) / det
                    Exit While
                End If
                '
                ' matrix is singular - lines are parallel. 
                ' Add another orthogonal axis, through the center of the unit square 
                '
                If Q__2(0, 0) > Q__2(1, 1) Then
                    v(0) = -Q__2(0, 1)
                    v(1) = Q__2(0, 0)
                ElseIf Q__2(1, 1) <> 0 Then
                    ' nur if (Q[1,1])
                    v(0) = -Q__2(1, 1)
                    v(1) = Q__2(1, 0)
                Else
                    v(0) = 1
                    v(1) = 0
                End If
                d = v(0) * v(0) + v(1) * v(1)
                v(2) = -v(1) * s.y - v(0) * s.x
                For l = 0 To 2
                    For k = 0 To 2
                        Q__2(l, k) += v(l) * v(k) / d
                    Next
                Next
            End While
            dx = Math.Abs(w.x - s.x)
            dy = Math.Abs(w.y - s.y)
            If dx <= 0.5 AndAlso dy <= 0.5 Then
                ' - 1 because we have a additional border set to the bitmap
                pp.Curves.vertex(i).x = w.x + x0
                pp.Curves.vertex(i).y = w.y + y0
                Continue For
            End If
            '
            ' the minimum was not in the unit square; now minimize quadratic
            '                   on boundary of square 
            '
            min = QuadraticForm(Q__2, s)
            xmin = s.x
            ymin = s.y
            ' -------------------------------------------- 
            If Q__2(0, 0) <> 0 Then
                For z = 0 To 1
                    ' value of the y-coordinate 
                    w.y = s.y - 0.5 + z
                    w.x = -(Q__2(0, 1) * w.y + Q__2(0, 2)) / Q__2(0, 0)
                    dx = Math.Abs(w.x - s.x)
                    cand = QuadraticForm(Q__2, w)
                    If dx <= 0.5 AndAlso cand < min Then
                        min = cand
                        xmin = w.x
                        ymin = w.y
                    End If
                Next
            End If
            ' -------------------------------------------- 
            If Q__2(1, 1) <> 0 Then
                For z = 0 To 1
                    ' value of the x-coordinate 
                    w.x = s.x - 0.5 + z
                    w.y = -(Q__2(1, 0) * w.x + Q__2(1, 2)) / Q__2(1, 1)
                    dy = Math.Abs(w.y - s.y)
                    cand = QuadraticForm(Q__2, w)
                    If dy <= 0.5 AndAlso cand < min Then
                        min = cand
                        xmin = w.x
                        ymin = w.y
                    End If
                Next
            End If
            ' -------------------------------------------- check four corners 
            For l = 0 To 1
                For k = 0 To 1
                    w.x = s.x - 0.5 + l
                    w.y = s.y - 0.5 + k
                    cand = QuadraticForm(Q__2, w)
                    If cand < min Then
                        min = cand
                        xmin = w.x
                        ymin = w.y
                    End If
                Next
            Next
            ' -------------------------------------------- "-1" because we have a additional border set to the bitmap
            pp.Curves.vertex(i).x = xmin + x0 - 1
            pp.Curves.vertex(i).y = ymin + y0 - 1
            Continue For
        Next

    End Sub


    ' ====================================================================================================
    '  STAGE 4
    '  smoothing and corner analysis
    ' ====================================================================================================

    Private Sub SmoothCurve(ByVal curve As privcurve, ByVal sign As Integer, ByVal alphamax As Double)
        Dim m As Integer = curve.n

        Dim i As Integer, j As Integer, k As Integer
        Dim dd As Double, denom As Double, alpha As Double
        Dim p2 As dPoint, p3 As dPoint, p4 As dPoint

        ' ------------------------------- reverse orientation of negative paths 
        If sign = -1 Then
            i = 0
            j = m - 1
            While i < j
                Dim tmp As dPoint
                tmp = curve.vertex(i)
                curve.vertex(i) = curve.vertex(j)
                curve.vertex(j) = tmp
                i += 1
                j -= 1
            End While
        End If
        ' ------------------------------- examine each vertex and find its best fit 
        For i = 0 To m - 1
            j = [mod](i + 1, m)
            k = [mod](i + 2, m)
            p4 = interval(1 / 2, curve.vertex(k), curve.vertex(j))

            denom = ddenom(curve.vertex(i), curve.vertex(k))
            If denom <> 0 Then
                dd = dpara(curve.vertex(i), curve.vertex(j), curve.vertex(k)) / denom
                dd = Math.Abs(dd)
                alpha = If(dd > 1, (1 - 1 / dd), 0)
                alpha = alpha / 0.75
            Else
                alpha = 4 / 3
            End If
            curve.alpha0(j) = alpha
            ' ----------------------------------- remember "original" value of alpha 
            If alpha > alphamax Then
                ' pointed corner 
                curve.tag(j) = CORNER
                'curve.c[j][1] = curve->vertex[j];
                curve.ControlPoints(j, 1) = curve.vertex(j)
                curve.ControlPoints(j, 2) = p4
            Else
                If alpha < 0.55 Then
                    alpha = 0.55
                ElseIf alpha > 1 Then
                    alpha = 1
                End If
                p2 = interval(0.5 + 0.5 * alpha, curve.vertex(i), curve.vertex(j))
                p3 = interval(0.5 + 0.5 * alpha, curve.vertex(k), curve.vertex(j))
                curve.tag(j) = CURVETO
                curve.ControlPoints(j, 0) = p2
                curve.ControlPoints(j, 1) = p3
                curve.ControlPoints(j, 2) = p4
            End If
            curve.alpha(j) = alpha
            ' ------------------------------------ store the "cropped" value of alpha 
            curve.beta(j) = 0.5
        Next
    End Sub



    ' ====================================================================================================
    '  STAGE 5
    '  Curve optimization
    ' ====================================================================================================

    ' ------------------------------------ a private type for the result of opti_penalty 
    Private Structure opti
        Public pen As Double            ' penalty 
        Public c As dPoint()            ' curve parameters 
        Public t As Double, s As Double ' curve parameters 
        Public alpha As Double          ' curve parameter 
    End Structure

    ' --------------------------------------------------------------------------------------------------
    ' calculate best fit from i+.5 to j+.5.  Assume i<j (cyclically).
    '           Return 0 and set badness and parameters (alpha, beta), if
    '           possible. Return 1 if impossible. 
    ' --------------------------------------------------------------------------------------------------
    Private Function OptimizePenality(ByVal pp As Path, ByVal i As Integer, _
                                      ByVal j As Integer, ByRef res As opti, _
                                      ByVal opttolerance As Double, ByVal convc As Integer(), _
                                      ByVal areac As Double()) As Boolean
        Dim m As Integer = pp.Curves.n
        Dim k As Integer, k1 As Integer, k2 As Integer, conv As Integer, i1 As Integer
        Dim area As Double, alpha As Double, d As Double, d1 As Double, d2 As Double
        Dim p0 As dPoint, p1 As dPoint, p2 As dPoint, p3 As dPoint, pt As dPoint
        Dim A As Double, R As Double, A1 As Double, A2 As Double, A3 As Double, A4 As Double
        Dim s As Double, t As Double

        ' -------------------------------- check convexity, corner-freeness, and maximum bend < 179 degrees 
        If i = j Then
            ' sanity - a full loop can never be an opticurve 
            Return True
        End If

        k = i
        i1 = [mod](i + 1, m)
        k1 = [mod](k + 1, m)
        conv = convc(k1)
        If conv = 0 Then
            Return True
        End If
        d = ddist(pp.Curves.vertex(i), pp.Curves.vertex(i1))
        k = k1
        While k <> j
            k1 = [mod](k + 1, m)
            k2 = [mod](k + 2, m)
            If convc(k1) <> conv Then
                Return True
            End If
            If sign(cprod(pp.Curves.vertex(i), _
                          pp.Curves.vertex(i1), _
                          pp.Curves.vertex(k1), _
                          pp.Curves.vertex(k2))) <> conv Then
                Return True
            End If
            If iprod1(pp.Curves.vertex(i), _
                      pp.Curves.vertex(i1), _
                      pp.Curves.vertex(k1), _
                      pp.Curves.vertex(k2)) < d * ddist(pp.Curves.vertex(k1), pp.Curves.vertex(k2)) * COS179 Then
                Return True
            End If
            k = k1
        End While
        ' ------------------------------------------------- the curve we're working in: 
        p0 = pp.Curves.ControlPoints([mod](i, m), 2)
        p1 = pp.Curves.vertex([mod](i + 1, m))
        p2 = pp.Curves.vertex([mod](j, m))
        p3 = pp.Curves.ControlPoints([mod](j, m), 2)
        ' ------------------------------------------------- determine its area 
        area = areac(j) - areac(i)
        area -= dpara(pp.Curves.vertex(0), pp.Curves.ControlPoints(i, 2), pp.Curves.ControlPoints(j, 2)) / 2
        If i >= j Then
            area += areac(m)
        End If
        '
        ' find intersection o of p0p1 and p2p3. Let t,s such that o =
        '               interval(t,p0,p1) = interval(s,p3,p2). Let A be the area of the
        '               triangle (p0,o,p3). 
        '
        A1 = dpara(p0, p1, p2)
        A2 = dpara(p0, p1, p3)
        A3 = dpara(p0, p2, p3)
        ' A4 = dpara(p1, p2, p3); 
        '
        A4 = A1 + A3 - A2
        ' ----------------------------------- this should never happen 
        If A2 = A1 Then
            Return True
        End If
        '
        t = A3 / (A3 - A4)
        s = A2 / (A2 - A1)
        A = A2 * t / 2
        ' ----------------------------------- this should never happen 
        If A = 0 Then
            Return True
        End If
        ' ----------------------------------- relative area 
        R = area / A
        ' ----------------------------------- overall alpha for p0-o-p3 curve 
        alpha = 2 - Math.Sqrt(4 - R / 0.3)
        '
        res.c = New dPoint(1) {}
        res.c(0) = interval(t * alpha, p0, p1)
        res.c(1) = interval(s * alpha, p3, p2)
        res.alpha = alpha
        res.t = t
        res.s = s
        '
        p1 = res.c(0)
        p2 = res.c(1)
        ' ----------------------------------- the proposed curve is now (p0,p1,p2,p3) 
        res.pen = 0
        ' ----------------------------------- calculate penalty 
        ' ----------------------------------- check tangency with edges 
        k = [mod](i + 1, m)
        While k <> j
            k1 = [mod](k + 1, m)
            t = tangent(p0, p1, p2, p3, pp.Curves.vertex(k), pp.Curves.vertex(k1))
            If t < -0.5 Then
                Return True
            End If
            pt = bezier(t, p0, p1, p2, p3)
            d = ddist(pp.Curves.vertex(k), pp.Curves.vertex(k1))
            ' ----------------------------------- this should never happen 
            If d = 0 Then
                Return True
            End If
            d1 = dpara(pp.Curves.vertex(k), pp.Curves.vertex(k1), pt) / d
            If Math.Abs(d1) > opttolerance Then
                Return True
            End If
            If iprod(pp.Curves.vertex(k), pp.Curves.vertex(k1), pt) < 0 OrElse _
               iprod(pp.Curves.vertex(k1), pp.Curves.vertex(k), pt) < 0 Then
                Return True
            End If
            res.pen += d1 * d1
            k = k1
        End While
        ' --------------------------------------- check corners 
        k = i
        While k <> j
            k1 = [mod](k + 1, m)
            t = tangent(p0, p1, p2, p3, pp.Curves.ControlPoints(k, 2), pp.Curves.ControlPoints(k1, 2))
            If t < -0.5 Then
                Return True
            End If
            pt = bezier(t, p0, p1, p2, p3)
            d = ddist(pp.Curves.ControlPoints(k, 2), pp.Curves.ControlPoints(k1, 2))
            ' ----------------------------------- this should never happen 
            If d = 0 Then
                Return True
            End If
            d1 = dpara(pp.Curves.ControlPoints(k, 2), pp.Curves.ControlPoints(k1, 2), pt) / d
            d2 = dpara(pp.Curves.ControlPoints(k, 2), pp.Curves.ControlPoints(k1, 2), pp.Curves.vertex(k1)) / d
            d2 *= 0.75 * pp.Curves.alpha(k1)
            If d2 < 0 Then
                d1 = -d1
                d2 = -d2
            End If
            If d1 < d2 - opttolerance Then
                Return True
            End If
            If d1 < d2 Then
                res.pen += (d1 - d2) * (d1 - d2)
            End If
            k = k1
        End While
        '
        Return False
    End Function


    ' -------------------------------------------------------------------------------------------------
    '  Optimize the path p, replacing sequences of Bezier segments by a single segment when possible
    '  Return 0 on success, 1 with errno set on failure. 
    ' -------------------------------------------------------------------------------------------------
    Private Sub OptimizeCurve(ByVal pp As Path, ByVal opttolerance As Double)
        '
        Dim m As Integer = pp.Curves.n
        Dim pt(m) As Integer        ' pt[m+1] 
        Dim pen(m) As Double        ' pen[m+1] 
        Dim len(m) As Integer       ' len[m+1] 
        Dim opt(m) As opti          ' opt[m+1] 
        Dim convc(m - 1) As Integer ' conv[m]: pre-computed convexities 
        Dim areac(m) As Double      ' cumarea[m+1]: cache for fast area computation 
        '
        Dim om As Integer
        Dim i As Integer, j As Integer
        Dim r As Boolean
        Dim o As opti = New opti()
        Dim p0 As dPoint
        Dim i1 As Integer
        Dim area As Double
        Dim alpha As Double
        Dim s As Double()
        Dim t As Double()
        ' -------------------------------------- pre-calculate convexity: +1 = right turn, -1 = left turn, 0 = corner 
        For i = 0 To m - 1
            If pp.Curves.tag(i) = CURVETO Then
                convc(i) = sign(dpara(pp.Curves.vertex([mod](i - 1, m)), _
                                      pp.Curves.vertex(i), _
                                      pp.Curves.vertex([mod](i + 1, m))))
            Else
                convc(i) = 0
            End If
        Next
        ' -------------------------------------- pre-calculate areas 
        area = 0
        areac(0) = 0
        p0 = pp.Curves.vertex(0)
        For i = 0 To m - 1
            i1 = [mod](i + 1, m)
            If pp.Curves.tag(i1) = CURVETO Then
                alpha = pp.Curves.alpha(i1)
                area += 0.3 * alpha * (4 - alpha) * dpara(pp.Curves.ControlPoints(i, 2), _
                                                          pp.Curves.vertex(i1), _
                                                          pp.Curves.ControlPoints(i1, 2)) / 2
                area += dpara(p0, _
                              pp.Curves.ControlPoints(i, 2), _
                              pp.Curves.ControlPoints(i1, 2)) / 2
            End If
            areac(i + 1) = area
        Next
        '
        pt(0) = -1
        pen(0) = 0
        len(0) = 0
        '
        ' Fixme: we always start from a fixed point -- should find the best curve cyclically ### 
        '
        ' ----------------------------------------- calculate best path from 0 to j 
        For j = 1 To m
            '
            pt(j) = j - 1
            pen(j) = pen(j - 1)
            len(j) = len(j - 1) + 1
            '
            For i = j - 2 To 0 Step -1
                r = OptimizePenality(pp, i, [mod](j, m), o, opttolerance, convc, _
                 areac)
                If r Then
                    Exit For
                End If
                If len(j) > len(i) + 1 OrElse (len(j) = len(i) + 1 AndAlso pen(j) > pen(i) + o.pen) Then
                    pt(j) = i
                    pen(j) = pen(i) + o.pen
                    len(j) = len(i) + 1
                    opt(j) = o
                End If
            Next
        Next
        om = len(m)
        pp.OptimizedCurves = New privcurve(om)
        '
        ReDim s(om - 1)
        ReDim t(om - 1)
        '
        j = m
        For i = om - 1 To 0 Step -1
            If pt(j) = j - 1 Then
                pp.OptimizedCurves.tag(i) = pp.Curves.tag([mod](j, m))
                pp.OptimizedCurves.ControlPoints(i, 0) = pp.Curves.ControlPoints([mod](j, m), 0)
                pp.OptimizedCurves.ControlPoints(i, 1) = pp.Curves.ControlPoints([mod](j, m), 1)
                pp.OptimizedCurves.ControlPoints(i, 2) = pp.Curves.ControlPoints([mod](j, m), 2)
                pp.OptimizedCurves.vertex(i) = pp.Curves.vertex([mod](j, m))
                pp.OptimizedCurves.alpha(i) = pp.Curves.alpha([mod](j, m))
                pp.OptimizedCurves.alpha0(i) = pp.Curves.alpha0([mod](j, m))
                pp.OptimizedCurves.beta(i) = pp.Curves.beta([mod](j, m))
                s(i) = 1
                t(i) = 1
            Else
                pp.OptimizedCurves.tag(i) = CURVETO
                pp.OptimizedCurves.ControlPoints(i, 0) = opt(j).c(0)
                pp.OptimizedCurves.ControlPoints(i, 1) = opt(j).c(1)
                pp.OptimizedCurves.ControlPoints(i, 2) = pp.Curves.ControlPoints([mod](j, m), 2)
                pp.OptimizedCurves.vertex(i) = interval(opt(j).s, _
                                                        pp.Curves.ControlPoints([mod](j, m), 2), _
                                                        pp.Curves.vertex([mod](j, m)))
                pp.OptimizedCurves.alpha(i) = opt(j).alpha
                pp.OptimizedCurves.alpha0(i) = opt(j).alpha
                s(i) = opt(j).s
                t(i) = opt(j).t
            End If
            j = pt(j)
        Next
        ' ----------------------------------------------- calculate beta parameters 
        For i = 0 To om - 1
            i1 = [mod](i + 1, om)
            pp.OptimizedCurves.beta(i) = s(i) / (s(i) + t(i1))
        Next
    End Sub



    Private Sub GetContour(ByVal bm As Boolean(,), _
                           ByVal x As Integer, _
                           ByVal y As Integer, _
                           ByVal PathList As ArrayList)
        '
        Form1.ProgressBar1.Value = CInt(100 * y / bm.GetUpperBound(1))
        '
        Dim Contour As Path = FindPath(bm, New iPoint(x, y))
        '
        Xor_Path(bm, Contour)
        Dim PolyPath As ArrayList = New ArrayList()
        ' ------------------------------------------- only area > turdsize is taken
        If Contour.area > AreaMin Then
            PathList.Add(PolyPath)
            ' --------------------------------------- Path with index 0 is a contour
            PolyPath.Add(Contour)
        End If
        '
        While FindNext(bm, x, y, Contour)
            Dim Hole As Path = FindPath(bm, New iPoint(x, y))
            ' -------------------------------------- Path Hole = findpath(bm, x, y);
            Xor_Path(bm, Hole)
            If Hole.area > AreaMin Then
                PolyPath.Add(Hole)
            End If
            ' -------------------------------------- Path with index > 0 is a hole,
            If FindNext(bm, x, y, Hole) Then
                GetContour(bm, x, y, PathList)
            End If
        End While
    End Sub


    Private Sub AddCurve(ByVal Curves As ArrayList, _
                         ByVal A As dPoint, _
                         ByVal ControlPointA As dPoint, _
                         ByVal ControlPointB As dPoint, _
                         ByVal B As dPoint)
        '
        '
        ' Curves.Add(new Curve(CurveKind.Bezier, A, ControlPointA, ControlPointB, B)):  return
        '
        Dim Kind As CurveKind
        If (Math.Abs(xprod(New dPoint(ControlPointA.x - A.x, _
                                      ControlPointA.y - A.y), _
                                      New dPoint(B.x - A.x, B.y - A.y))) < 0.01) AndAlso _
                                      (Math.Abs(xprod(New dPoint(ControlPointB.x - B.x, _
                                                                 ControlPointB.y - B.y), _
                                                                 New dPoint(B.x - A.x, B.y - A.y))) < 0.01) Then
            Kind = CurveKind.Line
        Else
            Kind = CurveKind.Bezier
        End If
        '
        '
        ' Curves.Add(New Curve(Kind, A, ControlPointA, ControlPointB, B)) : Return
        '
        If (Kind = CurveKind.Line) Then
            If (Curves.Count > 0) AndAlso (CType(Curves(Curves.Count - 1), Curve).Kind = CurveKind.Line) Then
                Dim C As Curve = CType(Curves(Curves.Count - 1), Curve)
                If (Math.Abs(xprod(New dPoint(C.B.x - C.A.x, C.B.y - C.A.y), _
                                   New dPoint(B.x - A.x, B.y - A.y))) < 0.01) AndAlso (iprod(C.B, C.A, B) < 0) Then
                    Curves(Curves.Count - 1) = New Curve(Kind, C.A, C.A, C.A, B)
                Else
                    Curves.Add(New Curve(CurveKind.Line, A, ControlPointA, ControlPointB, B))
                End If
            Else
                Curves.Add(New Curve(CurveKind.Line, A, ControlPointA, ControlPointB, B))
            End If
        Else
            Curves.Add(New Curve(CurveKind.Bezier, A, ControlPointA, ControlPointB, B))
        End If

    End Sub

    Private Sub PathList_to_CurveList(ByVal PathList As ArrayList, ByVal CurveList As ArrayList)
        Dim plist As ArrayList
        ' ------------------------------------------------------ call downstream function with each path 
        For j As Integer = 0 To PathList.Count - 1
            plist = DirectCast(PathList(j), ArrayList)
            Dim clist__1 As ArrayList = New ArrayList()
            CurveList.Add(clist__1)

            For i As Integer = 0 To plist.Count - 1
                Dim p As Path = DirectCast(plist(i), Path)
                Dim A As dPoint = p.Curves.ControlPoints(p.Curves.n - 1, 2)
                Dim Curves As ArrayList = New ArrayList()
                For k As Integer = 0 To p.Curves.n - 1
                    Dim C As dPoint = p.Curves.ControlPoints(k, 0)
                    Dim D As dPoint = p.Curves.ControlPoints(k, 1)
                    Dim E As dPoint = p.Curves.ControlPoints(k, 2)
                    If p.Curves.tag(k) = CORNER Then
                        AddCurve(Curves, A, A, D, D)

                        AddCurve(Curves, D, D, E, E)
                    Else
                        AddCurve(Curves, A, C, D, E)
                    End If
                    A = E
                Next
                If Curves.Count > 0 Then
                    Dim CL As Curve = CType(Curves(Curves.Count - 1), Curve)
                    Dim CF As Curve = CType(Curves(0), Curve)
                    If (CL.Kind = CurveKind.Line) _
                                    AndAlso ((CF.Kind = CurveKind.Line)) _
                                    AndAlso (iprod(CL.B, CL.A, CF.B) < 0) _
                                    AndAlso (Math.Abs(xprod(New dPoint(CF.B.x - CF.A.x, CF.B.y - CF.A.y), _
                                                            New dPoint(CL.A.x - CL.A.x, CL.B.y - CL.A.y))) < 0.01) Then
                        Curves(0) = New Curve(CurveKind.Line, CL.A, CL.A, CL.A, CF.B)
                        Curves.RemoveAt(Curves.Count - 1)
                    End If


                    Dim CList__2(Curves.Count - 1) As Curve
                    For ci As Integer = 0 To Curves.Count - 1
                        CList__2(ci) = CType(Curves(ci), Curve)
                    Next
                    clist__1.Add(CList__2)
                End If
                '---- Check Last with first
            Next
        Next
    End Sub

    ' ---------------------------------------------------------------------------------------------
    ' Decompose the given bitmap into paths. Returns a linked list 
    ' of Path objects with the fields len, pt, area filled
    ' ---------------------------------------------------------------------------------------------
    ' "bm" A binary bitmap which holds the imageinformations
    ' "plistp" List of Path objects
    ' ---------------------------------------------------------------------------------------------
    Private Sub BynaryBitmap_to_PathList(ByVal bm As Boolean(,), ByVal PathList As ArrayList)
        Dim x As Integer = 0, y As Integer = 0
        While FindNext(bm, x, y)
            GetContour(bm, x, y, PathList)
        End While
    End Sub


    Private Sub Process_PathList(ByVal PathList As ArrayList)
        Dim p As Path
        Dim plist As ArrayList
        ' ---------------------------------------------- call downstream function with each path 
        For j As Integer = 0 To PathList.Count - 1
            plist = DirectCast(PathList(j), ArrayList)
            For i As Integer = 0 To plist.Count - 1
                If True Then
                    p = DirectCast(plist(i), Path)
                    Calc_Sums(p)
                    Calc_Lon(p)
                    BestPolygon(p)
                    Adjust_Vertices(p)
                    SmoothCurve(p.Curves, 1, CornerThreshold)
                    If ErrorTolerance > 0 Then
                        OptimizeCurve(p, ErrorTolerance)
                        p.FCurves = p.OptimizedCurves
                    Else
                        p.FCurves = p.Curves
                    End If
                    p.Curves = p.FCurves
                End If
            Next
        Next
    End Sub





    ' =============================================================================================================
    '  PUBLIC FUNCTIONS
    ' =============================================================================================================

    ' ---------------------------------------------------------------------------------------------

    ' "ListOfCurveArrays" = A list in which the curveinformations will be stored 
    ' "bm" = A binary bitmap, which holds the pixelinformation about the image
    Friend Sub BynaryBitmap_ToListOfCurves(ByVal bm As Boolean(,), ByVal ListOfCurves As ArrayList)
        Dim plistp As ArrayList = New ArrayList()
        BynaryBitmap_to_PathList(bm, plistp)
        Process_PathList(plistp)
        PathList_to_CurveList(plistp, ListOfCurves)
    End Sub



    ' -------------------------------------------------------------------------------------------------------------
    ' Produces a binary Matrix with Dimensions b.Width+2 and b.Height +2, where
    ' the Border ( of width) in the Matrix is filled with 'true' -values.
    ' On this way we avoid a lot of boundsinequalities.
    ' For the threshold, we take the Maximum of (R,G,B ) of a Pixel at x,y. 
    ' If this is less then the threshold the resultMatrix at x+1, y+1 is filled with false else with true.
    ' -------------------------------------------------------------------------------------------------------------
    ' Param "b" = A Bitmap, which will be transformed to a binary Matrix
    ' Param "_treshold" = Gives a threshold ( between 1 and 254 ) for Converting
    ' Returns a binaray boolean Matrix
    ' -------------------------------------------------------------------------------------------------------------
    Friend Function Bitmap_to_BinaryBitmap(ByVal bmp As Bitmap, ByVal treshold As Integer) As Boolean(,)
        '
        ' -------------------------------------------------------------- inflated Result Array
        Dim Result(bmp.Width + 1, bmp.Height + 1) As Boolean

        'Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()
        '
        ' -------------------------------------------------------------- Fill inflated array
        Dim H As Integer = bmp.Height
        Dim W As Integer = bmp.Width
        Dim SourceData As BitmapData = bmp.LockBits(New Rectangle(0, 0, W, H), _
                                                  System.Drawing.Imaging.ImageLockMode.ReadOnly, _
                                                  System.Drawing.Imaging.PixelFormat.Format24bppRgb)
        Dim SourceStride As Integer = SourceData.Stride
        Dim SourcePtr As IntPtr = SourceData.Scan0
        Dim Ydisp As Integer = 0
        For y As Integer = 0 To H - 1
            For x As Integer = 0 To W - 1
                Dim b1 As Byte = Marshal.ReadByte(SourcePtr, x * 3 + 2 + Ydisp)
                Dim b2 As Byte = Marshal.ReadByte(SourcePtr, x * 3 + 1 + Ydisp)
                Dim b3 As Byte = Marshal.ReadByte(SourcePtr, x * 3 + 0 + Ydisp)
                If Math.Max(Math.Max(b1, b2), b3) < treshold Then
                    Result(x + 1, y + 1) = False
                Else
                    Result(x + 1, y + 1) = True
                End If
            Next
            Ydisp = Ydisp + SourceStride
        Next
        bmp.UnlockBits(SourceData)
        '
        ' -------------------------------------------------------------- Add a white Border
        For x As Integer = 0 To Result.GetLength(0) - 1
            Result(x, 0) = True
            Result(x, Result.GetLength(1) - 1) = True
        Next
        For y As Integer = 1 To Result.GetLength(1) - 2
            Result(0, y) = True
            Result(Result.GetLength(0) - 1, y) = True
        Next
        '
        Return Result
    End Function


    ' -------------------------------------------------------------------------------------------------------------
    ' Makes a Black and White Bitmap from the Data of a Binarymatrix.
    ' Value with 'true' returns a white Pixel such with 'false' a Black pixel.
    ' -------------------------------------------------------------------------------------------------------------
    ' Param "Matrix" A Binary Matrix, which have boolean values
    ' Returns a Black and white Image
    ' -------------------------------------------------------------------------------------------------------------
    Friend Function BinaryBitmap_to_Bitmap(ByVal Matrix As Boolean(,)) As Bitmap
        '
        ' -------------------------------------------------- -2 to ignore the border
        Dim W As Integer = Matrix.GetLength(0) - 2
        Dim H As Integer = Matrix.GetLength(1) - 2

        Dim OutPutImage As Bitmap = New Bitmap(W, H)
        Dim CopyData As BitmapData = OutPutImage.LockBits(New Rectangle(0, 0, OutPutImage.Width, OutPutImage.Height), _
                                                          ImageLockMode.ReadWrite, _
                                                          PixelFormat.Format24bppRgb)
        Dim stride As Integer = CopyData.Stride
        Dim DestPtr As IntPtr = CopyData.Scan0

        For i As Integer = 0 To W - 1
            For j As Integer = 0 To H - 1
                ' ------------------------------ test i+1 and j+1 to ignore the border
                If Matrix(i + 1, j + 1) Then
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride, 255)
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride + 1, 255)
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride + 2, 255)
                Else
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride, 0)
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride + 1, 0)
                    Marshal.WriteByte(DestPtr, i * 3 + j * stride + 2, 0)
                End If
            Next
        Next
        OutPutImage.UnlockBits(CopyData)

        Return OutPutImage
    End Function


End Module
