﻿Imports System.Collections
Imports System.Drawing
Imports System.Drawing.Drawing2D

Module VectorsToEmf

    Friend Sub DrawListToGraphics(ByVal g As Graphics, _
                                  ByVal Flatten As Boolean, _
                                  ByVal Fillings As Boolean, _
                                  ByVal Traces As Boolean, _
                                  ByVal Points As Boolean)

        If ListOfCurvesArray Is Nothing Then Return
        Dim gp As GraphicsPath = New GraphicsPath()
        For i As Integer = 0 To ListOfCurvesArray.Count - 1
            Dim CurveArray As ArrayList = DirectCast(ListOfCurvesArray(i), ArrayList)
            Dim Contour As GraphicsPath = Nothing
            Dim Hole As GraphicsPath = Nothing
            Dim Current As GraphicsPath = Nothing
            '
            For j As Integer = 0 To CurveArray.Count - 1
                If j = 0 Then
                    Contour = New GraphicsPath()
                    Current = Contour
                Else
                    Hole = New GraphicsPath()
                    Current = Hole
                End If
                Dim Curves As RasterToVectors.Curve() = DirectCast(CurveArray(j), RasterToVectors.Curve())

                For k As Integer = 0 To Curves.Length - 1
                    If Curves(k).Kind = RasterToVectors.CurveKind.Bezier Then
                        Current.AddBezier(CSng(Curves(k).A.x) * SizeFactor, _
                                          CSng(Curves(k).A.y) * SizeFactor, _
                                          CSng(Curves(k).ControlPointA.x) * SizeFactor, _
                                          CSng(Curves(k).ControlPointA.y) * SizeFactor, _
                                          CSng(Curves(k).ControlPointB.x) * SizeFactor, _
                                          CSng(Curves(k).ControlPointB.y) * SizeFactor, _
                                          CSng(Curves(k).B.x) * SizeFactor, _
                                          CSng(Curves(k).B.y) * SizeFactor)
                    Else
                        Current.AddLine(CSng(Curves(k).A.x) * SizeFactor, _
                                        CSng(Curves(k).A.y) * SizeFactor, _
                                        CSng(Curves(k).B.x) * SizeFactor, _
                                        CSng(Curves(k).B.y) * SizeFactor)
                    End If
                Next
                If j > 0 Then
                    Contour.AddPath(Hole, False)
                End If
            Next
            gp.AddPath(Contour, False)
        Next
        If Flatten Then
            gp.Flatten()
        End If
        If Fillings Then
            g.FillPath(Brushes.Black, gp)
        End If
        If Traces Then
            g.DrawPath(Pens.Red, gp)
        End If
        If Points Then
            DrawPoints(g)
        End If
    End Sub

    Private Sub DrawPoints(ByVal g As Graphics)
        If ListOfCurvesArray Is Nothing Then Return
        For i As Integer = 0 To ListOfCurvesArray.Count - 1
            Dim CurveArray As ArrayList = DirectCast(ListOfCurvesArray(i), ArrayList)
            For j As Integer = 0 To CurveArray.Count - 1
                Dim Curves As RasterToVectors.Curve() = DirectCast(CurveArray(j), RasterToVectors.Curve())
                For k As Integer = 0 To Curves.Length - 1
                    g.FillRectangle(Brushes.Green, _
                                    CSng(((Curves(k).A.x) * SizeFactor - 1)), _
                                    CSng(((Curves(k).A.y) * SizeFactor - 1)), _
                                    2, 2)
                Next
            Next
        Next
    End Sub


    ' --------------------------------------------------------------------------------------
    '  metafile OK but not working on PSP7
    ' --------------------------------------------------------------------------------------
    Friend Sub DrawGraphicsPathToMetafile(ByVal g As Graphics, _
                                          ByVal MetaFile As String, _
                                          ByVal Flatten As Boolean, _
                                          ByVal Fillings As Boolean, _
                                          ByVal Traces As Boolean, _
                                          ByVal Points As Boolean)
        Dim hdc As IntPtr = g.GetHdc()
        Dim myMetafile As Imaging.Metafile = New Imaging.Metafile(MetaFile, hdc)
        Dim myGraphics As Graphics = Graphics.FromImage(myMetafile)
        'myGraphics.Clear(pictureBox1.BackColor)
        ' ----------------------------------------------------------- draw
        DrawListToGraphics(myGraphics, _
                           Flatten, _
                           Fillings, _
                           Traces, _
                           Points)
        'myGraphics.FillRectangle(Brushes.White, New RectangleF(0, 0, 5, 1))
        'myGraphics.FillRectangle(Brushes.Red, New RectangleF(0.25, 0.25, 4.5, 0.5))
        ' -----------------------------------------------------------
        myGraphics.Dispose()
        myMetafile.Dispose()
        g.ReleaseHdc(hdc)
    End Sub


    ' --------------------------------------------------------------------------------------
    '  trying to generate a good metafile (working on PSP7)
    ' --------------------------------------------------------------------------------------
    'Public Structure RECT
    '    Public Left As Integer
    '    Public Top As Integer
    '    Public Right As Integer
    '    Public Bottom As Integer
    'End Structure
    'Public Declare Auto Function CreateEnhMetaFile Lib "gdi32" (ByVal hdcRef As IntPtr, ByVal lpFilename As String, ByRef lpRect As RECT, ByVal lpDescription As String) As IntPtr
    'Public Declare Auto Function CloseEnhMetaFile Lib "gdi32" (ByVal hdc As IntPtr) As IntPtr
    'Public Declare Auto Function DeleteEnhMetaFile Lib "gdi32" (ByVal hemfbitHandle As IntPtr) As Boolean

    'Private Sub DrawGraphicsPathToMetafile(ByVal g As Graphics, ByVal MetaFile As String)
    '    Dim r As RECT
    '    r.Left = 0
    '    r.Top = 0
    '    r.Right = CInt(5.5 * 2540) ' 5 inches ( in .01 millimeters )
    '    r.Bottom = CInt(8.1 * 2540) ' 1 inch ( in .01 millimeters )

    '    Dim hdcMF As IntPtr = CreateEnhMetaFile(IntPtr.Zero, MetaFile, r, "")

    '    Dim gg As Graphics = Graphics.FromHdc(hdcMF)
    '    gg.PageUnit = GraphicsUnit.Inch
    '    gg.Clear(pictureBox1.BackColor)
    '    ' ----------------------------------------------------------- draw
    '    DrawListToGraphics(gg, True) ' <<< flattened for psp7

    '    gg.FillRectangle(Brushes.White, New RectangleF(0, 0, 5, 1))
    '    gg.FillRectangle(Brushes.Red, New RectangleF(0.25, 0.25, 4.5, 0.5))

    '    gg.Dispose()
    '    Dim hemf As IntPtr = CloseEnhMetaFile(hdcMF)
    '    DeleteEnhMetaFile(hemf)

    '    Diagnostics.Process.Start("""C:\Programmi\Jasc Software Inc\Paint Shop Pro 7\psp.exe""", """" & MetaFile & """")
    'End Sub

End Module
