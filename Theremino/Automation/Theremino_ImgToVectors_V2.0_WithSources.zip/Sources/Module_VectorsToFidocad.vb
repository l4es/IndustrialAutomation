﻿Imports System.Collections
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Diagnostics

Module VectorsToFidocad


    Friend Sub DrawListToFidocadFile(ByVal FileName As String, _
                                     ByVal Fillings As Boolean, _
                                     ByVal Traces As Boolean, _
                                     ByVal Points As Boolean)
        If Fillings Then
            DrawListToFidocadFile_Filled(FileName)
        Else
            DrawListToFidocadFile_Bezier(FileName)
        End If
    End Sub

    ' =============================================================================================
    '  Without fillings
    '  All the Bezier curves separated
    '  No regions
    '  Thick Fidocad lines (2 pixels) to make appear the double region lines as a single line
    ' =============================================================================================

    Friend Sub DrawListToFidocadFile_Bezier(ByVal FileName As String)

        If ListOfCurvesArray Is Nothing Then Return

        ' -------------------------------------------------------------------------- Open File
        Dim f As System.IO.StreamWriter
        f = IO.File.CreateText(FileName)
        f.WriteLine("[FIDOCAD]")
        f.WriteLine("FJC A 2")
        f.WriteLine("FJC L 0 0 1.0")
        ' -------------------------------------------------------------------------- Write elements
        Dim GraphicPath As String = ""
        For i As Integer = 0 To ListOfCurvesArray.Count - 1
            Dim CurveArray As ArrayList = DirectCast(ListOfCurvesArray(i), ArrayList)
            Dim Contour As String = ""
            Dim Hole As String = ""
            Dim Current As String = ""
            '
            For j As Integer = 0 To CurveArray.Count - 1

                Current = ""

                Dim Curves As RasterToVectors.Curve() = DirectCast(CurveArray(j), RasterToVectors.Curve())

                For k As Integer = 0 To Curves.Length - 1
                    If Curves(k).Kind = RasterToVectors.CurveKind.Bezier Then
                        Current += "BE " + _
                                    (Curves(k).A.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).A.y * SizeFactor).ToString("0 ") + _
                                    (Curves(k).ControlPointA.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).ControlPointA.y * SizeFactor).ToString("0 ") + _
                                    (Curves(k).ControlPointB.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).ControlPointB.y * SizeFactor).ToString("0 ") + _
                                    (Curves(k).B.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).B.y * SizeFactor).ToString("0 ") + _
                                    "0" + _
                                    vbCrLf
                    Else
                        Current += "LI " + _
                                    (Curves(k).A.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).A.y * SizeFactor).ToString("0 ") + _
                                    (Curves(k).B.x * SizeFactor).ToString("0 ") + _
                                    (Curves(k).B.y * SizeFactor).ToString("0 ") + _
                                    "0" + _
                                    vbCrLf
                    End If
                Next
                GraphicPath += Current
            Next
        Next
        ' -------------------------------------------------------------------------- Write the file
        f.Write(GraphicPath)
        ' -------------------------------------------------------------------------- Close File
        f.Close()
    End Sub


    ' =============================================================================================
    '  Version with the CP primitive instead of the Bézier curves
    ' =============================================================================================

    Friend Sub DrawListToFidocadFile_Filled(ByVal FileName As String)

        If ListOfCurvesArray Is Nothing Then Return

        ' -------------------------------------------------------------------------- Open File
        Dim f As System.IO.StreamWriter
        f = IO.File.CreateText(FileName)
        f.WriteLine("[FIDOCAD]")
        ' -------------------------------------------------------------------------- lines thickness
        f.WriteLine("FJC A 0")
        ' -------------------------------------------------------------------------- colors
        For i As Int32 = 0 To 15
            f.WriteLine("FJC L " + i.ToString + " " + IntegerColor(i) + " 0.3")
        Next
        ' -------------------------------------------------------------------------- Write elements
        Dim OutString As String = ""
        For i As Integer = 0 To ListOfCurvesArray.Count - 1
            Dim CurveArray As ArrayList = DirectCast(ListOfCurvesArray(i), ArrayList)
            '
            For j As Integer = 0 To CurveArray.Count - 1

                OutString += "CP 1 "

                Dim Curves As RasterToVectors.Curve() = DirectCast(CurveArray(j), RasterToVectors.Curve())

                ' ---------------------------------------------------- limit to 250 otherwise for FidocadJ
                Dim ncurves As Int32 = Math.Min(Curves.Length, 250)

                For k As Integer = 0 To ncurves - 1
                    OutString += (Curves(k).A.x * SizeFactor).ToString("0 ") + _
                                 (Curves(k).A.y * SizeFactor).ToString("0 ")
                Next

                OutString += (j Mod 16).ToString + vbCrLf
            Next
        Next
        f.Write(OutString)
        ' -------------------------------------------------------------------------- Close File
        f.Close()
    End Sub

    Private Function IntegerColor(ByVal n As Int32) As String
        Dim c As Int32

        n = n * 16

        'c = (15 - n) * 256 * 256
        'c += (15 - n) * 256
        'c += n

        c = n * 256 * 256
        c += n * 256
        c += n

        c = 0
        Return c.ToString
    End Function

End Module
