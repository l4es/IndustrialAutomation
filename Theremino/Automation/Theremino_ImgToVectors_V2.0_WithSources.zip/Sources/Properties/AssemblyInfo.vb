

Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices


<Assembly: AssemblyTitle("Theremino_ImgToVectors")> 
<Assembly: AssemblyDescription("Image To Vectors")> 
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("ImgToVectors")> 
<Assembly: AssemblyCopyright("No copyright - Theremino System")> 
<Assembly: AssemblyTrademark("Theremino System")> 
<Assembly: AssemblyCulture("")>


<Assembly: ComVisible(False)> 

<Assembly: Guid("13402b65-650e-49dd-92d5-3b6084f7cddc")>


<Assembly: AssemblyVersion("2.0")> 
<Assembly: AssemblyFileVersion("2.0")> 
