﻿Imports System.Runtime.InteropServices

Public Class Class_AVI
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
  Public Structure RGBQUAD
        Public rgbBlue As Byte
        Public rgbGreen As Byte
        Public rgbRed As Byte
        Public rgbReserved As Byte
    End Structure

    Public Shared RGBQUAD_SIZE As Integer = 4
    Public Shared PALETTE_SIZE As Integer = 4 * 256  'RGBQUAD * 256 colours

    Public Shared ReadOnly streamtypeVIDEO As Integer = mmioFOURCC("v"c, "i"c, "d"c, "s"c)
    Public Shared ReadOnly streamtypeAUDIO As Integer = mmioFOURCC("a"c, "u"c, "d"c, "s"c)
    Public Shared ReadOnly streamtypeMIDI As Integer = mmioFOURCC("m"c, "i"c, "d"c, "s"c)
    Public Shared ReadOnly streamtypeTEXT As Integer = mmioFOURCC("t"c, "x"c, "t"c, "s"c)

    Public Const OF_SHARE_DENY_WRITE As Integer = 32
    Public Const OF_WRITE As Integer = 1
    Public Const OF_READWRITE As Integer = 2
    Public Const OF_CREATE As Integer = 4096

    Public Const BMP_MAGIC_COOKIE As Integer = 19778 'ascii string "BM"

    Public Const AVICOMPRESSF_INTERLEAVE As Integer = &H1    ' interleave
    Public Const AVICOMPRESSF_DATARATE As Integer = &H2    ' use a data rate
    Public Const AVICOMPRESSF_KEYFRAMES As Integer = &H4    ' use keyframes
    Public Const AVICOMPRESSF_VALID As Integer = &H8    ' has valid data
    Public Const AVIIF_KEYFRAME As Integer = &H10

    Public Const ICMF_CHOOSE_KEYFRAME As UInteger = &H1    ' show KeyFrame Every box
    Public Const ICMF_CHOOSE_DATARATE As UInteger = &H2  ' show DataRate box
    Public Const ICMF_CHOOSE_PREVIEW As UInteger = &H4  ' allow expanded preview dialog

    '       macro mmioFOURCC
    Public Shared Function mmioFOURCC(ByVal ch0 As Char, ByVal ch1 As Char, ByVal ch2 As Char, ByVal ch3 As Char) As Integer
        '   Return CInt(CByte(AscW(ch0)))
        ' Return ((CInt(CByte(AscW(ch0))) Or ((CByte(AscW(ch1))) << 8) Or ((CByte(AscW(ch2))) << 16) Or ((CByte(AscW(ch3))) << 24)))
        Return (CInt(CByte(Asc(ch0)) Or (CByte(Asc(ch1)) << 8) Or (CByte(Asc(ch2)) << 16) Or (CByte(Asc(ch3)) << 24)))
    End Function


#Region "structure declarations"

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
   Public Structure RECT
        Public left As UInteger
        Public top As UInteger
        Public right As UInteger
        Public bottom As UInteger
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
   Public Structure BITMAPINFOHEADER
        Public biSize As Integer
        Public biWidth As Integer
        Public biHeight As Integer
        Public biPlanes As Int16
        Public biBitCount As Int16
        Public biCompression As Integer
        Public biSizeImage As Integer
        Public biXPelsPerMeter As Integer
        Public biYPelsPerMeter As Integer
        Public biClrUsed As Integer
        Public biClrImportant As Integer
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
  Structure BITMAPINFO
        Public bmiHeader As BITMAPINFOHEADER
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=256)> _
        Public bmiColors As RGBQUAD()
    End Structure

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure PCMWAVEFORMAT
        Public wFormatTag As Short
        Public nChannels As Short
        Public nSamplesPerSec As Integer
        Public nAvgBytesPerSec As Integer
        Public nBlockAlign As Short
        Public wBitsPerSample As Short
        Public cbSize As Short
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure AVISTREAMINFO
        Public fccType As Int32
        Public fccHandler As Int32
        Public dwFlags As Int32
        Public dwCaps As Int32
        Public wPriority As Int16
        Public wLanguage As Int16
        Public dwScale As Int32
        Public dwRate As Int32
        Public dwStart As Int32
        Public dwLength As Int32
        Public dwInitialFrames As Int32
        Public dwSuggestedBufferSize As Int32
        Public dwQuality As Int32
        Public dwSampleSize As Int32
        Public rcFrame As RECT
        Public dwEditCount As Int32
        Public dwFormatChangeCount As Int32
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=64)> _
        Public szName As UInt16()
    End Structure
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure BITMAPFILEHEADER
        Public bfType As Int16 '"magic cookie" - must be "BM"
        Public bfSize As Int32
        Public bfReserved1 As Int16
        Public bfReserved2 As Int16
        Public bfOffBits As Int32
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
     Public Structure AVIFILEINFO
        Public dwMaxBytesPerSecond As Int32
        Public dwFlags As Int32
        Public dwCaps As Int32
        Public dwStreams As Int32
        Public dwSuggestedBufferSize As Int32
        Public dwWidth As Int32
        Public dwHeight As Int32
        Public dwScale As Int32
        Public dwRate As Int32
        Public dwLength As Int32
        Public dwEditCount As Int32
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=64)> _
        Public szFileType As Char()
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
     Public Structure AVICOMPRESSOPTIONS
        Public fccType As UInt32
        Public fccHandler As UInt32
        Public dwKeyFrameEvery As UInt32  ' only used with AVICOMRPESSF_KEYFRAMES
        Public dwQuality As UInt32
        Public dwBytesPerSecond As UInt32 ' only used with AVICOMPRESSF_DATARATE
        Public dwFlags As UInt32
        Public lpFormat As IntPtr
        Public cbFormat As UInt32
        Public lpParms As IntPtr
        Public cbParms As UInt32
        Public dwInterleaveEvery As UInt32
    End Structure

    ' <summary>AviSaveV needs a pointer to a pointer to an AVICOMPRESSOPTIONS structure</summary>
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
     Public Class AVICOMPRESSOPTIONS_CLASS
        Public fccType As UInt32
        Public fccHandler As UInt32
        Public dwKeyFrameEvery As UInt32  ' only used with AVICOMRPESSF_KEYFRAMES
        Public dwQuality As UInt32
        Public dwBytesPerSecond As UInt32 ' only used with AVICOMPRESSF_DATARATE
        Public dwFlags As UInt32
        Public lpFormat As IntPtr
        Public cbFormat As UInt32
        Public lpParms As IntPtr
        Public cbParms As UInt32
        Public dwInterleaveEvery As UInt32

        Public Function ToStruct() As AVICOMPRESSOPTIONS
            Dim returnVar As AVICOMPRESSOPTIONS = New AVICOMPRESSOPTIONS()
            With returnVar
                .fccType = Me.fccType
                .fccHandler = Me.fccHandler
                .dwKeyFrameEvery = Me.dwKeyFrameEvery
                .dwQuality = Me.dwQuality
                .dwBytesPerSecond = Me.dwBytesPerSecond
                .dwFlags = Me.dwFlags
                .lpFormat = Me.lpFormat
                .cbFormat = Me.cbFormat
                .lpParms = Me.lpParms
                .cbParms = Me.cbParms
                .dwInterleaveEvery = Me.dwInterleaveEvery
                Return returnVar
            End With
        End Function
    End Class
#End Region


#Region "method declarations"

    '	Initialize the AVI library
    <DllImport("avifil32.dll")> _
    Public Shared Sub AVIFileInit()

    End Sub

    'Open an AVI file
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIFileOpen(ByRef ppfile As Integer, ByVal siFile As String, ByVal uMode As Integer, ByVal pclsidHandler As Integer) As Integer
    End Function

    'Get a stream from an open AVI file
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIFileGetStream(ByVal pfile As Integer, ByVal ppavi As IntPtr, ByVal fccType As Integer, ByVal lParam As Integer) As Integer
    End Function
    'Get the start position of a stream
    <DllImport("avifil32.dll", PreserveSig:=True)> _
    Public Shared Function AVIStreamStart(ByVal pavi As Integer) As Integer
    End Function

    'Get the length of a stream in frames
    <DllImport("avifil32.dll", PreserveSig:=True)> _
    Public Shared Function AVIStreamLength(ByVal pavi As Integer) As Integer

    End Function
    'Get information about an open stream
    Public Declare Function AVIStreamInfo_implement Lib "avifil32.dll" Alias "AVIStreamInfo" (ByVal pAVIStream As IntPtr, ByRef psi As AVISTREAMINFO, ByVal lSize As Integer) As Integer
    ' <DllImport("avifil32.dll")> _
    ' Public Shared Function AVIStreamInfo(ByVal pAVIStream As IntPtr, ByRef psi As AVISTREAMINFO, ByVal lSize As Integer) As Integer
    'End Function
    'Get a pointer to a GETFRAME object (returns 0 on error)
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIStreamGetFrameOpen(ByVal pAVIStream As IntPtr, ByRef bih As BITMAPINFOHEADER) As Integer
    End Function

    'Get a pointer to a packed DIB (returns 0 on error)
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIStreamGetFrame(ByVal pGetFrameObj As Integer, ByVal lPos As Integer) As Integer

    End Function

    'Create a new stream in an open AVI file
    '<DllImport("avifil32.dll")> _
    'Public Shared Function AVIFileCreateStreamA(ByVal pfile As Integer, ByVal ppavi As IntPtr, ByRef ptr_streaminfo As AVISTREAMINFO) As Integer
    'End Function
    Declare Function AVIFileCreateStream Lib "avifil32.dll" Alias "AVIFileCreateStreamA" (ByVal pfile As Integer, ByRef ppavi As IntPtr, ByRef psi As AVISTREAMINFO) As Integer
    ' Create an editable stream
    <DllImport("avifil32.dll")> _
    Public Shared Function CreateEditableStream(ByRef ppsEditable As IntPtr, ByVal psSource As Integer) As Integer

    End Function

    '  Cut samples from an editable stream
    <DllImport("avifil32.dll")> _
    Public Shared Function EditStreamCut(ByVal pStream As IntPtr, ByRef plStart As Int32, ByRef plLength As Int32, ByRef ppResult As IntPtr) As Integer

    End Function
    'Copy a part of an editable stream
    <DllImport("avifil32.dll")> _
    Public Shared Function EditStreamCopy(ByVal pStream As IntPtr, ByRef plStart As Int32, ByRef plLength As Int32, ByRef ppResult As Int32) As Integer

    End Function
    'Paste an editable stream into another editable stream
    <DllImport("avifil32.dll")> _
    Public Shared Function EditStreamPaste(ByVal pStreamfirst As IntPtr, ByRef plPos As Int32, ByRef plLength As Int32, ByVal pstream As IntPtr, ByVal lStart As Int32, ByVal lLength As Int32) As Integer

    End Function
    '       Change a stream's header values
    <DllImport("avifil32.dll")> _
Public Shared Function EditStreamSetInfo(ByVal pStream As IntPtr, ByRef lpInfo As AVISTREAMINFO, Optional ByVal cbInfo As Int32 = 0) As Integer

    End Function
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIMakeFileFromStreams(ByRef ppfile As IntPtr, ByVal nStreams As Integer, ByRef papStreams As IntPtr) As Integer

    End Function

    '       Set the format for a new stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamSetFormat(ByVal aviStream As IntPtr, ByVal lPos As Int32, ByRef lpFormat As BITMAPINFO, ByVal cbFormat As Int32) As Integer

    End Function

    '	Set the format for a new stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamSetFormat(ByVal aviStream As IntPtr, ByVal lPos As Int32, ByRef lpFormat As PCMWAVEFORMAT, ByVal cbFormat As Int32) As Integer

    End Function

    '	Read the format for a stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamReadFormat(ByVal aviStream As IntPtr, ByVal lPos As Int32, ByRef lpFormat As BITMAPINFO, ByRef cbFormat As Int32) As Integer

    End Function

    '	Read the size of the format for a stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamReadFormat(ByVal aviStream As IntPtr, ByVal lPos As Int32, ByVal empty As Integer, ByRef cbFormat As Int32) As Integer

    End Function

    '	Read the format for a stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamReadFormat(ByVal aviStram As IntPtr, ByVal lPos As Int32, ByRef lpFormat As PCMWAVEFORMAT, ByRef cbFormat As Int32) As Integer

    End Function

    '	Write a sample to a stream
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIStreamWrite(ByVal aviStream As IntPtr, ByVal lStart As Int32, ByVal lSamples As Int32, ByVal lpBuffer As IntPtr, ByVal cbBuffer As Int32, ByVal dwFlags As Int32, ByVal dummy1 As Int32, ByVal dummy2 As Int32) As Integer

    End Function


    '	Release the GETFRAME object
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamGetFrameClose(ByVal pGetFrameObj As Integer) As Integer

    End Function
    '	Release an open AVI stream
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamRelease(ByVal aviStream As IntPtr) As Integer

    End Function

    '	Release an open AVI file
    <DllImport("avifil32.dll")> _
       Public Shared Function AVIFileRelease(ByVal pFile As Integer) As Integer

    End Function
    '	Close the AVI library
    <DllImport("avifil32.dll")> _
       Public Shared Sub AVIFileExit()

    End Sub


    '<DllImport("avifil32.dll", CharSet:=CharSet.None)> _
    '   Public Shared Function AVIMakeCompressedStream(ByVal ppsCompressed As IntPtr, ByVal aviStream As IntPtr, ByRef ao As AVICOMPRESSOPTIONS, ByVal dummy As Integer) As Integer

    'End Function
    '  Public Declare Function AVIMakeCompressedStream Lib "avifil32.dll" (ByVal ppsCompressed As IntPtr, ByVal aviStream As IntPtr, ByRef ao As AVICOMPRESSOPTIONS, ByVal dummy As Integer) As Integer
    ' Public Declare Function AVIMakeCompressedStream Lib "avifil32.dll" (ByRef ppsCompressed As Integer, ByVal psSource As Integer, ByRef lpOptions As AVICOMPRESSOPTIONS, ByVal pclsidHandler As Integer) As Integer
    <DllImport("avifil32.dll")> _
    Public Shared Function AVIMakeCompressedStream(ByRef ppsCompressed As IntPtr, ByVal aviStream As IntPtr, ByRef ao As AVICOMPRESSOPTIONS, ByVal dummy As Integer) As Integer
    End Function
    <DllImport("avifil32.dll")> _
       Public Shared Function AVISaveOptions(ByVal hwnd As IntPtr, ByVal uiFlags As UInt32, ByVal nStreams As Int32, ByRef ppavi As IntPtr, ByRef plpOptions As AVICOMPRESSOPTIONS_CLASS) As Boolean

    End Function


    <DllImport("avifil32.dll")> _
       Public Shared Function AVISaveOptionsFree(ByVal nStreams As Integer, ByRef plpOptions As AVICOMPRESSOPTIONS_CLASS) As Long

    End Function

    Public Declare Function AVIFileInfo_implement Lib "avifil32.dll" Alias "AVIFileInfo" (ByVal pfile As Integer, ByRef pfi As AVIFILEINFO, ByVal lSize As Integer) As Integer
    '<DllImport("avifil32.dll")> _
    '   Public Shared Function AVIFileInfo(ByVal pfile As Integer, ByRef pfi As AVIFILEINFO, ByVal lSize As Integer) As Integer

    'End Function

    <DllImport("winmm.dll", EntryPoint:="mmioStringToFOURCCA")> _
       Public Shared Function mmioStringToFOURCC(ByVal sz As String, ByVal uFlags As Integer) As Integer

    End Function

    <DllImport("avifil32.dll")> _
       Public Shared Function AVIStreamRead(ByVal pavi As IntPtr, ByVal lStart As Int32, ByVal lSamples As Int32, ByVal lpBuffer As IntPtr, ByVal cbBuffer As Int32, ByVal plBytes As Int32, Optional ByVal plSamples As Int32 = 0) As Integer

    End Function

    <DllImport("avifil32.dll")> _
       Public Shared Function AVISaveV(ByVal szFile As String, ByVal empty As Int16, ByVal lpfnCallback As Int16, ByVal nStreams As Int16, ByRef ppavi As IntPtr, ByRef plpOptions As AVICOMPRESSOPTIONS_CLASS) As Integer

    End Function


#End Region
End Class
