﻿Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices

Public Class Class_AVIManager
    Private aviFile As Integer = 0
    Private streams As ArrayList = New ArrayList
    ' <summary>Open or create an AVI file</summary>
    ' <param name="fileName">Name of the AVI file</param>
    '<param name="open">true: Open the file; false: Create or overwrite the file</param>
    Public Sub New(ByVal fileName As String, ByVal open As Boolean)

        Class_AVI.AVIFileInit()
        Dim result As Integer

        If open = True Then
            result = Class_AVI.AVIFileOpen(aviFile, fileName, Class_AVI.OF_READWRITE, 0)
        Else : result = Class_AVI.AVIFileOpen(aviFile, fileName, Class_AVI.OF_WRITE Or Class_AVI.OF_CREATE, 0)
        End If
        If (result <> 0) Then Throw New Exception("Exception in AVIFileOpen: " + result.ToString())
    End Sub
    Private Sub New(ByVal aviFile As Integer)
        Me.aviFile = aviFile
    End Sub


    ''' <summary>Get the first video stream - usually there is only one video stream</summary>
    ''' <returns>VideoStream object for the stream</returns>
    Public Function GetVideoStream() As Class_VideoStream
        Dim aviStream As IntPtr

        Dim result As Integer = Class_AVI.AVIFileGetStream(aviFile, aviStream, Class_AVI.streamtypeVIDEO, 0)

        If (result <> 0) Then Throw New Exception("Exception in AVIFileGetStream: " + result.ToString())
        Dim stream As Class_VideoStream = New Class_VideoStream(aviFile, aviStream)
        streams.Add(stream)
        Return stream
    End Function

    '''<summary>Getthe first wave audio stream</summary>
    '''<returns>AudioStream object for the stream</returns>
    Public Function GetWaveStream() As Class_AudioStream
        Dim aviStream As IntPtr

        Dim result As Integer = Class_AVI.AVIFileGetStream(aviFile, aviStream, Class_AVI.streamtypeAUDIO, 0)

        If (result <> 0) Then Throw New Exception("Exception in AVIFileGetStream: " + result.ToString())

        Dim stream As Class_AudioStream = New Class_AudioStream(aviFile, aviStream)
        streams.Add(stream)
        Return stream
    End Function

    Public Function GetOpenStream(ByVal index As Integer) As Class_VideoStream
        Return CType(streams(index), Class_VideoStream)
    End Function

    ''' <summary>Add an empty video stream to the file</summary>
    ''' <param name="isCompressed">true: Create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="frameSize">Size of one frame in bytes</param>
    ''' <param name="width">Width of each image</param>
    ''' <param name="height">Height of each image</param>
    ''' <param name="format">PixelFormat of the images</param>
    ''' <returns>VideoStream object for the new stream</returns>
    Public Function AddVideoStream(ByVal isCompressed As Boolean, ByVal frameRate As Double, ByVal frameSize As Integer, ByVal width As Integer, ByVal height As Integer, ByVal format As PixelFormat) As Class_VideoStream
        Dim stream As Class_VideoStream = New Class_VideoStream(aviFile, isCompressed, frameRate, frameSize, width, height, format)
        streams.Add(stream)
        Return stream
    End Function

    '''<summary>Add an empty video stream to the file</summary>
    '''<remarks>Compresses the stream without showing the codecs dialog</remarks>
    '''<param name="compressOptions">Compression options</param>
    '''<param name="frameRate">Frames per second</param>
    '''<param name="firstFrame">Image to write into the stream as the first frame</param>
    '''<returns>VideoStream object for the new stream</returns>
    Public Function AddVideoStream(ByVal compressOptions As Class_AVI.AVICOMPRESSOPTIONS, ByVal frameRate As Double, ByVal firstFrame As Bitmap) As Class_VideoStream
        Dim stream As Class_VideoStream = New Class_VideoStream(aviFile, compressOptions, frameRate, firstFrame)
        streams.Add(stream)
        Return stream
    End Function

    '''<summary>Add an empty video stream to the file</summary>
    ''' <param name="isCompressed">true: Create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="firstFrame">Image to write into the stream as the first frame</param>
    ''' <returns>VideoStream object for the new stream</returns>
    Public Function AddVideoStream(ByVal isCompressed As Boolean, ByVal frameRate As Double, ByVal firstFrame As Bitmap) As Class_VideoStream
        Dim stream As Class_VideoStream = New Class_VideoStream(aviFile, isCompressed, frameRate, firstFrame)
        streams.Add(stream)
        Return stream
    End Function

    ''' <summary>Add a wave audio stream from another file to this file</summary>
    ''' <param name="waveFileName">Name of the wave file to add</param>
    '''<param name="startAtFrameIndex">Index of the video frame at which the sound is going to start</param>
    Public Sub AddAudioStream(ByVal waveFileName As String, ByVal startAtFrameIndex As Integer)
        Dim audioManager As Class_AVIManager = New Class_AVIManager(waveFileName, True)
        Dim newStream As Class_AudioStream = audioManager.GetWaveStream()
        AddAudioStream(newStream, startAtFrameIndex)
        audioManager.Close()
    End Sub

    Private Function InsertSilence(ByVal countSilentSamples As Integer, ByVal waveData As IntPtr, ByVal lengthWave As Integer, ByRef streamInfo As Class_AVI.AVISTREAMINFO) As IntPtr
        'initialize silence
        Dim lengthSilence As Integer = countSilentSamples * streamInfo.dwSampleSize
        Dim silence As Byte() = New Byte(lengthSilence) {}

        'initialize new sound
        Dim lengthNewStream As Integer = lengthSilence + lengthWave
        Dim newWaveData As IntPtr = Marshal.AllocHGlobal(lengthNewStream)
        'copy silence
        Marshal.Copy(silence, 0, newWaveData, lengthSilence)
        'copy sound
        Dim sound As Byte() = New Byte(lengthWave) {}
        Marshal.Copy(waveData, sound, 0, lengthWave)
        Dim startOfSound As IntPtr = New IntPtr(newWaveData.ToInt32() + lengthSilence)
        Marshal.Copy(sound, 0, startOfSound, lengthWave)
        Marshal.FreeHGlobal(newWaveData)
        streamInfo.dwLength = lengthNewStream
        Return newWaveData
    End Function

    ''' <summary>Add an existing wave audio stream to the file</summary>
    ''' <param name="newStream">The stream to add</param>
    ''' <param name="startAtFrameIndex">
    ''' The index of the video frame at which the sound is going to start.
    ''' '0' inserts the sound at the beginning of the video.
    ''' </param>
    Public Sub AddAudioStream(ByVal newStream As Class_AudioStream, ByVal startAtFrameIndex As Integer)
        Dim streamInfo As Class_AVI.AVISTREAMINFO = New Class_AVI.AVISTREAMINFO()
        Dim streamFormat As Class_AVI.PCMWAVEFORMAT = New Class_AVI.PCMWAVEFORMAT()
        Dim streamLength As Integer = 0
        Dim rawData As IntPtr = newStream.GetStreamData(streamInfo, streamFormat, streamLength)
        Dim waveData As IntPtr = rawData
        If (startAtFrameIndex > 0) Then
            Dim framesPerSecond As Double = GetVideoStream().FrameRate
            Dim samplesPerSecond As Double = newStream.CountSamplesPerSecond
            Dim startAtSecond As Double = startAtFrameIndex / framesPerSecond
            Dim startAtSample As Integer = CInt((samplesPerSecond * startAtSecond))
            waveData = InsertSilence(startAtSample - 1, waveData, streamLength, streamInfo)
        End If
        Dim aviStream As IntPtr
        Dim result As Integer = Class_AVI.AVIFileCreateStream(aviFile, aviStream, streamInfo)
        If (result <> 0) Then Throw New Exception("Exception in AVIFileCreateStream: " + result.ToString())
        result = Class_AVI.AVIStreamSetFormat(aviStream, 0, streamFormat, Marshal.SizeOf(streamFormat))
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamSetFormat: " + result.ToString())
        result = Class_AVI.AVIStreamWrite(aviStream, 0, streamLength, waveData, streamLength, Class_AVI.AVIIF_KEYFRAME, 0, 0)
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamWrite: " + result.ToString())

        result = Class_AVI.AVIStreamRelease(aviStream)
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamRelease: " + result.ToString())

        Marshal.FreeHGlobal(waveData)
    End Sub

    ''' <summary>Add an existing wave audio stream to the file</summary>
    ''' <param name="waveData">The new stream's data</param>
    ''' <param name="streamInfo">Header info for the new stream</param>
    ''' <param name="streamFormat">The new stream' format info</param>
    ''' <param name="streamLength">Length of the new stream</param>
    Public Sub AddAudioStream(ByVal waveData As IntPtr, ByVal streamInfo As Class_AVI.AVISTREAMINFO, ByVal streamFormat As Class_AVI.PCMWAVEFORMAT, ByVal streamLength As Integer)
        Dim aviStream As IntPtr
        Dim result As Integer = Class_AVI.AVIFileCreateStream(aviFile, aviStream, streamInfo)
        If (result <> 0) Then Throw New Exception("Exception in AVIFileCreateStream: " + result.ToString())
        result = Class_AVI.AVIStreamSetFormat(aviStream, 0, streamFormat, Marshal.SizeOf(streamFormat))
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamSetFormat: " + result.ToString())


        result = Class_AVI.AVIStreamWrite(aviStream, 0, streamLength, waveData, streamLength, Class_AVI.AVIIF_KEYFRAME, 0, 0)
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamWrite: " + result.ToString())


        result = Class_AVI.AVIStreamRelease(aviStream)
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamRelease: " + result.ToString())

    End Sub

    ''' <summary>Copy a piece of video and wave sound int a new file</summary>
    ''' <param name="newFileName">File name</param>
    ''' <param name="startAtSecond">Start copying at second x</param>
    ''' <param name="stopAtSecond">Stop copying at second y</param>
    ''' <returns>AviManager for the new video</returns>
    Public Function CopyTo(ByVal newFileName As String, ByVal startAtSecond As Single, ByVal stopAtSecond As Single) As Class_AVIManager
        Dim newFile As Class_AVIManager = New Class_AVIManager(newFileName, False)

        Try
            'copy video stream
            Dim videoStream As Class_VideoStream = GetVideoStream()

            Dim startFrameIndex As Integer = CInt((videoStream.FrameRate * startAtSecond))
            Dim stopFrameIndex As Integer = CInt((videoStream.FrameRate * stopAtSecond))

            videoStream.GetFrameOpen()
            Dim bmp As Bitmap = videoStream.GetBitmap(startFrameIndex)
            Dim newStream As Class_VideoStream = newFile.AddVideoStream(False, videoStream.FrameRate, bmp)
            For n As Integer = startFrameIndex + 1 To stopFrameIndex - 1 Step 1
                bmp = videoStream.GetBitmap(n)
                newStream.AddFrame(bmp)
            Next
            videoStream.GetFrameClose()
            'copy audio stream
            Dim waveStream As Class_AudioStream = GetWaveStream()

            Dim streamInfo As Class_AVI.AVISTREAMINFO = New Class_AVI.AVISTREAMINFO()
            Dim streamFormat As Class_AVI.PCMWAVEFORMAT = New Class_AVI.PCMWAVEFORMAT()
            Dim streamLength As Integer = 0
            Dim ptrRawData As IntPtr = waveStream.GetStreamData(streamInfo, streamFormat, streamLength)

            Dim startByteIndex As Integer = CInt((startAtSecond * CSng((waveStream.CountSamplesPerSecond * streamFormat.nChannels * waveStream.CountBitsPerSample)) / 8))
            Dim stopByteIndex As Integer = CInt((stopAtSecond * CSng((waveStream.CountSamplesPerSecond * streamFormat.nChannels * waveStream.CountBitsPerSample)) / 8))

            Dim ptrWavePart As IntPtr = New IntPtr(ptrRawData.ToInt32() + startByteIndex)

            Dim rawData As Byte() = New Byte(stopByteIndex - startByteIndex) {}
            Marshal.Copy(ptrWavePart, rawData, 0, rawData.Length)
            Marshal.FreeHGlobal(ptrRawData)

            streamInfo.dwLength = rawData.Length
            streamInfo.dwStart = 0

            Dim unmanagedRawData As IntPtr = Marshal.AllocHGlobal(rawData.Length)
            Marshal.Copy(rawData, 0, unmanagedRawData, rawData.Length)
            newFile.AddAudioStream(unmanagedRawData, streamInfo, streamFormat, rawData.Length)
            Marshal.FreeHGlobal(unmanagedRawData)
        Catch ex As Exception
            newFile.Close()
            Throw ex
        End Try
        Return newFile
    End Function

    ''' <summary>Release all ressources</summary>
    Public Sub Close()
        For Each stream As Class_AVIStream In streams
            stream.Close()
        Next
        Class_AVI.AVIFileRelease(aviFile)
        Class_AVI.AVIFileExit()
    End Sub

    Public Shared Sub MakeFileFromStream(ByVal fileName As String, ByVal stream As Class_AVIStream)
        Dim newFile As IntPtr = IntPtr.Zero
        Dim streamPointer As IntPtr = stream.StreamPointer

        Dim opts As Class_AVI.AVICOMPRESSOPTIONS_CLASS = New Class_AVI.AVICOMPRESSOPTIONS_CLASS()
        opts.fccType = CUInt(Class_AVI.streamtypeVIDEO)
        opts.lpParms = IntPtr.Zero
        opts.lpFormat = IntPtr.Zero
        Class_AVI.AVISaveOptions(IntPtr.Zero, Class_AVI.ICMF_CHOOSE_KEYFRAME Or Class_AVI.ICMF_CHOOSE_DATARATE, 1, streamPointer, opts)
        Class_AVI.AVISaveOptionsFree(1, opts)
        Class_AVI.AVISaveV(fileName, 0, 0, 1, streamPointer, opts)
    End Sub
End Class
