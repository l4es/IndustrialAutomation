﻿Public MustInherit Class Class_AVIStream
    Protected aviFile As Integer
    Protected aviStream As IntPtr
    Protected compressedStream As IntPtr
    Protected writeCompressed_bool As Boolean
    ''' <summary>Pointer to the unmanaged AVI file</summary>
    Friend ReadOnly Property FilePointer() As Integer
        Get
            Return aviFile
        End Get
    End Property
    '''  <summary>Pointer to the unmanaged AVI Stream</summary>
    Friend Overridable ReadOnly Property StreamPointer() As IntPtr
        Get
            Return aviStream
        End Get
    End Property
 
    ''' <summary>Flag: The stream is compressed/uncompressed</summary>
    Friend Overridable ReadOnly Property WriteCompressed() As Boolean
        Get
            Return writeCompressed_bool
        End Get
    End Property
         

    ''' <summary>Close the stream</summary>
    Public Overridable Sub Close()
        If writeCompressed_bool Then
            Class_AVI.AVIStreamRelease(compressedStream)
        End If
        Class_AVI.AVIStreamRelease(StreamPointer)
    End Sub

    ''' <summary>Export the stream into a new file</summary>
    ''' <param name="fileName"></param>
    Public Overridable Sub ExportStream(ByVal fileName As String)
    End Sub
End Class
