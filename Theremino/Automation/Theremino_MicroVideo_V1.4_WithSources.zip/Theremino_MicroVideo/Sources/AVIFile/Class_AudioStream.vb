﻿Imports System.Runtime.InteropServices

Public Class Class_AudioStream : Inherits Class_AVIStream
    Public ReadOnly Property CountBitsPerSample() As Integer
        Get
            Return waveFormat.wBitsPerSample
        End Get
    End Property

    Public ReadOnly Property CountSamplesPerSecond() As Integer
        Get
            Return waveFormat.nSamplesPerSec
        End Get
    End Property
    Public ReadOnly Property CountChannels() As Integer
        Get
            Return waveFormat.nChannels
        End Get
    End Property
    '''<summary>the stream's format</summary>
    Private waveFormat As Class_AVI.PCMWAVEFORMAT = New Class_AVI.PCMWAVEFORMAT()
    '''<summary>Initialize an AudioStream for an existing stream</summary>
    ''<param name="aviFile">The file that contains the stream</param>
    ''<param name="aviStream">An IAVISTREAM from [aviFile]</param>
    Public Sub New(ByVal aviFile As Integer, ByVal aviStream As IntPtr)
        Me.aviFile = aviFile
        Me.aviStream = aviStream

        Dim size As Integer = Marshal.SizeOf(waveFormat)
        Class_AVI.AVIStreamReadFormat(aviStream, 0, waveFormat, size)
        Dim streamInfo As Class_AVI.AVISTREAMINFO = GetStreamInfo(aviStream)
    End Sub
    ''' <summary>Read the stream's header information</summary>
    '''<param name="aviStream">The IAVISTREAM to read from</param>
    '''<returns>AVISTREAMINFO</returns>
    Private Function GetStreamInfo(ByVal aviStream As IntPtr) As Class_AVI.AVISTREAMINFO
        Dim streamInfo As Class_AVI.AVISTREAMINFO = New Class_AVI.AVISTREAMINFO()
        Dim result As Integer = Class_AVI.AVIStreamInfo_implement(aviStream, streamInfo, Marshal.SizeOf(streamInfo))
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamInfo: " + result.ToString())
        Return streamInfo
    End Function

    '''<summary>Read the stream's header information</summary>
    '''<returns>AVISTREAMINFO</returns>
    Public Function GetStreamInfo() As Class_AVI.AVISTREAMINFO
        If (WriteCompressed) Then
            Return GetStreamInfo(compressedStream)
        Else : Return GetStreamInfo(aviStream)
        End If
    End Function
    '''   <summary>Read the stream's format information</summary>
    '''<returns>PCMWAVEFORMAT</returns>
    Public Function GetFormat() As Class_AVI.PCMWAVEFORMAT
        Dim format As Class_AVI.PCMWAVEFORMAT = New Class_AVI.PCMWAVEFORMAT()
        Dim size As Integer = Marshal.SizeOf(format)
        Dim result As Integer = Class_AVI.AVIStreamReadFormat(aviStream, 0, format, size)
        Return format
    End Function
    '''  <summary>Returns all data needed to copy the stream</summary>
    '''<remarks>Do not forget to call Marshal.FreeHGlobal and release the raw data pointer</remarks>
    '''<param name="streamInfo">Receives the header information</param>
    '''<param name="format">Receives the format</param>
    '''<param name="streamLength">Receives the length of the stream</param>
    '''<returns>Pointer to the wave data</returns>
    Public Function GetStreamData(ByRef streamInfo As Class_AVI.AVISTREAMINFO, ByRef format As Class_AVI.PCMWAVEFORMAT, ByRef streamLength As Integer) As IntPtr
        streamInfo = GetStreamInfo()

        format = GetFormat()

        streamLength = Class_AVI.AVIStreamLength(aviStream.ToInt32()) * streamInfo.dwSampleSize
        Dim waveData As IntPtr = Marshal.AllocHGlobal(streamLength)

        Dim result As Integer = Class_AVI.AVIStreamRead(aviStream, 0, streamLength, waveData, streamLength, 0, 0)
        If (result <> 0) Then Throw New Exception("Exception in AVIStreamRead: " + result.ToString())

        Return waveData
    End Function
    ''' 	 <summary>Copy the stream into a new file</summary>
    '''<param name="fileName">Name of the new file</param>
    Public Overrides Sub ExportStream(ByVal fileName As String)
        Dim opts As Class_AVI.AVICOMPRESSOPTIONS_CLASS = New Class_AVI.AVICOMPRESSOPTIONS_CLASS()
        opts.fccType = CUInt(Class_AVI.mmioStringToFOURCC("auds", 0))
        opts.fccHandler = CUInt(Class_AVI.mmioStringToFOURCC("CAUD", 0))
        opts.dwKeyFrameEvery = 0
        opts.dwQuality = 0
        opts.dwFlags = 0
        opts.dwBytesPerSecond = 0
        opts.lpFormat = New IntPtr(0)
        opts.cbFormat = 0
        opts.lpParms = New IntPtr(0)
        opts.cbParms = 0
        opts.dwInterleaveEvery = 0
        Class_AVI.AVISaveV(fileName, 0, 0, 1, aviStream, opts)
    End Sub
End Class
