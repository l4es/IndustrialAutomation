﻿Imports System.Runtime.InteropServices
Imports System.Drawing.Imaging
Imports System.IO

Public Class Class_VideoStream : Inherits Class_AVIStream
    ''' <summary>handle for AVIStreamGetFrame</summary>
    Private getFrameObject As Integer

    ''' <summary>size of an imge in bytes, stride*height</summary>
    Private frameSize_int As Integer
    Public ReadOnly Property FrameSize() As Integer
        Get
            Return frameSize_int
        End Get
    End Property
    Protected frameRate_doule As Double
    Public ReadOnly Property FrameRate() As Double
        Get
            Return frameRate_doule
        End Get
    End Property
    Private width_int As Integer
    Public ReadOnly Property Width() As Integer
        Get
            Return width_int
        End Get
    End Property
    Private height_int As Integer
    Public ReadOnly Property Height() As Integer
        Get
            Return height_int
        End Get
    End Property
    Private countBitsPerPixel_Int16 As Int16
    Public ReadOnly Property CountBitsPerPixel() As Int16
        Get
            Return countBitsPerPixel_Int16
        End Get
    End Property

    ''' <summary>count of frames in the stream</summary>
    Protected countFrames_int As Integer = 0
    Public ReadOnly Property CountFrames() As Integer
        Get
            Return countFrames_int
        End Get
    End Property

    ''' <summary>Palette for indexed frames</summary>
    Protected palette_rgbquad() As Class_AVI.RGBQUAD
    Public ReadOnly Property palette() As Class_AVI.RGBQUAD()
        Get
            Return palette_rgbquad
        End Get
    End Property


    ''' <summary>initial frame index</summary>
    ''' <remarks>Added by M. Covington</remarks>
    Protected firstFrame_int As Integer = 0
    Public ReadOnly Property FirstFrame() As Integer
        Get
            Return firstFrame_int
        End Get
    End Property
    Private compressOptions_avioption As Class_AVI.AVICOMPRESSOPTIONS
    Public ReadOnly Property CompressOptions() As Class_AVI.AVICOMPRESSOPTIONS
        Get
            Return compressOptions_avioption
        End Get
    End Property
    Public ReadOnly Property StreamInfo() As Class_AVI.AVISTREAMINFO
        Get
            Return GetStreamInfo(aviStream)
        End Get
    End Property

    ''' <summary>
    ''' Initialize an empty VideoStream
    ''' </summary>
    ''' <param name="aviFile">The file that contains the stream</param>
    ''' <param name="writeCompressed">true: Create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="frameSize">Size of one frame in bytes</param>
    ''' <param name="width">Width of each image</param>
    ''' <param name="height">Height of each image</param>
    ''' <param name="format">PixelFormat of the images</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal aviFile As Integer, ByVal writeCompressed As Boolean, ByVal frameRate As Double, ByVal frameSize As Integer, ByVal width As Integer, ByVal height As Integer, ByVal format As System.Drawing.Imaging.PixelFormat)
        Me.aviFile = aviFile
        Me.writeCompressed_bool = writeCompressed
        Me.frameRate_doule = frameRate
        Me.frameSize_int = frameSize
        Me.width_int = width
        Me.height_int = height
        Me.countBitsPerPixel_Int16 = ConvertPixelFormatToBitCount(format)
        Me.firstFrame_int = 0
        CreateStream()
    End Sub
    ''' <summary>
    ''' Initialize a new VideoStream and add the first frame
    ''' </summary>
    ''' <param name="aviFile">The file that contains the stream</param>
    ''' <param name="writeCompressed">true: create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="firstFrame">Image to write into the stream as the first frame</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal aviFile As Integer, ByVal writeCompressed As Boolean, ByVal frameRate As Double, ByVal firstFrame As Bitmap)
        Initialize(aviFile, writeCompressed, frameRate, firstFrame)
        CreateStream()
        AddFrame(firstFrame)
    End Sub
    ''' <summary>
    ''' Initialize a new VideoStream and add the first frame
    ''' </summary>
    ''' <param name="aviFile">The file that contains the stream</param>
    ''' <param name="compressOptions">true: create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="firstFrame">Image to write into the stream as the first frame</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal aviFile As Integer, ByVal compressOptions As Class_AVI.AVICOMPRESSOPTIONS, ByVal frameRate As Double, ByVal firstFrame As Bitmap)
        Initialize(aviFile, True, frameRate, firstFrame)
        CreateStream(compressOptions)
        AddFrame(firstFrame)
    End Sub
    ''' <summary>
    ''' Initialize a VideoStream for an existing stream
    ''' </summary>
    ''' <param name="aviFile">The file that contains the stream</param>
    ''' <param name="aviStream">An IAVISTREAM from [aviFile]</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal aviFile As Integer, ByVal aviStream As IntPtr)
        Me.aviFile = aviFile
        Me.aviStream = aviStream
        Dim streamInfo As Class_AVI.AVISTREAMINFO = GetStreamInfo(aviStream)
        Dim bih As Class_AVI.BITMAPINFO = New Class_AVI.BITMAPINFO()
        Dim size As Integer = Marshal.SizeOf(bih.bmiHeader)
        Class_AVI.AVIStreamReadFormat(aviStream, 0, bih, size)

        If (bih.bmiHeader.biBitCount < 24) Then
            size = Marshal.SizeOf(bih.bmiHeader) + Class_AVI.PALETTE_SIZE
            Class_AVI.AVIStreamReadFormat(aviStream, 0, bih, size)
            CopyPalette(bih.bmiColors)
        End If
        Me.frameRate_doule = CSng(streamInfo.dwRate / streamInfo.dwScale)
        Me.width_int = CInt(streamInfo.rcFrame.right)
        Me.height_int = CInt(streamInfo.rcFrame.bottom)
        Me.frameSize_int = bih.bmiHeader.biSizeImage
        Me.countBitsPerPixel_Int16 = bih.bmiHeader.biBitCount
        Me.firstFrame_int = Class_AVI.AVIStreamStart(aviStream.ToInt32())
        Me.countFrames_int = Class_AVI.AVIStreamLength(aviStream.ToInt32())
    End Sub
    ''' <summary>
    ''' Copy all properties from one VideoStream to another one
    ''' </summary>
    ''' <param name="FrameSize"></param>
    ''' <param name="frameRate"></param>
    ''' <param name="width"></param>
    ''' <param name="height"></param>
    ''' <param name="countBitsPerPixel"></param>
    ''' <param name="countFrames"></param>
    ''' <param name="compressOptions"></param>
    ''' <param name="writeCompressed"></param>
    ''' <remarks>Used by EditableVideoStream</remarks>
    Friend Sub New(ByVal FrameSize As Integer, ByVal frameRate As Double, ByVal width As Integer, ByVal height As Integer, ByVal countBitsPerPixel As Int16, ByVal countFrames As Integer, ByVal compressOptions As Class_AVI.AVICOMPRESSOPTIONS, ByVal writeCompressed As Boolean)
        Me.frameSize_int = FrameSize
        Me.frameRate_doule = frameRate
        Me.width_int = width
        Me.height_int = height
        Me.countBitsPerPixel_Int16 = countBitsPerPixel
        Me.countFrames_int = countFrames
        Me.compressOptions_avioption = compressOptions
        Me.writeCompressed_bool = writeCompressed
        Me.firstFrame_int = 0
    End Sub

    ''' <summary>
    ''' Copy a palette
    ''' </summary>
    ''' <param name="template">Original palette</param>
    ''' <remarks></remarks>
    Private Sub CopyPalette(ByVal template As ColorPalette)

        '  Me.palette_rgbquad = New Class_AVI.RGBQUAD(template.Entries.Length) {}
        Me.palette_rgbquad = New Class_AVI.RGBQUAD(template.Entries.Length - 1) {}
        For n As Integer = 0 To Me.palette_rgbquad.Length - 1 Step 1
            If (n < template.Entries.Length) Then
                Me.palette_rgbquad(n).rgbRed = template.Entries(n).R
                Me.palette_rgbquad(n).rgbGreen = template.Entries(n).G
                Me.palette_rgbquad(n).rgbBlue = template.Entries(n).B
            Else
                Me.palette_rgbquad(n).rgbRed = 0
                Me.palette_rgbquad(n).rgbGreen = 0
                Me.palette_rgbquad(n).rgbBlue = 0
            End If

        Next
    End Sub
    ''' <summary>
    ''' Copy a palette
    ''' </summary>
    ''' <param name="template">Original palette</param>
    ''' <remarks></remarks>
    Private Sub CopyPalette(ByVal template As Class_AVI.RGBQUAD())
        Me.palette_rgbquad = New Class_AVI.RGBQUAD(template.Length) {}
        For n As Integer = 0 To Me.palette_rgbquad.Length - 1 Step 1
            If (n < template.Length) Then

                Me.palette_rgbquad(n).rgbRed = template(n).rgbRed
                Me.palette_rgbquad(n).rgbGreen = template(n).rgbGreen
                Me.palette_rgbquad(n).rgbBlue = template(n).rgbBlue

            Else

                Me.palette_rgbquad(n).rgbRed = 0
                Me.palette_rgbquad(n).rgbGreen = 0
                Me.palette_rgbquad(n).rgbBlue = 0

            End If
        Next
    End Sub
    ''' <summary>
    ''' Initialize a new VideoStream
    ''' </summary>
    ''' <param name="aviFile">The file that contains the stream</param>
    ''' <param name="writeCompressed">true: create a compressed stream before adding frames</param>
    ''' <param name="frameRate">Frames per second</param>
    ''' <param name="firstFrameBitmap">Image to write into the stream as the first frame</param>
    ''' <remarks>Used only by constructors</remarks>
    Private Sub Initialize(ByVal aviFile As Integer, ByVal writeCompressed As Boolean, ByVal frameRate As Double, ByVal firstFrameBitmap As Bitmap)
        Me.aviFile = aviFile
        Me.writeCompressed_bool = writeCompressed
        Me.frameRate_doule = frameRate
        Me.firstFrame_int = 0
        CopyPalette(firstFrameBitmap.Palette)
        Dim bmpData As BitmapData = firstFrameBitmap.LockBits(New Rectangle(0, 0, firstFrameBitmap.Width, firstFrameBitmap.Height), ImageLockMode.ReadOnly, firstFrameBitmap.PixelFormat)

        Me.frameSize_int = bmpData.Stride * bmpData.Height
        Me.width_int = firstFrameBitmap.Width
        Me.height_int = firstFrameBitmap.Height
        Me.countBitsPerPixel_Int16 = ConvertPixelFormatToBitCount(firstFrameBitmap.PixelFormat)
        firstFrameBitmap.UnlockBits(bmpData)
    End Sub
    ''' <summary>
    ''' Get the count of bits per pixel from a PixelFormat value
    ''' </summary>
    ''' <param name="format">One of the PixelFormat members beginning with "Format..." - all others are not supported</param>
    ''' <returns>bit count</returns>
    ''' <remarks></remarks>
    Private Function ConvertPixelFormatToBitCount(ByVal format As PixelFormat) As Int16
        Dim formatName As String = format.ToString()
        If (formatName.Substring(0, 6) <> "Format") Then
            Throw New Exception("Unknown pixel format: " + formatName)
        End If
        formatName = formatName.Substring(6, 2)
        Dim bitCount As Int16 = 0
        If (Char.IsNumber(formatName(1))) Then
            bitCount = Int16.Parse(formatName) '16, 32, 48
        Else
            bitCount = Int16.Parse(formatName(0).ToString()) '4, 8
        End If
        Return bitCount
    End Function
    ''' <summary>
    ''' Returns a PixelFormat value for a specific bit count
    ''' </summary>
    ''' <param name="bitCount">count of bits per pixel</param>
    ''' <returns>A PixelFormat value for [bitCount]</returns>
    ''' <remarks></remarks>
    Private Function ConvertBitCountToPixelFormat(ByVal bitCount As Integer) As PixelFormat
        Dim formatName As String
        If (bitCount > 16) Then
            formatName = String.Format("Format{0}bppRgb", bitCount)
        ElseIf (bitCount = 16) Then
            formatName = "Format16bppRgb555"
        Else
            formatName = String.Format("Format{0}bppIndexed", bitCount)
        End If
        Return CType([Enum].Parse(GetType(PixelFormat), formatName), PixelFormat)

    End Function
    Private Function GetStreamInfo(ByVal aviStream As IntPtr) As Class_AVI.AVISTREAMINFO
        Dim streamInfo As Class_AVI.AVISTREAMINFO = New Class_AVI.AVISTREAMINFO()
        Dim result As Integer = Class_AVI.AVIStreamInfo_implement(StreamPointer, streamInfo, Marshal.SizeOf(streamInfo))
        If (result <> 0) Then
            Throw New Exception("Exception in VideoStreamInfo: " + result.ToString())
        End If
        Return streamInfo

    End Function
    Private Sub GetRateAndScale(ByRef frameRate As Double, ByRef scale As Integer)
        scale = 1
        While (frameRate <> CLng(frameRate))
            frameRate = frameRate * 10
            scale = scale * 10
        End While
    End Sub
    ''' <summary>Create a new stream</summary>
    Private Sub CreateStreamWithoutFormat()
        Dim scale As Integer = 1
        Dim rate As Double = FrameRate
        GetRateAndScale(rate, scale)

        Dim strhdr As Class_AVI.AVISTREAMINFO = New Class_AVI.AVISTREAMINFO()

        strhdr.fccType = Class_AVI.mmioStringToFOURCC("vids", 0)
        strhdr.fccHandler = Class_AVI.mmioStringToFOURCC("CVID", 0)
        strhdr.dwFlags = 0
        strhdr.dwCaps = 0
        strhdr.wPriority = 0
        strhdr.wLanguage = 0
        strhdr.dwScale = CInt(scale)
        strhdr.dwRate = CInt(rate) ' Frames per Second
        strhdr.dwStart = 0
        strhdr.dwLength = 0
        strhdr.dwInitialFrames = 0
        strhdr.dwSuggestedBufferSize = frameSize_int  'height_ * stride_;
        strhdr.dwQuality = -1        'default
        strhdr.dwSampleSize = 0
        strhdr.rcFrame.top = 0
        strhdr.rcFrame.left = 0
        strhdr.rcFrame.bottom = CUInt(height_int)
        strhdr.rcFrame.right = CUInt(width_int)
        strhdr.dwEditCount = 0
        strhdr.dwFormatChangeCount = 0
        strhdr.szName = New UInt16(64) {}

        Dim result As Integer = Class_AVI.AVIFileCreateStream(aviFile, aviStream, strhdr)
        If (result <> 0) Then
            Throw New Exception("Exception in AVIFileCreateStream: " + result.ToString())
        End If




    End Sub
    ''' <summary>Create a new stream</summary>
    Private Sub CreateStream()
        CreateStreamWithoutFormat()

        If (WriteCompressed) Then
            CreateCompressedStream()
        Else
        End If
    End Sub
    ''' <summary>Create a new stream</summary>
    Private Sub CreateStream(ByVal options As Class_AVI.AVICOMPRESSOPTIONS)
        CreateStreamWithoutFormat()
        CreateCompressedStream(options)
    End Sub
    Private Sub CreateCompressedStream()
        'display the compression options dialog...
        'Dim options As Class_AVI.AVICOMPRESSOPTIONS_CLASS = New Class_AVI.AVICOMPRESSOPTIONS_CLASS()
        'options.fccType = CUInt(Class_AVI.streamtypeVIDEO)
        'options.lpParms = IntPtr.Zero
        'options.lpFormat = IntPtr.Zero
        Dim opts As Class_AVI.AVICOMPRESSOPTIONS = New Class_AVI.AVICOMPRESSOPTIONS()
        opts.fccType = CUInt(Class_AVI.mmioStringToFOURCC("vids", 0))
        '  opts.fccHandler = CUInt(Class_AVI.mmioStringToFOURCC("CVID", 0)) ' Compression format: Cinepack
        opts.fccHandler = CUInt(Class_AVI.mmioStringToFOURCC("xvid", 0))   ' Compression format:    xvid
        opts.dwKeyFrameEvery = 0
        opts.dwQuality = 0  ' 0 .. 10000
        opts.dwFlags = 4  ' AVICOMRPESSF_KEYFRAMES
        opts.dwBytesPerSecond = 0
        opts.lpFormat = New IntPtr(0)
        opts.cbFormat = 0
        opts.lpParms = New IntPtr(0)
        opts.cbParms = 0
        opts.dwInterleaveEvery = 0
        'get the compressed stream
        Me.compressOptions_avioption = opts

        Dim result As Integer = Class_AVI.AVIMakeCompressedStream(compressedStream, aviStream, compressOptions_avioption, 0)
        If (result <> 0) Then
            Throw New Exception("Exception in AVIMakeCompressedStream: " + " Xvid.exe not Install !")
        End If
        SetFormat(compressedStream, 0)
    End Sub
    Private Sub CreateCompressedStream(ByVal options As Class_AVI.AVICOMPRESSOPTIONS)
        Dim result As Integer = Class_AVI.AVIMakeCompressedStream(compressedStream, aviStream, options, 0)
        If (result <> 0) Then Throw New Exception("Exception in AVIMakeCompressedStream: " + result.ToString())
        Me.compressOptions_avioption = options
        SetFormat(compressedStream, 0)
    End Sub


    ''' <summary>
    ''' Add one frame to a new stream
    ''' </summary>
    ''' <param name="bmp"></param>
    ''' <remarks>
    ' This works only with uncompressed streams,
    ' and compressed streams that have not been saved yet.
    ' Use DecompressToNewFile to edit saved compressed streams.
    '''</remarks>
    Public Sub AddFrame(ByVal bmp As Bitmap)
        Dim result As Integer = 0
        If (CountFrames = 0) Then

            CopyPalette(bmp.Palette)
            If WriteCompressed = True Then
                SetFormat(compressedStream, countFrames_int)
            Else
                SetFormat(StreamPointer, countFrames_int)
            End If
        End If
        Dim bmpDat As BitmapData = bmp.LockBits(New Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, bmp.PixelFormat)
        If writeCompressed_bool = True Then
            result = Class_AVI.AVIStreamWrite(compressedStream, countFrames_int, 1, bmpDat.Scan0, CInt((bmpDat.Stride * bmpDat.Height)), 0, 0, 0)
        Else
            result = Class_AVI.AVIStreamWrite(StreamPointer, countFrames_int, 1, bmpDat.Scan0, CInt((bmpDat.Stride * bmpDat.Height)), 0, 0, 0)
        End If


        If (result <> 0) Then
            Throw New Exception("Exception in VideoStreamWrite: " + result.ToString())
        End If
        bmp.UnlockBits(bmpDat)
        countFrames_int = countFrames_int + 1
    End Sub
    ''' <summary>
    ''' Apply a format to a new stream
    ''' </summary>
    ''' <param name="aviStream">The IAVISTREAM</param>
    ''' <param name="writePosition"></param>
    ''' <remarks> The format must be set before the first frame can be written,
    'and it cannot be changed later.
    '''</remarks>
    Private Sub SetFormat(ByVal aviStream As IntPtr, ByVal writePosition As Integer)
        Dim bi As Class_AVI.BITMAPINFO = New Class_AVI.BITMAPINFO()
        bi.bmiHeader.biWidth = width_int
        bi.bmiHeader.biHeight = height_int
        bi.bmiHeader.biPlanes = 1
        bi.bmiHeader.biBitCount = countBitsPerPixel_Int16
        bi.bmiHeader.biSizeImage = frameSize_int
        bi.bmiHeader.biSize = Marshal.SizeOf(bi.bmiHeader)

        If (CountBitsPerPixel < 24) Then

            bi.bmiHeader.biClrUsed = Me.palette_rgbquad.Length
            bi.bmiHeader.biClrImportant = Me.palette_rgbquad.Length
            bi.bmiColors = New Class_AVI.RGBQUAD(Me.palette_rgbquad.Length) {}
            Me.palette_rgbquad.CopyTo(bi.bmiColors, 0)
            bi.bmiHeader.biSize += bi.bmiColors.Length * Class_AVI.RGBQUAD_SIZE

        End If
        Dim result As Integer = Class_AVI.AVIStreamSetFormat(aviStream, writePosition, bi, bi.bmiHeader.biSize)
        If (result <> 0) Then Throw New Exception("Error in VideoStreamSetFormat: " + result.ToString("X"))
    End Sub
    ''' <summary>
    ''' Prepare for decompressing frames
    ''' </summary>
    ''' <remarks>Release ressources with GetFrameClose.</remarks>
    Public Sub GetFrameOpen()
        Dim streamInfo As Class_AVI.AVISTREAMINFO = GetStreamInfo(StreamPointer)

        'Open frames

        Dim bih As Class_AVI.BITMAPINFOHEADER = New Class_AVI.BITMAPINFOHEADER()
        bih.biBitCount = CountBitsPerPixel
        bih.biClrImportant = 0
        bih.biClrUsed = 0
        bih.biCompression = 0
        bih.biPlanes = 1
        bih.biSize = Marshal.SizeOf(bih)
        bih.biXPelsPerMeter = 0
        bih.biYPelsPerMeter = 0

        bih.biHeight = 0 ' was (Int32)streamInfo.rcFrame.bottom;
        bih.biWidth = 0 ' was (Int32)streamInfo.rcFrame.right;
        If (bih.biBitCount > 24) Then

            bih.biBitCount = 32

        ElseIf (bih.biBitCount > 16) Then

            bih.biBitCount = 24

        ElseIf (bih.biBitCount > 8) Then

            bih.biBitCount = 16

        ElseIf (bih.biBitCount > 4) Then

            bih.biBitCount = 8

        ElseIf (bih.biBitCount > 0) Then

            bih.biBitCount = 4
        End If

        getFrameObject = Class_AVI.AVIStreamGetFrameOpen(StreamPointer, bih)

        If (getFrameObject = 0) Then Throw New Exception("Exception in VideoStreamGetFrameOpen!")
    End Sub
    ''' <summary>
    ''' Export a frame into a bitmap file
    ''' </summary>
    ''' <param name="position">Position of the frame</param>
    ''' <param name="dstFileName">Name of the file to store the bitmap</param>
    ''' <remarks></remarks>
    Public Sub ExportBitmap(ByVal position As Integer, ByVal dstFileName As String)
        Dim bmp As Bitmap = GetBitmap(position)
        bmp.Save(dstFileName, ImageFormat.Bmp)
        bmp.Dispose()
    End Sub
    ''' <summary>
    ''' Export a frame into a bitmap
    ''' </summary>
    ''' <param name="position">Position of the frame</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetBitmap(ByVal position As Integer) As Bitmap
        If (position > CountFrames) Then Throw New Exception("Invalid frame position: " & position)
        Dim streamInfo As Class_AVI.AVISTREAMINFO = GetStreamInfo(StreamPointer)

        Dim bih As Class_AVI.BITMAPINFO = New Class_AVI.BITMAPINFO()
        Dim headerSize As Integer = Marshal.SizeOf(bih.bmiHeader)
        'Decompress the frame and return a pointer to the DIB
        Dim dib As Integer = Class_AVI.AVIStreamGetFrame(getFrameObject, firstFrame_int + position)
        'Copy the bitmap header into a managed struct
        bih.bmiColors = Me.palette_rgbquad
        bih.bmiHeader = CType(Marshal.PtrToStructure(New IntPtr(dib), bih.bmiHeader.GetType()), Class_AVI.BITMAPINFOHEADER)
        If (bih.bmiHeader.biSizeImage < 1) Then Throw New Exception("Exception in VideoStreamGetFrame")
        'copy the image			
        Dim framePaletteSize As Integer = bih.bmiHeader.biClrUsed * Class_AVI.RGBQUAD_SIZE
        Dim bitmapData As Byte() = New Byte(bih.bmiHeader.biSizeImage) {}
        Dim dibPointer As IntPtr = New IntPtr(dib + Marshal.SizeOf(bih.bmiHeader) + framePaletteSize)
        Marshal.Copy(dibPointer, bitmapData, 0, bih.bmiHeader.biSizeImage)
        'copy bitmap info
        Dim bitmapInfo As Byte() = New Byte(Marshal.SizeOf(bih)) {}
        Dim ptr As IntPtr = Marshal.AllocHGlobal(bitmapInfo.Length)
        Marshal.StructureToPtr(bih, ptr, False)
        Marshal.Copy(ptr, bitmapInfo, 0, bitmapInfo.Length)
        Marshal.FreeHGlobal(ptr)
        'create file header
        Dim bfh As Class_AVI.BITMAPFILEHEADER = New Class_AVI.BITMAPFILEHEADER()
        bfh.bfType = Class_AVI.BMP_MAGIC_COOKIE
        bfh.bfSize = CInt((55 + bih.bmiHeader.biSizeImage)) 'size of file as written to disk
        bfh.bfReserved1 = 0
        bfh.bfReserved2 = 0
        bfh.bfOffBits = Marshal.SizeOf(bih) + Marshal.SizeOf(bfh)
        If (bih.bmiHeader.biBitCount < 8) Then bfh.bfOffBits += bih.bmiHeader.biClrUsed * Class_AVI.RGBQUAD_SIZE
        'write a bitmap stream
        Dim bw As BinaryWriter = New BinaryWriter(New MemoryStream())
        'write header
        bw.Write(bfh.bfType)
        bw.Write(bfh.bfSize)
        bw.Write(bfh.bfReserved1)
        bw.Write(bfh.bfReserved2)
        bw.Write(bfh.bfOffBits)
        'write bitmap info
        bw.Write(bitmapInfo)
        'write bitmap data
        bw.Write(bitmapData)
        Dim bmp As Bitmap = CType(Image.FromStream(bw.BaseStream), Bitmap)
        Dim saveableBitmap As Bitmap = New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(saveableBitmap)
        g.DrawImage(bmp, 0, 0)
        g.Dispose()
        bmp.Dispose()
        bw.Close()
        Return saveableBitmap
    End Function
    ''' <summary>Free ressources that have been used by GetFrameOpen</summary>
    Public Sub GetFrameClose()
        If (getFrameObject <> 0) Then
            Class_AVI.AVIStreamGetFrameClose(getFrameObject)
            getFrameObject = 0
        End If
    End Sub
    ''' <summary>Copy all frames into a new file</summary>
    ''' <param name="fileName">Name of the new file</param>
    ''' <param name="recompress">true: Compress the new stream</param>
    ''' <returns>AviManager for the new file</returns>
    ''' <remarks>Use this method if you want to append frames to an existing, compressed stream</remarks>
    Public Function DecompressToNewFile(ByVal fileName As String, ByVal recompress As Boolean, ByVal newStream2 As Class_VideoStream) As Class_AVIManager
        Dim newFile As Class_AVIManager = New Class_AVIManager(fileName, False)

        Me.GetFrameOpen()

        Dim frame As Bitmap = GetBitmap(0)
        Dim newStream As Class_VideoStream = newFile.AddVideoStream(recompress, FrameRate, frame)
        frame.Dispose()

        For n As Integer = 1 To CountFrames - 1 Step 1
            frame = GetBitmap(n)
            newStream.AddFrame(frame)
            frame.Dispose()
        Next
        Me.GetFrameClose()
        newStream2 = newStream
        Return newFile
    End Function

    ''' <summary>Copy the stream into a new file</summary>
    ''' <param name="fileName">Name of the new file</param>
    Public Overrides Sub ExportStream(ByVal fileName As String)
        Dim opts As Class_AVI.AVICOMPRESSOPTIONS_CLASS = New Class_AVI.AVICOMPRESSOPTIONS_CLASS()
        opts.fccType = CUInt(Class_AVI.streamtypeVIDEO)
        opts.lpParms = IntPtr.Zero
        opts.lpFormat = IntPtr.Zero
        Dim StreamPointer As IntPtr = StreamPointer
        Class_AVI.AVISaveOptions(IntPtr.Zero, Class_AVI.ICMF_CHOOSE_KEYFRAME Or Class_AVI.ICMF_CHOOSE_DATARATE, 1, StreamPointer, opts)
        Class_AVI.AVISaveOptionsFree(1, opts)
        Class_AVI.AVISaveV(fileName, 0, 0, 1, aviStream, opts)
    End Sub

End Class





