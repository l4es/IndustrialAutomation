﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Dim DesignerRectTracker1 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems1 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems2 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker2 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker3 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems3 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems4 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker4 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker5 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems5 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems6 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker6 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label_FramesPerSec = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.btn_VideoInControls = New CustomControlsLib.MyButton
        Me.Label_Resolution = New System.Windows.Forms.Label
        Me.ComboBox_VideoInputDevice = New CustomControlsLib.MyComboBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_VideoinControls = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.Tool_VideoInControls = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Tool_Instructions_ENG = New System.Windows.Forms.ToolStripButton
        Me.Tool_Instructions_ITA = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Tool_XvidInstall = New System.Windows.Forms.ToolStripButton
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.PictureBox_CpuMillisec = New System.Windows.Forms.PictureBox
        Me.PictureBox_ProcessCPU = New System.Windows.Forms.PictureBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.PictureBox_TotalCpu = New System.Windows.Forms.PictureBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Timer_1Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txt_ShiftX = New CustomControlsLib.MyTextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txt_ShiftY = New CustomControlsLib.MyTextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txt_Zoom = New CustomControlsLib.MyTextBox
        Me.CheckBox_FlipY = New System.Windows.Forms.CheckBox
        Me.CheckBox_FlipX = New System.Windows.Forms.CheckBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_ImageName = New CustomControlsLib.MyTextBox
        Me.ComboBox_FileType = New CustomControlsLib.MyComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_ImagePath = New CustomControlsLib.MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.MyButton_SaveImageFile = New CustomControlsLib.MyButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label_FirstSlot = New System.Windows.Forms.Label
        Me.txt_AutosaveSlot = New CustomControlsLib.MyTextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_CrossSize = New CustomControlsLib.MyTextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txt_CrossColor = New CustomControlsLib.MyTextBox
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CloseProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.btn_VideoRecord = New CustomControlsLib.MyButton
        Me.Label10 = New System.Windows.Forms.Label
        Me.txt_VideoSlotrigger_Save = New CustomControlsLib.MyTextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txt_VideoSlotrigger_Ready = New CustomControlsLib.MyTextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txt_VideoPath_Save = New CustomControlsLib.MyTextBox
        Me.txt_VideoName = New CustomControlsLib.MyTextBox
        Me.Label12 = New System.Windows.Forms.Label
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox_CpuMillisec, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_ProcessCPU, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_TotalCpu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Cornsilk
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(6, 55)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(387, 622)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label_FramesPerSec
        '
        Me.Label_FramesPerSec.BackColor = System.Drawing.Color.MintCream
        Me.Label_FramesPerSec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_FramesPerSec.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FramesPerSec.Location = New System.Drawing.Point(238, 52)
        Me.Label_FramesPerSec.Name = "Label_FramesPerSec"
        Me.Label_FramesPerSec.Size = New System.Drawing.Size(51, 18)
        Me.Label_FramesPerSec.TabIndex = 65
        Me.Label_FramesPerSec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox4.Controls.Add(Me.btn_VideoInControls)
        Me.GroupBox4.Controls.Add(Me.Label_Resolution)
        Me.GroupBox4.Controls.Add(Me.ComboBox_VideoInputDevice)
        Me.GroupBox4.Controls.Add(Me.Label_FramesPerSec)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(399, 57)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(297, 80)
        Me.GroupBox4.TabIndex = 70
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Video Input Device"
        '
        'btn_VideoInControls
        '
        Me.btn_VideoInControls.BorderShow = False
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoInControls.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_VideoInControls.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems2.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_VideoInControls.ColorFillBlendChecked = CBlendItems2
        Me.btn_VideoInControls.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_VideoInControls.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_VideoInControls.Corners.All = CType(6, Short)
        Me.btn_VideoInControls.Corners.LowerLeft = CType(6, Short)
        Me.btn_VideoInControls.Corners.LowerRight = CType(6, Short)
        Me.btn_VideoInControls.Corners.UpperLeft = CType(6, Short)
        Me.btn_VideoInControls.Corners.UpperRight = CType(6, Short)
        Me.btn_VideoInControls.DimFactorOver = 30
        Me.btn_VideoInControls.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_VideoInControls.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearHorizontal
        Me.btn_VideoInControls.FocalPoints.CenterPtX = 0.4765625!
        Me.btn_VideoInControls.FocalPoints.CenterPtY = 0.5!
        Me.btn_VideoInControls.FocalPoints.FocusPtX = 0.0!
        Me.btn_VideoInControls.FocalPoints.FocusPtY = 0.0!
        Me.btn_VideoInControls.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_VideoInControls.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_VideoInControls.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_VideoInControls.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoInControls.FocusPtTracker = DesignerRectTracker2
        Me.btn_VideoInControls.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_VideoInControls.Image = Nothing
        Me.btn_VideoInControls.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoInControls.ImageIndex = 0
        Me.btn_VideoInControls.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_VideoInControls.Location = New System.Drawing.Point(12, 52)
        Me.btn_VideoInControls.Name = "btn_VideoInControls"
        Me.btn_VideoInControls.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_VideoInControls.SideImage = Nothing
        Me.btn_VideoInControls.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_VideoInControls.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_VideoInControls.Size = New System.Drawing.Size(128, 19)
        Me.btn_VideoInControls.TabIndex = 68
        Me.btn_VideoInControls.Text = "Video-in Controls"
        Me.btn_VideoInControls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoInControls.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_VideoInControls.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_VideoInControls.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_Resolution
        '
        Me.Label_Resolution.BackColor = System.Drawing.Color.MintCream
        Me.Label_Resolution.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Resolution.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Resolution.Location = New System.Drawing.Point(147, 52)
        Me.Label_Resolution.Name = "Label_Resolution"
        Me.Label_Resolution.Size = New System.Drawing.Size(85, 18)
        Me.Label_Resolution.TabIndex = 66
        Me.Label_Resolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_VideoInputDevice
        '
        Me.ComboBox_VideoInputDevice.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoInputDevice.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.ComboBox_VideoInputDevice.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BorderSize = 1
        Me.ComboBox_VideoInputDevice.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoInputDevice.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDownHeight = 318
        Me.ComboBox_VideoInputDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoInputDevice.DropDownWidth = 280
        Me.ComboBox_VideoInputDevice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoInputDevice.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoInputDevice.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoInputDevice.IntegralHeight = False
        Me.ComboBox_VideoInputDevice.Items.AddRange(New Object() {"Auto"})
        Me.ComboBox_VideoInputDevice.Location = New System.Drawing.Point(12, 22)
        Me.ComboBox_VideoInputDevice.Name = "ComboBox_VideoInputDevice"
        Me.ComboBox_VideoInputDevice.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoInputDevice.Size = New System.Drawing.Size(278, 23)
        Me.ComboBox_VideoInputDevice.TabIndex = 32
        Me.ComboBox_VideoInputDevice.TextPosition = 4
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.ToolsToolStripMenuItem, Me.Menu_Help})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(704, 24)
        Me.MenuStrip1.TabIndex = 72
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator3, Me.Menu_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(89, 6)
        '
        'Menu_Exit
        '
        Me.Menu_Exit.Name = "Menu_Exit"
        Me.Menu_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_Exit.Text = "Exit"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_VideoinControls})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'Menu_VideoinControls
        '
        Me.Menu_VideoinControls.Image = CType(resources.GetObject("Menu_VideoinControls.Image"), System.Drawing.Image)
        Me.Menu_VideoinControls.Name = "Menu_VideoinControls"
        Me.Menu_VideoinControls.Size = New System.Drawing.Size(167, 22)
        Me.Menu_VideoinControls.Text = "Video-in Controls"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp_ENG, Me.Menu_Help_ProgramHelp_ITA, Me.Menu_About})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp_ENG
        '
        Me.Menu_Help_ProgramHelp_ENG.Image = CType(resources.GetObject("Menu_Help_ProgramHelp_ENG.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp_ENG.Name = "Menu_Help_ProgramHelp_ENG"
        Me.Menu_Help_ProgramHelp_ENG.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp_ENG.Text = "Program help ( ENG )"
        '
        'Menu_Help_ProgramHelp_ITA
        '
        Me.Menu_Help_ProgramHelp_ITA.Image = CType(resources.GetObject("Menu_Help_ProgramHelp_ITA.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp_ITA.Name = "Menu_Help_ProgramHelp_ITA"
        Me.Menu_Help_ProgramHelp_ITA.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp_ITA.Text = "Program help ( ITA )"
        '
        'Menu_About
        '
        Me.Menu_About.Image = CType(resources.GetObject("Menu_About.Image"), System.Drawing.Image)
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(186, 22)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tool_VideoInControls, Me.ToolStripSeparator2, Me.ToolStripSeparator4, Me.Tool_Instructions_ENG, Me.Tool_Instructions_ITA, Me.ToolStripSeparator1, Me.Tool_XvidInstall})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(704, 25)
        Me.ToolStrip1.TabIndex = 73
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tool_VideoInControls
        '
        Me.Tool_VideoInControls.Image = CType(resources.GetObject("Tool_VideoInControls.Image"), System.Drawing.Image)
        Me.Tool_VideoInControls.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_VideoInControls.Name = "Tool_VideoInControls"
        Me.Tool_VideoInControls.Size = New System.Drawing.Size(120, 22)
        Me.Tool_VideoInControls.Text = "Video-in Controls"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'Tool_Instructions_ENG
        '
        Me.Tool_Instructions_ENG.Image = CType(resources.GetObject("Tool_Instructions_ENG.Image"), System.Drawing.Image)
        Me.Tool_Instructions_ENG.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_Instructions_ENG.Name = "Tool_Instructions_ENG"
        Me.Tool_Instructions_ENG.Size = New System.Drawing.Size(125, 22)
        Me.Tool_Instructions_ENG.Text = "Program help ENG"
        '
        'Tool_Instructions_ITA
        '
        Me.Tool_Instructions_ITA.Image = CType(resources.GetObject("Tool_Instructions_ITA.Image"), System.Drawing.Image)
        Me.Tool_Instructions_ITA.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_Instructions_ITA.Name = "Tool_Instructions_ITA"
        Me.Tool_Instructions_ITA.Size = New System.Drawing.Size(119, 22)
        Me.Tool_Instructions_ITA.Text = "Program help ITA"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'Tool_XvidInstall
        '
        Me.Tool_XvidInstall.Image = CType(resources.GetObject("Tool_XvidInstall.Image"), System.Drawing.Image)
        Me.Tool_XvidInstall.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_XvidInstall.Name = "Tool_XvidInstall"
        Me.Tool_XvidInstall.Size = New System.Drawing.Size(84, 22)
        Me.Tool_XvidInstall.Text = "Xvid Install"
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox6.Controls.Add(Me.PictureBox_CpuMillisec)
        Me.GroupBox6.Controls.Add(Me.PictureBox_ProcessCPU)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.PictureBox_TotalCpu)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(399, 142)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(297, 72)
        Me.GroupBox6.TabIndex = 74
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "System"
        '
        'PictureBox_CpuMillisec
        '
        Me.PictureBox_CpuMillisec.BackColor = System.Drawing.Color.MintCream
        Me.PictureBox_CpuMillisec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_CpuMillisec.Location = New System.Drawing.Point(92, 22)
        Me.PictureBox_CpuMillisec.Name = "PictureBox_CpuMillisec"
        Me.PictureBox_CpuMillisec.Size = New System.Drawing.Size(64, 18)
        Me.PictureBox_CpuMillisec.TabIndex = 80
        Me.PictureBox_CpuMillisec.TabStop = False
        '
        'PictureBox_ProcessCPU
        '
        Me.PictureBox_ProcessCPU.BackColor = System.Drawing.Color.MintCream
        Me.PictureBox_ProcessCPU.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_ProcessCPU.Location = New System.Drawing.Point(160, 22)
        Me.PictureBox_ProcessCPU.Name = "PictureBox_ProcessCPU"
        Me.PictureBox_ProcessCPU.Size = New System.Drawing.Size(130, 18)
        Me.PictureBox_ProcessCPU.TabIndex = 79
        Me.PictureBox_ProcessCPU.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(11, 22)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 14)
        Me.Label24.TabIndex = 78
        Me.Label24.Text = "CPU usage"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox_TotalCpu
        '
        Me.PictureBox_TotalCpu.BackColor = System.Drawing.Color.MintCream
        Me.PictureBox_TotalCpu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_TotalCpu.Location = New System.Drawing.Point(160, 44)
        Me.PictureBox_TotalCpu.Name = "PictureBox_TotalCpu"
        Me.PictureBox_TotalCpu.Size = New System.Drawing.Size(129, 18)
        Me.PictureBox_TotalCpu.TabIndex = 77
        Me.PictureBox_TotalCpu.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(11, 46)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(112, 14)
        Me.Label20.TabIndex = 76
        Me.Label20.Text = "CPU usage ( total )"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer_1Hz
        '
        '
        'GroupBox10
        '
        Me.GroupBox10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox10.Controls.Add(Me.Label17)
        Me.GroupBox10.Controls.Add(Me.txt_ShiftX)
        Me.GroupBox10.Controls.Add(Me.Label18)
        Me.GroupBox10.Controls.Add(Me.txt_ShiftY)
        Me.GroupBox10.Controls.Add(Me.Label19)
        Me.GroupBox10.Controls.Add(Me.txt_Zoom)
        Me.GroupBox10.Controls.Add(Me.CheckBox_FlipY)
        Me.GroupBox10.Controls.Add(Me.CheckBox_FlipX)
        Me.GroupBox10.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(399, 219)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(190, 87)
        Me.GroupBox10.TabIndex = 92
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Conversions"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(95, 20)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(43, 14)
        Me.Label17.TabIndex = 99
        Me.Label17.Text = "Shift X"
        '
        'txt_ShiftX
        '
        Me.txt_ShiftX.ArrowsIncrement = 1
        Me.txt_ShiftX.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ShiftX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ShiftX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ShiftX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ShiftX.Increment = 0.2
        Me.txt_ShiftX.Location = New System.Drawing.Point(139, 18)
        Me.txt_ShiftX.MaxValue = 100
        Me.txt_ShiftX.MinValue = -100
        Me.txt_ShiftX.Multiline = True
        Me.txt_ShiftX.Name = "txt_ShiftX"
        Me.txt_ShiftX.NumericValue = 0
        Me.txt_ShiftX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ShiftX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ShiftX.RoundingStep = 0
        Me.txt_ShiftX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ShiftX.Size = New System.Drawing.Size(42, 19)
        Me.txt_ShiftX.SuppressZeros = True
        Me.txt_ShiftX.TabIndex = 98
        Me.txt_ShiftX.Text = "0"
        Me.txt_ShiftX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(95, 42)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(44, 14)
        Me.Label18.TabIndex = 97
        Me.Label18.Text = "Shift Y"
        '
        'txt_ShiftY
        '
        Me.txt_ShiftY.ArrowsIncrement = 1
        Me.txt_ShiftY.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ShiftY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ShiftY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ShiftY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ShiftY.Increment = 0.2
        Me.txt_ShiftY.Location = New System.Drawing.Point(139, 40)
        Me.txt_ShiftY.MaxValue = 100
        Me.txt_ShiftY.MinValue = -100
        Me.txt_ShiftY.Multiline = True
        Me.txt_ShiftY.Name = "txt_ShiftY"
        Me.txt_ShiftY.NumericValue = 0
        Me.txt_ShiftY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ShiftY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ShiftY.RoundingStep = 0
        Me.txt_ShiftY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ShiftY.Size = New System.Drawing.Size(42, 19)
        Me.txt_ShiftY.SuppressZeros = True
        Me.txt_ShiftY.TabIndex = 96
        Me.txt_ShiftY.Text = "0"
        Me.txt_ShiftY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(96, 64)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 14)
        Me.Label19.TabIndex = 95
        Me.Label19.Text = "Zoom"
        '
        'txt_Zoom
        '
        Me.txt_Zoom.ArrowsIncrement = 0.01
        Me.txt_Zoom.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_Zoom.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Zoom.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Zoom.Decimals = 2
        Me.txt_Zoom.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Zoom.Increment = 0.01
        Me.txt_Zoom.Location = New System.Drawing.Point(139, 62)
        Me.txt_Zoom.MaxValue = 8
        Me.txt_Zoom.MinValue = 1
        Me.txt_Zoom.Multiline = True
        Me.txt_Zoom.Name = "txt_Zoom"
        Me.txt_Zoom.NumericValue = 1
        Me.txt_Zoom.NumericValueInteger = 1
        Me.txt_Zoom.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Zoom.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Zoom.RoundingStep = 0
        Me.txt_Zoom.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Zoom.Size = New System.Drawing.Size(42, 19)
        Me.txt_Zoom.SuppressZeros = True
        Me.txt_Zoom.TabIndex = 94
        Me.txt_Zoom.Text = "1"
        Me.txt_Zoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_FlipY
        '
        Me.CheckBox_FlipY.AutoSize = True
        Me.CheckBox_FlipY.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipY.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_FlipY.Location = New System.Drawing.Point(22, 58)
        Me.CheckBox_FlipY.Name = "CheckBox_FlipY"
        Me.CheckBox_FlipY.Size = New System.Drawing.Size(55, 18)
        Me.CheckBox_FlipY.TabIndex = 93
        Me.CheckBox_FlipY.Text = "Flip Y"
        Me.CheckBox_FlipY.UseVisualStyleBackColor = True
        '
        'CheckBox_FlipX
        '
        Me.CheckBox_FlipX.AutoSize = True
        Me.CheckBox_FlipX.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipX.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_FlipX.Location = New System.Drawing.Point(23, 36)
        Me.CheckBox_FlipX.Name = "CheckBox_FlipX"
        Me.CheckBox_FlipX.Size = New System.Drawing.Size(54, 18)
        Me.CheckBox_FlipX.TabIndex = 92
        Me.CheckBox_FlipX.Text = "Flip X"
        Me.CheckBox_FlipX.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(17, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 16)
        Me.Label3.TabIndex = 100
        Me.Label3.Text = "Path"
        '
        'txt_ImageName
        '
        Me.txt_ImageName.ArrowsIncrement = 0
        Me.txt_ImageName.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ImageName.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ImageName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ImageName.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ImageName.Increment = 0
        Me.txt_ImageName.Location = New System.Drawing.Point(8, 98)
        Me.txt_ImageName.MaxValue = 0
        Me.txt_ImageName.MinValue = 0
        Me.txt_ImageName.Multiline = True
        Me.txt_ImageName.Name = "txt_ImageName"
        Me.txt_ImageName.NumericValue = 0
        Me.txt_ImageName.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ImageName.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ImageName.RoundingStep = 0
        Me.txt_ImageName.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ImageName.Size = New System.Drawing.Size(202, 21)
        Me.txt_ImageName.TabIndex = 99
        Me.txt_ImageName.Text = "Image"
        Me.txt_ImageName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_ImageName.WordWrap = False
        '
        'ComboBox_FileType
        '
        Me.ComboBox_FileType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_FileType.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_FileType.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.ComboBox_FileType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.BorderColor = System.Drawing.Color.PowderBlue
        Me.ComboBox_FileType.BorderSize = 1
        Me.ComboBox_FileType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_FileType.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDownHeight = 318
        Me.ComboBox_FileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FileType.DropDownWidth = 80
        Me.ComboBox_FileType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_FileType.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_FileType.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_FileType.IntegralHeight = False
        Me.ComboBox_FileType.Location = New System.Drawing.Point(221, 96)
        Me.ComboBox_FileType.Name = "ComboBox_FileType"
        Me.ComboBox_FileType.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_FileType.Size = New System.Drawing.Size(67, 22)
        Me.ComboBox_FileType.TabIndex = 95
        Me.ComboBox_FileType.TextPosition = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(17, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 16)
        Me.Label2.TabIndex = 98
        Me.Label2.Text = "Name"
        '
        'txt_ImagePath
        '
        Me.txt_ImagePath.ArrowsIncrement = 0
        Me.txt_ImagePath.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ImagePath.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ImagePath.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ImagePath.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ImagePath.Increment = 0
        Me.txt_ImagePath.Location = New System.Drawing.Point(8, 45)
        Me.txt_ImagePath.MaxValue = 0
        Me.txt_ImagePath.MinValue = 0
        Me.txt_ImagePath.Multiline = True
        Me.txt_ImagePath.Name = "txt_ImagePath"
        Me.txt_ImagePath.NumericValue = 0
        Me.txt_ImagePath.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ImagePath.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Solid
        Me.txt_ImagePath.RoundingStep = 0
        Me.txt_ImagePath.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ImagePath.Size = New System.Drawing.Size(281, 35)
        Me.txt_ImagePath.TabIndex = 97
        Me.txt_ImagePath.Text = "   "
        Me.txt_ImagePath.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(210, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(13, 16)
        Me.Label1.TabIndex = 96
        Me.Label1.Text = "."
        '
        'MyButton_SaveImageFile
        '
        Me.MyButton_SaveImageFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MyButton_SaveImageFile.BorderShow = False
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_SaveImageFile.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_SaveImageFile.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_SaveImageFile.ColorFillBlendChecked = CBlendItems4
        Me.MyButton_SaveImageFile.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.MyButton_SaveImageFile.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_SaveImageFile.Corners.All = CType(9, Short)
        Me.MyButton_SaveImageFile.Corners.LowerLeft = CType(9, Short)
        Me.MyButton_SaveImageFile.Corners.LowerRight = CType(9, Short)
        Me.MyButton_SaveImageFile.Corners.UpperLeft = CType(9, Short)
        Me.MyButton_SaveImageFile.Corners.UpperRight = CType(9, Short)
        Me.MyButton_SaveImageFile.DimFactorOver = 30
        Me.MyButton_SaveImageFile.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.MyButton_SaveImageFile.FillTypeChecked = CustomControlsLib.MyButton.eFillType.GradientPath
        Me.MyButton_SaveImageFile.FocalPoints.CenterPtX = 0.476489!
        Me.MyButton_SaveImageFile.FocalPoints.CenterPtY = 0.3888889!
        Me.MyButton_SaveImageFile.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_SaveImageFile.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_SaveImageFile.FocalPointsChecked.CenterPtX = 0.492163!
        Me.MyButton_SaveImageFile.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.MyButton_SaveImageFile.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.MyButton_SaveImageFile.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_SaveImageFile.FocusPtTracker = DesignerRectTracker4
        Me.MyButton_SaveImageFile.Image = Nothing
        Me.MyButton_SaveImageFile.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_SaveImageFile.ImageIndex = 0
        Me.MyButton_SaveImageFile.ImageSize = New System.Drawing.Size(48, 48)
        Me.MyButton_SaveImageFile.Location = New System.Drawing.Point(398, 641)
        Me.MyButton_SaveImageFile.Name = "MyButton_SaveImageFile"
        Me.MyButton_SaveImageFile.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.MyButton_SaveImageFile.SideImage = Nothing
        Me.MyButton_SaveImageFile.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_SaveImageFile.SideImageSize = New System.Drawing.Size(32, 32)
        Me.MyButton_SaveImageFile.Size = New System.Drawing.Size(297, 23)
        Me.MyButton_SaveImageFile.TabIndex = 94
        Me.MyButton_SaveImageFile.Text = "Save Image  ( SPACE BAR )"
        Me.MyButton_SaveImageFile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_SaveImageFile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.MyButton_SaveImageFile.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_SaveImageFile.TextShadow = System.Drawing.Color.Transparent
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Label_FirstSlot)
        Me.GroupBox2.Controls.Add(Me.txt_AutosaveSlot)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txt_ImagePath)
        Me.GroupBox2.Controls.Add(Me.txt_ImageName)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.ComboBox_FileType)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(399, 504)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(297, 125)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Output file"
        '
        'Label_FirstSlot
        '
        Me.Label_FirstSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FirstSlot.Location = New System.Drawing.Point(92, 27)
        Me.Label_FirstSlot.Name = "Label_FirstSlot"
        Me.Label_FirstSlot.Size = New System.Drawing.Size(146, 14)
        Me.Label_FirstSlot.TabIndex = 189
        Me.Label_FirstSlot.Text = "Automation slot trigger"
        Me.Label_FirstSlot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_AutosaveSlot
        '
        Me.txt_AutosaveSlot.ArrowsIncrement = 1
        Me.txt_AutosaveSlot.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_AutosaveSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AutosaveSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AutosaveSlot.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AutosaveSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_AutosaveSlot.Increment = 0.2
        Me.txt_AutosaveSlot.Location = New System.Drawing.Point(242, 25)
        Me.txt_AutosaveSlot.MaxValue = 999
        Me.txt_AutosaveSlot.MinValue = -1
        Me.txt_AutosaveSlot.Multiline = True
        Me.txt_AutosaveSlot.Name = "txt_AutosaveSlot"
        Me.txt_AutosaveSlot.NumericValue = -1
        Me.txt_AutosaveSlot.NumericValueInteger = -1
        Me.txt_AutosaveSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AutosaveSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AutosaveSlot.RoundingStep = 0
        Me.txt_AutosaveSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AutosaveSlot.Size = New System.Drawing.Size(46, 17)
        Me.txt_AutosaveSlot.SuppressZeros = True
        Me.txt_AutosaveSlot.TabIndex = 188
        Me.txt_AutosaveSlot.Text = "-1"
        Me.txt_AutosaveSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txt_CrossSize)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.txt_CrossColor)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(594, 221)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(102, 87)
        Me.GroupBox3.TabIndex = 96
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Cross cursor"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 14)
        Me.Label4.TabIndex = 99
        Me.Label4.Text = "Size"
        '
        'txt_CrossSize
        '
        Me.txt_CrossSize.ArrowsIncrement = 1
        Me.txt_CrossSize.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_CrossSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_CrossSize.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CrossSize.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CrossSize.Increment = 0.2
        Me.txt_CrossSize.Location = New System.Drawing.Point(47, 37)
        Me.txt_CrossSize.MaxValue = 900
        Me.txt_CrossSize.MinValue = 0
        Me.txt_CrossSize.Multiline = True
        Me.txt_CrossSize.Name = "txt_CrossSize"
        Me.txt_CrossSize.NumericValue = 0
        Me.txt_CrossSize.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_CrossSize.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_CrossSize.RoundingStep = 0
        Me.txt_CrossSize.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_CrossSize.Size = New System.Drawing.Size(42, 19)
        Me.txt_CrossSize.TabIndex = 98
        Me.txt_CrossSize.Text = "0"
        Me.txt_CrossSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 61)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 14)
        Me.Label5.TabIndex = 97
        Me.Label5.Text = "Color"
        '
        'txt_CrossColor
        '
        Me.txt_CrossColor.ArrowsIncrement = 1
        Me.txt_CrossColor.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_CrossColor.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_CrossColor.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CrossColor.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CrossColor.Increment = 0.2
        Me.txt_CrossColor.Location = New System.Drawing.Point(47, 59)
        Me.txt_CrossColor.MaxValue = 100
        Me.txt_CrossColor.MinValue = 0
        Me.txt_CrossColor.Multiline = True
        Me.txt_CrossColor.Name = "txt_CrossColor"
        Me.txt_CrossColor.NumericValue = 0
        Me.txt_CrossColor.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_CrossColor.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_CrossColor.RoundingStep = 0
        Me.txt_CrossColor.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_CrossColor.Size = New System.Drawing.Size(42, 19)
        Me.txt_CrossColor.TabIndex = 96
        Me.txt_CrossColor.Text = "0"
        Me.txt_CrossColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseProgramToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(153, 26)
        '
        'CloseProgramToolStripMenuItem
        '
        Me.CloseProgramToolStripMenuItem.Image = CType(resources.GetObject("CloseProgramToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseProgramToolStripMenuItem.Name = "CloseProgramToolStripMenuItem"
        Me.CloseProgramToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CloseProgramToolStripMenuItem.Text = "Close program"
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox7.Controls.Add(Me.btn_VideoRecord)
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.txt_VideoSlotrigger_Save)
        Me.GroupBox7.Controls.Add(Me.Label8)
        Me.GroupBox7.Controls.Add(Me.txt_VideoSlotrigger_Ready)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.txt_VideoPath_Save)
        Me.GroupBox7.Controls.Add(Me.txt_VideoName)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(399, 318)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(297, 172)
        Me.GroupBox7.TabIndex = 98
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Output video file"
        '
        'btn_VideoRecord
        '
        Me.btn_VideoRecord.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_VideoRecord.BorderColor = System.Drawing.Color.BlanchedAlmond
        Me.btn_VideoRecord.BorderShow = False
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoRecord.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_VideoRecord.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_VideoRecord.ColorFillBlendChecked = CBlendItems6
        Me.btn_VideoRecord.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_VideoRecord.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_VideoRecord.Corners.All = CType(9, Short)
        Me.btn_VideoRecord.Corners.LowerLeft = CType(9, Short)
        Me.btn_VideoRecord.Corners.LowerRight = CType(9, Short)
        Me.btn_VideoRecord.Corners.UpperLeft = CType(9, Short)
        Me.btn_VideoRecord.Corners.UpperRight = CType(9, Short)
        Me.btn_VideoRecord.DimFactorOver = 30
        Me.btn_VideoRecord.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_VideoRecord.FillTypeChecked = CustomControlsLib.MyButton.eFillType.GradientPath
        Me.btn_VideoRecord.FocalPoints.CenterPtX = 0.4055555!
        Me.btn_VideoRecord.FocalPoints.CenterPtY = 0.3333333!
        Me.btn_VideoRecord.FocalPoints.FocusPtX = 0.0!
        Me.btn_VideoRecord.FocalPoints.FocusPtY = 0.0!
        Me.btn_VideoRecord.FocalPointsChecked.CenterPtX = 0.492163!
        Me.btn_VideoRecord.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.btn_VideoRecord.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_VideoRecord.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoRecord.FocusPtTracker = DesignerRectTracker6
        Me.btn_VideoRecord.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_VideoRecord.ForeColorChecked = System.Drawing.Color.DarkGray
        Me.btn_VideoRecord.Image = Nothing
        Me.btn_VideoRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoRecord.ImageIndex = 0
        Me.btn_VideoRecord.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_VideoRecord.Location = New System.Drawing.Point(6, 143)
        Me.btn_VideoRecord.Name = "btn_VideoRecord"
        Me.btn_VideoRecord.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_VideoRecord.SideImage = Nothing
        Me.btn_VideoRecord.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_VideoRecord.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_VideoRecord.Size = New System.Drawing.Size(278, 23)
        Me.btn_VideoRecord.TabIndex = 192
        Me.btn_VideoRecord.Text = "Start  Record"
        Me.btn_VideoRecord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoRecord.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_VideoRecord.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_VideoRecord.TextShadow = System.Drawing.Color.Transparent
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(158, 41)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 16)
        Me.Label10.TabIndex = 191
        Me.Label10.Text = "Save on event"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_VideoSlotrigger_Save
        '
        Me.txt_VideoSlotrigger_Save.ArrowsIncrement = 1
        Me.txt_VideoSlotrigger_Save.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_VideoSlotrigger_Save.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_VideoSlotrigger_Save.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_VideoSlotrigger_Save.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_VideoSlotrigger_Save.ForeColor = System.Drawing.Color.Black
        Me.txt_VideoSlotrigger_Save.Increment = 0.2
        Me.txt_VideoSlotrigger_Save.Location = New System.Drawing.Point(241, 41)
        Me.txt_VideoSlotrigger_Save.MaxValue = 999
        Me.txt_VideoSlotrigger_Save.MinValue = -1
        Me.txt_VideoSlotrigger_Save.Multiline = True
        Me.txt_VideoSlotrigger_Save.Name = "txt_VideoSlotrigger_Save"
        Me.txt_VideoSlotrigger_Save.NumericValue = -1
        Me.txt_VideoSlotrigger_Save.NumericValueInteger = -1
        Me.txt_VideoSlotrigger_Save.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_VideoSlotrigger_Save.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_VideoSlotrigger_Save.RoundingStep = 0
        Me.txt_VideoSlotrigger_Save.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_VideoSlotrigger_Save.Size = New System.Drawing.Size(46, 17)
        Me.txt_VideoSlotrigger_Save.SuppressZeros = True
        Me.txt_VideoSlotrigger_Save.TabIndex = 190
        Me.txt_VideoSlotrigger_Save.Text = "-1"
        Me.txt_VideoSlotrigger_Save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(158, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 16)
        Me.Label8.TabIndex = 189
        Me.Label8.Text = "Start recording"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_VideoSlotrigger_Ready
        '
        Me.txt_VideoSlotrigger_Ready.ArrowsIncrement = 1
        Me.txt_VideoSlotrigger_Ready.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_VideoSlotrigger_Ready.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_VideoSlotrigger_Ready.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_VideoSlotrigger_Ready.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_VideoSlotrigger_Ready.ForeColor = System.Drawing.Color.Black
        Me.txt_VideoSlotrigger_Ready.Increment = 0.2
        Me.txt_VideoSlotrigger_Ready.Location = New System.Drawing.Point(241, 16)
        Me.txt_VideoSlotrigger_Ready.MaxValue = 999
        Me.txt_VideoSlotrigger_Ready.MinValue = -1
        Me.txt_VideoSlotrigger_Ready.Multiline = True
        Me.txt_VideoSlotrigger_Ready.Name = "txt_VideoSlotrigger_Ready"
        Me.txt_VideoSlotrigger_Ready.NumericValue = -1
        Me.txt_VideoSlotrigger_Ready.NumericValueInteger = -1
        Me.txt_VideoSlotrigger_Ready.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_VideoSlotrigger_Ready.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_VideoSlotrigger_Ready.RoundingStep = 0
        Me.txt_VideoSlotrigger_Ready.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_VideoSlotrigger_Ready.Size = New System.Drawing.Size(46, 17)
        Me.txt_VideoSlotrigger_Ready.SuppressZeros = True
        Me.txt_VideoSlotrigger_Ready.TabIndex = 188
        Me.txt_VideoSlotrigger_Ready.Text = "-1"
        Me.txt_VideoSlotrigger_Ready.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 41)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 16)
        Me.Label11.TabIndex = 100
        Me.Label11.Text = "Video path"
        '
        'txt_VideoPath_Save
        '
        Me.txt_VideoPath_Save.ArrowsIncrement = 0
        Me.txt_VideoPath_Save.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_VideoPath_Save.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_VideoPath_Save.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_VideoPath_Save.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_VideoPath_Save.Increment = 0
        Me.txt_VideoPath_Save.Location = New System.Drawing.Point(6, 62)
        Me.txt_VideoPath_Save.MaxValue = 0
        Me.txt_VideoPath_Save.MinValue = 0
        Me.txt_VideoPath_Save.Multiline = True
        Me.txt_VideoPath_Save.Name = "txt_VideoPath_Save"
        Me.txt_VideoPath_Save.NumericValue = 0
        Me.txt_VideoPath_Save.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_VideoPath_Save.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Solid
        Me.txt_VideoPath_Save.RoundingStep = 0
        Me.txt_VideoPath_Save.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_VideoPath_Save.Size = New System.Drawing.Size(281, 35)
        Me.txt_VideoPath_Save.TabIndex = 97
        Me.txt_VideoPath_Save.Text = "   "
        Me.txt_VideoPath_Save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_VideoName
        '
        Me.txt_VideoName.ArrowsIncrement = 0
        Me.txt_VideoName.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_VideoName.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_VideoName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_VideoName.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_VideoName.Increment = 0
        Me.txt_VideoName.Location = New System.Drawing.Point(6, 114)
        Me.txt_VideoName.MaxValue = 0
        Me.txt_VideoName.MinValue = 0
        Me.txt_VideoName.Multiline = True
        Me.txt_VideoName.Name = "txt_VideoName"
        Me.txt_VideoName.NumericValue = 0
        Me.txt_VideoName.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_VideoName.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_VideoName.RoundingStep = 0
        Me.txt_VideoName.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_VideoName.Size = New System.Drawing.Size(278, 21)
        Me.txt_VideoName.TabIndex = 99
        Me.txt_VideoName.Text = "   Video"
        Me.txt_VideoName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_VideoName.WordWrap = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(15, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 16)
        Me.Label12.TabIndex = 98
        Me.Label12.Text = "Name"
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(704, 673)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.MyButton_SaveImageFile)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox7)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(720, 712)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.PictureBox_CpuMillisec, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_ProcessCPU, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_TotalCpu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label_FramesPerSec As System.Windows.Forms.Label
    Friend WithEvents ComboBox_VideoInputDevice As CustomControlsLib.MyComboBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents Tool_Instructions_ENG As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Timer_1Hz As System.Windows.Forms.Timer
    Friend WithEvents PictureBox_TotalCpu As System.Windows.Forms.PictureBox
    Friend WithEvents Label_Resolution As System.Windows.Forms.Label
    Friend WithEvents btn_VideoInControls As CustomControlsLib.MyButton
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_VideoinControls As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tool_VideoInControls As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PictureBox_ProcessCPU As System.Windows.Forms.PictureBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox_CpuMillisec As System.Windows.Forms.PictureBox
    Friend WithEvents MyButton_SaveImageFile As CustomControlsLib.MyButton
    Friend WithEvents ComboBox_FileType As CustomControlsLib.MyComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_FlipY As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FlipX As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_ImageName As CustomControlsLib.MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_ImagePath As CustomControlsLib.MyTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Tool_Instructions_ITA As System.Windows.Forms.ToolStripButton
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txt_ShiftX As CustomControlsLib.MyTextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txt_ShiftY As CustomControlsLib.MyTextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txt_Zoom As CustomControlsLib.MyTextBox
    Friend WithEvents Menu_Help_ProgramHelp_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label_FirstSlot As System.Windows.Forms.Label
    Friend WithEvents txt_AutosaveSlot As CustomControlsLib.MyTextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_CrossSize As CustomControlsLib.MyTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_CrossColor As CustomControlsLib.MyTextBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CloseProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tool_XvidInstall As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_VideoRecord As CustomControlsLib.MyButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_VideoSlotrigger_Save As CustomControlsLib.MyTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_VideoSlotrigger_Ready As CustomControlsLib.MyTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txt_VideoPath_Save As CustomControlsLib.MyTextBox
    Friend WithEvents txt_VideoName As CustomControlsLib.MyTextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class
