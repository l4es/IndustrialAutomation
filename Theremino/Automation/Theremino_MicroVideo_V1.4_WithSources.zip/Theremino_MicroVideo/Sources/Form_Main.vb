﻿

Public Class Form_Main

    Private Sub Form_Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' ----------------------------------------------------------------
        Me.Text = AppTitleAndVersion()
        ' ---------------------------------------------------------------- 
        Load_INI()
        Load_MachinConfig_INI()
        SaveNormalFormBounds()
        ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        ComboBox_FileFormat_InitWithCurrentFileFormat()
        ' ---------------------------------------------------------------- CAPTURE
        Capture_INIT(VideoInDevice)
        If VideoCaptureDevice_Is_VFW() Then
            Capture_ConnectFiltersAndRun()
        Else
            Capture_SetVideoFormatParams()
            Capture_ConnectFiltersAndRun()
        End If
        ' ---------------------------------------------------------------- DOCK
        If Form_VideoInControls_VisibleAtStart Then
            Form_VideoInControls.Show(Me)
        Else
            Form_VideoInControls.Show(Me)
            Form_VideoInControls.Visible = False
        End If
        DockAllWindows()
        SetPictureDimensions()
        ' ----------------------------------------------------------------
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------------------- Main Timer
        Timer1.Interval = 20
        '  Timer1.Interval = CInt(1000 / CInt(VideoFormatParams.VideoFPS)) - 10
        Timer1.Start()
        ' ---------------------------------------------------------------- Timer 1Hz
        Timer_1Hz.Interval = 1000
        Timer_1Hz.Start()
        ' ----------------------------------------------------------------
        SetDefaultFocus()
        EventsAreEnabled = True
        ' ---------------------------------------------------------------- SHOW
        Forms_FadeTo(1, 400)
        Try
            If Not FolderExists(File_termpory_Hide.Trim & "\") Then
                File_termpory_Hide = "C:\Theremino MicroVideo\Temp"
                My.Computer.FileSystem.CreateDirectory(File_termpory_Hide.Trim)
                SetAttr(File_termpory_Hide.Trim, vbHidden)
                ' System.IO.Directory.CreateDirectory(txt_VideoPath_Tempory.Text.Trim)
            End If
            If Not FolderExists(txt_VideoPath_Save.Text.Trim) Then
                txt_VideoPath_Save.Text = "C:\Theremino MicroVideo\Videos"
                System.IO.Directory.CreateDirectory(txt_VideoPath_Save.Text.Trim)
            End If
            If Not FolderExists(txt_ImagePath.Text.Trim & "\") Then
                txt_ImagePath.Text = "C:\Theremino MicroVideo\Images"
                System.IO.Directory.CreateDirectory(txt_ImagePath.Text.Trim)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Return
        CloseProgram()
    End Sub

    Private Sub CloseProgram()
        If Not avimanager Is Nothing Then
            avimanager.Close()
            avimanager = Nothing
            aviStream = Nothing
            If chooseRecroding = Recording_Style.Record_Button Or chooseRecroding = Recording_Style.Record_Slot Then
                Savevideo_buttonthread = New Threading.Thread(AddressOf thread_VideoDelete)
                Savevideo_buttonthread.Start()
            End If
           

        End If
       
        Save_INI()
        EventsAreEnabled = False
        Forms_FadeTo(0, 500)
        Me.Refresh()
        Timer1.Stop()
        Capture_STOP()
        Form_VideoInControls.Close()
        Me.Close()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
        'SaveNormalFormBounds()
    End Sub

    Private Sub Form_Main_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        DockAllWindows()
        'SaveNormalFormBounds()
    End Sub

    Private Sub Form_Main_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        DockAllWindows()
    End Sub

    Private Sub SetDefaultFocus()
        'Label_FramesPerSec.Focus()
        PictureBox1.Focus()
    End Sub

    Friend Sub PictureBox1_Clear()
        PictureBox1.Image = PictureBox1.InitialImage
    End Sub

    Friend Sub DockAllWindows()
        Form_VideoInControls.SetSnap()
    End Sub

    Private Sub OpenCloseFormVideoInControls()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.Visible = False
        Else
            Form_VideoInControls.Visible = True
            Me.Focus()
        End If
        DockAllWindows()
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub


    ' =======================================================================================
    '   MOUSE
    ' =======================================================================================
    Private Sub PictureBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Right Then
            ExecRbuttonUp()
        End If
        PictureBox1.Focus()
    End Sub
    Private Sub PictureBox1_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseWheel
        txt_Zoom.NumericValue *= (1 + e.Delta / 1200.0)
        txt_ShiftX.NumericValue = (e.X * 200) / PictureBox1.Width - 100
        txt_ShiftY.NumericValue = -((e.Y * 200) / PictureBox1.Height - 100)
    End Sub
    Private mouseStartX As Int32
    Private mouseStartY As Int32
    Private shiftStartX As Int32
    Private shiftStartY As Int32
    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
        mouseStartX = e.X
        mouseStartY = e.Y
        shiftStartX = txt_ShiftX.NumericValueInteger
        shiftStartY = txt_ShiftY.NumericValueInteger
    End Sub
    Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            txt_ShiftX.NumericValue = shiftStartX - (e.X - mouseStartX) / (PictureBox1.Width / 100)
            txt_ShiftY.NumericValue = shiftStartY + (e.Y - mouseStartY) / (PictureBox1.Height / 100)
        End If
    End Sub


    ' =======================================================================================
    '   PICTURE MAXIMIZED or NORMAL
    ' =======================================================================================
    Friend NormalLocation As Point
    Friend PictureMaximized As Boolean = False
    Friend NormalSize As Size
    Private Sub SaveNormalFormBounds()
        If Not PictureMaximized Then
            NormalLocation = Me.Location
            NormalSize = Me.Size
        End If
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Escape Then
            PictureMaximized = False
            SetPictureDimensions()
            Save_INI()
        End If
    End Sub

    Private Sub PictureBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox1.DoubleClick
        '  If Me.WindowState = FormWindowState.Maximized Then
        'SaveNormalFormBounds()
        'PictureMaximized = Not PictureMaximized
        'SetPictureDimensions()
        'Else
        PictureMaximized = Not PictureMaximized
        SetPictureDimensions_notMaximized()
        'End If
        Save_INI()
    End Sub
    Private Sub SetPictureDimensions_notMaximized()
        If PictureMaximized Then
            Me.MinimumSize = New Size(120, 120)
            MenuStrip1.Visible = False
            ToolStrip1.Visible = False
            PictureBox1.Top = 4
            PictureBox1.Left = 4
            PictureBox1.Width = Me.ClientSize.Width - 6
            PictureBox1.Height = Me.ClientSize.Height - 6
        Else
            Me.MinimumSize = New Size(720, 712)
            MenuStrip1.Visible = True
            ToolStrip1.Visible = True
            PictureBox1.Top = ToolStrip1.Bottom + 8
            PictureBox1.Left = 8
            PictureBox1.Width = GroupBox4.Left - 12
            PictureBox1.Height = Me.ClientSize.Height - ToolStrip1.Bottom - 16
        End If
    End Sub
    Private Sub SetPictureDimensions()
        If PictureMaximized Then
            Me.MinimumSize = New Size(120, 120)
            MenuStrip1.Visible = False
            ToolStrip1.Visible = False
            PictureBox1.Top = 4
            PictureBox1.Left = 4
            PictureBox1.Width = Me.ClientSize.Width - 6
            PictureBox1.Height = Me.ClientSize.Height - 6
            ' -------------------------------------------------------
            FormBorderStyle = FormBorderStyle.None
            Dim r As Rectangle = Screen.GetBounds(Me.Location)
            Me.Location = r.Location
            Me.Size = r.Size

            HideTrayWnd()
        Else
            Me.MinimumSize = New Size(720, 712)
            MenuStrip1.Visible = True
            ToolStrip1.Visible = True
            PictureBox1.Top = ToolStrip1.Bottom + 8
            PictureBox1.Left = 8
            PictureBox1.Width = GroupBox4.Left - 12
            PictureBox1.Height = Me.ClientSize.Height - ToolStrip1.Bottom - 16
            ' -------------------------------------------------------
            ShowTrayWnd()
            FormBorderStyle = FormBorderStyle.Sizable
            Me.Location = NormalLocation
            Me.Size = NormalSize
            'LimitFormPosition(Me)
            ShowTrayWnd()
        End If
    End Sub

    ' =======================================================================================
    '  Hide and Show - TrayWnd
    ' =======================================================================================
    Private Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As Int32
    Private Declare Function ShowWindow Lib "user32" (ByVal hwnd As Int32, ByVal nCmdShow As Int32) As Int32
    Private Const SW_HIDE As Int32 = 0
    Private Const SW_SHOW As Int32 = 5
    Friend Sub HideTrayWnd()
        Dim lngHandle As Int32
        lngHandle = FindWindow("Shell_TrayWnd", "")
        ShowWindow(lngHandle, SW_HIDE)
    End Sub
    Friend Sub ShowTrayWnd()
        Dim lngHandle As Int32
        lngHandle = FindWindow("Shell_TrayWnd", "")
        ShowWindow(lngHandle, SW_SHOW)
    End Sub

    ' ===================================================================================================
    '  ContextMenuStrip
    ' ===================================================================================================
    Friend Sub ExecRbuttonUp()
        ContextMenuStrip1.Show(PictureBox1, Me.PointToClient(Cursor.Position))
        Save_INI()
    End Sub
    Private Sub CloseProgramToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseProgramToolStripMenuItem.Click
        ShowTrayWnd()
        Me.Close()
    End Sub


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Exit.Click
        CloseProgram()
    End Sub

    ' =======================================================================================
    '   MENU TOOLS
    ' =======================================================================================
    Private Sub Menu_VideoinControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_VideoinControls.Click
        OpenCloseFormVideoInControls()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_ENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp_ENG.Click
        Language = "ENG"
        OpenLocalizedHelp("Theremino_MicroViewer", ".pdf")
    End Sub
    Private Sub Menu_Help_ProgramHelp_ITA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp_ITA.Click
        Language = "ITA"
        OpenLocalizedHelp("Theremino_MicroViewer", ".pdf")
    End Sub
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.Show()
    End Sub

    ' =======================================================================================
    '   TOOLSTRIP
    ' =======================================================================================
    Private Sub Tool_VideoInControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_VideoInControls.Click
        OpenCloseFormVideoInControls()
    End Sub

    Private Sub Tool_XvidInstall_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_XvidInstall.Click
        OpenXvidInstall()
    End Sub
    Private Sub ToolButton_HelpEng_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_Instructions_ENG.Click
        Language = "ENG"
        OpenLocalizedHelp("Theremino_MicroViewer", ".pdf")
    End Sub
    Private Sub ToolButton_HelpIta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_Instructions_ITA.Click
        Language = "ITA"
        OpenLocalizedHelp("Theremino_MicroViewer", ".pdf")
    End Sub

    Dim Language As String
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")

        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & Strings.Left(Language, 3).ToUpper & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub



    ' ==============================================================================================================
    '   COMBO BOX - FILE
    ' ==============================================================================================================
    Private Sub ComboBox_FileFormat_InitWithCurrentFileFormat()
        Combo_Init(ComboBox_FileType, FileFormat)
    End Sub
    Private Sub ComboBox_FileFormat_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.DropDownClosed
        SetDefaultFocus()
    End Sub
    Private Sub ComboBox_FileFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        FileFormat = Combo_GetValue(ComboBox_FileType)
        '
        SetDefaultFocus()
        Save_INI()
        '
    End Sub
    Private Sub ComboBox_FileFormat_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.DropDown
        With ComboBox_FileType
            .Items.Clear()
            .Items.Add("JPG")
            .Items.Add("PNG")
            .Items.Add("TIFF")
            .Items.Add("EXIF")
            .Items.Add("EMF")
            .Items.Add("WMF")
            .Items.Add("GIF")
            .Items.Add("BMP")
            Combo_SetIndex_FromString(ComboBox_FileType, FileFormat)
        End With
    End Sub


    ' ==============================================================================================================
    '   COMBO BOX - VIDEO INPUT
    ' ==============================================================================================================
    Private Sub ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        Combo_Init(ComboBox_VideoInputDevice, VideoInDevice)
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDownClosed
        SetDefaultFocus()
    End Sub
    Private Sub ComboBox_VideoInputDevice_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        VideoInDevice = Combo_GetValue(ComboBox_VideoInputDevice)
        Timer1.Stop()
        Application.DoEvents()
        Capture_STOP()
        Application.DoEvents()
        Capture_INIT(VideoInDevice)
        Capture_ConnectFiltersAndRun()
        Timer1.Start()
        SetDefaultFocus()
        Save_INI()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.UpdateAllValues()
            Form_VideoInControls.Focus()
        End If
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDown
        Dim fnames() As String
        fnames = EnumFiltersByCategory(FilterCategory.VideoInputDevice)
        With ComboBox_VideoInputDevice
            .Items.Clear()
            For Each fltName As String In fnames
                .Items.Add(fltName)
            Next
            Combo_SetIndex_FromString(ComboBox_VideoInputDevice, VideoInDevice)
        End With
    End Sub


    ' ==============================================================================================================
    '   BUTTONS AND COMMANDS
    ' ==============================================================================================================
    Private Sub btn_VideoInControls_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_VideoInControls.ClickButtonArea
        OpenCloseFormVideoInControls()
    End Sub
    Private Sub MyButton_SaveImageFile_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyButton_SaveImageFile.MouseClick
        MyButton_SaveImageFile.Focus()
        MyButton_SaveImageFile.Refresh()
        If e.Button = Windows.Forms.MouseButtons.Left Then
            MyButton_SaveImageFile.Checked = True
            MyButton_SaveImageFile.Refresh()
            SaveCapturedImage()
            MyButton_SaveImageFile.Checked = False
            MyButton_SaveImageFile.Refresh()
            MyButton_SaveImageFile.Focus()
        End If
    End Sub
    Private Sub MyButton_SaveImageFile_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyButton_SaveImageFile.GotFocus
        MyButton_SaveImageFile.BorderColor = Color.Red
        MyButton_SaveImageFile.BorderShow = True
    End Sub
    Private Sub MyButton_SaveImageFile_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyButton_SaveImageFile.LostFocus
        MyButton_SaveImageFile.BorderColor = Color.Gray
        MyButton_SaveImageFile.BorderShow = False
    End Sub
    Private Sub txt_FilePath_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_ImagePath.MouseDoubleClick
        SelectSaveFolder()
    End Sub
    Public Sub SelectSaveFolder()
        Dim FBD As System.Windows.Forms.FolderBrowserDialog
        FBD = New System.Windows.Forms.FolderBrowserDialog()
        With FBD
            ' -- USE ROOTFOLDER TO LIMIT USER CHOOSE AREA -- ( No RootFolder NO limits )
            '.RootFolder = Environment.SpecialFolder.MyComputer
            ' --------------------------------------------------------------------------
            .SelectedPath = txt_ImagePath.Text
            .Description = vbCr & "Select the ""File Save Path"""
            If .ShowDialog = DialogResult.OK Then
                txt_ImagePath.Text = .SelectedPath
            End If
        End With
    End Sub
 


    ' ==============================================================================================================
    '   TIMER 1 Hz
    ' ==============================================================================================================
    Private Sub Timer_1Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_1Hz.Tick
        If Not EventsAreEnabled Then Return
        ' -------------------------------- MUST BE CALLED EVERY SECOND
        TestCpuUsage(PictureBox_ProcessCPU, PictureBox_TotalCpu)
        Select Case VideoStatus
            Case True
                btn_VideoRecord.Text = "Stop  Record"
                '---------------------------Flash for the recrod button-------------------
                Select Case btn_VideoRecord.BorderColor
                    Case Color.Yellow
                        btn_VideoRecord.BorderColor = Color.Red
                        btn_VideoRecord.ForeColor = Color.Red
                        btn_VideoRecord.BorderShow = True
                    Case Color.Red
                        btn_VideoRecord.BorderColor = Color.Yellow
                        btn_VideoRecord.ForeColor = Color.Black
                        btn_VideoRecord.BorderShow = True
                End Select
            Case False
                btn_VideoRecord.Text = "Start  Record"
                btn_VideoRecord.BorderColor = Color.Yellow
                btn_VideoRecord.ForeColor = Color.Black
                btn_VideoRecord.BorderShow = False
        End Select

        'If (chooseRecroding = Recording_Style.Record_Button And btnorauto_checked = True) Or (chooseRecroding = Recording_Style.Record_Slot And btnorauto_checked = True) Then
        '    Color_VideoRecord = True
        '    btnorauto_checked = False
        'End If
        'If chooseRecroding = Recording_Style.Rccord_Unkown Or chooseRecroding = Recording_Style.Rccord_Stop_Button Or chooseRecroding = Recording_Style.Rccord_Stop_Slot Then
        '    Color_VideoRecord = False
        '    btn_VideoRecord.ForeColor = Color.Black
        '    btn_VideoRecord.Text = "Start recording"
        '    btn_VideoRecord.BorderShow = False
        '    Exit Sub
        'End If
        'If Color_VideoRecord = True Then
        '    btn_VideoRecord.BorderColor = Color.Red
        '    btn_VideoRecord.ForeColor = Color.Red
        '    btn_VideoRecord.BorderShow = True
        '    btn_VideoRecord.Text = "Recording..."
        '    Color_VideoRecord = False
        '    Exit Sub
        'End If
        'If Color_VideoRecord = False Then
        '    btn_VideoRecord.BorderColor = Color.Yellow
        '    btn_VideoRecord.ForeColor = Color.Yellow
        '    btn_VideoRecord.BorderShow = True
        '    btn_VideoRecord.Text = "Recording..."
        '    Color_VideoRecord = True
        '    Exit Sub
        'End If
        '
        '’   EnableDisableControls()
    End Sub
    'Private Sub EnableDisableControls()
    '    If FileFormat = "JPG" Then
    '        Label_JpegQuality.Enabled = True
    '        txt_JpegQuality.Enabled = True
    '    Else
    '        Label_JpegQuality.Enabled = False
    '        txt_JpegQuality.Enabled = False
    '    End If
    '    If CheckBox_HiRes.Checked Then
    '        Label_ResizeQuality.Enabled = True
    '        txt_ResizeQuality.Enabled = True
    '    Else
    '        Label_ResizeQuality.Enabled = False
    '        txt_ResizeQuality.Enabled = False
    '    End If
    'End Sub


    ' ==============================================================================================================
    '   CAPTURE TIMER
    ' ==============================================================================================================
    Private Timer1_Working As Boolean = False
    'Dim sw As Stopwatch = New Stopwatch
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick


        If Capture_Image Is Nothing OrElse Capture_Image.PixelFormat = Imaging.PixelFormat.Undefined Then
            Return
        End If
        If Capture_Image Is Nothing Then Exit Sub
        If Timer1_Working Then Exit Sub
        Timer1_Working = True
        'timeBeginPeriod(1)  'switch resolution to 1 ms
        ''sw.Reset()
        ''sw.Start()
        'StartTime = timeGetTime
        ProcessCapturedImage()

        ' --------------------------------------------------------------------------- BUTTON SAVE IMAGE
        If KeyFromPreviousCall(Keys.Space) And MyButton_SaveImageFile.Focused Then
            PressButtonAndSaveImage()
        End If
        ' --------------------------------------------------------------------------- 
        TestAutosaveSlot()

        TestAutosaveVideoSlot()   'Save Video

        '  TestButtonsave()

        ' --------------------------------------------------------------------------- 
        Timer1_Working = False
        ' sw.Stop()
        'Dim m_timeSpan As Long = timeGetTime - StartTime
        ''   timeEndPeroid(1)
        ''  Me.Text = sw.ElapsedMilliseconds.ToString
        'Dim h_timeSpan As Integer = CInt(1000 / CInt(VideoFormatParams.VideoFPS) - Timer1.Interval - m_timeSpan + 4)
        ''SleepMyThread(CInt(1000 / CInt(VideoFormatParams.VideoFPS) - 10 - sw.ElapsedMilliseconds))
        '' SleepMyThread(20)
        'If h_timeSpan > 0 Then Sleep(h_timeSpan)

    End Sub
    Private Thread_DeleteVideo As System.Threading.Thread
    Private Thread_MoveVideo As System.Threading.Thread
    Private Sub thread_VideoDelete()
        Videostatus_slot = False
        Try
            My.Computer.FileSystem.DeleteFile(GetSavedPath)
            Thread_DeleteVideo.Abort()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub Thread_VideoMove_Slot()
        Try
            My.Computer.FileSystem.MoveFile(GetSavedPath, GetMovedVideoPath)
            Thread_MoveVideo.Abort()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AviClose()
        If Not avimanager Is Nothing Then
            avimanager.Close()
            avimanager = Nothing
            aviStream = Nothing
        End If
    End Sub
    Private Sub AviOpen()
        If avimanager Is Nothing Then
            avimanager = New Class_AVIManager(SaveVideoPath(chooseRecroding), False) '----------True: read; False:write
            aviStream = avimanager.AddVideoStream(True, CInt(Capture_FramesPerSecond), _
                                                  Capture_Image.Width * Capture_Image.Height * 3, _
                                                  Capture_Image.Width, _
                                                  Capture_Image.Height, Imaging.PixelFormat.Format24bppRgb)
        End If
    End Sub
    Friend Sub TestAutosaveVideoSlot()
        If chooseRecroding = Recording_Style.Record_Button Then Exit Sub
        Dim slot_Ready As Int32 = txt_VideoSlotrigger_Ready.NumericValueInteger
        Dim slot_Save As Int32 = txt_VideoSlotrigger_Save.NumericValueInteger
        Dim v_video_Ready As Single
        Dim v_video_Save As Single
        Static oldv As Single = 0
        If slot_Ready >= 0 Then
            v_video_Ready = Slots.ReadSlot_NoNan(slot_Ready)  '.................read the  txt_VideoSlotrigger_Ready
            v_video_Save = Slots.ReadSlot_NoNan(slot_Save) '..................  read the txt_VideoSlotrigger_Start
            If v_video_Ready >= 500 And oldv < 500 Then
                chooseRecroding = Recording_Style.Record_Slot
                AviOpen()
                VideoStatus = True
                frame_startornot_ready_slot = True
                btn_saveornot_ready = True   '.................ready to record
            ElseIf v_video_Ready < 500 And oldv >= 500 Then
                chooseRecroding = Recording_Style.Rccord_Unkown
                If Not avimanager Is Nothing Then
                    VideoStatus = False
                    SyncLock lock_frame
                        AviClose()
                        frame_startornot_ready_slot = False
                        frames_Video = 0
                    End SyncLock
                    If Not btn_saveornot_save = True Then
                        Thread_DeleteVideo = New System.Threading.Thread(AddressOf thread_VideoDelete)
                        Thread_DeleteVideo.Start()
                    Else
                        Thread_MoveVideo = New System.Threading.Thread(AddressOf Thread_VideoMove_Slot)
                        Thread_MoveVideo.Start()
                    End If

                End If
                btn_saveornot_save = False
                'btn_saveornot_ready = False
            End If

            If v_video_Save >= 500 And btn_saveornot_ready = True Then
                btn_saveornot_save = True
                frame_startornot_save = True
            Else : frame_startornot_save = False
            End If
            oldv = v_video_Ready
        End If
    End Sub

    'Friend Sub TestButtonsave()
    '    If Videostatus = True Then
    '        ' SyncLock lock_queue
    '        '  queue_addframe.Enqueue(Capture_Image)
    '        '   Capture_Image = Nothing
    '        '   End SyncLock
    '        ' aviStream.AddFrame(CType(queue_addframe.Dequeue, Bitmap))
    '        'bitmap_Avi = CType(image2, Bitmap)
    '        'bitmap_Avi = CType(bitmap_Avi, Bitmap)
    '        aviStream.AddFrame(CType(Capture_Image, Bitmap))
    '    End If
    'End Sub


    Private Sub PressButtonAndSaveImage()
        MyButton_SaveImageFile.Checked = True
        MyButton_SaveImageFile.Refresh()
        SaveCapturedImage()
        MyButton_SaveImageFile.Checked = False
        MyButton_SaveImageFile.Refresh()
    End Sub


    ' ==============================================================================================================
    '   AUTOSAVE SLOT
    ' ==============================================================================================================
    Friend Sub TestAutosaveSlot()
        Dim slot As Int32 = txt_AutosaveSlot.NumericValueInteger
        Dim v As Single
        Static oldv As Single = 0
        If slot >= 0 Then
            v = (Slots.ReadSlot_NoNan(slot))
            If v >= 500 And oldv < 500 Then
                PressButtonAndSaveImage()
            End If
            oldv = v
        End If
    End Sub
    Dim lock_queue As New Object
    Private Sub btn_StartVideoRecord_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles btn_VideoRecord.MouseClick
        If Capture_Image Is Nothing Then Exit Sub
        If EventsAreEnabled = False Then Exit Sub
        btn_VideoRecord.Focus()
        btn_VideoRecord.Refresh()
        If e.Button = Windows.Forms.MouseButtons.Left Then
            '----------------------------------------VideoStatus------------------------------------------------------
            'true: loop to add frame; false: stop the loop 
            Select Case VideoStatus
                Case False
                    StartRecording()
                    VideoStatus = True
                Case True
                    StopRecording()
                    VideoStatus = False
            End Select
        End If
    End Sub
    Private Sub StartRecording()
        btn_VideoRecord.Checked = True
        btn_VideoRecord.Refresh()
        chooseRecroding = Recording_Style.Record_Button
        AviOpen()
        Videostatus = True

        btn_VideoRecord.Checked = False
        btn_VideoRecord.Refresh()
        btn_VideoRecord.Focus()
    End Sub
    Dim Savevideo_buttonthread As Threading.Thread
    Private Sub Thread_VideoMove_Button()
        '  SleepMyThread(10)
        Try
            My.Computer.FileSystem.MoveFile(GetSavedPath, GetMovedVideoPath)
            Savevideo_buttonthread.Abort()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub StopRecording()
        '   Sleep(1)
        SyncLock lock_frame
            avimanager.Close()
            avimanager = Nothing
            'aviStream.Close()
            aviStream = Nothing
            frame_startornot_save = False
            frame_startornot_ready_slot = False
            frames_Video = 0
        End SyncLock
        Savevideo_buttonthread = New Threading.Thread(AddressOf Thread_VideoMove_Button)
        Savevideo_buttonthread.Start()
        chooseRecroding = Recording_Style.Rccord_Unkown
       
    End Sub

    Private Sub txt_VideoPath_Save_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_VideoPath_Save.MouseDoubleClick
        OpenDialogforFilePath()
    End Sub
    Public Sub OpenDialogforFilePath()
        Dim SVP As Windows.Forms.FolderBrowserDialog
        SVP = New System.Windows.Forms.FolderBrowserDialog()
        With SVP
            .SelectedPath = txt_VideoPath_Save.Text.Trim
            .Description = vbCr & "Select the ""File Save Path"""
            If .ShowDialog = DialogResult.OK Then
                txt_VideoPath_Save.Text = .SelectedPath
            End If
        End With
    End Sub
End Class
