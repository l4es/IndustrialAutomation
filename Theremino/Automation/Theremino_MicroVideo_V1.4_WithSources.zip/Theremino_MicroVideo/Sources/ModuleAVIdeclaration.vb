﻿Imports System.Drawing.Drawing2D

Module ModuleAVIdeclaration
    ' Private Videostatus_slot As Boolean = False  '...........false: Viewing; true:Recording 
    Friend File_termpory_Hide As String = "C:\Theremino MicroVideo\Temp"
    Friend avimanager As Class_AVIManager
    Friend Videostatus_slot As Boolean = False  '...........false: Viewing; true:Recording 
    ' Friend bitmap_Avi As Bitmap
    Friend aviStream As Class_VideoStream
    Friend chooseRecroding As Recording_Style = Recording_Style.Rccord_Unkown
    Friend Queue_addFrame As New Queue '...............Add frame from BufferCB to memory
    Friend frames_Video As Integer = 0
    Friend frame_startornot_ready_slot As Boolean = False
    Friend frame_startornot_save As Boolean = False
    Friend VideoStatus As Boolean = False
    Friend lock_frame As New Object
    Enum Recording_Style
        Record_Button = 0
        Record_Slot = 1
        Rccord_Unkown = 4
    End Enum
    Friend btn_saveornot_ready As Boolean = False
    Friend btn_saveornot_save As Boolean = False
    Friend Color_VideoRecord As Boolean = False
    Friend btnorauto_checked As Boolean = True
    Public Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Public Declare Function timeEndPeroid Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Public Declare Function timeGetTime Lib "winmm.dll" () As Long
    Public Declare Sub Sleep Lib "kernel32" (ByVal uDuration As Long)
    ' Public Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Long) As Long
    Public Sub DrawFlippedText(ByVal gr As Graphics, ByVal _
    the_font As Font, ByVal the_brush As Brush, ByVal x As _
    Integer, ByVal y As Integer, ByVal txt As String, ByVal _
    flip_x As Boolean, ByVal flip_y As Boolean)
        ' Save the current graphics state.
        Dim state As GraphicsState = gr.Save()

        ' Set up the transformation.
        Dim scale_x As Integer = CInt(IIf(flip_x, -1, 1))
        Dim scale_y As Integer = CInt(IIf(flip_y, -1, 1))
        gr.ResetTransform()
        gr.ScaleTransform(scale_x, scale_y)

        ' Figure out where to draw.
        Dim txt_size As SizeF = gr.MeasureString(txt, the_font)
        If flip_x Then x = CInt(-x - txt_size.Width)
        If flip_y Then y = CInt(-y - txt_size.Height)

        ' Draw.
        gr.DrawString(txt, the_font, the_brush, x, y)

        ' Restore the original graphics state.
        gr.Restore(state)
    End Sub
End Module
