﻿
' NV12 example for 640 x 480 x 3 = 921600
' ------------------------------------------
'  640 x 480 x 1 = 307200 (lum)
'  640 x 480 x 2 = 
' ------------------------------------------
' total = 338688 ??
' 338688 - 307200 = 31488 ??


'http://stackoverflow.com/questions/17089469/capturing-a-photo-on-x86-atom-windows-8-directshow

'Some more information. 
'When running on the laptop, m_pinStill isn't found until the splitter is added. 
'On the tablet, it looks like it's found through the preview pin. 
'In the setupGraph Sub, tablet finds m_pinStill via: 
'  m_pinStill = DsFindPin.ByCategory(capFilter,PinCategory.Preview,0) 
' laptop sets it up in the splitter, 
' which it tries if the DsFindPin.ByCategory attempts are unsuccessful. 
'– Aaron Jun 13 '13 at 15:28 

'This actually solved the problem! 
'Commented out the DsFindPin.ByCategory(capFilter,PinCategory.Still,0) 
'and forced it to set up a splitter. 
'It's good now. Thanks for the help guys :p :) 
'– Aaron Jun 13 '13 at 15:33

Friend Class SamplegrabberCallback
    Implements ISampleGrabberCB

    ' TODO - USING BmiHeader - Needs an accurate test
    Friend Width As Int32
    Friend Height As Int32
    Dim h_h As Boolean = True
    Dim lock_queue As New Object
    Friend Function BufferCB(ByVal SampleTime As Double, ByVal pBuffer As System.IntPtr, ByVal BufferLen As Integer) As Integer Implements ISampleGrabberCB.BufferCB
        '
        If BufferLen = 0 Then Return 0
        '
        If BufferLen = 338688 Then
            Width = 448
            Height = 252
        End If
        '
        Dim nBytes As Int32 = Width * Height * 3
        Dim stride As Int32 = Width * 3

        ' --------------------------- Here we add the "aviStream.AddFrame" (EACH Callback)
        Dim img As Image
        ' Dim img_framesave As Image
        If BufferLen = nBytes Then
            img = New Bitmap(Width, Height, stride, Imaging.PixelFormat.Format24bppRgb, pBuffer)
            '  img_framesave = New Bitmap(Width, Height, stride, Imaging.PixelFormat.Format24bppRgb, pBuffer)
            Drawframs(img)
            '   img.RotateFlip(RotateFlipType.RotateNoneFlipY)
            If Videostatus = True Then
                SyncLock lock_frame
                    aviStream.AddFrame(CType(img, Bitmap))
                    '   Queue_addFrame.Enqueue(img_framesave)
                End SyncLock

            End If
            ' aviStream.Close()
        Else
            img = New Bitmap(Width, Height, Imaging.PixelFormat.Format24bppRgb)
            Dim g As Graphics = Graphics.FromImage(Capture_Image)
            g.Clear(Color.AliceBlue)
            g.DrawString("INCORRECT BUFFER DIMENSIONS", New Font("Arial", 20), Brushes.Black, 10, 10)
        End If

        ' --------------------------- Here we set the "Capture_Image" (when required by the user interface)
        '
        If Not Capture_NewImageIsReady Then
            Capture_Image = img
            Capture_NewImageIsReady = True

        End If

        ' -------------------------------------------------------
        CalcFramesPerSec(SampleTime)
        Return 0
    End Function
    Private Sub Drawframs(ByVal img As Image)
        If Videostatus = False Then Exit Sub
        Dim g As Graphics = Graphics.FromImage(img)
        Dim g_g As Color = Color.FromArgb(100, 0, 0, 100)
        If chooseRecroding = Recording_Style.Record_Slot Then
            If frame_startornot_ready_slot = True Then
                frames_Video = frames_Video + 1
                g.FillRectangle(New SolidBrush(g_g), img.Size.Width / 100.0F, img.Size.Height / 1.09F, _
                                img.Size.Width / 9.0F, img.Size.Height / 15.0F)
                If frame_startornot_save Then
                    DrawFlippedText(g, New Font("Tahoma", 45.0F * CSng(VideoFormatParams.VideoSize.Split("x"c)(0)) / 1600, _
                       FontStyle.Regular), Brushes.Red, CInt(img.Size.Width / 100.0F), CInt(img.Size.Height / 1.1F), _
                       frames_Video.ToString("0000"), False, True)
                Else
                    DrawFlippedText(g, New Font("Tahoma", 45.0F * CSng(VideoFormatParams.VideoSize.Split("x"c)(0)) / 1600, _
                        FontStyle.Regular), Brushes.White, CInt(img.Size.Width / 100.0F), CInt(img.Size.Height / 1.1F), _
                        frames_Video.ToString("0000"), False, True)
                End If
            End If
        End If
        If chooseRecroding = Recording_Style.Record_Button Then
            frames_Video = frames_Video + 1
            g.FillRectangle(New SolidBrush(g_g), img.Size.Width / 100.0F, img.Size.Height / 1.09F, img.Size.Width / 9.0F, _
                            img.Size.Height / 15.0F)
            DrawFlippedText(g, New Font("Tahoma", 45.0F * CSng(VideoFormatParams.VideoSize.Split("x"c)(0)) / 1600, _
                    FontStyle.Regular), Brushes.White, CInt(img.Size.Width / 100.0F), CInt(img.Size.Height / 1.1F), _
                    frames_Video.ToString("0000"), False, True)
        End If
    End Sub
    '
    Private Function SampleCB(ByVal SampleTime As Double, ByVal pSample As IMediaSample) As Integer Implements ISampleGrabberCB.SampleCB
        '
        Dim bufferlen As Integer = pSample.GetActualDataLength
        If bufferlen = 0 Then Return 0
        '
        If bufferlen = 338688 Then
            Width = 448
            Height = 252
        End If
        '
        Dim nBytes As Int32 = Width * Height * 3
        Dim stride As Int32 = Width * 3

        If Not Capture_NewImageIsReady Then
            If BufferLen = nBytes Then
                Dim ppbuffer As IntPtr = Nothing
                pSample.GetPointer(ppbuffer)
                Capture_Image = New Bitmap(Width, Height, stride, Imaging.PixelFormat.Format24bppRgb, ppbuffer)
            End If
            Capture_NewImageIsReady = True
        End If
        ' -------------------------------------------------------- without this release the process locks
        Runtime.InteropServices.Marshal.ReleaseComObject(pSample)
        ' --------------------------------------------------------
        CalcFramesPerSec(SampleTime)
        Return 0
    End Function

    Private Sub CalcFramesPerSec(ByVal sampletime As Double)
        Static oldSampleTime As Double
        Dim millisec As Double = sampletime - oldSampleTime
        oldSampleTime = sampletime
        If millisec > 0 And millisec < 100000 Then
            Capture_FramesPerSecond += (1 / millisec - Capture_FramesPerSecond) / 4
        End If
    End Sub
    '
End Class
