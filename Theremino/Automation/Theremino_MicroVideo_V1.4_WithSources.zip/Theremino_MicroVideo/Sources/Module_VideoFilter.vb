﻿Module Module_VideoFilter
    '---------------------using the declarationg to escape from the control`s text------------------
    'it is usfull for thread
    Friend GetSavedPath As String
    Friend GetMovedVideoPath As String
    Friend Function SaveVideoPath(ByVal recordTye As Recording_Style) As String   'Establish a tempory file path for recording video
        If Not FolderExists(Form_Main.txt_VideoPath_Save.Text & "\") Then
            Form_Main.OpenDialogforFilePath()
        End If
        If recordTye = Recording_Style.Record_Button Then
            Form_Main.txt_VideoName.Text = "M_" & SerialNumber & "_" & DateTime.Now.ToString("yyyyMMddHHmmss")
        Else
            Form_Main.txt_VideoName.Text = "A_" & SerialNumber & "_" & DateTime.Now.ToString("yyyyMMddHHmmss")
        End If
        SaveVideoPath = File_termpory_Hide.Trim & "\" & _
                               Form_Main.txt_VideoName.Text & ".avi"
        While My.Computer.FileSystem.FileExists(SaveVideoPath)
            SaveVideoPath = SaveVideoPath & DateTime.Now.Millisecond
        End While
        GetSavedPath = SaveVideoPath
        MovetoVideoPath()
    End Function
    Private Function MovetoVideoPath() As String

        MovetoVideoPath = Form_Main.txt_VideoPath_Save.Text.Trim & "\" & _
                                Form_Main.txt_VideoName.Text & ".avi"

        While My.Computer.FileSystem.FileExists(MovetoVideoPath)
            MovetoVideoPath = MovetoVideoPath & DateTime.Now.Millisecond
            Form_Main.txt_VideoName.Text = IO.Path.GetFileNameWithoutExtension(MovetoVideoPath)
        End While
        GetMovedVideoPath = MovetoVideoPath
    End Function
End Module
