﻿
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend Form_VideoInControls_VisibleAtStart As Boolean = True
    Friend EventsAreEnabled As Boolean = False
    Friend VideoInDevice As String = ""
    Friend FileFormat As String = ""

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function



    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub Save_INI()
        '
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            Dim r As Rectangle
            r = GetFormRectangle(Form_Main)
            f.WriteLine(TabString("FormMain_Top", r.Top))
            f.WriteLine(TabString("FormMain_Left", r.Left))
            f.WriteLine(TabString("FormMain_Width", r.Width))
            f.WriteLine(TabString("FormMain_Height", r.Height))
            f.WriteLine(TabString("FormMain_WindowState", Form_Main.WindowState))
            f.WriteLine(TabString("PictureMaximized", Form_Main.PictureMaximized))
            '
            r = GetFormRectangle(Form_VideoInControls)
            f.WriteLine(TabString("Form_VideoInControls_Top", r.Top))
            f.WriteLine(TabString("Form_VideoInControls_Left", r.Left))
            f.WriteLine(TabString("Form_VideoInControls_VisibleAtStart", Form_VideoInControls.Visible And Form_VideoInControls.WindowState <> FormWindowState.Minimized))
            '
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Video Input Params"))
            f.WriteLine(TabString("==========================================="))
            f.WriteLine(TabString("VideoInDevice", VideoInDevice))
            f.WriteLine(TabString("VideoFormat", VideoFormatParams.VideoFormat))
            f.WriteLine(TabString("VideoSize", VideoFormatParams.VideoSize))
            f.WriteLine(TabString("VideoFPS", VideoFormatParams.VideoFPS))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Conversions"))
            f.WriteLine(TabString("==========================================="))
            f.WriteLine(TabString("FlipX", Form_Main.CheckBox_FlipX.Checked.ToString))
            f.WriteLine(TabString("FlipY", Form_Main.CheckBox_FlipY.Checked.ToString))
            f.WriteLine(TabString("Zoom", Form_Main.txt_Zoom.NumericValue.ToString))
            f.WriteLine(TabString("ShiftX", Form_Main.txt_ShiftX.NumericValue.ToString))
            f.WriteLine(TabString("ShiftY", Form_Main.txt_ShiftY.NumericValue.ToString))
            f.WriteLine(TabString("CrossSize", Form_Main.txt_CrossSize.NumericValueInteger))
            f.WriteLine(TabString("CrossColor", Form_Main.txt_CrossColor.NumericValueInteger))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Quality"))
            f.WriteLine(TabString("==========================================="))
            f.WriteLine(TabString("HiRes", Form_Main.CheckBox_HiRes.Checked.ToString))
            f.WriteLine(TabString("ZoomQuality", Form_Main.txt_ZoomQuality.NumericValue.ToString))
            f.WriteLine(TabString("JpegQuality", Form_Main.txt_JpegQuality.NumericValue.ToString))
            f.WriteLine(TabString("ResizeQuality", Form_Main.txt_ResizeQuality.NumericValue.ToString))
            '
            f.WriteLine(TabString(""))
            f.WriteLine(TabString(" Output file"))
            f.WriteLine(TabString("==========================================="))
            f.WriteLine(TabString("AutosaveSlot", Form_Main.txt_AutosaveSlot.NumericValueInteger))
            f.WriteLine(TabString("FilePath", Form_Main.txt_FilePath.Text))
            f.WriteLine(TabString("FileName", Form_Main.txt_FileName.Text))
            f.WriteLine(TabString("FileFormat", FileFormat))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------------------------- defaults
        VideoInDevice = ""
        FileFormat = "JPG"
        VideoFormatParams.VideoFormat = "RGB42"
        VideoFormatParams.VideoSize = "320 x 240"
        VideoFormatParams.VideoFPS = "30"
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"

        If My.Computer.FileSystem.FileExists(iniFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)
            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "FormMain_Top" : Form_Main.Top = CInt(Val(l))
                    Case "FormMain_Left" : Form_Main.Left = CInt(Val(l))
                    Case "FormMain_Width" : Form_Main.Width = CInt(Val(l))
                    Case "FormMain_Height" : Form_Main.Height = CInt(Val(l))
                    Case "FormMain_WindowState" : Form_Main.WindowState = CType((Val(l)), FormWindowState)
                    Case "PictureMaximized" : Form_Main.PictureMaximized = l = "True"
                        ' ------------------------------------------------------------------------------ 
                    Case "Form_VideoInControls_Top" : Form_VideoInControls.Top = Val_Int(l)
                    Case "Form_VideoInControls_Left" : Form_VideoInControls.Left = Val_Int(l)
                    Case "Form_VideoInControls_VisibleAtStart" : Form_VideoInControls_VisibleAtStart = l = "True"
                        ' ------------------------------------------------------------------------------ Video in device
                    Case "VideoInDevice" : VideoInDevice = l
                    Case "VideoFormat" : VideoFormatParams.VideoFormat = l
                    Case "VideoSize" : VideoFormatParams.VideoSize = l
                    Case "VideoFPS" : VideoFormatParams.VideoFPS = l
                        ' ------------------------------------------------------------------------------
                    Case "FlipX" : Form_Main.CheckBox_FlipX.Checked = l = "True"
                    Case "FlipY" : Form_Main.CheckBox_FlipY.Checked = l = "True"
                    Case "Zoom" : Form_Main.txt_Zoom.NumericValue = Val(Replace(l, ",", "."))
                    Case "ShiftX" : Form_Main.txt_ShiftX.NumericValue = Val(l)
                    Case "ShiftY" : Form_Main.txt_ShiftY.NumericValue = Val(l)
                    Case "CrossSize" : Form_Main.txt_CrossSize.NumericValueInteger = Val_Int(l)
                    Case "CrossColor" : Form_Main.txt_CrossColor.NumericValueInteger = Val_Int(l)
                        ' ------------------------------------------------------------------------------
                    Case "HiRes" : Form_Main.CheckBox_HiRes.Checked = l = "True"
                    Case "ZoomQuality" : Form_Main.txt_ZoomQuality.NumericValue = Val(l)
                    Case "JpegQuality" : Form_Main.txt_JpegQuality.NumericValue = Val(l)
                    Case "ResizeQuality" : Form_Main.txt_ResizeQuality.NumericValue = Val(l)
                        ' ------------------------------------------------------------------------------
                    Case "AutosaveSlot" : Form_Main.txt_AutosaveSlot.NumericValueInteger = Val_Int(l)
                    Case "FilePath" : Form_Main.txt_FilePath.Text = l
                    Case "FileName" : Form_Main.txt_FileName.Text = l
                    Case "FileFormat" : FileFormat = l
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form_Main)
        LimitFormPosition(Form_VideoInControls)
        '
    End Sub

    Public Function File_GetPath(ByVal str As String) As String
        Try
            Return IO.Path.GetDirectoryName(str) & "\"
        Catch
            Return str
        End Try
    End Function


    ' ==================================================================================================
    '  SAVE IMAGE
    ' ==================================================================================================
    Public Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)

        extension = LCase(extension)
        filename = RemoveExtension(filename)
        filename += "." & extension
        '
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, Quality)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function

End Module
