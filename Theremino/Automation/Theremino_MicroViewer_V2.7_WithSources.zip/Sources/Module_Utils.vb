﻿

Imports System.Management

Module Module_Utils


    ' =======================================================================================================
    '   Handle all exceptions
    ' =======================================================================================================
    Private Sub ShowError(ByVal sError As String, ByVal terminating As Boolean)
        MsgBox("Unfortunately the program has crashed !", MsgBoxStyle.Information)
        'MsgBox("We apologize for this inconvenient !", MsgBoxStyle.Information)
        MsgBox(">>> SUGGESTION: use ""CTRL-C"" to copy this text to the clipboard. <<<" & vbCr & vbCr & _
               sError, MsgBoxStyle.Information)
        If terminating Then
            MsgBox("Now the program will close." _
            & vbCr & vbCr & "Bye bye cruel word !", MsgBoxStyle.Information)
            End
        End If
    End Sub
    Private Sub MYExceptionHandler(ByVal sender As Object, ByVal e As UnhandledExceptionEventArgs)
        ShowError(e.ExceptionObject.ToString, e.IsTerminating)
    End Sub
    Private Sub MYThreadHandler(ByVal sender As Object, ByVal e As Threading.ThreadExceptionEventArgs)
        ShowError(e.Exception.ToString, True)
    End Sub
    Friend Sub HandleAllExceptons()
#If Not Debug Then
        AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf MYExceptionHandler
        AddHandler Application.ThreadException, AddressOf MYThreadHandler
#End If
    End Sub



    ' =======================================================================================
    '  CPU USAGE   >>> MUST BE CALLED ONE TIME EVERY SECOND <<<
    ' =======================================================================================
    Private TotalCpuCounter As PerformanceCounter
    Private ProcessCpuCounter As PerformanceCounter
    'Private MemoryCounter As PerformanceCounter
    Private WithEvents AsyncTimer1 As System.Timers.Timer
    Private Sub AsyncTimer1_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles AsyncTimer1.Elapsed
        AsyncTimer1.Stop()
        Try
            TotalCpuCounter = New PerformanceCounter("Processor", "% Processor Time", "_Total")
            ProcessCpuCounter = New PerformanceCounter("Process", "% Processor Time", Process.GetCurrentProcess.ProcessName)
            'MemoryCounter = New PerformanceCounter("Memory", "Available MBytes")
        Catch
        End Try
    End Sub
    Friend Sub TestCpuUsage(ByVal ProcessCpuPbox As PictureBox, ByVal TotalCpuPbox As PictureBox)
        If AsyncTimer1 Is Nothing Then
            AsyncTimer1 = New System.Timers.Timer
            AsyncTimer1.Interval = 1
            AsyncTimer1.Start()
        End If
        If TotalCpuCounter IsNot Nothing AndAlso ProcessCpuCounter IsNot Nothing Then
            Dim pcount As Int32 = System.Environment.ProcessorCount
            ProgressBar_Cpu(ProcessCpuPbox, ProcessCpuCounter.NextValue / pcount)
            ProgressBar_Cpu(TotalCpuPbox, TotalCpuCounter.NextValue)
        End If
    End Sub


    Private Sub ProgressBar_Cpu(ByVal pbox As PictureBox, ByVal PercentualCPU As Double)

        If pbox.Image Is Nothing Then
            InitPictureboxImage(pbox)
        End If

        If PercentualCPU < 0 Then PercentualCPU = 0
        If PercentualCPU > 100 Then PercentualCPU = 100
        '
        Dim r As Rectangle
        r.X = 0
        r.Y = 0
        r.Width = CInt(pbox.Width / 2) - 1   ' <--- (-1) to correct the vertical green line in the middle
        r.Height = pbox.Height
        Dim b1 As Drawing2D.LinearGradientBrush = New Drawing2D.LinearGradientBrush(r, _
                                                                            Color.FromArgb(100, 255, 0), _
                                                                            Color.FromArgb(255, 200, 0), _
                                                                            Drawing2D.LinearGradientMode.Horizontal)
        Dim b2 As Drawing2D.LinearGradientBrush = New Drawing2D.LinearGradientBrush(r, _
                                                                            Color.FromArgb(255, 200, 0), _
                                                                            Color.FromArgb(255, 0, 0), _
                                                                            Drawing2D.LinearGradientMode.Horizontal)
        '
        Dim v As Int32 = CInt((PercentualCPU * pbox.Width) / 100)
        Dim vmid As Int32 = CInt(pbox.Width / 2)

        ' ----------------------------------------------------------- using "Graphics.FromImage" for best performance
        'Dim g As Graphics = pbox.CreateGraphics
        Dim g As Graphics = Graphics.FromImage(pbox.Image)

        If PercentualCPU <= 50 Then
            g.FillRectangle(b1, 0, 0, v, pbox.ClientSize.Height)
        Else
            g.FillRectangle(b1, 0, 0, vmid, pbox.ClientSize.Height)
            g.FillRectangle(b2, vmid, 0, v - vmid, pbox.ClientSize.Height)
        End If
        Dim b As Brush = New SolidBrush(pbox.BackColor)
        g.FillRectangle(b, v, 0, pbox.ClientSize.Width - v, pbox.ClientSize.Height)
        '
        Dim f As Font = New Font("Tahoma", pbox.ClientSize.Height - 2, FontStyle.Regular, GraphicsUnit.Pixel)
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAliasGridFit
        g.DrawString(Str(Int(PercentualCPU)) & " %", f, Brushes.Black, CInt(pbox.Width / 2 - 17), 0)

        ' ----------------------------------------------------------- final refresh - no flickering
        pbox.Refresh()
    End Sub



    ' =======================================================================================
    '  CPU TIME MILLISEC   >>> MUST BE CALLED ABOUT 30 TIMES PER SECOND <<<
    ' =======================================================================================
    Private cpuTime_Font As Font
    Friend Sub ShowCpuTime(ByVal pbox As PictureBox, ByVal timeMicrosec As Double)

        If pbox.Image Is Nothing Then
            ' -------------------------------------------------------- using a image for best performance
            InitPictureboxImage(pbox)
            cpuTime_Font = New Font("Tahoma", pbox.ClientSize.Height - 2, FontStyle.Regular, GraphicsUnit.Pixel)
        End If

        Static tt As Double = 0
        Dim delta As Double
        'delta = (TimeMicrosec - tt) / (tt * 0.001 + 1)

        delta = (timeMicrosec - tt) * 0.005
        delta = Math.Sign(delta) * (Math.Abs(delta) ^ 2)
        If delta > 100000 Then delta = 100000
        If delta < -100000 Then delta = -100000
        tt += delta

        ' ----------------------------------------------------------- using "Graphics.FromImage" for best performance
        Dim g As Graphics = Graphics.FromImage(pbox.Image)
        g.Clear(Color.MintCream)
        g.DrawString((tt / 1000).ToString("0.0 mS"), cpuTime_Font, Brushes.Black, 2, 0)

        ' ----------------------------------------------------------- final refresh - no flickering
        pbox.Refresh()
    End Sub


    ' =======================================================================================
    '  Utils
    ' =======================================================================================
    Friend Sub SleepMyThread(ByVal TimeMillisec As Int32)
        System.Threading.Thread.Sleep(TimeMillisec)
    End Sub

    Friend Function Shell_NormalFocus(ByVal path As String) As Int32
        Try
            Return Shell(path, AppWinStyle.NormalFocus)
        Catch
            MsgBox("Cannot open the path: " & vbCr & path, MsgBoxStyle.Information)
            Return 0
        End Try
    End Function
    Friend Function MouseButtonLeftPressed() As Boolean
        Return (Control.MouseButtons And Windows.Forms.MouseButtons.Left) <> Windows.Forms.MouseButtons.None
    End Function
    Friend Function MouseButtonRightPressed() As Boolean
        Return (Control.MouseButtons And Windows.Forms.MouseButtons.Right) <> Windows.Forms.MouseButtons.None
    End Function


    ' ==============================================================================================================
    '   COMBO FUNCTIONS
    ' ==============================================================================================================
    Friend Sub Combo_Init(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            .Items.Clear()
            .Items.Add(str)
            .SelectedIndex = 0
        End With
        EventsAreEnabled = old
    End Sub
    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub
    Friend Function Combo_GetValue(ByVal combo As ComboBox) As String
        If combo.SelectedIndex < 0 Then Return ""
        Return combo.Items(combo.SelectedIndex).ToString()
    End Function
    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByVal index As Int32)
        If combo.Items.Count < 1 Then Exit Sub
        If index < 0 Then index = 0
        If index > combo.Items.Count - 1 Then index = combo.Items.Count - 1
        combo.SelectedIndex = index
    End Sub



    ' =============================================================================================
    '  ASYNC KEY and MOUSE STATE
    ' =============================================================================================
    Private Const PRESSED_NOW As Int32 = &H8000
    Private Const PRESSED_AFTER_PREVIOUS_CALL As Int32 = &H1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Int32) As Int16
    Friend Function KeyFromPreviousCall(ByVal k As Int32) As Boolean
        KeyFromPreviousCall = (GetAsyncKeyState(k) And PRESSED_AFTER_PREVIOUS_CALL) <> 0
    End Function
    Friend Function Key(ByVal k As Int32) As Boolean
        Key = (GetAsyncKeyState(k) And PRESSED_NOW) <> 0
    End Function
    'Friend Sub WaitMouseOff()
    '    While Key(Keys.LButton) Or Key(Keys.MButton) Or Key(Keys.RButton)
    '        SleepMyThread(1)
    '    End While
    'End Sub
    'Friend Sub WaitKeyOff(ByVal WaitKey As Long)
    '    Do
    '        SleepMyThread(1)
    '    Loop Until Not Key(WaitKey)
    'End Sub


    ' =======================================================================================================
    '   FadeIn and FadeOut 
    ' =======================================================================================================
    Friend Sub Forms_FadeTo(ByVal FinalValue As Double, ByVal TimeMillisec As Double)
        Try
            If TimeMillisec < 1 Then TimeMillisec = 1
            Dim v As Double
            Dim k As Double
            Dim date1 As Date
            '
            Dim StartValue As Double = Form_Main.Opacity
            '
            Application.DoEvents()
            System.Threading.Thread.Sleep(1)
            date1 = Date.Now
            Do
                k = Date.Now.Subtract(date1).TotalMilliseconds / TimeMillisec
                If k > 1 Then k = 1
                v = StartValue + (FinalValue - StartValue) * k
                If FinalValue = 0 Then
                    v = v * 0.5
                End If
                Form_Main.Opacity = v
                Form_VideoInControls.Opacity = v
                System.Threading.Thread.Sleep(20)
                'Debug.Print(v.ToString)
            Loop Until k >= 1
        Catch
            Form_Main.Opacity = 1
            Form_VideoInControls.Opacity = 1
        End Try
    End Sub

End Module
