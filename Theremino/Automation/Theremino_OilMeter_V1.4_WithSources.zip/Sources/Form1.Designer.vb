﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label_Quality = New System.Windows.Forms.Label
        Me.chk_FrontLed = New System.Windows.Forms.CheckBox
        Me.chk_RearLed = New System.Windows.Forms.CheckBox
        Me.Label_BaseSlot = New System.Windows.Forms.Label
        Me.GroupBox_Hardware = New System.Windows.Forms.GroupBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox_OilTester = New System.Windows.Forms.GroupBox
        Me.btn_AddReferenceWater = New System.Windows.Forms.Button
        Me.Label_ReferenceOils = New System.Windows.Forms.Label
        Me.btn_CompleteTest = New System.Windows.Forms.Button
        Me.btn_TransmissionTest = New System.Windows.Forms.Button
        Me.btn_AddReferenceOil = New System.Windows.Forms.Button
        Me.btn_DeleteAllReferences = New System.Windows.Forms.Button
        Me.btn_FluorescenceTest = New System.Windows.Forms.Button
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.GroupBox_Meters = New System.Windows.Forms.GroupBox
        Me.Label_Blue = New System.Windows.Forms.Label
        Me.Label_Red = New System.Windows.Forms.Label
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_FRA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ESP = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_DEU = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_JPN = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_Hardware = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_TestMethods = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_OliveOil = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.txt_BaseSlot = New Theremino_OilMeter.MyTextBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Hardware.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox_OilTester.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox_Meters.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Khaki
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(70, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(537, 28)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label_Quality
        '
        Me.Label_Quality.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Quality.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_Quality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Quality.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_Quality.Location = New System.Drawing.Point(364, 238)
        Me.Label_Quality.Name = "Label_Quality"
        Me.Label_Quality.Size = New System.Drawing.Size(56, 13)
        Me.Label_Quality.TabIndex = 2
        Me.Label_Quality.Text = "Quality"
        Me.Label_Quality.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chk_FrontLed
        '
        Me.chk_FrontLed.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_FrontLed.BackColor = System.Drawing.Color.Snow
        Me.chk_FrontLed.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chk_FrontLed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_FrontLed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_FrontLed.Location = New System.Drawing.Point(27, 204)
        Me.chk_FrontLed.Name = "chk_FrontLed"
        Me.chk_FrontLed.Size = New System.Drawing.Size(106, 22)
        Me.chk_FrontLed.TabIndex = 11
        Me.chk_FrontLed.Text = "Front LED"
        Me.chk_FrontLed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_FrontLed.UseVisualStyleBackColor = False
        '
        'chk_RearLed
        '
        Me.chk_RearLed.Appearance = System.Windows.Forms.Appearance.Button
        Me.chk_RearLed.BackColor = System.Drawing.Color.Snow
        Me.chk_RearLed.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chk_RearLed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chk_RearLed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_RearLed.Location = New System.Drawing.Point(27, 25)
        Me.chk_RearLed.Name = "chk_RearLed"
        Me.chk_RearLed.Size = New System.Drawing.Size(106, 22)
        Me.chk_RearLed.TabIndex = 14
        Me.chk_RearLed.Text = "Rear LED"
        Me.chk_RearLed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_RearLed.UseVisualStyleBackColor = False
        '
        'Label_BaseSlot
        '
        Me.Label_BaseSlot.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_BaseSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BaseSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_BaseSlot.Location = New System.Drawing.Point(20, 238)
        Me.Label_BaseSlot.Name = "Label_BaseSlot"
        Me.Label_BaseSlot.Size = New System.Drawing.Size(69, 13)
        Me.Label_BaseSlot.TabIndex = 12
        Me.Label_BaseSlot.Text = "Base Slot"
        Me.Label_BaseSlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_Hardware
        '
        Me.GroupBox_Hardware.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Hardware.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_Hardware.Controls.Add(Me.Label_BaseSlot)
        Me.GroupBox_Hardware.Controls.Add(Me.chk_FrontLed)
        Me.GroupBox_Hardware.Controls.Add(Me.chk_RearLed)
        Me.GroupBox_Hardware.Controls.Add(Me.txt_BaseSlot)
        Me.GroupBox_Hardware.Controls.Add(Me.PictureBox5)
        Me.GroupBox_Hardware.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Hardware.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_Hardware.Name = "GroupBox_Hardware"
        Me.GroupBox_Hardware.Size = New System.Drawing.Size(154, 261)
        Me.GroupBox_Hardware.TabIndex = 16
        Me.GroupBox_Hardware.TabStop = False
        Me.GroupBox_Hardware.Text = "Hardware"
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox5.BackColor = System.Drawing.Color.Honeydew
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox5.InitialImage = Nothing
        Me.PictureBox5.Location = New System.Drawing.Point(15, 21)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(127, 208)
        Me.PictureBox5.TabIndex = 15
        Me.PictureBox5.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.GroupBox_OilTester)
        Me.Panel1.Location = New System.Drawing.Point(13, 35)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(444, 271)
        Me.Panel1.TabIndex = 17
        '
        'GroupBox_OilTester
        '
        Me.GroupBox_OilTester.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_OilTester.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_OilTester.Controls.Add(Me.btn_AddReferenceWater)
        Me.GroupBox_OilTester.Controls.Add(Me.Label_ReferenceOils)
        Me.GroupBox_OilTester.Controls.Add(Me.btn_CompleteTest)
        Me.GroupBox_OilTester.Controls.Add(Me.btn_TransmissionTest)
        Me.GroupBox_OilTester.Controls.Add(Me.btn_AddReferenceOil)
        Me.GroupBox_OilTester.Controls.Add(Me.btn_DeleteAllReferences)
        Me.GroupBox_OilTester.Controls.Add(Me.btn_FluorescenceTest)
        Me.GroupBox_OilTester.Controls.Add(Me.PictureBox3)
        Me.GroupBox_OilTester.Controls.Add(Me.Label_Quality)
        Me.GroupBox_OilTester.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_OilTester.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_OilTester.Name = "GroupBox_OilTester"
        Me.GroupBox_OilTester.Size = New System.Drawing.Size(434, 261)
        Me.GroupBox_OilTester.TabIndex = 17
        Me.GroupBox_OilTester.TabStop = False
        Me.GroupBox_OilTester.Text = "Oil tester"
        '
        'btn_AddReferenceWater
        '
        Me.btn_AddReferenceWater.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_AddReferenceWater.Location = New System.Drawing.Point(186, 159)
        Me.btn_AddReferenceWater.Name = "btn_AddReferenceWater"
        Me.btn_AddReferenceWater.Size = New System.Drawing.Size(164, 42)
        Me.btn_AddReferenceWater.TabIndex = 17
        Me.btn_AddReferenceWater.Text = "Add reference water"
        Me.btn_AddReferenceWater.UseVisualStyleBackColor = True
        '
        'Label_ReferenceOils
        '
        Me.Label_ReferenceOils.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_ReferenceOils.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_ReferenceOils.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ReferenceOils.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_ReferenceOils.Location = New System.Drawing.Point(227, 208)
        Me.Label_ReferenceOils.Name = "Label_ReferenceOils"
        Me.Label_ReferenceOils.Size = New System.Drawing.Size(123, 42)
        Me.Label_ReferenceOils.TabIndex = 16
        Me.Label_ReferenceOils.Text = "0 reference oils"
        Me.Label_ReferenceOils.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_CompleteTest
        '
        Me.btn_CompleteTest.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_CompleteTest.Location = New System.Drawing.Point(11, 31)
        Me.btn_CompleteTest.Name = "btn_CompleteTest"
        Me.btn_CompleteTest.Size = New System.Drawing.Size(339, 55)
        Me.btn_CompleteTest.TabIndex = 15
        Me.btn_CompleteTest.Text = "Fluorescence and Transmission test"
        Me.btn_CompleteTest.UseVisualStyleBackColor = True
        '
        'btn_TransmissionTest
        '
        Me.btn_TransmissionTest.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_TransmissionTest.Location = New System.Drawing.Point(186, 92)
        Me.btn_TransmissionTest.Name = "btn_TransmissionTest"
        Me.btn_TransmissionTest.Size = New System.Drawing.Size(164, 42)
        Me.btn_TransmissionTest.TabIndex = 14
        Me.btn_TransmissionTest.Text = "Transmission test"
        Me.btn_TransmissionTest.UseVisualStyleBackColor = True
        '
        'btn_AddReferenceOil
        '
        Me.btn_AddReferenceOil.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_AddReferenceOil.Location = New System.Drawing.Point(11, 159)
        Me.btn_AddReferenceOil.Name = "btn_AddReferenceOil"
        Me.btn_AddReferenceOil.Size = New System.Drawing.Size(164, 42)
        Me.btn_AddReferenceOil.TabIndex = 13
        Me.btn_AddReferenceOil.Text = "Add reference oil"
        Me.btn_AddReferenceOil.UseVisualStyleBackColor = True
        '
        'btn_DeleteAllReferences
        '
        Me.btn_DeleteAllReferences.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_DeleteAllReferences.Location = New System.Drawing.Point(11, 208)
        Me.btn_DeleteAllReferences.Name = "btn_DeleteAllReferences"
        Me.btn_DeleteAllReferences.Size = New System.Drawing.Size(205, 42)
        Me.btn_DeleteAllReferences.TabIndex = 12
        Me.btn_DeleteAllReferences.Text = "Delete all reference data"
        Me.btn_DeleteAllReferences.UseVisualStyleBackColor = True
        '
        'btn_FluorescenceTest
        '
        Me.btn_FluorescenceTest.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_FluorescenceTest.Location = New System.Drawing.Point(11, 92)
        Me.btn_FluorescenceTest.Name = "btn_FluorescenceTest"
        Me.btn_FluorescenceTest.Size = New System.Drawing.Size(164, 42)
        Me.btn_FluorescenceTest.TabIndex = 11
        Me.btn_FluorescenceTest.Text = "Fluorescence test"
        Me.btn_FluorescenceTest.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.Khaki
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.Location = New System.Drawing.Point(365, 28)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(55, 201)
        Me.PictureBox3.TabIndex = 9
        Me.PictureBox3.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.GroupBox_Hardware)
        Me.Panel2.Location = New System.Drawing.Point(475, 35)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(164, 271)
        Me.Panel2.TabIndex = 18
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.GroupBox_Meters)
        Me.Panel3.Location = New System.Drawing.Point(13, 318)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(626, 100)
        Me.Panel3.TabIndex = 19
        '
        'GroupBox_Meters
        '
        Me.GroupBox_Meters.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Meters.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox_Meters.Controls.Add(Me.Label_Blue)
        Me.GroupBox_Meters.Controls.Add(Me.Label_Red)
        Me.GroupBox_Meters.Controls.Add(Me.PictureBox2)
        Me.GroupBox_Meters.Controls.Add(Me.PictureBox1)
        Me.GroupBox_Meters.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Meters.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox_Meters.Name = "GroupBox_Meters"
        Me.GroupBox_Meters.Size = New System.Drawing.Size(616, 90)
        Me.GroupBox_Meters.TabIndex = 17
        Me.GroupBox_Meters.TabStop = False
        Me.GroupBox_Meters.Text = "Meters"
        '
        'Label_Blue
        '
        Me.Label_Blue.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_Blue.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Blue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_Blue.Location = New System.Drawing.Point(9, 58)
        Me.Label_Blue.Name = "Label_Blue"
        Me.Label_Blue.Size = New System.Drawing.Size(52, 28)
        Me.Label_Blue.TabIndex = 10
        Me.Label_Blue.Text = "Blue" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "450 nm"
        Me.Label_Blue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Red
        '
        Me.Label_Red.BackColor = System.Drawing.Color.Cornsilk
        Me.Label_Red.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Red.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_Red.Location = New System.Drawing.Point(9, 23)
        Me.Label_Red.Name = "Label_Red"
        Me.Label_Red.Size = New System.Drawing.Size(52, 28)
        Me.Label_Red.TabIndex = 9
        Me.Label_Red.Text = "Red " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "650 nm" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label_Red.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.Khaki
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(70, 58)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(537, 28)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Timer1
        '
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 431)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(655, 29)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 20
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(10, Byte), Integer))
        Me.StatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust
        Me.StatusLabel1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(654, 24)
        Me.StatusLabel1.Text = "Ready"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(655, 24)
        Me.MenuStrip1.TabIndex = 154
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_ENG, Me.Menu_Language_ITA, Me.Menu_Language_FRA, Me.Menu_Language_ESP, Me.Menu_Language_DEU, Me.Menu_Language_JPN})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_ENG
        '
        Me.Menu_Language_ENG.Image = CType(resources.GetObject("Menu_Language_ENG.Image"), System.Drawing.Image)
        Me.Menu_Language_ENG.Name = "Menu_Language_ENG"
        Me.Menu_Language_ENG.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ENG.Text = "English"
        '
        'Menu_Language_ITA
        '
        Me.Menu_Language_ITA.Image = CType(resources.GetObject("Menu_Language_ITA.Image"), System.Drawing.Image)
        Me.Menu_Language_ITA.Name = "Menu_Language_ITA"
        Me.Menu_Language_ITA.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ITA.Text = "Italiano"
        '
        'Menu_Language_FRA
        '
        Me.Menu_Language_FRA.Image = CType(resources.GetObject("Menu_Language_FRA.Image"), System.Drawing.Image)
        Me.Menu_Language_FRA.Name = "Menu_Language_FRA"
        Me.Menu_Language_FRA.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_FRA.Text = "Francais"
        '
        'Menu_Language_ESP
        '
        Me.Menu_Language_ESP.Image = CType(resources.GetObject("Menu_Language_ESP.Image"), System.Drawing.Image)
        Me.Menu_Language_ESP.Name = "Menu_Language_ESP"
        Me.Menu_Language_ESP.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ESP.Text = "Espanol"
        '
        'Menu_Language_DEU
        '
        Me.Menu_Language_DEU.Image = CType(resources.GetObject("Menu_Language_DEU.Image"), System.Drawing.Image)
        Me.Menu_Language_DEU.Name = "Menu_Language_DEU"
        Me.Menu_Language_DEU.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_DEU.Text = "Deutsch"
        '
        'Menu_Language_JPN
        '
        Me.Menu_Language_JPN.Image = CType(resources.GetObject("Menu_Language_JPN.Image"), System.Drawing.Image)
        Me.Menu_Language_JPN.Name = "Menu_Language_JPN"
        Me.Menu_Language_JPN.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_JPN.Text = "Japanese"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.ToolStripSeparator2, Me.ToolStripSeparator3, Me.Menu_Help_Hardware, Me.Menu_Help_TestMethods, Me.Menu_Help_OliveOil, Me.ToolStripSeparator6, Me.Menu_Help_OpenProgramFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program help"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(183, 6)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(183, 6)
        '
        'Menu_Help_Hardware
        '
        Me.Menu_Help_Hardware.Image = CType(resources.GetObject("Menu_Help_Hardware.Image"), System.Drawing.Image)
        Me.Menu_Help_Hardware.Name = "Menu_Help_Hardware"
        Me.Menu_Help_Hardware.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_Hardware.Text = "Hardware info"
        '
        'Menu_Help_TestMethods
        '
        Me.Menu_Help_TestMethods.Image = CType(resources.GetObject("Menu_Help_TestMethods.Image"), System.Drawing.Image)
        Me.Menu_Help_TestMethods.Name = "Menu_Help_TestMethods"
        Me.Menu_Help_TestMethods.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_TestMethods.Text = "Test methods"
        '
        'Menu_Help_OliveOil
        '
        Me.Menu_Help_OliveOil.Image = CType(resources.GetObject("Menu_Help_OliveOil.Image"), System.Drawing.Image)
        Me.Menu_Help_OliveOil.Name = "Menu_Help_OliveOil"
        Me.Menu_Help_OliveOil.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_OliveOil.Text = "Olive oil info"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(183, 6)
        '
        'Menu_Help_OpenProgramFolder
        '
        Me.Menu_Help_OpenProgramFolder.Image = CType(resources.GetObject("Menu_Help_OpenProgramFolder.Image"), System.Drawing.Image)
        Me.Menu_Help_OpenProgramFolder.Name = "Menu_Help_OpenProgramFolder"
        Me.Menu_Help_OpenProgramFolder.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_OpenProgramFolder.Text = "Open program folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'txt_BaseSlot
        '
        Me.txt_BaseSlot.ArrowsIncrement = 1
        Me.txt_BaseSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_BaseSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BaseSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BaseSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BaseSlot.Increment = 0.2
        Me.txt_BaseSlot.Location = New System.Drawing.Point(95, 236)
        Me.txt_BaseSlot.MaxValue = 990
        Me.txt_BaseSlot.MinValue = 1
        Me.txt_BaseSlot.Multiline = True
        Me.txt_BaseSlot.Name = "txt_BaseSlot"
        Me.txt_BaseSlot.NumericValue = 800
        Me.txt_BaseSlot.NumericValueInteger = 800
        Me.txt_BaseSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BaseSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BaseSlot.RoundingStep = 0
        Me.txt_BaseSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BaseSlot.Size = New System.Drawing.Size(40, 15)
        Me.txt_BaseSlot.SuppressZeros = True
        Me.txt_BaseSlot.TabIndex = 13
        Me.txt_BaseSlot.Text = "800"
        Me.txt_BaseSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(655, 460)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Oil Meter"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Hardware.ResumeLayout(False)
        Me.GroupBox_Hardware.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox_OilTester.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.GroupBox_Meters.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label_Quality As System.Windows.Forms.Label
    Friend WithEvents Label_BaseSlot As System.Windows.Forms.Label
    Friend WithEvents chk_RearLed As System.Windows.Forms.CheckBox
    Friend WithEvents chk_FrontLed As System.Windows.Forms.CheckBox
    Friend WithEvents txt_BaseSlot As MyTextBox
    Friend WithEvents GroupBox_Hardware As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_OilTester As System.Windows.Forms.GroupBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_Meters As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label_Blue As System.Windows.Forms.Label
    Friend WithEvents Label_Red As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_FluorescenceTest As System.Windows.Forms.Button
    Friend WithEvents btn_AddReferenceOil As System.Windows.Forms.Button
    Friend WithEvents btn_DeleteAllReferences As System.Windows.Forms.Button
    Friend WithEvents btn_CompleteTest As System.Windows.Forms.Button
    Friend WithEvents btn_TransmissionTest As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_FRA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ESP As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_DEU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_JPN As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_Hardware As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_TestMethods As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_OliveOil As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label_ReferenceOils As System.Windows.Forms.Label
    Friend WithEvents btn_AddReferenceWater As System.Windows.Forms.Button

End Class
