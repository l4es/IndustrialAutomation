﻿
Public Class Form1

    ' ============================================================================================
    '  Constants and Variables 
    ' ============================================================================================
    Private FrontLedSlot As Int32
    Private RearLedSlot As Int32
    Private RedSensorSlot As Int32
    Private BlueSensorSlot As Int32

    Private FrontLedOn As Boolean = False
    Private RearLedOn As Boolean = False

    Private MeterBar1 As MeterBar
    Private MeterBar2 As MeterBar
    Private MeterBar3 As MeterBar

    Private ValuesStability As Single
    Private RedValueOld As Single
    Private BlueValueOld As Single
    Private RedValue As Single
    Private BlueValue As Single

    Private Quality As Single

    Friend Structure Measure
        Friend ZeroRed As Single
        Friend ZeroBlue As Single
        Friend FrontRed As Single
        Friend FrontBlue As Single
        Friend RearRed As Single
        Friend RearBlue As Single
    End Structure

    Friend ReferenceOils(-1) As Measure
    Friend ReferenceWaterCoefficient As Single = -1

    ' ============================================================================================
    '   User interface events 
    ' ============================================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' --------------------------------------------
        Load_INI()
        'ToolStrip1.Renderer = New ToolStripButtonRenderer
        StartThereminoHAL()
        Load_ReferenceData()
        SetLocales()
        SetParams()
        UpdateUserInterface()
        Text = AppTitleAndVersion("Theremino - Extra Virgin Oil Meter")
        MeterBar1 = New MeterBar(PictureBox1, 4)
        MeterBar2 = New MeterBar(PictureBox2, 5)
        MeterBar3 = New MeterBar(PictureBox3, 2)
        ' ------------------------------------------- FadeIn
        Refresh()
        Forms_FadeTo(1, 400)
        Timer1.Interval = 15
        Timer1.Start()
        ' -------------------------------------------
        EventsAreEnabled = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Forms_FadeTo(0, 500)
        Me.Refresh()
        Save_INI()
        StopThereminoHAL()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub UpdateUserInterface()
        SetLedOnOff()
        PrintStatus(1)
        PrintReferenceOilsCount()
        Refresh()
    End Sub


    ' =========================================================================
    '   THEREMINO HAL - START STOP -
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        Dim HalPath As String = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
        If Not FileExists(HalPath) Then HalPath = Application.StartupPath & "\Theremino_HAL.exe"
        If Not FileExists(HalPath) Then Return
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(HalPath)
        psi.FileName = HalPath
        HalProcess = Process.Start(psi)
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing AndAlso Not HalProcess.HasExited Then
            Try
                HalProcess.CloseMainWindow()
            Finally
            End Try
        End If
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        'Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
        '                                               Color.FromArgb(230, 230, 230), _
        '                                               Color.FromArgb(200, 200, 200), _
        '                                               Drawing2D.LinearGradientMode.Horizontal)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(150, 150, 150), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    'Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
    '    Dim bounds As New Rectangle(0, 0, _
    '                                ToolStrip1.Width, ToolStrip1.Height)
    '    Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
    '                                                   Color.White, _
    '                                                   Color.FromArgb(200, 200, 200), _
    '                                                   Drawing2D.LinearGradientMode.Vertical)
    '    e.Graphics.FillRectangle(brush, bounds)
    'End Sub


    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        Me.Close()
    End Sub

    ' =======================================================================================
    '   MENU LANGUAGE
    ' =======================================================================================
    Private Sub Menu_Language_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language.DropDownOpening
        For Each item As ToolStripMenuItem In Menu_Language.DropDownItems
            If item.Name.EndsWith(Language, StringComparison.InvariantCultureIgnoreCase) Then
                item.Select()
            End If
        Next
    End Sub
    Private Sub Menu_Language_DEU_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_DEU.Click
        Language = "DEU"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ENG_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ENG.Click
        Language = "ENG"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ESP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ESP.Click
        Language = "ESP"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_FRA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_FRA.Click
        Language = "FRA"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ITA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ITA.Click
        Language = "ITA"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_JPN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Language_JPN.Click
        Language = "JPN"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        OpenLocalizedHelp("Theremino_OilMeter_Help", ".pdf")
    End Sub
    Private Sub Menu_Help_Hardware_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_Hardware.Click
        OpenLocalizedHelp("Theremino_OilMeter_Hardware", ".pdf")
    End Sub
    Private Sub Menu_Help_TestMethods_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_TestMethods.Click
        OpenLocalizedHelp("Theremino_OilMeter_TestMethods", ".pdf")
    End Sub
    Private Sub Menu_Help_OliveOil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_OliveOil.Click
        OpenLocalizedHelp("Theremino_OilMeter_OliveOil", ".pdf")
    End Sub
    Private Sub Menu_Help_OpenProgramFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_OpenProgramFolder.Click
        Process.Start(Application.StartupPath)
    End Sub
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")
        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & Language & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog(Me)
    End Sub


    ' =======================================================================================
    '   PARAMS
    ' =======================================================================================
    Private Sub Params_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_BaseSlot.MouseLeave
        SetParams()
        Save_INI()
    End Sub
    Private Sub SetParams()
        RearLedSlot = txt_BaseSlot.NumericValueInteger
        FrontLedSlot = RearLedSlot + 1
        RedSensorSlot = RearLedSlot + 2
        BlueSensorSlot = RearLedSlot + 3
    End Sub


    ' =======================================================================================
    '   HARWARE CONTROLS
    ' =======================================================================================
    Private Sub chk_RearLed_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_RearLed.CheckedChanged
        RearLedOn = chk_RearLed.Checked
        SetLedOnOff()
    End Sub
    Private Sub chk_FrontLed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_FrontLed.CheckedChanged
        FrontLedOn = chk_FrontLed.Checked
        SetLedOnOff()
    End Sub
    Private Sub SetLedOnOff()
        Slots.WriteSlot(RearLedSlot, If(RearLedOn, 1000, 0))
        Slots.WriteSlot(FrontLedSlot, If(FrontLedOn, 1000, 0))
        '
        If RearLedOn And FrontLedOn Then
            PictureBox5.BackgroundImage = My.Resources.Hw4
        ElseIf RearLedOn Then
            PictureBox5.BackgroundImage = My.Resources.Hw3
        ElseIf FrontLedOn Then
            PictureBox5.BackgroundImage = My.Resources.Hw2
        Else
            PictureBox5.BackgroundImage = My.Resources.Hw1
        End If
        '
        If RearLedOn Or FrontLedOn Then
            PrintStatus(8)
        Else
            PrintStatus(1)
        End If
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return

        'RedValue = Slots.ReadSlot_NoNan(RedSensorSlot)
        'BlueValue = Slots.ReadSlot_NoNan(BlueSensorSlot)

        SmoothValue_Pow(RedValue, Slots.ReadSlot_NoNan(RedSensorSlot), 100)
        SmoothValue_Pow(BlueValue, Slots.ReadSlot_NoNan(BlueSensorSlot), 100)

        MeterBar1.SetValue(RedValue)
        MeterBar2.SetValue(BlueValue)
        ' ------------------------------------------------------------ stability
        Dim s1 As Single = Math.Abs(RedValue - RedValueOld) / (RedValue + 10)
        Dim s2 As Single = Math.Abs(BlueValue - BlueValueOld) / (BlueValue + 10)
        ValuesStability = Math.Max(s1, s2)
        RedValueOld = RedValue
        BlueValueOld = BlueValue
    End Sub

    Private Sub SmoothValue_Pow(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        Dim delta As Single = new_value - value
        Dim delta_sgn As Single = Math.Sign(delta)
        Dim delta_abs As Single = Math.Abs(delta)
        Dim delta_pow As Single
        delta_pow = CSng((0.003F * speed * delta_abs) ^ 2)
        If delta_pow >= delta_abs Then
            value = new_value
        Else
            value += delta_sgn * delta_pow
        End If
    End Sub


    ' =======================================================================================
    '  Oil Tester
    ' =======================================================================================
    Private Sub btn_CompleteTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CompleteTest.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        If ReferenceOils.Length > 0 Then
            If ReferenceWaterCoefficient > 0 Then
                DisableControls()
                MeterBar3.SetValue(0)
                Dim m As Measure = ReadValues("zero_front_rear")
                If TestZero(m) Then
                    CompareAllMeasures(m, "front_rear")
                    MeterBar3.SetValue(Quality * 10)
                    PrintStatus(5, Quality)
                End If
                EnableControls()
            Else
                PrintStatus(14)
            End If
        Else
            PrintStatus(13)
        End If
    End Sub
    Private Sub btn_FluorescenceTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_FluorescenceTest.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        If ReferenceOils.Length > 0 Then
            If ReferenceWaterCoefficient > 0 Then
                DisableControls()
                MeterBar3.SetValue(0)
                Dim m As Measure = ReadValues("zero_front")
                If TestZero(m) Then
                    CompareAllMeasures(m, "front")
                    MeterBar3.SetValue(Quality * 10)
                    PrintStatus(6, Quality)
                End If
                EnableControls()
            Else
                PrintStatus(14)
            End If
        Else
            PrintStatus(13)
        End If
    End Sub
    Private Sub btn_TransmissionTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_TransmissionTest.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        If ReferenceOils.Length > 0 Then
            If ReferenceWaterCoefficient > 0 Then
                DisableControls()
                MeterBar3.SetValue(0)
                Dim m As Measure = ReadValues("zero_rear")
                If TestZero(m) Then
                    CompareAllMeasures(m, "rear")
                    MeterBar3.SetValue(Quality * 10)
                    PrintStatus(7, Quality)
                End If
                EnableControls()
            Else
                PrintStatus(14)
            End If
        Else
            PrintStatus(13)
        End If
    End Sub
    Private Sub btn_AddReferenceOil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AddReferenceOil.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        If MsgBox(Msg_AddNewReferenceOil, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            DisableControls()
            MeterBar3.SetValue(0)
            Dim m As Measure = ReadValues("zero_front_rear")
            If TestZero(m) Then
                If TestValidExtraVirgin(m) Then
                    ReDim Preserve ReferenceOils(ReferenceOils.Length)
                    ReferenceOils(ReferenceOils.Length - 1) = m
                    Save_ReferenceData()
                    UpdateUserInterface()
                End If
            End If
            EnableControls()
        End If
    End Sub
    Private Sub btn_AddReferenceWater_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AddReferenceWater.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        If ReferenceOils.Length > 0 Then
            If MsgBox(Msg_AddReferenceWater, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                DisableControls()
                MeterBar3.SetValue(0)
                Dim m As Measure = ReadValues("zero_front_rear")
                If TestZero(m) Then
                    If TestValidWater(m) Then
                        For ReferenceWaterCoefficient = 0 To 5 Step 0.001
                            CompareAllMeasures(m, "zero_front_rear")
                            If Quality < 7 Then
                                Exit For
                            End If
                        Next
                        Save_ReferenceData()
                        UpdateUserInterface()
                    End If
                End If
                EnableControls()
            End If
        Else
            PrintStatus(13)
        End If
    End Sub
    Private Sub btn_DeleteAllReferences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_DeleteAllReferences.Click
        If MsgBox(Msg_DeleteAllReferences, MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            DisableControls()
            MeterBar3.SetValue(0)
            chk_RearLed.Checked = False
            chk_FrontLed.Checked = False
            ReDim ReferenceOils(-1)
            ReferenceWaterCoefficient = -1
            Save_ReferenceData()
            UpdateUserInterface()
            EnableControls()
        End If
    End Sub

    Friend Sub PrintReferenceOilsCount()
        Label_ReferenceOils.Text = If(ReferenceOils.Length <> 1, Msg_ReferenceOils, Msg_ReferenceOil) & " " & _
                                   ReferenceOils.Length.ToString & vbCrLf & _
                                   If(ReferenceWaterCoefficient > 0, Msg_ReferenceWaterOK, Msg_ReferenceWaterNO)
    End Sub

    Private Sub Label_ReferenceOils_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_ReferenceOils.Click
        Load_ReferenceData()
        PrintReferenceOilsCount()
        Process.Start(Application.StartupPath & "\ReferenceData.txt")
    End Sub

    Private Function ReadValues(ByVal test As String) As Measure
        Dim m As Measure
        ' -----------------------------------------
        If test.ToLower.Contains("front") Then
            chk_RearLed.Checked = False
            chk_FrontLed.Checked = True
            PrintStatus(3)
            WaitStability()
            m.FrontRed = RedValue
            m.FrontBlue = BlueValue
        End If
        ' -----------------------------------------
        If test.ToLower.Contains("rear") Then
            chk_RearLed.Checked = True
            chk_FrontLed.Checked = False
            PrintStatus(4)
            WaitStability()
            m.RearRed = RedValue
            m.RearBlue = BlueValue
        End If
        ' -----------------------------------------
        If test.ToLower.Contains("zero") Then
            chk_RearLed.Checked = False
            chk_FrontLed.Checked = False
            PrintStatus(2)
            WaitStability()
            m.ZeroRed = RedValue
            m.ZeroBlue = BlueValue
        End If
        ' -----------------------------------------
        chk_RearLed.Checked = False
        chk_FrontLed.Checked = False
        Return m
    End Function

    Private Sub WaitStability()
        Dim counter As Int32 = 0
        ValuesStability = 100
        System.Threading.Thread.Sleep(15)
        For i As Int32 = 1 To 300
            Application.DoEvents()
            System.Threading.Thread.Sleep(15)
            If ValuesStability > 0.001 Then
                counter = 0
            Else
                counter += 1
                If counter > 40 Then
                    'Debug.Print(ValuesStability.ToString)
                    Return
                End If
            End If
        Next
        MsgBox(Msg_NotStabilized_1 & vbCrLf & vbCrLf & _
               Msg_NotStabilized_2 & vbCrLf & _
               Msg_NotStabilized_3, MsgBoxStyle.Critical)
    End Sub

    Private Sub CompareAllMeasures(ByVal m1 As Measure, ByVal test As String)
        Dim c As Single = 9999
        For i As Int32 = 0 To ReferenceOils.Length - 1
            c = Math.Min(c, CompareMeasures(m1, ReferenceOils(i), test))
        Next
        Quality = 1 - c * ReferenceWaterCoefficient
        If Quality < 0 Then Quality = 0
        'Quality = CSng(Math.Pow(Quality, 4))
        Quality = 100 * Quality
    End Sub

    Private Function CompareMeasures(ByVal m1 As Measure, ByVal m2 As Measure, ByVal test As String) As Single
        CompareMeasures = 0
        Dim n As Int32 = 0
        If test.ToLower.Contains("front") Then
            CompareMeasures += Percentual(m1.FrontBlue - m1.ZeroBlue, m2.FrontBlue - m2.ZeroBlue)
            CompareMeasures += Percentual(m1.FrontRed - m1.ZeroRed, m2.FrontRed - m2.ZeroRed)
            n += 2
        End If
        If test.ToLower.Contains("rear") Then
            CompareMeasures += Percentual(m1.RearBlue - m1.ZeroBlue, m2.RearBlue - m2.ZeroBlue)
            CompareMeasures += Percentual(m1.RearRed - m1.ZeroRed, m2.RearRed - m2.ZeroRed)
            n += 2
        End If
        If n > 0 Then CompareMeasures /= n
    End Function

    Private Function Percentual(ByVal v1 As Single, ByVal v2 As Single) As Single
        Return 2 * Math.Abs(v1 - v2) / (v1 + v2)
    End Function

    Private Function TestZero(ByVal m As Measure) As Boolean
        If m.ZeroRed > 90 Or m.ZeroBlue > 90 Then
            PrintStatus(11)
            Return False
        End If
        If m.ZeroRed < 0.5 Or m.ZeroBlue < 0.5 Then
            PrintStatus(12)
            Return False
        End If
        Return True
    End Function

    Private Function TestValidExtraVirgin(ByVal m As Measure) As Boolean
        If m.FrontRed < 1.2 * m.FrontBlue Then
            PrintStatus(15)
            Return False
        End If
        Return True
    End Function

    Private Function TestValidWater(ByVal m As Measure) As Boolean
        If m.FrontRed > 0.5 * m.FrontBlue Then
            PrintStatus(16)
            Return False
        End If
        Return True
    End Function

    Private Sub DisableControls()
        For Each c As Control In Me.Controls
            If c.Name.Contains("Menu") Then
                c.Enabled = False
            End If
        Next
        For Each c As Control In Me.GroupBox_OilTester.Controls
            c.Enabled = False
        Next
        For Each c As Control In Me.GroupBox_Hardware.Controls
            c.Enabled = False
        Next
    End Sub

    Private Sub EnableControls()
        For Each c As Control In Me.Controls
            If c.Name.Contains("Menu") Then
                c.Enabled = True
            End If
        Next
        For Each c As Control In Me.GroupBox_OilTester.Controls
            c.Enabled = True
        Next
        For Each c As Control In Me.GroupBox_Hardware.Controls
            c.Enabled = True
        Next
    End Sub

    Private Sub PrintStatus(ByVal status As Int32, _
                            Optional ByVal q As Single = 0)

        Dim colors As String = ""

        Select Case status
            Case 1
                StatusLabel1.Text = Msg_Ready
            Case 2
                StatusLabel1.Text = Msg_ZeroLightTest
                colors = "zero"
            Case 3
                StatusLabel1.Text = Msg_UvFluorescenceTest
                colors = "UV"
            Case 4
                StatusLabel1.Text = Msg_UvTransmissionTest
                colors = "UV"
            Case 5
                StatusLabel1.Text = Msg_Quality & q.ToString(" 0.0", Globalization.CultureInfo.InvariantCulture) & "% - "
                If q > 95 Then
                    StatusLabel1.Text &= Msg_ExtraQualityOliveOil
                ElseIf q > 90 Then
                    StatusLabel1.Text &= Msg_GoodQualityOliveOil
                ElseIf q > 80 Then
                    StatusLabel1.Text &= Msg_MediumQualityOliveOil
                    colors = "warning"
                ElseIf q > 70 Then
                    StatusLabel1.Text &= Msg_PoorQualityOliveOil
                    colors = "warning"
                ElseIf q > 60 Then
                    StatusLabel1.Text &= Msg_VeryPoorQualityOliveOil
                    colors = "warning"
                ElseIf q > 50 Then
                    StatusLabel1.Text &= Msg_VeryLowPercentage
                    colors = "warning"
                ElseIf q > 40 Then
                    StatusLabel1.Text &= Msg_SeedPomace_1
                    colors = "error"
                ElseIf q > 20 Then
                    StatusLabel1.Text &= Msg_SeedPomace_2
                    colors = "error"
                Else
                    StatusLabel1.Text = Msg_NoLiquidOrError
                    colors = "error"
                End If
            Case 6
                StatusLabel1.Text = Msg_Quality & q.ToString(" 0.0", Globalization.CultureInfo.InvariantCulture) & "% - "
                StatusLabel1.Text &= Msg_PartialTest_1
            Case 7
                StatusLabel1.Text = Msg_Quality & q.ToString(" 0.0", Globalization.CultureInfo.InvariantCulture) & "% - "
                StatusLabel1.Text &= Msg_PartialTest_2
            Case 8
                StatusLabel1.Text = Msg_ManualTest
                colors = "warning"

            Case 10
                StatusLabel1.Text = Msg_Error
                colors = "error"
            Case 11
                StatusLabel1.Text = Msg_ZeroValuesHigh
                colors = "error"
            Case 12
                StatusLabel1.Text = Msg_ZeroValuesLow
                colors = "error"
            Case 13
                StatusLabel1.Text = Msg_NoReferenceOils
                colors = "error"
            Case 14
                StatusLabel1.Text = Msg_NoReferenceWater
                colors = "error"
            Case 15
                StatusLabel1.Text = Msg_NotValidReferenceOil
                colors = "error"
            Case 16
                StatusLabel1.Text = Msg_NotValidReferenceWater
                colors = "error"
        End Select

        Select Case colors
            Case "zero"
                StatusLabel1.BackColor = Color.FromArgb(40, 40, 40)
                StatusLabel1.ForeColor = Color.FromArgb(255, 255, 220)
            Case "UV"
                StatusLabel1.BackColor = Color.FromArgb(60, 0, 120)
                StatusLabel1.ForeColor = Color.FromArgb(255, 100, 40) '(220, 180, 255)
            Case "warning"
                StatusLabel1.BackColor = Color.FromArgb(60, 0, 120) '(60, 40, 20)
                StatusLabel1.ForeColor = Color.FromArgb(255, 210, 0)
            Case "error"
                StatusLabel1.BackColor = Color.FromArgb(100, 0, 0)
                StatusLabel1.ForeColor = Color.FromArgb(255, 255, 0)
            Case ""
                StatusLabel1.BackColor = Color.FromArgb(50, 60, 10)
                StatusLabel1.ForeColor = Color.FromArgb(240, 255, 0)
        End Select
    End Sub

End Class