﻿Imports System.Windows.Forms

Module Utils_LocaleNames

    Friend Language As String = "ENG"
    Private ls(1, -1) As String

    Friend Sub SetLocales()
        ' ------------------------------------- read the file
        ReadLocaleFile()
        ' ------------------------------------- rename
        RenameControls(Form1)
        ' ------------------------------------- release the array
        ReDim ls(-1, -1)
    End Sub

    Private Sub ReadLocaleFile()
        Dim locfilename As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\Language_" & Language & ".txt")
        If Not FileExists(locfilename) Then
            locfilename = PlatformAdjustedFileName(Application.StartupPath & "\Docs\Language_ENG.txt")
        End If
        If FileExists(locfilename) Then
            Dim i As Int32 = -1
            Dim s0 As String
            Dim s1 As String
            '
            Dim f As IO.StreamReader
            f = New System.IO.StreamReader(locfilename, System.Text.Encoding.Default)
            '
            Do While Not f.EndOfStream
                s1 = f.ReadLine
                s1 = Trim(s1.Replace(vbTab, " "))
                s0 = ExtractParamName(s1)
                If s0.Length > 1 And s1.Length > 1 Then
                    If s0.StartsWith("Msg_") Then
                        AddMessage(s0, s1)
                    Else
                        i += 1
                        RedimPreserve_2D_Array(ls, 1, i)
                        ls(0, i) = s0
                        ls(1, i) = s1
                    End If
                End If
            Loop
            f.Close()
        End If
    End Sub

    ' ===============================================================================================
    '  RENAME CONTROLS
    ' ===============================================================================================
    Private Sub RenameControls(ByVal container As Control)
        '
        For i As Int32 = 0 To ls.GetLength(1) - 1
            If container.Name = ls(0, i) Then
                container.Text = ls(1, i)
            End If
        Next
        '
        For Each ctrl As Control In container.Controls
            For i As Int32 = 0 To ls.GetLength(1) - 1

                If ctrl.Name = ls(0, i) Then
                    ctrl.Text = ls(1, i)
                End If

                If TypeOf ctrl Is ToolStrip Then
                    Dim ts As ToolStrip = DirectCast(ctrl, ToolStrip)
                    RenameToolStripItems(ts)
                End If

                If TypeOf ctrl Is MenuStrip Then
                    Dim ms As MenuStrip = DirectCast(ctrl, MenuStrip)
                    RenameMenuStripItems(ms)
                End If
            Next
            ' ---------------------------- Recursively call this function for any container controls.
            If container.HasChildren Then
                RenameControls(ctrl)
            End If
        Next
    End Sub

    Private Sub RenameToolStripItems(ByRef ts As ToolStrip)
        For i As Int32 = 0 To ls.GetLength(1) - 1
            For j As Int32 = 0 To ts.Items.Count - 1
                If ts.Items(j).Name = ls(0, i) Then
                    ts.Items(j).Text = " " & ls(1, i)
                End If
            Next
        Next
    End Sub

    Private Sub RenameMenuStripItems(ByRef ms As MenuStrip)
        For i As Int32 = 0 To ls.GetLength(1) - 1
            For j As Int32 = 0 To ms.Items.Count - 1
                If ms.Items(j).Name = ls(0, i) Then
                    ms.Items(j).Text = " " & ls(1, i)
                End If
                Dim tsmi As ToolStripMenuItem = DirectCast(ms.Items(j), ToolStripMenuItem)
                For k As Int32 = 0 To tsmi.DropDownItems.Count - 1
                    If tsmi.DropDownItems(k).Name = ls(0, i) Then
                        tsmi.DropDownItems(k).Text = " " & ls(1, i)
                    End If
                Next
            Next
        Next
    End Sub


    ' ===============================================================================================
    '  MESSAGES
    ' ===============================================================================================
    Friend Msg_Ready As String = "Ready"
    Friend Msg_ZeroLightTest As String = "Zero light test"
    Friend Msg_UvFluorescenceTest As String = "UV fluorescence test"
    Friend Msg_UvTransmissionTest As String = "UV transmission test"
    Friend Msg_Quality As String = "Quality"
    Friend Msg_ExtraQualityOliveOil As String = "Extra quality Olive Oil"
    Friend Msg_GoodQualityOliveOil As String = "Good quality Olive Oil"
    Friend Msg_MediumQualityOliveOil As String = "Medium quality Olive Oil"
    Friend Msg_PoorQualityOliveOil As String = "Poor quality Olive Oil"
    Friend Msg_VeryPoorQualityOliveOil As String = "Very poor quality Olive Oil"
    Friend Msg_VeryLowPercentage As String = "Very low percentage of Olive Oil--"
    Friend Msg_SeedPomace_1 As String = "Seed, pomace or lamp oil"
    Friend Msg_SeedPomace_2 As String = "Water or some other undefined liquid"
    Friend Msg_NoLiquidOrError As String = "No liquid or error"
    Friend Msg_PartialTest_1 As String = "Partial test - Fluorescence only"
    Friend Msg_PartialTest_2 As String = "Partial test - Absorption only"
    Friend Msg_AddNewReferenceOil As String = "Add a new reference oil?"
    Friend Msg_AddReferenceWater As String = "Add reference water?"
    Friend Msg_DeleteAllReferences As String = "Delete all old references?"
    Friend Msg_ReferenceOil As String = "reference oil"
    Friend Msg_ReferenceOils As String = "reference oils"
    Friend Msg_ReferenceWaterOK As String = "Reference water OK"
    Friend Msg_ReferenceWaterNO As String = "NO reference water"
    Friend Msg_About_1 As String = "Only consumers are really interested in testing the oil."
    Friend Msg_About_2 As String = "Only consumers can test each bottle."
    Friend Msg_ManualTest As String = "Manual test - Warning: A long test can change led temperatures."

    Friend Msg_Error As String = "Error"
    Friend Msg_ZeroValuesHigh As String = "Zero values are high. Too much ambient light?"
    Friend Msg_ZeroValuesLow As String = "Zero values are low. Please test HAL configuration and hardware."
    Friend Msg_NotStabilized_1 As String = "Measure not stabilized."
    Friend Msg_NotStabilized_2 As String = "Please test HAL configuration and hardware."
    Friend Msg_NotStabilized_3 As String = "Please configure HAL pins 3 and 4 with ""Response speed = 30"""
    Friend Msg_NoReferenceOils As String = "No reference oils. Please add one or more reference oil."
    Friend Msg_NoReferenceWater As String = "No reference water. Please add a reference water."
    Friend Msg_NotValidReferenceOil As String = "This is not a valid reference oil (low 650nm fluorescence)"
    Friend Msg_NotValidReferenceWater As String = "This is not a valid reference water (high 650nm fluorescence)"

    Private Sub AddMessage(ByVal s0 As String, ByVal s1 As String)
        Select Case s0
            Case "Msg_Ready" : Msg_Ready = s1
            Case "Msg_ZeroLightTest" : Msg_ZeroLightTest = s1
            Case "Msg_UvFluorescenceTest" : Msg_UvFluorescenceTest = s1
            Case "Msg_UvTransmissionTest" : Msg_UvTransmissionTest = s1
            Case "Msg_Quality" : Msg_Quality = s1
            Case "Msg_ExtraQualityOliveOil" : Msg_ExtraQualityOliveOil = s1
            Case "Msg_GoodQualityOliveOil" : Msg_GoodQualityOliveOil = s1
            Case "Msg_MediumQualityOliveOil" : Msg_MediumQualityOliveOil = s1
            Case "Msg_PoorQualityOliveOil" : Msg_PoorQualityOliveOil = s1
            Case "Msg_VeryPoorQualityOliveOil" : Msg_VeryPoorQualityOliveOil = s1
            Case "Msg_VeryLowPercentage" : Msg_VeryLowPercentage = s1
            Case "Msg_SeedPomace_1" : Msg_SeedPomace_1 = s1
            Case "Msg_SeedPomace_2" : Msg_SeedPomace_2 = s1
            Case "Msg_NoLiquidOrError" : Msg_NoLiquidOrError = s1
            Case "Msg_PartialTest_1" : Msg_PartialTest_1 = s1
            Case "Msg_PartialTest_2" : Msg_PartialTest_2 = s1
            Case "Msg_AddNewReferenceOil" : Msg_AddNewReferenceOil = s1
            Case "Msg_AddReferenceWater" : Msg_AddReferenceWater = s1
            Case "Msg_DeleteAllReferences" : Msg_DeleteAllReferences = s1
            Case "Msg_ReferenceOil" : Msg_ReferenceOil = s1
            Case "Msg_ReferenceOils" : Msg_ReferenceOils = s1
            Case "Msg_ReferenceWaterOK" : Msg_ReferenceWaterOK = s1
            Case "Msg_ReferenceWaterNO" : Msg_ReferenceWaterNO = s1
            Case "Msg_About_1" : Msg_About_1 = s1
            Case "Msg_About_2" : Msg_About_2 = s1
            Case "Msg_ManualTest" : Msg_ManualTest = s1
                '
            Case "Msg_Error" : Msg_Error = s1
            Case "Msg_ZeroValuesHigh" : Msg_ZeroValuesHigh = s1
            Case "Msg_ZeroValuesLow" : Msg_ZeroValuesLow = s1
            Case "Msg_NotStabilized_1" : Msg_NotStabilized_1 = s1
            Case "Msg_NotStabilized_2" : Msg_NotStabilized_2 = s1
            Case "Msg_NotStabilized_3" : Msg_NotStabilized_3 = s1
            Case "Msg_NoReferenceOils" : Msg_NoReferenceOils = s1
            Case "Msg_NoReferenceWater" : Msg_NoReferenceWater = s1
            Case "Msg_NotValidReferenceOil" : Msg_NotValidReferenceOil = s1
            Case "Msg_NotValidReferenceWater" : Msg_NotValidReferenceWater = s1
        End Select
    End Sub

End Module
