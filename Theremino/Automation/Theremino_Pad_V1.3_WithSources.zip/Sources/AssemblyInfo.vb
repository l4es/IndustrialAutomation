Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.



<Assembly: AssemblyTitle("Theremino_Pad")> 
<Assembly: AssemblyDescription("Theremino Pad")> 
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("Theremino_Pad")> 
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyTrademark("Theremino")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.3")> 



<Assembly: ComVisibleAttribute(False)> 
<Assembly: AssemblyFileVersionAttribute("1.3")> 