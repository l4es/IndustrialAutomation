<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Timer1 As System.Windows.Forms.Timer
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_SetCursorPos = New MyButton
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.txt_FirstSlot = New MyTextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.PictureBox_Test = New System.Windows.Forms.PictureBox
        Me.GroupBox9.SuspendLayout()
        CType(Me.PictureBox_Test, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'btn_SetCursorPos
        '
        Me.btn_SetCursorPos.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetCursorPos.CenterPtTracker = DesignerRectTracker1
        Me.btn_SetCursorPos.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SetCursorPos.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SetCursorPos.ColorFillBlendChecked = CBlendItems2
        Me.btn_SetCursorPos.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SetCursorPos.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SetCursorPos.Corners.All = CType(6, Short)
        Me.btn_SetCursorPos.Corners.LowerLeft = CType(6, Short)
        Me.btn_SetCursorPos.Corners.LowerRight = CType(6, Short)
        Me.btn_SetCursorPos.Corners.UpperLeft = CType(6, Short)
        Me.btn_SetCursorPos.Corners.UpperRight = CType(6, Short)
        Me.btn_SetCursorPos.DimFactorOver = 30
        Me.btn_SetCursorPos.FillType = MyButton.eFillType.LinearVertical
        Me.btn_SetCursorPos.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_SetCursorPos.FocalPoints.CenterPtX = 0.01020408!
        Me.btn_SetCursorPos.FocalPoints.CenterPtY = 0.5!
        Me.btn_SetCursorPos.FocalPoints.FocusPtX = 0.0!
        Me.btn_SetCursorPos.FocalPoints.FocusPtY = 0.0!
        Me.btn_SetCursorPos.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_SetCursorPos.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_SetCursorPos.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SetCursorPos.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetCursorPos.FocusPtTracker = DesignerRectTracker2
        Me.btn_SetCursorPos.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SetCursorPos.Image = Nothing
        Me.btn_SetCursorPos.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetCursorPos.ImageIndex = 0
        Me.btn_SetCursorPos.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SetCursorPos.Location = New System.Drawing.Point(13, 349)
        Me.btn_SetCursorPos.Name = "btn_SetCursorPos"
        Me.btn_SetCursorPos.Shape = MyButton.eShape.Rectangle
        Me.btn_SetCursorPos.SideImage = Nothing
        Me.btn_SetCursorPos.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetCursorPos.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SetCursorPos.Size = New System.Drawing.Size(240, 24)
        Me.btn_SetCursorPos.TabIndex = 157
        Me.btn_SetCursorPos.Text = "Set Cursor Pos  -  (CTRL to disable)"
        Me.btn_SetCursorPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetCursorPos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SetCursorPos.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SetCursorPos.TextShadow = System.Drawing.Color.Transparent
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox9.Controls.Add(Me.txt_FirstSlot)
        Me.GroupBox9.Controls.Add(Me.Label13)
        Me.GroupBox9.Controls.Add(Me.btn_SetCursorPos)
        Me.GroupBox9.Controls.Add(Me.PictureBox_Test)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(7, 7)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(505, 379)
        Me.GroupBox9.TabIndex = 145
        Me.GroupBox9.TabStop = False
        '
        'txt_FirstSlot
        '
        Me.txt_FirstSlot.ArrowsIncrement = 1
        Me.txt_FirstSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_FirstSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FirstSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FirstSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FirstSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_FirstSlot.Increment = 0.2
        Me.txt_FirstSlot.Location = New System.Drawing.Point(442, 354)
        Me.txt_FirstSlot.MaxValue = 999
        Me.txt_FirstSlot.MinValue = 0
        Me.txt_FirstSlot.Name = "txt_FirstSlot"
        Me.txt_FirstSlot.NumericValue = 1
        Me.txt_FirstSlot.NumericValueInteger = 1
        Me.txt_FirstSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FirstSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FirstSlot.RoundingStep = 0
        Me.txt_FirstSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FirstSlot.Size = New System.Drawing.Size(40, 15)
        Me.txt_FirstSlot.SuppressZeros = True
        Me.txt_FirstSlot.TabIndex = 175
        Me.txt_FirstSlot.Text = "1"
        Me.txt_FirstSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(385, 355)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(55, 13)
        Me.Label13.TabIndex = 176
        Me.Label13.Text = "First slot"
        '
        'PictureBox_Test
        '
        Me.PictureBox_Test.BackColor = System.Drawing.Color.AliceBlue
        Me.PictureBox_Test.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_Test.Location = New System.Drawing.Point(13, 16)
        Me.PictureBox_Test.Name = "PictureBox_Test"
        Me.PictureBox_Test.Size = New System.Drawing.Size(473, 324)
        Me.PictureBox_Test.TabIndex = 153
        Me.PictureBox_Test.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(516, 391)
        Me.Controls.Add(Me.GroupBox9)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(17, 22)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Pad"
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.PictureBox_Test, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox_Test As System.Windows.Forms.PictureBox
    Friend WithEvents btn_SetCursorPos As MyButton
    Friend WithEvents txt_FirstSlot As MyTextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
#End Region
End Class