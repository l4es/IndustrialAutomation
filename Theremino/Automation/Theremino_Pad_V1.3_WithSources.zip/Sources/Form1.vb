
Imports System.Math

Friend Class Form1
    Inherits System.Windows.Forms.Form

    Private Sub frmMain_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        '
        ' ---------------------------------------------------------------- 
        EventsAreEnabled = False
        Load_INI()
        StartThereminoHAL()
        GetScreenSize()
        ' ---------------------------------------------------------------- INIT
        Show()
        Refresh()
        ' ---------------------------------------------------------------- TIMER 60Hz 
        Timer1.Interval = 15 'with interval < 16 the timer is about 16.6mS ( 60 Hz )
        Timer1.Enabled = True
        '
        Text = AppTitleAndVersion("Theremino Pad")
        '
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
        CloseAll()
    End Sub

    Friend Sub CloseAll()
        EventsAreEnabled = False
        Timer1.Enabled = False
        StopThereminoHAL()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub txt_FirstSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_FirstSlot.TextChanged
        slotX1 = txt_FirstSlot.NumericValueInteger
        slotY1 = slotX1 + 1
    End Sub


    ' =========================================================================
    '   THEREMINO HAL - START STOP -
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        Dim path As String = Application.StartupPath & "\Theremino_HAL.exe"
        If Not My.Computer.FileSystem.FileExists(path) Then
            path = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
        End If
        If Not My.Computer.FileSystem.FileExists(path) Then Return
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(path)
        psi.FileName = path
        HalProcess = Process.Start(psi)
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing AndAlso Not HalProcess.HasExited Then
            Try
                HalProcess.CloseMainWindow()
            Finally
            End Try
        End If
    End Sub


    ' ==============================================================================================================
    '   AUTO SAVE FOR ALL PARAMS - USING LostFocus
    ' ==============================================================================================================
    Private Sub btn_ShowXY_CheckedChanged(ByVal Sender As Object, ByVal e As System.EventArgs)
        If Not EventsAreEnabled Then Return
        PictureBox_Test.Image = Nothing
    End Sub
    Private Sub btn_SetCursorPos_CheckedChanged(ByVal Sender As Object, ByVal e As System.EventArgs) Handles btn_SetCursorPos.CheckedChanged
        If Not EventsAreEnabled Then Return
        PictureBox_Test.Image = Nothing
    End Sub


    ' ==============================================================================================================
    '   Screen size
    ' ==============================================================================================================
    Private ScreenSize As Size
    Private Sub GetScreenSize()
        ScreenSize = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Size
    End Sub

    ' ==============================================================================================================
    '   TIMER
    ' ==============================================================================================================
    Private slotX1 As Int32
    Private slotY1 As Int32
    Private min As Single = 0
    Private max As Single = 1000

    Private Sub Timer1_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        ' ---------------------------------------------------------------------------
        If My.Computer.Keyboard.CtrlKeyDown Then btn_SetCursorPos.Checked = False
        ' ---------------------------------------------------------------------------
        '
        Dim x As Single
        Dim y As Single

        x = (Slots.ReadSlot_NoNan(slotX1) - min) / (max - min)
        y = (Slots.ReadSlot_NoNan(slotY1) - min) / (max - min)

        DisplayPictureBoxMarker(PictureBox_Test, x, y)

        If btn_SetCursorPos.Checked Then
            Cursor.Position = New Point(CInt(ScreenSize.Width * x), CInt(ScreenSize.Height * y))
        End If
    End Sub


End Class