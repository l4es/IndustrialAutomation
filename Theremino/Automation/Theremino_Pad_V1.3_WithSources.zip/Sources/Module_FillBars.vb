Module Module_FillBars

    ' =======================================================================================
    '  PBOX Functions
    ' =======================================================================================
    Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
        With pbox
            If .ClientSize.Width < 1 Then Return
            .Image = New Bitmap(.ClientSize.Width, .ClientSize.Height)
        End With
    End Sub

    Friend Sub DisplayPictureBoxMarker(ByVal pbox As PictureBox, ByVal x As Double, ByVal y As Double)
        ' ------------------------------------------------ using a bitmap for best performance
        If pbox.Image Is Nothing Then
            InitPictureboxImage(pbox)
        End If
        ' ------------------------------------------------ using "Graphics.FromImage" for best performance
        Dim g As Graphics = Graphics.FromImage(pbox.Image)
        Const Diam As Single = 16
        Dim px As Single = CSng(x * (pbox.ClientSize.Width - Diam - 1))
        Dim py As Single = CSng((1 - y) * (pbox.ClientSize.Height - Diam - 1))
        Dim d2 As Single = CSng(Diam / 2)
        Dim p As Pen = New Pen(Color.Black, 2)
        ' ------------------------------------------------ delete old marker
        Static OldPx As Single
        Static OldPy As Single
        g.FillRectangle(New SolidBrush(Color.AliceBlue), OldPx, OldPy, Diam + 2, Diam + 2)
        pbox.Invalidate(New Rectangle(CInt(OldPx), CInt(OldPy), CInt(Diam + 2), CInt(Diam + 2)))
        OldPx = px
        OldPy = py
        ' ------------------------------------------------ draw new marker         
        g.DrawLine(p, px, py + d2, px + Diam, py + d2)
        g.DrawLine(p, px + d2, py, px + d2, py + Diam)
        pbox.Invalidate(New Rectangle(CInt(px), CInt(py), CInt(Diam), CInt(Diam)))
    End Sub

End Module
