﻿Imports System.Math

Module Module_Utils

    ' ==============================================================================================================
    '   COMBO FUNCTIONS
    ' ==============================================================================================================
    Friend Sub Combo_Init(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            .Items.Clear()
            .Items.Add(str)
            .SelectedIndex = 0
        End With
        EventsAreEnabled = old
    End Sub

    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub

    Friend Function Combo_GetValue(ByVal combo As ComboBox) As String
        If combo.SelectedIndex < 0 Then Return ""
        Return combo.Items(combo.SelectedIndex).ToString()
    End Function

    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByVal index As Int32)
        If combo.Items.Count < 1 Then Exit Sub
        If index < 0 Then index = 0
        If index > combo.Items.Count - 1 Then index = combo.Items.Count - 1
        combo.SelectedIndex = index
    End Sub


    ' ==================================================================================================
    '   Vector 3D
    ' ==================================================================================================
    Friend Structure Vec3
        Dim x As Double
        Dim y As Double
        Dim z As Double
        Function Dist(ByVal other As Vec3) As Double
            Dist = Sqrt((other.x - x) ^ 2 + (other.y - y) ^ 2 + (other.z - z) ^ 2)
        End Function
        Function Add(ByVal other As Vec3) As Vec3
            Add.x = x + other.x
            Add.y = y + other.y
            Add.z = z + other.z
        End Function
        Function Subtract(ByVal other As Vec3) As Vec3
            Subtract.x = x - other.x
            Subtract.y = y - other.y
            Subtract.z = z - other.z
        End Function
        Function Mul(ByVal factor As Double) As Vec3
            Mul.x = x * factor
            Mul.y = y * factor
            Mul.z = z * factor
        End Function
        Function Length() As Double
            Return Sqrt(x ^ 2 + y ^ 2 + z ^ 2)
        End Function
        Function OrthoZ() As Vec3
            OrthoZ.x = y
            OrthoZ.y = -x
            OrthoZ.z = z
        End Function
        Function Normalized() As Vec3
            Dim l As Double = Me.Length()
            If l > 0 Then
                Normalized = Me.Mul(1 / l)
            End If
        End Function

    End Structure


    '90 degree rotations in a right-handed coordinate system
    ' ( for left-handed coordinate system switch 'CW' with 'CCW' )
    ' ====================================================================
    '90 degrees CW about x-axis: (x, y, z) -> (x, -z, y)
    '90 degrees CCW about x-axis: (x, y, z) -> (x, z, -y)
    ' --------------------------------------------------------------------
    '90 degrees CW about y-axis: (x, y, z) -> (-z, y, x)
    '90 degrees CCW about y-axis: (x, y, z) -> (z, y, -x)
    ' --------------------------------------------------------------------
    '90 degrees CW about z-axis: (x, y, z) -> (y, -x, z)
    '90 degrees CCW about z-axis: (x, y, z) -> (-y, x, z)
    ' --------------------------------------------------------------------


    ' =================================================================================================
    '   TRIANGLE HELPERS
    ' =================================================================================================

    '    c = (0,0)
    '    |\
    ' AA | \ BB
    '    |  \
    '    |___\
    '   b  CC  a


    ' ----------------------------------------------------------------------------- 
    '  -- Right Triangle --
    ' -----------------------------------------------------------------------------
    '  Calc vertex "b" from vertexes "a" and "c" and distance "CC"
    ' -----------------------------------------------------------------------------

    Friend Sub CalcVertexB_FromVertsAandC(ByVal ax As Double, _
                                          ByVal ay As Double, _
                                          ByVal cx As Double, _
                                          ByVal cy As Double, _
                                          ByVal CC As Double, _
                                          ByRef bx As Double, _
                                          ByRef by As Double)

        Dim BB As Double = Sqrt((ax - cx) ^ 2 + (ay - cy) ^ 2)
        Dim AA As Double = Sqrt(BB ^ 2 - CC ^ 2)

        bx = (AA * AA * ax - CC * (AA * ay - CC * cx - AA * cy)) / (BB * BB)
        by = (AA * CC * ax + AA * AA * ay - AA * CC * cx + CC * CC * cy) / (BB * BB)
    End Sub


    ' ----------------------------------------------------------------------------- 
    '  -- Right Triangle -- 
    ' -----------------------------------------------------------------------------
    '  Calc vertex "b" from vertexes "a"  and distance "CC" ( with c at 0,0 )
    ' -----------------------------------------------------------------------------

    Friend Sub CalcVertexB_FromVertexA(ByVal ax As Double, _
                                       ByVal ay As Double, _
                                       ByVal CC As Double, _
                                       ByRef bx As Double, _
                                       ByRef by As Double)

        Dim BB2 As Double = ax ^ 2 + ay ^ 2
        Dim AA As Double = Sqrt(BB2 - CC ^ 2)

        bx = AA * (AA * ax - CC * ay) / BB2
        by = AA * (AA * ay + CC * ax) / BB2
    End Sub

End Module





