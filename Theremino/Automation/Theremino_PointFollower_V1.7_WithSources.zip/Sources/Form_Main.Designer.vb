﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Me.PBox_Camera = New System.Windows.Forms.PictureBox
        Me.Label_FramesPerSec = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_VideoInDevice = New System.Windows.Forms.GroupBox
        Me.chk_FlipY = New System.Windows.Forms.CheckBox
        Me.Label_Millisec = New System.Windows.Forms.Label
        Me.Label_Resolution = New System.Windows.Forms.Label
        Me.ComboBox_VideoInputDevice = New MyComboBox
        Me.chk_FlipX = New System.Windows.Forms.CheckBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_VideoinControls = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_FRA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ESP = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_DEU = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_JPN = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.Tool_VideoControls = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveCamera = New System.Windows.Forms.ToolStripButton
        Me.Tools_SaveTotal = New System.Windows.Forms.ToolStripButton
        Me.Timer_1Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_Input = New System.Windows.Forms.GroupBox
        Me.txt_Gain = New MyTextBox
        Me.txt_SlotX = New MyTextBox
        Me.txt_SlotY = New MyTextBox
        Me.txt_DeltaX = New MyTextBox
        Me.Label_Gain = New System.Windows.Forms.Label
        Me.Label_SlotX = New System.Windows.Forms.Label
        Me.Label_DeltaX = New System.Windows.Forms.Label
        Me.Label_SlotY = New System.Windows.Forms.Label
        Me.txt_JpegQuality = New MyTextBox
        Me.Label_JpegQuality = New System.Windows.Forms.Label
        Me.Label_Path = New System.Windows.Forms.Label
        Me.ComboBox_FileType = New MyComboBox
        Me.Label_Name = New System.Windows.Forms.Label
        Me.txt_FilePath = New MyTextBox
        Me.LabelDot = New System.Windows.Forms.Label
        Me.GroupBox_SaveImage = New System.Windows.Forms.GroupBox
        Me.txt_FileName = New MyTextBox
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel
        Me.GroupBox_FollowerParams = New System.Windows.Forms.GroupBox
        Me.Label_MinValue = New System.Windows.Forms.Label
        Me.txt_MinValue = New MyTextBox
        Me.txt_DeltaY = New MyTextBox
        Me.Label_DeltaY = New System.Windows.Forms.Label
        CType(Me.PBox_Camera, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_VideoInDevice.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox_Input.SuspendLayout()
        Me.GroupBox_SaveImage.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox_FollowerParams.SuspendLayout()
        Me.SuspendLayout()
        '
        'PBox_Camera
        '
        Me.PBox_Camera.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PBox_Camera.BackColor = System.Drawing.Color.DimGray
        Me.PBox_Camera.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PBox_Camera.ErrorImage = Nothing
        Me.PBox_Camera.InitialImage = Nothing
        Me.PBox_Camera.Location = New System.Drawing.Point(6, 12)
        Me.PBox_Camera.Name = "PBox_Camera"
        Me.PBox_Camera.Size = New System.Drawing.Size(298, 272)
        Me.PBox_Camera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PBox_Camera.TabIndex = 0
        Me.PBox_Camera.TabStop = False
        '
        'Label_FramesPerSec
        '
        Me.Label_FramesPerSec.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_FramesPerSec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_FramesPerSec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FramesPerSec.Location = New System.Drawing.Point(85, 54)
        Me.Label_FramesPerSec.Name = "Label_FramesPerSec"
        Me.Label_FramesPerSec.Size = New System.Drawing.Size(44, 16)
        Me.Label_FramesPerSec.TabIndex = 65
        Me.Label_FramesPerSec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'GroupBox_VideoInDevice
        '
        Me.GroupBox_VideoInDevice.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_VideoInDevice.Controls.Add(Me.chk_FlipY)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_Millisec)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_Resolution)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.ComboBox_VideoInputDevice)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_FramesPerSec)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.chk_FlipX)
        Me.GroupBox_VideoInDevice.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_VideoInDevice.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_VideoInDevice.Location = New System.Drawing.Point(6, 52)
        Me.GroupBox_VideoInDevice.Name = "GroupBox_VideoInDevice"
        Me.GroupBox_VideoInDevice.Size = New System.Drawing.Size(297, 80)
        Me.GroupBox_VideoInDevice.TabIndex = 70
        Me.GroupBox_VideoInDevice.TabStop = False
        Me.GroupBox_VideoInDevice.Text = "Video Input Device"
        '
        'chk_FlipY
        '
        Me.chk_FlipY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_FlipY.Location = New System.Drawing.Point(245, 54)
        Me.chk_FlipY.Name = "chk_FlipY"
        Me.chk_FlipY.Size = New System.Drawing.Size(48, 19)
        Me.chk_FlipY.TabIndex = 93
        Me.chk_FlipY.Text = "FlipY"
        Me.chk_FlipY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_FlipY.UseVisualStyleBackColor = True
        '
        'Label_Millisec
        '
        Me.Label_Millisec.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_Millisec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Millisec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Millisec.Location = New System.Drawing.Point(131, 54)
        Me.Label_Millisec.Name = "Label_Millisec"
        Me.Label_Millisec.Size = New System.Drawing.Size(54, 16)
        Me.Label_Millisec.TabIndex = 69
        Me.Label_Millisec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Resolution
        '
        Me.Label_Resolution.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_Resolution.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Resolution.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Resolution.Location = New System.Drawing.Point(12, 54)
        Me.Label_Resolution.Name = "Label_Resolution"
        Me.Label_Resolution.Size = New System.Drawing.Size(70, 16)
        Me.Label_Resolution.TabIndex = 66
        Me.Label_Resolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_VideoInputDevice
        '
        Me.ComboBox_VideoInputDevice.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoInputDevice.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BackColor = System.Drawing.Color.FloralWhite
        Me.ComboBox_VideoInputDevice.BackColor_Focused = System.Drawing.Color.FloralWhite
        Me.ComboBox_VideoInputDevice.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BorderSize = 1
        Me.ComboBox_VideoInputDevice.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoInputDevice.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDownHeight = 318
        Me.ComboBox_VideoInputDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoInputDevice.DropDownWidth = 280
        Me.ComboBox_VideoInputDevice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoInputDevice.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoInputDevice.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoInputDevice.IntegralHeight = False
        Me.ComboBox_VideoInputDevice.Items.AddRange(New Object() {"Auto"})
        Me.ComboBox_VideoInputDevice.Location = New System.Drawing.Point(12, 23)
        Me.ComboBox_VideoInputDevice.Name = "ComboBox_VideoInputDevice"
        Me.ComboBox_VideoInputDevice.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoInputDevice.Size = New System.Drawing.Size(278, 22)
        Me.ComboBox_VideoInputDevice.TabIndex = 32
        Me.ComboBox_VideoInputDevice.TextPosition = 4
        '
        'chk_FlipX
        '
        Me.chk_FlipX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_FlipX.Location = New System.Drawing.Point(193, 54)
        Me.chk_FlipX.Name = "chk_FlipX"
        Me.chk_FlipX.Size = New System.Drawing.Size(48, 19)
        Me.chk_FlipX.TabIndex = 92
        Me.chk_FlipX.Text = "FlipX"
        Me.chk_FlipX.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_FlipX.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tools, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(624, 24)
        Me.MenuStrip1.TabIndex = 72
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator3, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(89, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tools
        '
        Me.Menu_Tools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Tools_VideoinControls})
        Me.Menu_Tools.Name = "Menu_Tools"
        Me.Menu_Tools.Size = New System.Drawing.Size(48, 20)
        Me.Menu_Tools.Text = "Tools"
        '
        'Menu_Tools_VideoinControls
        '
        Me.Menu_Tools_VideoinControls.Image = CType(resources.GetObject("Menu_Tools_VideoinControls.Image"), System.Drawing.Image)
        Me.Menu_Tools_VideoinControls.Name = "Menu_Tools_VideoinControls"
        Me.Menu_Tools_VideoinControls.Size = New System.Drawing.Size(167, 22)
        Me.Menu_Tools_VideoinControls.Text = "Video-in Controls"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_ENG, Me.Menu_Language_ITA, Me.Menu_Language_FRA, Me.Menu_Language_ESP, Me.Menu_Language_DEU, Me.Menu_Language_JPN})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_ENG
        '
        Me.Menu_Language_ENG.Image = CType(resources.GetObject("Menu_Language_ENG.Image"), System.Drawing.Image)
        Me.Menu_Language_ENG.Name = "Menu_Language_ENG"
        Me.Menu_Language_ENG.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ENG.Text = "English"
        '
        'Menu_Language_ITA
        '
        Me.Menu_Language_ITA.Image = CType(resources.GetObject("Menu_Language_ITA.Image"), System.Drawing.Image)
        Me.Menu_Language_ITA.Name = "Menu_Language_ITA"
        Me.Menu_Language_ITA.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ITA.Text = "Italiano"
        '
        'Menu_Language_FRA
        '
        Me.Menu_Language_FRA.Image = CType(resources.GetObject("Menu_Language_FRA.Image"), System.Drawing.Image)
        Me.Menu_Language_FRA.Name = "Menu_Language_FRA"
        Me.Menu_Language_FRA.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_FRA.Text = "Francais"
        '
        'Menu_Language_ESP
        '
        Me.Menu_Language_ESP.Image = CType(resources.GetObject("Menu_Language_ESP.Image"), System.Drawing.Image)
        Me.Menu_Language_ESP.Name = "Menu_Language_ESP"
        Me.Menu_Language_ESP.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_ESP.Text = "Espanol"
        '
        'Menu_Language_DEU
        '
        Me.Menu_Language_DEU.Image = CType(resources.GetObject("Menu_Language_DEU.Image"), System.Drawing.Image)
        Me.Menu_Language_DEU.Name = "Menu_Language_DEU"
        Me.Menu_Language_DEU.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_DEU.Text = "Deutsch"
        '
        'Menu_Language_JPN
        '
        Me.Menu_Language_JPN.Image = CType(resources.GetObject("Menu_Language_JPN.Image"), System.Drawing.Image)
        Me.Menu_Language_JPN.Name = "Menu_Language_JPN"
        Me.Menu_Language_JPN.Size = New System.Drawing.Size(121, 22)
        Me.Menu_Language_JPN.Text = "Japanese"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.ToolStripSeparator4, Me.Menu_Help_OpenProgramFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program help"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(183, 6)
        '
        'Menu_Help_OpenProgramFolder
        '
        Me.Menu_Help_OpenProgramFolder.Image = CType(resources.GetObject("Menu_Help_OpenProgramFolder.Image"), System.Drawing.Image)
        Me.Menu_Help_OpenProgramFolder.Name = "Menu_Help_OpenProgramFolder"
        Me.Menu_Help_OpenProgramFolder.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_OpenProgramFolder.Text = "Open program folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tool_VideoControls, Me.ToolStripSeparator2, Me.ToolStripSeparator1, Me.Tools_SaveCamera, Me.Tools_SaveTotal})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(624, 25)
        Me.ToolStrip1.TabIndex = 73
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tool_VideoControls
        '
        Me.Tool_VideoControls.Image = CType(resources.GetObject("Tool_VideoControls.Image"), System.Drawing.Image)
        Me.Tool_VideoControls.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_VideoControls.Name = "Tool_VideoControls"
        Me.Tool_VideoControls.Size = New System.Drawing.Size(103, 22)
        Me.Tool_VideoControls.Text = "Video controls"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveCamera
        '
        Me.Tools_SaveCamera.Image = CType(resources.GetObject("Tools_SaveCamera.Image"), System.Drawing.Image)
        Me.Tools_SaveCamera.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveCamera.Name = "Tools_SaveCamera"
        Me.Tools_SaveCamera.Size = New System.Drawing.Size(104, 22)
        Me.Tools_SaveCamera.Text = "Camera image"
        '
        'Tools_SaveTotal
        '
        Me.Tools_SaveTotal.Image = CType(resources.GetObject("Tools_SaveTotal.Image"), System.Drawing.Image)
        Me.Tools_SaveTotal.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveTotal.Name = "Tools_SaveTotal"
        Me.Tools_SaveTotal.Size = New System.Drawing.Size(90, 22)
        Me.Tools_SaveTotal.Text = "Total image"
        '
        'Timer_1Hz
        '
        '
        'GroupBox_Input
        '
        Me.GroupBox_Input.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Input.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_Input.Controls.Add(Me.PBox_Camera)
        Me.GroupBox_Input.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Input.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_Input.Location = New System.Drawing.Point(309, 52)
        Me.GroupBox_Input.Name = "GroupBox_Input"
        Me.GroupBox_Input.Size = New System.Drawing.Size(309, 289)
        Me.GroupBox_Input.TabIndex = 92
        Me.GroupBox_Input.TabStop = False
        '
        'txt_Gain
        '
        Me.txt_Gain.ArrowsIncrement = 0.1
        Me.txt_Gain.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_Gain.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Gain.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Gain.Decimals = 1
        Me.txt_Gain.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Gain.Increment = 0.02
        Me.txt_Gain.Location = New System.Drawing.Point(73, 25)
        Me.txt_Gain.MaxValue = 100
        Me.txt_Gain.MinValue = -100
        Me.txt_Gain.Multiline = True
        Me.txt_Gain.Name = "txt_Gain"
        Me.txt_Gain.NumericValue = 1
        Me.txt_Gain.NumericValueInteger = 1
        Me.txt_Gain.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Gain.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Gain.RoundingStep = 0
        Me.txt_Gain.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Gain.Size = New System.Drawing.Size(36, 16)
        Me.txt_Gain.SuppressZeros = True
        Me.txt_Gain.TabIndex = 100
        Me.txt_Gain.Text = "1"
        Me.txt_Gain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotX
        '
        Me.txt_SlotX.ArrowsIncrement = 1
        Me.txt_SlotX.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SlotX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotX.Increment = 1
        Me.txt_SlotX.Location = New System.Drawing.Point(250, 25)
        Me.txt_SlotX.MaxValue = 999
        Me.txt_SlotX.MinValue = 0
        Me.txt_SlotX.Multiline = True
        Me.txt_SlotX.Name = "txt_SlotX"
        Me.txt_SlotX.NumericValue = 1
        Me.txt_SlotX.NumericValueInteger = 1
        Me.txt_SlotX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotX.RoundingStep = 0
        Me.txt_SlotX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotX.Size = New System.Drawing.Size(36, 16)
        Me.txt_SlotX.TabIndex = 98
        Me.txt_SlotX.Text = "1"
        Me.txt_SlotX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotY
        '
        Me.txt_SlotY.ArrowsIncrement = 1
        Me.txt_SlotY.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SlotY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotY.Increment = 1
        Me.txt_SlotY.Location = New System.Drawing.Point(249, 45)
        Me.txt_SlotY.MaxValue = 999
        Me.txt_SlotY.MinValue = 0
        Me.txt_SlotY.Multiline = True
        Me.txt_SlotY.Name = "txt_SlotY"
        Me.txt_SlotY.NumericValue = 2
        Me.txt_SlotY.NumericValueInteger = 2
        Me.txt_SlotY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotY.RoundingStep = 0
        Me.txt_SlotY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotY.Size = New System.Drawing.Size(36, 16)
        Me.txt_SlotY.TabIndex = 94
        Me.txt_SlotY.Text = "2"
        Me.txt_SlotY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaX
        '
        Me.txt_DeltaX.ArrowsIncrement = 1
        Me.txt_DeltaX.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_DeltaX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaX.Increment = 0.2
        Me.txt_DeltaX.Location = New System.Drawing.Point(165, 25)
        Me.txt_DeltaX.MaxValue = 500
        Me.txt_DeltaX.MinValue = -500
        Me.txt_DeltaX.Multiline = True
        Me.txt_DeltaX.Name = "txt_DeltaX"
        Me.txt_DeltaX.NumericValue = 0
        Me.txt_DeltaX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaX.RoundingStep = 0
        Me.txt_DeltaX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaX.Size = New System.Drawing.Size(36, 16)
        Me.txt_DeltaX.TabIndex = 96
        Me.txt_DeltaX.Text = "0"
        Me.txt_DeltaX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_Gain
        '
        Me.Label_Gain.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Gain.Location = New System.Drawing.Point(9, 27)
        Me.Label_Gain.Name = "Label_Gain"
        Me.Label_Gain.Size = New System.Drawing.Size(61, 13)
        Me.Label_Gain.TabIndex = 101
        Me.Label_Gain.Text = "Gain"
        Me.Label_Gain.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_SlotX
        '
        Me.Label_SlotX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SlotX.Location = New System.Drawing.Point(208, 27)
        Me.Label_SlotX.Name = "Label_SlotX"
        Me.Label_SlotX.Size = New System.Drawing.Size(41, 13)
        Me.Label_SlotX.TabIndex = 99
        Me.Label_SlotX.Text = "Slot X"
        Me.Label_SlotX.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_DeltaX
        '
        Me.Label_DeltaX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DeltaX.Location = New System.Drawing.Point(117, 27)
        Me.Label_DeltaX.Name = "Label_DeltaX"
        Me.Label_DeltaX.Size = New System.Drawing.Size(47, 13)
        Me.Label_DeltaX.TabIndex = 97
        Me.Label_DeltaX.Text = "Delta X"
        Me.Label_DeltaX.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_SlotY
        '
        Me.Label_SlotY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SlotY.Location = New System.Drawing.Point(205, 47)
        Me.Label_SlotY.Name = "Label_SlotY"
        Me.Label_SlotY.Size = New System.Drawing.Size(44, 13)
        Me.Label_SlotY.TabIndex = 95
        Me.Label_SlotY.Text = "Slot Y"
        Me.Label_SlotY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_JpegQuality
        '
        Me.txt_JpegQuality.ArrowsIncrement = 1
        Me.txt_JpegQuality.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_JpegQuality.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_JpegQuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_JpegQuality.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_JpegQuality.Increment = 0.2
        Me.txt_JpegQuality.Location = New System.Drawing.Point(245, 19)
        Me.txt_JpegQuality.MaxValue = 100
        Me.txt_JpegQuality.MinValue = 1
        Me.txt_JpegQuality.Multiline = True
        Me.txt_JpegQuality.Name = "txt_JpegQuality"
        Me.txt_JpegQuality.NumericValue = 100
        Me.txt_JpegQuality.NumericValueInteger = 100
        Me.txt_JpegQuality.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_JpegQuality.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_JpegQuality.RoundingStep = 0
        Me.txt_JpegQuality.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_JpegQuality.Size = New System.Drawing.Size(41, 19)
        Me.txt_JpegQuality.SuppressZeros = True
        Me.txt_JpegQuality.TabIndex = 102
        Me.txt_JpegQuality.Text = "100"
        Me.txt_JpegQuality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_JpegQuality
        '
        Me.Label_JpegQuality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_JpegQuality.ForeColor = System.Drawing.Color.Black
        Me.Label_JpegQuality.Location = New System.Drawing.Point(154, 21)
        Me.Label_JpegQuality.Name = "Label_JpegQuality"
        Me.Label_JpegQuality.Size = New System.Drawing.Size(93, 13)
        Me.Label_JpegQuality.TabIndex = 101
        Me.Label_JpegQuality.Text = "JPEG quality"
        Me.Label_JpegQuality.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_Path
        '
        Me.Label_Path.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Path.ForeColor = System.Drawing.Color.Black
        Me.Label_Path.Location = New System.Drawing.Point(16, 69)
        Me.Label_Path.Name = "Label_Path"
        Me.Label_Path.Size = New System.Drawing.Size(65, 13)
        Me.Label_Path.TabIndex = 100
        Me.Label_Path.Text = "Path"
        '
        'ComboBox_FileType
        '
        Me.ComboBox_FileType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_FileType.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_FileType.BackColor = System.Drawing.Color.FloralWhite
        Me.ComboBox_FileType.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.ComboBox_FileType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.BorderColor = System.Drawing.Color.PowderBlue
        Me.ComboBox_FileType.BorderSize = 1
        Me.ComboBox_FileType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_FileType.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDownHeight = 318
        Me.ComboBox_FileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FileType.DropDownWidth = 80
        Me.ComboBox_FileType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_FileType.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_FileType.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_FileType.IntegralHeight = False
        Me.ComboBox_FileType.Location = New System.Drawing.Point(215, 41)
        Me.ComboBox_FileType.Name = "ComboBox_FileType"
        Me.ComboBox_FileType.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_FileType.Size = New System.Drawing.Size(73, 21)
        Me.ComboBox_FileType.TabIndex = 95
        Me.ComboBox_FileType.TextPosition = 4
        '
        'Label_Name
        '
        Me.Label_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Name.ForeColor = System.Drawing.Color.Black
        Me.Label_Name.Location = New System.Drawing.Point(16, 28)
        Me.Label_Name.Name = "Label_Name"
        Me.Label_Name.Size = New System.Drawing.Size(65, 13)
        Me.Label_Name.TabIndex = 98
        Me.Label_Name.Text = "Name"
        '
        'txt_FilePath
        '
        Me.txt_FilePath.ArrowsIncrement = 0
        Me.txt_FilePath.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_FilePath.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FilePath.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FilePath.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FilePath.Increment = 0
        Me.txt_FilePath.Location = New System.Drawing.Point(12, 84)
        Me.txt_FilePath.MaxValue = 0
        Me.txt_FilePath.MinValue = 0
        Me.txt_FilePath.Multiline = True
        Me.txt_FilePath.Name = "txt_FilePath"
        Me.txt_FilePath.NumericValue = 0
        Me.txt_FilePath.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FilePath.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Solid
        Me.txt_FilePath.RoundingStep = 0
        Me.txt_FilePath.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FilePath.Size = New System.Drawing.Size(277, 28)
        Me.txt_FilePath.TabIndex = 97
        Me.txt_FilePath.Text = "   "
        Me.txt_FilePath.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabelDot
        '
        Me.LabelDot.AutoSize = True
        Me.LabelDot.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDot.Location = New System.Drawing.Point(198, 45)
        Me.LabelDot.Name = "LabelDot"
        Me.LabelDot.Size = New System.Drawing.Size(13, 16)
        Me.LabelDot.TabIndex = 96
        Me.LabelDot.Text = "."
        '
        'GroupBox_SaveImage
        '
        Me.GroupBox_SaveImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_JpegQuality)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_JpegQuality)
        Me.GroupBox_SaveImage.Controls.Add(Me.LabelDot)
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_FilePath)
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_FileName)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_Name)
        Me.GroupBox_SaveImage.Controls.Add(Me.ComboBox_FileType)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_Path)
        Me.GroupBox_SaveImage.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_SaveImage.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_SaveImage.Location = New System.Drawing.Point(6, 138)
        Me.GroupBox_SaveImage.Name = "GroupBox_SaveImage"
        Me.GroupBox_SaveImage.Size = New System.Drawing.Size(297, 124)
        Me.GroupBox_SaveImage.TabIndex = 95
        Me.GroupBox_SaveImage.TabStop = False
        Me.GroupBox_SaveImage.Text = "Save image"
        '
        'txt_FileName
        '
        Me.txt_FileName.ArrowsIncrement = 0
        Me.txt_FileName.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_FileName.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FileName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FileName.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FileName.Increment = 0
        Me.txt_FileName.Location = New System.Drawing.Point(12, 44)
        Me.txt_FileName.MaxValue = -1
        Me.txt_FileName.MinValue = -1
        Me.txt_FileName.Multiline = True
        Me.txt_FileName.Name = "txt_FileName"
        Me.txt_FileName.NumericValue = -1
        Me.txt_FileName.NumericValueInteger = -1
        Me.txt_FileName.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FileName.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FileName.RoundingStep = 0
        Me.txt_FileName.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FileName.Size = New System.Drawing.Size(184, 16)
        Me.txt_FileName.SuppressZeros = True
        Me.txt_FileName.TabIndex = 99
        Me.txt_FileName.Text = "0"
        Me.txt_FileName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_FileName.WordWrap = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.LightYellow
        Me.StatusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1, Me.StatusLabel2, Me.StatusLabel3, Me.StatusLabel4, Me.StatusLabel5, Me.StatusLabel6})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 345)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip1.Size = New System.Drawing.Size(624, 22)
        Me.StatusStrip1.TabIndex = 97
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(100, 17)
        '
        'StatusLabel2
        '
        Me.StatusLabel2.AutoSize = False
        Me.StatusLabel2.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel2.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel2.Name = "StatusLabel2"
        Me.StatusLabel2.Size = New System.Drawing.Size(100, 17)
        '
        'StatusLabel3
        '
        Me.StatusLabel3.AutoSize = False
        Me.StatusLabel3.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel3.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel3.Name = "StatusLabel3"
        Me.StatusLabel3.Size = New System.Drawing.Size(100, 17)
        '
        'StatusLabel4
        '
        Me.StatusLabel4.AutoSize = False
        Me.StatusLabel4.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel4.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel4.Name = "StatusLabel4"
        Me.StatusLabel4.Size = New System.Drawing.Size(100, 17)
        '
        'StatusLabel5
        '
        Me.StatusLabel5.AutoSize = False
        Me.StatusLabel5.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel5.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel5.Name = "StatusLabel5"
        Me.StatusLabel5.Size = New System.Drawing.Size(100, 17)
        '
        'StatusLabel6
        '
        Me.StatusLabel6.AutoSize = False
        Me.StatusLabel6.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.StatusLabel6.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.StatusLabel6.Name = "StatusLabel6"
        Me.StatusLabel6.Size = New System.Drawing.Size(100, 17)
        '
        'GroupBox_FollowerParams
        '
        Me.GroupBox_FollowerParams.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_MinValue)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_MinValue)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_DeltaY)
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_DeltaY)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_DeltaX)
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_Gain)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_SlotY)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_Gain)
        Me.GroupBox_FollowerParams.Controls.Add(Me.txt_SlotX)
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_DeltaX)
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_SlotX)
        Me.GroupBox_FollowerParams.Controls.Add(Me.Label_SlotY)
        Me.GroupBox_FollowerParams.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_FollowerParams.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_FollowerParams.Location = New System.Drawing.Point(6, 268)
        Me.GroupBox_FollowerParams.Name = "GroupBox_FollowerParams"
        Me.GroupBox_FollowerParams.Size = New System.Drawing.Size(297, 73)
        Me.GroupBox_FollowerParams.TabIndex = 102
        Me.GroupBox_FollowerParams.TabStop = False
        Me.GroupBox_FollowerParams.Text = "Follower params"
        '
        'Label_MinValue
        '
        Me.Label_MinValue.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MinValue.Location = New System.Drawing.Point(9, 47)
        Me.Label_MinValue.Name = "Label_MinValue"
        Me.Label_MinValue.Size = New System.Drawing.Size(61, 13)
        Me.Label_MinValue.TabIndex = 105
        Me.Label_MinValue.Text = "Min value"
        Me.Label_MinValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_MinValue
        '
        Me.txt_MinValue.ArrowsIncrement = 1
        Me.txt_MinValue.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_MinValue.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinValue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinValue.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinValue.Increment = 0.2
        Me.txt_MinValue.Location = New System.Drawing.Point(73, 45)
        Me.txt_MinValue.MaxLength = 4
        Me.txt_MinValue.MaxValue = 250
        Me.txt_MinValue.MinValue = 0
        Me.txt_MinValue.Multiline = True
        Me.txt_MinValue.Name = "txt_MinValue"
        Me.txt_MinValue.NumericValue = 100
        Me.txt_MinValue.NumericValueInteger = 100
        Me.txt_MinValue.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinValue.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinValue.RoundingStep = 0
        Me.txt_MinValue.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinValue.Size = New System.Drawing.Size(36, 16)
        Me.txt_MinValue.SuppressZeros = True
        Me.txt_MinValue.TabIndex = 104
        Me.txt_MinValue.Text = "100"
        Me.txt_MinValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DeltaY
        '
        Me.txt_DeltaY.ArrowsIncrement = 1
        Me.txt_DeltaY.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_DeltaY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeltaY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeltaY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeltaY.Increment = 0.2
        Me.txt_DeltaY.Location = New System.Drawing.Point(165, 45)
        Me.txt_DeltaY.MaxValue = 500
        Me.txt_DeltaY.MinValue = -500
        Me.txt_DeltaY.Multiline = True
        Me.txt_DeltaY.Name = "txt_DeltaY"
        Me.txt_DeltaY.NumericValue = 0
        Me.txt_DeltaY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeltaY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeltaY.RoundingStep = 0
        Me.txt_DeltaY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeltaY.Size = New System.Drawing.Size(36, 16)
        Me.txt_DeltaY.TabIndex = 102
        Me.txt_DeltaY.Text = "0"
        Me.txt_DeltaY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_DeltaY
        '
        Me.Label_DeltaY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DeltaY.Location = New System.Drawing.Point(117, 47)
        Me.Label_DeltaY.Name = "Label_DeltaY"
        Me.Label_DeltaY.Size = New System.Drawing.Size(47, 13)
        Me.Label_DeltaY.TabIndex = 103
        Me.Label_DeltaY.Text = "Delta Y"
        Me.Label_DeltaY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(624, 367)
        Me.Controls.Add(Me.GroupBox_FollowerParams)
        Me.Controls.Add(Me.GroupBox_SaveImage)
        Me.Controls.Add(Me.GroupBox_Input)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox_VideoInDevice)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(1200, 800)
        Me.MinimumSize = New System.Drawing.Size(640, 405)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino PointFollower"
        CType(Me.PBox_Camera, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_VideoInDevice.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox_Input.ResumeLayout(False)
        Me.GroupBox_SaveImage.ResumeLayout(False)
        Me.GroupBox_SaveImage.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox_FollowerParams.ResumeLayout(False)
        Me.GroupBox_FollowerParams.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PBox_Camera As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label_FramesPerSec As System.Windows.Forms.Label
    Friend WithEvents ComboBox_VideoInputDevice As MyComboBox
    Friend WithEvents GroupBox_VideoInDevice As System.Windows.Forms.GroupBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer_1Hz As System.Windows.Forms.Timer
    Friend WithEvents Label_Resolution As System.Windows.Forms.Label
    Friend WithEvents Menu_Tools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_VideoinControls As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tool_VideoControls As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox_Input As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_FileType As MyComboBox
    Friend WithEvents LabelDot As System.Windows.Forms.Label
    Friend WithEvents chk_FlipX As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Path As System.Windows.Forms.Label
    Friend WithEvents Label_Name As System.Windows.Forms.Label
    Friend WithEvents txt_FilePath As MyTextBox
    Friend WithEvents txt_JpegQuality As MyTextBox
    Friend WithEvents Label_JpegQuality As System.Windows.Forms.Label
    Friend WithEvents GroupBox_SaveImage As System.Windows.Forms.GroupBox
    Friend WithEvents Label_SlotX As System.Windows.Forms.Label
    Friend WithEvents txt_SlotX As MyTextBox
    Friend WithEvents Label_DeltaX As System.Windows.Forms.Label
    Friend WithEvents txt_DeltaX As MyTextBox
    Friend WithEvents Label_SlotY As System.Windows.Forms.Label
    Friend WithEvents txt_SlotY As MyTextBox
    Friend WithEvents Label_Gain As System.Windows.Forms.Label
    Friend WithEvents txt_Gain As MyTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents Label_Millisec As System.Windows.Forms.Label
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_FRA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ESP As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_DEU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_JPN As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txt_FileName As MyTextBox
    Friend WithEvents Tools_SaveCamera As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tools_SaveTotal As System.Windows.Forms.ToolStripButton
    Friend WithEvents chk_FlipY As System.Windows.Forms.CheckBox
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents GroupBox_FollowerParams As System.Windows.Forms.GroupBox
    Friend WithEvents StatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel6 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txt_DeltaY As MyTextBox
    Friend WithEvents Label_DeltaY As System.Windows.Forms.Label
    Friend WithEvents Label_MinValue As System.Windows.Forms.Label
    Friend WithEvents txt_MinValue As MyTextBox

End Class
