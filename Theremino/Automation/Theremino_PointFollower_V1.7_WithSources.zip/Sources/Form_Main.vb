﻿
Public Class Form_Main

    Private Sub Form_Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' ----------------------------------------------------------------
        Me.Text = AppTitleAndVersion()
        ' ---------------------------------------------------------------- 
        Load_INI()
        ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        ComboBox_FileFormat_InitWithCurrentFileFormat()
        SetLocales()
        UpdateUserInterface()
        ' ---------------------------------------------------------------- CAPTURE
        Capture_INIT(VideoInDevice)
        If VideoCaptureDevice_Is_VFW() Then
            Capture_ConnectFiltersAndRun()
        Else
            Capture_SetVideoFormatParams()
        End If
        ' ---------------------------------------------------------------- DOCK
        If Form_VideoInControls_VisibleAtStart Then
            Form_VideoInControls.Show(Me)
        Else
            Form_VideoInControls.Show(Me)
            Form_VideoInControls.Visible = False
        End If
        DockAllWindows()
        ' ----------------------------------------------------------------
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------------------- Main Timer
        Timer1.Interval = 1
        Timer1.Start()
        ' ---------------------------------------------------------------- Timer 1Hz
        Timer_1Hz.Interval = 1000
        Timer_1Hz.Start()
        ' ----------------------------------------------------------------
        SetDefaultFocus()
        EventsAreEnabled = True
        ' ---------------------------------------------------------------- SHOW
        Refresh()
        Forms_FadeTo(1, 400)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Return
        CloseProgram()
    End Sub

    Private Sub CloseProgram()
        Save_INI()
        EventsAreEnabled = False
        Forms_FadeTo(0, 500)
        Me.Refresh()
        Timer1.Stop()
        Capture_STOP()
        Form_VideoInControls.Close()
        Me.Close()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub Form_Main_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        DockAllWindows()
    End Sub

    Private Sub Form_Main_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        DockAllWindows()
    End Sub

    Private Sub SetDefaultFocus()
        PBox_Camera.Focus()
    End Sub

    Friend Sub PictureBox1_Clear()
        PBox_Camera.Image = PBox_Camera.InitialImage
    End Sub

    Friend Sub DockAllWindows()
        Form_VideoInControls.SetSnap()
    End Sub

    Private Sub OpenCloseFormVideoInControls()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.Visible = False
        Else
            Form_VideoInControls.Visible = True
            Me.Focus()
        End If
        DockAllWindows()
    End Sub

    Private Sub UpdateUserInterface()
        ' ready for language string not laready updated
        Refresh()
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        CloseProgram()
    End Sub

    ' =======================================================================================
    '   MENU TOOLS
    ' =======================================================================================
    Private Sub Menu_VideoinControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Tools_VideoinControls.Click
        OpenCloseFormVideoInControls()
    End Sub

    ' =======================================================================================
    '   MENU LANGUAGE
    ' =======================================================================================
    Private Sub Menu_Language_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language.DropDownOpening
        For Each item As ToolStripMenuItem In Menu_Language.DropDownItems
            If item.Name.EndsWith(Language, StringComparison.InvariantCultureIgnoreCase) Then
                item.Select()
            End If
        Next
    End Sub
    Private Sub Menu_Language_DEU_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_DEU.Click
        Language = "DEU"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ENG_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ENG.Click
        Language = "ENG"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ESP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ESP.Click
        Language = "ESP"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_FRA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_FRA.Click
        Language = "FRA"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_ITA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_ITA.Click
        Language = "ITA"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub
    Private Sub Menu_Language_JPN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Language_JPN.Click
        Language = "JPN"
        SetLocales()
        Save_INI()
        UpdateUserInterface()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Help.DropDownOpening
        SetLocales()
    End Sub
    Private Sub Menu_Help_ProgramHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        OpenLocalizedHelp("Theremino_PointFollower_Help", ".pdf")
    End Sub
    Private Sub Menu_Help_OpenProgramFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_OpenProgramFolder.Click
        Process.Start(Application.StartupPath)
    End Sub
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")
        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & Language & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog(Me)
    End Sub

    ' =======================================================================================
    '   TOOLSTRIP
    ' =======================================================================================
    Private Sub Tools_SaveCamera_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_SaveCamera.Click
        Tools_SaveCamera.Visible = False
        Tools_SaveCamera.Visible = True
        Me.Refresh()
        SaveImage(PBox_Camera)
    End Sub
    Private Sub Tools_SaveTotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tools_SaveTotal.Click
        Tools_SaveTotal.Visible = False
        Tools_SaveTotal.Visible = True
        Me.Refresh()
        SaveImage(Me)
    End Sub
    Private Sub Tool_VideoInControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_VideoControls.Click
        OpenCloseFormVideoInControls()
    End Sub
    Private Sub ToolStrip1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStrip1.MouseEnter
        Me.Focus() ' with this the toolstrip responds always at the first click
    End Sub

    ' ==============================================================================================================
    '   COMBO BOX - FILE
    ' ==============================================================================================================
    Private Sub ComboBox_FileFormat_InitWithCurrentFileFormat()
        Combo_Init(ComboBox_FileType, FileFormat)
    End Sub
    Private Sub ComboBox_FileFormat_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.DropDownClosed
        SetDefaultFocus()
    End Sub
    Private Sub ComboBox_FileFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        FileFormat = Combo_GetValue(ComboBox_FileType)
        SetDefaultFocus()
        Save_INI()
    End Sub
    Private Sub ComboBox_FileFormat_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_FileType.DropDown
        With ComboBox_FileType
            .Items.Clear()
            .Items.Add("JPG")
            .Items.Add("PNG")
            .Items.Add("TIFF")
            .Items.Add("EXIF")
            .Items.Add("EMF")
            .Items.Add("WMF")
            .Items.Add("GIF")
            .Items.Add("BMP")
            Combo_SetIndex_FromString(ComboBox_FileType, FileFormat)
        End With
    End Sub

    ' ==============================================================================================================
    '   COMBO BOX - VIDEO INPUT
    ' ==============================================================================================================
    Private Sub ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        Combo_Init(ComboBox_VideoInputDevice, VideoInDevice)
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDownClosed
        SetDefaultFocus()
    End Sub
    Private Sub ComboBox_VideoInputDevice_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        VideoInDevice = Combo_GetValue(ComboBox_VideoInputDevice)
        Timer1.Stop()
        Application.DoEvents()
        Capture_STOP()
        Application.DoEvents()
        Capture_INIT(VideoInDevice)
        Capture_ConnectFiltersAndRun()
        Timer1.Start()
        SetDefaultFocus()
        Save_INI()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.UpdateAllValues()
            Form_VideoInControls.Focus()
        End If
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDown
        Dim fnames() As String
        fnames = EnumFiltersByCategory(FilterCategory.VideoInputDevice)
        With ComboBox_VideoInputDevice
            .Items.Clear()
            For Each fltName As String In fnames
                .Items.Add(fltName)
            Next
            Combo_SetIndex_FromString(ComboBox_VideoInputDevice, VideoInDevice)
        End With
    End Sub

    ' ==============================================================================================================
    '   BUTTONS AND COMMANDS
    ' ==============================================================================================================
    Private Sub txt_FilePath_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_FilePath.MouseDoubleClick
        SelectSaveFolder()
    End Sub
    Public Sub SelectSaveFolder()
        Dim FBD As System.Windows.Forms.FolderBrowserDialog
        FBD = New System.Windows.Forms.FolderBrowserDialog()
        With FBD
            ' Use RootFolder to limit user choose area ( No RootFolder No limits )
            '.RootFolder = Environment.SpecialFolder.MyComputer
            ' --------------------------------------------------------------------------
            .SelectedPath = txt_FilePath.Text
            .Description = vbCr & "Select the ""File Save Path"""
            If .ShowDialog = DialogResult.OK Then
                txt_FilePath.Text = .SelectedPath
            End If
        End With
    End Sub

   
    ' ==============================================================================================================
    '   PARAMS
    ' ==============================================================================================================
    Private Sub Params_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_FlipX.LostFocus, _
                                                                                                     chk_FlipY.LostFocus, _
                                                                                                     txt_Gain.LostFocus, _
                                                                                                     txt_MinValue.LostFocus, _
                                                                                                     txt_DeltaX.LostFocus, _
                                                                                                     txt_DeltaY.LostFocus, _
                                                                                                     txt_SlotX.LostFocus, _
                                                                                                     txt_SlotY.LostFocus, _
                                                                                                     txt_FileName.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub Params_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_FlipX.CheckedChanged, _
                                                                                                   chk_FlipY.CheckedChanged, _
                                                                                                   txt_Gain.TextChanged, _
                                                                                                   txt_MinValue.TextChanged, _
                                                                                                   txt_DeltaX.TextChanged, _
                                                                                                   txt_DeltaY.TextChanged, _
                                                                                                   txt_SlotX.TextChanged, _
                                                                                                   txt_SlotY.TextChanged
        If Not EventsAreEnabled Then Return
        PointFollower_SetParams()
    End Sub


    ' ==============================================================================================================
    '   TIMER 1 Hz
    ' ==============================================================================================================
    Private Sub Timer_1Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_1Hz.Tick
        If Not EventsAreEnabled Then Return
        EnableDisableControls()
    End Sub
    Private Sub EnableDisableControls()
        If FileFormat = "JPG" Then
            Label_JpegQuality.Enabled = True
            txt_JpegQuality.Enabled = True
        Else
            Label_JpegQuality.Enabled = False
            txt_JpegQuality.Enabled = False
        End If
    End Sub

    ' ==============================================================================================================
    '   CAPTURE TIMER
    ' ==============================================================================================================
    Private Timer1_Working As Boolean = False
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        If Capture_Image Is Nothing OrElse Capture_Image.PixelFormat = Imaging.PixelFormat.Undefined Then
            Capture_NewImageIsReady = False
            Return
        End If
        If Timer1_Working Then Exit Sub
        Timer1_Working = True
        ProcessCapturedImage()
        Timer1_Working = False
    End Sub

End Class
