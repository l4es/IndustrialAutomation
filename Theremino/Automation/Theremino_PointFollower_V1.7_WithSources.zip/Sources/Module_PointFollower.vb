
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices

Module PointFollower

    Private ci As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture
    Private StopWatch1 As Stopwatch = New Stopwatch

    Private FlipX As Boolean
    Private FlipY As Boolean

    Private SrcImage As Image
    Private SrcBmp As Bitmap
    Private SrcW As Int32
    Private SrcH As Int32
    Private SrcPen As Pen

    Private Gain As Single
    Private MinValue As Int32
    Private DeltaX As Int32
    Private DeltaY As Int32
    Private SlotX As Int32
    Private SlotY As Int32

    Private Kred As Single = 0.299F
    Private Kgreen As Single = 0.587F
    Private Kblue As Single = 0.114F

    Friend Sub PointFollower_SetParams()
        If SrcImage Is Nothing Then Return
        ' ---------------------------------------------------------------------
        FlipX = Form_Main.chk_FlipX.Checked
        FlipY = Form_Main.chk_FlipY.Checked
        ' ---------------------------------------------------------------------
        SrcW = SrcImage.Width
        SrcH = SrcImage.Height
        SrcPen = New Pen(Color.FromArgb(200, 120, 0), SrcH \ 100)
        ' ---------------------------------------------------------------------
        Gain = CSng(Form_Main.txt_Gain.NumericValue)
        MinValue = Form_Main.txt_MinValue.NumericValueInteger
        DeltaX = Form_Main.txt_DeltaX.NumericValueInteger
        DeltaY = Form_Main.txt_DeltaY.NumericValueInteger
        SlotX = Form_Main.txt_SlotX.NumericValueInteger
        SlotY = Form_Main.txt_SlotY.NumericValueInteger
    End Sub


    ' ================================================================================
    '  PROCESS CAPTURED IMAGE
    ' ================================================================================
    Friend Sub ProcessCapturedImage()
        ' -----------------------------------------------------------------------
        If Not Capture_NewImageIsReady Then Return
        ' ----------------------------------------------------------------------- START TIMER
        StopWatch1.Reset()
        StopWatch1.Start()
        ' ----------------------------------------------------------------------- LOAD CAPTURED IMAGE
        SrcImage = Capture_Image
        If SrcImage Is Nothing Then Return
        ' ----------------------------------------------------------------------- CAPTURE IMAGE NOT READY
        Capture_NewImageIsReady = False
        ' ----------------------------------------------------------------------- FLIP X and Y
        If Not FlipY Then
            If FlipX Then
                SrcImage.RotateFlip(RotateFlipType.RotateNoneFlipXY)
            Else
                SrcImage.RotateFlip(RotateFlipType.RotateNoneFlipY)
            End If
        Else
            If FlipX Then
                SrcImage.RotateFlip(RotateFlipType.RotateNoneFlipX)
            Else

            End If
        End If
        ' ----------------------------------------------------------------------- PREPARE BITMAP
        SrcBmp = CType(SrcImage, Bitmap)
        ' ----------------------------------------------------------------------- SET PARAMS
        If SrcImage.Width <> SrcW Or SrcImage.Height <> SrcH Then
            PointFollower_SetParams()
        End If
        ' ----------------------------------------------------------------------- PROCESS BITMAP DATA
        ProcessBitmap()
        ' ----------------------------------------------------------------------- SHOW SOURCE IMAGE
        Form_Main.PBox_Camera.Image = SrcImage
        ' ----------------------------------------------------------------------- SHOW IMAGE SIZE and TIME
        Form_Main.Label_Resolution.Text = Capture_Image.Width.ToString & _
                                          " x " & Capture_Image.Height.ToString
        Form_Main.Label_FramesPerSec.Text = Capture_FramesPerSecond.ToString("0") & " fps"
        ' -----------------------------------------------------------------------
        Form_Main.Label_Millisec.Text = (StopWatch1.ElapsedMilliseconds).ToString("0") & " mS"
    End Sub


    Private Sub ProcessBitmap()
        If SrcBmp Is Nothing Then Return
        ' --------------------------------------------------------------------- bitmap to byte array
        Dim SourceData As BitmapData
        SourceData = SrcBmp.LockBits(New Rectangle(0, 0, SrcW, SrcH), _
                                     ImageLockMode.ReadWrite, _
                                     PixelFormat.Format24bppRgb)
        Dim SourceStride As Int32 = SourceData.Stride
        Dim byteCount As Integer = (SourceData.Stride * SourceData.Height)
        Dim bmpBytes(byteCount - 1) As Byte
        Marshal.Copy(SourceData.Scan0, bmpBytes, 0, byteCount)
        SrcBmp.UnlockBits(SourceData)
        ' --------------------------------------------------------------------- Loop vars
        Dim r As Byte
        Dim g As Byte
        Dim b As Byte
        Dim gray As Single
        Dim CenterX As Single
        Dim CenterY As Single
        Dim disp As Int32
        ' --------------------------------------------------------------------- Weighted baricentric vars
        Dim SumValues As Single
        Dim WeigthSumX As Single
        Dim WeigthSumY As Single
        ' --------------------------------------------------------------------- Loop for each pixel 
        For y As Int32 = 0 To SrcH - 1
            disp = y * SourceStride
            For x As Int32 = 0 To SrcW - 1
                ' ------------------------------------------------------------- R/G/B extraction
                r = bmpBytes(disp + 2)
                g = bmpBytes(disp + 1)
                b = bmpBytes(disp)
                disp += 3
                ' ------------------------------------------------------------- Gray value
                gray = r * Kred + g * Kgreen + b * Kblue
                ' ------------------------------------------------------------- MinValue reduces noise and CPU work
                If gray > MinValue Then
                    ' --------------------------------------------------------- Weighted baricentric accumulation
                    SumValues += gray
                    WeigthSumX += x * gray
                    WeigthSumY += y * gray
                End If
            Next
        Next
        ' --------------------------------------------------------------------- Weighted baricentric division
        If SumValues > 0 Then
            CenterX = WeigthSumX / SumValues
            CenterY = WeigthSumY / SumValues
        Else
            CenterX = SrcW / 2.0F
            CenterY = SrcH / 2.0F
        End If
        ' --------------------------------------------------------------------- CenterX and CenterY to Slots
        Dim SlotX_Value As Single = CenterX - (SrcW / 2.0F)
        Dim SlotY_Value As Single = CenterY - (SrcH / 2.0F)
        SlotX_Value = Gain * SlotX_Value + 500 + DeltaX
        SlotY_Value = Gain * SlotY_Value + 500 + DeltaY
        Slots.WriteSlot(SlotX, SlotX_Value)
        Slots.WriteSlot(SlotY, SlotY_Value)
        ' --------------------------------------------------------------------- Draw circle on the source image  
        Dim SrcGraphics As Graphics = Graphics.FromImage(SrcBmp)
        Dim Radius As Single = SrcW / 20.0F
        Dim cx As Single = CenterX - Radius
        Dim cy As Single = CenterY - Radius
        SrcGraphics.DrawEllipse(SrcPen, cx, cy, 2 * Radius, 2 * Radius)
        ' --------------------------------------------------------------------- Status bar informations
        Form_Main.StatusLabel1.Text = "X = " & CenterX.ToString("0.0", ci)
        Form_Main.StatusLabel2.Text = "Y = " & CenterY.ToString("0.0", ci)
        Form_Main.StatusLabel3.Text = "SlotX = " & SlotX_Value.ToString("0.0", ci)
        Form_Main.StatusLabel4.Text = "SlotY = " & SlotY_Value.ToString("0.0", ci)
        Form_Main.StatusLabel5.Text = ""
        Form_Main.StatusLabel6.Text = ""
    End Sub

End Module
