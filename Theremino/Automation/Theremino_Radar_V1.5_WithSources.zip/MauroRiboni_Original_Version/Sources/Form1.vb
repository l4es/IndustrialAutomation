﻿
Public Class Form1

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '   Nelle proprietà del progetto ho messo "Option strict = ON" e "Option Infer = OFF"
    '   Questo impedisce di mischiare i tipi (Int, Single e Double) 
    '   e scrivere cose che funzionano male 
    '   e che poi sono difficilissime da trovare e aggiustare.
    '   Quindi ora per cambiare tipo si devono usare le funzioni:
    '   - Val( )    << da stringa a numero
    '   - Cint( )   << da Double o da Single verso Intero
    '   - Csng( )   << da Double a Single
    '   E per scivere numeri immediati di tipo Single si scrive una F 
    '    (che sta per FLOAT) dopo al numero, così: 123456F
    ' -------------------------------------------------------------------------------

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '   Tolti tutti i "Dim" e i "Friend" e sostituiti con "Private"
    '   "Private" significa "Accessibile solo da questo file"
    ' -------------------------------------------------------------------------------

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '   Sostituiti tutti gli "Integer" con "Int32"
    '   (se si usano PC a 32 o 64 bit gli Integer diventano a 32 o 64 bit
    '    invece scrivendo Int32 siamo sicuri di usare dei 32 Bit che sono
    '    sempre i più veloci)
    ' -------------------------------------------------------------------------------

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '   Sostituito il: Private pen As New Pen(Color.GreenYellow, 4)
    '   Con          : Private pen As Pen = New Pen(Color.GreenYellow, 4)
    '   Mai usare "As New" perchè se non si dichiara il tipo dell'oggetto
    '   allora l'oggetto diventa generico e quindi più lento.
    '   In questo caso diventerebbe un "Object" contenente una "Pen" 
    ' -------------------------------------------------------------------------------

    ' ============================================================================================
    '  Constants and Variables 
    ' ============================================================================================
    Private MaxDistMM As Int32 = 1000 ' <<< da mettere uguale al "Max dist" dell'UsoundSensor in HAL
    Private AngleMin As Single = 0     ' <<< modificare per non andare oltre il fondo corsa meccanico
    Private AngleMax As Single = 180   ' <<< modificare per non andare oltre il fondo corsa meccanico
    Private BorderUp As Int32 = 10
    Private BorderDown As Int32 = 5
    Private Angle As Single
    Private AngleUS As Single
    Private AnglePerCycle As Single
    Private Direction As Int32 = 1
    Private Const Krad As Single = Math.PI / 180
    Private GFX As Graphics

    ' ============================================================================================
    '  Colors
    ' ============================================================================================
    Private ColorBackground As Color = Color.FromArgb(0, 50, 0)
    Private PenRadarRayBackground As Pen = New Pen(ColorBackground, 3)
    Private PenRadarRay As Pen = New Pen(Color.FromArgb(155, 255, 100), 2)
    Private PenScale1 As Pen = New Pen(Color.FromArgb(60, 40, 100))
    Private PenScale2 As Pen = New Pen(Color.FromArgb(140, 120, 80))
    Private BrushScaleText As Brush = New SolidBrush(Color.FromArgb(240, 180, 50))
    Private BrushEchoPoints As Brush = New SolidBrush(Color.FromArgb(155, 255, 0))

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '  Gli eventi della interfaccia utente (Form.Load, Form.Resize, Button.Click) 
    '   normalmente si tengono tutti all'inizio e l'esecuzione alla fine
    ' -------------------------------------------------------------------------------
    ' ============================================================================================
    '   User interface events 
    ' ============================================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetSpeed()
        Timer2.Interval = 50
        Timer2.Enabled = True
    End Sub

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '  La grafica viene rifatta qui, nel "Form1.Resize", per poter ridimensionare il form
    '  La PictureBox1 ha la proprietà "Anchor = Top / Bootom / Left / Right"
    '   in modo da stare dietro al form se lo si ridimensiona
    '  Gli altri comandi hanno la proprietà "Anchor = Top / Right"
    '   in modo da stare attacati al bordo destro
    ' -------------------------------------------------------------------------------
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If PictureBox1.Width = 0 Or PictureBox1.Height = 0 Then Return
        PictureBox1.Image = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        GFX = Graphics.FromImage(PictureBox1.Image)
        ClearRadarArea()
    End Sub

    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '   Timer1.Start e Timer1.Stop non servono se si usano Timer1.Enabled/Disabled
    ' -------------------------------------------------------------------------------
    '   Al posto di usare una ulteriore variabile per sapere se è in movimento 
    '   si controlla direttamente "Timer1.Enabled"    
    ' -------------------------------------------------------------------------------
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Not Timer1.Enabled Then
            Timer1.Enabled = True
            Timer1.Interval = 10
            Button1.Text = "Stop"
        Else
            Timer1.Enabled = False
            MotorSleep()
            Button1.Text = "Start"
        End If
    End Sub

    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar1.Scroll
        SetSpeed()
    End Sub

    Private Sub SetSpeed()
        AnglePerCycle = TrackBar1.Value * 0.1F
    End Sub

    Private Sub MotorSleep()
        WriteSlot(1, NAN_Sleep)
    End Sub

    Private Sub ClearRadarArea()
        GFX.Clear(ColorBackground)
    End Sub


    ' --- CANCELLAMI DOPO AVER LETTO ------------------------------------------------
    '  Il Refresh e la Scala causerebbero molto lavoro alla CPU
    '  E le Label anche peggio! 
    '  I movimenti vanno fatti 100 volte al secondo (se possibile anche di più)
    '  Ma per le visualizzazioni basta una frequenza adeguata all'cchio umano
    '  (20 fotogrammi al secondo) per cui si usa un Timer2 regolato a 50 o 100 mS 
    ' -------------------------------------------------------------------------------
    ' ============================================================================================
    '   Radar scale divisions
    ' ============================================================================================
    Private Sub Timer2_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim w As Single = PictureBox1.Width
        Dim h As Single = PictureBox1.Height - BorderUp - BorderDown
        Dim x1 As Single = w / 2
        Dim y1 As Single = h + BorderUp
        Dim x2 As Single
        Dim y2 As Single
        Dim f As Font = New Font("Tahoma", 7)
        Dim strFormat As New StringFormat
        strFormat.Alignment = StringAlignment.Center
        ' --------------------------------------------------------- Scale circles
        Dim LargeDivisions As Int32
        Dim SmallDivisions As Int32
        If MaxDistMM <= 1000 Then
            LargeDivisions = 100
            SmallDivisions = 10
        Else
            LargeDivisions = 1000
            SmallDivisions = 100
        End If
        For d As Int32 = SmallDivisions To MaxDistMM Step SmallDivisions
            Dim d2 As Single = d * h / MaxDistMM
            If d Mod LargeDivisions = 0 Then
                GFX.DrawEllipse(PenScale2, x1 - d2, y1 - d2, d2 * 2, d2 * 2)
                GFX.DrawString(d.ToString, f, BrushScaleText, x1, y1 - d2 + 3, strFormat)
            Else
                GFX.DrawEllipse(PenScale1, x1 - d2, y1 - d2, d2 * 2, d2 * 2)
            End If
        Next
        ' --------------------------------------------------------- Scale lines
        For a As Single = 0 To 180 Step 10
            x2 = CSng(x1 - h * Math.Cos(a * Krad))
            y2 = CSng(y1 - h * Math.Sin(a * Krad))
            GFX.DrawLine(PenScale2, x1, y1, x2, y2)
            GFX.DrawString(a.ToString, f, BrushScaleText, x2, y2 - 10, strFormat)
        Next
        ' --------------------------------------------------------- Label update
        Label1.Text = Angle.ToString("0.0")
        ' --------------------------------------------------------- Refresh
        PictureBox1.Refresh()
    End Sub


    ' ============================================================================================
    '   Radar execution 
    ' ============================================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' --------------------------------------------------------- Vars
        Dim w As Single = PictureBox1.Width
        Dim h As Single = PictureBox1.Height - BorderUp - BorderDown
        Dim x1 As Single = w / 2
        Dim y1 As Single = h + BorderUp
        Dim x2 As Single
        Dim y2 As Single
        ' --------------------------------------------------------- Angle increment 
        Angle = Angle + Direction * AnglePerCycle
        If Angle > AngleMax Then
            Angle = AngleMax
            Direction = -1
        End If
        If Angle < AngleMin Then
            Angle = AngleMin
            Direction = 1
        End If
        ' --------------------------------------------------------- Angle to Motor
        WriteSlot(1, 1000 - 1000 * Angle / 180)
        ' --------------------------------------------------------- Remove old radar line
        Static OldX2 As Single = x1
        Static OldY2 As Single = y1
        GFX.DrawLine(PenRadarRayBackground, x1, y1, OldX2, OldY2)
        ' --------------------------------------------------------- Draw new radar line
        x2 = CSng(x1 - h * Math.Cos(Angle * Krad))
        y2 = CSng(y1 - h * Math.Sin(Angle * Krad))
        GFX.DrawLine(PenRadarRay, x1, y1, x2, y2)
        OldX2 = x2
        OldY2 = y2
        ' --------------------------------------------------------- Distance in mm
        Dim DistMM As Single
        DistMM = MaxDistMM * (1 - (ReadSlot_NoNan(2) / 1000))
        If DistMM < MaxDistMM Then
            ' --------------------------------------------------------- Distance in graphical units
            Dim DistGraph As Single
            DistGraph = DistMM * h / MaxDistMM
            ' --------------------------------------------------------- Draw "Echo" points
            x2 = CSng(x1 - DistGraph * Math.Cos(Angle * Krad))
            y2 = CSng(y1 - DistGraph * Math.Sin(Angle * Krad))
            GFX.FillEllipse(BrushEchoPoints, x2 - 3, y2 - 4, 7, 7)
        End If
    End Sub


End Class