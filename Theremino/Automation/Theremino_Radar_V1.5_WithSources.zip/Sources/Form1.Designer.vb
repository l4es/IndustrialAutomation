﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.TrackBar_Speed = New System.Windows.Forms.TrackBar
        Me.Label5 = New System.Windows.Forms.Label
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label
        Me.TrackBar_Angle = New System.Windows.Forms.TrackBar
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.CheckBox_AutoScan = New System.Windows.Forms.CheckBox
        Me.TrackBar_Scale = New System.Windows.Forms.TrackBar
        Me.Button_About = New System.Windows.Forms.Button
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label_ServoSlot = New System.Windows.Forms.Label
        Me.txt_ServoSlot = New MyTextBox
        Me.Label_UsoundSlot = New System.Windows.Forms.Label
        Me.txt_UsoundSlot = New MyTextBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Speed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Angle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.TrackBar_Scale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.DarkKhaki
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(6, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(580, 282)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(5, 223)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Angle"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Speed
        '
        Me.TrackBar_Speed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Speed.BackColor = System.Drawing.Color.Khaki
        Me.TrackBar_Speed.Location = New System.Drawing.Point(50, 104)
        Me.TrackBar_Speed.Minimum = 1
        Me.TrackBar_Speed.Name = "TrackBar_Speed"
        Me.TrackBar_Speed.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar_Speed.Size = New System.Drawing.Size(45, 123)
        Me.TrackBar_Speed.TabIndex = 6
        Me.TrackBar_Speed.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar_Speed.Value = 4
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(51, 223)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Speed"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer2
        '
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(51, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Scale"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Angle
        '
        Me.TrackBar_Angle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Angle.BackColor = System.Drawing.Color.Khaki
        Me.TrackBar_Angle.Location = New System.Drawing.Point(4, 3)
        Me.TrackBar_Angle.Maximum = 1800
        Me.TrackBar_Angle.Name = "TrackBar_Angle"
        Me.TrackBar_Angle.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar_Angle.Size = New System.Drawing.Size(45, 224)
        Me.TrackBar_Angle.TabIndex = 9
        Me.TrackBar_Angle.TickFrequency = 100
        Me.TrackBar_Angle.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar_Angle.Value = 4
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Khaki
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 294)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(704, 22)
        Me.StatusStrip1.TabIndex = 10
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(95, 17)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.AutoSize = False
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(105, 17)
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.AutoSize = False
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.DarkRed
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(300, 17)
        '
        'CheckBox_AutoScan
        '
        Me.CheckBox_AutoScan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CheckBox_AutoScan.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_AutoScan.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.CheckBox_AutoScan.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_AutoScan.Location = New System.Drawing.Point(5, 247)
        Me.CheckBox_AutoScan.Name = "CheckBox_AutoScan"
        Me.CheckBox_AutoScan.Size = New System.Drawing.Size(87, 22)
        Me.CheckBox_AutoScan.TabIndex = 11
        Me.CheckBox_AutoScan.Text = "Auto scan"
        Me.CheckBox_AutoScan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CheckBox_AutoScan.UseVisualStyleBackColor = True
        '
        'TrackBar_Scale
        '
        Me.TrackBar_Scale.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Scale.BackColor = System.Drawing.Color.Khaki
        Me.TrackBar_Scale.Location = New System.Drawing.Point(50, 3)
        Me.TrackBar_Scale.Maximum = 100
        Me.TrackBar_Scale.Minimum = 1
        Me.TrackBar_Scale.Name = "TrackBar_Scale"
        Me.TrackBar_Scale.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar_Scale.Size = New System.Drawing.Size(45, 89)
        Me.TrackBar_Scale.TabIndex = 12
        Me.TrackBar_Scale.TickFrequency = 10
        Me.TrackBar_Scale.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar_Scale.Value = 4
        '
        'Button_About
        '
        Me.Button_About.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button_About.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_About.Location = New System.Drawing.Point(9, 9)
        Me.Button_About.Name = "Button_About"
        Me.Button_About.Size = New System.Drawing.Size(42, 18)
        Me.Button_About.TabIndex = 13
        Me.Button_About.Text = "About"
        Me.Button_About.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button_About.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.DarkKhaki
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(592, 6)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(108, 282)
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Khaki
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.TrackBar_Angle)
        Me.Panel1.Controls.Add(Me.TrackBar_Speed)
        Me.Panel1.Controls.Add(Me.TrackBar_Scale)
        Me.Panel1.Controls.Add(Me.CheckBox_AutoScan)
        Me.Panel1.Location = New System.Drawing.Point(598, 11)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(96, 272)
        Me.Panel1.TabIndex = 15
        '
        'Label_ServoSlot
        '
        Me.Label_ServoSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_ServoSlot.BackColor = System.Drawing.Color.Khaki
        Me.Label_ServoSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ServoSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_ServoSlot.Location = New System.Drawing.Point(472, 299)
        Me.Label_ServoSlot.Name = "Label_ServoSlot"
        Me.Label_ServoSlot.Size = New System.Drawing.Size(66, 13)
        Me.Label_ServoSlot.TabIndex = 16
        Me.Label_ServoSlot.Text = "Servo Slot"
        Me.Label_ServoSlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_ServoSlot
        '
        Me.txt_ServoSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_ServoSlot.ArrowsIncrement = 1
        Me.txt_ServoSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_ServoSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ServoSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ServoSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ServoSlot.Increment = 0.2
        Me.txt_ServoSlot.Location = New System.Drawing.Point(537, 298)
        Me.txt_ServoSlot.MaxValue = 990
        Me.txt_ServoSlot.MinValue = 1
        Me.txt_ServoSlot.Multiline = True
        Me.txt_ServoSlot.Name = "txt_ServoSlot"
        Me.txt_ServoSlot.NumericValue = 931
        Me.txt_ServoSlot.NumericValueInteger = 931
        Me.txt_ServoSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ServoSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ServoSlot.RoundingStep = 0
        Me.txt_ServoSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ServoSlot.Size = New System.Drawing.Size(30, 15)
        Me.txt_ServoSlot.SuppressZeros = True
        Me.txt_ServoSlot.TabIndex = 17
        Me.txt_ServoSlot.Text = "931"
        Me.txt_ServoSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_UsoundSlot
        '
        Me.Label_UsoundSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_UsoundSlot.BackColor = System.Drawing.Color.Khaki
        Me.Label_UsoundSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_UsoundSlot.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Label_UsoundSlot.Location = New System.Drawing.Point(571, 298)
        Me.Label_UsoundSlot.Name = "Label_UsoundSlot"
        Me.Label_UsoundSlot.Size = New System.Drawing.Size(82, 13)
        Me.Label_UsoundSlot.TabIndex = 18
        Me.Label_UsoundSlot.Text = "Usound Slot"
        Me.Label_UsoundSlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_UsoundSlot
        '
        Me.txt_UsoundSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_UsoundSlot.ArrowsIncrement = 1
        Me.txt_UsoundSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_UsoundSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_UsoundSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_UsoundSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_UsoundSlot.Increment = 0.2
        Me.txt_UsoundSlot.Location = New System.Drawing.Point(652, 297)
        Me.txt_UsoundSlot.MaxValue = 990
        Me.txt_UsoundSlot.MinValue = 1
        Me.txt_UsoundSlot.Multiline = True
        Me.txt_UsoundSlot.Name = "txt_UsoundSlot"
        Me.txt_UsoundSlot.NumericValue = 932
        Me.txt_UsoundSlot.NumericValueInteger = 932
        Me.txt_UsoundSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_UsoundSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_UsoundSlot.RoundingStep = 0
        Me.txt_UsoundSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_UsoundSlot.Size = New System.Drawing.Size(30, 15)
        Me.txt_UsoundSlot.SuppressZeros = True
        Me.txt_UsoundSlot.TabIndex = 19
        Me.txt_UsoundSlot.Text = "932"
        Me.txt_UsoundSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(704, 316)
        Me.Controls.Add(Me.Label_UsoundSlot)
        Me.Controls.Add(Me.txt_UsoundSlot)
        Me.Controls.Add(Me.Label_ServoSlot)
        Me.Controls.Add(Me.txt_ServoSlot)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Button_About)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(720, 350)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Radar"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Speed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Angle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.TrackBar_Scale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Speed As System.Windows.Forms.TrackBar
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Angle As System.Windows.Forms.TrackBar
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CheckBox_AutoScan As System.Windows.Forms.CheckBox
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Button_About As System.Windows.Forms.Button
    Friend WithEvents TrackBar_Scale As System.Windows.Forms.TrackBar
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label_ServoSlot As System.Windows.Forms.Label
    Friend WithEvents txt_ServoSlot As MyTextBox
    Friend WithEvents Label_UsoundSlot As System.Windows.Forms.Label
    Friend WithEvents txt_UsoundSlot As MyTextBox

End Class
