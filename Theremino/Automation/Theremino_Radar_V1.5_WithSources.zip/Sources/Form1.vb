﻿
Public Class Form1

    ' ============================================================================================
    '  Constants and Variables 
    ' ============================================================================================
    Private ServoSlot As Int32 = 931
    Private DistanceSlot As Int32 = 932
    Private MaxDistance As Int32 = 1000
    Private AngleMin As Single = 0
    Private AngleMax As Single = 180
    Private BorderUp As Int32 = 10
    Private BorderDown As Int32 = 2
    Private Distance As Single
    Private DesiredAngle As Single
    Private Angle As Single
    Private AngleUS As Single
    Private AnglePerCycle As Single
    Private Direction As Int32 = 1
    Private Const Krad As Single = Math.PI / 180
    Private GFX As Graphics

    ' ============================================================================================
    '  Colors
    ' ============================================================================================
    Private ColorBackground As Color = Color.FromArgb(0, 50, 0)
    Private PenRadarRayBackground As Pen = New Pen(ColorBackground, 3)
    Private PenRadarRay As Pen = New Pen(Color.FromArgb(155, 255, 100), 2)
    Private PenScale1 As Pen = New Pen(Color.FromArgb(80, 80, 120))
    Private PenScale2 As Pen = New Pen(Color.FromArgb(140, 120, 80))
    Private BrushScaleText As Brush = New SolidBrush(Color.FromArgb(240, 180, 50))
    Private BrushEchoPoints As Brush = New SolidBrush(Color.FromArgb(155, 255, 0))

    ' ============================================================================================
    '   User interface events 
    ' ============================================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Text = AppTitleAndVersion("Theremino Radar")
        Load_INI()
        StartThereminoHAL()
        SetParams()
        PictureBox1.BackColor = ColorBackground
        Timer1.Interval = 10
        Timer1.Enabled = True
        Timer2.Interval = 50
        Timer2.Enabled = True
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If PictureBox1.ClientSize.Width < 1 Or PictureBox1.ClientSize.Height < 1 Then Return
        PictureBox1.Image = New Bitmap(PictureBox1.ClientSize.Width, PictureBox1.ClientSize.Height)
        GFX = Graphics.FromImage(PictureBox1.Image)
        Timer2_Tick(Nothing, Nothing)
        If PictureBox1.ClientSize.Width > 800 Or PictureBox1.ClientSize.Height > 400 Then
            ToolStripStatusLabel3.Text = "Warning: Large window = high CPU work."
        Else
            ToolStripStatusLabel3.Text = ""
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
        StopThereminoHAL()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    ' =========================================================================
    '   THEREMINO HAL - START STOP -
    ' =========================================================================
    Private HalProcess As Process = Nothing
    Private Sub StartThereminoHAL()
        Dim path As String = Application.StartupPath & "\Theremino_HAL.exe"
        If Not My.Computer.FileSystem.FileExists(path) Then
            path = Application.StartupPath & "\Theremino_HAL\Theremino_HAL.exe"
        End If
        If Not My.Computer.FileSystem.FileExists(path) Then Return
        Dim psi As New ProcessStartInfo
        psi.WorkingDirectory = IO.Path.GetDirectoryName(path)
        psi.FileName = path
        HalProcess = Process.Start(psi)
    End Sub
    Private Sub StopThereminoHAL()
        If HalProcess IsNot Nothing AndAlso Not HalProcess.HasExited Then
            Try
                HalProcess.CloseMainWindow()
            Finally
            End Try
        End If
    End Sub


    ' =========================================================================
    '   Commands
    ' =========================================================================
    Private Sub Button_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_About.Click
        Form_About.ShowDialog(Me)
    End Sub
    Private Sub TrackBar_Scale_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBar_Scale.ValueChanged
        SetParams()
        ClearRadarArea()
    End Sub
    Private Sub TrackBar_Angle_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBar_Angle.ValueChanged
        SetParams()
    End Sub
    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar_Speed.Scroll
        SetParams()
    End Sub
    Private Sub txt_ServoSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_ServoSlot.TextChanged
        SetParams()
    End Sub
    Private Sub txt_UsoundSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_UsoundSlot.TextChanged
        SetParams()
    End Sub

    Private Sub SetParams()
        DesiredAngle = TrackBar_Angle.Value / 10.0F
        AnglePerCycle = TrackBar_Speed.Value * 0.1F
        MaxDistance = TrackBar_Scale.Value * 100
        ServoSlot = txt_ServoSlot.NumericValueInteger
        DistanceSlot = txt_UsoundSlot.NumericValueInteger
    End Sub

    Private Sub MotorSleep()
        Slots.WriteSlot(ServoSlot, NAN_Sleep)
    End Sub

    Private Sub ClearRadarArea()
        If GFX Is Nothing Then Return
        GFX.Clear(ColorBackground)
    End Sub

    ' ============================================================================================
    '   Radar scale divisions
    ' ============================================================================================
    Private Sub Timer2_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim w As Single = PictureBox1.ClientSize.Width
        Dim h As Single = PictureBox1.ClientSize.Height - BorderUp - BorderDown
        Dim x1 As Single = w / 2
        Dim y1 As Single = h + BorderUp
        Dim x2 As Single
        Dim y2 As Single
        Dim f As Font = New Font("Tahoma", 7)
        Dim strFormat As New StringFormat
        strFormat.Alignment = StringAlignment.Center
        ' --------------------------------------------------------- Scale circles
        Dim LargeDivisions As Int32
        Dim SmallDivisions As Int32
        If MaxDistance <= 100 Then
            LargeDivisions = 10
            SmallDivisions = 1
        ElseIf MaxDistance <= 1000 Then
            LargeDivisions = 100
            SmallDivisions = 10
        Else
            LargeDivisions = 1000
            SmallDivisions = 100
        End If
        For d As Int32 = SmallDivisions To MaxDistance Step SmallDivisions
            Dim d2 As Single = d * h / MaxDistance
            If d Mod LargeDivisions = 0 Then
                GFX.DrawEllipse(PenScale2, x1 - d2, y1 - d2, d2 * 2, d2 * 2)
                GFX.DrawString(d.ToString, f, BrushScaleText, x1, y1 - d2 + 3, strFormat)
            Else
                GFX.DrawEllipse(PenScale1, x1 - d2, y1 - d2, d2 * 2, d2 * 2)
            End If
        Next
        ' --------------------------------------------------------- Scale lines
        For a As Single = 0 To 180 Step 10
            x2 = CSng(x1 - h * Math.Cos(a * Krad))
            y2 = CSng(y1 - h * Math.Sin(a * Krad))
            GFX.DrawLine(PenScale2, x1, y1, x2, y2)
            x2 = CSng(x1 - (h + 8) * Math.Cos(a * Krad))
            GFX.DrawString(a.ToString, f, BrushScaleText, x2, y2 - 10, strFormat)
        Next
        ' --------------------------------------------------------- Toolstrip update
        ToolStripStatusLabel1.Text = "Angle: " & Angle.ToString("0.0", Globalization.CultureInfo.InvariantCulture)
        ToolStripStatusLabel2.Text = "Distance: " & Distance.ToString("0")
        ' --------------------------------------------------------- Trackbar Update
        If CheckBox_AutoScan.Checked Then
            TrackBar_Angle.Value = CInt(Angle * 10)
        End If
        ' --------------------------------------------------------- Refresh
        PictureBox1.Refresh()
    End Sub


    ' ============================================================================================
    '   Radar execution 
    ' ============================================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        If GFX Is Nothing Then Return
        ' --------------------------------------------------------- Vars
        Dim w As Single = PictureBox1.ClientSize.Width
        Dim h As Single = PictureBox1.ClientSize.Height - BorderUp - BorderDown
        Dim x1 As Single = w / 2
        Dim y1 As Single = h + BorderUp
        Dim x2 As Single
        Dim y2 As Single
        Dim x3 As Single
        Dim y3 As Single
        Static OldX2 As Single = x1
        Static OldY2 As Single = y1
        ' --------------------------------------------------------- Angle increment 
        If CheckBox_AutoScan.Checked Then
            ' ----------------------------------------------------- Autoscan
            Angle = Angle + Direction * AnglePerCycle
        Else
            ' ----------------------------------------------------- Manual
            If DesiredAngle > Angle Then
                Angle = Angle + AnglePerCycle
            End If
            If DesiredAngle < Angle Then
                Angle = Angle - AnglePerCycle
            End If
        End If
        If Angle > AngleMax Then
            Angle = AngleMax
            Direction = -1
        End If
        If Angle < AngleMin Then
            Angle = AngleMin
            Direction = 1
        End If
        ' --------------------------------------------------------- Angle to Motor
        Slots.WriteSlot(ServoSlot, 1000 - 1000 * Angle / 180)
        ' --------------------------------------------------------- Remove the old radar line
        GFX.DrawLine(PenRadarRayBackground, x1, y1, OldX2, OldY2)
        ' --------------------------------------------------------- Draw the new radar line
        x2 = CSng(x1 - h * Math.Cos(Angle * Krad))
        y2 = CSng(y1 - h * Math.Sin(Angle * Krad))
        GFX.DrawLine(PenRadarRay, x1, y1, x2, y2)
        ' --------------------------------------------------------- Echo distance in mm
        Distance = MaxDistance * (1 - (Slots.ReadSlot_NoNan(DistanceSlot) / 1000))
        If Distance < MaxDistance Then
            ' ----------------------------------------------------- Distance in graphical units
            Dim DistGraph As Single
            DistGraph = Distance * h / MaxDistance
            ' ----------------------------------------------------- Calculate echo position on OLD line
            x3 = x1 - (x1 - OldX2) * DistGraph / h
            y3 = y1 - (y1 - OldY2) * DistGraph / h
            ' ----------------------------------------------------- Draw "Echo" points
            GFX.FillEllipse(BrushEchoPoints, x3 - 3, y3 - 3, 5, 5)
        End If
        ' --------------------------------------------------------- Update the old positions
        OldX2 = x2
        OldY2 = y2
    End Sub


End Class