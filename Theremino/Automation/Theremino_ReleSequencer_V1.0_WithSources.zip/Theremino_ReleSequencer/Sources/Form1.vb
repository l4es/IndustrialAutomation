﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Text = AppTitleAndVersion()
        Load_INI()
        SetParams()
        ReadSequenceFile()
        DecodeSequence()
        Refresh()
        Opacity = 1
        SchedulerMaxPrecision()
        ThreadStart()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        SchedulerDefaultPrecision()
        Save_INI()
        WriteSequenceFile()
        ThreadStop()
        SendEmptyDataString()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        WriteSequenceFile()
        DecodeSequence()
    End Sub

    Private Sub SetParams()
        SlotStore = CInt(Val(txt_SlotStore.Text))
        SlotData = CInt(Val(txt_SlotData.Text))
        SlotClock = CInt(Val(txt_SlotClock.Text))
        BitTimeMillisec = CInt(Val(txt_BitTime.Text))
        If BitTimeMillisec < 3 Then
            BitTimeMillisec = 3
        End If
    End Sub

    Private Sub textbox_Params_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SlotStore.TextChanged, _
                                                                                                               txt_SlotData.TextChanged, _
                                                                                                               txt_SlotClock.TextChanged, _
                                                                                                               txt_BitTime.TextChanged
        SetParams()
    End Sub


    ' =========================================================================
    '  WINDOWS SCHEDULER PRECISION
    ' ========================================================================= 
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Sub SchedulerMaxPrecision()
        If OperatingSystemIsWindows Then
            timeBeginPeriod(1)
        End If
    End Sub
    Private Sub SchedulerDefaultPrecision()
        If OperatingSystemIsWindows Then
            timeEndPeriod(1)
        End If
    End Sub

End Class
