﻿Module Module_Sequencer

    Friend SlotStore As Int32        ' Slot ENABLE			- Slot del filo STORE
    Friend SlotData As Int32         ' Slot DATA			- Slot del filo DATA
    Friend SlotClock As Int32        ' Slot CLOCK			- Slot del filo CLOCK
    Friend BitTimeMillisec As Int32  ' Time Each bit (ms)	- Tempo tra i bit (millisec)

    Private NumRele As Int32

    ' -------------------------------------------------------------------------
    '  DECODE SEQUENCE
    ' -------------------------------------------------------------------------
    Private Structure SequenceRow
        Dim DataString As String
        Dim TimeMillisec As Int32
    End Structure
    Private SequenceRows(-1) As SequenceRow

    Friend Sub DecodeSequence()
        Dim NumRows As Int32 = 0
        For Each row As String In Form1.TextBox1.Lines
            row = RemoveComments(row)
            row = ReplaceMultipleSpacesAndTrim(row)
            Dim fields() As String = row.Split(" "c)
            If fields.Length = 2 Then
                Dim n As Int32 = fields(0).Length
                If n > NumRele Then NumRele = n
                ReDim Preserve SequenceRows(NumRows)
                With SequenceRows(NumRows)
                    .DataString = fields(0)
                    .TimeMillisec = CInt(Val(fields(1)))
                    If .TimeMillisec < 1 Then .TimeMillisec = 1
                End With
                NumRows += 1
            End If
        Next
    End Sub

    ' -------------------------------------------------------------------------
    '  SEQUENCE EXECUTION THREAD
    ' -------------------------------------------------------------------------
    Dim ThreadStopFlag As Boolean
    Dim MyThread As System.Threading.Thread
    Friend Sub ThreadStart()
        MyThread = New System.Threading.Thread(AddressOf ThreadProc)
        ThreadStopFlag = False
        MyThread.Start()
    End Sub

    Friend Sub ThreadStop()
        ThreadStopFlag = True
        Do
            Threading.Thread.Sleep(10)
        Loop Until MyThread Is Nothing
    End Sub

    Private Sub ThreadProc()
        Do
            For Each row As SequenceRow In SequenceRows
                ' ----------------------------------------------- send data string
                SendDataString(row.DataString)
                If ThreadStopFlag Then Exit Do
                ' ----------------------------------------------- correct delay subtracting transmission time
                Dim ms As Int32 = row.TimeMillisec
                ms -= NumRele * BitTimeMillisec * 2
                If ms < 1 Then ms = 1
                ' ----------------------------------------------- wait
                Threading.Thread.Sleep(ms)
                If ThreadStopFlag Then Exit Do
            Next
        Loop Until ThreadStopFlag
        MyThread = Nothing
    End Sub

    ' -------------------------------------------------------------------------
    '  SEND SEQUENCE ROW
    ' -------------------------------------------------------------------------
    Sub SendEmptyDataString()
        Dim DataString As String = ""
        For i As Int32 = 0 To NumRele - 1
            DataString = DataString & "0"
        Next
        SendDataString(DataString)
    End Sub

    Sub SendDataString(ByVal DataString As String)
        Slots.WriteSlot(SlotStore, 0)
        For i As Int32 = DataString.Length - 1 To 0 Step -1
            If DataString(i) = "0" Then
                Slots.WriteSlot(SlotData, 0)
            Else
                Slots.WriteSlot(SlotData, 1000)
            End If
            Slots.WriteSlot(SlotClock, 0)
            Threading.Thread.Sleep(BitTimeMillisec)
            Slots.WriteSlot(SlotClock, 1000)
            Threading.Thread.Sleep(BitTimeMillisec)
        Next
        Slots.WriteSlot(SlotStore, 1000)
        Threading.Thread.Sleep(BitTimeMillisec)
        Slots.WriteSlot(SlotData, 0)
        Slots.WriteSlot(SlotClock, 0)
        Slots.WriteSlot(SlotStore, 0)
    End Sub

End Module
