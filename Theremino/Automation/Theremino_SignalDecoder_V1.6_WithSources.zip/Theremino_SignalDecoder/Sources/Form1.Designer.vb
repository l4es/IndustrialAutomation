﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker13 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems13 As cBlendItems = New cBlendItems
        Dim CBlendItems14 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker14 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker15 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems15 As cBlendItems = New cBlendItems
        Dim CBlendItems16 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker16 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker17 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems17 As cBlendItems = New cBlendItems
        Dim CBlendItems18 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker18 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker19 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems19 As cBlendItems = New cBlendItems
        Dim CBlendItems20 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker20 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker21 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems21 As cBlendItems = New cBlendItems
        Dim CBlendItems22 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker22 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker23 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems23 As cBlendItems = New cBlendItems
        Dim CBlendItems24 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker24 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker25 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems25 As cBlendItems = New cBlendItems
        Dim CBlendItems26 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker26 As DesignerRectTracker = New DesignerRectTracker
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pbox_Scope = New System.Windows.Forms.PictureBox
        Me.GroupBox_Scope = New System.Windows.Forms.GroupBox
        Me.cmb_AudioInDevices = New MyComboBox
        Me.btn_AudioInputs = New MyButton
        Me.cmb_SignalType = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.chk_Sig7 = New MyButton
        Me.chk_Sig6 = New MyButton
        Me.chk_Sig5 = New MyButton
        Me.chk_Sync = New MyButton
        Me.txt_Trim6 = New MyTextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txt_Trim5 = New MyTextBox
        Me.txt_Trim4 = New MyTextBox
        Me.txt_Trim3 = New MyTextBox
        Me.txt_Trim2 = New MyTextBox
        Me.txt_Trim1 = New MyTextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.chk_Sig4 = New MyButton
        Me.chk_Sig3 = New MyButton
        Me.chk_Sig2 = New MyButton
        Me.chk_Sig1 = New MyButton
        Me.tbar_ScopePosition = New System.Windows.Forms.TrackBar
        Me.chk_SignalInverted = New MyButton
        Me.tbar_ScopeTime = New System.Windows.Forms.TrackBar
        Me.tbar_ScopeVoltage = New System.Windows.Forms.TrackBar
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.toolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.toolStripButton_Run = New System.Windows.Forms.ToolStripButton
        Me.toolStripButton_SaveConfig = New System.Windows.Forms.ToolStripButton
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.toolStripButton_LoadConfig = New System.Windows.Forms.ToolStripButton
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.toolStripButton_Docs = New System.Windows.Forms.ToolStripButton
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.btn_CopyText = New MyButton
        Me.btn_ClearText = New MyButton
        Me.txt_FirstSlot = New MyTextBox
        Me.Label_FirstSlot = New System.Windows.Forms.Label
        Me.chk_MultipleSlots = New MyButton
        Me.Label_BitMask = New System.Windows.Forms.Label
        Me.txt_BitMask = New System.Windows.Forms.TextBox
        CType(Me.pbox_Scope, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Scope.SuspendLayout()
        CType(Me.tbar_ScopePosition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbar_ScopeTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbar_ScopeVoltage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.toolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'pbox_Scope
        '
        Me.pbox_Scope.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pbox_Scope.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_Scope.Location = New System.Drawing.Point(9, 19)
        Me.pbox_Scope.Name = "pbox_Scope"
        Me.pbox_Scope.Size = New System.Drawing.Size(597, 56)
        Me.pbox_Scope.TabIndex = 1
        Me.pbox_Scope.TabStop = False
        '
        'GroupBox_Scope
        '
        Me.GroupBox_Scope.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Scope.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox_Scope.Controls.Add(Me.cmb_AudioInDevices)
        Me.GroupBox_Scope.Controls.Add(Me.btn_AudioInputs)
        Me.GroupBox_Scope.Controls.Add(Me.cmb_SignalType)
        Me.GroupBox_Scope.Controls.Add(Me.Label8)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig7)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig6)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig5)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sync)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim6)
        Me.GroupBox_Scope.Controls.Add(Me.Label6)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim5)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim4)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim3)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim2)
        Me.GroupBox_Scope.Controls.Add(Me.txt_Trim1)
        Me.GroupBox_Scope.Controls.Add(Me.Label5)
        Me.GroupBox_Scope.Controls.Add(Me.Label4)
        Me.GroupBox_Scope.Controls.Add(Me.Label3)
        Me.GroupBox_Scope.Controls.Add(Me.Label2)
        Me.GroupBox_Scope.Controls.Add(Me.Label1)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig4)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig3)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig2)
        Me.GroupBox_Scope.Controls.Add(Me.chk_Sig1)
        Me.GroupBox_Scope.Controls.Add(Me.tbar_ScopePosition)
        Me.GroupBox_Scope.Controls.Add(Me.chk_SignalInverted)
        Me.GroupBox_Scope.Controls.Add(Me.tbar_ScopeTime)
        Me.GroupBox_Scope.Controls.Add(Me.tbar_ScopeVoltage)
        Me.GroupBox_Scope.Controls.Add(Me.pbox_Scope)
        Me.GroupBox_Scope.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Scope.Location = New System.Drawing.Point(4, 31)
        Me.GroupBox_Scope.Name = "GroupBox_Scope"
        Me.GroupBox_Scope.Size = New System.Drawing.Size(615, 163)
        Me.GroupBox_Scope.TabIndex = 2
        Me.GroupBox_Scope.TabStop = False
        Me.GroupBox_Scope.Text = "Input signal"
        '
        'cmb_AudioInDevices
        '
        Me.cmb_AudioInDevices.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_AudioInDevices.ArrowColor = System.Drawing.Color.DarkGray
        Me.cmb_AudioInDevices.BackColor = System.Drawing.Color.FloralWhite
        Me.cmb_AudioInDevices.BackColor_Focused = System.Drawing.Color.FloralWhite
        Me.cmb_AudioInDevices.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_AudioInDevices.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_AudioInDevices.BorderSize = 1
        Me.cmb_AudioInDevices.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_AudioInDevices.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.cmb_AudioInDevices.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.cmb_AudioInDevices.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.cmb_AudioInDevices.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmb_AudioInDevices.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.cmb_AudioInDevices.DropDownHeight = 500
        Me.cmb_AudioInDevices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_AudioInDevices.DropDownWidth = 180
        Me.cmb_AudioInDevices.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_AudioInDevices.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_AudioInDevices.ForeColor = System.Drawing.Color.Black
        Me.cmb_AudioInDevices.IntegralHeight = False
        Me.cmb_AudioInDevices.ItemHeight = 11
        Me.cmb_AudioInDevices.Items.AddRange(New Object() {"Auto"})
        Me.cmb_AudioInDevices.Location = New System.Drawing.Point(74, 0)
        Me.cmb_AudioInDevices.Name = "cmb_AudioInDevices"
        Me.cmb_AudioInDevices.ShadowColor = System.Drawing.Color.LightGray
        Me.cmb_AudioInDevices.Size = New System.Drawing.Size(141, 17)
        Me.cmb_AudioInDevices.TabIndex = 233
        Me.cmb_AudioInDevices.TextPosition = 1
        '
        'btn_AudioInputs
        '
        Me.btn_AudioInputs.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_AudioInputs.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AudioInputs.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.btn_AudioInputs.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.btn_AudioInputs.ColorFillBlendChecked = CBlendItems2
        Me.btn_AudioInputs.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_AudioInputs.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_AudioInputs.Corners.All = CType(6, Short)
        Me.btn_AudioInputs.Corners.LowerLeft = CType(6, Short)
        Me.btn_AudioInputs.Corners.LowerRight = CType(6, Short)
        Me.btn_AudioInputs.Corners.UpperLeft = CType(6, Short)
        Me.btn_AudioInputs.Corners.UpperRight = CType(6, Short)
        Me.btn_AudioInputs.DimFactorOver = 30
        Me.btn_AudioInputs.FillType = MyButton.eFillType.LinearVertical
        Me.btn_AudioInputs.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_AudioInputs.FocalPoints.CenterPtX = 1.0!
        Me.btn_AudioInputs.FocalPoints.CenterPtY = 1.0!
        Me.btn_AudioInputs.FocalPoints.FocusPtX = 0.0!
        Me.btn_AudioInputs.FocalPoints.FocusPtY = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_AudioInputs.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AudioInputs.FocusPtTracker = DesignerRectTracker2
        Me.btn_AudioInputs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AudioInputs.Image = Nothing
        Me.btn_AudioInputs.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.ImageIndex = 0
        Me.btn_AudioInputs.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_AudioInputs.Location = New System.Drawing.Point(221, 0)
        Me.btn_AudioInputs.Name = "btn_AudioInputs"
        Me.btn_AudioInputs.Shape = MyButton.eShape.Rectangle
        Me.btn_AudioInputs.SideImage = Nothing
        Me.btn_AudioInputs.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_AudioInputs.Size = New System.Drawing.Size(79, 18)
        Me.btn_AudioInputs.TabIndex = 232
        Me.btn_AudioInputs.Text = "Audio inputs"
        Me.btn_AudioInputs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AudioInputs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_AudioInputs.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_AudioInputs.TextShadow = System.Drawing.Color.Transparent
        '
        'cmb_SignalType
        '
        Me.cmb_SignalType.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmb_SignalType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_SignalType.FormattingEnabled = True
        Me.cmb_SignalType.Items.AddRange(New Object() {"Morse", "Encoded remote controls", "Meteo (not implemented)"})
        Me.cmb_SignalType.Location = New System.Drawing.Point(450, 112)
        Me.cmb_SignalType.Name = "cmb_SignalType"
        Me.cmb_SignalType.Size = New System.Drawing.Size(154, 21)
        Me.cmb_SignalType.TabIndex = 127
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(420, 116)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 128
        Me.Label8.Text = "Type"
        '
        'chk_Sig7
        '
        Me.chk_Sig7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig7.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig7.CenterPtTracker = DesignerRectTracker3
        Me.chk_Sig7.CheckButton = True
        Me.chk_Sig7.Checked = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig7.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig7.ColorFillBlendChecked = CBlendItems4
        Me.chk_Sig7.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig7.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig7.Corners.All = CType(6, Short)
        Me.chk_Sig7.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig7.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig7.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig7.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig7.DimFactorOver = 30
        Me.chk_Sig7.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig7.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig7.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig7.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig7.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig7.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig7.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig7.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig7.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig7.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig7.FocusPtTracker = DesignerRectTracker4
        Me.chk_Sig7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig7.Image = Nothing
        Me.chk_Sig7.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig7.ImageIndex = 0
        Me.chk_Sig7.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig7.Location = New System.Drawing.Point(370, 114)
        Me.chk_Sig7.Name = "chk_Sig7"
        Me.chk_Sig7.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig7.SideImage = Nothing
        Me.chk_Sig7.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig7.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig7.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig7.TabIndex = 126
        Me.chk_Sig7.Text = "Sig.7"
        Me.chk_Sig7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig7.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig7.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sig6
        '
        Me.chk_Sig6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig6.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig6.CenterPtTracker = DesignerRectTracker5
        Me.chk_Sig6.CheckButton = True
        Me.chk_Sig6.Checked = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig6.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig6.ColorFillBlendChecked = CBlendItems6
        Me.chk_Sig6.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig6.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig6.Corners.All = CType(6, Short)
        Me.chk_Sig6.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig6.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig6.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig6.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig6.DimFactorOver = 30
        Me.chk_Sig6.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig6.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig6.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig6.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig6.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig6.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig6.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig6.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig6.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig6.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig6.FocusPtTracker = DesignerRectTracker6
        Me.chk_Sig6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig6.Image = Nothing
        Me.chk_Sig6.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig6.ImageIndex = 0
        Me.chk_Sig6.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig6.Location = New System.Drawing.Point(325, 114)
        Me.chk_Sig6.Name = "chk_Sig6"
        Me.chk_Sig6.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig6.SideImage = Nothing
        Me.chk_Sig6.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig6.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig6.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig6.TabIndex = 125
        Me.chk_Sig6.Text = "Sig.6"
        Me.chk_Sig6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig6.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig6.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sig5
        '
        Me.chk_Sig5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig5.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig5.CenterPtTracker = DesignerRectTracker7
        Me.chk_Sig5.CheckButton = True
        Me.chk_Sig5.Checked = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig5.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig5.ColorFillBlendChecked = CBlendItems8
        Me.chk_Sig5.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig5.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig5.Corners.All = CType(6, Short)
        Me.chk_Sig5.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig5.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig5.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig5.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig5.DimFactorOver = 30
        Me.chk_Sig5.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig5.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig5.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig5.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig5.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig5.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig5.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig5.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig5.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig5.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig5.FocusPtTracker = DesignerRectTracker8
        Me.chk_Sig5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig5.Image = Nothing
        Me.chk_Sig5.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig5.ImageIndex = 0
        Me.chk_Sig5.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig5.Location = New System.Drawing.Point(280, 114)
        Me.chk_Sig5.Name = "chk_Sig5"
        Me.chk_Sig5.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig5.SideImage = Nothing
        Me.chk_Sig5.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig5.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig5.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig5.TabIndex = 124
        Me.chk_Sig5.Text = "Sig.5"
        Me.chk_Sig5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig5.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig5.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sync
        '
        Me.chk_Sync.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sync.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sync.CenterPtTracker = DesignerRectTracker9
        Me.chk_Sync.CheckButton = True
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sync.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sync.ColorFillBlendChecked = CBlendItems10
        Me.chk_Sync.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sync.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sync.Corners.All = CType(6, Short)
        Me.chk_Sync.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sync.Corners.LowerRight = CType(6, Short)
        Me.chk_Sync.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sync.Corners.UpperRight = CType(6, Short)
        Me.chk_Sync.DimFactorOver = 30
        Me.chk_Sync.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sync.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sync.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sync.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sync.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sync.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sync.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sync.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sync.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sync.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sync.FocusPtTracker = DesignerRectTracker10
        Me.chk_Sync.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sync.Image = Nothing
        Me.chk_Sync.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sync.ImageIndex = 0
        Me.chk_Sync.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sync.Location = New System.Drawing.Point(56, 114)
        Me.chk_Sync.Name = "chk_Sync"
        Me.chk_Sync.Shape = MyButton.eShape.Rectangle
        Me.chk_Sync.SideImage = Nothing
        Me.chk_Sync.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sync.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sync.Size = New System.Drawing.Size(40, 18)
        Me.chk_Sync.TabIndex = 123
        Me.chk_Sync.Text = "Sync"
        Me.chk_Sync.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sync.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sync.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sync.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_Trim6
        '
        Me.txt_Trim6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim6.ArrowsIncrement = 1
        Me.txt_Trim6.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim6.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim6.DimFactorGray = -10
        Me.txt_Trim6.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim6.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim6.Increment = 0.2
        Me.txt_Trim6.Location = New System.Drawing.Point(561, 141)
        Me.txt_Trim6.MaxValue = 999
        Me.txt_Trim6.MinValue = 1
        Me.txt_Trim6.Name = "txt_Trim6"
        Me.txt_Trim6.NumericValue = 18
        Me.txt_Trim6.NumericValueInteger = 18
        Me.txt_Trim6.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim6.RoundingStep = 0
        Me.txt_Trim6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim6.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim6.SuppressZeros = True
        Me.txt_Trim6.TabIndex = 121
        Me.txt_Trim6.TabStop = False
        Me.txt_Trim6.Text = "18"
        Me.txt_Trim6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(498, 141)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 16)
        Me.Label6.TabIndex = 122
        Me.Label6.Text = "N.bit"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txt_Trim5
        '
        Me.txt_Trim5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim5.ArrowsIncrement = 1
        Me.txt_Trim5.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim5.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim5.DimFactorGray = -10
        Me.txt_Trim5.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim5.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim5.Increment = 0.2
        Me.txt_Trim5.Location = New System.Drawing.Point(467, 141)
        Me.txt_Trim5.MaxValue = 999
        Me.txt_Trim5.MinValue = 1
        Me.txt_Trim5.Name = "txt_Trim5"
        Me.txt_Trim5.NumericValue = 30
        Me.txt_Trim5.NumericValueInteger = 30
        Me.txt_Trim5.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim5.RoundingStep = 0
        Me.txt_Trim5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim5.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim5.SuppressZeros = True
        Me.txt_Trim5.TabIndex = 115
        Me.txt_Trim5.TabStop = False
        Me.txt_Trim5.Text = "30"
        Me.txt_Trim5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Trim4
        '
        Me.txt_Trim4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim4.ArrowsIncrement = 1
        Me.txt_Trim4.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim4.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim4.DimFactorGray = -10
        Me.txt_Trim4.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim4.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim4.Increment = 0.2
        Me.txt_Trim4.Location = New System.Drawing.Point(372, 141)
        Me.txt_Trim4.MaxValue = 999
        Me.txt_Trim4.MinValue = 1
        Me.txt_Trim4.Name = "txt_Trim4"
        Me.txt_Trim4.NumericValue = 30
        Me.txt_Trim4.NumericValueInteger = 30
        Me.txt_Trim4.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim4.RoundingStep = 0
        Me.txt_Trim4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim4.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim4.SuppressZeros = True
        Me.txt_Trim4.TabIndex = 114
        Me.txt_Trim4.TabStop = False
        Me.txt_Trim4.Text = "30"
        Me.txt_Trim4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Trim3
        '
        Me.txt_Trim3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim3.ArrowsIncrement = 1
        Me.txt_Trim3.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim3.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim3.DimFactorGray = -10
        Me.txt_Trim3.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim3.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim3.Increment = 0.2
        Me.txt_Trim3.Location = New System.Drawing.Point(278, 141)
        Me.txt_Trim3.MaxValue = 999
        Me.txt_Trim3.MinValue = 1
        Me.txt_Trim3.Name = "txt_Trim3"
        Me.txt_Trim3.NumericValue = 30
        Me.txt_Trim3.NumericValueInteger = 30
        Me.txt_Trim3.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim3.RoundingStep = 0
        Me.txt_Trim3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim3.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim3.SuppressZeros = True
        Me.txt_Trim3.TabIndex = 112
        Me.txt_Trim3.TabStop = False
        Me.txt_Trim3.Text = "30"
        Me.txt_Trim3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Trim2
        '
        Me.txt_Trim2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim2.ArrowsIncrement = 1
        Me.txt_Trim2.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim2.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim2.DimFactorGray = -10
        Me.txt_Trim2.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim2.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim2.Increment = 0.2
        Me.txt_Trim2.Location = New System.Drawing.Point(179, 141)
        Me.txt_Trim2.MaxValue = 999
        Me.txt_Trim2.MinValue = 1
        Me.txt_Trim2.Name = "txt_Trim2"
        Me.txt_Trim2.NumericValue = 30
        Me.txt_Trim2.NumericValueInteger = 30
        Me.txt_Trim2.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim2.RoundingStep = 0
        Me.txt_Trim2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim2.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim2.SuppressZeros = True
        Me.txt_Trim2.TabIndex = 111
        Me.txt_Trim2.TabStop = False
        Me.txt_Trim2.Text = "30"
        Me.txt_Trim2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Trim1
        '
        Me.txt_Trim1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_Trim1.ArrowsIncrement = 1
        Me.txt_Trim1.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_Trim1.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_Trim1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Trim1.DimFactorGray = -10
        Me.txt_Trim1.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Trim1.ForeColor = System.Drawing.Color.Black
        Me.txt_Trim1.Increment = 0.2
        Me.txt_Trim1.Location = New System.Drawing.Point(82, 141)
        Me.txt_Trim1.MaxValue = 999
        Me.txt_Trim1.MinValue = 1
        Me.txt_Trim1.Name = "txt_Trim1"
        Me.txt_Trim1.NumericValue = 30
        Me.txt_Trim1.NumericValueInteger = 30
        Me.txt_Trim1.RectangleColor = System.Drawing.Color.White
        Me.txt_Trim1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_Trim1.RoundingStep = 0
        Me.txt_Trim1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Trim1.Size = New System.Drawing.Size(36, 16)
        Me.txt_Trim1.SuppressZeros = True
        Me.txt_Trim1.TabIndex = 113
        Me.txt_Trim1.TabStop = False
        Me.txt_Trim1.Text = "30"
        Me.txt_Trim1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(403, 141)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 16)
        Me.Label5.TabIndex = 120
        Me.Label5.Text = "Count2"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(309, 141)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 16)
        Me.Label4.TabIndex = 119
        Me.Label4.Text = "Count1"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(215, 141)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 16)
        Me.Label3.TabIndex = 118
        Me.Label3.Text = "Trig."
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(116, 141)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 16)
        Me.Label2.TabIndex = 117
        Me.Label2.Text = "Filter"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(18, 141)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 16)
        Me.Label1.TabIndex = 116
        Me.Label1.Text = "Env."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'chk_Sig4
        '
        Me.chk_Sig4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig4.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig4.CenterPtTracker = DesignerRectTracker11
        Me.chk_Sig4.CheckButton = True
        Me.chk_Sig4.Checked = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig4.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig4.ColorFillBlendChecked = CBlendItems12
        Me.chk_Sig4.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig4.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig4.Corners.All = CType(6, Short)
        Me.chk_Sig4.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig4.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig4.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig4.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig4.DimFactorOver = 30
        Me.chk_Sig4.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig4.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig4.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig4.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig4.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig4.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig4.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig4.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig4.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig4.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig4.FocusPtTracker = DesignerRectTracker12
        Me.chk_Sig4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig4.Image = Nothing
        Me.chk_Sig4.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig4.ImageIndex = 0
        Me.chk_Sig4.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig4.Location = New System.Drawing.Point(235, 114)
        Me.chk_Sig4.Name = "chk_Sig4"
        Me.chk_Sig4.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig4.SideImage = Nothing
        Me.chk_Sig4.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig4.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig4.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig4.TabIndex = 49
        Me.chk_Sig4.Text = "Sig.4"
        Me.chk_Sig4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig4.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig4.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sig3
        '
        Me.chk_Sig3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig3.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig3.CenterPtTracker = DesignerRectTracker13
        Me.chk_Sig3.CheckButton = True
        Me.chk_Sig3.Checked = True
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig3.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig3.ColorFillBlendChecked = CBlendItems14
        Me.chk_Sig3.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig3.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig3.Corners.All = CType(6, Short)
        Me.chk_Sig3.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig3.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig3.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig3.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig3.DimFactorOver = 30
        Me.chk_Sig3.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig3.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig3.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig3.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig3.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig3.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig3.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig3.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig3.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig3.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig3.FocusPtTracker = DesignerRectTracker14
        Me.chk_Sig3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig3.Image = Nothing
        Me.chk_Sig3.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig3.ImageIndex = 0
        Me.chk_Sig3.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig3.Location = New System.Drawing.Point(190, 114)
        Me.chk_Sig3.Name = "chk_Sig3"
        Me.chk_Sig3.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig3.SideImage = Nothing
        Me.chk_Sig3.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig3.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig3.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig3.TabIndex = 48
        Me.chk_Sig3.Text = "Sig.3"
        Me.chk_Sig3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig3.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig3.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sig2
        '
        Me.chk_Sig2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig2.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig2.CenterPtTracker = DesignerRectTracker15
        Me.chk_Sig2.CheckButton = True
        Me.chk_Sig2.Checked = True
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig2.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems16.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig2.ColorFillBlendChecked = CBlendItems16
        Me.chk_Sig2.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig2.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig2.Corners.All = CType(6, Short)
        Me.chk_Sig2.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig2.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig2.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig2.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig2.DimFactorOver = 30
        Me.chk_Sig2.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig2.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig2.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig2.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig2.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig2.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig2.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig2.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig2.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig2.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig2.FocusPtTracker = DesignerRectTracker16
        Me.chk_Sig2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig2.Image = Nothing
        Me.chk_Sig2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig2.ImageIndex = 0
        Me.chk_Sig2.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig2.Location = New System.Drawing.Point(145, 114)
        Me.chk_Sig2.Name = "chk_Sig2"
        Me.chk_Sig2.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig2.SideImage = Nothing
        Me.chk_Sig2.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig2.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig2.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig2.TabIndex = 47
        Me.chk_Sig2.Text = "Sig.2"
        Me.chk_Sig2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig2.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig2.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_Sig1
        '
        Me.chk_Sig1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_Sig1.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig1.CenterPtTracker = DesignerRectTracker17
        Me.chk_Sig1.CheckButton = True
        Me.chk_Sig1.Checked = True
        CBlendItems17.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems17.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_Sig1.ColorFillBlend = CBlendItems17
        CBlendItems18.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems18.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_Sig1.ColorFillBlendChecked = CBlendItems18
        Me.chk_Sig1.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_Sig1.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_Sig1.Corners.All = CType(6, Short)
        Me.chk_Sig1.Corners.LowerLeft = CType(6, Short)
        Me.chk_Sig1.Corners.LowerRight = CType(6, Short)
        Me.chk_Sig1.Corners.UpperLeft = CType(6, Short)
        Me.chk_Sig1.Corners.UpperRight = CType(6, Short)
        Me.chk_Sig1.DimFactorOver = 30
        Me.chk_Sig1.FillType = MyButton.eFillType.LinearVertical
        Me.chk_Sig1.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_Sig1.FocalPoints.CenterPtX = 1.0!
        Me.chk_Sig1.FocalPoints.CenterPtY = 1.0!
        Me.chk_Sig1.FocalPoints.FocusPtX = 0.0!
        Me.chk_Sig1.FocalPoints.FocusPtY = 0.0!
        Me.chk_Sig1.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_Sig1.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_Sig1.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_Sig1.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_Sig1.FocusPtTracker = DesignerRectTracker18
        Me.chk_Sig1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Sig1.Image = Nothing
        Me.chk_Sig1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig1.ImageIndex = 0
        Me.chk_Sig1.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_Sig1.Location = New System.Drawing.Point(100, 114)
        Me.chk_Sig1.Name = "chk_Sig1"
        Me.chk_Sig1.Shape = MyButton.eShape.Rectangle
        Me.chk_Sig1.SideImage = Nothing
        Me.chk_Sig1.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig1.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_Sig1.Size = New System.Drawing.Size(45, 18)
        Me.chk_Sig1.TabIndex = 46
        Me.chk_Sig1.Text = "Sig.1"
        Me.chk_Sig1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_Sig1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_Sig1.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_Sig1.TextShadow = System.Drawing.Color.Transparent
        '
        'tbar_ScopePosition
        '
        Me.tbar_ScopePosition.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbar_ScopePosition.AutoSize = False
        Me.tbar_ScopePosition.Location = New System.Drawing.Point(103, 75)
        Me.tbar_ScopePosition.Maximum = 1000
        Me.tbar_ScopePosition.Name = "tbar_ScopePosition"
        Me.tbar_ScopePosition.Size = New System.Drawing.Size(408, 29)
        Me.tbar_ScopePosition.TabIndex = 45
        Me.tbar_ScopePosition.TickFrequency = 10
        Me.tbar_ScopePosition.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'chk_SignalInverted
        '
        Me.chk_SignalInverted.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_SignalInverted.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SignalInverted.CenterPtTracker = DesignerRectTracker19
        Me.chk_SignalInverted.CheckButton = True
        CBlendItems19.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems19.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_SignalInverted.ColorFillBlend = CBlendItems19
        CBlendItems20.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems20.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_SignalInverted.ColorFillBlendChecked = CBlendItems20
        Me.chk_SignalInverted.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_SignalInverted.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_SignalInverted.Corners.All = CType(6, Short)
        Me.chk_SignalInverted.Corners.LowerLeft = CType(6, Short)
        Me.chk_SignalInverted.Corners.LowerRight = CType(6, Short)
        Me.chk_SignalInverted.Corners.UpperLeft = CType(6, Short)
        Me.chk_SignalInverted.Corners.UpperRight = CType(6, Short)
        Me.chk_SignalInverted.DimFactorOver = 30
        Me.chk_SignalInverted.FillType = MyButton.eFillType.LinearVertical
        Me.chk_SignalInverted.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_SignalInverted.FocalPoints.CenterPtX = 1.0!
        Me.chk_SignalInverted.FocalPoints.CenterPtY = 1.0!
        Me.chk_SignalInverted.FocalPoints.FocusPtX = 0.0!
        Me.chk_SignalInverted.FocalPoints.FocusPtY = 0.0!
        Me.chk_SignalInverted.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_SignalInverted.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_SignalInverted.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_SignalInverted.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_SignalInverted.FocusPtTracker = DesignerRectTracker20
        Me.chk_SignalInverted.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_SignalInverted.Image = Nothing
        Me.chk_SignalInverted.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SignalInverted.ImageIndex = 0
        Me.chk_SignalInverted.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_SignalInverted.Location = New System.Drawing.Point(8, 114)
        Me.chk_SignalInverted.Name = "chk_SignalInverted"
        Me.chk_SignalInverted.Shape = MyButton.eShape.Rectangle
        Me.chk_SignalInverted.SideImage = Nothing
        Me.chk_SignalInverted.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SignalInverted.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_SignalInverted.Size = New System.Drawing.Size(44, 18)
        Me.chk_SignalInverted.TabIndex = 42
        Me.chk_SignalInverted.Text = "Invert"
        Me.chk_SignalInverted.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_SignalInverted.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_SignalInverted.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_SignalInverted.TextShadow = System.Drawing.Color.Transparent
        '
        'tbar_ScopeTime
        '
        Me.tbar_ScopeTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbar_ScopeTime.AutoSize = False
        Me.tbar_ScopeTime.LargeChange = 1
        Me.tbar_ScopeTime.Location = New System.Drawing.Point(516, 75)
        Me.tbar_ScopeTime.Maximum = 8
        Me.tbar_ScopeTime.Name = "tbar_ScopeTime"
        Me.tbar_ScopeTime.Size = New System.Drawing.Size(92, 29)
        Me.tbar_ScopeTime.TabIndex = 41
        Me.tbar_ScopeTime.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tbar_ScopeTime.Value = 4
        '
        'tbar_ScopeVoltage
        '
        Me.tbar_ScopeVoltage.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tbar_ScopeVoltage.AutoSize = False
        Me.tbar_ScopeVoltage.Location = New System.Drawing.Point(4, 75)
        Me.tbar_ScopeVoltage.Maximum = 11
        Me.tbar_ScopeVoltage.Name = "tbar_ScopeVoltage"
        Me.tbar_ScopeVoltage.Size = New System.Drawing.Size(92, 29)
        Me.tbar_ScopeVoltage.TabIndex = 40
        Me.tbar_ScopeVoltage.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tbar_ScopeVoltage.Value = 3
        '
        'Timer2
        '
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.Cornsilk
        Me.TextBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.Black
        Me.TextBox1.Location = New System.Drawing.Point(4, 200)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(615, 98)
        Me.TextBox1.TabIndex = 3
        '
        'toolStrip1
        '
        Me.toolStrip1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.toolStrip1.AutoSize = False
        Me.toolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.toolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.toolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator3, Me.toolStripButton_Run, Me.toolStripButton_SaveConfig, Me.toolStripSeparator1, Me.toolStripButton_LoadConfig, Me.toolStripSeparator4, Me.toolStripButton_Docs, Me.toolStripSeparator2})
        Me.toolStrip1.Location = New System.Drawing.Point(1, 0)
        Me.toolStrip1.Name = "toolStrip1"
        Me.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.toolStrip1.Size = New System.Drawing.Size(618, 28)
        Me.toolStrip1.TabIndex = 223
        Me.toolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 28)
        '
        'toolStripButton_Run
        '
        Me.toolStripButton_Run.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.toolStripButton_Run.AutoSize = False
        Me.toolStripButton_Run.Checked = True
        Me.toolStripButton_Run.CheckOnClick = True
        Me.toolStripButton_Run.CheckState = System.Windows.Forms.CheckState.Checked
        Me.toolStripButton_Run.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolStripButton_Run.Image = CType(resources.GetObject("toolStripButton_Run.Image"), System.Drawing.Image)
        Me.toolStripButton_Run.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton_Run.Name = "toolStripButton_Run"
        Me.toolStripButton_Run.Size = New System.Drawing.Size(60, 24)
        Me.toolStripButton_Run.Text = "Run"
        '
        'toolStripButton_SaveConfig
        '
        Me.toolStripButton_SaveConfig.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolStripButton_SaveConfig.Image = CType(resources.GetObject("toolStripButton_SaveConfig.Image"), System.Drawing.Image)
        Me.toolStripButton_SaveConfig.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton_SaveConfig.Name = "toolStripButton_SaveConfig"
        Me.toolStripButton_SaveConfig.Size = New System.Drawing.Size(165, 25)
        Me.toolStripButton_SaveConfig.Text = "Save configuration as"
        Me.toolStripButton_SaveConfig.ToolTipText = "Save configuration or frequency" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "To save frequency the file name must start with " & _
            """Freq"""
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 28)
        '
        'toolStripButton_LoadConfig
        '
        Me.toolStripButton_LoadConfig.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolStripButton_LoadConfig.Image = CType(resources.GetObject("toolStripButton_LoadConfig.Image"), System.Drawing.Image)
        Me.toolStripButton_LoadConfig.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton_LoadConfig.Name = "toolStripButton_LoadConfig"
        Me.toolStripButton_LoadConfig.Size = New System.Drawing.Size(146, 25)
        Me.toolStripButton_LoadConfig.Text = "Load configuration"
        Me.toolStripButton_LoadConfig.ToolTipText = "Load configuration or frequency." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "To load frequency the file name must start with" & _
            " ""Freq"""
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(6, 28)
        '
        'toolStripButton_Docs
        '
        Me.toolStripButton_Docs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolStripButton_Docs.Image = CType(resources.GetObject("toolStripButton_Docs.Image"), System.Drawing.Image)
        Me.toolStripButton_Docs.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton_Docs.Name = "toolStripButton_Docs"
        Me.toolStripButton_Docs.Size = New System.Drawing.Size(60, 25)
        Me.toolStripButton_Docs.Text = "Docs"
        Me.toolStripButton_Docs.ToolTipText = "Open doc folder"
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(6, 28)
        '
        'btn_CopyText
        '
        Me.btn_CopyText.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_CopyText.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_CopyText.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CopyText.CenterPtTracker = DesignerRectTracker21
        CBlendItems21.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems21.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.btn_CopyText.ColorFillBlend = CBlendItems21
        CBlendItems22.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems22.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.btn_CopyText.ColorFillBlendChecked = CBlendItems22
        Me.btn_CopyText.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_CopyText.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_CopyText.Corners.All = CType(6, Short)
        Me.btn_CopyText.Corners.LowerLeft = CType(6, Short)
        Me.btn_CopyText.Corners.LowerRight = CType(6, Short)
        Me.btn_CopyText.Corners.UpperLeft = CType(6, Short)
        Me.btn_CopyText.Corners.UpperRight = CType(6, Short)
        Me.btn_CopyText.DimFactorOver = 30
        Me.btn_CopyText.FillType = MyButton.eFillType.LinearVertical
        Me.btn_CopyText.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_CopyText.FocalPoints.CenterPtX = 1.0!
        Me.btn_CopyText.FocalPoints.CenterPtY = 1.0!
        Me.btn_CopyText.FocalPoints.FocusPtX = 0.0!
        Me.btn_CopyText.FocalPoints.FocusPtY = 0.0!
        Me.btn_CopyText.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_CopyText.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_CopyText.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_CopyText.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_CopyText.FocusPtTracker = DesignerRectTracker22
        Me.btn_CopyText.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CopyText.Image = Nothing
        Me.btn_CopyText.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CopyText.ImageIndex = 0
        Me.btn_CopyText.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_CopyText.Location = New System.Drawing.Point(78, 304)
        Me.btn_CopyText.Name = "btn_CopyText"
        Me.btn_CopyText.Shape = MyButton.eShape.Rectangle
        Me.btn_CopyText.SideImage = Nothing
        Me.btn_CopyText.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CopyText.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_CopyText.Size = New System.Drawing.Size(108, 18)
        Me.btn_CopyText.TabIndex = 224
        Me.btn_CopyText.Text = "Copy to clipboard"
        Me.btn_CopyText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_CopyText.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_CopyText.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_CopyText.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_ClearText
        '
        Me.btn_ClearText.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ClearText.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btn_ClearText.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ClearText.CenterPtTracker = DesignerRectTracker23
        CBlendItems23.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems23.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.btn_ClearText.ColorFillBlend = CBlendItems23
        CBlendItems24.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems24.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.btn_ClearText.ColorFillBlendChecked = CBlendItems24
        Me.btn_ClearText.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ClearText.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ClearText.Corners.All = CType(6, Short)
        Me.btn_ClearText.Corners.LowerLeft = CType(6, Short)
        Me.btn_ClearText.Corners.LowerRight = CType(6, Short)
        Me.btn_ClearText.Corners.UpperLeft = CType(6, Short)
        Me.btn_ClearText.Corners.UpperRight = CType(6, Short)
        Me.btn_ClearText.DimFactorOver = 30
        Me.btn_ClearText.FillType = MyButton.eFillType.LinearVertical
        Me.btn_ClearText.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_ClearText.FocalPoints.CenterPtX = 1.0!
        Me.btn_ClearText.FocalPoints.CenterPtY = 1.0!
        Me.btn_ClearText.FocalPoints.FocusPtX = 0.0!
        Me.btn_ClearText.FocalPoints.FocusPtY = 0.0!
        Me.btn_ClearText.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_ClearText.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_ClearText.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ClearText.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ClearText.FocusPtTracker = DesignerRectTracker24
        Me.btn_ClearText.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ClearText.Image = Nothing
        Me.btn_ClearText.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ClearText.ImageIndex = 0
        Me.btn_ClearText.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ClearText.Location = New System.Drawing.Point(4, 304)
        Me.btn_ClearText.Name = "btn_ClearText"
        Me.btn_ClearText.Shape = MyButton.eShape.Rectangle
        Me.btn_ClearText.SideImage = Nothing
        Me.btn_ClearText.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ClearText.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ClearText.Size = New System.Drawing.Size(70, 18)
        Me.btn_ClearText.TabIndex = 225
        Me.btn_ClearText.Text = "Clear text"
        Me.btn_ClearText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ClearText.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ClearText.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ClearText.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_FirstSlot
        '
        Me.txt_FirstSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_FirstSlot.ArrowsIncrement = 1
        Me.txt_FirstSlot.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.txt_FirstSlot.BackColor_Over = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txt_FirstSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FirstSlot.DimFactorGray = -10
        Me.txt_FirstSlot.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FirstSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_FirstSlot.Increment = 0.2
        Me.txt_FirstSlot.Location = New System.Drawing.Point(583, 306)
        Me.txt_FirstSlot.MaxValue = 999
        Me.txt_FirstSlot.MinValue = 0
        Me.txt_FirstSlot.Name = "txt_FirstSlot"
        Me.txt_FirstSlot.NumericValue = 1
        Me.txt_FirstSlot.NumericValueInteger = 1
        Me.txt_FirstSlot.RectangleColor = System.Drawing.Color.White
        Me.txt_FirstSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Inset
        Me.txt_FirstSlot.RoundingStep = 0
        Me.txt_FirstSlot.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_FirstSlot.Size = New System.Drawing.Size(36, 16)
        Me.txt_FirstSlot.SuppressZeros = True
        Me.txt_FirstSlot.TabIndex = 226
        Me.txt_FirstSlot.TabStop = False
        Me.txt_FirstSlot.Text = "1"
        Me.txt_FirstSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_FirstSlot
        '
        Me.Label_FirstSlot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_FirstSlot.ForeColor = System.Drawing.Color.Black
        Me.Label_FirstSlot.Location = New System.Drawing.Point(529, 307)
        Me.Label_FirstSlot.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label_FirstSlot.Name = "Label_FirstSlot"
        Me.Label_FirstSlot.Size = New System.Drawing.Size(49, 16)
        Me.Label_FirstSlot.TabIndex = 227
        Me.Label_FirstSlot.Text = "First Slot"
        Me.Label_FirstSlot.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'chk_MultipleSlots
        '
        Me.chk_MultipleSlots.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk_MultipleSlots.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker25.IsActive = False
        DesignerRectTracker25.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker25.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_MultipleSlots.CenterPtTracker = DesignerRectTracker25
        Me.chk_MultipleSlots.CheckButton = True
        CBlendItems25.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems25.iPoint = New Single() {0.0!, 0.8683274!, 1.0!}
        Me.chk_MultipleSlots.ColorFillBlend = CBlendItems25
        CBlendItems26.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems26.iPoint = New Single() {0.0!, 0.2491103!, 1.0!}
        Me.chk_MultipleSlots.ColorFillBlendChecked = CBlendItems26
        Me.chk_MultipleSlots.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.chk_MultipleSlots.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.chk_MultipleSlots.Corners.All = CType(6, Short)
        Me.chk_MultipleSlots.Corners.LowerLeft = CType(6, Short)
        Me.chk_MultipleSlots.Corners.LowerRight = CType(6, Short)
        Me.chk_MultipleSlots.Corners.UpperLeft = CType(6, Short)
        Me.chk_MultipleSlots.Corners.UpperRight = CType(6, Short)
        Me.chk_MultipleSlots.DimFactorOver = 30
        Me.chk_MultipleSlots.FillType = MyButton.eFillType.LinearVertical
        Me.chk_MultipleSlots.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.chk_MultipleSlots.FocalPoints.CenterPtX = 1.0!
        Me.chk_MultipleSlots.FocalPoints.CenterPtY = 1.0!
        Me.chk_MultipleSlots.FocalPoints.FocusPtX = 0.0!
        Me.chk_MultipleSlots.FocalPoints.FocusPtY = 0.0!
        Me.chk_MultipleSlots.FocalPointsChecked.CenterPtX = 0.0!
        Me.chk_MultipleSlots.FocalPointsChecked.CenterPtY = 0.0!
        Me.chk_MultipleSlots.FocalPointsChecked.FocusPtX = 0.0!
        Me.chk_MultipleSlots.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker26.IsActive = False
        DesignerRectTracker26.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker26.TrackerRectangle"), System.Drawing.RectangleF)
        Me.chk_MultipleSlots.FocusPtTracker = DesignerRectTracker26
        Me.chk_MultipleSlots.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_MultipleSlots.Image = Nothing
        Me.chk_MultipleSlots.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_MultipleSlots.ImageIndex = 0
        Me.chk_MultipleSlots.ImageSize = New System.Drawing.Size(16, 16)
        Me.chk_MultipleSlots.Location = New System.Drawing.Point(440, 304)
        Me.chk_MultipleSlots.Name = "chk_MultipleSlots"
        Me.chk_MultipleSlots.Shape = MyButton.eShape.Rectangle
        Me.chk_MultipleSlots.SideImage = Nothing
        Me.chk_MultipleSlots.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_MultipleSlots.SideImageSize = New System.Drawing.Size(32, 32)
        Me.chk_MultipleSlots.Size = New System.Drawing.Size(84, 18)
        Me.chk_MultipleSlots.TabIndex = 228
        Me.chk_MultipleSlots.Text = "Multiple Slots"
        Me.chk_MultipleSlots.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk_MultipleSlots.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.chk_MultipleSlots.TextMargin = New System.Windows.Forms.Padding(0)
        Me.chk_MultipleSlots.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_BitMask
        '
        Me.Label_BitMask.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_BitMask.ForeColor = System.Drawing.Color.Black
        Me.Label_BitMask.Location = New System.Drawing.Point(192, 306)
        Me.Label_BitMask.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label_BitMask.Name = "Label_BitMask"
        Me.Label_BitMask.Size = New System.Drawing.Size(50, 16)
        Me.Label_BitMask.TabIndex = 229
        Me.Label_BitMask.Text = "Bit Mask"
        Me.Label_BitMask.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txt_BitMask
        '
        Me.txt_BitMask.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_BitMask.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BitMask.Location = New System.Drawing.Point(245, 303)
        Me.txt_BitMask.MaxLength = 26
        Me.txt_BitMask.Name = "txt_BitMask"
        Me.txt_BitMask.Size = New System.Drawing.Size(190, 21)
        Me.txt_BitMask.TabIndex = 230
        Me.txt_BitMask.Text = "12345678901234567890123456"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 325)
        Me.Controls.Add(Me.txt_BitMask)
        Me.Controls.Add(Me.Label_BitMask)
        Me.Controls.Add(Me.chk_MultipleSlots)
        Me.Controls.Add(Me.txt_FirstSlot)
        Me.Controls.Add(Me.Label_FirstSlot)
        Me.Controls.Add(Me.btn_ClearText)
        Me.Controls.Add(Me.btn_CopyText)
        Me.Controls.Add(Me.toolStrip1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox_Scope)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(640, 360)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Signal Decoder"
        CType(Me.pbox_Scope, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Scope.ResumeLayout(False)
        Me.GroupBox_Scope.PerformLayout()
        CType(Me.tbar_ScopePosition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbar_ScopeTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbar_ScopeVoltage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.toolStrip1.ResumeLayout(False)
        Me.toolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents pbox_Scope As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox_Scope As System.Windows.Forms.GroupBox
    Friend WithEvents tbar_ScopeVoltage As System.Windows.Forms.TrackBar
    Friend WithEvents tbar_ScopeTime As System.Windows.Forms.TrackBar
    Friend WithEvents chk_SignalInverted As MyButton
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents tbar_ScopePosition As System.Windows.Forms.TrackBar
    Friend WithEvents chk_Sig2 As MyButton
    Friend WithEvents chk_Sig1 As MyButton
    Friend WithEvents chk_Sig3 As MyButton
    Friend WithEvents chk_Sig4 As MyButton
    Friend WithEvents txt_Trim2 As MyTextBox
    Friend WithEvents txt_Trim3 As MyTextBox
    Friend WithEvents txt_Trim4 As MyTextBox
    Friend WithEvents txt_Trim1 As MyTextBox
    Friend WithEvents txt_Trim5 As MyTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_Trim6 As MyTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents chk_Sync As MyButton
    Friend WithEvents chk_Sig7 As MyButton
    Friend WithEvents chk_Sig6 As MyButton
    Friend WithEvents chk_Sig5 As MyButton
    Friend WithEvents cmb_SignalType As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents toolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents toolStripButton_Run As System.Windows.Forms.ToolStripButton
    Friend WithEvents toolStripButton_SaveConfig As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents toolStripButton_LoadConfig As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents toolStripButton_Docs As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btn_CopyText As MyButton
    Friend WithEvents btn_ClearText As MyButton
    Friend WithEvents txt_FirstSlot As MyTextBox
    Friend WithEvents Label_FirstSlot As System.Windows.Forms.Label
    Friend WithEvents chk_MultipleSlots As MyButton
    Friend WithEvents Label_BitMask As System.Windows.Forms.Label
    Friend WithEvents txt_BitMask As System.Windows.Forms.TextBox
    Friend WithEvents btn_AudioInputs As MyButton
    Friend WithEvents cmb_AudioInDevices As MyComboBox

End Class
