﻿
Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        Text = AppTitleAndVersion("")
        toolStrip1.Renderer = New ToolStripButtonRenderer
        ' --------------------------------------------------------
        Load_INI("")
        ' -------------------------------------------------------- Init Audio In
        Decoder_Initialize(SelectedAudioIn)
        FillAudioDevicesCombo()
        ' --------------------------------------------------------
        SetMainParams()
        SetSignalParams()
        ' -------------------------------------------------------- TIMER START
        Timer1.Interval = 100
        Timer1.Start()
        Timer2.Interval = 15
        Timer2.Start()
        ' -------------------------------------------------------- CPU Affinity test
        'Dim Proc As Process = Process.GetCurrentProcess()
        'For i As Int32 = 0 To Proc.Threads.Count
        '    Dim Thread As ProcessThread = Proc.Threads(0)
        '    Dim AffinityMask As Int32 = 2  ' use only flagged processors, despite availability
        '    Thread.ProcessorAffinity = CType(AffinityMask, IntPtr)
        'Next
        ' --------------------------------------------------------
        EventsAreEnabled = True
        pbox_Scope.Focus()
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Decoder_CloseAll()
        Save_INI("")
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        UpdateScope()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub ToolStrip1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles toolStrip1.MouseEnter
        Me.Focus() ' with this the toolstrip responds always to the first click
    End Sub

    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles toolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    toolStrip1.Width, toolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    Private Sub toolStripButton_SaveConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton_SaveConfig.Click
        SaveConfigurationAs()
    End Sub

    Private Sub toolStripButton_LoadConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton_LoadConfig.Click
        EventsAreEnabled = False
        LoadConfiguration()
        EventsAreEnabled = True
        SetMainParams()
        SetSignalParams()
    End Sub

    Private Sub toolStripButton_Docs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton_Docs.Click
        Dim s As String = Application.StartupPath + "\Docs"
        If FolderExists(s) Then Process.Start(s)
    End Sub

    ' ===================================================================================================
    '  SELECT AUDIO INPUT 
    ' ===================================================================================================
    Friend SelectedAudioIn As Int32 = 0
    Private Sub cmb_AudioInDevices_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_AudioInDevices.DropDown
        cmb_AudioInDevices.ItemHeight = 16
        FillAudioDevicesCombo()
    End Sub
    Private Sub cmb_AudioInDevices_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_AudioInDevices.DropDownClosed
        cmb_AudioInDevices.ItemHeight = 11
        SelectedAudioIn = cmb_AudioInDevices.SelectedIndex
        Decoder_Initialize(SelectedAudioIn)
    End Sub
    Private Sub FillAudioDevicesCombo()
        Dim sa As String() = WaveNative.GetDevNames
        If sa.Length = 0 Then ReDim sa(0) : sa(0) = ""
        cmb_AudioInDevices.Items.Clear()
        For i As Int32 = 0 To sa.Length - 1
            cmb_AudioInDevices.Items.Add(ExtractDeviceName(sa(i)))
        Next
        Combo_SetIndex(cmb_AudioInDevices, SelectedAudioIn)
    End Sub

    ' ===================================================================================================
    '  AUDIO IN HELPERS
    ' ===================================================================================================
    Private Function ExtractDeviceName(ByVal s As String) As String
        If s = Nothing Then Return ""
        Dim i As Int32 = InStr(s, "(") - 1
        If i > 1 Then s = s.Remove(i)
        Return s.Trim
    End Function
    Private Sub btn_AudioInputs_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_AudioInputs.ClickButtonArea
        Open_AudioInputs()
    End Sub


    ' ===================================================================================================
    '  USER COMMANDS 
    ' ===================================================================================================
    Private Sub btn_ClearText_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ClearText.ClickButtonArea
        DecodedBits = ""
    End Sub

    Private Sub btn_CopyText_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_CopyText.ClickButtonArea
        Clipboard.SetData(System.Windows.Forms.DataFormats.Text, DecodedBits)
    End Sub

    ' ===================================================================================================
    '  USER PARAMS 
    ' ===================================================================================================
    Private Sub RemoveFocusFromControls(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                                  Handles _
                                                      tbar_ScopeVoltage.MouseLeave, _
                                                      tbar_ScopeTime.MouseLeave, _
                                                      tbar_ScopePosition.MouseLeave, _
                                                      chk_SignalInverted.MouseLeave, _
                                                      chk_Sync.MouseLeave, _
                                                      chk_Sig1.MouseLeave, _
                                                      chk_Sig2.MouseLeave, _
                                                      chk_Sig3.MouseLeave, _
                                                      chk_Sig4.MouseLeave, _
                                                      chk_Sig5.MouseLeave, _
                                                      chk_Sig6.MouseLeave, _
                                                      chk_Sig7.MouseLeave, _
                                                      txt_Trim1.MouseLeave, _
                                                      txt_Trim2.MouseLeave, _
                                                      txt_Trim3.MouseLeave, _
                                                      txt_Trim4.MouseLeave, _
                                                      txt_Trim5.MouseLeave, _
                                                      txt_Trim6.MouseLeave, _
                                                      cmb_SignalType.MouseLeave, _
                                                      txt_BitMask.LostFocus, _
                                                      chk_MultipleSlots.LostFocus, _
                                                      txt_FirstSlot.LostFocus
        If Not EventsAreEnabled Then Return
        pbox_Scope.Focus()
    End Sub

    Private Sub SaveParamsOnLostFocus(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                                    Handles _
                                                        tbar_ScopeVoltage.LostFocus, _
                                                        tbar_ScopeTime.LostFocus, _
                                                        tbar_ScopePosition.LostFocus, _
                                                        chk_SignalInverted.LostFocus, _
                                                        chk_Sync.LostFocus, _
                                                        chk_Sig1.LostFocus, _
                                                        chk_Sig2.LostFocus, _
                                                        chk_Sig3.LostFocus, _
                                                        chk_Sig4.LostFocus, _
                                                        chk_Sig5.LostFocus, _
                                                        chk_Sig6.LostFocus, _
                                                        chk_Sig7.LostFocus, _
                                                        txt_Trim1.LostFocus, _
                                                        txt_Trim2.LostFocus, _
                                                        txt_Trim3.LostFocus, _
                                                        txt_Trim4.LostFocus, _
                                                        txt_Trim5.LostFocus, _
                                                        txt_Trim6.LostFocus, _
                                                        cmb_SignalType.LostFocus, _
                                                        txt_BitMask.LostFocus, _
                                                        chk_MultipleSlots.LostFocus, _
                                                        txt_FirstSlot.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI("")
    End Sub

    Private Sub ChangedMainParams(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles tbar_ScopeVoltage.Scroll, _
                                                                            tbar_ScopeTime.Scroll, _
                                                                            tbar_ScopePosition.Scroll, _
                                                                            chk_SignalInverted.CheckedChanged, _
                                                                            chk_Sync.CheckedChanged, _
                                                                            chk_Sig1.CheckedChanged, _
                                                                            chk_Sig2.CheckedChanged, _
                                                                            chk_Sig3.CheckedChanged, _
                                                                            chk_Sig4.CheckedChanged, _
                                                                            chk_Sig5.CheckedChanged, _
                                                                            chk_Sig6.CheckedChanged, _
                                                                            chk_Sig7.CheckedChanged, _
                                                                            txt_Trim1.TextChanged, _
                                                                            txt_Trim2.TextChanged, _
                                                                            txt_Trim3.TextChanged, _
                                                                            txt_Trim4.TextChanged, _
                                                                            txt_Trim5.TextChanged, _
                                                                            txt_Trim6.TextChanged
        If Not EventsAreEnabled Then Return
        SetMainParams()
    End Sub

    Private Sub ChangedSignalParams(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                                                    Handles cmb_SignalType.TextChanged, _
                                                                            txt_BitMask.TextChanged, _
                                                                            chk_MultipleSlots.CheckedChanged, _
                                                                            txt_FirstSlot.TextChanged
        If Not EventsAreEnabled Then Return
        SetSignalParams()
    End Sub

    Private Sub SetMainParams()
        Scope.SetVoltage(VoltageFromTrackBar(tbar_ScopeVoltage.Value))
        Scope.SetTime(TimeFromTrackBar(tbar_ScopeTime.Value))
        Scope.SetPosition(tbar_ScopePosition.Value)
        Scope.SetSync(chk_Sync.Checked)
        Scope.SetSignalType(CType(cmb_SignalType.SelectedIndex, DecoderTypes))
        Scope.SetSignals(chk_Sig1.Checked, _
                         chk_Sig2.Checked, _
                         chk_Sig3.Checked, _
                         chk_Sig4.Checked, _
                         chk_Sig5.Checked, _
                         chk_Sig6.Checked, _
                         chk_Sig7.Checked)
        DecoderSetParams(chk_SignalInverted.Checked, _
                         txt_Trim1.NumericValueInteger, _
                         txt_Trim2.NumericValueInteger, _
                         txt_Trim3.NumericValueInteger, _
                         txt_Trim4.NumericValueInteger, _
                         txt_Trim5.NumericValueInteger, _
                         txt_Trim6.NumericValueInteger)
        UpdateScope()
        pbox_Scope.Refresh()
    End Sub

    Private Sub SetSignalParams()
        DecoderType = CType(cmb_SignalType.SelectedIndex, DecoderTypes)
        InitControls_ByDecoderType()

        BitMask = txt_BitMask.Text
        MultiSlot = chk_MultipleSlots.Checked
        FirstSlot = txt_FirstSlot.NumericValueInteger

        DecodedBits = ""
        MaskedBits = ""
        MaskedBitsValue = 0

        Dim numasterix As Int32 = 0
        For Each c As Char In BitMask
            If c = "x"c AndAlso numasterix < 28 Then numasterix += 1
        Next

        NumConsecutiveSlots = CInt(2 ^ numasterix)
    End Sub

    Private Sub InitControls_ByDecoderType()
        Select Case DecoderType
            Case DecoderTypes.MorseCode
                chk_Sig1.Visible = True
                chk_Sig2.Visible = True
                chk_Sig3.Visible = True
                chk_Sig4.Visible = True
                chk_Sig5.Visible = True
                chk_Sig6.Visible = True
                chk_Sig7.Visible = False
                Label1.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label4.Visible = True
                Label5.Visible = False
                Label6.Visible = False
                txt_Trim1.Visible = True
                txt_Trim2.Visible = True
                txt_Trim3.Visible = True
                txt_Trim4.Visible = True
                txt_Trim5.Visible = False
                txt_Trim6.Visible = False
                Label1.Text = "Envelope"
                Label2.Text = "Filter"
                Label3.Text = "Trigger"
                Label4.Text = "Dot ms"
                ShowOutputControls(False)
            Case DecoderTypes.EncodedRC
                chk_Sig1.Visible = True
                chk_Sig2.Visible = True
                chk_Sig3.Visible = True
                chk_Sig4.Visible = True
                chk_Sig5.Visible = True
                chk_Sig6.Visible = True
                chk_Sig7.Visible = True
                Label1.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label4.Visible = True
                Label5.Visible = True
                Label6.Visible = True
                txt_Trim1.Visible = True
                txt_Trim2.Visible = True
                txt_Trim3.Visible = True
                txt_Trim4.Visible = True
                txt_Trim5.Visible = True
                txt_Trim6.Visible = True
                Label1.Text = "Envelope"
                Label2.Text = "Filter"
                Label3.Text = "Trigger"
                Label4.Text = "Count1"
                Label5.Text = "Count2"
                Label6.Text = "N.bit"
                ShowOutputControls(True)
            Case DecoderTypes.Meteo
                chk_Sig1.Visible = False
                chk_Sig2.Visible = False
                chk_Sig3.Visible = False
                chk_Sig4.Visible = False
                chk_Sig5.Visible = False
                chk_Sig6.Visible = False
                chk_Sig7.Visible = False
                Label1.Visible = True
                Label2.Visible = False
                Label3.Visible = False
                Label4.Visible = False
                Label5.Visible = False
                Label6.Visible = False
                txt_Trim1.Visible = True
                txt_Trim2.Visible = False
                txt_Trim3.Visible = False
                txt_Trim4.Visible = False
                txt_Trim5.Visible = False
                txt_Trim6.Visible = False
                ShowOutputControls(True)
        End Select
    End Sub

    Private Sub ShowOutputControls(ByVal show As Boolean)
        Label_BitMask.Visible = show
        txt_BitMask.Visible = show
        chk_MultipleSlots.Visible = show
        Label_FirstSlot.Visible = show
        txt_FirstSlot.Visible = show
        If show Then
            TextBox1.Font = New Font("Courier New", 10)
        Else
            TextBox1.Font = New Font("Calibri", 11)
        End If
    End Sub

    Private Function VoltageFromTrackBar(ByVal n As Int32) As Single
        Select Case n
            Case 0 : Return 500
            Case 1 : Return 250
            Case 2 : Return 200
            Case 3 : Return 100
            Case 4 : Return 50
            Case 5 : Return 25
            Case 6 : Return 20
            Case 7 : Return 10
            Case 8 : Return 5
            Case 9 : Return 2.5
            Case 10 : Return 2
            Case 11 : Return 1
        End Select
    End Function

    Private Function TimeFromTrackBar(ByVal n As Int32) As Single
        Select Case n
            Case 0 : Return 200
            Case 1 : Return 100
            Case 2 : Return 50
            Case 3 : Return 20
            Case 4 : Return 10
            Case 5 : Return 5
            Case 6 : Return 2
            Case 7 : Return 1
            Case 8 : Return 0.5
        End Select
    End Function

    ' ===================================================================================================
    '  TIMER 1 - 10 Hz
    ' ===================================================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        If WindowState <> FormWindowState.Minimized Then
            If toolStripButton_Run.Checked Then
                UpdateScope()
            End If
        End If
    End Sub

    Private Sub UpdateScope()
        Scope.Update(pbox_Scope, chk_SignalInverted.Checked)
    End Sub

    ' ===================================================================================================
    '  TIMER 2 - 60 Hz
    ' ===================================================================================================
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        '
        ' ------------------------------------------------ if not changed exit
        Static oldDecodedBits As String = ""
        If DecodedBits = oldDecodedBits Then Return
        oldDecodedBits = DecodedBits

        ' ------------------------------------------------ decode to slots
        Select Case DecoderType

            Case DecoderTypes.MorseCode
                If toolStripButton_Run.Checked Then
                    If TextBox1.Text <> DecodedBits Then
                        TextBox1.Text = DecodedBits
                        TextBox1.SelectionStart = 99999
                        TextBox1.ScrollToCaret()
                    End If
                End If

            Case DecoderTypes.EncodedRC
                ExtractMaskedBits()
                If chk_MultipleSlots.Checked Then
                    For i As Int32 = 0 To NumConsecutiveSlots - 1
                        Slots.WriteSlot(FirstSlot + i, If(i = MaskedBitsValue, 1000, 0))
                    Next
                Else
                    Slots.WriteSlot(FirstSlot, MaskedBitsValue)
                End If

                If toolStripButton_Run.Checked Then
                    TextBox1.Text = "Decoded Bits: " + DecodedBits + vbCrLf + _
                                    " Masked Bits: " + MaskedBits + vbCrLf + _
                                    "Masked Value: " + MaskedBitsValue.ToString
                End If

            Case DecoderTypes.Meteo

        End Select

    End Sub

    Private MaskedBits As String
    Private MaskedBitsValue As Int32
    Private NumConsecutiveSlots As Int32

    Private Sub ExtractMaskedBits()
        Dim s As String
        MaskedBits = ""
        MaskedBitsValue = -1
        If DecodedBits.Length <> BitMask.Length Then
            Return
        End If
        For i As Int32 = 0 To BitMask.Length - 1
            s = BitMask(i)
            If s = "0" Or s = "1" Then
                If DecodedBits(i) <> s Then
                    MaskedBits = ""
                    MaskedBitsValue = -1
                    Return
                End If
            Else
                MaskedBits += DecodedBits(i)
            End If
        Next
        If MaskedBits.Length = 0 Then Return
        MaskedBitsValue = Convert.ToInt32(MaskedBits, 2)
    End Sub

End Class
