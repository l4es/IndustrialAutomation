﻿Module SignalDecoder

    Friend Enum DecoderTypes As Int32
        MorseCode
        EncodedRC 'Motorola_5026 / Holtek_HT12 / National_MM53200 / UMC_UM3750 / Princeton_PT2262 / Ev1527
        Meteo
    End Enum

    Friend Structure SignalSample
        Public Sig1 As Single
        Public Sig3 As Single
        Public Sig2 As Single
        Public Sig4 As Single
        Public Sig5 As Single
        Public Sig6 As Int32
        Public Sig7 As Int32
        Public triglevel As Single
        Public delta As Single
        Public bits As UInt32
        Public text As String
    End Structure

    'Private m_SampleFreq As Int32 = 176400 ' 44100 or 176400 or 192000 or 198450
    'Private m_Channels As Int32 = 1
    'Private m_NumBuffers As Int32 = 4
    'Private m_LenBuffers As Int32 = 4096

    Friend SampleFreq As Int32 = 44100 ' 44100 or 176400 or 192000 or 198450
    Private m_Channels As Int32 = 1
    Private m_NumBuffers As Int32 = 40
    Private m_LenBuffers As Int32 = 256

    Friend FIFO As SignalFIFO = New SignalFIFO(CInt(SampleFreq * 3))
    Private REC As AudioIn

    Friend BitMask As String
    Friend MultiSlot As Boolean
    Friend FirstSlot As Int32
    Friend DecoderType As DecoderTypes
    Friend DecodedBits As String = ""


    Friend Sub DecoderSetParams(ByVal SignalInverted As Boolean, _
                                ByVal Trim1 As Int32, _
                                ByVal Trim2 As Int32, _
                                ByVal Trim3 As Int32, _
                                ByVal Trim4 As Int32, _
                                ByVal Trim5 As Int32, _
                                ByVal Trim6 As Int32)

        DecoderMorse_SetParams(SignalInverted, _
                                  Trim1, _
                                  Trim2, _
                                  Trim4)

        Decoder5026_SetParams(SignalInverted, _
                              Trim1, _
                              Trim2, _
                              Trim3, _
                              Trim4, _
                              Trim5, _
                              Trim6)
    End Sub

    Friend Sub Decoder_Initialize(Optional ByVal InputDeviceIndex As Int32 = -1)
        Decoder_CloseAll()
        REC = New AudioIn()
        REC.InputOn(InputDeviceIndex, _
                    SampleFreq, _
                    m_Channels, _
                    m_LenBuffers, _
                    m_NumBuffers, _
                    New AudioIn.BufferDoneEventHandler(AddressOf DataArrived))
    End Sub

    Friend Sub Decoder_CloseAll()
        If REC IsNot Nothing Then
            REC.InputOff()
        End If
    End Sub

    Private Sub DataArrived(ByRef data() As Int16)
        Select Case DecoderType

            Case DecoderTypes.MorseCode
                DecoderMorse_DataArrived(data)

            Case DecoderTypes.EncodedRC
                Decoder5026_DataArrived(data)

            Case DecoderTypes.Meteo

        End Select
    End Sub

End Module
