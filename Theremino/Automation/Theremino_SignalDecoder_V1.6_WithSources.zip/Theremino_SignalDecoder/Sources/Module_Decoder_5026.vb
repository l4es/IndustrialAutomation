﻿Module Decoder_5026

    Private OldOut As Single
    Private Sample As SignalSample
    Private SignalInverted As Boolean
    Private EnvelopeSpeed As Single
    Private FilterSpeed As Single
    Private TrigLevel As Single
    Private Count1 As Single
    Private Count2 As Single
    Private NumBits As Int32

    Friend Sub Decoder5026_SetParams(ByVal _SignalInverted As Boolean, _
                                       ByVal _EnvelopeSpeed As Int32, _
                                       ByVal _FilterSpeed As Int32, _
                                       ByVal _TrigLevel As Int32, _
                                       ByVal _Count1 As Int32, _
                                       ByVal _Count2 As Int32, _
                                       ByVal _NumBits As Int32)
        SignalInverted = _SignalInverted
        EnvelopeSpeed = 1 - _EnvelopeSpeed / 100000.0F
        FilterSpeed = _FilterSpeed / 100.0F
        TrigLevel = _TrigLevel / 100.0F
        Count1 = _Count1
        Count2 = _Count2
        NumBits = _NumBits
    End Sub

    Friend Sub Decoder5026_DataArrived(ByRef data() As Int16)
        For i As Int32 = 0 To data.Length - 1
            Normalize(data(i))
            Decode()
            ' -------------------------------- add to FIFO for Scope Visualizer 
            FIFO.AddElement(Sample)
        Next
    End Sub

    Private Sub Normalize(ByVal data As Short)
        If SignalInverted Then
            sample.Sig1 = -data / 32768.0F
        Else
            sample.Sig1 = data / 32768.0F
        End If
    End Sub

    Private Sub Decode()
        With Sample
            ' ------------------------------------------------- min
            If .Sig1 < .Sig2 Then .Sig2 = .Sig1
            If .Sig2 < -0.000001 Then .Sig2 *= EnvelopeSpeed
            ' ------------------------------------------------- max
            If .Sig1 > .Sig3 Then .Sig3 = .Sig1
            If .Sig3 > 0.000001 Then .Sig3 *= EnvelopeSpeed
            ' ------------------------------------------------- update triglevel
            .triglevel = (.Sig3 - .Sig2) * TrigLevel
            ' ------------------------------------------------- update filtered value
            .delta = .Sig1 - .Sig4
            .Sig4 += .delta * FilterSpeed
            ' ------------------------------------------------- update out
            If .delta > .triglevel Then .Sig5 = 1
            If .delta < -.triglevel Then .Sig5 = -1
            ' -------------------------------------------------
            .Sig6 += Math.Sign(.Sig5)
            ' ------------------------------------------------- without a transition do nothing
            If .Sig5 = OldOut Then Return
            OldOut = .Sig5
            ' -------------------------------------------------
            If Math.Abs(.Sig6) > Count2 Then
                If .Sig7 = NumBits Then
                    DecodedBits = CodeToString(.bits)
                End If
                .Sig7 = 0
                .bits = 0
            End If
            ' -------------------------------------------------
            If .Sig7 > NumBits Then
                DecodedBits = ""
            End If
            ' -------------------------------------------------
            If .Sig5 < 0 Then
                ' ---------------------------------------------
                .bits = .bits << 1
                If .Sig6 > Count1 Then .bits += 1UI
                .Sig7 += 1
            End If
            .Sig6 = 0
        End With
    End Sub

    Private Function CodeToString(ByVal b As UInt32) As String
        Const BinaryFormat As Int32 = 2
        Return Convert.ToString(b, BinaryFormat).PadLeft(NumBits, "0"c)
    End Function

End Module
