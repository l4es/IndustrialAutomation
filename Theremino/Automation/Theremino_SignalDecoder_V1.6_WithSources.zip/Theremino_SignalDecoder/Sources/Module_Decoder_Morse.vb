﻿
Module Decoder_Morse

    ' -----------------------------------------
    ' Morse code timings
    ' -----------------------------------------
    ' Dash length              = Dot length x 3
    ' Pause between elements   = Dot length
    ' Pause between characters = Dot length x 3
    ' Pause between words      = Dot length x 7

    ' -----------------------------------------
    ' Dot Time      Speed       Speed  
    '               (Paris)     (Codex)    
    ' -----------------------------------------
    ' 250 mS          5 WPM
    ' 100 mS         12 WPM
    '  50 mS         24 WPM     20 WPM
    '  45 mS         27 WPM
    '  40 mS         30 WPM
    '  25 mS         34 WPM
    '  30 mS         40 WPM
    '  25 mS         48 WPM
    '  20 mS         60 WPM
    '  15 mS         80 WPM
    '  10 mS        120 WPM
    '   5 mS        240 WPM

    ' tested
    ' 40 WPM = 26 to 35 mS  (30)
    ' 25 WPM = 35 to 56 mS  (48)


    ' ==============================================================================
    '  Decode MORSE
    ' ==============================================================================
    Private sample As SignalSample
    Private SignalInverted As Boolean
    Private FilterSpeed As Single
    Private MinMaxSpeed As Single
    Private DotTime As Single = 30

    Friend Sub DecoderMorse_SetParams(ByVal _SignalInverted As Boolean, _
                                      ByVal _MinMaxSpeed As Int32, _
                                      ByVal _FilterSpeed As Int32, _
                                      ByVal _DotTime As Int32)
        SignalInverted = _SignalInverted
        MinMaxSpeed = _MinMaxSpeed
        FilterSpeed = _FilterSpeed / 100.0F
        DotTime = _DotTime
    End Sub

    Friend Sub DecoderMorse_DataArrived(ByRef data() As Int16)
        For i As Int32 = 0 To data.Length - 1
            Normalize(data(i))
            Decode()
            ' ---------------------------------- add to FIFO for Scope Visualizer 
            FIFO.AddElement(sample)
        Next
    End Sub

    Private Sub Normalize(ByVal data As Short)
        If SignalInverted Then
            sample.Sig1 = data / -32768.0F
        Else
            sample.Sig1 = data / 32768.0F
        End If
    End Sub

    Private Sub Decode()
        With sample
            Ticks += 1
            ' ------------------------------------------------- update filtered value
            .delta = (Math.Abs(.Sig1)) - .Sig4
            .Sig4 += .delta * FilterSpeed * 0.01F
            ' ------------------------------------------------- min
            If .Sig4 < .Sig2 Then .Sig2 = .Sig4
            If .Sig3 > .Sig2 + 0.000001 Then .Sig3 -= MinMaxSpeed * 0.00000001F
            ' ------------------------------------------------- max
            If .Sig4 > .Sig3 Then .Sig3 = .Sig4
            If .Sig2 < .Sig3 - 0.000001 Then .Sig2 += MinMaxSpeed * 0.00000001F
            ' ------------------------------------------------- update triglevel
            .triglevel = (.Sig3 + .Sig2) / 2
            ' ------------------------------------------------- 
            If .Sig4 > .triglevel AndAlso .Sig4 > 0.001 Then
                If .Sig5 = 0 Then .Sig5 = 1 : StatusChanged(sample)
            Else
                If .Sig5 = 1 Then .Sig5 = 0 : StatusChanged(sample)
            End If
        End With
    End Sub

    Private Ticks As Int32
    Private LetterString As String = ""
    Private Sub StatusChanged(ByRef sample As SignalSample)
        ' ----------------------------------------- 
        Dim t As Double = Ticks * 1000D / 44100
        Ticks = 0
        ' -----------------------------------------
        If sample.Sig5 = 1 Then
            If t > DotTime * 4 Then
                ' --------------------------------- End of word
                AddText(Morse_Decode(LetterString))
                LetterString = ""
                AddText(" ")
            ElseIf t > DotTime * 1.7 Then ' 1.7
                ' --------------------------------- End of letter
                AddText(Morse_Decode(LetterString))
                LetterString = ""
            Else
                'Beep()
            End If
        Else
            If t > DotTime * 1.7 Then
                ' --------------------------------- End of line
                'AddText("-")
                LetterString += "-"
            ElseIf t > DotTime * 0.2 Then
                ' --------------------------------- End of dot
                'AddText(".")
                LetterString += "."
            Else
                'AddText(",")
                'Beep()
            End If
        End If
    End Sub

    Private Sub AddText(ByVal s As String)
        DecodedBits += s
        sample.text = s
    End Sub

End Module
