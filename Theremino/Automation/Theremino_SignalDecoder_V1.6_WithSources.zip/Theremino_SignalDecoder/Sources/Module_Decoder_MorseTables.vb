﻿
Module Decoder_MorseTables

    'QRA  Callsign of station
    'QRG  station frequency
    'QRK   readability on a scale of 1 to 5
    'QRM  interference on a scale of 1 to 5
    'QRN  impulsive interference on a scale of 1 to 5
    'QRO  higher power
    'QRP  lower power
    'QRQ  please send faster
    'QRS  please send slower
    'QRT  close down
    'QRX  please call me again
    'QRZ  please repeat your callsign
    'QSB  signal fading
    'QSL  acknowledgement of message receipt
    'QSO  a communication
    'QSY  change frequency
    'QTH  station location

    Friend Function Q_Decode(ByVal qCode As String) As String
        Select Case qCode
            Case "QRQ?" : Return "Shall I send faster?"
            Case "QRQ" : Return "Send faster"
            Case "QRS?" : Return "Shall I send slower?"
            Case "QRS" : Return "Send slower"
            Case "QRT?" : Return "Shall I stop sending?"
            Case "QRT" : Return "Stop sending"
            Case "QRV?" : Return "Are you ready?"
            Case "QRV" : Return "I am ready"
            Case Else : Return ""
        End Select
    End Function

    Friend Function Morse_Decode(ByVal pattern As String) As String
        Select Case pattern
            Case ".-" : Return "A"
            Case "-..." : Return "B"
            Case "-.-." : Return "C"
            Case "-.." : Return "D"
            Case "." : Return "E"
            Case "..-." : Return "F"
            Case "--." : Return "G"
            Case "...." : Return "H"
            Case ".." : Return "I"
            Case ".---" : Return "J"
            Case "-.-" : Return "K"
            Case ".-.." : Return "L"
            Case "--" : Return "M"
            Case "-." : Return "N"
            Case "---" : Return "O"
            Case ".--." : Return "P"
            Case "--.-" : Return "Q"
            Case ".-." : Return "R"
            Case "..." : Return "S"
            Case "-" : Return "T"
            Case "..-" : Return "U"
            Case "...-" : Return "V"
            Case ".--" : Return "W"
            Case "-..-" : Return "X"
            Case "-.--" : Return "Y"
            Case "--.." : Return "Z"

            Case "-----" : Return "0"
            Case ".----" : Return "1"
            Case "..---" : Return "2"
            Case "...--" : Return "3"
            Case "....-" : Return "4"
            Case "....." : Return "5"
            Case "-...." : Return "6"
            Case "--..." : Return "7"
            Case "---.." : Return "8"
            Case "----." : Return "9"

            Case ".-.-.-" : Return "."
            Case "--..--" : Return ","
            Case "---..." : Return ":"
            Case "-.-.-." : Return ";"
            Case "..--.." : Return "?"
            Case ".----." : Return "'"
            Case "-.-.--" : Return "!"
            Case ".-..." : Return "&"
            Case "...-..-" : Return "$"
            Case ".--.-." : Return "@"
            Case "-..-." : Return "/"
            Case "..--.-" : Return "_"
            Case ".-.-." : Return "+"
            Case "-...-" : Return "="

            Case "...-." : Return "S^" 'S with ^
            Case "..-.." : Return "E'" 'E with rigt accent
            Case "..--" : Return "U''" 'U with two points
            Case "..--." : Return "-D" 'D left cutted
            Case ".-..-" : Return "E'" 'E with left accent
            Case ".-..-." : Return """" 'double quote
            Case ".-.-" : Return "A''" 'A with two points
            Case ".--.." : Return "b" 'strange b symbol
            Case ".--.-" : Return "A'" 'A with left accent
            Case ".----." : Return "J^" 'J with ^
            Case "-.-.." : Return "C," 'C with cediglia
            Case "-.-.-" : Return " " 'space
            Case "-.--." : Return "H^" 'H with ^
            Case "-.--.-" : Return "()"
            Case "--..-" : Return " " 'space
            Case "--.-." : Return "G^" 'G with ^
            Case "--.--" : Return "N''" 'N with two points
            Case "---." : Return "O''" 'O with two points
            Case "----" : Return "CH"

            Case "--.-...." : Return "QH" ' "G6"
            Case "..-.-." : Return "UR" ' "IC"

                'Case Else : Return "?"c
            Case Else : Return "|" + pattern + "|"
        End Select
    End Function

    Friend Function Morse_Encode(ByVal c As String) As String
        Select Case c.ToLower
            Case "a" : Return ".-"
            Case "b" : Return "-..."
            Case "" : Return "-.-."
            Case "d" : Return "-.."
            Case "e" : Return "."
            Case "f" : Return "..-."
            Case "g" : Return "--."
            Case "h" : Return "...."
            Case "i" : Return ".."
            Case "j" : Return ".---"
            Case "k" : Return "-.-"
            Case "l" : Return ".-.."
            Case "m" : Return "--"
            Case "n" : Return "-."
            Case "o" : Return "---"
            Case "p" : Return ".--."
            Case "q" : Return "--.-"
            Case "r" : Return ".-."
            Case "s" : Return "..."
            Case "t" : Return "-"
            Case "u" : Return "..-"
            Case "v" : Return "...-"
            Case "w" : Return ".--"
            Case "x" : Return "-..-"
            Case "y" : Return "-.--"
            Case "z" : Return "--.."

            Case "0" : Return "-----"
            Case "1" : Return ".----"
            Case "2" : Return "..---"
            Case "3" : Return "...--"
            Case "4" : Return "....-"
            Case "5" : Return "....."
            Case "6" : Return "-...."
            Case "7" : Return "--..."
            Case "8" : Return "---.."
            Case "9" : Return "----."

            Case "." : Return ".-.-.-"
            Case "," : Return "--..--"
            Case ":" : Return "---..."
            Case ";" : Return "-.-.-."
            Case "?" : Return "..--.."
            Case "'" : Return ".----."
            Case "!" : Return "-.-.--"
            Case "&" : Return ".-..."
            Case "$" : Return "...-..-"
            Case "@" : Return ".--.-."
            Case "/" : Return "-..-."
            Case "_" : Return "..--.-"
            Case "+" : Return ".-.-."
            Case "=" : Return "-...-"

            Case Else : Return ""
        End Select
    End Function


End Module
