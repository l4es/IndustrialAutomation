﻿
Module SaveLoad

    Friend EventsAreEnabled As Boolean = False

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function


    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function

    Friend Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function

    Friend Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function

    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function

    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function

    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function

    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function

    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Int32
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function

    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function



    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub SaveConfigurationAs()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        sfd.InitialDirectory = Application.StartupPath + "\Configurations"
        sfd.AddExtension = True
        sfd.DefaultExt = ".txt"
        sfd.Filter = "Configuration file (*.txt)|*txt"
        sfd.FileName = "Configuration_" & Form1.cmb_SignalType.Text
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Save_INI(sfd.FileName)
        End If
    End Sub

    Friend Sub LoadConfiguration()
        Dim ofd As OpenFileDialog = New OpenFileDialog
        ofd.AutoUpgradeEnabled = True
        ofd.Multiselect = True
        ofd.InitialDirectory = Application.StartupPath + "\Configurations"
        ofd.Filter = "Configuration file (*.txt)|*txt"
        ofd.DefaultExt = ".txt"
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Load_INI(ofd.FileName)
        End If
    End Sub


    Friend Sub Save_INI(ByVal filename As String)
        '
        Dim SaveWindowPosition As Boolean = False
        If filename = "" Then
            filename = Application.StartupPath & "\Configurations\Last_configuration.txt"
            SaveWindowPosition = True
        End If
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(filename)
            '
            If SaveWindowPosition Then
                f.WriteLine(" Application params")
                f.WriteLine("===========================================")
                Dim r As Rectangle
                r = GetFormRectangle(Form1)
                f.WriteLine(TabString("Form1_Top", r.Top))
                f.WriteLine(TabString("Form1_Left", r.Left))
                f.WriteLine(TabString("Form1_Width", r.Width))
                f.WriteLine(TabString("Form1_Height", r.Height))
                f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            End If
            '
            f.WriteLine("")
            f.WriteLine(" Decode params")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("SelectedAudioIn", Form1.SelectedAudioIn))

            f.WriteLine(TabString("ScopeVoltage", Form1.tbar_ScopeVoltage.Value))
            f.WriteLine(TabString("ScopePosition", Form1.tbar_ScopePosition.Value))
            f.WriteLine(TabString("ScopeTime", Form1.tbar_ScopeTime.Value))
            '
            f.WriteLine(TabString("SignalInverted", Form1.chk_SignalInverted.Checked.ToString))
            f.WriteLine(TabString("Sync", Form1.chk_Sync.Checked.ToString))
            f.WriteLine(TabString("Sig1", Form1.chk_Sig1.Checked.ToString))
            f.WriteLine(TabString("Sig2", Form1.chk_Sig2.Checked.ToString))
            f.WriteLine(TabString("Sig3", Form1.chk_Sig3.Checked.ToString))
            f.WriteLine(TabString("Sig4", Form1.chk_Sig4.Checked.ToString))
            f.WriteLine(TabString("Sig5", Form1.chk_Sig5.Checked.ToString))
            f.WriteLine(TabString("Sig6", Form1.chk_Sig6.Checked.ToString))
            f.WriteLine(TabString("Sig7", Form1.chk_Sig7.Checked.ToString))
            '
            f.WriteLine(TabString("Trim1", Form1.txt_Trim1.NumericValueInteger))
            f.WriteLine(TabString("Trim2", Form1.txt_Trim2.NumericValueInteger))
            f.WriteLine(TabString("Trim3", Form1.txt_Trim3.NumericValueInteger))
            f.WriteLine(TabString("Trim4", Form1.txt_Trim4.NumericValueInteger))
            f.WriteLine(TabString("Trim5", Form1.txt_Trim5.NumericValueInteger))
            f.WriteLine(TabString("Trim6", Form1.txt_Trim6.NumericValueInteger))
            '
            f.WriteLine(TabString("SignalType", Form1.cmb_SignalType.SelectedIndex))
            '
            f.WriteLine("")
            f.WriteLine(" Output params")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("BitMask", Form1.txt_BitMask.Text))
            f.WriteLine(TabString("MultipleSlots", Form1.chk_MultipleSlots.Checked.ToString))
            f.WriteLine(TabString("FirstSlot", Form1.txt_FirstSlot.NumericValueInteger))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI(ByVal filename As String)
        ' ------------------------------------------------------------- defaults
        '
        ' -------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l, l2 As String
        Dim LoadWindowPosition As Boolean = False
        If filename = "" Then
            filename = Application.StartupPath & "\Configurations\Last_configuration.txt"
            LoadWindowPosition = True
        End If
        If My.Computer.FileSystem.FileExists(filename) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(filename)

            Do While Not f.EndOfStream
                l = f.ReadLine()
                l2 = ExtractParamName(l)
                If LoadWindowPosition Then
                    Select Case l2
                        Case "Form1_Top" : Form1.Top = Val_Int(l)
                        Case "Form1_Left" : Form1.Left = Val_Int(l)
                        Case "Form1_Width" : Form1.Width = Val_Int(l)
                        Case "Form1_Height" : Form1.Height = Val_Int(l)
                        Case "Form1_WindowState" : Form1.WindowState = CType((Val(l)), FormWindowState)
                    End Select
                End If
                Select Case l2
                    ' ----------------------------------------------------------------- params
                    Case "SelectedAudioIn" : Form1.SelectedAudioIn = Val_Int(l)

                    Case "ScopeVoltage" : Form1.tbar_ScopeVoltage.Value = Val_Int(l)
                    Case "ScopePosition" : Form1.tbar_ScopePosition.Value = Val_Int(l)
                    Case "ScopeTime" : Form1.tbar_ScopeTime.Value = Val_Int(l)
                        '
                    Case "SignalInverted" : Form1.chk_SignalInverted.Checked = l = "True"
                    Case "Sync" : Form1.chk_Sync.Checked = l = "True"
                    Case "Sig1" : Form1.chk_Sig1.Checked = l = "True"
                    Case "Sig2" : Form1.chk_Sig2.Checked = l = "True"
                    Case "Sig3" : Form1.chk_Sig3.Checked = l = "True"
                    Case "Sig4" : Form1.chk_Sig4.Checked = l = "True"
                    Case "Sig5" : Form1.chk_Sig5.Checked = l = "True"
                    Case "Sig6" : Form1.chk_Sig6.Checked = l = "True"
                    Case "Sig7" : Form1.chk_Sig7.Checked = l = "True"
                        '
                    Case "Trim1" : Form1.txt_Trim1.NumericValueInteger = Val_Int(l)
                    Case "Trim2" : Form1.txt_Trim2.NumericValueInteger = Val_Int(l)
                    Case "Trim3" : Form1.txt_Trim3.NumericValueInteger = Val_Int(l)
                    Case "Trim4" : Form1.txt_Trim4.NumericValueInteger = Val_Int(l)
                    Case "Trim5" : Form1.txt_Trim5.NumericValueInteger = Val_Int(l)
                    Case "Trim6" : Form1.txt_Trim6.NumericValueInteger = Val_Int(l)
                        '
                    Case "SignalType" : Form1.cmb_SignalType.SelectedIndex = Val_Int(l)
                        '
                    Case "BitMask" : Form1.txt_BitMask.Text = l
                    Case "MultipleSlots" : Form1.chk_MultipleSlots.Checked = l = "True"
                    Case "FirstSlot" : Form1.txt_FirstSlot.NumericValueInteger = Val_Int(l)
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
    End Sub

End Module
