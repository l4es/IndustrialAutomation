﻿
Module Scope

    Private m_mvDiv As Single = 500
    Private m_Position As Single = 0
    Private m_msDiv As Single = 100
    Private m_Sync As Boolean = False

    Private m_Sig1 As Boolean = True
    Private m_Sig2 As Boolean = True
    Private m_Sig3 As Boolean = True
    Private m_Sig4 As Boolean = True
    Private m_Sig5 As Boolean = True
    Private m_Sig6 As Boolean = True
    Private m_Sig7 As Boolean = True

    Private m_DecoderType As DecoderTypes

    Private textFont As Font = New Font("Tahoma", 8)
    Private textFont2 As Font = New Font("Tahoma", 16)
    Private BackColor As Color = Color.FromArgb(30, 90, 120)
    Private scalePen As Pen = New Pen(Color.FromArgb(45, 58, 70))
    Private tracePen As Pen = New Pen(Color.FromArgb(240, 255, 255))

    Friend Sub SetVoltage(ByVal mvDiv As Single)
        m_mvDiv = mvDiv
    End Sub
    Friend Sub SetTime(ByVal msDiv As Single)
        m_msDiv = msDiv
    End Sub
    Friend Sub SetPosition(ByVal position As Single)
        m_Position = position
    End Sub
    Friend Sub SetSync(ByVal sync As Boolean)
        m_Sync = sync
    End Sub
    Friend Sub SetSignalType(ByVal DecoderType As DecoderTypes)
        m_DecoderType = DecoderType
    End Sub
    Friend Sub SetSignals(ByVal s1 As Boolean, _
                          ByVal s2 As Boolean, _
                          ByVal s3 As Boolean, _
                          ByVal s4 As Boolean, _
                          ByVal s5 As Boolean, _
                          ByVal s6 As Boolean, _
                          ByVal s7 As Boolean)
        m_Sig1 = s1
        m_Sig2 = s2
        m_Sig3 = s3
        m_Sig4 = s4
        m_Sig5 = s5
        m_Sig6 = s6
        m_Sig7 = s7
    End Sub

    Friend Sub Update(ByVal pbox As PictureBox, _
                      ByVal neg As Boolean)

        'Dim sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch : sw1.Start()
        ' ----------------------------------------------------------------- 
        InitPictureboxImage(pbox)
        If pbox.Image Is Nothing Then Return
        ' ----------------------------------------------------------------- 
        Dim i As Int32
        Dim x As Single
        Dim oldx As Int32
        Dim y1, y2, y3, y4, y4b, y5, y6, y7 As Single
        Dim oldy1, oldy2, oldy3, oldy4, oldy4b, oldy5, oldy6, oldy7 As Single
        Dim oldbitcounter As Int32
        Dim h As Int32 = pbox.Image.Height
        Dim w As Int32 = pbox.Image.Width
        Dim h2 As Single = h / 2.0F
        Dim kmv As Single = h * 1000.0F / 8.0F / m_mvDiv
        Dim k200 As Single = h / 8.0F
        Dim kw As Single = SampleFreq / 100.0F * m_msDiv / w
        Dim preTrigSamples As Int32
        Dim FifoReadIndex As Int32
        Dim sample As SignalSample
        Dim v As Single
        Dim oldv As Single
        ' ----------------------------------------------------------------- 
        Dim g As Graphics = Graphics.FromImage(pbox.Image)
        g.Clear(BackColor)
        ' ----------------------------------------------------------------- draw scale
        For i = 0 To 9
            x = w * i \ 10
            g.DrawLine(scalePen, x, 0, x, h)
        Next
        For i = 0 To 7
            y1 = h * i \ 8
            g.DrawLine(scalePen, 0, y1, w, y1)
        Next
        ' ----------------------------------------------------------------- prepare the FIFO read position
        preTrigSamples = Math.Max(CInt(kw * w * 10), SampleFreq \ 4)
        FifoReadIndex = CInt(FIFO.GetWriteIndex - preTrigSamples)
        Dim trigpos As Int32 = 0

        Select Case m_DecoderType
            Case DecoderTypes.MorseCode
                'For ix As Int32 = 0 To preTrigSamples \ 2
                '    sample = FIFO.GetElement(FifoReadIndex + ix)
                '    If sample.text <> "" Then
                '        Static ot As String
                '        If sample.text <> ot Then
                '            ot = sample.text
                '            trigpos = ix - CInt(w * kw * 0.11F)
                '        End If
                '    End If
                'Next

                For ix As Int32 = 0 To preTrigSamples \ 2
                    sample = FIFO.GetElement(FifoReadIndex + ix)
                    v = sample.Sig5
                    If v <> 1 And oldv = 0 Then
                        trigpos = ix - CInt(w * kw * 0.11F)
                    End If
                    oldv = v
                Next


            Case DecoderTypes.EncodedRC
                ' ----------------------------------------------------------------- adaptive trigger
                'Static TrigMin As Single
                'Static TrigMax As Single
                'Dim min As Single = 1
                'Dim max As Single = -1
                'Dim TrigState As Int32 = 0
                'For ix As Int32 = 0 To preTrigSamples \ 2
                '    sample = FIFO.GetElement(FifoReadIndex + ix)
                '    v = sample.value
                '    If TrigState = 0 AndAlso v > TrigMax Then TrigState = 1
                '    If TrigState = 1 AndAlso v < TrigMin Then TrigState = 2
                '    If TrigState = 2 AndAlso v > TrigMax / 10 Then
                '        TrigState = -1
                '        trigpos = ix - CInt(w * kw * 0.11F)
                '    End If
                '    If v > max Then max = v
                '    If v < min Then min = v
                'Next
                'TrigMin = min * 0.9F
                'TrigMax = max * 0.9F
                ' ----------------------------------------------------------------- trigger on silence

                'preTrigSamples = CInt(kw * w * 10)
                'FifoReadIndex = CInt(FIFO.GetWriteIndex - preTrigSamples)


                'For ix As Int32 = 0 To preTrigSamples \ 2
                '    sample = FIFO.GetElement(FifoReadIndex + ix)
                '    v = Math.Abs(sample.Sig6)
                '    If oldv > 500 And oldv < 1500 And v = 0 Then
                '        trigpos = ix - CInt(w * kw * 0.11F)
                '    End If
                '    oldv = v
                'Next
                ' ----------------------------------------------------------------- trigger on silence
                'Dim oldv As Single
                For ix As Int32 = preTrigSamples \ 2 To 0 Step -1
                    sample = FIFO.GetElement(FifoReadIndex + ix)
                    v = Math.Abs(sample.Sig6)
                    If v > 200 And oldv = 0 Then
                        trigpos = ix - CInt(w * kw * 0.11F)
                    End If
                    oldv = v
                Next

            Case DecoderTypes.Meteo
        End Select


        If m_Sync AndAlso trigpos = 0 Then Return

        ' ----------------------------------------------------------------- position
        trigpos += CInt(m_Position * SampleFreq / 10000.0F)

        ' ----------------------------------------------------------------- scope
        g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        oldx = -1
        For ix As Int32 = 0 To w - 1
            sample = FIFO.GetElement(FifoReadIndex + CInt(ix * kw + trigpos))
            v = sample.Sig1
            ' -------------------------------------------------------------
            y1 = h2 - kmv * v
            y2 = h2 - kmv * sample.Sig2
            y3 = h2 - kmv * sample.Sig3
            y4 = h2 - kmv * sample.Sig4
            y4b = h2 - kmv * sample.triglevel
            y5 = h2 - k200 * sample.Sig5
            y6 = h2 - k200 * sample.Sig6 / 500
            y7 = h2 - k200 * sample.Sig7 / 10
            ' -------------------------------------------------------------
            If oldx >= 0 Then
                If m_Sig1 Then
                    g.DrawLine(tracePen, oldx, oldy1, ix, y1)
                    'g.DrawLine(tracePen, ix + 2, y, ix + 3, y)
                End If
                If m_Sig2 Then
                    g.DrawLine(Pens.Orange, oldx, oldy2, ix, y2)
                End If
                If m_Sig3 Then
                    g.DrawLine(Pens.Orange, oldx, oldy3, ix, y3)
                End If
                If m_Sig4 Then
                    g.DrawLine(Pens.Yellow, oldx, oldy4, ix, y4)
                    g.DrawLine(Pens.Yellow, oldx, oldy4b, ix, y4b)
                End If
                If m_Sig5 Then
                    g.DrawLine(Pens.LightGreen, oldx, oldy5, ix, y5)
                End If
                If m_Sig6 Then
                    g.DrawLine(Pens.LightBlue, oldx, oldy6, ix, y6)
                End If
                If m_Sig7 Then
                    Select Case m_DecoderType
                        Case DecoderTypes.MorseCode
                            If sample.text <> "" Then
                                Static oldt As String
                                If sample.text <> oldt Then
                                    oldt = sample.text
                                    g.DrawString(sample.text, textFont, Brushes.Azure, ix - 30, y7 - 16)
                                End If
                            End If
                        Case DecoderTypes.EncodedRC
                            g.DrawLine(Pens.Orange, oldx, oldy7, ix, y7)
                            If sample.Sig7 <> oldbitcounter Then
                                g.DrawString(sample.Sig7.ToString(), textFont, Brushes.Azure, ix, y7 - 16)
                            End If
                    End Select
                End If
            End If
            oldx = ix
            oldy1 = y1
            oldy2 = y2
            oldy3 = y3
            oldy4 = y4
            oldy4b = y4b
            oldy5 = y5
            oldy6 = y6
            oldy7 = y7
            oldbitcounter = sample.Sig7
        Next
        ' ----------------------------------------------------------------- text
        g.DrawString(m_mvDiv.ToString() & " mV", textFont, Brushes.Azure, 5, h - 20)
        If m_msDiv >= 1 Then
            g.DrawString(m_msDiv.ToString() & " mS", textFont, Brushes.Azure, w - 46, h - 20)
        Else
            g.DrawString((m_msDiv * 1000).ToString() & " uS", textFont, Brushes.Azure, w - 45, h - 20)
        End If
        ' ----------------------------------------------------------------- 
        'Const BinaryFormat As Int32 = 2
        'Dim s As String = Convert.ToString(DecodedBits, BinaryFormat).PadLeft(18, "0"c)
        'g.DrawString(s, textFont2, Brushes.Azure, 5, 5)
        ' ----------------------------------------------------------------- show
        pbox.Invalidate()
        'ReportString = "Scope time: " & (sw1.Elapsed.TotalMilliseconds * 1000).ToString("0") & " uS"
    End Sub

End Module

