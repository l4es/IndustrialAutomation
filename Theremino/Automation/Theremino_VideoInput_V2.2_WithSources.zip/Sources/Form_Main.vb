﻿
Public Class Form_Main

    Private Sub Form_Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' ----------------------------------------------------------------
        Me.Text = AppTitleAndVersion()
        '
        Load_INI()
        EventsAreEnabled = True
        ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        '
        ' ---------------------------------------------------------------- CAPTURE
        Capture_INIT(VideoInDevice)
        If VideoCaptureDevice_Is_VFW() Then
            Capture_ConnectFiltersAndRun()
        Else
            Capture_SetVideoFormatParams()
        End If
        '
        ' ---------------------------------------------------------------- DOCK
        If Form_VideoInControls_VisibleAtStart Then
            Form_VideoInControls.Show(Me)
        Else
            Form_VideoInControls.Show(Me)
            Form_VideoInControls.Visible = False
        End If
        DockAllWindows()
        ' ----------------------------------------------------------------
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        '
        ' ---------------------------------------------------------------- Main Timer
        Timer1.Interval = 1000 \ txt_DetectorMaxFps.NumericValueInteger
        Timer1.Start()
        ' ----------------------------------------------------------------
        SetDefaultFocus()
        EventsAreEnabled = True
        ' ---------------------------------------------------------------- SHOW
        Refresh()
        Forms_FadeTo(1, 400)
        '
        ' ----------------------------------- test - divide by zero
        'Dim a As Int32 = 0 : a = 7 \ a
        ' ----------------------------------------------------------------
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Return
        CloseProgram()
    End Sub

    Private Sub CloseProgram()
        Save_INI()
        EventsAreEnabled = False
        Forms_FadeTo(0, 500)
        Me.Refresh()
        Timer1.Stop()
        Capture_STOP()
        Form_VideoInControls.Close()
        Me.Close()
    End Sub

    Private Sub Form_Main_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub

    Private Sub Form_Main_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        DockAllWindows()
    End Sub

    Private Sub Form_Main_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        DockAllWindows()
    End Sub

    Private Sub SetDefaultFocus()
        Label_FramesPerSec.Focus()
    End Sub

    Friend Sub PictureBox1_Clear()
        PictureBox1.Image = PictureBox1.InitialImage
    End Sub
    Friend Sub PictureBox2_Clear()
        PictureBox2.Image = PictureBox2.InitialImage
    End Sub

    Friend Sub DockAllWindows()
        Form_VideoInControls.SetSnap()
    End Sub

    Private Sub OpenCloseFormVideoInControls()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.Visible = False
        Else
            Form_VideoInControls.Visible = True
            Me.Focus()
        End If
        DockAllWindows()
    End Sub


    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(230, 230, 230), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer
        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub



    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Exit.Click
        CloseProgram()
    End Sub

    ' =======================================================================================
    '   MENU TOOLS
    ' =======================================================================================
    Private Sub Menu_VideoinControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_VideoinControls.Click
        OpenCloseFormVideoInControls()
    End Sub
    Private Sub Menu_OpenDirectShowGraph_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_OpenDirectShowGraph.Click
        OpenDirectShowGraph()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_ENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp_ENG.Click
        Language = "ENG"
        OpenLocalizedHelp("Theremino_VideoInput", ".pdf")
    End Sub
    Private Sub Menu_Help_ProgramHelp_ITA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp_ITA.Click
        Language = "ITA"
        OpenLocalizedHelp("Theremino_VideoInput", ".pdf")
    End Sub
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.Show()
    End Sub

    ' =======================================================================================
    '   TOOLSTRIP
    ' =======================================================================================
    Private Sub Tool_VideoInControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_VideoInControls.Click
        OpenCloseFormVideoInControls()
    End Sub
    Private Sub Tool_DirectShowGraph_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tool_DirectShowGraph.Click
        OpenDirectShowGraph()
    End Sub
    Private Sub ToolButton_HelpEng_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolButton_HelpEng.Click
        Language = "ENG"
        OpenLocalizedHelp("Theremino_VideoInput", ".pdf")
    End Sub
    Private Sub ToolButton_HelpIta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolButton_HelpIta.Click
        Language = "ITA"
        OpenLocalizedHelp("Theremino_VideoInput", ".pdf")
    End Sub

    Dim Language As String
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")

        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & Strings.Left(Language, 3).ToUpper & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub






    ' ==============================================================================================================
    '   COMBO BOX - WEBCAM
    ' ==============================================================================================================
    Private Sub ComboBox_VideoInputDevice_InitWithCurrentDeviceName()
        Combo_Init(ComboBox_VideoInputDevice, VideoInDevice)
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDownClosed
        SetDefaultFocus()
    End Sub
    Private Sub ComboBox_VideoInputDevice_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.SelectedIndexChanged
        If Not EventsAreEnabled Then Exit Sub
        VideoInDevice = Combo_GetValue(ComboBox_VideoInputDevice)
        Timer1.Stop()
        Application.DoEvents()
        Capture_STOP()
        Application.DoEvents()
        Capture_INIT(VideoInDevice)
        Capture_ConnectFiltersAndRun()
        Timer1.Start()
        SetDefaultFocus()
        Save_INI()
        If Form_VideoInControls.Visible Then
            Form_VideoInControls.UpdateAllValues()
            Form_VideoInControls.Focus()
        End If
    End Sub
    Private Sub ComboBox_VideoInputDevice_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_VideoInputDevice.DropDown
        Dim fnames() As String
        fnames = EnumFiltersByCategory(FilterCategory.VideoInputDevice)
        With ComboBox_VideoInputDevice
            .Items.Clear()
            For Each fltName As String In fnames
                .Items.Add(fltName)
            Next
            Combo_SetIndex_FromString(ComboBox_VideoInputDevice, VideoInDevice)
        End With
    End Sub

    Private Sub btn_VideoInControls_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_VideoInControls.ClickButtonArea
        OpenCloseFormVideoInControls()
    End Sub

    Private Sub btn_Init_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Reinit.ClickButtonArea
        TriggerAreas_Reinit(image4, True)
    End Sub



    ' ==============================================================================================================
    '   AUTO SAVE FOR ALL PARAMS - USING LostFocus
    ' ==============================================================================================================
    Private Sub ImageCropParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_FlipX.LostFocus, _
                                                                                                       CheckBox_FlipY.LostFocus, _
                                                                                                       txt_Zoom.LostFocus, _
                                                                                                       txt_ShiftX.LostFocus, _
                                                                                                       txt_ShiftY.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub MotionDetectorParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton_Positive.LostFocus, _
                                                                                                            RadioButton_Negative.LostFocus, _
                                                                                                            RadioButton_Double.LostFocus, _
                                                                                                            CheckBox_GrayScale.LostFocus, _
                                                                                                            CheckBox_BlackOrWhite.LostFocus, _
                                                                                                            txt_DetectorShift.LostFocus, _
                                                                                                            txt_DetectorGain.LostFocus, _
                                                                                                            txt_DetectorRes.LostFocus, _
                                                                                                            txt_DelayStages.LostFocus, _
                                                                                                            txt_DetectorMaxFps.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub CommonParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_EnableImage1.LostFocus, _
                                                                                                    CheckBox_EnableImage2.LostFocus, _
                                                                                                    CheckBox_TrigShow1.LostFocus, _
                                                                                                    CheckBox_TrigShow2.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub
    Private Sub AreaParams_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
                                                                                            txt_UsedAreas.LostFocus, _
                                                                                            txt_FirstSlot.LostFocus
        If Not EventsAreEnabled Then Return
        Save_INI()
    End Sub

    Private Sub EnableDisableControls()
        Dim en As Boolean
        en = txt_ZoomQuality.NumericValueInteger > 0
        txt_Zoom.Enabled = en
        txt_ShiftX.Enabled = en
        txt_ShiftY.Enabled = en
    End Sub

    Private Sub txt_ZoomQuality_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_ZoomQuality.TextChanged
        EnableDisableControls()
    End Sub


    Private Sub txtLoopTime_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_DetectorMaxFps.TextChanged
        Timer1.Interval = 1000 \ txt_DetectorMaxFps.NumericValueInteger
    End Sub





    ' ==============================================================================================================
    '   MAIN LOOP TIMER
    ' ==============================================================================================================
    Private DelayImages(31) As Image
    Private image2 As Image
    Private image3 As Image
    Private image4 As Image

    Private Timer1_Working As Boolean = False
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not EventsAreEnabled Then Return
        '
        If Not Capture_NewImageIsReady Then
            If Capture_Image Is Nothing OrElse Capture_Image.PixelFormat = Imaging.PixelFormat.Undefined Then
                'PictureBox1.Image = CType(PictureBox1.InitialImage.Clone, Image)
                'PictureBox2.Image = PictureBox1.Image
                System.Threading.Thread.Sleep(10)
                Return
            End If
        End If
        ' ----------------------------------------------------------------------- 
        If Capture_Image Is Nothing Then
            Capture_NewImageIsReady = False
            Exit Sub
        End If
        '
        If Timer1_Working Then Exit Sub
        Timer1_Working = True

        If Capture_NewImageIsReady Then
            'Dim t As PrecisionTimer = New PrecisionTimer

            'If txt_Zoom.NumericValue = 1 And Capture_Image.Width = 320 Then
            If txt_ZoomQuality.NumericValueInteger = 0 Then
                image2 = Capture_Image
            Else
                image2 = ImageZoom(Capture_Image, _
                                   txt_Zoom.NumericValue, _
                                   txt_ShiftX.NumericValueInteger, _
                                   txt_ShiftY.NumericValueInteger, _
                                   320, 240, _
                                   txt_ZoomQuality.NumericValueInteger)
            End If

            ' ----------------------------------------------------------------------- FLIP X / Y
            If Not CheckBox_FlipY.Checked Then
                If CheckBox_FlipX.Checked Then
                    image2.RotateFlip(RotateFlipType.RotateNoneFlipXY)
                Else
                    image2.RotateFlip(RotateFlipType.RotateNoneFlipY)
                End If
            Else
                If CheckBox_FlipX.Checked Then
                    image2.RotateFlip(RotateFlipType.RotateNoneFlipX)
                Else
                    'Dim i As Object = image2.Clone
                    If txt_ZoomQuality.NumericValueInteger = 0 And txt_PreFilterQuality.NumericValueInteger = 0 Then
                        image2.RotateFlip(RotateFlipType.RotateNoneFlipY)
                        image2.RotateFlip(RotateFlipType.RotateNoneFlipY)
                    End If

                End If
            End If

            ' ----------------------------------------------------------------------- Show PictureBox1 image and info
            If CheckBox_EnableImage1.Checked Then
                PictureBox1.Image = image2
            End If

            If Capture_Image.PixelFormat <> Imaging.PixelFormat.Undefined Then
                Label_Resolution.Text = Capture_Image.Width.ToString & " x " & Capture_Image.Height.ToString
            End If
            Label_FramesPerSec.Text = Capture_FramesPerSecond.ToString("0") & " fps"

            ' ----------------------------------------------------------------------- Resize to low resolution
            'If image2.Width = txt_DetectorRes.NumericValueInteger Then
            If txt_PreFilterQuality.NumericValueInteger = 0 Then
                image3 = image2
            Else
                image3 = ImageResize(image2, _
                                     txt_DetectorRes.NumericValueInteger, _
                                     txt_DetectorRes.NumericValueInteger * 3 \ 4, _
                                     txt_PreFilterQuality.NumericValueInteger)
            End If

            ' ----------------------------------------------------------------------- MOTION DETECTION
            image4 = Image_DetectMotion(image3, _
                                        DelayImages(0), _
                                        txt_DetectorShift.NumericValueInteger, _
                                        txt_DetectorGain.NumericValueInteger, _
                                        CheckBox_GrayScale.Checked, _
                                        RadioButton_Negative.Checked, _
                                        RadioButton_Double.Checked, _
                                        CheckBox_BlackOrWhite.Checked)

            ' ----------------------------------------------------------------------- DELAY STAGES
            For i As Int32 = 0 To txt_DelayStages.NumericValueInteger - 2
                DelayImages(i) = DelayImages(i + 1)
                If DelayImages(i) Is Nothing Then DelayImages(i) = image3
            Next
            DelayImages(txt_DelayStages.NumericValueInteger - 1) = image3

            ' ----------------------------------------------------------------------- TRIGGER AREAS
            If PictureBox1.Image IsNot Nothing And image4 IsNot Nothing Then
                '
                If CheckBox_TrigShow1.Checked Or CheckBox_TrigShow2.Checked Then
                    TriggerAreas_TestImage(image4)
                End If
                If CheckBox_TrigShow1.Checked And CheckBox_EnableImage1.Checked Then
                    TriggerAreas_Show(PictureBox1.Image, PictureBox1.Image.Width / image4.Width)
                End If
                If CheckBox_TrigShow2.Checked And CheckBox_EnableImage2.Checked Then
                    TriggerAreas_Show(image4)
                End If
                '
                TriggerAreas_ResetTriggerFlags()
            End If

            ' ----------------------------------------------------------------------- Show PictureBox2 image
            If CheckBox_EnableImage2.Checked Then
                PictureBox2.Image = image4
            End If

            ' ----------------------------------------------------------------------- mark capture image as not-ready
            Capture_NewImageIsReady = False
        End If

        Timer1_Working = False
    End Sub



    ' ==============================================================================================================
    '   TRIGGER WITH MOUSE
    ' ==============================================================================================================
    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
        If CheckBox_TrigShow1.Checked Then
            Dim k As Double = PictureBox2.Image.Width / PictureBox1.Image.Width
            TriggerAreas_TriggerWithMouse(PictureBox1, e.Location, k)
        End If
    End Sub
    Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        If e.Button <> Windows.Forms.MouseButtons.None Then
            Dim k As Double = PictureBox2.Image.Width / PictureBox1.Image.Width
            If CheckBox_TrigShow1.Checked Then TriggerAreas_TriggerWithMouse(PictureBox1, e.Location, k)
        End If
    End Sub

    Private Sub PictureBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseDown
        If CheckBox_TrigShow2.Checked Then TriggerAreas_TriggerWithMouse(PictureBox2, e.Location)
    End Sub
    Private Sub PictureBox2_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseMove
        If e.Button <> Windows.Forms.MouseButtons.None Then
            If CheckBox_TrigShow2.Checked Then TriggerAreas_TriggerWithMouse(PictureBox2, e.Location)
        End If
    End Sub




    ' ==============================================================================================================
    '   QUALITY CONTROLS
    ' ==============================================================================================================
    Private Sub CheckBox_EnableImage1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_EnableImage1.CheckedChanged
        PictureBox1_Clear()
    End Sub
    Private Sub CheckBox_EnableImage2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_EnableImage2.CheckedChanged
        PictureBox2_Clear()
    End Sub


    ' ==============================================================================================================
    '   AREAS
    ' ==============================================================================================================

    Private Sub txt_FirstSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_FirstSlot.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        TriggerAreas_SetFirstSlot(txt_FirstSlot.NumericValueInteger)
    End Sub

    Private Sub txt_UsedAreas_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_UsedAreas.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        TriggerAreas_SetUsedAreas(txt_UsedAreas.NumericValueInteger)
    End Sub

    Private Sub txt_SelectedArea_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SelectedArea.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        TriggerAreas_SetSelectedArea(txt_SelectedArea.NumericValueInteger)
    End Sub


    Private Sub txt_AreaParams_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_AreaPosX.TextChanged, _
                                                                                                                  txt_AreaPosY.TextChanged, _
                                                                                                                  txt_AreaSizeX.TextChanged, _
                                                                                                                  txt_AreaSizeY.TextChanged

        If Not EventsAreEnabled Then Exit Sub
        TriggerAreas_SetSelectedAreaParams(txt_AreaPosX.NumericValueInteger, _
                                           txt_AreaPosY.NumericValueInteger, _
                                           txt_AreaSizeX.NumericValueInteger, _
                                           txt_AreaSizeY.NumericValueInteger)
    End Sub



End Class
