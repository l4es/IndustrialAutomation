﻿Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices

Module Module_TriggerAreas



    Friend Structure TrigArea
        Friend Rec As Rectangle
        Friend Triggered As Boolean
    End Structure

    Friend TrigAreas(MaxAreas - 1) As TrigArea

    Private SelectedArea As Int32 = 0

    Const MaxAreas As Int32 = 30
    Private UsedAreas As Int32 = 30
    Private FirstSlot As Int32 = 1

    Private PictureBoxWidth As Int32 = 320
    Private PictureBoxHeight As Int32 = 240

    Friend Sub TriggerAreas_Reinit(ByVal img As Image, ByVal PromptTheUser As Boolean)
        '
        If PromptTheUser Then
            If MsgBox("Do you really want to reinit all the areas ?", MsgBoxStyle.Question Or MsgBoxStyle.OkCancel) <> MsgBoxResult.Ok Then
                Exit Sub
            End If
        End If
        '
        UsedAreas = MaxAreas
        SelectedArea = 0
        '
        If img Is Nothing Then Exit Sub
        '
        Dim imgW As Int32 = img.Width
        Dim imgH As Int32 = img.Height
        '
        Dim areaX As Int32 = 0
        Dim areaY As Int32 = 0
        Dim areaW As Int32 = 49
        Dim areaH As Int32 = 44
        '
        For i As Int32 = 0 To UsedAreas - 1
            With TrigAreas(i)
                .Rec.X = areaX
                .Rec.Y = areaY
                .Rec.Width = areaW
                .Rec.Height = areaH

                areaX += CInt(areaW * 1.1)
                If areaX + areaW > imgW Then
                    areaX = 0
                    areaY += CInt(areaH * 1.1)
                End If
            End With
        Next
        '
        ShowAreaParams()
    End Sub

    Private Sub ShowAreaParams()
        EventsAreEnabled = False
        With Form_Main
            .txt_UsedAreas.NumericValueInteger = UsedAreas
            If SelectedArea >= 0 Then
                .txt_SelectedArea.NumericValueInteger = SelectedArea
                .lbl_SelectedSlot.Text = (SelectedArea + FirstSlot).ToString
                .txt_AreaPosX.NumericValueInteger = TrigAreas(SelectedArea).Rec.X
                .txt_AreaPosY.NumericValueInteger = PictureBoxHeight - TrigAreas(SelectedArea).Rec.Y
                .txt_AreaSizeX.NumericValueInteger = TrigAreas(SelectedArea).Rec.Width
                .txt_AreaSizeY.NumericValueInteger = TrigAreas(SelectedArea).Rec.Height
                .GroupBox_SelectedArea.Enabled = True
            Else
                .txt_SelectedArea.Text = "-"
                .lbl_SelectedSlot.Text = ""
                .txt_AreaPosX.Text = ""
                .txt_AreaPosY.Text = ""
                .txt_AreaSizeX.Text = ""
                .txt_AreaSizeY.Text = ""
                .GroupBox_SelectedArea.Refresh()
                .GroupBox_SelectedArea.Enabled = False
            End If
        End With
        EventsAreEnabled = True
    End Sub


    Friend Sub TriggerAreas_Show(ByVal img As Image, Optional ByVal ksize As Double = 1)
        '
        Dim r As Rectangle
        '
        Dim pt As Pen = New Pen(Color.FromArgb(255, 70, 0), img.Width \ 100)
        Dim ps As Pen = New Pen(Color.FromArgb(200, 160, 80), img.Width \ 100)
        Dim p As Pen = New Pen(Color.FromArgb(130, 80, 0))
        '
        Dim g As Graphics = Graphics.FromImage(img)
        '
        For i As Int32 = 0 To UsedAreas - 1
            With TrigAreas(i)
                '
                r = .Rec
                If ksize <> 1 Then
                    r.X = CInt(r.X * ksize)
                    r.Y = CInt(r.Y * ksize)
                    r.Width = CInt(r.Width * ksize)
                    r.Height = CInt(r.Height * ksize)
                End If
                '
                If .Triggered Then
                    g.DrawRectangle(pt, r)
                ElseIf i = SelectedArea Then
                    g.DrawRectangle(ps, r)
                Else
                    g.DrawRectangle(p, r)
                End If
            End With
        Next
    End Sub

    Friend Sub TriggerAreas_ResetTriggerFlags()
        For i As Int32 = 0 To TrigAreas.Length - 1
            TrigAreas(i).Triggered = False
        Next
    End Sub

    Friend Sub TriggerAreas_SetFirstSlot(ByVal n As Int32)
        FirstSlot = n
        ShowAreaParams()
    End Sub

    Friend Sub TriggerAreas_SetUsedAreas(ByVal n As Int32)
        UsedAreas = n
        If SelectedArea >= n Then SelectedArea = n - 1
        If UsedAreas > 0 And SelectedArea < 0 Then SelectedArea = 0
        ShowAreaParams()
    End Sub

    Friend Sub TriggerAreas_SetSelectedArea(ByVal n As Int32)
        If UsedAreas = 0 Then Exit Sub
        If n >= UsedAreas Then n = UsedAreas - 1
        If n < 0 Then n = 0
        SelectedArea = n
        ShowAreaParams()
    End Sub

    Friend Sub TriggerAreas_SetSelectedAreaParams(ByVal x As Int32, ByVal y As Int32, ByVal w As Int32, ByVal h As Int32)
        If UsedAreas = 0 Then Exit Sub
        If SelectedArea < 0 Or SelectedArea >= UsedAreas Then Exit Sub
        With TrigAreas(SelectedArea)
            .Rec.X = x
            .Rec.Y = PictureBoxHeight - y
            .Rec.Width = w
            .Rec.Height = h
        End With
        ShowAreaParams()
    End Sub


    Friend Sub TriggerAreas_TestImage(ByVal img As Image)
        '
        'Dim t As PrecisionTimer = New PrecisionTimer
        '
        Dim v As Int32
        '
        For i As Int32 = 0 To UsedAreas - 1
            With TrigAreas(i)
                'If TestImage(img, .Rec) > img.Width / 4 Then
                '    .Triggered = True
                '    WriteToSlot(i, 2000)
                'Else
                '    WriteToSlot(i, 0)
                'End If

                v = TestImage(img, .Rec)

                'v *= 1000 \ (.Rec.Width * .Rec.Height)

                WriteToSlot(i, v)

                If v > 10 Then .Triggered = True
            End With
        Next
        '
        't.DebugPrintMicrosec()
        'Form_Main.Text = t.GetTimeMicrosec.ToString
    End Sub


    Friend Sub TriggerAreas_TriggerWithMouse(ByVal pbox As PictureBox, ByVal mousePoint As Point, Optional ByVal ksize As Double = 1)

        If TrigAreas Is Nothing Then Exit Sub
        '
        Dim scale As Double = pbox.Image.Width / pbox.Width * ksize
        mousePoint.X = CInt(mousePoint.X * scale)
        mousePoint.Y = CInt(mousePoint.Y * scale)
        '
        SelectedArea = -1
        For i As Int32 = 0 To UsedAreas - 1
            With TrigAreas(i)
                If .Rec.Contains(mousePoint) Then
                    .Triggered = True
                    WriteToSlot(i, 2000)
                    SelectedArea = i
                Else
                    WriteToSlot(i, 0)
                End If
            End With
        Next
        ShowAreaParams()
    End Sub

    Private Sub WriteToSlot(ByVal AreaIndex As Int32, ByVal value As Int32)
        Slots.WriteSlot(AreaIndex + FirstSlot, value)
    End Sub


    Friend Sub TriggerAreas_WriteAreasToFile(ByVal f As System.IO.StreamWriter)
        For i As Int32 = 0 To MaxAreas - 1
            With TrigAreas(i)
                f.WriteLine("Area, " & _
                            i.ToString & ", " & _
                            .Rec.X.ToString & ", " & _
                            (PictureBoxHeight - .Rec.Y).ToString & ", " & _
                            .Rec.Width.ToString & ", " & _
                            .Rec.Height.ToString)
            End With
        Next
    End Sub

    Friend Sub TriggerAreas_ReadAreasFromFile(ByVal f As System.IO.StreamReader)
        Dim i As Int32 = 0
        Dim l As String
        Dim s() As String
        Do
            l = f.ReadLine()
            s = Strings.Split(l, ",")
            If s.Length = 6 Then
                If s(0) = "Area" Then
                    With TrigAreas(i)
                        .Rec.X = CInt(Val(s(2)))
                        .Rec.Y = PictureBoxHeight - CInt(Val(s(3)))
                        .Rec.Width = CInt(Val(s(4)))
                        .Rec.Height = CInt(Val(s(5)))
                    End With
                    i += 1
                End If
            End If
            If i >= MaxAreas Then Exit Do
            If f.EndOfStream Then Exit Do
        Loop
        FirstSlot = Form_Main.txt_FirstSlot.NumericValueInteger
        UsedAreas = Form_Main.txt_UsedAreas.NumericValueInteger
        ShowAreaParams()
    End Sub


End Module
