﻿

Module Module_Utils

    ' =======================================================================================
    '  OpenDirectShowGraph
    ' =======================================================================================

    Friend Sub OpenDirectShowGraph()
        '
        Dim GraphEditPath As String = Application.StartupPath & "\Graphedit\GraphEdit.exe"
        If Not IO.File.Exists(GraphEditPath) Then
            MsgBox("GraphEdit not found in the ""GraphEdit"" folder:" & vbCr & vbCr & GraphEditPath, MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim ProcID As Int32
        ProcID = Shell_NormalFocus("""" & GraphEditPath & """")

        SleepMyThread(800)
        Application.DoEvents()

        ' -------------------------------------------------- not working
        'AppActivate(ProcID)
        ' -------------------------------------------------- working but only with MONOGRAM GraphStudio
        AppActivate("Untitled - MONOGRAM GraphStudio")

        'If TV_IsOpen Then
        'SleepMyThread(800)
        'Application.DoEvents()
        '
        SleepMyThread(100)
        'Application.DoEvents()
        '
        'AppActivate(ProcID)
        My.Computer.Keyboard.SendKeys("^g", True)           ' CTRL + g
        My.Computer.Keyboard.SendKeys("{ENTER}", True)
        My.Computer.Keyboard.SendKeys("{ENTER}", True)
        '
        ' maybe some GraphEdit needs a different opening method... 
        'AppActivate(ProcID)
        'My.Computer.Keyboard.SendKeys("%fc", True)         ' ALT + f + c
        'My.Computer.Keyboard.SendKeys("{ENTER}", True)
        'My.Computer.Keyboard.SendKeys("{ENTER}", True)
        '
        SleepMyThread(500)
        My.Computer.Keyboard.SendKeys("^{F5}", True)        ' CTRL + F5
        My.Computer.Keyboard.SendKeys("{ENTER}", True)
        'End If

    End Sub


    ' =======================================================================================
    '  Utils
    ' =======================================================================================
    Friend Sub SleepMyThread(ByVal TimeMillisec As Int32)
        System.Threading.Thread.Sleep(TimeMillisec)
    End Sub

    Friend Function Shell_NormalFocus(ByVal path As String) As Int32
        Try
            Return Shell(path, AppWinStyle.NormalFocus)
        Catch
            MsgBox("Cannot open the path: " & vbCr & path, MsgBoxStyle.Information)
            Return 0
        End Try
    End Function
    Friend Function MouseButtonLeftPressed() As Boolean
        Return (Control.MouseButtons And Windows.Forms.MouseButtons.Left) <> Windows.Forms.MouseButtons.None
    End Function
    Friend Function MouseButtonRightPressed() As Boolean
        Return (Control.MouseButtons And Windows.Forms.MouseButtons.Right) <> Windows.Forms.MouseButtons.None
    End Function


    ' ==============================================================================================================
    '   COMBO FUNCTIONS
    ' ==============================================================================================================
    Friend Sub Combo_Init(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            .Items.Clear()
            .Items.Add(str)
            .SelectedIndex = 0
        End With
        EventsAreEnabled = old
    End Sub
    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub
    Friend Function Combo_GetValue(ByVal combo As ComboBox) As String
        If combo.SelectedIndex < 0 Then Return ""
        Return combo.Items(combo.SelectedIndex).ToString()
    End Function
    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByVal index As Int32)
        If combo.Items.Count < 1 Then Exit Sub
        If index < 0 Then index = 0
        If index > combo.Items.Count - 1 Then index = combo.Items.Count - 1
        combo.SelectedIndex = index
    End Sub



    '' =============================================================================================
    ''  ASYNC KEY and MOUSE STATE
    '' =============================================================================================
    'Private Const PRESSED_NOW As Int32 = &H8000
    'Private Const PRESSED_AFTER_PREVIOUS_CALL As Int32 = &H1
    'Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Int32) As Int16
    ''Friend Function KeyFromPreviousCall(ByVal k As Int32) As Boolean
    ''    KeyPrevious = (GetAsyncKeyState(k) And PRESSED_AFTER_PREVIOUS_CALL) <> 0
    ''End Function
    'Friend Function Key(ByVal k As Int32) As Boolean
    '    Key = (GetAsyncKeyState(k) And PRESSED_NOW) <> 0
    'End Function
    ''Friend Sub WaitMouseOff()
    ''    While Key(Keys.LButton) Or Key(Keys.MButton) Or Key(Keys.RButton)
    ''        SleepMyThread(1)
    ''    End While
    ''End Sub
    ''Friend Sub WaitKeyOff(ByVal WaitKey As Long)
    ''    Do
    ''        SleepMyThread(1)
    ''    Loop Until Not Key(WaitKey)
    ''End Sub

    ' =======================================================================================================
    '   FadeIn and FadeOut 
    ' =======================================================================================================
    Friend Sub Forms_FadeTo(ByVal FinalValue As Double, ByVal TimeMillisec As Double)
        Try
            If TimeMillisec < 1 Then TimeMillisec = 1
            Dim v As Double
            Dim k As Double
            Dim date1 As Date
            '
            Dim StartValue As Double = Form_Main.Opacity
            '
            Application.DoEvents()
            System.Threading.Thread.Sleep(1)
            date1 = Date.Now
            Do
                k = Date.Now.Subtract(date1).TotalMilliseconds / TimeMillisec
                If k > 1 Then k = 1
                v = StartValue + (FinalValue - StartValue) * k
                If FinalValue = 0 Then
                    v = v * 0.5
                End If
                Form_Main.Opacity = v
                Form_VideoInControls.Opacity = v
                System.Threading.Thread.Sleep(20)
                'Debug.Print(v.ToString)
            Loop Until k >= 1
        Catch
            Form_Main.Opacity = 1
            Form_VideoInControls.Opacity = 1
        End Try
    End Sub

End Module
