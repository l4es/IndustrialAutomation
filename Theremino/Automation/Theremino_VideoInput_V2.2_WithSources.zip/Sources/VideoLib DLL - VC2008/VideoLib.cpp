// VideoLib.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "VideoLib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CVideoLibApp

BEGIN_MESSAGE_MAP(CVideoLibApp, CWinApp)
	//{{AFX_MSG_MAP(CVideoLibApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVideoLibApp construction

CVideoLibApp::CVideoLibApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CVideoLibApp object

CVideoLibApp theApp;


//////////////////////////////////////////////////////////////////////////////
// Questo progetto e' stato creato con :  "NEW" e "MfcAppWizard-DLL"
// Il nome delle funzioni sono scritti anche in "VideoLib.DEF"
//////////////////////////////////////////////////////////////////////////////

// VideoLib-SPECIFIC
#include "math.h"
//#include "dos.h"
//#include "conio.h"


long	g_Width;
long	g_Height;
long	g_WidthBytes;
long	g_BitsPixel;
void*	g_Bits = 0;
HDC		g_hdc;
HBITMAP	g_oldBmp;
HBITMAP g_Bmp = 0;

BITMAPINFO* g_pBitmapInfo = 0;




///////////////////////////////////////////////////////////////////////////////////
//  PIXEL / FILL / LINES / RECTANGLES / CIRCLES / SCROLL / TEXT .... EXAMPLES
///////////////////////////////////////////////////////////////////////////////////


//extern "C" void PASCAL EXPORT BMP_InitFromHDC(HDC hDC)
//{
//
//	// Se era gia stata creata una bitmap la disalloco prima di farne un' altra.
//	if (g_pBitmapInfo != 0) BMP_End();
//
//	CDC* pDC = pDC->FromHandle(hDC);
//
//	// ---------------------------------------------------------------
//	CBitmap* pBmp = pDC->GetCurrentBitmap();
//
//	// --------------------------------------------------------------- recupero le informazioni
//	BITMAP bmp;
//	pBmp->GetBitmap(&bmp); 
//	g_Width = bmp.bmWidth;
//	g_Height = bmp.bmHeight;
//	g_WidthBytes = bmp.bmWidthBytes;
//	g_BitsPixel = bmp.bmBitsPixel;
//	DeleteObject(&bmp);
//	
//	// --------------------------------------------------------------- ALWAYS CONVERT TO 24bit(1400uS) or 32bit(1200uS) 
//	g_BitsPixel = 32;
//
//	// --------------------------------------------------------------- BITMAPINFO
//    g_pBitmapInfo = (BITMAPINFO*) new BYTE [sizeof(BITMAPINFOHEADER)]; 
//
//	// --------------------------------------------------------------- BITMAPINFOHEADER
//	g_pBitmapInfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
//	g_pBitmapInfo->bmiHeader.biWidth = g_Width;
//	g_pBitmapInfo->bmiHeader.biHeight = g_Height;
//	g_pBitmapInfo->bmiHeader.biPlanes = 1;
//	g_pBitmapInfo->bmiHeader.biBitCount = (WORD)g_BitsPixel;
//	g_pBitmapInfo->bmiHeader.biCompression = BI_RGB;
//	g_pBitmapInfo->bmiHeader.biSizeImage = 0;
//	g_pBitmapInfo->bmiHeader.biXPelsPerMeter = 0;
//	g_pBitmapInfo->bmiHeader.biYPelsPerMeter = 0;
//	g_pBitmapInfo->bmiHeader.biClrUsed = 0;
//	g_pBitmapInfo->bmiHeader.biClrImportant = 0;
//
//
//	// --------------------------------------------------------------- CreateDIBSection usa le informazioni di BITMAPINFO 
//	//                                                                 e alloca la memoria per i bits della bitmap 
//	g_Bmp = CreateDIBSection(NULL, g_pBitmapInfo, DIB_RGB_COLORS, &g_Bits, NULL, NULL);
//
//
//	// --------------------------------------------------------------- Creo un DC in memoria per TextOut e Scroll
//	g_hdc = CreateCompatibleDC(NULL);
//	g_oldBmp = (HBITMAP) SelectObject(g_hdc, g_Bmp);
//
//
//	// --------------------------------------------------------------- Recupero "WidthBytes"
//	GetObject(g_Bmp, sizeof(BITMAP), &bmp);
//	g_WidthBytes = bmp.bmWidthBytes;
//	DeleteObject(&bmp);
//
//
//	// ----------------------------------------------------------- prendo i bits
//	GetDIBits( 
//				g_hdc, 
//				pBmp->operator HBITMAP(), 
//				0, 
//				g_Height, 
//				g_Bits, 
//				g_pBitmapInfo, 
//				DIB_RGB_COLORS
//			  );
//	// ============================================================================================
//
//}

//extern "C" void PASCAL EXPORT BMP_AntialiasedCircleFilled(double CenterX, 
//														  double CenterY, 
//														  double Radius, 
//														  double Feather, 
//														  COLORREF Color)
//{
//	int x,y;
//	int LX, RX, LY, RY;
//	double RPF2, RMF2;
//    double SqY, SqDist, k;
//	// ------------------------------------------------------------ helpful values
//	RPF2 = Radius + Feather / 2;
//	RMF2 = Radius - Feather / 2;
//	//
//	RPF2 = RPF2 * RPF2;
//	RMF2 = RMF2 * RMF2;
//	// ------------------------------------------------------------ bounds
//	LX = int(floor(CenterX - Radius - Feather));
//	RX = int(ceil (CenterX + Radius + Feather));
//	LY = int(floor(CenterY - Radius - Feather));
//	RY = int(ceil (CenterY + Radius + Feather));
//	// ------------------------------------------------------------ scan all the area
//	for (y = LY; y <= RY; y++)
//	{
//		// -------------------------------------------------------- the squared distance from center for this pixel
//		SqY = y - CenterY;
//		SqY = SqY * SqY;
//		//
//		for (x = LX; x <= RX; x++)
//		{
//			// ---------------------------------------------------- the squared distance from center for this pixel
//			SqDist = SqY + (x - CenterX) * (x - CenterX);
//			//
//			if (SqDist < RMF2) // check if inside the inner circle
//			{
//				// ------------------------------------------------ in the inner area ( fill area )
//				BMP_SetPixel(x, y, Color);
//			}
//			else if (SqDist < RPF2) // check if inside the outer circle
//			{
//				// ------------------------------------------------ in the feather area
//				k = ( sqrt(SqDist) - (Radius - Feather / 2) ) / Feather;
//				BMP_SetPixel(x, y, MixedColor(Color, BMP_GetPixel(x, y), k));
//			}
//		}
//	}
//}




///////////////////////////////////////////////////////////////////////////////////
//  RANDOM
///////////////////////////////////////////////////////////////////////////////////

static unsigned long random = 0;

extern "C" long PASCAL EXPORT RndLong ()
{
	random = 1664525L * random + 1013904223L;
	return random;
}


extern "C" long PASCAL EXPORT Rnd24bit ()
{	
	random = 1664525L * random + 1013904223L;
	return random >> 8;
}


extern "C" float PASCAL EXPORT RndSingle ()
{
	random = 1664525L * random + 1013904223L;           
	return random / (float) 4294967296;
}

extern "C" float PASCAL EXPORT RndSingleSigned ()
{
	random = 1664525L * random + 1013904223L;           
	return random / (float) 2147483648 - 1;
}













///////////////////////////////////////////////////////////////////////////////////
//  TestBitmapData
///////////////////////////////////////////////////////////////////////////////////

extern "C" long PASCAL EXPORT TestBitmapData( 
												long start,
												long height,
												long width,
												long offset,
												long trigvalue
											)
{


	//__asm {
	//	   mov al, 2
	//	   mov dx, 0xD007
	//	   out dx, al
	//	  }


	long x;
	long y;
	long detected = 0;
	BYTE* i = (BYTE*) start;
	//
	for (y = 0; y < height; y++)
	{
		for (x = 0; x < width; x++)
		{
			if (*i > trigvalue) detected ++;
			//*i = 255;                      //<< all white test
			i++;
		}
		i += offset;
	}
	return detected;
}




///////////////////////////////////////////////////////////////////////////////////
//  MotionDetector
///////////////////////////////////////////////////////////////////////////////////

extern "C" void PASCAL EXPORT MotionDetector( 
												long start1,
												long start2,
												long height,
												long width,
												long offset,
												long Shift,
												long Gain,
												long GrayScale,
												long Invert,
												long AllPositive,
												long BlackOrWhite
											)
{
	long x;
	long y;
	long v = 0;
	long trig = 0;
	if (BlackOrWhite) trig = 254;
	BYTE* i1 = (BYTE*) start1;
	BYTE* i2 = (BYTE*) start2;
	//
	if (GrayScale)
	{
		for (y = 0; y < height; y++)
		{
			for (x = 0; x < width; x+=3)
			{
				v  = long(*i1) / 4 + long(*(i1+1)) + long(*(i1+2)) / 2; 
				v -= long(*i2) / 4 + long(*(i2+1)) + long(*(i2+2)) / 2;
				v *= Gain;

				if (Invert) v = -v;

				if (v < 0 && AllPositive)
				{
					v = Shift - v;
				}
				else
				{
					v = Shift + v;
				}

				if (v < trig) v = 0;
				if (v > 255) v = 255;

				*i1 = (BYTE) v;
				*(i1+1) = (BYTE) v;
				*(i1+2) = (BYTE) v;

				i1+=3;
				i2+=3;
			}
			i1 += offset;
			i2 += offset;
		}
	}
	else
	{
		for (y = 0; y < height; y++)
		{
			for (x = 0; x < width; x++)
			{
				v = long(*i1) - long(*i2);
				v *= Gain;

				if (Invert) v = -v;

				if (v < 0 && AllPositive)
				{
					v = Shift - v;
				}
				else
				{
					v = Shift + v;
				}

				if (v < trig) v = 0;
				if (v > 255) v = 255;

				*i1 = (BYTE) v;

				i1++;
				i2++;
			}
			i1 += offset;
			i2 += offset;
		}
	}
}


