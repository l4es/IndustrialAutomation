﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btn_SetRefImg = New MyButton
        Me.RadioButton_Double = New System.Windows.Forms.RadioButton
        Me.RadioButton_Negative = New System.Windows.Forms.RadioButton
        Me.RadioButton_Positive = New System.Windows.Forms.RadioButton
        Me.CheckBox_BlackOrWhite = New System.Windows.Forms.CheckBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txt_DetectorRes = New MyTextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.CheckBox_GrayScale = New System.Windows.Forms.CheckBox
        Me.txt_DetectorShift = New MyTextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txt_DetectorGain = New MyTextBox
        Me.txt_DetectorMaxFps = New MyTextBox
        Me.Label_FramesPerSec = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.btn_VideoInControls = New MyButton
        Me.Label_Resolution = New System.Windows.Forms.Label
        Me.ComboBox_VideoInputDevice = New MyComboBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.CheckBox_FlipY = New System.Windows.Forms.CheckBox
        Me.CheckBox_FlipX = New System.Windows.Forms.CheckBox
        Me.CheckBox_EnableImage1 = New System.Windows.Forms.CheckBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txt_ShiftX = New MyTextBox
        Me.CheckBox_EnableImage2 = New System.Windows.Forms.CheckBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txt_ShiftY = New MyTextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txt_Zoom = New MyTextBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_VideoinControls = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_OpenDirectShowGraph = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.Tool_VideoInControls = New System.Windows.Forms.ToolStripButton
        Me.Tool_DirectShowGraph = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolButton_HelpEng = New System.Windows.Forms.ToolStripButton
        Me.ToolButton_HelpIta = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Label29 = New System.Windows.Forms.Label
        Me.txt_NumAreaX = New MyTextBox
        Me.CheckBox_TrigShow1 = New System.Windows.Forms.CheckBox
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_OutValueMultiplier = New MyTextBox
        Me.chk_FirstSlotOnly = New System.Windows.Forms.CheckBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txt_FirstSlot = New MyTextBox
        Me.txt_NumAreaY = New MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.CheckBox_TrigShow2 = New System.Windows.Forms.CheckBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.txt_PostFilterQuality = New MyTextBox
        Me.txt_ZoomQuality = New MyTextBox
        Me.txt_PreFilterQuality = New MyTextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Cornsilk
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(9, 68)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(324, 244)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(157, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 16)
        Me.Label6.TabIndex = 60
        Me.Label6.Text = "Max FPS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.btn_SetRefImg)
        Me.GroupBox2.Controls.Add(Me.RadioButton_Double)
        Me.GroupBox2.Controls.Add(Me.RadioButton_Negative)
        Me.GroupBox2.Controls.Add(Me.RadioButton_Positive)
        Me.GroupBox2.Controls.Add(Me.CheckBox_BlackOrWhite)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txt_DetectorRes)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.CheckBox_GrayScale)
        Me.GroupBox2.Controls.Add(Me.txt_DetectorShift)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txt_DetectorGain)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txt_DetectorMaxFps)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(344, 318)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(324, 144)
        Me.GroupBox2.TabIndex = 63
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Difference Detector"
        '
        'btn_SetRefImg
        '
        Me.btn_SetRefImg.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetRefImg.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SetRefImg.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SetRefImg.ColorFillBlendChecked = CBlendItems2
        Me.btn_SetRefImg.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SetRefImg.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SetRefImg.Corners.All = CType(6, Short)
        Me.btn_SetRefImg.Corners.LowerLeft = CType(6, Short)
        Me.btn_SetRefImg.Corners.LowerRight = CType(6, Short)
        Me.btn_SetRefImg.Corners.UpperLeft = CType(6, Short)
        Me.btn_SetRefImg.Corners.UpperRight = CType(6, Short)
        Me.btn_SetRefImg.DimFactorOver = 30
        Me.btn_SetRefImg.FillType = MyButton.eFillType.LinearVertical
        Me.btn_SetRefImg.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_SetRefImg.FocalPoints.CenterPtX = 0.1578947!
        Me.btn_SetRefImg.FocalPoints.CenterPtY = 1.0!
        Me.btn_SetRefImg.FocalPoints.FocusPtX = 0.0!
        Me.btn_SetRefImg.FocalPoints.FocusPtY = 0.0!
        Me.btn_SetRefImg.FocalPointsChecked.CenterPtX = 0.0!
        Me.btn_SetRefImg.FocalPointsChecked.CenterPtY = 0.0!
        Me.btn_SetRefImg.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SetRefImg.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetRefImg.FocusPtTracker = DesignerRectTracker2
        Me.btn_SetRefImg.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SetRefImg.Image = Nothing
        Me.btn_SetRefImg.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetRefImg.ImageIndex = 0
        Me.btn_SetRefImg.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SetRefImg.Location = New System.Drawing.Point(160, 113)
        Me.btn_SetRefImg.Name = "btn_SetRefImg"
        Me.btn_SetRefImg.Shape = MyButton.eShape.Rectangle
        Me.btn_SetRefImg.SideImage = Nothing
        Me.btn_SetRefImg.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetRefImg.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SetRefImg.Size = New System.Drawing.Size(148, 19)
        Me.btn_SetRefImg.TabIndex = 217
        Me.btn_SetRefImg.Text = "Set reference image"
        Me.btn_SetRefImg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetRefImg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SetRefImg.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SetRefImg.TextShadow = System.Drawing.Color.Transparent
        '
        'RadioButton_Double
        '
        Me.RadioButton_Double.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Double.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_Double.Location = New System.Drawing.Point(19, 65)
        Me.RadioButton_Double.Name = "RadioButton_Double"
        Me.RadioButton_Double.Size = New System.Drawing.Size(116, 20)
        Me.RadioButton_Double.TabIndex = 79
        Me.RadioButton_Double.Text = "Double"
        Me.RadioButton_Double.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Double.UseVisualStyleBackColor = True
        '
        'RadioButton_Negative
        '
        Me.RadioButton_Negative.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Negative.Checked = True
        Me.RadioButton_Negative.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_Negative.Location = New System.Drawing.Point(19, 46)
        Me.RadioButton_Negative.Name = "RadioButton_Negative"
        Me.RadioButton_Negative.Size = New System.Drawing.Size(116, 20)
        Me.RadioButton_Negative.TabIndex = 78
        Me.RadioButton_Negative.TabStop = True
        Me.RadioButton_Negative.Text = "Negative"
        Me.RadioButton_Negative.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Negative.UseVisualStyleBackColor = True
        '
        'RadioButton_Positive
        '
        Me.RadioButton_Positive.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Positive.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_Positive.Location = New System.Drawing.Point(19, 27)
        Me.RadioButton_Positive.Name = "RadioButton_Positive"
        Me.RadioButton_Positive.Size = New System.Drawing.Size(116, 20)
        Me.RadioButton_Positive.TabIndex = 77
        Me.RadioButton_Positive.Text = "Positive"
        Me.RadioButton_Positive.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RadioButton_Positive.UseVisualStyleBackColor = True
        '
        'CheckBox_BlackOrWhite
        '
        Me.CheckBox_BlackOrWhite.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_BlackOrWhite.Checked = True
        Me.CheckBox_BlackOrWhite.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_BlackOrWhite.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_BlackOrWhite.Location = New System.Drawing.Point(19, 112)
        Me.CheckBox_BlackOrWhite.Name = "CheckBox_BlackOrWhite"
        Me.CheckBox_BlackOrWhite.Size = New System.Drawing.Size(116, 20)
        Me.CheckBox_BlackOrWhite.TabIndex = 76
        Me.CheckBox_BlackOrWhite.Text = "Black or White"
        Me.CheckBox_BlackOrWhite.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_BlackOrWhite.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(157, 70)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(98, 16)
        Me.Label10.TabIndex = 68
        Me.Label10.Text = "Detector res."
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_DetectorRes
        '
        Me.txt_DetectorRes.ArrowsIncrement = 10
        Me.txt_DetectorRes.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_DetectorRes.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DetectorRes.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DetectorRes.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DetectorRes.Increment = 1
        Me.txt_DetectorRes.Location = New System.Drawing.Point(258, 69)
        Me.txt_DetectorRes.MaxValue = 320
        Me.txt_DetectorRes.MinValue = 40
        Me.txt_DetectorRes.Multiline = True
        Me.txt_DetectorRes.Name = "txt_DetectorRes"
        Me.txt_DetectorRes.NumericValue = 100
        Me.txt_DetectorRes.NumericValueInteger = 100
        Me.txt_DetectorRes.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DetectorRes.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DetectorRes.RoundingStep = 10
        Me.txt_DetectorRes.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DetectorRes.Size = New System.Drawing.Size(50, 16)
        Me.txt_DetectorRes.SuppressZeros = True
        Me.txt_DetectorRes.TabIndex = 67
        Me.txt_DetectorRes.Text = "100"
        Me.txt_DetectorRes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(157, 28)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 16)
        Me.Label9.TabIndex = 64
        Me.Label9.Text = "Detector shift"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CheckBox_GrayScale
        '
        Me.CheckBox_GrayScale.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_GrayScale.Checked = True
        Me.CheckBox_GrayScale.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_GrayScale.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_GrayScale.Location = New System.Drawing.Point(19, 90)
        Me.CheckBox_GrayScale.Name = "CheckBox_GrayScale"
        Me.CheckBox_GrayScale.Size = New System.Drawing.Size(116, 20)
        Me.CheckBox_GrayScale.TabIndex = 71
        Me.CheckBox_GrayScale.Text = "Gray scale"
        Me.CheckBox_GrayScale.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_GrayScale.UseVisualStyleBackColor = True
        '
        'txt_DetectorShift
        '
        Me.txt_DetectorShift.ArrowsIncrement = 1
        Me.txt_DetectorShift.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_DetectorShift.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DetectorShift.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DetectorShift.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DetectorShift.Increment = 0.2
        Me.txt_DetectorShift.Location = New System.Drawing.Point(258, 27)
        Me.txt_DetectorShift.MaxValue = 200
        Me.txt_DetectorShift.MinValue = -200
        Me.txt_DetectorShift.Multiline = True
        Me.txt_DetectorShift.Name = "txt_DetectorShift"
        Me.txt_DetectorShift.NumericValue = 0
        Me.txt_DetectorShift.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DetectorShift.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DetectorShift.RoundingStep = 0
        Me.txt_DetectorShift.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DetectorShift.Size = New System.Drawing.Size(50, 16)
        Me.txt_DetectorShift.SuppressZeros = True
        Me.txt_DetectorShift.TabIndex = 63
        Me.txt_DetectorShift.Text = "0"
        Me.txt_DetectorShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(157, 49)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(98, 16)
        Me.Label8.TabIndex = 62
        Me.Label8.Text = "Detector gain"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_DetectorGain
        '
        Me.txt_DetectorGain.ArrowsIncrement = 1
        Me.txt_DetectorGain.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_DetectorGain.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DetectorGain.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DetectorGain.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DetectorGain.Increment = 0.2
        Me.txt_DetectorGain.Location = New System.Drawing.Point(258, 48)
        Me.txt_DetectorGain.MaxValue = 50
        Me.txt_DetectorGain.MinValue = 1
        Me.txt_DetectorGain.Multiline = True
        Me.txt_DetectorGain.Name = "txt_DetectorGain"
        Me.txt_DetectorGain.NumericValue = 5
        Me.txt_DetectorGain.NumericValueInteger = 5
        Me.txt_DetectorGain.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DetectorGain.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DetectorGain.RoundingStep = 0
        Me.txt_DetectorGain.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DetectorGain.Size = New System.Drawing.Size(50, 16)
        Me.txt_DetectorGain.SuppressZeros = True
        Me.txt_DetectorGain.TabIndex = 61
        Me.txt_DetectorGain.Text = "5"
        Me.txt_DetectorGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DetectorMaxFps
        '
        Me.txt_DetectorMaxFps.ArrowsIncrement = 1
        Me.txt_DetectorMaxFps.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_DetectorMaxFps.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DetectorMaxFps.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DetectorMaxFps.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DetectorMaxFps.Increment = 0.2
        Me.txt_DetectorMaxFps.Location = New System.Drawing.Point(258, 90)
        Me.txt_DetectorMaxFps.MaxValue = 50
        Me.txt_DetectorMaxFps.MinValue = 1
        Me.txt_DetectorMaxFps.Multiline = True
        Me.txt_DetectorMaxFps.Name = "txt_DetectorMaxFps"
        Me.txt_DetectorMaxFps.NumericValue = 15
        Me.txt_DetectorMaxFps.NumericValueInteger = 15
        Me.txt_DetectorMaxFps.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DetectorMaxFps.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DetectorMaxFps.RoundingStep = 0
        Me.txt_DetectorMaxFps.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DetectorMaxFps.Size = New System.Drawing.Size(50, 16)
        Me.txt_DetectorMaxFps.SuppressZeros = True
        Me.txt_DetectorMaxFps.TabIndex = 59
        Me.txt_DetectorMaxFps.Text = "15"
        Me.txt_DetectorMaxFps.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_FramesPerSec
        '
        Me.Label_FramesPerSec.BackColor = System.Drawing.Color.MintCream
        Me.Label_FramesPerSec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_FramesPerSec.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FramesPerSec.Location = New System.Drawing.Point(254, 52)
        Me.Label_FramesPerSec.Name = "Label_FramesPerSec"
        Me.Label_FramesPerSec.Size = New System.Drawing.Size(51, 18)
        Me.Label_FramesPerSec.TabIndex = 65
        Me.Label_FramesPerSec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Cornsilk
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.ErrorImage = Nothing
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.InitialImage = CType(resources.GetObject("PictureBox2.InitialImage"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(343, 68)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(324, 244)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 64
        Me.PictureBox2.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox4.Controls.Add(Me.btn_VideoInControls)
        Me.GroupBox4.Controls.Add(Me.Label_Resolution)
        Me.GroupBox4.Controls.Add(Me.ComboBox_VideoInputDevice)
        Me.GroupBox4.Controls.Add(Me.Label_FramesPerSec)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(10, 318)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(321, 80)
        Me.GroupBox4.TabIndex = 70
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Video Input Device"
        '
        'btn_VideoInControls
        '
        Me.btn_VideoInControls.BorderShow = False
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoInControls.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_VideoInControls.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems4.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_VideoInControls.ColorFillBlendChecked = CBlendItems4
        Me.btn_VideoInControls.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_VideoInControls.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_VideoInControls.Corners.All = CType(6, Short)
        Me.btn_VideoInControls.Corners.LowerLeft = CType(6, Short)
        Me.btn_VideoInControls.Corners.LowerRight = CType(6, Short)
        Me.btn_VideoInControls.Corners.UpperLeft = CType(6, Short)
        Me.btn_VideoInControls.Corners.UpperRight = CType(6, Short)
        Me.btn_VideoInControls.DimFactorOver = 30
        Me.btn_VideoInControls.FillType = MyButton.eFillType.LinearVertical
        Me.btn_VideoInControls.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_VideoInControls.FocalPoints.CenterPtX = 0.4765625!
        Me.btn_VideoInControls.FocalPoints.CenterPtY = 0.5!
        Me.btn_VideoInControls.FocalPoints.FocusPtX = 0.0!
        Me.btn_VideoInControls.FocalPoints.FocusPtY = 0.0!
        Me.btn_VideoInControls.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_VideoInControls.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_VideoInControls.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_VideoInControls.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_VideoInControls.FocusPtTracker = DesignerRectTracker4
        Me.btn_VideoInControls.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_VideoInControls.Image = Nothing
        Me.btn_VideoInControls.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoInControls.ImageIndex = 0
        Me.btn_VideoInControls.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_VideoInControls.Location = New System.Drawing.Point(16, 51)
        Me.btn_VideoInControls.Name = "btn_VideoInControls"
        Me.btn_VideoInControls.Shape = MyButton.eShape.Rectangle
        Me.btn_VideoInControls.SideImage = Nothing
        Me.btn_VideoInControls.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_VideoInControls.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_VideoInControls.Size = New System.Drawing.Size(128, 18)
        Me.btn_VideoInControls.TabIndex = 68
        Me.btn_VideoInControls.Text = "Video-in Controls"
        Me.btn_VideoInControls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_VideoInControls.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_VideoInControls.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_VideoInControls.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_Resolution
        '
        Me.Label_Resolution.BackColor = System.Drawing.Color.MintCream
        Me.Label_Resolution.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Resolution.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Resolution.Location = New System.Drawing.Point(157, 52)
        Me.Label_Resolution.Name = "Label_Resolution"
        Me.Label_Resolution.Size = New System.Drawing.Size(85, 18)
        Me.Label_Resolution.TabIndex = 66
        Me.Label_Resolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_VideoInputDevice
        '
        Me.ComboBox_VideoInputDevice.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoInputDevice.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.ComboBox_VideoInputDevice.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BorderSize = 1
        Me.ComboBox_VideoInputDevice.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoInputDevice.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDownHeight = 318
        Me.ComboBox_VideoInputDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoInputDevice.DropDownWidth = 280
        Me.ComboBox_VideoInputDevice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoInputDevice.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoInputDevice.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoInputDevice.IntegralHeight = False
        Me.ComboBox_VideoInputDevice.Items.AddRange(New Object() {"Auto"})
        Me.ComboBox_VideoInputDevice.Location = New System.Drawing.Point(16, 20)
        Me.ComboBox_VideoInputDevice.Name = "ComboBox_VideoInputDevice"
        Me.ComboBox_VideoInputDevice.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoInputDevice.Size = New System.Drawing.Size(294, 23)
        Me.ComboBox_VideoInputDevice.TabIndex = 32
        Me.ComboBox_VideoInputDevice.TabStop = False
        Me.ComboBox_VideoInputDevice.TextPosition = 4
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.CheckBox_FlipY)
        Me.GroupBox5.Controls.Add(Me.CheckBox_FlipX)
        Me.GroupBox5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(199, 405)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(134, 64)
        Me.GroupBox5.TabIndex = 71
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Flip"
        '
        'CheckBox_FlipY
        '
        Me.CheckBox_FlipY.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipY.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_FlipY.Location = New System.Drawing.Point(12, 40)
        Me.CheckBox_FlipY.Name = "CheckBox_FlipY"
        Me.CheckBox_FlipY.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_FlipY.TabIndex = 74
        Me.CheckBox_FlipY.Text = "Flip Y"
        Me.CheckBox_FlipY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipY.UseVisualStyleBackColor = True
        '
        'CheckBox_FlipX
        '
        Me.CheckBox_FlipX.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipX.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_FlipX.Location = New System.Drawing.Point(12, 22)
        Me.CheckBox_FlipX.Name = "CheckBox_FlipX"
        Me.CheckBox_FlipX.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_FlipX.TabIndex = 73
        Me.CheckBox_FlipX.Text = "Flip X"
        Me.CheckBox_FlipX.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_FlipX.UseVisualStyleBackColor = True
        '
        'CheckBox_EnableImage1
        '
        Me.CheckBox_EnableImage1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_EnableImage1.Checked = True
        Me.CheckBox_EnableImage1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_EnableImage1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_EnableImage1.Location = New System.Drawing.Point(12, 18)
        Me.CheckBox_EnableImage1.Name = "CheckBox_EnableImage1"
        Me.CheckBox_EnableImage1.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_EnableImage1.TabIndex = 82
        Me.CheckBox_EnableImage1.Text = "Image 1"
        Me.CheckBox_EnableImage1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_EnableImage1.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(11, 38)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(105, 16)
        Me.Label17.TabIndex = 70
        Me.Label17.Text = "Shift X"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ShiftX
        '
        Me.txt_ShiftX.ArrowsIncrement = 1
        Me.txt_ShiftX.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ShiftX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ShiftX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ShiftX.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ShiftX.Increment = 0.2
        Me.txt_ShiftX.Location = New System.Drawing.Point(120, 38)
        Me.txt_ShiftX.MaxValue = 320
        Me.txt_ShiftX.MinValue = -320
        Me.txt_ShiftX.Multiline = True
        Me.txt_ShiftX.Name = "txt_ShiftX"
        Me.txt_ShiftX.NumericValue = 0
        Me.txt_ShiftX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ShiftX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ShiftX.RoundingStep = 0
        Me.txt_ShiftX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ShiftX.Size = New System.Drawing.Size(50, 16)
        Me.txt_ShiftX.SuppressZeros = True
        Me.txt_ShiftX.TabIndex = 69
        Me.txt_ShiftX.Text = "0"
        Me.txt_ShiftX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_EnableImage2
        '
        Me.CheckBox_EnableImage2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_EnableImage2.Checked = True
        Me.CheckBox_EnableImage2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_EnableImage2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_EnableImage2.Location = New System.Drawing.Point(12, 36)
        Me.CheckBox_EnableImage2.Name = "CheckBox_EnableImage2"
        Me.CheckBox_EnableImage2.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_EnableImage2.TabIndex = 83
        Me.CheckBox_EnableImage2.Text = "Image 2"
        Me.CheckBox_EnableImage2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_EnableImage2.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(11, 55)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(105, 16)
        Me.Label18.TabIndex = 68
        Me.Label18.Text = "Shift Y"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ShiftY
        '
        Me.txt_ShiftY.ArrowsIncrement = 1
        Me.txt_ShiftY.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ShiftY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ShiftY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ShiftY.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ShiftY.Increment = 0.2
        Me.txt_ShiftY.Location = New System.Drawing.Point(120, 56)
        Me.txt_ShiftY.MaxValue = 240
        Me.txt_ShiftY.MinValue = -240
        Me.txt_ShiftY.Multiline = True
        Me.txt_ShiftY.Name = "txt_ShiftY"
        Me.txt_ShiftY.NumericValue = 0
        Me.txt_ShiftY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ShiftY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ShiftY.RoundingStep = 0
        Me.txt_ShiftY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ShiftY.Size = New System.Drawing.Size(50, 16)
        Me.txt_ShiftY.SuppressZeros = True
        Me.txt_ShiftY.TabIndex = 67
        Me.txt_ShiftY.Text = "0"
        Me.txt_ShiftY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(11, 20)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 16)
        Me.Label19.TabIndex = 66
        Me.Label19.Text = "Zoom"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Zoom
        '
        Me.txt_Zoom.ArrowsIncrement = 0.01
        Me.txt_Zoom.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_Zoom.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Zoom.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Zoom.Decimals = 2
        Me.txt_Zoom.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Zoom.Increment = 0.01
        Me.txt_Zoom.Location = New System.Drawing.Point(120, 20)
        Me.txt_Zoom.MaxValue = 8
        Me.txt_Zoom.MinValue = 1
        Me.txt_Zoom.Multiline = True
        Me.txt_Zoom.Name = "txt_Zoom"
        Me.txt_Zoom.NumericValue = 1
        Me.txt_Zoom.NumericValueInteger = 1
        Me.txt_Zoom.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Zoom.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Zoom.RoundingStep = 0
        Me.txt_Zoom.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Zoom.Size = New System.Drawing.Size(50, 16)
        Me.txt_Zoom.SuppressZeros = True
        Me.txt_Zoom.TabIndex = 65
        Me.txt_Zoom.Text = "1"
        Me.txt_Zoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.ToolsToolStripMenuItem, Me.Menu_Help})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(677, 24)
        Me.MenuStrip1.TabIndex = 72
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator3, Me.Menu_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(89, 6)
        '
        'Menu_Exit
        '
        Me.Menu_Exit.Name = "Menu_Exit"
        Me.Menu_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_Exit.Text = "Exit"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_VideoinControls, Me.Menu_OpenDirectShowGraph})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'Menu_VideoinControls
        '
        Me.Menu_VideoinControls.Image = CType(resources.GetObject("Menu_VideoinControls.Image"), System.Drawing.Image)
        Me.Menu_VideoinControls.Name = "Menu_VideoinControls"
        Me.Menu_VideoinControls.Size = New System.Drawing.Size(169, 22)
        Me.Menu_VideoinControls.Text = "Video-in Controls"
        '
        'Menu_OpenDirectShowGraph
        '
        Me.Menu_OpenDirectShowGraph.Image = CType(resources.GetObject("Menu_OpenDirectShowGraph.Image"), System.Drawing.Image)
        Me.Menu_OpenDirectShowGraph.Name = "Menu_OpenDirectShowGraph"
        Me.Menu_OpenDirectShowGraph.Size = New System.Drawing.Size(169, 22)
        Me.Menu_OpenDirectShowGraph.Text = "DirectShow Graph"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp_ENG, Me.Menu_Help_ProgramHelp_ITA, Me.Menu_About})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp_ENG
        '
        Me.Menu_Help_ProgramHelp_ENG.Image = CType(resources.GetObject("Menu_Help_ProgramHelp_ENG.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp_ENG.Name = "Menu_Help_ProgramHelp_ENG"
        Me.Menu_Help_ProgramHelp_ENG.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp_ENG.Text = "Program help ( ENG )"
        '
        'Menu_Help_ProgramHelp_ITA
        '
        Me.Menu_Help_ProgramHelp_ITA.Image = CType(resources.GetObject("Menu_Help_ProgramHelp_ITA.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp_ITA.Name = "Menu_Help_ProgramHelp_ITA"
        Me.Menu_Help_ProgramHelp_ITA.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp_ITA.Text = "Program help ( ITA )"
        '
        'Menu_About
        '
        Me.Menu_About.Image = CType(resources.GetObject("Menu_About.Image"), System.Drawing.Image)
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(186, 22)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tool_VideoInControls, Me.Tool_DirectShowGraph, Me.ToolStripSeparator2, Me.ToolButton_HelpEng, Me.ToolButton_HelpIta, Me.ToolStripSeparator1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(677, 38)
        Me.ToolStrip1.TabIndex = 73
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tool_VideoInControls
        '
        Me.Tool_VideoInControls.Image = CType(resources.GetObject("Tool_VideoInControls.Image"), System.Drawing.Image)
        Me.Tool_VideoInControls.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_VideoInControls.Name = "Tool_VideoInControls"
        Me.Tool_VideoInControls.Size = New System.Drawing.Size(104, 35)
        Me.Tool_VideoInControls.Text = "Video-in Controls"
        Me.Tool_VideoInControls.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Tool_DirectShowGraph
        '
        Me.Tool_DirectShowGraph.Image = CType(resources.GetObject("Tool_DirectShowGraph.Image"), System.Drawing.Image)
        Me.Tool_DirectShowGraph.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_DirectShowGraph.Name = "Tool_DirectShowGraph"
        Me.Tool_DirectShowGraph.Size = New System.Drawing.Size(106, 35)
        Me.Tool_DirectShowGraph.Text = "DirectShow Graph"
        Me.Tool_DirectShowGraph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'ToolButton_HelpEng
        '
        Me.ToolButton_HelpEng.Image = CType(resources.GetObject("ToolButton_HelpEng.Image"), System.Drawing.Image)
        Me.ToolButton_HelpEng.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolButton_HelpEng.Name = "ToolButton_HelpEng"
        Me.ToolButton_HelpEng.Size = New System.Drawing.Size(109, 35)
        Me.ToolButton_HelpEng.Text = "Program help ENG"
        Me.ToolButton_HelpEng.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolButton_HelpIta
        '
        Me.ToolButton_HelpIta.Image = CType(resources.GetObject("ToolButton_HelpIta.Image"), System.Drawing.Image)
        Me.ToolButton_HelpIta.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolButton_HelpIta.Name = "ToolButton_HelpIta"
        Me.ToolButton_HelpIta.Size = New System.Drawing.Size(103, 35)
        Me.ToolButton_HelpIta.Text = "Program help ITA"
        Me.ToolButton_HelpIta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(19, 29)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(82, 16)
        Me.Label29.TabIndex = 69
        Me.Label29.Text = "Num area X"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_NumAreaX
        '
        Me.txt_NumAreaX.ArrowsIncrement = 1
        Me.txt_NumAreaX.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_NumAreaX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_NumAreaX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_NumAreaX.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NumAreaX.Increment = 0.2
        Me.txt_NumAreaX.Location = New System.Drawing.Point(101, 29)
        Me.txt_NumAreaX.MaxValue = 16
        Me.txt_NumAreaX.MinValue = 1
        Me.txt_NumAreaX.Multiline = True
        Me.txt_NumAreaX.Name = "txt_NumAreaX"
        Me.txt_NumAreaX.NumericValue = 1
        Me.txt_NumAreaX.NumericValueInteger = 1
        Me.txt_NumAreaX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_NumAreaX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_NumAreaX.RoundingStep = 0
        Me.txt_NumAreaX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_NumAreaX.Size = New System.Drawing.Size(34, 16)
        Me.txt_NumAreaX.SuppressZeros = True
        Me.txt_NumAreaX.TabIndex = 68
        Me.txt_NumAreaX.Text = "0"
        Me.txt_NumAreaX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_TrigShow1
        '
        Me.CheckBox_TrigShow1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_TrigShow1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_TrigShow1.Location = New System.Drawing.Point(12, 54)
        Me.CheckBox_TrigShow1.Name = "CheckBox_TrigShow1"
        Me.CheckBox_TrigShow1.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_TrigShow1.TabIndex = 74
        Me.CheckBox_TrigShow1.Text = "Triggers 1"
        Me.CheckBox_TrigShow1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_TrigShow1.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox9.Controls.Add(Me.Label2)
        Me.GroupBox9.Controls.Add(Me.txt_OutValueMultiplier)
        Me.GroupBox9.Controls.Add(Me.chk_FirstSlotOnly)
        Me.GroupBox9.Controls.Add(Me.Label7)
        Me.GroupBox9.Controls.Add(Me.txt_FirstSlot)
        Me.GroupBox9.Controls.Add(Me.txt_NumAreaY)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Controls.Add(Me.Label29)
        Me.GroupBox9.Controls.Add(Me.txt_NumAreaX)
        Me.GroupBox9.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(344, 470)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(324, 99)
        Me.GroupBox9.TabIndex = 81
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Trigger areas"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(150, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 16)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "Out value multiplier"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_OutValueMultiplier
        '
        Me.txt_OutValueMultiplier.ArrowsIncrement = 1
        Me.txt_OutValueMultiplier.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_OutValueMultiplier.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_OutValueMultiplier.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_OutValueMultiplier.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_OutValueMultiplier.Increment = 0.2
        Me.txt_OutValueMultiplier.Location = New System.Drawing.Point(265, 69)
        Me.txt_OutValueMultiplier.MaxValue = 1000
        Me.txt_OutValueMultiplier.MinValue = 1
        Me.txt_OutValueMultiplier.Multiline = True
        Me.txt_OutValueMultiplier.Name = "txt_OutValueMultiplier"
        Me.txt_OutValueMultiplier.NumericValue = 10
        Me.txt_OutValueMultiplier.NumericValueInteger = 10
        Me.txt_OutValueMultiplier.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_OutValueMultiplier.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_OutValueMultiplier.RoundingStep = 0
        Me.txt_OutValueMultiplier.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_OutValueMultiplier.Size = New System.Drawing.Size(40, 16)
        Me.txt_OutValueMultiplier.SuppressZeros = True
        Me.txt_OutValueMultiplier.TabIndex = 83
        Me.txt_OutValueMultiplier.Text = "10"
        Me.txt_OutValueMultiplier.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_FirstSlotOnly
        '
        Me.chk_FirstSlotOnly.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_FirstSlotOnly.Checked = True
        Me.chk_FirstSlotOnly.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_FirstSlotOnly.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_FirstSlotOnly.Location = New System.Drawing.Point(186, 23)
        Me.chk_FirstSlotOnly.Name = "chk_FirstSlotOnly"
        Me.chk_FirstSlotOnly.Size = New System.Drawing.Size(116, 20)
        Me.chk_FirstSlotOnly.TabIndex = 82
        Me.chk_FirstSlotOnly.Text = "First slot only"
        Me.chk_FirstSlotOnly.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_FirstSlotOnly.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(180, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 16)
        Me.Label7.TabIndex = 81
        Me.Label7.Text = "First slot"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_FirstSlot
        '
        Me.txt_FirstSlot.ArrowsIncrement = 1
        Me.txt_FirstSlot.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_FirstSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FirstSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FirstSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FirstSlot.Increment = 0.2
        Me.txt_FirstSlot.Location = New System.Drawing.Point(265, 48)
        Me.txt_FirstSlot.MaxValue = 950
        Me.txt_FirstSlot.MinValue = 0
        Me.txt_FirstSlot.Multiline = True
        Me.txt_FirstSlot.Name = "txt_FirstSlot"
        Me.txt_FirstSlot.NumericValue = 1
        Me.txt_FirstSlot.NumericValueInteger = 1
        Me.txt_FirstSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FirstSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FirstSlot.RoundingStep = 0
        Me.txt_FirstSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FirstSlot.Size = New System.Drawing.Size(40, 16)
        Me.txt_FirstSlot.SuppressZeros = True
        Me.txt_FirstSlot.TabIndex = 80
        Me.txt_FirstSlot.Text = "1"
        Me.txt_FirstSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumAreaY
        '
        Me.txt_NumAreaY.ArrowsIncrement = 1
        Me.txt_NumAreaY.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_NumAreaY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_NumAreaY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_NumAreaY.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NumAreaY.Increment = 0.2
        Me.txt_NumAreaY.Location = New System.Drawing.Point(101, 49)
        Me.txt_NumAreaY.MaxValue = 16
        Me.txt_NumAreaY.MinValue = 1
        Me.txt_NumAreaY.Multiline = True
        Me.txt_NumAreaY.Name = "txt_NumAreaY"
        Me.txt_NumAreaY.NumericValue = 1
        Me.txt_NumAreaY.NumericValueInteger = 1
        Me.txt_NumAreaY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_NumAreaY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_NumAreaY.RoundingStep = 0
        Me.txt_NumAreaY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_NumAreaY.Size = New System.Drawing.Size(34, 16)
        Me.txt_NumAreaY.SuppressZeros = True
        Me.txt_NumAreaY.TabIndex = 71
        Me.txt_NumAreaY.Text = "0"
        Me.txt_NumAreaY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 16)
        Me.Label1.TabIndex = 70
        Me.Label1.Text = "Num area Y"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CheckBox_TrigShow2
        '
        Me.CheckBox_TrigShow2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_TrigShow2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_TrigShow2.Location = New System.Drawing.Point(12, 72)
        Me.CheckBox_TrigShow2.Name = "CheckBox_TrigShow2"
        Me.CheckBox_TrigShow2.Size = New System.Drawing.Size(111, 18)
        Me.CheckBox_TrigShow2.TabIndex = 80
        Me.CheckBox_TrigShow2.Text = "Triggers 2"
        Me.CheckBox_TrigShow2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_TrigShow2.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(9, 21)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(118, 16)
        Me.Label37.TabIndex = 86
        Me.Label37.Text = "Zoom quality"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(9, 39)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(117, 16)
        Me.Label38.TabIndex = 88
        Me.Label38.Text = "Motion pre filter"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(9, 57)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(116, 16)
        Me.Label39.TabIndex = 90
        Me.Label39.Text = "Motion post filter"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox10
        '
        Me.GroupBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox10.Controls.Add(Me.txt_PostFilterQuality)
        Me.GroupBox10.Controls.Add(Me.Label37)
        Me.GroupBox10.Controls.Add(Me.Label39)
        Me.GroupBox10.Controls.Add(Me.txt_ZoomQuality)
        Me.GroupBox10.Controls.Add(Me.txt_PreFilterQuality)
        Me.GroupBox10.Controls.Add(Me.Label38)
        Me.GroupBox10.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(10, 491)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(178, 78)
        Me.GroupBox10.TabIndex = 92
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Process quality"
        '
        'txt_PostFilterQuality
        '
        Me.txt_PostFilterQuality.ArrowsIncrement = 1
        Me.txt_PostFilterQuality.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_PostFilterQuality.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_PostFilterQuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_PostFilterQuality.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_PostFilterQuality.Increment = 0.2
        Me.txt_PostFilterQuality.Location = New System.Drawing.Point(130, 55)
        Me.txt_PostFilterQuality.MaxValue = 9
        Me.txt_PostFilterQuality.MinValue = 0
        Me.txt_PostFilterQuality.Multiline = True
        Me.txt_PostFilterQuality.Name = "txt_PostFilterQuality"
        Me.txt_PostFilterQuality.NumericValue = 0
        Me.txt_PostFilterQuality.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_PostFilterQuality.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_PostFilterQuality.RoundingStep = 0
        Me.txt_PostFilterQuality.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_PostFilterQuality.Size = New System.Drawing.Size(39, 16)
        Me.txt_PostFilterQuality.SuppressZeros = True
        Me.txt_PostFilterQuality.TabIndex = 91
        Me.txt_PostFilterQuality.Text = "0"
        Me.txt_PostFilterQuality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ZoomQuality
        '
        Me.txt_ZoomQuality.ArrowsIncrement = 1
        Me.txt_ZoomQuality.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_ZoomQuality.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ZoomQuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ZoomQuality.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ZoomQuality.Increment = 0.2
        Me.txt_ZoomQuality.Location = New System.Drawing.Point(130, 19)
        Me.txt_ZoomQuality.MaxValue = 9
        Me.txt_ZoomQuality.MinValue = 0
        Me.txt_ZoomQuality.Multiline = True
        Me.txt_ZoomQuality.Name = "txt_ZoomQuality"
        Me.txt_ZoomQuality.NumericValue = 1
        Me.txt_ZoomQuality.NumericValueInteger = 1
        Me.txt_ZoomQuality.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ZoomQuality.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ZoomQuality.RoundingStep = 0
        Me.txt_ZoomQuality.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ZoomQuality.Size = New System.Drawing.Size(39, 16)
        Me.txt_ZoomQuality.SuppressZeros = True
        Me.txt_ZoomQuality.TabIndex = 87
        Me.txt_ZoomQuality.Text = "1"
        Me.txt_ZoomQuality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_PreFilterQuality
        '
        Me.txt_PreFilterQuality.ArrowsIncrement = 1
        Me.txt_PreFilterQuality.BackColor = System.Drawing.Color.Cornsilk
        Me.txt_PreFilterQuality.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_PreFilterQuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_PreFilterQuality.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_PreFilterQuality.Increment = 0.2
        Me.txt_PreFilterQuality.Location = New System.Drawing.Point(130, 37)
        Me.txt_PreFilterQuality.MaxValue = 9
        Me.txt_PreFilterQuality.MinValue = 0
        Me.txt_PreFilterQuality.Multiline = True
        Me.txt_PreFilterQuality.Name = "txt_PreFilterQuality"
        Me.txt_PreFilterQuality.NumericValue = 1
        Me.txt_PreFilterQuality.NumericValueInteger = 1
        Me.txt_PreFilterQuality.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_PreFilterQuality.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_PreFilterQuality.RoundingStep = 0
        Me.txt_PreFilterQuality.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_PreFilterQuality.Size = New System.Drawing.Size(39, 16)
        Me.txt_PreFilterQuality.SuppressZeros = True
        Me.txt_PreFilterQuality.TabIndex = 89
        Me.txt_PreFilterQuality.Text = "1"
        Me.txt_PreFilterQuality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.CheckBox_EnableImage2)
        Me.GroupBox1.Controls.Add(Me.CheckBox_EnableImage1)
        Me.GroupBox1.Controls.Add(Me.CheckBox_TrigShow2)
        Me.GroupBox1.Controls.Add(Me.CheckBox_TrigShow1)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(199, 475)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(134, 94)
        Me.GroupBox1.TabIndex = 93
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enable"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txt_Zoom)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.txt_ShiftY)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.txt_ShiftX)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(24, 405)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(178, 80)
        Me.GroupBox3.TabIndex = 75
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Zoom and Crop"
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(677, 575)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino VideoInspector"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_DetectorMaxFps As MyTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label_FramesPerSec As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_DetectorGain As MyTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_DetectorShift As MyTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_DetectorRes As MyTextBox
    Friend WithEvents ComboBox_VideoInputDevice As MyComboBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolButton_HelpEng As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txt_ShiftX As MyTextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txt_ShiftY As MyTextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txt_Zoom As MyTextBox
    Friend WithEvents CheckBox_GrayScale As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FlipX As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FlipY As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Resolution As System.Windows.Forms.Label
    Friend WithEvents CheckBox_BlackOrWhite As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_Double As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Negative As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Positive As System.Windows.Forms.RadioButton
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txt_NumAreaX As MyTextBox
    Friend WithEvents CheckBox_TrigShow1 As System.Windows.Forms.CheckBox
    Friend WithEvents btn_VideoInControls As MyButton
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_VideoinControls As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_OpenDirectShowGraph As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tool_VideoInControls As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tool_DirectShowGraph As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_EnableImage1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_EnableImage2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txt_ZoomQuality As MyTextBox
    Friend WithEvents txt_PreFilterQuality As MyTextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txt_PostFilterQuality As MyTextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_TrigShow2 As System.Windows.Forms.CheckBox
    Friend WithEvents txt_NumAreaY As MyTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_FirstSlot As MyTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_SetRefImg As MyButton
    Friend WithEvents chk_FirstSlotOnly As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_OutValueMultiplier As MyTextBox
    Friend WithEvents Menu_Help_ProgramHelp_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolButton_HelpIta As System.Windows.Forms.ToolStripButton

End Class
