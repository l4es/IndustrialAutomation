
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices


Module ImageFilters

Friend Sub InitPictureboxImage(ByVal pbox As PictureBox)
    With pbox
        If .ClientSize.Height < 1 Then Return
        .Image = New Bitmap(.ClientSize.Width, .ClientSize.Height)
    End With
End Sub

    'Public Function ImageNegative(ByVal img As Image) As Image
    '    Dim w As Integer = img.Width
    '    Dim h As Integer = img.Height
    '    ' ---------------------------------------------------- a rectangle
    '    Dim rec As New Rectangle(0, 0, w, h)
    '    ' ---------------------------------------------------- the color matrix
    '    Dim cMatrix As ColorMatrix = New ColorMatrix(New Single()() _
    '                       {New Single() {-1, 0, 0, 0, 0}, _
    '                        New Single() {0, -1, 0, 0, 0}, _
    '                        New Single() {0, 0, -1, 0, 0}, _
    '                        New Single() {0, 0, 0, 1, 0}, _
    '                        New Single() {0, 0, 0, 0, 1}})
    '    ' ---------------------------------------------------- ImageAttributes object
    '    Dim imgAttr As New ImageAttributes()
    '    imgAttr.SetColorMatrix(cMatrix)
    '    ' ---------------------------------------------------- do the work
    '    Dim imgOut As New Bitmap(w, h)
    '    Dim g As Graphics = Graphics.FromImage(imgOut)
    '    g.DrawImage(img, rec, 0, 0, w + 1, h + 1, GraphicsUnit.Pixel, imgAttr)
    '    Return imgOut
    'End Function

    'Public Function ImageGray(ByVal img As Image) As Image
    '    Dim w As Integer = img.Width
    '    Dim h As Integer = img.Height
    '    ' ---------------------------------------------------- a rectangle
    '    Dim rec As New Rectangle(0, 0, w, h)
    '    ' ---------------------------------------------------- the color matrix
    '    Dim cMatrix As ColorMatrix = New ColorMatrix(New Single()() _
    '                           {New Single() {0.299, 0.299, 0.299, 0, 0}, _
    '                            New Single() {0.587, 0.587, 0.587, 0, 0}, _
    '                            New Single() {0.114, 0.114, 0.114, 0, 0}, _
    '                            New Single() {0, 0, 0, 1, 0}, _
    '                            New Single() {0, 0, 0, 0, 1}})
    '    ' ---------------------------------------------------- ImageAttributes object
    '    Dim imgAttr As New ImageAttributes()
    '    imgAttr.SetColorMatrix(cMatrix)
    '    ' ---------------------------------------------------- do the work
    '    Dim imgOut As New Bitmap(w, h)
    '    Dim g As Graphics = Graphics.FromImage(imgOut)
    '    g.DrawImage(img, rec, 0, 0, w + 1, h + 1, GraphicsUnit.Pixel, imgAttr)
    '    Return imgOut
    'End Function



    ' ================================================================================
    '  ROTAZIONI
    ' ================================================================================

    'Public Function ImageRotate(ByRef img As Image, ByVal angle As Single) As Image
    '    Dim bmp As New Bitmap(img)
    '    Dim g As Graphics = Graphics.FromImage(bmp)
    '    ' --------------------------------------------------- rotate from the middle
    '    g.Clear(Color.White)
    '    g.ResetTransform()
    '    g.TranslateTransform(img.Width \ 2, img.Height \ 2)
    '    g.RotateTransform(angle)
    '    ' --------------------------------------------------- draw centered
    '    g.DrawImage(img, -bmp.Width \ 2, -bmp.Height \ 2)
    '    Return bmp
    'End Function

    'Public Sub ImageRotateInPlace(ByRef img As Image, ByVal angle As Single)
    '    Dim bmp As New Bitmap(img)
    '    Dim g As Graphics = Graphics.FromImage(img)
    '    ' --------------------------------------------------- rotate from the middle
    '    g.Clear(Color.White)
    '    g.ResetTransform()
    '    g.TranslateTransform(bmp.Width \ 2, bmp.Height \ 2)
    '    g.RotateTransform(angle)
    '    ' --------------------------------------------------- draw centered
    '    g.DrawImage(bmp, -img.Width \ 2, -img.Height \ 2)
    'End Sub


    'http://msdn.microsoft.com/en-us/library/k0fsyd4e.aspx

    Private Sub SetQuality(ByVal g As Graphics, ByVal nQuality As Int32)
        Select Case nQuality
            Case 1
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.NearestNeighbor
            Case 2
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Low
            Case 3
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Bilinear
            Case 4
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.HighQualityBilinear
            Case 5
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.NearestNeighbor
            Case 6
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Bicubic
            Case 7
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.Bicubic
            Case 8
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.HighQualityBilinear
            Case 9
                g.CompositingQuality = CompositingQuality.HighQuality
                g.SmoothingMode = SmoothingMode.HighQuality
                g.InterpolationMode = InterpolationMode.HighQualityBicubic
                ' --------------------------------------------------------------- ( zero or > 9 ) 
            Case Else
                g.CompositingQuality = CompositingQuality.HighSpeed
                g.SmoothingMode = SmoothingMode.HighSpeed
                g.InterpolationMode = InterpolationMode.Low
        End Select
    End Sub




    Public Function ImageResize(ByRef img As Image, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32) As Image
        Dim bmp As New Bitmap(w, h)
        Dim g As Graphics = Graphics.FromImage(bmp)
        SetQuality(g, quality)
        g.DrawImage(img, 0, 0, w + 1, h + 1)
        Return bmp
    End Function

    'Public Sub ImageResizeInPlace(ByRef img As Image, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32)
    '    If img Is Nothing Then Exit Sub
    '    Dim bmp As New Bitmap(w, h)
    '    Dim g As Graphics = Graphics.FromImage(bmp)
    '    SetQuality(g, quality)
    '    g.DrawImage(img, 0, 0, w + 1, h + 1)
    '    img = bmp
    'End Sub

    Public Function ImageZoom(ByRef img As Image, ByVal zoom As Double, _
                                                    ByVal shiftX As Integer, _
                                                    ByVal shiftY As Integer, _
                                                    ByVal destW As Integer, _
                                                    ByVal destH As Integer, _
                                                    ByVal quality As Int32) As Image
        If img Is Nothing Then Return img
        '
        Dim bmp As New Bitmap(destW, destH)
        Dim g As Graphics = Graphics.FromImage(bmp)
        SetQuality(g, quality)

        Dim dest As Rectangle
        dest.X = 0
        dest.Y = 0
        dest.Width = destW
        dest.Height = destH

        Dim sx As Int32
        Dim sy As Int32
        Dim sw As Int32
        Dim sh As Int32

        sw = CInt(img.Width / zoom)
        sh = CInt(img.Height / zoom)
        sx = CInt((img.Width - sw) / 2 - shiftX)
        sy = CInt((img.Height - sh) / 2 - shiftY)

        Try
            g.DrawImage(img, dest, sx, sy, sw, sh, GraphicsUnit.Pixel)
        Catch
        End Try

        Return bmp
    End Function








    ' ================================================================================
    '  MOTION DETECTOR
    ' ================================================================================

    Private Declare Sub MotionDetector Lib "Videolib.dll" (ByVal start1 As IntPtr, _
                                                           ByVal start2 As IntPtr, _
                                                           ByVal height As Int32, _
                                                           ByVal width As Int32, _
                                                           ByVal offset As Int32, _
                                                           ByVal Shift As Int32, _
                                                           ByVal Gain As Int32, _
                                                           ByVal GrayScale As Int32, _
                                                           ByVal Invert As Int32, _
                                                           ByVal AllPositive As Int32, _
                                                           ByVal BlackOrWhite As Int32)


    Friend Function Image_DetectMotion(ByVal Image1 As Image, _
                                        ByVal Image2 As Image, _
                                        ByVal Shift As Int32, _
                                        ByVal Gain As Int32, _
                                        ByVal GrayScale As Boolean, _
                                        ByVal Invert As Boolean, _
                                        ByVal AllPositive As Boolean, _
                                        ByVal BlackOrWhite As Boolean) As Image

        If Image1 Is Nothing Or Image2 Is Nothing Then Return Nothing
        If Image1.Width <> Image2.Width Or Image1.Height <> Image2.Height Then Return Nothing


        ' Dim t As PrecisionTimer = New PrecisionTimer



        Dim b1 As Bitmap = CType(Image1.Clone, Bitmap)
        Dim b2 As Bitmap = CType(Image2, Bitmap)




        Dim bmData1 As BitmapData = b1.LockBits(New Rectangle(0, 0, b1.Width, b1.Height), _
                                               ImageLockMode.ReadWrite, _
                                               PixelFormat.Format24bppRgb)

        Dim bmData2 As BitmapData = b2.LockBits(New Rectangle(0, 0, b2.Width, b2.Height), _
                                               ImageLockMode.ReadWrite, _
                                               PixelFormat.Format24bppRgb)

        If bmData1.Width <> bmData2.Width Or bmData1.Height <> bmData2.Height Or bmData1.Stride <> bmData2.Stride Then Return Nothing

        Dim nHeight As Int32 = bmData1.Height
        Dim nWidth As Int32 = bmData1.Width * 3
        Dim nOffset As Int32 = bmData1.Stride - nWidth

        'Debug.Print(nOffset.ToString)

        ' Dim t As PrecisionTimer = New PrecisionTimer
        Try

            MotionDetector(bmData1.Scan0, _
                           bmData2.Scan0, _
                           nHeight, _
                           nWidth, _
                           nOffset, _
                           Shift, _
                           Gain, _
                           CInt(GrayScale), _
                           CInt(Invert), _
                           CInt(AllPositive), _
                           CInt(BlackOrWhite))

        Catch ex As Exception
            'MsgBox(Image1.Width & " " & Image2.Width & " " & Image1.Height & " " & Image2.Height)
            'MsgBox(bmData1.Width & " " & bmData2.Width & " " & bmData1.Height & " " & bmData2.Height & " " & bmData1.Stride & " " & bmData2.Stride)
            'MsgBox(bmData1.Scan0.ToString & " " & bmData2.Scan0.ToString)
            'MsgBox(ex.ToString)
            'System.Threading.Thread.Sleep(5000)
        End Try

        'Form_Main.Text = t.GetTimeMicrosec.ToString

        '
        b1.UnlockBits(bmData1)
        b2.UnlockBits(bmData2)
        '

        'Form_Main.Text = t.GetTimeMicrosec.ToString
        If Form_Main.txt_PostFilterQuality.NumericValueInteger > 0 Then
            Return ImageResize(CType(b1, Image), 320, 240, Form_Main.txt_PostFilterQuality.NumericValueInteger)
        Else
            Return b1
        End If
    End Function









    ' ================================================================================
    '  TEST BITMAP DATA
    '  Returns the number of pixels whith a value ( 0..255 ) more that TrigValue
    '  Pixels can be all gray pixels or individual r g b pixels
    ' ================================================================================

    Private Declare Function TestBitmapData Lib "Videolib.dll" (ByVal start As IntPtr, _
                                                                ByVal height As Int32, _
                                                                ByVal width As Int32, _
                                                                ByVal offset As Int32, _
                                                                ByVal trigvalue As Int32) As Int32


    ' ================================================================================
    '  TEST IMAGE
    ' ================================================================================

    Friend Function TestImage(ByVal img As Image, ByVal rec As Rectangle) As Int32

        If img Is Nothing Then Return 0
        If rec.Width < 2 Or rec.Height < 2 Then Return 0

        If Not New Rectangle(0, 0, img.Width, img.Height).Contains(rec) Then Return 0

        Dim b1 As Bitmap = CType(img, Bitmap)

        Dim bmData As BitmapData = b1.LockBits(rec, _
                                               ImageLockMode.ReadWrite, _
                                               PixelFormat.Format24bppRgb)

        Dim detected As Int32
        Dim nHeight As Int32 = bmData.Height
        Dim nWidth As Int32 = bmData.Width * 3
        Dim nOffset As Int32 = bmData.Stride - nWidth

        detected = TestBitmapData(bmData.Scan0, nHeight, nWidth, nOffset, 10)

        b1.UnlockBits(bmData)

        'Debug.Print(detected.ToString)

        Return detected
    End Function























End Module
