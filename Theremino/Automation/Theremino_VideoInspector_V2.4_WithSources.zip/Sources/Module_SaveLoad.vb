﻿
Imports System.Drawing.Imaging

Module Module_SaveLoad

    Friend Form_VideoInControls_VisibleAtStart As Boolean = True
    Friend EventsAreEnabled As Boolean = False
    Friend VideoInDevice As String = ""

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   Files
    ' =======================================================================================================
    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function
    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function
    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function
    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function

    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function



    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function

    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function

    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function

    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function

    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function

    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function

    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================

    Friend Sub Save_INI()
        '
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            Dim r As Rectangle
            r = GetFormRectangle(Form_Main)
            f.WriteLine(TabString("FormMain_Top", r.Top))
            f.WriteLine(TabString("FormMain_Left", r.Left))
            'f.WriteLine(TabString("FormMain_Width", r.Width))
            'f.WriteLine(TabString("FormMain_Height", r.Height))
            f.WriteLine(TabString("FormMain_WindowState", Form_Main.WindowState))
            '
            r = GetFormRectangle(Form_VideoInControls)
            f.WriteLine(TabString("Form_VideoInControls_Top", r.Top))
            f.WriteLine(TabString("Form_VideoInControls_Left", r.Left))
            f.WriteLine(TabString("Form_VideoInControls_VisibleAtStart", Form_VideoInControls.Visible And Form_VideoInControls.WindowState <> FormWindowState.Minimized))

            '
            f.WriteLine("")
            f.WriteLine(" Video Input Params")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("VideoInDevice", VideoInDevice))
            f.WriteLine(TabString("VideoFormat", VideoFormatParams.VideoFormat))
            f.WriteLine(TabString("VideoSize", VideoFormatParams.VideoSize))
            f.WriteLine(TabString("VideoFPS", VideoFormatParams.VideoFPS))
            '
            f.WriteLine("")
            f.WriteLine(" Crop Params")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("Zoom", Form_Main.txt_Zoom.NumericValue.ToString))
            f.WriteLine(TabString("ShiftX", Form_Main.txt_ShiftX.NumericValue.ToString))
            f.WriteLine(TabString("ShiftY", Form_Main.txt_ShiftY.NumericValue.ToString))
            f.WriteLine(TabString("FlipX", Form_Main.CheckBox_FlipX.Checked.ToString))
            f.WriteLine(TabString("FlipY", Form_Main.CheckBox_FlipY.Checked.ToString))
            '
            f.WriteLine("")
            f.WriteLine(" Motion detector")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("Positive", Form_Main.RadioButton_Positive.Checked.ToString))
            f.WriteLine(TabString("Negative", Form_Main.RadioButton_Negative.Checked.ToString))
            f.WriteLine(TabString("Double", Form_Main.RadioButton_Double.Checked.ToString))
            f.WriteLine(TabString("GrayScale", Form_Main.CheckBox_GrayScale.Checked.ToString))
            f.WriteLine(TabString("BlackOrWhite", Form_Main.CheckBox_BlackOrWhite.Checked.ToString))
            '
            f.WriteLine(TabString("DetectorShift", Form_Main.txt_DetectorShift.NumericValue.ToString))
            f.WriteLine(TabString("DetectorGain", Form_Main.txt_DetectorGain.NumericValue.ToString))
            f.WriteLine(TabString("DetectorRes", Form_Main.txt_DetectorRes.NumericValue.ToString))
            f.WriteLine(TabString("DetectorMaxFps", Form_Main.txt_DetectorMaxFps.NumericValueInteger.ToString))
            '
            f.WriteLine("")
            f.WriteLine(" Process quality")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("ZoomQuality", Form_Main.txt_ZoomQuality.NumericValueInteger.ToString))
            f.WriteLine(TabString("PreFilterQuality", Form_Main.txt_PreFilterQuality.NumericValueInteger.ToString))
            f.WriteLine(TabString("PostFilterQuality", Form_Main.txt_PostFilterQuality.NumericValueInteger.ToString))
            '
            f.WriteLine("")
            f.WriteLine(" Enable")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("EnableImage1", Form_Main.CheckBox_EnableImage1.Checked.ToString))
            f.WriteLine(TabString("EnableImage2", Form_Main.CheckBox_EnableImage2.Checked.ToString))
            f.WriteLine(TabString("TrigShow1", Form_Main.CheckBox_TrigShow1.Checked.ToString))
            f.WriteLine(TabString("TrigShow2", Form_Main.CheckBox_TrigShow2.Checked.ToString))
            '
            f.WriteLine("")
            f.WriteLine(" AreaParams")
            f.WriteLine("===========================================")
            f.WriteLine(TabString("NumAreaX", Form_Main.txt_NumAreaX.NumericValueInteger.ToString))
            f.WriteLine(TabString("NumAreaY", Form_Main.txt_NumAreaY.NumericValueInteger.ToString))
            f.WriteLine(TabString("FirstSlot", Form_Main.txt_FirstSlot.NumericValueInteger.ToString))
            f.WriteLine(TabString("FirstSlotOnly", Form_Main.chk_FirstSlotOnly.Checked.ToString))
            f.WriteLine(TabString("OutValueMultiplier", Form_Main.txt_OutValueMultiplier.NumericValue.ToString))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------------------------- defaults
        VideoInDevice = ""
        VideoFormatParams.VideoFormat = "RGB42"
        VideoFormatParams.VideoSize = "320 x 240"
        VideoFormatParams.VideoFPS = "30"
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"

        If My.Computer.FileSystem.FileExists(iniFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)
            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "FormMain_Top" : Form_Main.Top = CInt(Val(l))
                    Case "FormMain_Left" : Form_Main.Left = CInt(Val(l))
                        'Case "FormMain_Width" : Form_Main.Width = CInt(Val(l))
                        'Case "FormMain_Height" : Form_Main.Height = CInt(Val(l))
                    Case "FormMain_WindowState" : Form_Main.WindowState = CType((Val(l)), FormWindowState)
                        ' ------------------------------------------------------------------------------ 
                    Case "Form_VideoInControls_Top" : Form_VideoInControls.Top = Val_Int(l)
                    Case "Form_VideoInControls_Left" : Form_VideoInControls.Left = Val_Int(l)
                    Case "Form_VideoInControls_VisibleAtStart" : Form_VideoInControls_VisibleAtStart = l = "True"
                        ' ------------------------------------------------------------------------------ Video in device
                    Case "VideoInDevice" : VideoInDevice = l
                    Case "VideoFormat" : VideoFormatParams.VideoFormat = l
                    Case "VideoSize" : VideoFormatParams.VideoSize = l
                    Case "VideoFPS" : VideoFormatParams.VideoFPS = l
                        ' ------------------------------------------------------------------------------ Image crop
                    Case "Zoom" : Form_Main.txt_Zoom.NumericValue = Val_Double(l)
                    Case "ShiftX" : Form_Main.txt_ShiftX.NumericValue = Val_Double(l)
                    Case "ShiftY" : Form_Main.txt_ShiftY.NumericValue = Val_Double(l)
                    Case "FlipX" : Form_Main.CheckBox_FlipX.Checked = l = "True"
                    Case "FlipY" : Form_Main.CheckBox_FlipY.Checked = l = "True"
                        ' ------------------------------------------------------------------------------ Motion detector 
                    Case "Positive" : Form_Main.RadioButton_Positive.Checked = l = "True"
                    Case "Negative" : Form_Main.RadioButton_Negative.Checked = l = "True"
                    Case "Double" : Form_Main.RadioButton_Double.Checked = l = "True"
                    Case "GrayScale" : Form_Main.CheckBox_GrayScale.Checked = l = "True"
                    Case "BlackOrWhite" : Form_Main.CheckBox_BlackOrWhite.Checked = l = "True"
                        '
                    Case "DetectorShift" : Form_Main.txt_DetectorShift.NumericValue = Val_Double(l)
                    Case "DetectorGain" : Form_Main.txt_DetectorGain.NumericValue = Val_Double(l)
                    Case "DetectorRes" : Form_Main.txt_DetectorRes.NumericValue = Val_Double(l)
                    Case "DetectorMaxFps" : Form_Main.txt_DetectorMaxFps.NumericValueInteger = Val_Int(l)
                        ' ------------------------------------------------------------------------------ Process quality
                    Case "ZoomQuality" : Form_Main.txt_ZoomQuality.NumericValueInteger = Val_Int(l)
                    Case "PreFilterQuality" : Form_Main.txt_PreFilterQuality.NumericValueInteger = Val_Int(l)
                    Case "PostFilterQuality" : Form_Main.txt_PostFilterQuality.NumericValueInteger = Val_Int(l)
                        ' ------------------------------------------------------------------------------ Enable
                    Case "EnableImage1" : Form_Main.CheckBox_EnableImage1.Checked = l = "True"
                    Case "EnableImage2" : Form_Main.CheckBox_EnableImage2.Checked = l = "True"
                    Case "TrigShow1" : Form_Main.CheckBox_TrigShow1.Checked = l = "True"
                    Case "TrigShow2" : Form_Main.CheckBox_TrigShow2.Checked = l = "True"
                        ' ------------------------------------------------------------------------------ Area params
                    Case "NumAreaX" : Form_Main.txt_NumAreaX.NumericValueInteger = Val_Int(l)
                    Case "NumAreaY" : Form_Main.txt_NumAreaY.NumericValueInteger = Val_Int(l)
                    Case "FirstSlot" : Form_Main.txt_FirstSlot.NumericValueInteger = Val_Int(l)
                    Case "FirstSlotOnly" : Form_Main.chk_FirstSlotOnly.Checked = l = "True"
                    Case "OutValueMultiplier" : Form_Main.txt_OutValueMultiplier.NumericValue = Val_Double(l)
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form_Main)
        LimitFormPosition(Form_VideoInControls)
    End Sub


    ' ==================================================================================================
    '  SAVE IMAGE
    ' ==================================================================================================
    Public Sub SaveImage(ByVal img As Image, _
                         ByVal filename As String, _
                         ByVal extension As String, _
                         ByVal Quality As Int32)

        extension = LCase(extension)
        filename = RemoveExtension(filename)
        filename += "." & extension
        '
        If img Is Nothing Then Exit Sub
        Try
            File_Kill(filename)
            If extension = "jpg" Then
                Dim ImageEncoders() As ImageCodecInfo = ImageCodecInfo.GetImageEncoders()
                Dim myEncoder As System.Drawing.Imaging.Encoder = System.Drawing.Imaging.Encoder.Quality
                Dim myEncoderParameters As New EncoderParameters(1)
                Dim myEncoderParameter As New EncoderParameter(myEncoder, Quality)
                myEncoderParameters.Param(0) = myEncoderParameter
                img.Save(filename, ImageEncoders(1), myEncoderParameters)
            Else
                img.Save(filename, ImageFormatFromFileExtension(extension))
            End If
        Catch
            MsgBox("Image save error", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Function ImageFormatFromFileExtension(ByVal extension As String) As ImageFormat
        Select Case LCase(extension)
            Case "jpg" : Return ImageFormat.Jpeg
            Case "png" : Return ImageFormat.Png
            Case "tiff" : Return ImageFormat.Tiff
            Case "exif" : Return ImageFormat.Exif
            Case "emf" : Return ImageFormat.Emf
            Case "wmf" : Return ImageFormat.Wmf
            Case "gif" : Return ImageFormat.Gif
            Case "bmp" : Return ImageFormat.Bmp
                'Case "ico" : Return ImageFormat.Icon
            Case Else : Return ImageFormat.Jpeg
        End Select
    End Function

    Friend Sub File_Kill(ByVal filename As String)
        If My.Computer.FileSystem.FileExists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
        End If
    End Sub


End Module
