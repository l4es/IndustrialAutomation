﻿'Imports System.Drawing
'Imports System.Drawing.Imaging
'Imports System.Drawing.Drawing2D
'Imports System.Runtime.InteropServices

Module Module_TriggerAreas

    Friend Structure TrigArea
        Friend Rec As Rectangle
        Friend Triggered As Boolean
    End Structure

    Friend TrigAreas(MaxAreas - 1) As TrigArea
    Const MaxAreas As Int32 = 256
    Private UsedAreas As Int32 = 0
    Private FirstSlot As Int32 = 1

    Friend Sub TriggerAreas_Init(ByVal imgW As Single, ByVal imgH As Single, ByVal nx As Int32, ByVal ny As Int32)
        Dim areaX As Single
        Dim areaY As Single
        Dim areaW As Single = imgW / nx
        Dim areaH As Single = imgH / ny
        UsedAreas = 0
        areaX = 0
        For y As Int32 = 0 To ny - 1
            areaX = 0
            For x As Int32 = 0 To nx - 1
                With TrigAreas(UsedAreas)
                    .Rec.X = CInt(areaX)
                    .Rec.Y = CInt(areaY)
                    .Rec.Width = CInt(areaW - 2.0F)
                    .Rec.Height = CInt(areaH - 2.0F)
                End With
                UsedAreas += 1
                areaX += areaW
            Next
            areaY += areaH
        Next
    End Sub

    Friend Sub TriggerAreas_Show(ByVal img As Image, Optional ByVal ksize As Double = 1)
        '
        Dim r As Rectangle
        Dim pt As Pen = New Pen(Color.FromArgb(255, 70, 0), img.Width \ 100)
        Dim p As Pen = New Pen(Color.FromArgb(130, 80, 0))
        Dim g As Graphics = Graphics.FromImage(img)
        '
        For i As Int32 = 0 To UsedAreas - 1
            With TrigAreas(i)
                '
                r = .Rec
                If ksize <> 1 Then
                    r.X = CInt(r.X * ksize)
                    r.Y = CInt(r.Y * ksize)
                    r.Width = CInt(r.Width * ksize)
                    r.Height = CInt(r.Height * ksize)
                End If
                '
                If .Triggered Then
                    g.DrawRectangle(pt, r)
                Else
                    g.DrawRectangle(p, r)
                End If
            End With
        Next
    End Sub

    Friend Sub TriggerAreas_ResetTriggerFlags()
        For i As Int32 = 0 To TrigAreas.Length - 1
            TrigAreas(i).Triggered = False
        Next
    End Sub

    Friend Sub TriggerAreas_SetFirstSlot(ByVal n As Int32)
        FirstSlot = n
    End Sub


    Friend Sub TriggerAreas_TestImage(ByVal img As Image)
        '
        'Dim t As PrecisionTimer = New PrecisionTimer
        '
        Dim v As Int32
        Dim k As Int32 = Form_Main.txt_OutValueMultiplier.NumericValueInteger
        '
        If Form_Main.chk_FirstSlotOnly.Checked Then
            Dim maxvalue As Int32 = 0
            For i As Int32 = 0 To UsedAreas - 1
                With TrigAreas(i)
                    v = TestImage(img, .Rec)
                    If v > maxvalue Then maxvalue = v
                    If v > 100 Then .Triggered = True
                End With
            Next
            WriteToSlot(0, maxvalue * k)
        Else
            For i As Int32 = 0 To UsedAreas - 1
                With TrigAreas(i)
                    v = TestImage(img, .Rec)
                    WriteToSlot(i, v * k)
                    If v > 100 Then .Triggered = True
                End With
            Next
        End If
        '
        't.DebugPrintMicrosec()
        'Form_Main.Text = t.GetTimeMicrosec.ToString
    End Sub


    Friend Sub TriggerAreas_TriggerWithMouse(ByVal pbox As PictureBox, ByVal mousePoint As Point, Optional ByVal ksize As Double = 1)

        If TrigAreas Is Nothing Then Exit Sub
        '
        Dim scale As Double = pbox.Image.Width / pbox.Width * ksize
        mousePoint.X = CInt(mousePoint.X * scale)
        mousePoint.Y = CInt(mousePoint.Y * scale)
        '
        If Form_Main.chk_FirstSlotOnly.Checked Then
            For i As Int32 = 0 To UsedAreas - 1
                With TrigAreas(i)
                    If .Rec.Contains(mousePoint) Then
                        .Triggered = True
                    End If
                End With
            Next
            WriteToSlot(0, 1000)
        Else
            For i As Int32 = 0 To UsedAreas - 1
                With TrigAreas(i)
                    If .Rec.Contains(mousePoint) Then
                        .Triggered = True
                        WriteToSlot(i, 1000)
                    Else
                        WriteToSlot(i, 0)
                    End If
                End With
            Next
        End If
 
    End Sub

    Private Sub WriteToSlot(ByVal AreaIndex As Int32, ByVal value As Int32)
        Slots.WriteSlot(AreaIndex + FirstSlot, value)
    End Sub

End Module
