﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.mainMenu = New System.Windows.Forms.MainMenu(Me.components)
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.mnuExit = New System.Windows.Forms.MenuItem
        Me.mnuDevices = New System.Windows.Forms.MenuItem
        Me.mnuVideoDevices = New System.Windows.Forms.MenuItem
        Me.mnuAudioDevices = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.mnuVideoCompressors = New System.Windows.Forms.MenuItem
        Me.mnuAudioCompressors = New System.Windows.Forms.MenuItem
        Me.menuItem7 = New System.Windows.Forms.MenuItem
        Me.mnuVideoSources = New System.Windows.Forms.MenuItem
        Me.mnuFrameSizes = New System.Windows.Forms.MenuItem
        Me.mnuFrameRates = New System.Windows.Forms.MenuItem
        Me.mnuVideoCaps = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        Me.mnuAudioSources = New System.Windows.Forms.MenuItem
        Me.mnuAudioChannels = New System.Windows.Forms.MenuItem
        Me.mnuAudioSamplingRate = New System.Windows.Forms.MenuItem
        Me.mnuAudioSampleSizes = New System.Windows.Forms.MenuItem
        Me.mnuAudioCaps = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.mnuChannel = New System.Windows.Forms.MenuItem
        Me.mnuInputType = New System.Windows.Forms.MenuItem
        Me.menuItem6 = New System.Windows.Forms.MenuItem
        Me.mnuPropertyPages = New System.Windows.Forms.MenuItem
        Me.menuItem8 = New System.Windows.Forms.MenuItem
        Me.mnuPreview = New System.Windows.Forms.MenuItem
        Me.panelVideo = New System.Windows.Forms.Panel
        Me.label1 = New System.Windows.Forms.Label
        Me.txtFilename = New System.Windows.Forms.TextBox
        Me.btnCue = New System.Windows.Forms.Button
        Me.btnStop = New System.Windows.Forms.Button
        Me.btnStart = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.mnuDevices, Me.menuItem7})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuExit})
        Me.menuItem1.Text = "File"
        '
        'mnuExit
        '
        Me.mnuExit.Index = 0
        Me.mnuExit.Text = "E&xit"
        '
        'mnuDevices
        '
        Me.mnuDevices.Index = 1
        Me.mnuDevices.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuVideoDevices, Me.mnuAudioDevices, Me.menuItem4, Me.mnuVideoCompressors, Me.mnuAudioCompressors})
        Me.mnuDevices.Text = "Devices"
        '
        'mnuVideoDevices
        '
        Me.mnuVideoDevices.Index = 0
        Me.mnuVideoDevices.Text = "Video Devices"
        '
        'mnuAudioDevices
        '
        Me.mnuAudioDevices.Index = 1
        Me.mnuAudioDevices.Text = "Audio Devices"
        '
        'menuItem4
        '
        Me.menuItem4.Index = 2
        Me.menuItem4.Text = "-"
        '
        'mnuVideoCompressors
        '
        Me.mnuVideoCompressors.Index = 3
        Me.mnuVideoCompressors.Text = "Video Compressors"
        '
        'mnuAudioCompressors
        '
        Me.mnuAudioCompressors.Index = 4
        Me.mnuAudioCompressors.Text = "Audio Compressors"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 2
        Me.menuItem7.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuVideoSources, Me.mnuFrameSizes, Me.mnuFrameRates, Me.mnuVideoCaps, Me.menuItem5, Me.mnuAudioSources, Me.mnuAudioChannels, Me.mnuAudioSamplingRate, Me.mnuAudioSampleSizes, Me.mnuAudioCaps, Me.menuItem3, Me.mnuChannel, Me.mnuInputType, Me.menuItem6, Me.mnuPropertyPages, Me.menuItem8, Me.mnuPreview})
        Me.menuItem7.Text = "Options"
        '
        'mnuVideoSources
        '
        Me.mnuVideoSources.Index = 0
        Me.mnuVideoSources.Text = "Video Sources"
        '
        'mnuFrameSizes
        '
        Me.mnuFrameSizes.Index = 1
        Me.mnuFrameSizes.Text = "Video Frame Size"
        '
        'mnuFrameRates
        '
        Me.mnuFrameRates.Index = 2
        Me.mnuFrameRates.Text = "Video Frame Rate"
        '
        'mnuVideoCaps
        '
        Me.mnuVideoCaps.Index = 3
        Me.mnuVideoCaps.Text = "Video Capabilities..."
        '
        'menuItem5
        '
        Me.menuItem5.Index = 4
        Me.menuItem5.Text = "-"
        '
        'mnuAudioSources
        '
        Me.mnuAudioSources.Index = 5
        Me.mnuAudioSources.Text = "Audio Sources"
        '
        'mnuAudioChannels
        '
        Me.mnuAudioChannels.Index = 6
        Me.mnuAudioChannels.Text = "Audio Channels"
        '
        'mnuAudioSamplingRate
        '
        Me.mnuAudioSamplingRate.Index = 7
        Me.mnuAudioSamplingRate.Text = "Audio Sampling Rate"
        '
        'mnuAudioSampleSizes
        '
        Me.mnuAudioSampleSizes.Index = 8
        Me.mnuAudioSampleSizes.Text = "Audio Sample Size"
        '
        'mnuAudioCaps
        '
        Me.mnuAudioCaps.Index = 9
        Me.mnuAudioCaps.Text = "Audio Capabilities..."
        '
        'menuItem3
        '
        Me.menuItem3.Index = 10
        Me.menuItem3.Text = "-"
        '
        'mnuChannel
        '
        Me.mnuChannel.Index = 11
        Me.mnuChannel.Text = "TV Tuner Channel"
        '
        'mnuInputType
        '
        Me.mnuInputType.Index = 12
        Me.mnuInputType.Text = "TV Tuner Input Type"
        '
        'menuItem6
        '
        Me.menuItem6.Index = 13
        Me.menuItem6.Text = "-"
        '
        'mnuPropertyPages
        '
        Me.mnuPropertyPages.Index = 14
        Me.mnuPropertyPages.Text = "PropertyPages"
        '
        'menuItem8
        '
        Me.menuItem8.Index = 15
        Me.menuItem8.Text = "-"
        '
        'mnuPreview
        '
        Me.mnuPreview.Index = 16
        Me.mnuPreview.Text = "Preview"
        '
        'panelVideo
        '
        Me.panelVideo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelVideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelVideo.Location = New System.Drawing.Point(0, 4)
        Me.panelVideo.Name = "panelVideo"
        Me.panelVideo.Size = New System.Drawing.Size(541, 346)
        Me.panelVideo.TabIndex = 7
        '
        'label1
        '
        Me.label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label1.Location = New System.Drawing.Point(10, 360)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(57, 16)
        Me.label1.TabIndex = 9
        Me.label1.Text = "Filename:"
        '
        'txtFilename
        '
        Me.txtFilename.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFilename.Location = New System.Drawing.Point(65, 358)
        Me.txtFilename.Name = "txtFilename"
        Me.txtFilename.Size = New System.Drawing.Size(192, 20)
        Me.txtFilename.TabIndex = 8
        Me.txtFilename.Text = ".\Video\Test1.avi"
        '
        'btnCue
        '
        Me.btnCue.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCue.Location = New System.Drawing.Point(280, 356)
        Me.btnCue.Name = "btnCue"
        Me.btnCue.Size = New System.Drawing.Size(80, 24)
        Me.btnCue.TabIndex = 13
        Me.btnCue.Text = "Cue"
        '
        'btnStop
        '
        Me.btnStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnStop.Location = New System.Drawing.Point(456, 356)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(80, 24)
        Me.btnStop.TabIndex = 11
        Me.btnStop.Text = "Stop"
        '
        'btnStart
        '
        Me.btnStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnStart.Location = New System.Drawing.Point(368, 356)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(80, 24)
        Me.btnStart.TabIndex = 10
        Me.btnStart.Text = "Start"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(540, 383)
        Me.Controls.Add(Me.btnCue)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtFilename)
        Me.Controls.Add(Me.panelVideo)
        Me.Menu = Me.mainMenu
        Me.MinimumSize = New System.Drawing.Size(388, 253)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.Text = "Theremino Video Recorder"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents mainMenu As System.Windows.Forms.MainMenu
    Private WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Private WithEvents mnuExit As System.Windows.Forms.MenuItem
    Private WithEvents mnuDevices As System.Windows.Forms.MenuItem
    Private WithEvents mnuVideoDevices As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioDevices As System.Windows.Forms.MenuItem
    Private WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Private WithEvents mnuVideoCompressors As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioCompressors As System.Windows.Forms.MenuItem
    Private WithEvents menuItem7 As System.Windows.Forms.MenuItem
    Private WithEvents mnuVideoSources As System.Windows.Forms.MenuItem
    Private WithEvents mnuFrameSizes As System.Windows.Forms.MenuItem
    Private WithEvents mnuFrameRates As System.Windows.Forms.MenuItem
    Private WithEvents mnuVideoCaps As System.Windows.Forms.MenuItem
    Private WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioSources As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioChannels As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioSamplingRate As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioSampleSizes As System.Windows.Forms.MenuItem
    Private WithEvents mnuAudioCaps As System.Windows.Forms.MenuItem
    Private WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Private WithEvents mnuChannel As System.Windows.Forms.MenuItem
    Private WithEvents mnuInputType As System.Windows.Forms.MenuItem
    Private WithEvents menuItem6 As System.Windows.Forms.MenuItem
    Private WithEvents mnuPropertyPages As System.Windows.Forms.MenuItem
    Private WithEvents menuItem8 As System.Windows.Forms.MenuItem
    Private WithEvents mnuPreview As System.Windows.Forms.MenuItem
    Private WithEvents panelVideo As System.Windows.Forms.Panel
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents txtFilename As System.Windows.Forms.TextBox
    Private WithEvents btnCue As System.Windows.Forms.Button
    Private WithEvents btnStop As System.Windows.Forms.Button
    Private WithEvents btnStart As System.Windows.Forms.Button

End Class
