﻿Imports DirectX.Capture

Public Class Form1

    Private WithEvents CAP As Capture = Nothing
    Private filters As New Filters()

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CAP = New Capture(filters.VideoInputDevices(0), filters.AudioInputDevices(0))
        UpdateMenu()
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If CAP IsNot Nothing Then
            CAP.Stop()
        End If
    End Sub

    Private Sub btnCue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCue.Click
        Try
            If CAP Is Nothing Then
                Throw New ApplicationException("Please select a video and/or audio device.")
            End If
            If Not CAP.Cued Then
                CAP.Filename = txtFilename.Text
            End If
            CAP.Cue()
            btnCue.Enabled = False
            MessageBox.Show("Ready to capture." & vbLf & vbLf & "Use Cue() before Start() to " & "do all the preparation work that needs to be done to start a " & "capture. Now, when you click Start the capture will begin faster " & "than if you had just clicked Start. Using Cue() is completely " & "optional. The downside to using Cue() is the preview is disabled until " & "the capture begins.")
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub btnStart_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Try
            If CAP Is Nothing Then
                Throw New ApplicationException("Please select a video and/or audio device.")
            End If
            If Not CAP.Cued Then
                CAP.Filename = txtFilename.Text
            End If
            CAP.Start()
            btnCue.Enabled = False
            btnStart.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub btnStop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnStop.Click
        Try
            If CAP Is Nothing Then
                Throw New ApplicationException("Please select a video and/or audio device.")
            End If
            CAP.[Stop]()
            btnCue.Enabled = True
            btnStart.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub UpdateMenu()
        Dim m As MenuItem
        Dim f As Filter
        Dim s As Source
        Dim current As Source
        Dim p As PropertyPage
        Dim oldPreviewWindow As Control = Nothing
        ' --------------------------------------------------------------------- Disable preview to avoid additional flashes
        If CAP IsNot Nothing Then
            oldPreviewWindow = CAP.PreviewWindow
            CAP.PreviewWindow = Nothing
        End If
        ' --------------------------------------------------------------------- Load video devices
        Dim videoDevice As Filter = Nothing
        If CAP IsNot Nothing Then
            videoDevice = CAP.VideoDevice
        End If
        mnuVideoDevices.MenuItems.Clear()
        m = New MenuItem("(None)", New EventHandler(AddressOf mnuVideoDevices_Click))
        m.Checked = (videoDevice Is Nothing)
        mnuVideoDevices.MenuItems.Add(m)
        For c As Integer = 0 To filters.VideoInputDevices.Count - 1
            f = filters.VideoInputDevices(c)
            m = New MenuItem(f.Name, New EventHandler(AddressOf mnuVideoDevices_Click))
            m.Checked = (videoDevice Is f)
            mnuVideoDevices.MenuItems.Add(m)
        Next
        mnuVideoDevices.Enabled = (filters.VideoInputDevices.Count > 0)
        ' --------------------------------------------------------------------- Load audio devices
        Dim audioDevice As Filter = Nothing
        If CAP IsNot Nothing Then
            audioDevice = CAP.AudioDevice
        End If
        mnuAudioDevices.MenuItems.Clear()
        m = New MenuItem("(None)", New EventHandler(AddressOf mnuAudioDevices_Click))
        m.Checked = (audioDevice Is Nothing)
        mnuAudioDevices.MenuItems.Add(m)
        For c As Integer = 0 To filters.AudioInputDevices.Count - 1
            f = filters.AudioInputDevices(c)
            m = New MenuItem(f.Name, New EventHandler(AddressOf mnuAudioDevices_Click))
            m.Checked = (audioDevice Is f)
            mnuAudioDevices.MenuItems.Add(m)
        Next
        mnuAudioDevices.Enabled = (filters.AudioInputDevices.Count > 0)
        ' --------------------------------------------------------------------- Load video compressors
        Try
            mnuVideoCompressors.MenuItems.Clear()
            m = New MenuItem("(None)", New EventHandler(AddressOf mnuVideoCompressors_Click))
            m.Checked = (CAP.VideoCompressor Is Nothing)
            mnuVideoCompressors.MenuItems.Add(m)
            For c As Integer = 0 To filters.VideoCompressors.Count - 1
                f = filters.VideoCompressors(c)
                m = New MenuItem(f.Name, New EventHandler(AddressOf mnuVideoCompressors_Click))
                m.Checked = (CAP.VideoCompressor Is f)
                mnuVideoCompressors.MenuItems.Add(m)
            Next
            mnuVideoCompressors.Enabled = ((CAP.VideoDevice IsNot Nothing) AndAlso (filters.VideoCompressors.Count > 0))
        Catch
            mnuVideoCompressors.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load audio compressors
        Try
            mnuAudioCompressors.MenuItems.Clear()
            m = New MenuItem("(None)", New EventHandler(AddressOf mnuAudioCompressors_Click))
            m.Checked = (CAP.AudioCompressor Is Nothing)
            mnuAudioCompressors.MenuItems.Add(m)
            For c As Integer = 0 To filters.AudioCompressors.Count - 1
                f = filters.AudioCompressors(c)
                m = New MenuItem(f.Name, New EventHandler(AddressOf mnuAudioCompressors_Click))
                m.Checked = (CAP.AudioCompressor Is f)
                mnuAudioCompressors.MenuItems.Add(m)
            Next
            mnuAudioCompressors.Enabled = ((CAP.AudioDevice IsNot Nothing) AndAlso (filters.AudioCompressors.Count > 0))
        Catch
            mnuAudioCompressors.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load video sources
        Try
            mnuVideoSources.MenuItems.Clear()
            current = CAP.VideoSource
            For c As Integer = 0 To CAP.VideoSources.Count - 1
                s = CAP.VideoSources(c)
                m = New MenuItem(s.Name, New EventHandler(AddressOf mnuVideoSources_Click))
                m.Checked = (current Is s)
                mnuVideoSources.MenuItems.Add(m)
            Next
            mnuVideoSources.Enabled = (CAP.VideoSources.Count > 0)
        Catch
            mnuVideoSources.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load audio sources
        Try
            mnuAudioSources.MenuItems.Clear()
            current = CAP.AudioSource
            For c As Integer = 0 To CAP.AudioSources.Count - 1
                s = CAP.AudioSources(c)
                m = New MenuItem(s.Name, New EventHandler(AddressOf mnuAudioSources_Click))
                m.Checked = (current Is s)
                mnuAudioSources.MenuItems.Add(m)
            Next
            mnuAudioSources.Enabled = (CAP.AudioSources.Count > 0)
        Catch
            mnuAudioSources.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load frame rates
        Try
            mnuFrameRates.MenuItems.Clear()
            Dim frameRate As Integer = CInt(Math.Truncate(CAP.FrameRate * 1000))
            m = New MenuItem("15 fps", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 15000)
            mnuFrameRates.MenuItems.Add(m)
            m = New MenuItem("24 fps (Film)", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 24000)
            mnuFrameRates.MenuItems.Add(m)
            m = New MenuItem("25 fps (PAL)", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 25000)
            mnuFrameRates.MenuItems.Add(m)
            m = New MenuItem("29.997 fps (NTSC)", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 29997)
            mnuFrameRates.MenuItems.Add(m)
            m = New MenuItem("30 fps (~NTSC)", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 30000)
            mnuFrameRates.MenuItems.Add(m)
            m = New MenuItem("59.994 fps (2xNTSC)", New EventHandler(AddressOf mnuFrameRates_Click))
            m.Checked = (frameRate = 59994)
            mnuFrameRates.MenuItems.Add(m)
            mnuFrameRates.Enabled = True
        Catch
            mnuFrameRates.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load frame sizes
        Try
            mnuFrameSizes.MenuItems.Clear()
            Dim frameSize As Size = CAP.FrameSize
            m = New MenuItem("160 x 120", New EventHandler(AddressOf mnuFrameSizes_Click))
            m.Checked = (frameSize = New Size(160, 120))
            mnuFrameSizes.MenuItems.Add(m)
            m = New MenuItem("320 x 240", New EventHandler(AddressOf mnuFrameSizes_Click))
            m.Checked = (frameSize = New Size(320, 240))
            mnuFrameSizes.MenuItems.Add(m)
            m = New MenuItem("640 x 480", New EventHandler(AddressOf mnuFrameSizes_Click))
            m.Checked = (frameSize = New Size(640, 480))
            mnuFrameSizes.MenuItems.Add(m)
            m = New MenuItem("1024 x 768", New EventHandler(AddressOf mnuFrameSizes_Click))
            m.Checked = (frameSize = New Size(1024, 768))
            mnuFrameSizes.MenuItems.Add(m)
            mnuFrameSizes.Enabled = True
        Catch
            mnuFrameSizes.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load audio channels
        Try
            mnuAudioChannels.MenuItems.Clear()
            Dim audioChannels As Short = CAP.AudioChannels
            m = New MenuItem("Mono", New EventHandler(AddressOf mnuAudioChannels_Click))
            m.Checked = (audioChannels = 1)
            mnuAudioChannels.MenuItems.Add(m)
            m = New MenuItem("Stereo", New EventHandler(AddressOf mnuAudioChannels_Click))
            m.Checked = (audioChannels = 2)
            mnuAudioChannels.MenuItems.Add(m)
            mnuAudioChannels.Enabled = True
        Catch
            mnuAudioChannels.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load audio sampling rate
        Try
            mnuAudioSamplingRate.MenuItems.Clear()
            Dim samplingRate As Integer = CAP.AudioSamplingRate
            m = New MenuItem("8 kHz", New EventHandler(AddressOf mnuAudioSamplingRate_Click))
            m.Checked = (samplingRate = 8000)
            mnuAudioSamplingRate.MenuItems.Add(m)
            m = New MenuItem("11.025 kHz", New EventHandler(AddressOf mnuAudioSamplingRate_Click))
            m.Checked = (CAP.AudioSamplingRate = 11025)
            mnuAudioSamplingRate.MenuItems.Add(m)
            m = New MenuItem("22.05 kHz", New EventHandler(AddressOf mnuAudioSamplingRate_Click))
            m.Checked = (CAP.AudioSamplingRate = 22050)
            mnuAudioSamplingRate.MenuItems.Add(m)
            m = New MenuItem("44.1 kHz", New EventHandler(AddressOf mnuAudioSamplingRate_Click))
            m.Checked = (CAP.AudioSamplingRate = 44100)
            mnuAudioSamplingRate.MenuItems.Add(m)
            mnuAudioSamplingRate.Enabled = True
        Catch
            mnuAudioSamplingRate.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load audio sample sizes
        Try
            mnuAudioSampleSizes.MenuItems.Clear()
            Dim sampleSize As Short = CAP.AudioSampleSize
            m = New MenuItem("8 bit", New EventHandler(AddressOf mnuAudioSampleSizes_Click))
            m.Checked = (sampleSize = 8)
            mnuAudioSampleSizes.MenuItems.Add(m)
            m = New MenuItem("16 bit", New EventHandler(AddressOf mnuAudioSampleSizes_Click))
            m.Checked = (sampleSize = 16)
            mnuAudioSampleSizes.MenuItems.Add(m)
            mnuAudioSampleSizes.Enabled = True
        Catch
            mnuAudioSampleSizes.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load property pages
        Try
            mnuPropertyPages.MenuItems.Clear()
            For c As Integer = 0 To CAP.PropertyPages.Count - 1
                p = CAP.PropertyPages(c)
                m = New MenuItem(p.Name & "...", New EventHandler(AddressOf mnuPropertyPages_Click))
                mnuPropertyPages.MenuItems.Add(m)
            Next
            mnuPropertyPages.Enabled = (CAP.PropertyPages.Count > 0)
        Catch
            mnuPropertyPages.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load TV Tuner channels
        Try
            mnuChannel.MenuItems.Clear()
            Dim channel As Integer = CAP.Tuner.Channel
            For c As Integer = 1 To 25
                m = New MenuItem(c.ToString(), New EventHandler(AddressOf mnuChannel_Click))
                m.Checked = (channel = c)
                mnuChannel.MenuItems.Add(m)
            Next
            mnuChannel.Enabled = True
        Catch
            mnuChannel.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Load TV Tuner input types
        Try
            mnuInputType.MenuItems.Clear()
            m = New MenuItem(TunerInputType.Cable.ToString(), New EventHandler(AddressOf mnuInputType_Click))
            m.Checked = (CAP.Tuner.InputType = TunerInputType.Cable)
            mnuInputType.MenuItems.Add(m)
            m = New MenuItem(TunerInputType.Antenna.ToString(), New EventHandler(AddressOf mnuInputType_Click))
            m.Checked = (CAP.Tuner.InputType = TunerInputType.Antenna)
            mnuInputType.MenuItems.Add(m)
            mnuInputType.Enabled = True
        Catch
            mnuInputType.Enabled = False
        End Try
        ' --------------------------------------------------------------------- Enable/disable caps
        '
        mnuVideoCaps.Enabled = ((CAP IsNot Nothing) AndAlso (CAP.VideoCaps IsNot Nothing))
        mnuAudioCaps.Enabled = ((CAP IsNot Nothing) AndAlso (CAP.AudioCaps IsNot Nothing))
        '
        ' --------------------------------------------------------------------- Check Preview menu option
        mnuPreview.Checked = (oldPreviewWindow IsNot Nothing)
        mnuPreview.Enabled = (CAP IsNot Nothing)
        '
        ' --------------------------------------------------------------------- Reenable preview if it was enabled before
        If CAP IsNot Nothing Then
            CAP.PreviewWindow = oldPreviewWindow
        End If
    End Sub

    Private Sub mnuVideoDevices_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' --------------------------------------------------------------------------------
            '  Get current devices and dispose capture object because video and audio devices
            '  can only be changed by creating a new Capture object
            ' --------------------------------------------------------------------------------
            Dim videoDevice As Filter = Nothing
            Dim audioDevice As Filter = Nothing
            If CAP IsNot Nothing Then
                videoDevice = CAP.VideoDevice
                audioDevice = CAP.AudioDevice
                CAP.Dispose()
                CAP = Nothing
            End If
            ' ------------------------------------------------------------------------- Get new video device
            Dim m As MenuItem = TryCast(sender, MenuItem)
            videoDevice = (If(m.Index > 0, filters.VideoInputDevices(m.Index - 1), Nothing))
            ' ------------------------------------------------------------------------- Create capture object
            If (videoDevice IsNot Nothing) OrElse (audioDevice IsNot Nothing) Then
                CAP = New Capture(videoDevice, audioDevice)
                AddHandler CAP.CaptureComplete, New EventHandler(AddressOf OnCaptureComplete)
            End If
            ' ------------------------------------------------------------------------- Update the menu
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Video device not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuAudioDevices_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' --------------------------------------------------------------------------------
            '  Get current devices and dispose capture object because video and audio devices
            '  can only be changed by creating a new Capture object
            ' --------------------------------------------------------------------------------
            Dim videoDevice As Filter = Nothing
            Dim audioDevice As Filter = Nothing
            If CAP IsNot Nothing Then
                videoDevice = CAP.VideoDevice
                audioDevice = CAP.AudioDevice
                CAP.Dispose()
                CAP = Nothing
            End If
            ' ------------------------------------------------------------------------- Get new audio device
            Dim m As MenuItem = TryCast(sender, MenuItem)
            audioDevice = (If(m.Index > 0, filters.AudioInputDevices(m.Index - 1), Nothing))
            ' ------------------------------------------------------------------------- Create capture object
            If (videoDevice IsNot Nothing) OrElse (audioDevice IsNot Nothing) Then
                CAP = New Capture(videoDevice, audioDevice)
                AddHandler CAP.CaptureComplete, New EventHandler(AddressOf OnCaptureComplete)
            End If
            ' ------------------------------------------------------------------------- Update the menu
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Audio device not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuVideoCompressors_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' ------------------------------------------------------------------------- 
            ' Change the video compressor (Index-1 beacuse the first item is None)
            ' ------------------------------------------------------------------------- 
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.VideoCompressor = (If(m.Index > 0, filters.VideoCompressors(m.Index - 1), Nothing))
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Video compressor not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try

    End Sub

    Private Sub mnuAudioCompressors_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' ------------------------------------------------------------------------- 
            ' Change the audio compressor (Index-1 beacuse the first item is None)
            ' ------------------------------------------------------------------------- 
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.AudioCompressor = (If(m.Index > 0, filters.AudioCompressors(m.Index - 1), Nothing))
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Audio compressor not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuVideoSources_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' ------------------------------------------------------------------------
            ' If the device only has one source, this menu item will be disabled
            ' ------------------------------------------------------------------------
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.VideoSource = CAP.VideoSources(m.Index)
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Unable to set video source. Please submit bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuAudioSources_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' ------------------------------------------------------------------------
            ' If the device only has one source, this menu item will be disabled
            ' ------------------------------------------------------------------------
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.AudioSource = CAP.AudioSources(m.Index)
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Unable to set audio source. Please submit bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub


    Private Sub mnuExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        If CAP IsNot Nothing Then
            CAP.[Stop]()
        End If
        Application.[Exit]()
    End Sub

    Private Sub mnuFrameSizes_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ' ----------------------------------------------------------------- Disable preview to avoid flashes
            Dim preview As Boolean = (CAP.PreviewWindow IsNot Nothing)
            CAP.PreviewWindow = Nothing
            ' ----------------------------------------------------------------- Update the frame size
            Dim m As MenuItem = TryCast(sender, MenuItem)
            Dim s As String() = m.Text.Split("x"c)
            Dim size As New Size(Integer.Parse(s(0)), Integer.Parse(s(1)))
            CAP.FrameSize = size
            ' ----------------------------------------------------------------- Update the menu
            UpdateMenu()
            ' ----------------------------------------------------------------- Restore previous preview setting
            CAP.PreviewWindow = (If(preview, panelVideo, Nothing))
        Catch ex As Exception
            MessageBox.Show("Frame size not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuFrameRates_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuFrameRates.Click
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            Dim s As String() = m.Text.Split(" "c)
            CAP.FrameRate = Double.Parse(s(0))
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Frame rate not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub


    Private Sub mnuAudioChannels_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.AudioChannels = CShort(Math.Truncate(Math.Pow(2, m.Index)))
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Number of audio channels not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuAudioSamplingRate_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            Dim s As String() = m.Text.Split(" "c)
            Dim samplingRate As Integer = CInt(Math.Truncate(Double.Parse(s(0)) * 1000))
            CAP.AudioSamplingRate = samplingRate
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Audio sampling rate not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuAudioSampleSizes_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            Dim s As String() = m.Text.Split(" "c)
            Dim sampleSize As Short = Short.Parse(s(0))
            CAP.AudioSampleSize = sampleSize
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Audio sample size not supported." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuPreview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuPreview.Click
        Try
            If CAP.PreviewWindow Is Nothing Then
                CAP.PreviewWindow = panelVideo
                mnuPreview.Checked = True
            Else
                CAP.PreviewWindow = Nothing
                mnuPreview.Checked = False
            End If
        Catch ex As Exception
            MessageBox.Show("Unable to enable/disable preview. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuPropertyPages_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.PropertyPages(m.Index).Show(Me)
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Unable display property page. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuChannel_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.Tuner.Channel = m.Index + 1
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Unable change channel. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuInputType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuInputType.Click
        Try
            Dim m As MenuItem = TryCast(sender, MenuItem)
            CAP.Tuner.InputType = CType(m.Index, TunerInputType)
            UpdateMenu()
        Catch ex As Exception
            MessageBox.Show("Unable change tuner input type. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuVideoCaps_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuVideoCaps.Click
        Try
            Dim s As String
            s = [String].Format("Video Device Capabilities" & vbLf & "--------------------------------" & vbLf & vbLf & "Input Size:" & vbTab & vbTab & "{0} x {1}" & vbLf & vbLf & "Min Frame Size:" & vbTab & vbTab & "{2} x {3}" & vbLf & "Max Frame Size:" & vbTab & vbTab & "{4} x {5}" & vbLf & "Frame Size Granularity X:" & vbTab & "{6}" & vbLf & "Frame Size Granularity Y:" & vbTab & "{7}" & vbLf & vbLf & "Min Frame Rate:" & vbTab & vbTab & "{8:0.000} fps" & vbLf & "Max Frame Rate:" & vbTab & vbTab & "{9:0.000} fps" & vbLf, CAP.VideoCaps.InputSize.Width, CAP.VideoCaps.InputSize.Height, CAP.VideoCaps.MinFrameSize.Width, CAP.VideoCaps.MinFrameSize.Height, CAP.VideoCaps.MaxFrameSize.Width, _
             CAP.VideoCaps.MaxFrameSize.Height, CAP.VideoCaps.FrameSizeGranularityX, CAP.VideoCaps.FrameSizeGranularityY, CAP.VideoCaps.MinFrameRate, CAP.VideoCaps.MaxFrameRate)

            MessageBox.Show(s)
        Catch ex As Exception
            MessageBox.Show("Unable display video capabilities. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub mnuAudioCaps_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuAudioCaps.Click
        Try
            Dim s As String
            s = [String].Format("Audio Device Capabilities" & vbLf & "--------------------------------" & vbLf & vbLf & "Min Channels:" & vbTab & vbTab & "{0}" & vbLf & "Max Channels:" & vbTab & vbTab & "{1}" & vbLf & "Channels Granularity:" & vbTab & "{2}" & vbLf & vbLf & "Min Sample Size:" & vbTab & vbTab & "{3}" & vbLf & "Max Sample Size:" & vbTab & vbTab & "{4}" & vbLf & "Sample Size Granularity:" & vbTab & "{5}" & vbLf & vbLf & "Min Sampling Rate:" & vbTab & vbTab & "{6}" & vbLf & "Max Sampling Rate:" & vbTab & vbTab & "{7}" & vbLf & "Sampling Rate Granularity:" & vbTab & "{8}" & vbLf, CAP.AudioCaps.MinimumChannels, CAP.AudioCaps.MaximumChannels, CAP.AudioCaps.ChannelsGranularity, CAP.AudioCaps.MinimumSampleSize, CAP.AudioCaps.MaximumSampleSize, _
             CAP.AudioCaps.SampleSizeGranularity, CAP.AudioCaps.MinimumSamplingRate, CAP.AudioCaps.MaximumSamplingRate, CAP.AudioCaps.SamplingRateGranularity)

            MessageBox.Show(s)
        Catch ex As Exception
            MessageBox.Show("Unable display audio capabilities. Please submit a bug report." & vbLf & vbLf & ex.Message & vbLf & vbLf & ex.ToString())
        End Try
    End Sub

    Private Sub OnCaptureComplete(ByVal sender As Object, ByVal e As EventArgs)
        Beep()
    End Sub

End Class
