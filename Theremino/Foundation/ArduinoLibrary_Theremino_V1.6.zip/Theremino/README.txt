=================================
 Theremino Libraries for Arduino
=================================
The "Theremino" library allows to connect the Arduino modules
with the Theremino System software on the PC.

The "ThereminoFilters" library provides simple one pole filters.
The filters can be configured as LowPass and HiPass
and easely cascaded to form bandpass filters. 
See "extras/Pulsometer" for an example of filters usage.

For more informations: 
http://www.theremino.com/en
http://www.theremino.com/en/downloads/foundations#arduhal

================================
 Use of the library
================================
Program the Arduino with the ThereDuinoV1

Configure the IN-OUT pins, with the ArduHAL application,
to read sensors, move motors... see this page:
http://www.theremino.com/en/downloads/foundations#arduhal

The over 100 applications of the Theremino System
interact with the hardware and cover almost all fields, 
from scientific experiments to music, radioactivity, 
teaching ... see this page:
http://www.theremino.com/en/applications

Everything works immediately 
without writing a single line of firmware or software.

================================
 License
================================
All the Theremino Software is absolutely free and open source.
You can do anything you want with it, without any limitations.

No license information is therefore required.

We would like to eliminate the concept of the license itself 
(and therefore any limit to the dissemination of knowledge) 
but, if necessary, our Creative Commons license is here:
http://www.theremino.com/en/contacts/copyrights