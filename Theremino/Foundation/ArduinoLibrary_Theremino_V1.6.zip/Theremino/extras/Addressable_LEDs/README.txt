==============
 ENG
==============
This example send RGB data to a WS2812B LEDs chain.

Each LED can be addressed indipendly 
with 256 brightness levels and 16 million colors.

You can connect more than 1000 LEDs in a single chain
and update them more than thirty times per second.

All the Theremino System apps can control colors
through the Slots on the PC and the ArduHAL application. 

More info here:
https://www.theremino.com/en/downloads/foundations#arduhal


==============
 ITA
==============
Questo esempio invia dati RGB a una catena di LED WS2812B

Ogni led può essere indirizzato indipendentemente
con 256 livelli di luminosità e 16 milioni di colori.

Si possono collegare più di 1000 LED in una sola catena
e aggiornarli più di trenta volte al secondo.

Tutte le app di Theremino System possono controllare i colori
attraverso gli slot sul PC e l'applicazione ArduHAL.

Informazioni qui:
https://www.theremino.com/downloads/foundations#arduhal