==============
 ENG
==============
This example reads a VL53L0X sensor
for Time-of-Flight Laser ranging devices and Distance Meters.

All the Theremino System apps can read the ranging data
through the Slots on the PC and the ArduHAL application.  

The sensor has Gesture Recognition capability and fast response
and can be a valid substitute for the Theremino CapSensors
in the Theremin musical instruments.

More info here:
https://www.theremino.com/en/downloads/foundations#arduhal


==============
 ITA
==============
Questo esempio legge un sensore VL53L0X
per dispositivi di misura basati sul Tempo di Volo della luce.

Tutte le app di Theremino System possono leggere la distanza
attraverso gli slot sul PC e l'applicazione ArduHAL.

Il sensore può riconoscere con precisione la posizione di una mano
ed ha una risposta veloce. Per cui può sostituire i CapSensors
negli strumenti musicali di tipo Theremin.

Informazioni qui:
https://www.theremino.com/downloads/foundations#arduhal