
#include "Arduino.h"
#include <Wire.h>
#include "MAX30102.h"

MAX30102::MAX30102() 
{
}

// ============================================================
//  SET FUNCTIONS
// ============================================================

void MAX30102::begin() 
{
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_INT_ENABLE1, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_INT_ENABLE2, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_FIFO_WR_PTR, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_OVRFLOW_CTR, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_FIFO_RD_PTR, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_FIFO_CONFIG, 0x00);
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG, 0x03);  // 3 = RED and IR leds (sPO2 mode)
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG, 0x07);  // 7 = samplerate 100 and pulsewidth 411uS
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_LED1_AMP ,   0xFF);  // RED Led max current = 50 mA
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_LED2_AMP,    0xFF);  //  IR Led max current = 50 mA
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_PILOT,       0x00);
}

void MAX30102::setLEDs(uint8_t redLedCurrent, uint8_t irLedCurrent, uint8_t grnLedCurrent) 
{
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_LED1_AMP, redLedCurrent);   // Write RED LED current 0 to 255 = 0 to 50 mA
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_LED2_AMP, irLedCurrent);    // Write  IR LED current 0 to 255 = 0 to 50 mA
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_LED3_AMP, grnLedCurrent);   // Write GRN LED current 0 to 255 = 0 to 50 mA
}

void MAX30102::setPulseWidth(pulseWidth pw) 
{
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG);// Read SPO2_CONFIG
    reg = reg & 0xFC; // Set SPO2_LED_PW to 00
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG, reg | pw);   // Add  LED_PW and write
}

void MAX30102::setSampleRate(sampleRate sr) 
{
    // ----------------------------------------------------------------------- Read SPO2_CONFIG mask and write sr
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG);
    reg = reg & 0xE3; // Set SPO2_SR bits to 000
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG, reg | (sr << 2));
}

void MAX30102::setAdcRange(adcRange range) 
{
    // ----------------------------------------------------------------------- Read SPO2_CONFIG mask and write AdcRange
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG);
    reg = reg & 0x9F;      // Set SPO2_ADC_RGE bits to 00
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG, reg | (range << 5));
}


void MAX30102::setSamplingAverage(samplingAvg avg) 
{
    // ----------------------------------------------------------------------- Read FIFO_CONFIG mask and write SamplingAverage
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_CONFIG);
    reg = reg & 0x1F;      // Set SMP_AVE bits to 00
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_FIFO_CONFIG, reg | (avg << 5));
}

void MAX30102::setWorkingMode(workingMode wm) 
{
    // ----------------------------------------------------------------------- Read MODE_CONFIG mask and write wm
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG);
    reg = reg & 0xf8; // Set Mode bits to 000
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG, reg | wm);  
}


void MAX30102::reset(void) 
{
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG);  // Get the current register
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG, reg | 0x40);   // mask the RESET bit
}
void MAX30102::shutdown(void) 
{
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG);  // Get the current register
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG, reg | 0x80);
}
void MAX30102::startup(void) 
{
    uint8_t reg = I2CreadByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG);  // Get the current register
    I2CwriteByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG, reg & 0x7F);   // mask the SHDN bit
}



// ============================================================
//  GET FUNCTIONS
// ============================================================

int MAX30102::getNumSamp(void) 
{
    uint8_t wrPtr = I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_WR_PTR);
    uint8_t rdPtr = I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_RD_PTR);
    return (abs( 16 + wrPtr - rdPtr ) % 16);
}

void MAX30102::readSensor(void) 
{
    uint8_t temp[6] = {0};  // Temporary buffer for read values
    I2CreadBytes(MAX30102_ADDRESS, MAX30102_FIFO_DATA, &temp[0], 6);  // Read six bytes from the FIFO

    // 18 bit (combine values to get the actual number)
    //IR =  (long)((long)((long)temp[0] & 0x03) << 16) | (long)temp[1] << 8 | (long)temp[2]; 
    //RED = (long)((long)((long)temp[3] & 0x03) << 16) | (long)temp[4] << 8 | (long)temp[5];

    // 16 bit (combine values to get the actual number)
    RED = ((long)temp[1] << 8) | (long)temp[2];
    IR =  ((long)temp[4] << 8) | (long)temp[5];
}

int MAX30102::getRevID(void) 
{
    return I2CreadByte(MAX30102_ADDRESS, MAX30102_REV_ID);
}

int MAX30102::getPartID(void) 
{
    return I2CreadByte(MAX30102_ADDRESS, MAX30102_PART_ID);
}


// ============================================================
//  I2C FUNCTIONS
// ============================================================

// Wire.h read and write protocols
void MAX30102::I2CwriteByte(uint8_t address, uint8_t subAddress, uint8_t data)
{
    Wire.beginTransmission(address);  // Initialize the Tx buffer
    Wire.write(subAddress);           // Put slave register address in Tx buffer
    Wire.write(data);                 // Put data in Tx buffer
    Wire.endTransmission();           // Send the Tx buffer
}

uint8_t MAX30102::I2CreadByte(uint8_t address, uint8_t subAddress)
{
    uint8_t data; // `data` will store the register data
    Wire.beginTransmission(address);
    Wire.write(subAddress);
    Wire.endTransmission(false);
    Wire.requestFrom(address, (uint8_t) 1);
    data = Wire.read();
    return data;
}

void MAX30102::I2CreadBytes(uint8_t address, uint8_t subAddress, uint8_t * dest, uint8_t count)
{
    Wire.beginTransmission(address);   // Initialize the Tx buffer
    // Next send the register to be read. OR with 0x80 to indicate multi-read.
    Wire.write(subAddress);
    Wire.endTransmission(false);
    uint8_t i = 0;
    Wire.requestFrom(address, count);  // Read bytes from slave register address
    while (Wire.available())
    {
        dest[i++] = Wire.read();
    }
}

// ============================================================
//  DEBUG FUNCTIONS
// ============================================================

//void MAX30102::printRegisters(void) 
//{
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_INT_STATUS1),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_INT_STATUS2),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_WR_PTR),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_INT_ENABLE1),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_OVRFLOW_CTR),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_RD_PTR),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_DATA),      BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_FIFO_CONFIG),    BIN);
//    // Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_LED_CONFIG),  BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_MODE_CONFIG),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_SPO2_CONFIG),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_LED1_AMP),       BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_LED2_AMP),       BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_PILOT ),         BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX310100_MLED_CTRL1),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX310100_MLED_CTRL2),    BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_TEMP_INTG),      BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS,  MAX30102_TEMP_FRAC),     BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_DIE_TEMP),       BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_PROX_INT_TRESH), BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_REV_ID),         BIN);
//    Serial.println(I2CreadByte(MAX30102_ADDRESS, MAX30102_PART_ID),        BIN);
//}
