
#ifndef MAX30102_h 
#define MAX30102_h 

// Registers
#define MAX30102_INT_STATUS1    0x00  // Which interrupts are tripped
#define MAX30102_INT_STATUS2    0x01  // Which interrupts are tripped
#define MAX30102_INT_ENABLE1    0x02  // Which interrupts are active
#define MAX30102_INT_ENABLE2    0x03  // Which interrupts are active

#define MAX30102_FIFO_WR_PTR    0x04  // Where data is being written
#define MAX30102_OVRFLOW_CTR    0x05  // Number of lost samples
#define MAX30102_FIFO_RD_PTR    0x06  // Where to read from
#define MAX30102_FIFO_DATA      0x07  // Ouput data buffer

#define MAX30102_FIFO_CONFIG    0x08
#define MAX30102_MODE_CONFIG    0x09  // Control register
#define MAX30102_SPO2_CONFIG    0x0A  // Oximetry settings
#define MAX30102_LED1_AMP       0x0C
#define MAX30102_LED2_AMP       0x0D
#define MAX30102_LED3_AMP       0x0E  // For MAX30105 only
#define MAX30102_PILOT          0x10
#define MAX30102_MLED_CTRL1     0x11
#define MAX30102_MLED_CTRL2     0x12
#define MAX30102_TEMP_INTG      0x1F  // Temperature value, whole number
#define MAX30102_TEMP_FRAC      0x20  // Temperature value, fraction
#define MAX30102_DIE_TEMP       0x21
#define MAX30102_PROX_INT_TRESH 0x30
#define MAX30102_REV_ID         0xFE  // Part revision
#define MAX30102_PART_ID        0xFF  // Part ID, normally 0x15

#define MAX30102_ADDRESS        0x57  // 8bit address converted to 7bit

typedef unsigned char uint8_t;

typedef enum
{
    pw69,    //  69us led pulse width (adc resolution 15 bits)
    pw118,   // 118us led pulse width (adc resolution 16 bits)
    pw215,   // 215us led pulse width (adc resolution 17 bits)
    pw411    // 411us led pulse width (adc resolution 18 bits)
}pulseWidth;

typedef enum
{
    sr50,    //  50 samples per second
    sr100,   // 100 samples per second
    sr200,   // 200 samples per second
    sr400,   // 400 samples per second
    sr800,   // 800 samples per second
    sr1000,  // 1000 samples per second
    sr1600,  // 1600 samples per second
    sr3200   // 3200 samples per second
}sampleRate;
// max sampleRate is limited by pulseWidth see MAX30102 datasheet page 23 

typedef enum
{
    rge2048,  // adc full scale 2048 nA
    rge4096,         
    rge8192,
    rge16384
}adcRange;


typedef enum
{
    avg1,    // average 1 (no average)
    avg2,         
    avg4,
    avg8,
    avg16,    
    avg32,   // average 32 
    avg32b,
    avg32c,
}samplingAvg;

typedef enum
{
    wmHeartRate = 2,    // HeartRate mode
    wmSpO2 = 3,         // SpO2 mode = RED and IR LEDs
    wmMultiLed = 7
}workingMode;

class MAX30102 
{
public:
  uint16_t IR = 0;      // Last IR reflectance datapoint
  uint16_t RED = 0;     // Last Red reflectance datapoint

  MAX30102();

  void  begin();                             // Init all registers
  
  void  setLEDs(uint8_t redLedCurrent,       // 0 to 255 (0 to 50 mA)  
                uint8_t irLedCurrent,        // 0 to 255 (0 to 50 mA)
                uint8_t grnLedCurrent);      // 0 to 255 (0 to 50 mA) 

  void  setPulseWidth(pulseWidth pw);        // pw69, pw118, pw215, pw411 
                
  void  setSampleRate(sampleRate sr);        // sr50, sr100, sr200, sr400, sr800, sr1000, sr1600, sr3200 

  void  setAdcRange(adcRange range);         // rge2048, rge4096, rge8192, rge16384 (adc range nA)

  void  setSamplingAverage(samplingAvg avg); // avg1, avg2, avg4, avg8, avg16, avg32 (sampling average)

  void  setWorkingMode(workingMode wm);      // wmHeartRate, wmSpO2, wmMultiLed

  void  reset(void);                         // Resets the device
  void  shutdown(void);                      // Instructs device to power-save
  void  startup(void);                       // Leaves power-save
  
  int   getNumSamp(void);                    // Get number of samples
  void  readSensor(void);                    // Updates the values
  int   getRevID(void);                      // Gets revision ID
  int   getPartID(void);                     // Gets part ID
  
  void  printRegisters(void);                // Dumps contents of registers for debug

private:
  void    I2CwriteByte(uint8_t address, uint8_t subAddress, uint8_t data);
  uint8_t I2CreadByte (uint8_t address, uint8_t subAddress);
  void    I2CreadBytes(uint8_t address, uint8_t subAddress, uint8_t * dest, uint8_t count);
};

#endif


