==============
 ENG
==============
This example reads a MAX30102 (or MAX30105) sensor
for cardiotachimeter and arrithmia detection apps:
http://www.theremino.com/en/downloads/biometry#ecg

More info here:
https://www.theremino.com/en/downloads/foundations#arduhal


==============
 ITA
==============
Questo esempio legge un sensore MAX30102 (o MAX30105)
per cardiotachimetri e per il rilevamento delle aritmie:
http://www.theremino.com/en/downloads/biometry#ecg

Informazioni qui:
https://www.theremino.com/downloads/foundations#arduhal