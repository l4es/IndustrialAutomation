﻿##########
 ENGLISH
##########
=====================================================
 VERSION 1.4
=====================================================
Starting from our library version 1.4.0, the "Async mode" option can be easely channged in the ArduHAL application. 
http://www.theremino.com/en/downloads/foundations#arduhal

This is useful to separate the communication with ArduHAL and make it independent from the Arduino loop.

With this variant, the maximum frequency decreases from about 300 to about 200 exchanges per second, but on the other hand it becomes independent of what is written in the "loop ()" function.

This technique could also be useful for running some Arduino models that otherwise would not work at all.

======================================================
 VERSION 1.5
======================================================
Starting from version 1.5.0, our library can be loaded with the command "Add library from ZIP file".

======================================================
 VERSIONE 1.6
======================================================
Starting from version 1.6.0, the pins configured as UNUSED are left as they are. Previously they were set as "INPUT", and this prevented them from being used as output in the Arduino loop.


###########
 ITALIANO
###########
======================================================
VERSIONE 1.4
======================================================
Dalla versione 1.4.0 della nostra libreria, l'opzione "Async mode" è comodamente modificabile nella applicazione ArduHAL.
http://www.theremino.com/downloads/foundations#arduhal

Questo è utile per separare la comunicazione con l’ArduHAL e renderla indipendente dal loop di Arduino.

Con questa modifica, la massima frequenza decresce da circa 300 a circa 200 scambi al secondo, ma in compenso diventa indipendente da quello che si scrive nella funziona “loop()”.

Questa tecnica potrebbe anche essere utile per far funzionare alcuni modelli di Arduino che altrimenti non funzionerebbero del tutto.

======================================================
 VERSIONE 1.5
======================================================
A partire dalla versione 1.5.0 la nostra libreria può essere caricata in arduino con il comando "Aggiungi libreria da file .ZIP"

======================================================
 VERSIONE 1.6
======================================================
A partire dalla versione 1.6.0 della nostra libreria, i Pin configurati come UNUSED vengono lasciati come sono. Precedentemente venivano impostati come "INPUT", e questo impediva di utilizzarli come output nel loop di Arduino.

