
// =================================
//  Theremino Library - Version 1.6
// =================================
//  https://www.theremino.com/en
// =================================

#include "Theremino.h"
cTheremino Theremino;

// ======================================================================================
// Defining AsyncMode the timer0 compare interrupt is enabled.
// The ArduHAL exchange frequency becomes independent by the "loop()"
// but the max frequency drops from about 300 to about 200 per second
// ======================================================================================
void cTheremino::setAsyncMode()
{
	OCR0A = 0x80;  // interrupts executed away from millis() and delay()
	TIMSK0 |= _BV(OCIE0A);
	AsyncMode = 1;
}

void cTheremino::resetAsyncMode()
{
	TIMSK0 &= ~_BV(OCIE0A);
	AsyncMode = 0;
}

ISR(TIMER0_COMPA_vect) 
{
	interrupts();
	Theremino.executeHostCommands();
}

// ======================================================================================
// "serialEvent()" is called between each "loop()"
// If the "loop()" is stopped or slowed then "serialEvent()" is not called
// "serialEvent()" is called also if there are no new chars in the serial buffer
// Serial.available() max = 63
// ======================================================================================
void serialEvent()
{
	if (Theremino.AsyncMode) return;
	Theremino.executeHostCommands();
}

// ======================================================================================
//   CLASS THEREMINO
// ======================================================================================
cTheremino::cTheremino()
{
}

// ======================================================================================
//   SYNC
// ======================================================================================
bool cTheremino::testSync()
{
    if (Serial.read() != 0x55) return false;
    if (Serial.read() != 0xAA) return false;
    if (Serial.read() != 0x55) return false;
    if (Serial.read() != 0xAA) return false;
    return true;
}

void cTheremino::sendSync()
{
    Serial.write(0x55);
    Serial.write(0xAA);
    Serial.write(0x55);
    Serial.write(0xAA);
}

// ======================================================================================
//   EEPROM
// ======================================================================================
//void cTheremino::stringToEeprom_Simple(uint16_t addr, const String s)
//{
//    if (s.length() > 31) return;
//    char c[32];
//    strcpy(c, s.c_str());
//    EEPROM.put(addr, c);
//}

void cTheremino::stringToEeprom_OnlyChangedCells(uint16_t addr, const String s)
{
    if (s.length() > 31) return;
    uint8_t i = 0;
    while (i < s.length())
    {
        EEPROM.update(addr++, s[i++]);
    }
    EEPROM.update(addr, char(0));
}

String cTheremino::stringFromEeprom(uint16_t addr)
{
    char c[32];
    EEPROM.get(addr, c);
    return String(c);
}

// ======================================================================================
//   CRC
// ======================================================================================
void cTheremino::initCrc()
{
    gCrc = 0;
} 
void cTheremino::appendByteToCrc(uint8_t new_byte)
{
    gCrc = (gCrc ^ new_byte) + 1;
} 
void cTheremino::appendArrayToCrc(uint8_t* bytes, uint16_t nBytes)
{
    uint16_t i;
    for (i = 0; i < nBytes; i++)
    {
      gCrc = (gCrc ^ bytes[i]) + 1;
    }
}
void cTheremino::sendSerialByteAndUpdateCRC(uint8_t b)
{
    appendByteToCrc(b);
    Serial.write(b);
}
void cTheremino::sendSerialStringAndUpdateCRC(String s)
{
    for (uint8_t i = 0; i < s.length(); i++)
    {
       sendSerialByteAndUpdateCRC(s[i]);
    }    
}

// ======================================================================================
//  GENERIC IN-OUT
// ======================================================================================
void cTheremino::genericWrite8 (uint8_t index,  uint8_t value)
{
    if (index > NUM_PINS -1) return; 
    index *= 3;
    GenericInOutBuffer[index] = value;
}

void cTheremino::genericWrite16(uint8_t index, uint16_t value)
{
    if (index > NUM_PINS -1) return; 
    index *= 3;
	noInterrupts();
    GenericInOutBuffer[index] =     value >> 8;
    GenericInOutBuffer[index + 1] = value;
	interrupts();
}

void cTheremino::genericWrite24(uint8_t index, uint32_t value)
{
    if (index > NUM_PINS -1) return; 
    index *= 3;
	noInterrupts();
    GenericInOutBuffer[index] =     value >> 16;
    GenericInOutBuffer[index + 1] = value >> 8;
    GenericInOutBuffer[index + 2] = value;
	interrupts();
}

uint8_t cTheremino::genericRead8 (uint8_t index)
{
    index *= 3;
    return GenericInOutBuffer[index];
}

uint16_t cTheremino::genericRead16(uint8_t index)
{
	uint16_t value;
    index *= 3;
	noInterrupts();
    value = GenericInOutBuffer[index] * (uint32_t)256 +
            GenericInOutBuffer[index + 1];
	interrupts();
	return value;
}

uint32_t cTheremino::genericRead24(uint8_t index)
{
	uint32_t value;
    index *= 3;
	noInterrupts();
    value = GenericInOutBuffer[index]     * (uint32_t)65536 +
            GenericInOutBuffer[index + 1] * (uint32_t)256 +
            GenericInOutBuffer[index + 2];
	interrupts();
	return value;
}

// ======================================================================================
//  COUNT IN-OUT BYTES
// ======================================================================================
void cTheremino::detachAllServo()
{
    for (uint8_t i = 0; i < MAX_NUM_SERVO; i++)
    {
        ServoArray[i].detach();
    }
}

void cTheremino::countInOutBytesAndSetPinModes()
{
    detachAllServo();
    uint8_t ServoCounter = 0;
    InputBytesCount = 0;
    OutputBytesCount = 0;
    for (uint8_t i = 0; i < NUM_PINS; i++)
    {
        switch (PinTypes[i])
        {
            // ---------------------------------------------- OUT 
            case DIG_OUT:  OutputBytesCount += 1; pinMode(i, OUTPUT); break;
            case PWM_8:    OutputBytesCount += 1; pinMode(i, OUTPUT); break;
            //case PWM_16:   OutputBytesCount += 2; pinMode(i, OUTPUT); break;
            case SERVO_8:  OutputBytesCount += 1; pinMode(i, OUTPUT); ServoArray[ServoCounter].attach(i); ServoCounter++; break;
            case SERVO_16: OutputBytesCount += 2; pinMode(i, OUTPUT); ServoArray[ServoCounter].attach(i); ServoCounter++; break;
            //case STEPPER:  OutputBytesCount += 4; pinMode(i, OUTPUT); break;
            case GEN_OUT_8:  OutputBytesCount += 1; pinMode(i, OUTPUT); break;
            case GEN_OUT_16: OutputBytesCount += 2; pinMode(i, OUTPUT); break;
            case GEN_OUT_24: OutputBytesCount += 3; pinMode(i, OUTPUT); break;
            // ---------------------------------------------- IN
            case DIG_IN:     InputBytesCount += 1; pinMode(i, INPUT); break;
            case DIG_IN_PU:  InputBytesCount += 1; pinMode(i, INPUT_PULLUP); break;
            case ADC_8:      InputBytesCount += 1; pinMode(i, INPUT); break;
            case ADC_16:     InputBytesCount += 2; pinMode(i, INPUT); break;
            //case COUNTER:    InputBytesCount += 2; pinMode(i, INPUT); break;
            //case COUNTER_PU: InputBytesCount += 2; pinMode(i, INPUT_PULLUP); break;
            //case PERIOD:    InputBytesCount += 4; pinMode(i, INPUT); break;
            //case PERIOD_PU: InputBytesCount += 4; pinMode(i, INPUT_PULLUP); break;
            case GEN_IN_8:   InputBytesCount += 1; pinMode(i, INPUT); break;
            case GEN_IN_16:  InputBytesCount += 2; pinMode(i, INPUT); break;
            case GEN_IN_24:  InputBytesCount += 3; pinMode(i, INPUT); break;
            // ---------------------------------------------- UNUSED
			// Starting from version 1.6, the UNUSED pins are left unchanged.
            //case UNUSED: pinMode(i, INPUT);  break;  
        }
    }
} 

// ======================================================================================
//  HOST COMMANDS
// ======================================================================================
void cTheremino::setupProps()
{
    // ------------------------------------------------ set pintype
    if (ReceivedDataBuffer[0] != 0)
	{
		setAsyncMode();
	}
	else
	{
		resetAsyncMode();
	}
    // ---------------------------------------------------- 
    String s1 = "OK";
    sendSync();
    initCrc();
    sendSerialByteAndUpdateCRC(CMD_SETUP_PROPS);
    sendSerialByteAndUpdateCRC(s1.length());
    sendSerialStringAndUpdateCRC(s1);
    Serial.write(gCrc);
    Serial.write(TERMINATOR);
} 

void cTheremino::setupPins()
{
    for (uint8_t i = 0; i < ReceivedPayloadBytes; i++)
    {
        // ------------------------------------------------ set pintype
        uint8_t pt = ReceivedDataBuffer[i];
        PinTypes[i] = pt;
    }   
    countInOutBytesAndSetPinModes();
    // ---------------------------------------------------- 
    String s1 = "OutBytesCount = " + String(OutputBytesCount) + char(13) +
                "InBytesCount = "  + String(InputBytesCount);
    sendSync();
    initCrc();
    sendSerialByteAndUpdateCRC(CMD_SETUP_PINS);
    sendSerialByteAndUpdateCRC(s1.length());
    sendSerialStringAndUpdateCRC(s1);
    Serial.write(gCrc);
    Serial.write(TERMINATOR);
} 

void cTheremino::setName()
{
    Name = "";
    for (uint8_t i = 0; i < ReceivedPayloadBytes; i++)
    {
        Name += char(ReceivedDataBuffer[i]);
    }
    sendSync();
    initCrc();
    sendSerialByteAndUpdateCRC(CMD_SET_NAME);
    sendSerialByteAndUpdateCRC(Name.length());
    sendSerialStringAndUpdateCRC(Name);
    Serial.write(gCrc);
    Serial.write(TERMINATOR);
    // ---------------------------------- Name to EEPROM
    //stringToEeprom_Simple(100, Name);
    stringToEeprom_OnlyChangedCells(100, Name);
    // ----------------------------------
}

void cTheremino::recognizeReplay()
{
    // ---------------------------------- Name from EEPROM
    Name = stringFromEeprom(100);
    // ----------------------------------
    sendSync();
    initCrc();
    sendSerialByteAndUpdateCRC(CMD_RECOGNIZE);
    sendSerialByteAndUpdateCRC(Identifier.length() + Version.length() + Name.length() + 2);
    sendSerialStringAndUpdateCRC(Identifier);
    sendSerialByteAndUpdateCRC(13);
    sendSerialStringAndUpdateCRC(Version);
    sendSerialByteAndUpdateCRC(13);
    sendSerialStringAndUpdateCRC(Name);
    Serial.write(gCrc);
    Serial.write(TERMINATOR);
}

void cTheremino::dataExchange()
{
    // ------------------------------------------------------------- OUT
    uint8_t ServoCounter = 0;
    uint8_t j = 0;
    uint8_t gb;
    for (uint8_t i = 0; i < NUM_PINS; i++)
    {
        // security if HAL does not send SetupPins 
        //if (j >= ReceivedPayloadBytes) break;
        // --------------------------------------
        switch (PinTypes[i])
        {
            case DIG_OUT:
                digitalWrite(i, ReceivedDataBuffer[j]);
                j += 1;
            break;
            case PWM_8:
                analogWrite(i, ReceivedDataBuffer[j]);
                j += 1;
            break;
            case SERVO_8: 
                //ServoArray[0].writeMicroseconds(ReceivedDataBuffer[j] * 16); // not precise - 16 instead of 15.625
                ServoArray[ServoCounter].writeMicroseconds(((int32_t)ReceivedDataBuffer[j] * 4000) >> 8); // precise - but using 60 more bytes
                ServoCounter ++;
                j += 1;
            break;
            case SERVO_16:
                ServoArray[ServoCounter].writeMicroseconds((((int32_t)ReceivedDataBuffer[j] * 256 + ReceivedDataBuffer[j+1]) * 4000) >> 16); // precise - but using 90 more bytes
                ServoCounter ++;
                j += 2;
            break;
            case GEN_OUT_8:
                gb = i * 3;
                GenericInOutBuffer[gb] = ReceivedDataBuffer[j];
                j += 1;
            break;
            case GEN_OUT_16:
                gb = i * 3;
                GenericInOutBuffer[gb] = ReceivedDataBuffer[j];
                GenericInOutBuffer[gb + 1] = ReceivedDataBuffer[j + 1];
                j += 2;
            break;
            case GEN_OUT_24:
                gb = i * 3;
                GenericInOutBuffer[gb] = ReceivedDataBuffer[j];
                GenericInOutBuffer[gb + 1] = ReceivedDataBuffer[j + 1];
                GenericInOutBuffer[gb + 2] = ReceivedDataBuffer[j + 2];
                j += 3;
            break;
        }
    }   

    // ------------------------------------------------------------- IN 
    sendSync();
    initCrc();
    sendSerialByteAndUpdateCRC(CMD_DATA_EXCHANGE);
    sendSerialByteAndUpdateCRC(InputBytesCount);
    uint16_t n;
    for (uint8_t i = 0; i < NUM_PINS; i++)
    {
        switch (PinTypes[i])
        {
            case DIG_IN:
            case DIG_IN_PU:
                sendSerialByteAndUpdateCRC(digitalRead(i));
            break;
            case ADC_8:
                sendSerialByteAndUpdateCRC(analogRead(i) >> 2);
            break;
            case ADC_16:
                n = 64 * analogRead(i);
                sendSerialByteAndUpdateCRC(n >> 8);
                sendSerialByteAndUpdateCRC(n);
            break;
            case GEN_IN_8:
                gb = i * 3;
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb]);
            break;
            case GEN_IN_16:
                gb = i * 3;
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb]);
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb + 1]);
            break;
            case GEN_IN_24:
                gb = i * 3;
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb]);
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb + 1]);
                sendSerialByteAndUpdateCRC(GenericInOutBuffer[gb + 2]);
            break;
        }
    }   
    Serial.write(gCrc);
    Serial.write(TERMINATOR);
}

void cTheremino::receiveBufferFlush()
{
    while (Serial.available() > 0) Serial.read();
}

void cTheremino::enterFlushStatus()
{
    receiveBufferFlush();
    status = ST_FLUSH;
    BytesToWait = 1;
    delay(200);

//    receiveBufferFlush();
//    status = ST_WAITING_SYNC;
//    BytesToWait = SyncLen + 2;
//    delay(200);
}


// ======================================================================================
//   EXECUTE HOST COMMANDS
// ======================================================================================
void cTheremino::executeHostCommands()
{ 
    if (Serial.available() < BytesToWait) return; 
    
    switch (status)
    {
        case ST_FLUSH:
        {
            receiveBufferFlush();
            status = ST_WAITING_SYNC;
            BytesToWait = SYNC_LEN + 2;
            return;
        }
        // ----------------------------------------------------- Waiting sync
        case ST_WAITING_SYNC:
            if (testSync())
            {
                ReceivedCommandID = Serial.read();
                ReceivedPayloadBytes = Serial.read();
                if (ReceivedPayloadBytes > MAX_PAYLOAD_BYTES)
                {
                    //Serial.print("PayloadBytes = " + String(ReceivedPayloadBytes));
                    //Serial.write(TERMINATOR);
                    enterFlushStatus();
                    return;
                }
                status = ST_WAITING_END;
                BytesToWait = ReceivedPayloadBytes + 2;
            }
            else
            {
                //Serial.print("Sync error ");
                //Serial.write(TERMINATOR);
                enterFlushStatus();
                return;
            }
        break;
        // ----------------------------------------------------- Waiting end of command
        case ST_WAITING_END:
            // ------------------------------------------------- get all the bytes
            for (uint8_t i = 0; i < ReceivedPayloadBytes; i++)
            {
                ReceivedDataBuffer[i] = Serial.read();
            }
            ReceivedCRC = Serial.read();
            ReceivedTerminator = Serial.read();
            // ------------------------------------------------- test terminator
            if (ReceivedTerminator != TERMINATOR)
            {
                //Serial.print("Terminator not zero = " + String(ReceivedTerminator));
                //Serial.write(TERMINATOR);
                enterFlushStatus();
                return;
            }
            // ------------------------------------------------- test crc
            initCrc();
            appendByteToCrc(ReceivedCommandID);
            appendByteToCrc(ReceivedPayloadBytes);
            appendArrayToCrc(ReceivedDataBuffer, ReceivedPayloadBytes);
            if (gCrc != ReceivedCRC)
            {
				// Serial.print("CRC error = " + char(13) + char(10));
                // Serial.print("Received = " + String(ReceivedCRC) + char(13) + char(10));
                // Serial.print("Calculated = " + String(gCrc));
                // Serial.write(TERMINATOR);
                enterFlushStatus();
                return;
            }
            // ------------------------------------------------- execute command
            switch (ReceivedCommandID)
            {
                case CMD_RECOGNIZE:
                    recognizeReplay();
                break;
				case CMD_SETUP_PROPS:
                    setupProps();                  
                break;
                case CMD_SETUP_PINS:
                    setupPins();                  
                break;
                case CMD_SET_NAME:
                    setName();
                break;
                case CMD_DATA_EXCHANGE:
                    dataExchange();
                break;
                default:
                    enterFlushStatus();
                    return;
                break;
            } 
            status = ST_WAITING_SYNC;
            BytesToWait = SYNC_LEN + 2;
        break;
    }
}














