
// =================================
//  Theremino Library - Version 1.6
// =================================
//  https://www.theremino.com/en
// =================================

#ifndef Theremino_h 
#define Theremino_h 

#include "Arduino.h"
#include <EEPROM.h>  
#include <Servo.h> 

// ===============================================================================================
//   ENUMS
// ===============================================================================================
enum PIN_TYPE
{
    UNUSED      = 0,
    // -------------------- OUT
    DIG_OUT     = 1,
    PWM_8       = 2,
    //PWM_16      = 3,
    SERVO_8     = 4,
    SERVO_16    = 5,
    //STEPPER     = 6,

    GEN_OUT_8    = 90,
    GEN_OUT_16   = 91,
    GEN_OUT_24   = 92,
    // -------------------- IN
    DIG_IN      = 129,
    DIG_IN_PU   = 130,

    ADC_8       = 131,
    ADC_16      = 132,
    
    //COUNTER     = 140,
    //COUNTER_PU  = 141,
    //PERIOD      = 144,
    //PERIOD_PU   = 145,

    GEN_IN_8    = 190,
    GEN_IN_16   = 191,
    GEN_IN_24   = 192,
};

enum CMD
{
    // ------------------------------------------ commands 
    CMD_RECOGNIZE       = 255,
    CMD_DATA_EXCHANGE   = 251,
	CMD_SETUP_PROPS     = 250,
    CMD_SETUP_PINS      = 249,
    CMD_SET_NAME        = 248,
    CMD_NOCMD           = 0
};

enum RECEIVE_STATUS
{
    ST_WAITING_SYNC    = 0,
    ST_WAITING_END     = 1,
    ST_FLUSH           = 2,
};

class cTheremino
{
    public:
        cTheremino();
        void executeHostCommands();
		uint8_t AsyncMode = 0;
		
    private:
    // d0..d13 = 14 pin     (14 bytes)
    // a0..a7  =  8 pin     (16 bytes)
    // g1..g4  =  4 generic (16 bytes)

    #define TERMINATOR 10
    #define SYNC_LEN 4
    
    #define NUM_PINS 22
    uint8_t PinTypes[NUM_PINS] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    #define MAX_PAYLOAD_BYTES 52
    uint8_t ReceivedDataBuffer[MAX_PAYLOAD_BYTES];
    uint8_t InputBytesCount = 0;
    uint8_t OutputBytesCount = 0;

    RECEIVE_STATUS status = ST_WAITING_SYNC;
    uint8_t BytesToWait = 8;
    
    uint8_t ReceivedCommandID;
    uint8_t ReceivedPayloadBytes;
    uint8_t ReceivedCRC;
    uint8_t ReceivedTerminator;
	uint8_t gCrc;
    
    String Identifier = "Arduino";
    String Version = "Version 1";
    String Name = "NoName";

    #define MAX_NUM_SERVO 22
    volatile Servo ServoArray[MAX_NUM_SERVO];

    volatile uint8_t GenericInOutBuffer[NUM_PINS * 3];

    // =============================================================================================== METHODS
	void setAsyncMode();
	void resetAsyncMode();
    void initCrc();
    void appendByteToCrc(uint8_t new_byte);
    void appendArrayToCrc(uint8_t* bytes, uint16_t nBytes);
    void sendSerialByteAndUpdateCRC(uint8_t b);
    void sendSerialStringAndUpdateCRC(String s);
    void detachAllServo();
    void countInOutBytesAndSetPinModes();
    void recognizeReplay();
    void receiveBufferFlush();
    void enterFlushStatus();
	void setupProps();
    void setupPins();
    void setName();
    void dataExchange();
    bool testSync();
    void sendSync();
    //void stringToEeprom_Simple(uint16_t addr, const String s);
    void stringToEeprom_OnlyChangedCells(uint16_t addr, const String s);
    String stringFromEeprom(uint16_t addr);
    
public: 
    void genericWrite8 (uint8_t index,  uint8_t value);
    void genericWrite16(uint8_t index, uint16_t value);
    void genericWrite24(uint8_t index, uint32_t value);

    uint8_t genericRead8 (uint8_t index);
    uint16_t genericRead16(uint8_t index);
    uint32_t genericRead24(uint8_t index);

};

extern cTheremino Theremino;

#endif


