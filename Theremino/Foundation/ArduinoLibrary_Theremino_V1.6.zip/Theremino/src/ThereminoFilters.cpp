#include "ThereminoFilters.h"

float Filter::filterData;

void setFilterInput(float value) {Filter::filterData = value;}

float getFilterOutput() {return Filter::filterData;}

Filter::Filter(float freq, bool hiPass) 
{
    inValue = 0;
    outValue = 0;
    lastUS = micros();
    isHighPass = hiPass;
    tauUS = 1e6 / (TWO_PI * freq);
}

void Filter::run() 
{  
    inValue = filterData;
    
    // the time rollover is corrected automatically by the unsigned math
    uint32_t time = micros();
    uint32_t elapsedUS = time - lastUS;
    lastUS = time;
          
    float tauSamps = tauUS / elapsedUS;
    float ampFactor = exp(-1.0 / tauSamps);

    outValue = (1.0 - ampFactor) * inValue + ampFactor * outValue;

    if (isHighPass)
    {
         filterData = inValue - outValue;
    }
    else
    {
         filterData = outValue;
    }   
}




