
#ifndef ThereminoFilters_h
#define ThereminoFilters_h

#include <Arduino.h>

void setFilterInput(float value);
float getFilterOutput();

class Filter 
{
  private:
  bool  isHighPass;
  float tauUS;       // filter time constant in US
  uint32_t lastUS;   // last time in microseconds
  float inValue;          
  float outValue;
   
  public:
  Filter(float freq, bool hiPass);
  static float filterData; 

  void run();
};

#endif


