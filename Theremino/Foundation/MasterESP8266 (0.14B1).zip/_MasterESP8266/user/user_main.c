/******************************************************************************
Firmware for Theremino Wemos D1 mini and compatible modules

FileName: user_main.c

Description: main user application

*******************************************************************************/


/*
Memory allocation
boot loader code = 4 KB = sector 0x000
OTA code = 1023 KB + 1023 KB = sectors 0x001 to 0x1ff
wear leveling area 1 user data = 512 KB = sectors 0x200 to 0x27f
wear leveling area 1 index sector = 4 KB = sector 0x300
wear leveling area 2 user data = 1024 KB = sectors 0x280 to 0x2ff
wear leveling area 2 index sector = 4 KB = sector 0x301
not used : 1019 KB = sector 0x302 to 0x3fb
system reserved : 16KB sectors 0x3fc,0x3fd,0x3fe,0x3ff
*/


/******************************************************************************
=============IN CORSO=============

mettere WebServer su porta 80 con display pagina logo Theremino e status
trasformare da 16 bit a 32 bit tutti i valori XCHG

test buffer overflow su ricezione dati UDP > 1024
nome TH-IOT-v0.1

nethal help
netmoduleprogrammer help
netmodulefeatures help
netmoduleusbprogramming help

=============DA FARE=============

attivare un configuration HTTP server in SoftAP mode
wps
Utilizzo led azzurro prima della connessione nethal
valori residui su cambio tipologia di pin
scrittura ultima programmazione in FLASH
portare da 4096 us a 4000 us il periodo pwm/servo

stepper
wifi-direct
sicurezza comm : SIPHASH o equivalente
migrazione da C a C++
(APP)netslots_simple
(APP)NetHAL con indirizzo IP configurabile (per port forwarding firewall)
(APP)NetHAL con porta UDP configurabile (per port forwarding firewall)

*******************************************************************************/
#include <stddef.h>			//	for offsetof
#include "osapi.h"
#include "user_interface.h"
#include "espconn.h"		//	for communication
#include "mem.h"			//	for alloc
#include "upgrade.h"		//	for upgrade OTA
#include "gpio.h"       	//  for I/O
#include "driver\uart.h"	// 	for RX from USB UART

//	IRAM is code executed in RAM
//	ICACHE_RAM_ATTR must be defined only for RTOS, is default for NONOS
//	IRAM is a limited resource, is used only where execution speed is requested, that is in interrupt routines
#ifndef ICACHE_RAM_ATTR
#define ICACHE_RAM_ATTR
#endif

//	firmware version
#define FWVER "M0.14"

#define THEREMINOPROTOCOL "TH-IOT-v0.1"

//	debug

//#define DEBUG_PWM_TIMER
//#define DEBUG_PWM_ABSOLUTE
//#define DEBUG_PWM_RELATIVE
//#define DEBUG_RANDOMDELAY

//	features

#define SYMBOLICPIN			//	symbolic pin name
#define TIMER1_USE_NMI		//	without this define timer1 interrupt routine is not executed !?
//#define BUBBLE_SORT		//	sort type in pwm/servo : gnome or bubble
#define COMPACT_PWM_ARRAY	//	compact phase array in pwm/servo
#define FUOTA_SUPPORT		//	support for firmware upgrade on the air

//	pin types

#define MAXNUMPIN 8

enum EPin
{
	Unus,
	Dgou,
	Pwmo,
	Serv,
	Dgin,
	Dgip,
	Coun,
	Coup,
	Peri,
	Perp,
	Enca,
	Encb,
	Enap,
	Enbp,
	Adci,
};

//	WiFi

enum EWiFiNetwork
{
	station_dhcp,
	station_static,
	softap,
};

enum EWiFiSecurity
{
	open,
	wep,
	wpa,
	wpa2,
	mixed,
};

//  from SDK hw_timer.c

#define TIMER1_DIVIDE_BY_16 0x0004	//	FRC1_CTRL_ADDRESS	0x08
#define TIMER1_ENABLE_TIMER 0x0080	//	FRC1_CTRL_ADDRESS	0x08

//	the timers are not influenced from turbo mode (160 Mhz)
//  80 Mhz bus CPU / 16 prescaler = 5 Mhz = 200 ns
//  4096 us period = GRANULARITY / 0,2 = 20480 tick

#define PERIODTICKS 20480

//  GPIO register direct access

struct SGpioRegs
{
    volatile uint32 out;         //  0x60000300
    volatile uint32 out_w1ts;    //  0x60000304
    volatile uint32 out_w1tc;    //  0x60000308
    volatile uint32 enable;      //  0x6000030C
    volatile uint32 enable_w1ts; //  0x60000310
    volatile uint32 enable_w1tc; //  0x60000314
    volatile uint32 in;          //  0x60000318
    volatile uint32 status;      //  0x6000031C
    volatile uint32 status_w1ts; //  0x60000320
    volatile uint32 status_w1tc; //  0x60000324
};

//  timers register direct access

struct STimerRegs
{
    volatile uint32 frc1_load;   //  0x60000600
    volatile uint32 frc1_count;  //  0x60000604
    volatile uint32 frc1_ctrl;   //  0x60000608
    volatile uint32 frc1_int;    //  0x6000060C
    volatile uint8  pad[16];
    volatile uint32 frc2_load;   //  0x60000620
    volatile uint32 frc2_count;  //  0x60000624
    volatile uint32 frc2_ctrl;   //  0x60000628
    volatile uint32 frc2_int;    //  0x6000062C
    volatile uint32 frc2_alarm;  //  0x60000630
};

//  single pwm prog

struct SSinglePwmProg
{
	enum EPin Type;	//	pin type
	uint8 Num;			//	GPIO number
	uint16 Mask;    	//  GPIO bit mask
	uint32 Duty;    	//  duty info for pwm/servo
};

//  all GPIO progs

struct SGpioProgs
{
    uint8 Num;      //  total number of pwm/servo
    struct SSinglePwmProg GpioProgs[];
};

//  single wm/servo phase

struct SSinglePhase
{
    uint32 Ticks;   //  delay until next phase, in 200ns units
    uint16 OnMask;  //  single active GPIO on mask
    uint16 OffMask; //  single active GPIO off mask
};

//  all pwm/servo phases

struct SPhases
{
    struct SSinglePhase Phases[MAXNUMPIN + 2];
};

//  allocation for startup pwm/servo data, GPIO table

struct SGpioProgs DGpioProgs =
{
    8,  //  total number of general purpose GPIO
    {
        {Unus, 5,  1<<5,  0},
        {Unus, 4,  1<<4,  0},
        {Unus, 0,  1<<0,  0},
        {Unus, 2,  1<<2,  0},
        {Unus, 14, 1<<14, 0},
        {Unus, 12, 1<<12, 0},
        {Unus, 13, 1<<13, 0},
        {Unus, 15, 1<<15, 0},
    },
};

//  two bank data allocation for transparent pwm/servo phase handling

struct SPhases DPhase[2];

//	encoders

//BA filtered encoder phases table

// 	inc
//     BA  BA  BA  BA
//pre  00  01  11  10
//now  01  11  10  00

//	dec
//     BA  BA  BA  BA
//pre  00  10  11  01
//now  10  11  01  00

//0000	not expected
//0001  inc
//0010  dec
//0011	not expected
//0100  dec
//0101	not expected
//0110	not expected
//0111  inc
//1000  inc
//1001	not expected
//1010	not expected
//1011  dec
//1100	not expected
//1101  dec
//1110  inc
//1111	not expected

uint16 EncoderUpDn[] =
{
	0x0000, 0x0001, 0xffff, 0x0000, 0xffff, 0x0000, 0x0000, 0x0001,
	0x0001, 0x0000, 0x0000, 0xffff, 0x0000, 0xffff, 0x0001,	0x0000,
};

bool A1Prev = false, A2Prev = false, A3Prev = false, A4Prev = false;
bool B1Prev = false, B2Prev = false, B3Prev = false, B4Prev = false;

//	period

uint32	PrevPeriod1, PrevPeriod2, PrevPeriod3, PrevPeriod4, PrevPeriod5, PrevPeriod6, PrevPeriod7, PrevPeriod8;

//  flash R/W
//	all items must be dword aligned

//#pragma pack(push, 4)
//__attribute__((packed,aligned(4)))
//#pragma pack(pop)

#define RAMFLASH 512	//	Size of read only flash read
#define MAXSTRLEN 31	//	Size of parameters names

#define FWL1DATASECTORBEGIN 0x200
#define FWL1DATASECTORNUM 0x80		//	128 sectors
#define FWL1INDEXSECTOR 0x300
#define FWL2DATASECTORBEGIN 0x280
#define FWL2DATASECTORNUM 0x80		//	128 sectors
#define FWL2INDEXSECTOR 0x301

//  pwm/servo phase handling cycle

uint8 InnerPhase = 0, OuterPhase = 0;
bool PhaseToggle = false, NewPhaseReady = false;

//  mask pwm level during servo hole

uint16 ServoMask;

//	timed activity

#ifdef USE_US_TIMER
uint16 Tick2msCounter = 0;
#else
uint16 Tick10msCounter = 0;
#endif
os_timer_t *pTickTimer;
uint8 Tick1SecCounter = 0;
uint8 Tick1MinCounter = 0;
uint8 Tick1HourCounter = 0;
uint16 Tick1DayCounter = 0;

//	DHCP info

struct ip_info DHCPInfo;

//	communication

struct espconn ControllerComm;
esp_udp ControllerCommUDP;
uint8 ControllerCommTXBuf[1024];

//	DNS communication

struct espconn DNSEspconn;

//	configuration

enum EWiFiNetwork WiFiNetworkMode_conf;
char modulename_conf[MAXSTRLEN+1];
struct station_config sta_conf;
struct softap_config sap_conf;
uint8 stamac_conf[6];
uint8 sapmac_conf[6];
uint16 NetControllerUDPPort_conf;
struct ip_info StaticIP_conf;
struct dhcps_lease DhcpLease_conf;
uint8 SoftAPChannel_conf;
struct ip_addr DNS0_conf;
struct ip_addr DNS1_conf;
uint16 CommFaultCountDown_conf;
uint8 CommFaultUseD0_conf;
uint16 ADCOverNumber_conf;
uint16 ADCOverDelay_conf;
uint16 ADCOverShift_conf;
uint8 ADCOverUseD0_conf;
uint8 CPUFreq_conf;

//	firmware upgrade on the air FUOTA

uint8 FUOTAFlashUserID;

#ifdef FUOTA_SUPPORT
uint8 FUOTAHTTPServerIP[16];	// xxx.xxx.xxx.xxx (4x3)+3+1=16
uint16 FUOTAHTTPServerPort;
char FUOTAHTTPFile1[MAXSTRLEN];
char FUOTAHTTPFile2[MAXSTRLEN];
#endif

//	ADC

uint16 ADCValue;
uint8 A0PinType = Unus;

//	background tasks

#define TASK0_QUEUE_LEN   5
#define TASK1_QUEUE_LEN   5
#define TASK2_QUEUE_LEN   5

os_event_t *TaskPrio0Queue;
os_event_t *TaskPrio1Queue;
os_event_t *TaskPrio2Queue;

enum ETaskPrio0Reason
{
	FlashZone1,
	FlashZone2,
	Reboot,
	FuotaOK,
	FuotaKO,
	TEmergencyConf,
	ReadFlashUint16,
};

//	misc

bool CommActive = false;
char ProgStatus = 'N';
uint8 Xchg_O_Status;
uint16 CommFaultCountDown = 0;
bool CommFaultStatus = true;
uint8 local_ip[16];			// xxx.xxx.xxx.xxx (4x3)+3+1=16
uint8 FWL1WriteSector = 0;
uint8 FWL2WriteSector = 0;

//	"const" directive with variable declarations : data is stored in flash and can be accessed directly on any boundary

const char CommStrProtH[] = THEREMINOPROTOCOL" H ";
#ifdef FUOTA_SUPPORT
const char CommStrFUOTA[] = "FUOTA ";
#endif
const char CommStrScan[] = "SCAN";
const char CommStrProg[] = "PROG ";
const char CommStrXchg[] = "XCGI";
const char CommStrName[] = "NAME ";
const char CommStrConf[] = "CONF ";

const char ModuleNameCfgStr[] = "\r\nModuleName";
const char ModuleNameDefStr[] = "NoName";

const char str_crlf[] = "\r\n";
const char str_BOF[] = "BOF";
const char str_EOF[] = "\r\nEOF";
const char char_blank = ' ';
const char char_tab = '\t';
const char WiFiNetworkModeConfStr[] = "\r\nWiFiNetworkMode";
const char WiFiNetworkModeDefStr[] = "SoftAP";
const char WiFiNetworkModeStationDHCP[] = "StationDHCP";
const char WiFiNetworkModeStationStaticStr[] = "StationStatic";

const char NetControllerUDPPortConfStr[] = "\r\nNetHALUDPPort";
const char NetControllerUDPPortDefStr[] = "49152";
const char WiFiNetworkNameConfStr[] = "\r\nWiFiNetworkName";
const char WiFiStaNetworkNameDefStr[] = "NoName";
const char WiFiNetworkPasswordConfStr[] = "\r\nWiFiNetworkPassword";
const char WiFiNetworkPasswordDefStr[] = "password";

const char StaticNetworkIPConfStr[] = "\r\nStaticNetworkIP";
const char StaticNetworkIPDefStr[] = "192.168.0.1";
const char StaticNetworkMaskConfStr[] = "\r\nStaticNetworkMask";
const char StaticNetworkMaskDefStr[] = "255.255.255.0";
const char StaticGatewayConfStr[] = "\r\nStaticGateway";
const char StaticGatewayDefStr[] = "192.168.0.254";
const char StaticDNS0ConfStr[] = "\r\nStaticDNS0";
const char StaticDNS0DefStr[] = "208.67.222.222";
const char StaticDNS1ConfStr[] = "\r\nStaticDNS1";
const char StaticDNS1DefStr[] = "208.67.220.220";

const char SoftAPLeaseStartConfStr[] = "\r\nSoftAPLeaseStart";
const char SoftAPLeaseStartDefStr[] = "192.168.0.2";
const char SoftAPLeaseEndConfStr[] = "\r\nSoftAPLeaseEnd";
const char SoftAPLeaseEndDefStr[] = "192.168.0.253";
const char SoftAPChannelConfStr[] = "\r\nSoftAPChannel";
const char SoftAPChannelDefStr[] = "1";

const char CommFaultDelayConfStr[] = "\r\nCommFaultDelay";
const char CommFaultDelayDefStr[] = "200";
const char CommFaultUseD0ConfStr[] = "\r\nCommFaultUseD0";
const char CommFaultUseD0DefStr[] = "0";

const char ADCOverNumberConfStr[] = "\r\nADCOverNumber";
const char ADCOverNumberDefStr[] = "1";
const char ADCOverDelayConfStr[] = "\r\nADCOverDelay";
const char ADCOverDelayDefStr[] = "0";
const char ADCOverUseD0ConfStr[] = "\r\nADCOverUseD0";
const char ADCOverUseD0DefStr[] = "0";

const char CPUFreqConfStr[] = "\r\nCPUFreq";
const char CPUFreqDefStr[] = "160";

//	using ICACHE_RODATA_ATTR strings are stored in flash and can only be directly accessed only on a dword boundary
//	indirect access using ReadFlashUint8,FlashToStr is possible to access them in any boundary

char ICACHE_RODATA_ATTR CfgEmergencyConf[] = "BOF\r\nWiFiNetworkMode StationDHCP\r\nWiFiNetworkName NoName\r\nWiFiNetworkPassword !!NoName!!\r\nEOF";

//	ESP8266 GPIOs registers pointer

volatile struct SGpioRegs* pGpio = (struct SGpioRegs*)(PERIPHS_GPIO_BASEADDR);

//	ESP8266 timers registers pointer

volatile struct STimerRegs* pTimer = (struct STimerRegs*)(PERIPHS_TIMER_BASEDDR);

/******************************************************************************
 * FunctionName : FTimer1InterruptHandler
 * Description  : Interrupt handler : pwm/servo processing
*******************************************************************************/

ICACHE_RAM_ATTR	//	execution speed up in RAM
void FTimer1InterruptHandler(void)
{
    register uint16 w1ts, w1tc;
    register struct SPhases *pDPhaseActive;

    //	disable timer
    pTimer->frc1_ctrl &= ~TIMER1_ENABLE_TIMER;
    //  use the bank not used in update routine
    pDPhaseActive = PhaseToggle ? &DPhase[0] : &DPhase[1];
    //  next interval (+ some delay to avoid timer rollup before we exit from int. routine)
    //	PERIODTICKS
    pTimer->frc1_load = pDPhaseActive->Phases[InnerPhase].Ticks + 5;
    //  prepare masks
    w1ts = pDPhaseActive->Phases[InnerPhase].OnMask;
    w1tc = pDPhaseActive->Phases[InnerPhase].OffMask;
    //  if servo hole phase
    if(OuterPhase != 0)
    {
        //  clear servo mask on set mask
        w1ts &= ~ServoMask;
        //  set servo mask on clear mask
        w1tc |= ServoMask;
    }
    //  set/reset GPIO output pins
    pGpio->out_w1ts = (uint32)w1ts;
    pGpio->out_w1tc = (uint32)w1tc;
    //  next phase
    InnerPhase++;
    // 	loop at the end
    if(pDPhaseActive->Phases[InnerPhase].Ticks == 0)
    {
    	//	recycle the inner phase starting from 0
        InnerPhase = 0;
        //  next servo hole index
        OuterPhase++;
        //  loop at the end
        if(OuterPhase > 4)
        {
        	//	recycle the outer phase starting from 0
            OuterPhase = 0;
        }
        //  if new data available
        if(NewPhaseReady)
        {
            //  swap banks
            PhaseToggle = !PhaseToggle;
            //  acquired
            NewPhaseReady = false;
        }
    }
    //	reset interrupt flag
    pTimer->frc1_int &= ~FRC1_INT_CLR_MASK;
    //	enable timer
    pTimer->frc1_ctrl |= TIMER1_ENABLE_TIMER;
}

/******************************************************************************
 * FunctionName : FTimer1Init
 * Description  : PWM/Servo timer initialization
*******************************************************************************/

ICACHE_FLASH_ATTR
void FTimer1Init(void)
{
//  timer init
#ifdef TIMER1_USE_NMI
    ETS_FRC_TIMER1_NMI_INTR_ATTACH(FTimer1InterruptHandler);
#else
    ETS_FRC_TIMER1_INTR_ATTACH((ets_isr_t)FTimer1InterruptHandler, NULL);
#endif
    TM1_EDGE_INT_ENABLE();
#ifdef DEBUG_PWM_TIMER
	const char str[] = "[DBG] FTimer1Init\n";
    os_printf(str);
#endif
}

/******************************************************************************
 * FunctionName : FTimer1Start
 * Description  : PWM/Servo timer start
*******************************************************************************/

ICACHE_FLASH_ATTR
void FTimer1Start(void)
{
	//	timer start
	pTimer->frc1_load = PERIODTICKS;
    pTimer->frc1_ctrl |= TIMER1_DIVIDE_BY_16;
    pTimer->frc1_int &= ~FRC1_INT_CLR_MASK;
    pTimer->frc1_ctrl |= TIMER1_ENABLE_TIMER;
#ifdef DEBUG_PWM_TIMER
	const char str[] = "[DBG] FTimer1Start\n";
    os_printf("str");
#endif
}

/******************************************************************************
 * FunctionName : FTimer1Stop
 * Description  : PWM/Servo timer stop
*******************************************************************************/
ICACHE_FLASH_ATTR
void FTimer1Stop(void)
{
    //  timer stop
    pTimer->frc1_ctrl = 0;
#ifdef DEBUG_PWM_TIMER
	const char str[] = "[DBG] FTimer1Stop\n";
    os_printf(str);
#endif
}

/******************************************************************************
 * FunctionName : FPwmUpdate
 * Description  : PWM data update
*******************************************************************************/

ICACHE_RAM_ATTR	//	execution speed up in RAM
void FPwmUpdate(void)
{
	//	if phase data has been already used by the interrupt routine
    if(!NewPhaseReady)
    {
        //  prepare new phase data
        register struct SPhases *pDPhaseUpdate;
        register uint8 i, l, r;
        register uint16 mask;
        uint8 phases = 1;

        //  update the bank not used in interrupt routine
        pDPhaseUpdate = !PhaseToggle ? &DPhase[0] : &DPhase[1];

        //	init
        pDPhaseUpdate->Phases[0].OnMask = 0;
        pDPhaseUpdate->Phases[0].OffMask = 0;
        pDPhaseUpdate->Phases[0].Ticks = 0;

        //	for every pin
        for(i = 0; i < DGpioProgs.Num; i++)
        {
        	//	if pwm or servo
            if((DGpioProgs.GpioProgs[i].Type == Pwmo) || (DGpioProgs.GpioProgs[i].Type == Serv))
            {
                //  speedup mask in local
                mask = DGpioProgs.GpioProgs[i].Mask;
                //  phase 0 always off
                if (DGpioProgs.GpioProgs[i].Duty == 0)
                {
                    pDPhaseUpdate->Phases[0].OffMask |= mask;
                }
                //  phase 0 always on
                else if (DGpioProgs.GpioProgs[i].Duty >= (PERIODTICKS - 1))
                {
                    pDPhaseUpdate->Phases[0].OnMask |= mask;
                }
                // new phase starting on and after some time off
                else
                {
                    pDPhaseUpdate->Phases[0].OnMask |= mask;
                    pDPhaseUpdate->Phases[phases].OnMask = 0;
                    pDPhaseUpdate->Phases[phases].OffMask = mask;
                    pDPhaseUpdate->Phases[phases].Ticks = DGpioProgs.GpioProgs[i].Duty;
                    phases++;
                }
            }
        }
        //  last dummy phase ends the period
        pDPhaseUpdate->Phases[phases].OnMask = 0;
        pDPhaseUpdate->Phases[phases].OffMask = 0;
        pDPhaseUpdate->Phases[phases].Ticks = PERIODTICKS;

        //  sort lowest to hightest duty

        if(phases > 1)
        {

#ifdef BUBBLE_SORT
            //  original bubble sort
            i = 2;
            while (i < phases)
            {
                if (pDPhaseUpdate->Phases[i].Ticks < pDPhaseUpdate->Phases[i - 1].Ticks)
                {
                    struct SSinglePhase t = pDPhaseUpdate->Phases[i];
                    pDPhaseUpdate->Phases[i] = pDPhaseUpdate->Phases[i - 1];
                    pDPhaseUpdate->Phases[i - 1] = t;
                    if (i > 2)
                    {
                        i--;
                    }
                }
                else
                {
                    i++;
                }
            }
#else
            //  Livio's gnome sort
            i = 1;
            while (i < phases)
            {
                if (pDPhaseUpdate->Phases[i].Ticks >= pDPhaseUpdate->Phases[i - 1].Ticks)
                {
                    i++;
                }
                else
                {
                    struct SSinglePhase t = pDPhaseUpdate->Phases[i];
                    pDPhaseUpdate->Phases[i] = pDPhaseUpdate->Phases[i - 1];
                    pDPhaseUpdate->Phases[i - 1] = t;
                    if (i > 1)
                    {
                        i--;
                    }
                }
            }
#endif

            //  if different pins have same duty compact them in one single phase

#ifdef COMPACT_PWM_ARRAY

            l = 1, r = 2;
            while (r <= phases)
            {
                //  if same time
                if (pDPhaseUpdate->Phases[r].Ticks == pDPhaseUpdate->Phases[l].Ticks)
                {
                    //  use same off phase
                    pDPhaseUpdate->Phases[l].OffMask |= pDPhaseUpdate->Phases[r].OffMask;
                }
                else
                {
                    l++;
                    //  if previous has compacted
                    if (l != r)
                    {
                        //  overwrite from right to left
                        pDPhaseUpdate->Phases[l] = pDPhaseUpdate->Phases[r];
                    }
                }
                r++;
            }
            phases = l;
#endif

        }

#ifdef DEBUG_PWM_ABSOLUTE
        //  debug absolute timings
        for (i = 0; i <= phases; i++)
        {
            os_printf("[DBG] DEBUG_PWM_ABSOLUTE %d : %04x %04x %d\n", i, pDPhaseUpdate->Phases[i].OnMask, pDPhaseUpdate->Phases[i].OffMask, pDPhaseUpdate->Phases[i].Ticks);
        }
#endif

        //  transform absolute timings to interval timings

        for (i = 0; i < phases; i++)
        {
            pDPhaseUpdate->Phases[i].Ticks = pDPhaseUpdate->Phases[i + 1].Ticks - pDPhaseUpdate->Phases[i].Ticks;
        }
        //  last dummy phase used to recycle is identified by Ticks = 0
        pDPhaseUpdate->Phases[phases].Ticks = 0;

#ifdef DEBUG_PWM_RELATIVE
        //  debug relative timings
        for (i = 0; i <= phases; i++)
        {
            os_printf("[DBG] DEBUG_PWM_RELATIVE %d : %04x %04x %d\n", i, pDPhaseUpdate->Phases[i].OnMask, pDPhaseUpdate->Phases[i].OffMask, pDPhaseUpdate->Phases[i].Ticks);
        }
#endif

        //	data ready
        NewPhaseReady = true;
    }
}


/******************************************************************************
 * FunctionName : FGpioPullupEnable
 * Description  : GPIO pullup enable
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpioPullupEnable(uint8 Gpio)
{
	switch(Gpio)
	{
    //	D1
	case 0:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_GPIO5_U);
		break;
	//	D2
	case 1:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_GPIO4_U);
		break;
	//	D3
	case 2:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_GPIO0_U);
		break;
	//	D4
	case 3:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_GPIO2_U);
		break;
	//	D5
	case 4:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_MTMS_U);
		break;
	//	D6
	case 5:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_MTDI_U);
		break;
	//	D7
	case 6:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_MTCK_U);
		break;
	//	D8
	case 7:
		PIN_PULLUP_EN(PERIPHS_IO_MUX_MTDO_U);
		break;
	}
}

/******************************************************************************
 * FunctionName : FGpioPullupDisable
 * Description  : GPIO pullup disable
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpioPullupDisable(uint8 Gpio)
{
	switch(Gpio)
	{
    //	D1
	case 0:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_GPIO5_U);
		break;
	//	D2
	case 1:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_GPIO4_U);
		break;
	//	D3
	case 2:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_GPIO0_U);
		break;
	//	D4
	case 3:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_GPIO2_U);
		break;
	//	D5
	case 4:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_MTMS_U);
		break;
	//	D6
	case 5:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_MTDI_U);
		break;
	//	D7
	case 6:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_MTCK_U);
		break;
	//	D8
	case 7:
		PIN_PULLUP_DIS(PERIPHS_IO_MUX_MTDO_U);
		break;
	}
}

/******************************************************************************
 * FunctionName : FGpioSetup
 * Description  : GPIO setup
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpioSetup(void)
{
    uint8 i;
    uint32 pwmservomask = 0, servomask = 0, inputmask = 0, outputmask = 0;
    FTimer1Stop();
    //  for every pin
    for(i = 0; i < DGpioProgs.Num; i++)
    {
    	switch(DGpioProgs.GpioProgs[i].Type)
    	{
			//  if unused or digital input
    	case Unus:
    	case Dgin:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	no GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_DISABLE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
			//  if digital input pullup
    	case Dgip:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	no GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_DISABLE);
			//	enable pullup
			FGpioPullupEnable(i);
			break;
			//  if counter or period
    	case Coun:
    	case Peri:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	yes GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_POSEDGE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
			//  if period pullup
    	case Perp:
    	case Coup:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	yes GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_POSEDGE);
			//	enable pullup
			FGpioPullupEnable(i);
			break;
			//  if encoder
    	case Enca:
    	case Encb:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	yes GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_ANYEDGE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
			//  if encoder pullup
    	case Enap:
    	case Enbp:
			//  build input pin mask
			inputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	yes GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_ANYEDGE);
			//	enable pullup
			FGpioPullupEnable(i);
			break;
			//  if digital output
    	case Dgou:
			//  build output pin mask
			outputmask |= DGpioProgs.GpioProgs[i].Mask;
			//	no GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_DISABLE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
			//  if pwm
    	case Pwmo:
			//  build pwmservo pin mask
			pwmservomask |= DGpioProgs.GpioProgs[i].Mask;
			//	no GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_DISABLE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
			//  if servo
    	case Serv:
			//  build servo pin mask
			servomask |= DGpioProgs.GpioProgs[i].Mask;
			//  build pwmservo pin mask
			pwmservomask |= DGpioProgs.GpioProgs[i].Mask;
			//	no GPIO interrupt
			gpio_pin_intr_state_set(DGpioProgs.GpioProgs[i].Num, GPIO_PIN_INTR_DISABLE);
			//	disable pullup
			FGpioPullupDisable(i);
			break;
    	}
    }
    //  reset and prog all output pin
    pGpio->enable_w1ts = pwmservomask | outputmask;
    //  reset and prog all input pin
    pGpio->enable_w1tc = inputmask;
    //  store servo pin mask
    ServoMask = servomask;
    //  if pwm or servo init pwm handling
    if(pwmservomask)
    {
        PhaseToggle = false;
        NewPhaseReady = false;
        //  update phase
        FPwmUpdate();
        //  swap banks
        PhaseToggle = !PhaseToggle;
        //  start timer
        FTimer1Start();
    }
}

/******************************************************************************
 * FunctionName : FGpioInterruptHandler
 * Description  : Callback function : GPIO input has changed level
*******************************************************************************/

ICACHE_RAM_ATTR	//	execution speed up in RAM
void FGpioInterruptHandler(void * pFoo)
{
	register uint32 IntStatReg;
	register uint32 Input;
	register uint32	Tmp;
#ifndef ENCODER_TYPE_1
	bool PrevAPhase, PrevBPhase;
	uint8 EncoderUpDnIndex;
#endif
	//	read interrupt status
	IntStatReg = pGpio->status;
	//	read inputs
	Input = pGpio->in;
	//	if GPIO D1 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[0].Mask)
	{
		//	if D1 level toggled
		switch(DGpioProgs.GpioProgs[0].Type)
		{
		//	if counter or counter pullup
		case Coun:
		case Coup:
			//	increase count
			DGpioProgs.GpioProgs[0].Duty++;
			break;
			//	if encoder or encoder pullup
		case Enca:
		case Enap:
			//	A
			//	acquire A and B phase levels
			PrevAPhase = (Input & DGpioProgs.GpioProgs[0].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[1].Mask) ? true : false;
			//	get the table index from old and actual levels
			EncoderUpDnIndex = (B1Prev << 3) + (A1Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			//	encoder count increments or decreases according to the table
			DGpioProgs.GpioProgs[0].Duty += EncoderUpDn[EncoderUpDnIndex];
			//	store actual phase levels as previous ones
			A1Prev = PrevAPhase;
			B1Prev = PrevBPhase;
			break;
		//	if period or period pullup
		case Peri:
		case Perp:
			//	read actual count
			Tmp = pTimer->frc2_count;
			//	store difference from previous count
			DGpioProgs.GpioProgs[0].Duty = (Tmp - PrevPeriod1) & 0xffff;
			//	store actual count as previous one
			PrevPeriod1 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[0].Mask;
	}
	//	if D2 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[1].Mask)
	{
		switch(DGpioProgs.GpioProgs[1].Type)
		{
		//	if counter or counter pullup
		case Coun:
		case Coup:
			//	increase count
			DGpioProgs.GpioProgs[1].Duty++;
			break;
		case Encb:
		case Enbp:
			//	B
			//	acquire A and B phase levels
			PrevAPhase = (Input & DGpioProgs.GpioProgs[0].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[1].Mask) ? true : false;
			//	get the table index from old and actual levels
			EncoderUpDnIndex = (B1Prev << 3) + (A1Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			//	encoder count increments or decreases according to the table
			DGpioProgs.GpioProgs[0].Duty += EncoderUpDn[EncoderUpDnIndex];
			//	store actual phase levels as previous ones
			A1Prev = PrevAPhase;
			B1Prev = PrevBPhase;
			break;
		case Peri:
		case Perp:
			//	read actual count
			Tmp = pTimer->frc2_count;
			//	store difference from previous count
			DGpioProgs.GpioProgs[1].Duty = (Tmp - PrevPeriod2) & 0xffff;
			//	store actual count as previous one
			PrevPeriod2 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[1].Mask;
	}
	//	if D3 level toggled - cannot be input because of special function at boot time, it enable flashing mode if low
	if(IntStatReg & DGpioProgs.GpioProgs[2].Mask)
	{
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[2].Mask;
	}
	//	if D4 level toggled - cannot be encoder B because of D3 cannot be encoder A
	if(IntStatReg & DGpioProgs.GpioProgs[3].Mask)
	{
		switch(DGpioProgs.GpioProgs[3].Type)
		{
		case Coun:
		case Coup:
			DGpioProgs.GpioProgs[3].Duty++;
			break;
		case Peri:
		case Perp:
			Tmp = pTimer->frc2_count;
			DGpioProgs.GpioProgs[3].Duty = (Tmp - PrevPeriod4) & 0xffff;
			PrevPeriod4 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[3].Mask;
	}
	//	if D5 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[4].Mask)
	{
		switch(DGpioProgs.GpioProgs[4].Type)
		{
		case Coun:
		case Coup:
			DGpioProgs.GpioProgs[4].Duty++;
			break;
		case Enca:
		case Enap:
			//	A
			PrevAPhase = (Input & DGpioProgs.GpioProgs[4].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[5].Mask) ? true : false;
			EncoderUpDnIndex = (B3Prev << 3) + (A3Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			DGpioProgs.GpioProgs[4].Duty += EncoderUpDn[EncoderUpDnIndex];
			A3Prev = PrevAPhase;
			B3Prev = PrevBPhase;
			break;
		case Peri:
		case Perp:
			Tmp = pTimer->frc2_count;
			DGpioProgs.GpioProgs[4].Duty = (Tmp - PrevPeriod5) & 0xffff;
			PrevPeriod5 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[4].Mask;
	}
	//	if D6 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[5].Mask)
	{
		switch(DGpioProgs.GpioProgs[5].Type)
		{
		case Coun:
		case Coup:
			DGpioProgs.GpioProgs[5].Duty++;
			break;
		case Encb:
		case Enbp:
			//	B
			PrevAPhase = (Input & DGpioProgs.GpioProgs[4].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[5].Mask) ? true : false;
			EncoderUpDnIndex = (B3Prev << 3) + (A3Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			DGpioProgs.GpioProgs[4].Duty += EncoderUpDn[EncoderUpDnIndex];
			A3Prev = PrevAPhase;
			B3Prev = PrevBPhase;
			break;
		case Peri:
		case Perp:
			Tmp = pTimer->frc2_count;
			DGpioProgs.GpioProgs[5].Duty = (Tmp - PrevPeriod6) & 0xffff;
			PrevPeriod6 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[5].Mask;
	}
	//	if D7 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[6].Mask)
	{
		switch(DGpioProgs.GpioProgs[6].Type)
		{
		case Coun:
		case Coup:
			DGpioProgs.GpioProgs[6].Duty++;
			break;
		case Enca:
		case Enap:
			//	A
			PrevAPhase = (Input & DGpioProgs.GpioProgs[6].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[7].Mask) ? true : false;
			EncoderUpDnIndex = (B4Prev << 3) + (A4Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			DGpioProgs.GpioProgs[6].Duty += EncoderUpDn[EncoderUpDnIndex];
			A4Prev = PrevAPhase;
			B4Prev = PrevBPhase;
			break;
		case Peri:
		case Perp:
			Tmp = pTimer->frc2_count;
			DGpioProgs.GpioProgs[6].Duty = (Tmp - PrevPeriod7) & 0xffff;
			PrevPeriod7 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[6].Mask;
	}
	//	if D8 level toggled
	if(IntStatReg & DGpioProgs.GpioProgs[7].Mask)
	{
		switch(DGpioProgs.GpioProgs[7].Type)
		{
		case Coun:
		case Coup:
			DGpioProgs.GpioProgs[7].Duty++;
			break;
		case Encb:
		case Enbp:
			//	B
			PrevAPhase = (Input & DGpioProgs.GpioProgs[6].Mask) ? true : false;
			PrevBPhase = (Input & DGpioProgs.GpioProgs[7].Mask) ? true : false;
			EncoderUpDnIndex = (B4Prev << 3) + (A4Prev << 2) + (PrevBPhase << 1) + (PrevAPhase);
			DGpioProgs.GpioProgs[6].Duty += EncoderUpDn[EncoderUpDnIndex];
			A4Prev = PrevAPhase;
			B4Prev = PrevBPhase;
			break;
		case Peri:
		case Perp:
			Tmp = pTimer->frc2_count;
			DGpioProgs.GpioProgs[7].Duty = (Tmp - PrevPeriod8) & 0xffff;
			PrevPeriod8 = Tmp;
			break;
		}
		pGpio->status_w1tc |= DGpioProgs.GpioProgs[7].Mask;
	}
}

/******************************************************************************
 * FunctionName : FGpio16Enable
 * Description  : Enable GPIO 16 (D0)
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpio16Enable(void)
{
	//	mux configuration for XPD_DCDC to output rtc_gpio0
	WRITE_PERI_REG(PAD_XPD_DCDC_CONF, (READ_PERI_REG(PAD_XPD_DCDC_CONF) & 0xffffffbc) | (uint32)0x1);

	//	mux configuration for out enable
	WRITE_PERI_REG(RTC_GPIO_CONF, (READ_PERI_REG(RTC_GPIO_CONF) & (uint32)0xfffffffe) | (uint32)0x0);
}

/******************************************************************************
 * FunctionName : FGpio16OutputConf
 * Description  : Configure GPIO 16 (D0) as output
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpio16OutputConf(void)
{
	//	output enable
	WRITE_PERI_REG(RTC_GPIO_ENABLE, (READ_PERI_REG(RTC_GPIO_ENABLE) & (uint32)0xfffffffe) | (uint32)0x1);
}

/******************************************************************************
 * FunctionName : FGpio16InputConf
 * Description  : Configure GPIO 16 (D0) as input
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpio16InputConf()
{
	// input enabled
	WRITE_PERI_REG(RTC_GPIO_ENABLE, READ_PERI_REG(RTC_GPIO_ENABLE) & ~1);
}

/******************************************************************************
 * FunctionName : FGpio16InputGet
 * Description  : Read GPIO 16 (D0) level
*******************************************************************************/

ICACHE_FLASH_ATTR
bool FGpio16InputGet()
{
	// read the input state
	return READ_PERI_REG(RTC_GPIO_IN_DATA) & 1;
}

/******************************************************************************
 * FunctionName : FGpio16OutputSet
 * Description  : Set GPIO 16 (D0) low(0)/high(1)
*******************************************************************************/

ICACHE_FLASH_ATTR
void FGpio16OutputSet(uint8 value)
{
	//	set GPIO 16 level
	WRITE_PERI_REG(RTC_GPIO_OUT, (READ_PERI_REG(RTC_GPIO_OUT) & (uint32)0xfffffffe) | (uint32)(value & 1));
}

/******************************************************************************
 * FunctionName : inet_pton4
 * Description  : Conversion of IPv4 from string to uint32
*******************************************************************************/

#define NS_INADDRSZ 4

ICACHE_FLASH_ATTR
uint32 inet_pton4(const char *src, struct ip_addr *dst)
{
	const char digits[] = "0123456789";
	int saw_digit, octets, ch;
	uint8 tmp[NS_INADDRSZ], *tp;

	saw_digit = 0;
	octets = 0;
	*(tp = tmp) = 0;
	while ((ch = *src++) != '\0')
	{
		const char *pch;

		if ((pch = strchr(digits, ch)) != NULL)
		{
			u_int new = *tp * 10 + (pch - digits);

			if (new > 255)
				return (0);
			*tp = new;
			if (! saw_digit)
			{
				if (++octets > 4)
					return (0);
				saw_digit = 1;
			}
		}
		else if (ch == '.' && saw_digit)
		{
			if (octets == 4)
				return (0);
			*++tp = 0;
			saw_digit = 0;
		}
		else
		{
			return (0);
		}
	}
	if (octets < 4)
		return (0);

	memcpy(dst, tmp, NS_INADDRSZ);
	return (1);
}

/******************************************************************************
 * FunctionName : FUpgradeStatesCheckCB
 * Description  : Callback function : check FUOTA upgrade result
*******************************************************************************/

#ifdef FUOTA_SUPPORT
ICACHE_FLASH_ATTR
void FUpgradeStatesCheckCB(void *arg)
{
    struct upgrade_server_info *pusi = arg;
    if (pusi->upgrade_flag == true)
    {
        os_printf("[DBG] FUpgradeStatesCheckCB success!\n");
        os_free(pusi->url);
        os_free(pusi);
        //	goto execute system_upgrade_reboot
        if(!system_os_post(USER_TASK_PRIO_0, FuotaOK, 0))
        {
        }
    }
    else
    {
        os_printf("[DBG] FUpgradeStatesCheckCB failed!\n");
        os_free(pusi->url);
        os_free(pusi);
        //  start interrupt
        if(!system_os_post(USER_TASK_PRIO_0, FuotaKO, 0))
        {
        }
    }
}
#endif

/******************************************************************************
 * FunctionName : FFUOTA
 * Description  : Process the FUOTA request
*******************************************************************************/

#ifdef FUOTA_SUPPORT
ICACHE_FLASH_ATTR
bool FFUOTA(char *pPar)
{
	bool ret;
    uint8 l;
    uint8 UserID;
    char *pscan_b, *pscan_e, *pFileName;

    pscan_b = pPar;
    
    //	"<IP> "
    pscan_e = (char *)os_strstr(pscan_b, " ");
    l = pscan_e - pscan_b;
    os_bzero(FUOTAHTTPServerIP, sizeof(FUOTAHTTPServerIP));
    os_memcpy(FUOTAHTTPServerIP, pscan_b, l);
    os_printf("[CFG] FUOTAHTTPServerIP : %s\n", FUOTAHTTPServerIP);
    pscan_b = pscan_e + 1;
    //	"<PORT> "
    FUOTAHTTPServerPort = atoi(pscan_b);
    os_printf("[CFG] FUOTAHTTPServerPort : %d\n", FUOTAHTTPServerPort);
    pscan_e = (char *)os_strstr(pscan_b, " ");
    pscan_b = pscan_e + 1;
    //	"<FILE1>"
    pscan_e = (char *)os_strstr(pscan_b, " ");
    l = pscan_e - pscan_b;
    os_bzero(FUOTAHTTPFile1, sizeof(FUOTAHTTPFile1));
    os_memcpy(FUOTAHTTPFile1, pscan_b, l);
    os_printf("[CFG] FUOTAHTTPFile1 : %s\n", FUOTAHTTPFile1);
    pscan_b = pscan_e + 1;
    //	"<FILE2>"
    pscan_e = (char *)os_strstr(pscan_b, " ");
    l = pscan_e - pscan_b;
    os_bzero(FUOTAHTTPFile2, sizeof(FUOTAHTTPFile2));
    os_memcpy(FUOTAHTTPFile2, pscan_b, l);
    os_printf("[CFG] FUOTAHTTPFile2 : %s\n", FUOTAHTTPFile2);
    
    struct upgrade_server_info* pusi = (struct upgrade_server_info *)os_zalloc(sizeof(struct upgrade_server_info));
    if(pusi != 0)
    {
		//  struct espconn *pespconn;   need not set unless using Espressif Cloud
		//  uint8 pre_version[16];      need not set
		//  uint8 upgrade_version[16];  need not set
		//  uint8 upgrade_flag;         need not set
		//  uint8 ip[4]                 used
		//  uint16 port                 used
		//  uint32 check_times          used

		//  server IP
		//	uint8[4] IP
		//	if valid IPv4
		if(inet_pton4(FUOTAHTTPServerIP, (struct ip_addr *)&pusi->ip) == 1)
		{
			switch (FUOTAFlashUserID)
			{
			case UPGRADE_FW_BIN1:
				//user1 flash portion in use, upgrade using user2
				pFileName = FUOTAHTTPFile2;
				break;
			case UPGRADE_FW_BIN2:
				//user2 flash portion in use, upgrade using user1
				pFileName = FUOTAHTTPFile1;
				break;
			}
			//  server port
			//  uint16 port;
			pusi->port = FUOTAHTTPServerPort;
			//  the whole update process must be finished before this elapsed time in milliseconds
			pusi->check_times = 30000;
			//  download callback
			pusi->check_cb = FUpgradeStatesCheckCB;
			//  build a GET request to the Fuota Web Server
			pusi->url = (uint8 *)os_zalloc(256);
			if(pusi->url != 0)
			{
				os_sprintf(pusi->url, "GET /%s HTTP/1.1\r\nHost: %s:%d\r\nConnection: keep-alive\r\nCache-Control: no-cache\r\n\r\n", pFileName, FUOTAHTTPServerIP, pusi->port);
				os_printf("[DBG] FUOTA : GET /%s HTTP/1.1\r\nHost: %s:%d\r\nConnection: keep-alive\r\nCache-Control: no-cache\r\n\r\n", pFileName, FUOTAHTTPServerIP, pusi->port);
				//  stop interrupt
				FTimer1Stop();
				//  start upgrade
				if (system_upgrade_start(pusi) == true)
				{
					os_printf("[DBG] FUOTA : started...\n");
					ret = true;
				}
				else
				{
					os_printf("[DBG] FUOTA : could not start\n");
					os_free(pusi->url);
					os_free(pusi);
					//  start interrupt
					FTimer1Start();
					ret = false;
				}
			}
			else
			{
				os_free(pusi);
				ret = false;
			}
		}
		else
		{
			os_free(pusi);
			ret = false;
		}
    }
    else
    {
    	ret = false;
    }
    return ret;
}
#endif

/******************************************************************************
 * FunctionName : FSpiFlashEraseSector
 * Description  : Erase 4K sector from flash, must be executed in RAM
*******************************************************************************/

ICACHE_RAM_ATTR
void FSpiFlashEraseSector(const uint16 Sect)
{
	if(spi_flash_erase_sector(Sect) != SPI_FLASH_RESULT_OK)
	{
		os_printf("[DBG] spi_flash_erase_sector %04X : ***KO***\n", Sect);
	}
}

/******************************************************************************
 * FunctionName : FReadFlashUint8
 * Description  : Read bytes everywhere in flash (access is always dword boundary)
*******************************************************************************/

ICACHE_FLASH_ATTR
uint8 FReadFlashUint8(const uint8 *addr)
{
	//	must be volatile to avoid memory access exceptions
	volatile uint32 bytes;
    bytes = *(uint32*)((uint32)addr & ~3);
    return ((uint8*)&bytes)[(uint32)addr & 3];
}

/******************************************************************************
 * FunctionName : FReadFlashUint16
 * Description  : Read words everywhere in flash (access is always dword boundary)
*******************************************************************************/

ICACHE_FLASH_ATTR
uint16 FReadFlashUint16(const uint8 *addr)
{
	return (FReadFlashUint8(addr + 1) << 8) | FReadFlashUint8(addr);
}

/******************************************************************************
 * FunctionName : FStrCpyFlashToRam
 * Description  : Copy one string from flash to RAM
*******************************************************************************/

ICACHE_FLASH_ATTR
void FStrCpyFlashToRam(char *pFlashStr, char *pRamStr)
{
	char *pFlashStrSrc = pFlashStr, *pRamStrDst = pRamStr, OneChar;
	do
	{
		OneChar = FReadFlashUint8(pFlashStrSrc++);
		*(pRamStrDst++) = OneChar;
	}
	while(OneChar != 0);
}

/******************************************************************************
 * FunctionName : FFlashWrite
 * Description  : Write to flash
*******************************************************************************/


ICACHE_FLASH_ATTR
void FFlashWrite(uint16 FlashSector, void *pData, uint32 DataOffset, uint16 DataLenght)
{
	uint32 FlashSectorOffset = FlashSector << 12;

	//	write struct element to flash
	if(spi_flash_write(FlashSectorOffset + DataOffset, pData, DataLenght) != SPI_FLASH_RESULT_OK)
	{
        os_printf("[DBG] spi_flash_write : ***KO***\n");
	}
}

/******************************************************************************
 * FunctionName : FFlashRead
 * Description  : Read from flash
*******************************************************************************/

ICACHE_FLASH_ATTR
void FFlashRead(uint16 FlashSector, void *pRetValue, uint32 Offset, uint16 DataLenght)
{
	uint32 FlashSectorOffset = FlashSector << 12;

	//	read struct element from flash
	if(spi_flash_read(FlashSectorOffset + Offset, pRetValue, DataLenght) != SPI_FLASH_RESULT_OK)
	{
        os_printf("[DBG] spi_flash_read : ***KO***\n");
	}
}

/******************************************************************************
 * FunctionName : FGetRAMChecksum
 * Description  : Computes the checksum of a portion of RAM
*******************************************************************************/

ICACHE_FLASH_ATTR
uint8 FGetRAMChecksum(char *pCfgStr, uint16 DataLenght)
{
	uint16 i;
	uint8 Checksum = 0;

	for(i = 0; i < DataLenght; i++)
	{
		Checksum += pCfgStr[i];
	}
	return Checksum;
}

/******************************************************************************
 * FunctionName : FGetFlashChecksum
 * Description  : Computes the checksum of a portion of flash sector
*******************************************************************************/

ICACHE_FLASH_ATTR
uint8 FGetFlashChecksum(uint16 FlashSector, uint16 DataOffset, uint16 DataLenght)
{
	uint16 i;
	uint8 Checksum = 0;
	uint8 v;

	for(i = 0; i < DataLenght; i++)
	{
		FFlashRead(FlashSector, &v, DataOffset + i, 1);
		Checksum += v;
	}
	return Checksum;
}

/******************************************************************************
 * FunctionName : FWL1Write
 * Description  : Write parameters in flash with wear leveling algorithm
*******************************************************************************/
//	FWL1WriteSector is initialized with 0 only at boot time
//	FWL1WriteSector is the current over writable sector

ICACHE_FLASH_ATTR
void FWL1Write(char* pCfgStr)
{
	uint32 v;
	uint8 Checksum;
	uint16 DataLenght;
	char *pscan_BOF, *pscan_EOF;

	pscan_BOF = (char *)os_strstr(pCfgStr, str_BOF);
	pscan_EOF = (char *)os_strstr(pCfgStr, str_EOF);
	DataLenght = pscan_EOF - pscan_BOF + strlen(pscan_EOF);
	DataLenght += DataLenght % 4;
	Checksum = FGetRAMChecksum(pCfgStr, DataLenght);

	//	erase current indexed data sector
	FSpiFlashEraseSector(FWL1DATASECTORBEGIN + FWL1WriteSector);
	//	write single parameters at indexed data sector
	FFlashWrite(FWL1DATASECTORBEGIN + FWL1WriteSector, pCfgStr, 0, DataLenght);
	//	if we are (again) at first indexed sector
	if(FWL1WriteSector % FWL1DATASECTORNUM == 0)
	{
		//	and the sector has been already used (marked with 0)
		FFlashRead(FWL1INDEXSECTOR, &v, 0, 4);
		if ((v >> 24) == 0)
		{
			// 	we have to erase all the index sector
			FSpiFlashEraseSector(FWL1INDEXSECTOR);
			os_printf("[DBG] FWL1Write FSpiFlashEraseSector FWL2INDEXSECTOR\n");
		}
	}
	//	mark the current index sector with 0 + checksum + lenght
	v = (Checksum << 16) | DataLenght;
	FFlashWrite(FWL1INDEXSECTOR, &v, FWL1WriteSector * 4, 4);

	os_printf("[DBG] FWL1Write config write at offset %d\n", FWL1WriteSector);
	os_printf("[DBG] FWL1Write config write v : %08X\n", v);

	//	set next over writable sector
	FWL1WriteSector++;
	FWL1WriteSector &= ~FWL1DATASECTORNUM;
}

/******************************************************************************
 * FunctionName : FWL2Write
 * Description  : Write parameters in flash with wear leveling algorithm
*******************************************************************************/
//	FWL2WriteSector is initialized with 0 only at boot time
//	FWL2WriteSector is the current over writable sector

ICACHE_FLASH_ATTR
void FWL2Write(char* pCfgStr)
{
	uint32 v;
	uint8 Checksum;
	uint16 DataLenght;
	char *pscan_BOF, *pscan_EOF;

	pscan_BOF = (char *)os_strstr(pCfgStr, str_BOF);
	pscan_EOF = (char *)os_strstr(pCfgStr, str_EOF);
	DataLenght = pscan_EOF - pscan_BOF + strlen(pscan_EOF);
	DataLenght += DataLenght % 4;
	Checksum = FGetRAMChecksum(pCfgStr, DataLenght);

	//	erase current indexed data sector
	FSpiFlashEraseSector(FWL2DATASECTORBEGIN + FWL2WriteSector);
	//	write single parameters at indexed data sector
	FFlashWrite(FWL2DATASECTORBEGIN + FWL2WriteSector, pCfgStr, 0, DataLenght);
	//	if we are (again) at first indexed sector
	if(FWL2WriteSector % FWL2DATASECTORNUM == 0)
	{
		//	and the sector has been already used (marked with 0)
		FFlashRead(FWL2INDEXSECTOR, &v, 0, 4);
		if ((v >> 24) == 0)
		{
			// 	we have to erase all the index sector
			FSpiFlashEraseSector(FWL2INDEXSECTOR);
			os_printf("[DBG] FWL2Write FSpiFlashEraseSector FWL2INDEXSECTOR\n");
		}
	}
	//	mark the current index sector with 0 + checksum + lenght
	v = (Checksum << 16) | DataLenght;
	FFlashWrite(FWL2INDEXSECTOR, &v, FWL2WriteSector * 4, 4);

	os_printf("[DBG] FWL2Write config write at offset %d\n", FWL2WriteSector);
	os_printf("[DBG] FWL2Write config write v : %08X\n", v);

	//	set next over writable sector
	FWL2WriteSector++;
	FWL2WriteSector &= ~FWL2DATASECTORNUM;
}

/******************************************************************************
 * FunctionName : FWL1Read
 * Description  : Read parameters in flash
*******************************************************************************/
//	vPrev(3) = 0x00/0xff
//	vPrev(2) = data checksum
//	vPrev(01) = data len

ICACHE_FLASH_ATTR
void FWL1Read(char* pCfgStr)
{
	uint32 v;
	uint32 vPrev = 0xffffffff;
	uint8 Checksum;

	//	looks for the first free sector index marked with 0xffxxxxxx within the FWL1DATASECTORNUM available sectors marks
	while(true)
	{
		//read a dword
		FFlashRead(FWL1INDEXSECTOR, &v, FWL1WriteSector * 4, 4);
		//	if found
		if((v >> 24) == 0xff)
		{
			//	exit from loop
			break;
		}
		//	store the sector mark just read
		vPrev = v;
		//	go to next sector mark
		FWL1WriteSector++;
		//	if we have reach the begin again
		if((FWL1WriteSector % FWL1DATASECTORNUM) == 0)
		{
			// exit from loop
			break;
		}
	};

	//	if found at least one marked sector index(0x00xxxxxx) in the previous sector index
	if((vPrev >> 24) == 0)
	{
		os_printf("[DBG] FWL1Read vPrev : %08X\n", vPrev);
		//	the valid index is the previous one
		FWL1WriteSector--;
		//	this is the original checksum read from index sector
		Checksum = (vPrev >> 16);
		//	if it is the same as the one calculated from data read from flash
		if (Checksum == FGetFlashChecksum(FWL1DATASECTORBEGIN + FWL1WriteSector, 0, (vPrev & 0xffff)))
		{
			//	read parameters
			FFlashRead(FWL1DATASECTORBEGIN + FWL1WriteSector, pCfgStr, 0, (vPrev & 0xffff));

			os_printf("[DBG] FWL1Read config read at sector index %d\n", FWL1WriteSector);
			//	set next over writable sector
			FWL1WriteSector++;
			FWL1WriteSector &= ~FWL1DATASECTORNUM;
		}
		//	if checksum is not correct (something is gone wrong writing?)
		else
		{
			// parameters are default
			os_printf("[DBG] FWL1Read config not valid : using default\n");
			//	restart from first writable flash sector
			FWL1WriteSector = 0;
		}
	}
	//	if NOT found at least one marked index (the flash has never been used?)
	else
	{
		// parameters are default
		os_printf("[DBG] FWL1Read config not found : using default\n");
		//	restart from first writable flash sector
		FWL1WriteSector = 0;
	}
}

/******************************************************************************
 * FunctionName : FWL2Read
 * Description  : Read parameters in flash
*******************************************************************************/
//	vPrev(3) = 0x00/0xff
//	vPrev(2) = data checksum
//	vPrev(01) = data len

ICACHE_FLASH_ATTR
void FWL2Read(char* pCfgStr)
{
	uint32 v;
	uint32 vPrev = 0xffffffff;
	uint8 Checksum;

	//	looks for the first free sector index marked with 0xffxxxxxx within the FWL2DATASECTORNUM available sectors marks
	while(true)
	{
		//read a dword
		FFlashRead(FWL2INDEXSECTOR, &v, FWL2WriteSector * 4, 4);
		//	if found
		if((v >> 24) == 0xff)
		{
			//	exit from loop
			break;
		}
		//	store the sector mark just read
		vPrev = v;
		//	go to next sector mark
		FWL2WriteSector++;
		//	if we have reach the begin again
		if((FWL2WriteSector % FWL2DATASECTORNUM) == 0)
		{
			// exit from loop
			break;
		}
	};

	//	if found at least one marked sector index(0x00xxxxxx)
	if((vPrev >> 24) == 0)
	{
		os_printf("[DBG] FWL2Read vPrev : %08X\n", vPrev);
		//	the valid index is the previous one
		FWL2WriteSector--;
		//	this is the original checksum read from index sector
		Checksum = (vPrev >> 16);
		//	if it is the same as the one calculated from data read from flash
		if (Checksum == FGetFlashChecksum(FWL2DATASECTORBEGIN + FWL2WriteSector, 0, (vPrev & 0xffff)))
		{
			//	read parameters
			FFlashRead(FWL2DATASECTORBEGIN + FWL2WriteSector, pCfgStr, 0, (vPrev & 0xffff));

			os_printf("[DBG] FWL2Read read at sector index %d\n", FWL2WriteSector);
			//	set next over writable sector
			FWL2WriteSector++;
			FWL2WriteSector &= ~FWL2DATASECTORNUM;
		}
		//	if checksum is not correct (something is gone wrong writing?)
		else
		{
			// parameters are default
			os_printf("[DBG] FWL2Read config not valid : using default\n");
			//	restart from first writable flash sector
			FWL2WriteSector = 0;
		}
	}
	//	if NOT found at least one marked index (the flash has never been used?)
	else
	{
		// parameters are default
		os_printf("[DBG] FWL2Read config not found : using default\n");
		//	restart from first writable flash sector
		FWL2WriteSector = 0;
	}
}

/******************************************************************************
 * FunctionName : FUDPCommCB
 * Description  : Callback function : communication data received
*******************************************************************************/

ICACHE_RAM_ATTR	//	execution speed up in RAM
void FUDPCommCB(void *arg, char *pusrdata, unsigned short lenght)
{
	struct espconn *pconn = arg;
	remot_info *premot = NULL;

	if(espconn_get_connection_info(pconn, &premot, 0) == ESPCONN_OK)
	{
        char *pscan_b, *pscan_e, *pscan_n;
        //	is it network protocol recognized?
        pscan_e = (char *)os_strstr(pusrdata, CommStrProtH);
        if(pscan_e != NULL)
        {
        	//	if yes
            pscan_e = pscan_e + os_strlen(CommStrProtH);
            pscan_b = pscan_e;
            //  is it XCGI command?
            pscan_e = (char *)os_strstr(pscan_b, CommStrXchg);
            if(pscan_e != NULL)
            {
            	//	if yes
                pscan_e = pscan_e + os_strlen(CommStrXchg);
                //	is it already programmed ?
                if(ProgStatus == 'Y')
                {
                    //  OUTPUT
                    //  init output
                    uint8 pwmservo_changed = 0;
                    uint8 i;
                    uint32 w1ts = 0;
                    uint32 w1tc = 0;
                    Xchg_O_Status = 'Y';

                    //  process output
                    while(os_strlen(pscan_e) != 0)
                    {
                    	if(*pscan_e == ' ')
                    	{
                    		pscan_e = pscan_e + 1;
                    	}
                    	if(*pscan_e == ':')
                    	{
                    		pscan_e = pscan_e + 1;
                    	}
                        uint8 index = strtoul(pscan_e, &pscan_n, 16);
                        uint32 value = strtoul(pscan_e + 3, &pscan_n, 16);

                        if((index >= 0) && (index <=7))
                        {
							//  if digital output
							if (DGpioProgs.GpioProgs[index].Type == Dgou)
							{
								//  if on
								if(value)
								{
									//  on mask
									w1ts |= DGpioProgs.GpioProgs[index].Mask;
								}
								else
								{
									//  off mask
									w1tc |= DGpioProgs.GpioProgs[index].Mask;
								}
							}
							//  if pwm or servo type
							else if ((DGpioProgs.GpioProgs[index].Type == Pwmo) || (DGpioProgs.GpioProgs[index].Type == Serv))
							{
								//	PERIODTICKS
								DGpioProgs.GpioProgs[index].Duty = ((value * 5) >> 4);
								pwmservo_changed = 1;
							}
							else
							{
								Xchg_O_Status = 'E';
		                        //os_printf("[COMM] XCGI : ***KO*** 1\n");
							}
                        }
						else
						{
							Xchg_O_Status = 'E';
	                        //os_printf("[COMM] XCGI : ***KO*** 2\n");
						}
                        pscan_e = pscan_e + 7;
                    }
                    if(Xchg_O_Status == 'Y')
                    {
                        // if at least one output involved actualize output
                        if(w1tc || w1ts)
                        {
                            //  set/reset GPIO output pin
                            pGpio->out_w1tc = (uint32)w1tc;
                            pGpio->out_w1ts = (uint32)w1ts;
                        }
                        //  if at least one pwm/servo involved
                        if(pwmservo_changed)
                        {
                            //  update phases
                            FPwmUpdate();
                        }
                    }
                    //  INPUT
                    //  init input
                    uint32 input;
                    input = pGpio->in;
                    uint32 value;

                    char tmp_elem[8 + 1];
                    char tmp_buf[(8 * 9) + 1];
                    *(tmp_buf) = 0;
                    //	for every GPIO
                    for(i = 0; i < DGpioProgs.Num; i++)
                    {
                    	//	pin type
                    	switch(DGpioProgs.GpioProgs[i].Type)
                    	{
                        //  if input or input pullup
                    	case Dgin:
                    	case Dgip:
                            value = input & DGpioProgs.GpioProgs[i].Mask;
                            os_sprintf(tmp_elem, "%02X=%04X:", i, value?1:0);
                            os_strcat(tmp_buf, tmp_elem);
                            break;
                        //  else
                    	case Coun:
                    	case Coup:
                    	case Enca:
                    	case Encb:
                    	case Enap:
                    	case Enbp:
                    	case Peri:
                    	case Perp:
                            value = DGpioProgs.GpioProgs[i].Duty;
                            os_sprintf(tmp_elem, "%02X=%04X:", i, value & 0xffff);
                            os_strcat(tmp_buf, tmp_elem);
                            break;
                    	}
                    }
                    //	if A0 used
                    if(A0PinType != Unus)
                    {
                    	//	if ADC
                        if(A0PinType == Adci)
                        {
                        	//	send previous read
                        	os_sprintf(tmp_elem, "%02X=%04X:", 8, ADCValue);
                        	os_strcat(tmp_buf, tmp_elem);
                        	//	read next ADC value in background task
                        	if(!system_os_post(USER_TASK_PRIO_1, 0, 0))
                        	{
                        	    os_printf("[DBG] system_os_post read ADC : ***KO***\n");
                        	}
                        }
                        //	if digital input
                        else if(A0PinType == Dgin)
                        {
                        	if(ADCValue < 32768)
                        	{
                        		os_sprintf(tmp_elem, "%02X=%04X:", 8, 0);
                        	}
                        	else
                        	{
                        		os_sprintf(tmp_elem, "%02X=%04X:", 8, 1);
                        	}
                        	os_strcat(tmp_buf, tmp_elem);
                        }
                    }
                    //	prepare answer string
                    char resp[] = THEREMINOPROTOCOL" M XCGI XYX";
                    os_strcpy(ControllerCommTXBuf, resp);
                    if(os_strlen(tmp_buf) != 0)
                    {
                        *(tmp_buf + os_strlen(tmp_buf) - 1) = 0;
                        os_strcat(ControllerCommTXBuf, " ");
                        os_strcat(ControllerCommTXBuf, tmp_buf);
                    }
                    *(ControllerCommTXBuf + 19) = ProgStatus;
                    *(ControllerCommTXBuf + 21) = Xchg_O_Status;
                }
                else
                {
                    //	negative answer
                    char resp[] = THEREMINOPROTOCOL" M XCGI NEE";
                    os_strcpy(ControllerCommTXBuf, resp);
                }
                //	copy remote IP endpoint
                os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
                //	copy remote port
                ControllerComm.proto.udp->remote_port = premot->remote_port;
                //	send UDP message
                if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
				{
				}
                CommFaultCountDown = CommFaultCountDown_conf;
            }
			else
			{
				//  is it PROG command?
				pscan_e = (char *)os_strstr(pscan_b, CommStrProg);
				if(pscan_e != NULL)
				{
					//	if yes
					uint8 i;
					pscan_e = pscan_e + os_strlen(CommStrProg);

					//  "XX=YY:XX=YY:XX=YY:XX=YY:XX=YY:XX=YY:XX=YY:XX=YY"
					ProgStatus = 'Y';
					//	reset all previous setup
					for(i = 0; i < DGpioProgs.Num; i++)
					{
						DGpioProgs.GpioProgs[i].Type = Unus;
					}
					A0PinType = Unus;

					//	scan GPIO program string
					while(os_strlen(pscan_e) != 0)
					{
						uint8 index;
						char type[5];

						if(*pscan_e == ':')
						{
							pscan_e = pscan_e + 1;
						}
						index = strtoul(pscan_e, &pscan_n, 16);
						os_strncpy(type, pscan_e + 3, 4);
						type[4] = 0;
						//	if pin is valid
						if((index >= 0) && (index <=7))
						{
							if(os_strcmp(type, "UNUS") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Unus;
							}
							else if(os_strcmp(type, "DGIN") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Dgin;
							}
							else if(os_strcmp(type, "DGOU") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Dgou;
							}
							else if(os_strcmp(type, "PWMO") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Pwmo;
							}
							else if(os_strcmp(type, "SERV") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Serv;
							}
							else if(os_strcmp(type, "COUN") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Coun;
							}
							else if(os_strcmp(type, "DGIP") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Dgip;
							}
							else if(os_strcmp(type, "COUP") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Coup;
							}
							else if(os_strcmp(type, "ENCA") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Enca;
							}
							else if(os_strcmp(type, "ENCB") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Encb;
							}
							else if(os_strcmp(type, "ENAP") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Enap;
							}
							else if(os_strcmp(type, "ENBP") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Enbp;
							}
							else if(os_strcmp(type, "PERI") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Peri;
							}
							else if(os_strcmp(type, "PERP") == 0)
							{
								DGpioProgs.GpioProgs[index].Type = Perp;
							}
							else
							{
								ProgStatus = 'E';
							}
						}
						//	if A0 pin
						else if(index == 8)
						{
							if(os_strcmp(type, "UNUS") == 0)
							{
								A0PinType = Unus;
							}
							else if((os_strcmp(type, "ADCI") == 0) && (index == 8))
							{
								A0PinType = Adci;
							}
							else if(os_strcmp(type, "DGIN") == 0)
							{
								A0PinType = Dgin;
							}
							else
							{
								ProgStatus = 'E';
							}
						}
						//	pin index not valid
						else
						{
							ProgStatus = 'E';
						}
						pscan_e = pscan_e + 7;
					}
					//	if no error
					if(ProgStatus == 'Y')
					{
						//	set GPIO pins
						FGpioSetup();
					}
					// 	prepare answer
					char resp[] = THEREMINOPROTOCOL" M PROG X";
					os_strcpy(ControllerCommTXBuf, resp);
					*(ControllerCommTXBuf + 19) = ProgStatus;

					os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
					ControllerComm.proto.udp->remote_port = premot->remote_port;
					if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
					{
					}
					CommFaultCountDown = CommFaultCountDown_conf;
				}
				else
				{
					//	is it SCAN command?
					pscan_e = (char *)os_strstr(pscan_b, CommStrScan);
					if(pscan_e != NULL)
					{
					//	if yes
						os_sprintf(ControllerCommTXBuf,
							THEREMINOPROTOCOL" "FWVER" SCAN %s %02X%02X%02X%02X%02X%02X %c "
#ifdef SYMBOLICPIN
							"D1=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"D2=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"D3=UNUS-DGOU-PWMO-SERV:"
							"D4=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP:"
							"D5=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"D6=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"D7=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"D8=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"A0=UNUS-ADCI-DGIN",
#else
							"0=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"1=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"2=UNUS-DGOU-PWMO-SERV:"
							"3=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP:"
							"4=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"5=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"6=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCA-ENAP:"
							"7=UNUS-DGOU-PWMO-SERV-DGIN-DGIP-COUN-COUP-PERI-PERP-ENCB-ENBP:"
							"8=UNUS-ADCI-DGIN",
#endif
							modulename_conf,
							stamac_conf[0],stamac_conf[1],stamac_conf[2],stamac_conf[3],stamac_conf[4],stamac_conf[5],
							ProgStatus);
						os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
						ControllerComm.proto.udp->remote_port = premot->remote_port;
#ifdef DEBUG_RANDOMDELAY
						os_delay_us(os_random() & 50000);
#endif
						if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
						{
						}
						os_printf("[COMM] SCAN end\n");
						CommFaultCountDown = CommFaultCountDown_conf;
					}
					else
					{
						//	is it NAME command?
						pscan_e = (char *)os_strstr(pscan_b, CommStrName);
						if(pscan_e != NULL)
						{
							//	if yes
							pscan_e = pscan_e + os_strlen(CommStrName);
							os_strcpy(modulename_conf, pscan_e);
							//	Write new module name to flash
							if(!system_os_post(USER_TASK_PRIO_0, FlashZone2, 0))
		                    {
		                    }
							char resp[] = THEREMINOPROTOCOL" M NAME Y";
							os_strcpy(ControllerCommTXBuf, resp);
							os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
							ControllerComm.proto.udp->remote_port = premot->remote_port;
							if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
							{
							}
							os_printf("[COMM] NAME end\n");
			                CommFaultCountDown = CommFaultCountDown_conf;
						}
						else
						{
							//	is it CONF command?
							pscan_e = (char *)os_strstr(pscan_b, CommStrConf);
							if(pscan_e != NULL)
							{
								//	if yes
								pscan_e = pscan_e + os_strlen(CommStrConf);
								char *pCfgMem = (char*)os_zalloc(lenght - (pscan_e - pusrdata) + 1);
								if(pCfgMem != NULL)
								{
									os_memcpy(pCfgMem, pscan_e, lenght - (pscan_e - pusrdata));
									if(!system_os_post(USER_TASK_PRIO_0, FlashZone1, (uint32_t)pCfgMem))
									{
									}
									char resp[] = THEREMINOPROTOCOL" M CONF Y";
									os_strcpy(ControllerCommTXBuf, resp);
									os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
									ControllerComm.proto.udp->remote_port = premot->remote_port;
									if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
									{
									}
								}
								else
								{
									char resp[] = THEREMINOPROTOCOL" M CONF N";
									os_strcpy(ControllerCommTXBuf, resp);
									os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
									ControllerComm.proto.udp->remote_port = premot->remote_port;
									if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
									{
									}
									os_printf("[DBG] FWL1Write : out of memory\n");
								}
								os_printf("[COMM] CONF end\n");
				                CommFaultCountDown = CommFaultCountDown_conf;
							}
#ifdef FUOTA_SUPPORT
							else
							{
								//	is it FUOTA command?
								pscan_e = (char *)os_strstr(pscan_b, CommStrFUOTA);
								if(pscan_e != NULL)
								{
									//	if yes
									pscan_e = pscan_e + os_strlen(CommStrFUOTA);
									//	if FUOTA started
									if(FFUOTA(pscan_e) == true)
									{
										char resp[] = THEREMINOPROTOCOL" M FUOTA Y";
										os_strcpy(ControllerCommTXBuf, resp);
										os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
										ControllerComm.proto.udp->remote_port = premot->remote_port;
										if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
										{
										}
									}
									else
									{
										char resp[] = THEREMINOPROTOCOL" M FUOTA N";
										os_strcpy(ControllerCommTXBuf, resp);
										os_memcpy(ControllerComm.proto.udp->remote_ip, premot->remote_ip, 4);
										ControllerComm.proto.udp->remote_port = premot->remote_port;
										if(espconn_send(&ControllerComm, ControllerCommTXBuf, os_strlen(ControllerCommTXBuf)) != ESPCONN_OK)
										{
										}
									}
									CommFaultCountDown = CommFaultCountDown_conf;
								}
							}
#endif
						}
					}
                }
            }
        }
    }
    else
    {
    }
}

/******************************************************************************
 * FunctionName : FCommOn
 * Description  : Open communication channel
*******************************************************************************/

ICACHE_FLASH_ATTR
void FHALCommOn(void)
{
    if(!CommActive)
    {
    	ControllerComm.type = ESPCONN_UDP;
		ControllerComm.proto.udp = &ControllerCommUDP;
		ControllerComm.proto.udp->local_port = NetControllerUDPPort_conf;
		espconn_regist_recvcb(&ControllerComm, FUDPCommCB);
		if(espconn_create(&ControllerComm) != ESPCONN_OK)
		{
		}
		else
		{
			CommActive = true;
		}
   	}
}

/******************************************************************************
 * FunctionName : FCommOff
 * Description  : Close communication channel
*******************************************************************************/

ICACHE_FLASH_ATTR
void FHALCommOff(void)
{
    if(CommActive)
    {
        if(espconn_delete(&ControllerComm) != ESPCONN_OK)
        {
        }
        else
        {
            CommActive = false;
        }
    }
}

/******************************************************************************
 * FunctionName : FEspconnGethostbynameCB
 * Description  : Callback function : DNS IP has been resolved
*******************************************************************************/

ICACHE_FLASH_ATTR
void FEspconnGethostbynameCB(const char *name, ip_addr_t *ipaddr, void *arg)
{
    struct espconn *pespconn = (struct espconn *)arg;
    if (ipaddr != NULL)
    {
    	os_printf("[DBG] FEspconnGethostbynameCB - name : %s - addr : "IPSTR"\n", name,
			*((uint8 *)&ipaddr->addr), *((uint8 *)&ipaddr->addr + 1),
			*((uint8 *)&ipaddr->addr + 2), *((uint8 *)&ipaddr->addr + 3));
    }
}

/******************************************************************************
 * FunctionName : FScanConfig
 * Description  : Scan the config data looking for parameters and values
*******************************************************************************/

ICACHE_FLASH_ATTR
bool FScanConfig(const char *pCfgMem, const char *pKeyStr, char *pValStr)
{
	char *pscan_b, *pscan_e, *pscan_BOF, *pscan_EOF;
	bool RetVal = false;

	pscan_BOF = (char *)os_strstr(pCfgMem, str_BOF);
	pscan_EOF = (char *)os_strstr(pCfgMem, str_EOF);
	pscan_b = os_strstr(pCfgMem, pKeyStr);
	if((pscan_BOF != NULL) && (pscan_EOF != NULL) && (pscan_b != NULL) && (pscan_b > pscan_BOF) && (pscan_b < pscan_EOF))
	{
		pscan_e = os_strstr(pscan_b + os_strlen(str_crlf), str_crlf);
		pscan_b += os_strlen(pKeyStr);
		while(true)
		{
			pscan_b++;
			if((*pscan_b != char_blank) && (*pscan_b != char_tab))
			{
				break;
			}
		};
		os_memcpy(pValStr, pscan_b, pscan_e - pscan_b);
		pValStr[pscan_e - pscan_b] = 0;
		//	os_printf("[CFG] Key %s found - value : %s - lenght : %d\n", pKeyStr + os_strlen(str_crlf), pValStr, pscan_e - pscan_b);
		RetVal = true;
	}
	else
	{
	}
	return RetVal;
}

/******************************************************************************
 * FunctionName : FWifiEventHandlerCB
 * Description  : Callback function : WiFi event has been triggered
*******************************************************************************/

ICACHE_FLASH_ATTR
void FWiFiEventHandlerCB(System_Event_t *evt)
{
	switch (evt->event)
	{
    case EVENT_STAMODE_CONNECTED:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_STAMODE_CONNECTED\n");
	    os_printf("[DBG] FWifiEventHandlerCB :  bssid " MACSTR "\n", MAC2STR(evt->event_info.connected.bssid));
	    os_printf("[DBG] FWifiEventHandlerCB :  channel %d\n", evt->event_info.connected.channel);
	    os_printf("[DBG] FWifiEventHandlerCB :  ssid %s\n", evt->event_info.connected.ssid);
	    //	evt->event_info.connected.ssid_len
	    os_printf("[DBG] wifi_station_get_rssi : %d\n", wifi_station_get_rssi());
	    os_printf("[DBG] wifi_get_phy_mode : %d\n", wifi_get_phy_mode());
		break;
    case EVENT_STAMODE_DISCONNECTED:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_STAMODE_DISCONNECTED\n");
	    os_printf("[DBG] FWifiEventHandlerCB :  bssid " MACSTR "\n", MAC2STR(evt->event_info.disconnected.bssid));
	    os_printf("[DBG] FWifiEventHandlerCB :  reason %d\n", evt->event_info.disconnected.reason);
	    os_printf("[DBG] FWifiEventHandlerCB :  ssid %s\n", evt->event_info.connected.ssid);
	    //	evt->event_info.connected.ssid_len
		FHALCommOff();
		break;
    case EVENT_STAMODE_GOT_IP:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_STAMODE_GOT_IP\n");
		os_sprintf(local_ip, IPSTR, IP2STR(&evt->event_info.got_ip.ip));
		os_printf("[DBG] FWifiEventHandlerCB :  IP %s\n", local_ip);
		os_sprintf(local_ip, IPSTR, IP2STR(&evt->event_info.got_ip.mask));
		os_printf("[DBG] FWifiEventHandlerCB :  MASK %s\n", local_ip);
		os_sprintf(local_ip, IPSTR, IP2STR(&evt->event_info.got_ip.gw));
		os_printf("[DBG] FWifiEventHandlerCB :  GW %s\n", local_ip);
		ip_addr_t DNSServer0 = espconn_dns_getserver(0);
		os_printf("[DBG] espconn_dns_getserver (0) : "IPSTR"\n", IP2STR(&DNSServer0.addr));
		ip_addr_t DNSServer1 = espconn_dns_getserver(1);
		os_printf("[DBG] espconn_dns_getserver (1) : "IPSTR"\n", IP2STR(&DNSServer1.addr));
		FHALCommOff();
		FHALCommOn();
		break;
    case EVENT_SOFTAPMODE_STACONNECTED:
        os_printf("[DBG] FWifiEventHandlerCB : EVENT_SOFTAPMODE_STACONNECTED: " MACSTR " join, AID %d\n", MAC2STR(evt->event_info.sta_connected.mac), evt->event_info.sta_connected.aid);
		FHALCommOff();
		FHALCommOn();
		break;
    case EVENT_SOFTAPMODE_STADISCONNECTED:
        os_printf("[DBG] FWifiEventHandlerCB : EVENT_SOFTAPMODE_STADISCONNECTED: " MACSTR " leave, AID %d\n", MAC2STR(evt->event_info.sta_disconnected.mac), evt->event_info.sta_disconnected.aid);
		FHALCommOff();
		break;
    case EVENT_SOFTAPMODE_PROBEREQRECVED:
        os_printf("[DBG] FWifiEventHandlerCB : EVENT_SOFTAPMODE_PROBEREQRECVED: " MACSTR " probe, RSSI %d\n", MAC2STR(evt->event_info.ap_probereqrecved.mac), evt->event_info.ap_probereqrecved.rssi);
		break;
    case EVENT_STAMODE_DHCP_TIMEOUT:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_STAMODE_DHCP_TIMEOUT\n");
		break;
    case EVENT_STAMODE_AUTHMODE_CHANGE:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_STAMODE_AUTHMODE_CHANGE : old %d - new %d\n", evt->event_info.auth_change.old_mode, evt->event_info.auth_change.new_mode);
		break;
    case EVENT_OPMODE_CHANGED:
		os_printf("[DBG] FWifiEventHandlerCB : EVENT_OPMODE_CHANGED : old %d - new %d\n", evt->event_info.auth_change.old_mode, evt->event_info.auth_change.new_mode);
    	break;
    case EVENT_MAX:
    	os_printf("[DBG] FWifiEventHandlerCB : EVENT_MAX\n");
		break;     
	}
}

/******************************************************************************
 * FunctionName : FTicker
 * Description  : Callback function : 2 mS or 10 mS are elapsed
*******************************************************************************/

ICACHE_FLASH_ATTR
void FTicker(void *arg)
{
#ifdef USE_US_TIMER
	os_timer_arm_us(pTickTimer, 2000, 0);
#else
	os_timer_arm(pTickTimer, 10, 0);
#endif
#ifdef USE_US_TIMER
	//---------------------------------------------------
	//	periodic activity every 2 mS
	//---------------------------------------------------
	//	nothing
	//---------------------------------------------------
#endif
#ifdef USE_US_TIMER
	if((Tick2msCounter % 5) == 0)
#endif
	//---------------------------------------------------
	//	periodic activity every 10 mS
	//---------------------------------------------------
	{
		//	if communication fault enabled on D0
		if(CommFaultUseD0_conf == 1)
		{
			//	if not in communication failure status
			if(CommFaultStatus == false)
			{
				//	delay
				CommFaultCountDown -= 10;
				//	if count down reach 0
				if(CommFaultCountDown == 0)
				{
					//	D0 off (remove aux power)
					FGpio16OutputSet(0);
					//	fault true
					CommFaultStatus = true;
					//	disable GPIO interrupts
					//	ETS_GPIO_INTR_DISABLE();
					os_printf("[DBG] Controller communication failure : D0 pin Low\n");
				}
			}
			else
			{
				//	if communication restarted
				if(CommFaultCountDown != 0)
				{
					//	D0 on (grant aux power)
					FGpio16OutputSet(1);
					//	fault false
					CommFaultStatus = false;
					//	enable GPIO interrupts
					//	ETS_GPIO_INTR_ENABLE();
					os_printf("[DBG] Controller communication restarted : D0 pin High\n");
				}
			}
		}
	}
	//---------------------------------------------------
#ifdef USE_US_TIMER
	Tick2msCounter++;
	if(Tick2msCounter == 500)
#else
	Tick10msCounter++;
	if(Tick10msCounter == 100)
#endif
	{
#ifdef USE_US_TIMER
		Tick2msCounter = 0;
#else
		Tick10msCounter = 0;
#endif
		//---------------------------------------------------
		//	periodic activity every 1 second
		//---------------------------------------------------
		//	nothing
		//---------------------------------------------------
		Tick1SecCounter++;
		if(Tick1SecCounter == 60)
		{
			Tick1SecCounter = 0;
			//---------------------------------------------------
			//	periodic activity every 1 minute
			//---------------------------------------------------
			//	nothing
    		//---------------------------------------------------
			Tick1MinCounter++;
			if(Tick1MinCounter == 60)
			{
				Tick1MinCounter = 0;
				//---------------------------------------------------
				//	periodic activity every 1 hour
				//---------------------------------------------------
				//	nothing
				//---------------------------------------------------
				Tick1HourCounter++;
				if(Tick1HourCounter == 24)
				{
					Tick1HourCounter = 0;
					Tick1DayCounter++;
					//---------------------------------------------------
					//	periodic activity every 1 day
					//---------------------------------------------------
					//	nothing
					//---------------------------------------------------
				}
			}
		}
	}
}

/******************************************************************************
 * FunctionName : FWifiStationScanCB
 * Description  : Callback function : stations scan is finished
*******************************************************************************/

ICACHE_FLASH_ATTR
void FWiFiStationScanCB (void *arg, STATUS status)
{
    os_printf("[DBG] FWifiStationScanCB\n");
}

/******************************************************************************
 * FunctionName : FSystemInitDoneCB
 * Description  : Callback function : initialization is finished
*******************************************************************************/

ICACHE_FLASH_ATTR
void FSystemInitDoneCB(void)
{
	os_printf("[DBG] SystemInitDoneCB\n");
}

/******************************************************************************
 * FunctionName : FTaskPrio0
 * Description  : Callback function : task with lower priority
*******************************************************************************/

ICACHE_FLASH_ATTR
void FTaskPrio0CB(os_event_t *e)
{
	uint16 val;

	os_printf("[DBG] FTaskPrio0CB sig %d\n", e->sig);
	switch(e->sig)
	{
	//	write the configuration in flash (zone 1)
	case FlashZone1:
		os_printf("[DBG] FWL1Write : %s\n", (char *)e->par);
		FWL1Write((char *)e->par);
		os_free((void *)e->par);
		break;
	//	write the configuration in flash (zone 2)
	case  FlashZone2:
		{
			char *pCfgMem;
			pCfgMem = (char*)os_zalloc(RAMFLASH);
			if(pCfgMem != 0)
			{
				char tmp_buf[(MAXSTRLEN + 1) * 2];
				os_strcpy(pCfgMem, str_BOF);
				//	module name
				os_sprintf(tmp_buf, "%s %s", ModuleNameCfgStr, modulename_conf);
				os_strcat(pCfgMem, tmp_buf);
				//	end list
				os_strcat(pCfgMem, str_EOF);
				os_printf("[DBG] FWL2Write : %s\n", pCfgMem);
				FWL2Write(pCfgMem);
				os_free(pCfgMem);
			}
			else
			{
				os_printf("[DBG] FWL2Write : out of memory\n");
			}
		}
		break;
	//	reboot from USB
	case Reboot:
		system_restart();
		break;
	//	positive end of FUOTA procedure
	case FuotaOK:
		{
			system_upgrade_reboot();
		}
		break;
	//	negative end of FUOTA procedure
	case FuotaKO:
		{
			FTimer1Start();
		}
		break;
	//	emergency programming in flash
	case TEmergencyConf:
		{
			//	allocate RAM memory
			char *pCfgRam = (char*)os_zalloc(128);
			if(pCfgRam != 0)
			{
				//	copy data from flash to RAM
				FStrCpyFlashToRam((char *)CfgEmergencyConf, pCfgRam);
				//	write temporary config
				FWL1Write(pCfgRam);
				//	deallocate RAM memory
				os_free(pCfgRam);
			}
		}
		break;
	case ReadFlashUint16:
		{
			os_printf("[DBG] FReadFlashUint8 0 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 0));
			os_printf("[DBG] FReadFlashUint8 1 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 1));
			os_printf("[DBG] FReadFlashUint8 2 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 2));
			os_printf("[DBG] FReadFlashUint8 3 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 3));
			os_printf("[DBG] FReadFlashUint8 4 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 4));
			os_printf("[DBG] FReadFlashUint8 5 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 5));
			os_printf("[DBG] FReadFlashUint8 6 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 6));
			os_printf("[DBG] FReadFlashUint8 7 : %02X\n", FReadFlashUint8(CfgEmergencyConf + 7));

			os_printf("[DBG] FReadFlashUint16 0 : %04X\n", FReadFlashUint16(CfgEmergencyConf + 0));
			os_printf("[DBG] FReadFlashUint16 1 : %04X\n", FReadFlashUint16(CfgEmergencyConf + 1));
			os_printf("[DBG] FReadFlashUint16 2 : %04X\n", FReadFlashUint16(CfgEmergencyConf + 2));
			os_printf("[DBG] FReadFlashUint16 3 : %04X\n", FReadFlashUint16(CfgEmergencyConf + 3));
		}
		break;
	}
}

/******************************************************************************
 * FunctionName : FTaskPrio1
 * Description  : Callback function : task with medium priority
*******************************************************************************/
//	O.S. function call faster and with 16 bit resolution but not usable with wifi active:
//	system_adc_read_fast(uint16 *adc_addr, uint16 adc_num, uint8 adc_clk_div);

ICACHE_FLASH_ATTR
void FTaskPrio1CB(os_event_t *e)
{
	//	if ADC pin
	if(A0PinType == Adci)
	{
		uint8 i;
		uint32 Acc = 0;
		uint16 Val;
		//	if timing on D0 enabled
		if(ADCOverUseD0_conf == 1)
		{
			//	set D0
			FGpio16OutputSet(1);
		}
		//	for configured conversion number
		for(i = 0; i < ADCOverNumber_conf; i++)
		{
			//	oversample the sample
			Val = system_adc_read();
			Val = (Val >= 1024) ? 1023 : Val;
			Acc += Val;
			//	if not the last sample
			if(i != (ADCOverNumber_conf - 1))
			{
				//	do configured delay
				os_delay_us(ADCOverDelay_conf);
			}
		}
		//	if timing on D0 enabled
		if(ADCOverUseD0_conf == 1)
		{
			//	reset D0
			FGpio16OutputSet(0);
		}
		//	shift from 6 to 0 valid ADCOverNumber_conf values : 1,2,4,8,16,32,64
		ADCValue = Acc << (6 - ADCOverShift_conf);
	}
	//	if digital input pin
	else if(A0PinType == Dgin)
	{
		//	read and convert A0 pin voltage once
		ADCValue = system_adc_read() << 6;
	}
}

/******************************************************************************
 * FunctionName : FTaskPrio2
 * Description  : Callback function : task with higher priority
*******************************************************************************/

ICACHE_FLASH_ATTR
void FTaskPrio2CB(os_event_t *e)
{
    os_printf("[DBG] FTaskPrio2CB sig %c\n", (char)e->sig);
}

/******************************************************************************
 * FunctionName : FRcvCharFromUSBCB
 * Description  : Callback function : a character has been typed on the USB putty
*******************************************************************************/

ICACHE_FLASH_ATTR
void FRcvCharFromUSBCB(uint8 RcvChar)
{
	os_printf("[DBG] RcvCharFromUSBCB : %c\n", RcvChar);
	//	do a system restart
	if((RcvChar == 'r') || (RcvChar == 'R'))
	{
        if(!system_os_post(USER_TASK_PRIO_0, Reboot, 0))
        {
        }
	}
	//	do a test
	else if((RcvChar == 'e') || (RcvChar == 'E'))
	{
		FSpiFlashEraseSector(FWL1INDEXSECTOR);
		FSpiFlashEraseSector(FWL2INDEXSECTOR);
	}
	else if((RcvChar == 'f') || (RcvChar == 'F'))
	{
        if(!system_os_post(USER_TASK_PRIO_0, TEmergencyConf, 0))
        {
        }
	}
	else if((RcvChar == '6'))
	{
        if(!system_os_post(USER_TASK_PRIO_0, ReadFlashUint16, 0))
        {
        }
	}
}

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : System function for RF calibration
*******************************************************************************/

ICACHE_FLASH_ATTR
uint32 user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map)
    {
	//	512 KB
	case FLASH_SIZE_4M_MAP_256_256:
		rf_cal_sec = 128 - 8;
		break;
	//	1 MB
	case FLASH_SIZE_8M_MAP_512_512:
		rf_cal_sec = 256 - 5;
		break;
	//	2 MB
	case FLASH_SIZE_16M_MAP_512_512:
	case FLASH_SIZE_16M_MAP_1024_1024:
		rf_cal_sec = 512 - 5;
		break;
	//	4 MB
	case FLASH_SIZE_32M_MAP_512_512:
	case FLASH_SIZE_32M_MAP_1024_1024:
		rf_cal_sec = 1024 - 5;
		break;
	//	8 MB
	case FLASH_SIZE_64M_MAP_1024_1024:
		rf_cal_sec = 2048 - 5;
		break;
	//	16 MB
	case FLASH_SIZE_128M_MAP_1024_1024:
		rf_cal_sec = 4096 - 5;
		break;

	default:
		rf_cal_sec = 0;
		break;
    }
    return rf_cal_sec;
}

/******************************************************************************
 * FunctionName : user_spi_flash_dio_to_qio_pre_ini
 * Description  : System function to reduce IRAM usage by SDK
*******************************************************************************/

ICACHE_FLASH_ATTR
void user_spi_flash_dio_to_qio_pre_ini(void)
{
}

/******************************************************************************
 * FunctionName : user_rf_pre_init
 * Description  : System function for RF pre-initialization
*******************************************************************************/

ICACHE_FLASH_ATTR
void user_rf_pre_init(void)
{
}

/******************************************************************************
 * FunctionName : user_init
 * Description  : System function is the entry point of user application
*******************************************************************************/

ICACHE_FLASH_ATTR
void user_init(void)
{
	//	If you need to customize init data then first download the Espressif SDK and extract esp_init_data_default.bin.
	//	Then flash that file just like you'd flash the firmware.
	//	The correct address for the init data depends on the capacity of the flash chip.
	//	0x7c000 for 512 kB, modules like most ESP-01, -03, -07 etc.
	//  0xfc000 for 1 MB, modules like ESP8285, PSF-A85, some ESP-01, -03 etc.
	//	0x1fc000 for 2 MB
	//  0x3fc000 for 4 MB, modules like ESP-12E, NodeMCU devkit 1.0, WeMos D1 mini
	//  0x7fc000 for 8 MB
	//  0xffc000 for 16 MB, modules like WeMos D1 mini pro

	//	reinit software timer to use microseconds, USE_US_TIMER must be defined in user_config.h
#ifdef USE_US_TIMER
	system_timer_reinit();
#endif

	//	26MHz quarz = default to 74880 bps uart speed
	//	install uart0_rx_intr_handler (uart.c) to handle DBG commands from putty (leave native baud rate)
	uart_init(BIT_RATE_74880, BIT_RATE_74880);

	//	voids os_printf calls on serial TX
	//	system_set_os_print(0);

	//	GPIO init
    gpio_init();

    //	attach GPIO interrupt handler
    ETS_GPIO_INTR_ATTACH(FGpioInterruptHandler, NULL);

    //	D1 pin as GPIO enabled
    PIN_FUNC_SELECT((PERIPHS_IO_MUX_GPIO5_U), (FUNC_GPIO5));
    FGpioPullupDisable(0);
    //	D2 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO4_U, FUNC_GPIO4);
    FGpioPullupDisable(1);
    //	D3 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO0_U, FUNC_GPIO0);
    FGpioPullupDisable(2);
    //	D4 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO2_U, FUNC_GPIO2);
    FGpioPullupDisable(3);
    //	D5 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTMS_U, FUNC_GPIO14);
    FGpioPullupDisable(4);
    //	D6 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDI_U, FUNC_GPIO12);
    FGpioPullupDisable(5);
    //	D7 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTCK_U, FUNC_GPIO13);
    FGpioPullupDisable(6);
    //	D8 pin as GPIO enabled
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDO_U, FUNC_GPIO15);
    FGpioPullupDisable(7);

    //	check which flash area is in use
    FUOTAFlashUserID = system_upgrade_userbin_check();

    switch (FUOTAFlashUserID)
    {
	case UPGRADE_FW_BIN1:
		os_printf("[DBG] system_upgrade_userbin_check : UPGRADE_FW_BIN1\n");
		break;
	case UPGRADE_FW_BIN2:
		os_printf("[DBG] system_upgrade_userbin_check : UPGRADE_FW_BIN2\n");
		break;
    }

    //	misc debug info
    struct rst_info* pRestartInfo;
    pRestartInfo = system_get_rst_info();
    os_printf("[DBG] system_get_rst_info : %d\n", pRestartInfo->reason);
    os_printf("[DBG] firmware version : "FWVER"\n");
    os_printf("[DBG] system_get_chip_id : %08X\n", system_get_chip_id());
    os_printf("[DBG] system_get_boot_version : %d\n", system_get_boot_version());
    os_printf("[DBG] system_get_boot_mode : %d\n", system_get_boot_mode());
    os_printf("[DBG] system_get_cpu_freq(%d)\n", system_get_cpu_freq());
    if(wifi_get_macaddr(STATION_IF, stamac_conf) == true)
    {
	    os_printf("[DBG] wifi_get_macaddr STATION_IF : %02X%02X%02X%02X%02X%02X\n", stamac_conf[0], stamac_conf[1], stamac_conf[2], stamac_conf[3], stamac_conf[4], stamac_conf[5]);
    }
	if(wifi_get_macaddr(SOFTAP_IF, sapmac_conf) == true)
	{
		os_printf("[DBG] wifi_get_macaddr SOFTAP_IF : %02X%02X%02X%02X%02X%02X\n", sapmac_conf[0], sapmac_conf[1], sapmac_conf[2], sapmac_conf[3], sapmac_conf[4], sapmac_conf[5]);
	}
	system_print_meminfo();

	//	Set default configuration parameters
	os_strcpy(modulename_conf, ModuleNameDefStr);

	NetControllerUDPPort_conf = atoi(NetControllerUDPPortDefStr);

	WiFiNetworkMode_conf = softap;

	os_sprintf(sap_conf.ssid, "PTP_%02X%02X%02X%02X%02X%02X", sapmac_conf[0], sapmac_conf[1], sapmac_conf[2], sapmac_conf[3], sapmac_conf[4], sapmac_conf[5]);
	sap_conf.ssid_len = os_strlen(sap_conf.ssid);
	os_strcpy(sap_conf.password, WiFiNetworkPasswordDefStr);
	inet_pton4(SoftAPLeaseStartDefStr, &DhcpLease_conf.start_ip);
	inet_pton4(SoftAPLeaseEndDefStr, &DhcpLease_conf.end_ip);
	sap_conf.channel = atoi(SoftAPChannelDefStr);
	sap_conf.authmode = AUTH_WPA_WPA2_PSK;
	sap_conf.max_connection = 1;
	sap_conf.beacon_interval = 100;

	os_strcpy(sta_conf.ssid, WiFiStaNetworkNameDefStr);
	os_strcpy(sta_conf.password, WiFiNetworkPasswordDefStr);

	inet_pton4(StaticNetworkIPDefStr, &StaticIP_conf.ip);
	inet_pton4(StaticNetworkMaskDefStr, &StaticIP_conf.netmask);
	inet_pton4(StaticGatewayDefStr, &StaticIP_conf.gw);

	ADCOverNumber_conf = atoi(ADCOverNumberDefStr);
	ADCOverUseD0_conf = atoi(ADCOverUseD0DefStr);
	ADCOverDelay_conf = atoi(ADCOverDelayDefStr);
	ADCOverShift_conf = 0;

	CommFaultUseD0_conf = atoi(CommFaultUseD0DefStr);
	CommFaultCountDown_conf = atoi(CommFaultDelayDefStr);

	CPUFreq_conf = atoi(CPUFreqDefStr);

    //	D0 pin (D16 GPIO) enabled
    FGpio16Enable();
    FGpio16InputConf();

	//	allocate RAM memory to read from flash
	char *pCfgMem = (char*)os_zalloc(RAMFLASH);
	char TmpString[MAXSTRLEN+1];

	//	if D0 is low we read configuration from flash
	if(FGpio16InputGet() == false)
	{
		uint32 TmpInt;

		//	read flash parameters in RAM (zone 1)
		FWL1Read(pCfgMem);

		//	substitute default parameters with user parameters if any
		if(FScanConfig(pCfgMem, WiFiNetworkModeConfStr, TmpString) == true)
		{
			if(os_strcmp(TmpString, WiFiNetworkModeDefStr) == 0)
			{
				WiFiNetworkMode_conf = softap;
			}
			else if(os_strcmp(TmpString, WiFiNetworkModeStationStaticStr) == 0)
			{
				WiFiNetworkMode_conf = station_static;
			}
			else if(os_strcmp(TmpString, WiFiNetworkModeStationDHCP) == 0)
			{
				WiFiNetworkMode_conf = station_dhcp;
			}
			//	todo case
		    os_printf("[CFG] WiFiNetworkMode : %s\n", TmpString);
		}
		if(FScanConfig(pCfgMem, WiFiNetworkNameConfStr, TmpString) == true)
		{
			os_strcpy(sta_conf.ssid, TmpString);
			os_strcpy(sap_conf.ssid, TmpString);
			sap_conf.ssid_len = os_strlen(sap_conf.ssid);
		    os_printf("[CFG] WiFiNetworkName : %s\n", TmpString);
		}
		if(FScanConfig(pCfgMem, WiFiNetworkPasswordConfStr, TmpString) == true)
		{
			os_strcpy(sta_conf.password, TmpString);
			os_strcpy(sap_conf.password, TmpString);
		    os_printf("[CFG] WiFiNetworkPassword : %s\n", TmpString);
		}
		if(FScanConfig(pCfgMem, NetControllerUDPPortConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt >= 1) && (TmpInt <= 65535))
			{
				NetControllerUDPPort_conf = TmpInt;
			    os_printf("[CFG] NetControllerUDPPort : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, StaticNetworkIPConfStr, TmpString) == true)
		{
			if(inet_pton4(TmpString, &StaticIP_conf.ip) == 1)
			{
			    os_printf("[CFG] StaticNetworkIP : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, StaticNetworkMaskConfStr, TmpString) == true)
		{
			if(inet_pton4(TmpString, &StaticIP_conf.netmask) == 1)
			{
			    os_printf("[CFG] StaticNetworkMask : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, StaticGatewayConfStr, TmpString) == true)
		{
			if(inet_pton4(TmpString, &StaticIP_conf.gw) == 1)
			{
			    os_printf("[CFG] StaticGateway : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, SoftAPChannelConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt >= 1) && (TmpInt <= 13))
			{
				sap_conf.channel = TmpInt;
			    os_printf("[CFG] SoftAPChannel : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, SoftAPLeaseStartConfStr, TmpString) == true)
		{
			if(inet_pton4(TmpString, &DhcpLease_conf.start_ip) == 1)
			{
			    os_printf("[CFG] SoftAPLeaseStart : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, SoftAPLeaseEndConfStr, TmpString) == true)
		{
			if(inet_pton4(TmpString, &DhcpLease_conf.end_ip) == 1)
			{
			    os_printf("[CFG] SoftAPLeaseEnd : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, ADCOverNumberConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt == 1) || (TmpInt == 2) || (TmpInt == 4) || (TmpInt == 8) || (TmpInt == 16) || (TmpInt == 32) || (TmpInt == 64))
			{
				ADCOverNumber_conf = TmpInt;
			    os_printf("[CFG] ADCOverNumber : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, ADCOverDelayConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt >= 100) && (TmpInt <= 10000))
			{
				ADCOverDelay_conf = TmpInt;
			    os_printf("[CFG] ADCOverDelay : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, ADCOverUseD0ConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt == 0) || (TmpInt == 1))
			{
				ADCOverUseD0_conf = TmpInt;
			    os_printf("[CFG] ADCOverUseD0 : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, CPUFreqConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt == 80) || (TmpInt == 160))
			{
				CPUFreq_conf = TmpInt;
			    os_printf("[CFG] CPUFreq : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, CommFaultUseD0ConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt == 0) || (TmpInt == 1))
			{
				CommFaultUseD0_conf = TmpInt;
			    os_printf("[CFG] CommFaultUseD0 : %s\n", TmpString);
			}
		}
		if(FScanConfig(pCfgMem, CommFaultDelayConfStr, TmpString) == true)
		{
			TmpInt = atoi(TmpString);
			if((TmpInt >= 100) && (TmpInt <= 10000))
			{
				CommFaultCountDown_conf = TmpInt - (TmpInt % 10);
			    os_printf("[CFG] CommFaultDelay : %s\n", TmpString);
			}
		}
	}

	//	read flash parameters in RAM (zone 2)
	FWL2Read(pCfgMem);

	//	substitute default parameters with user parameters if any
	if(FScanConfig(pCfgMem, ModuleNameCfgStr, TmpString) == true)
	{
		os_strcpy(modulename_conf, TmpString);
	    os_printf("[CFG] ModuleName : %s\n", TmpString);
	}
	//	release RAM memory
	os_free(pCfgMem);

	//	some post processing

	uint16 Tmp = ADCOverNumber_conf;
	ADCOverShift_conf = 0;
	while(1)
	{
		Tmp >>= 1;
		if(Tmp == 0)
		{
			break;
		}
		ADCOverShift_conf++;
	}
	if(system_get_cpu_freq() != CPUFreq_conf)
    {
		system_update_cpu_freq(CPUFreq_conf);
    }
	os_printf("[DBG] system_get_cpu_freq : %d\n", system_get_cpu_freq());

	//	set WiFi communication handler
	wifi_set_event_handler_cb(FWiFiEventHandlerCB);

	////////////////////////////////////////////////
	//	call system functions to setup configuration
	////////////////////////////////////////////////

	switch(WiFiNetworkMode_conf)
    {
	//	wifi station-dhcp, dhcpc is started by default
	case station_dhcp:
		if (wifi_set_opmode_current(STATION_MODE))		//  no flash
		{
			os_printf("[CFG] wifi_set_opmode_current STATION_MODE : OK\n");
		}
		if(wifi_station_set_config_current(&sta_conf))	//  no flash
		{
		}
		if(wifi_station_set_auto_connect(1))			//	auto connect
		{
		}
		if(wifi_station_set_reconnect_policy(1))       	//	automatic reconnect
		{
		}
	    //	set host name
	    os_printf("[DBG] start module hostname : %s\n", wifi_station_get_hostname());
	    wifi_station_set_hostname(modulename_conf);
	    os_printf("[DBG] actual module hostname : %s\n", wifi_station_get_hostname());
		break;
    //	wifi station-static
	case station_static:
		if (wifi_set_opmode_current(STATION_MODE))		//  no flash
		{
			os_printf("[CFG] wifi_set_opmode_current STATION_MODE : OK\n");
		}
		if(wifi_station_set_config_current(&sta_conf))	//  no flash
		{
		}
		if(wifi_station_set_auto_connect(1))           	//	auto connect
		{
		}
		if(wifi_station_set_reconnect_policy(1))       	//	automatic reconnect
		{
		}
		wifi_station_dhcpc_stop();
		if(wifi_set_ip_info(STATION_IF, &StaticIP_conf))		//	static IP
		{
		}
		espconn_dns_setserver(0, &DNS0_conf);
		espconn_dns_setserver(1, &DNS1_conf);
	    //	set host name
	    os_printf("[DBG] start module hostname : %s\n", wifi_station_get_hostname());
	    wifi_station_set_hostname(modulename_conf);
	    os_printf("[DBG] actual module hostname : %s\n", wifi_station_get_hostname());
		break;
	//	wifi softap
    case softap:
		if (wifi_set_opmode_current(SOFTAP_MODE))		//  no flash
		{
			os_printf("[CFG] wifi_set_opmode_current SOFTAP_MODE : OK\n");
		}
		if(wifi_softap_set_config_current(&sap_conf))	//  no flash
		{
		}
		wifi_softap_dhcps_stop();
		wifi_station_dhcpc_stop();
		if(wifi_set_ip_info(SOFTAP_IF, &StaticIP_conf))	//	static IP
		{
		}
		wifi_softap_set_dhcps_lease(&DhcpLease_conf);
		wifi_softap_dhcps_start();

		espconn_dns_setserver(0, &DNS0_conf);
		espconn_dns_setserver(1, &DNS1_conf);
		break;
    }

    //	do not power sleep
    if(wifi_set_sleep_type(NONE_SLEEP_T))
    {
    }
    //	wifi_fpm_set_sleep_type(NONE_SLEEP_T)
    // 	wifi_fpm_set_sleep_type(MODEM_SLEEP_T);

    //	task init
    TaskPrio0Queue=(os_event_t*)os_malloc(sizeof(os_event_t)*TASK0_QUEUE_LEN);
    TaskPrio1Queue=(os_event_t*)os_malloc(sizeof(os_event_t)*TASK1_QUEUE_LEN);
    TaskPrio2Queue=(os_event_t*)os_malloc(sizeof(os_event_t)*TASK2_QUEUE_LEN);
    system_os_task(FTaskPrio0CB, USER_TASK_PRIO_0, TaskPrio2Queue, TASK0_QUEUE_LEN);
    system_os_task(FTaskPrio1CB, USER_TASK_PRIO_1, TaskPrio2Queue, TASK1_QUEUE_LEN);
    system_os_task(FTaskPrio2CB, USER_TASK_PRIO_2, TaskPrio2Queue, TASK2_QUEUE_LEN);

    //	timer1 (FRC1) init
    //  we use it for the Theremino pwm/servo timings algorithm

    FTimer1Init();

    //	timer2 (FRC2) is used by the SDK (os_timer_arm, os_timer_arm_us)
    //	FRC2 is system programmed with 3.2 uS clock (312600 Hz).
    //	we use it also to measure the type period pin

	pTickTimer = (os_timer_t *)os_zalloc(sizeof(os_timer_t));
	os_timer_setfn(pTickTimer, (os_timer_func_t *)FTicker, NULL);
#ifdef USE_US_TIMER
	os_timer_arm_us(pTickTimer, 2000, 0);
#else
	os_timer_arm(pTickTimer, 10, 0);
#endif
	//	if we must use D0 as output for ADC or CommFault stuff and at boot time the input level was low
	if(((ADCOverUseD0_conf == true) || (CommFaultUseD0_conf == true)) && (FGpio16InputGet() == false))
	{
		//	set D0 pin (D16 GPIO) as output
		FGpio16OutputConf();
		//	set D0 pin (D16 GPIO) low level
		FGpio16OutputSet(0);
	}

    // initialization done
	system_init_done_cb(FSystemInitDoneCB);

}











