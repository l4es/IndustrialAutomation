﻿
'    Baud   Byte/sec  16bit/sec  32bit/sec  10slots(16bit)  10slots(32bit)  20slots(32bit)
' ----------------------------------------------------------------------------------------
'    1200       120        60        30          6
'    2400       240       120        60         12
'    4800       480       240       120         24
'    9600       960       480       240         48
'   19200      1920       960       480         96
'   38400      3840      1920       960        192
'   57600      5760      2880      1440        288
'  115200     11520      5760      2880       1440                720           360
'  250000     25000     12500      6250       3125               1562           781
'  500000     50000     25000     12500       6250               3125          1562
' 1000000    100000     50000     25000      12500               6250          3125
' 1500000    150000     75000     37500      18750               9375          4688
' 2000000    200000    100000     50000      25000              12500          9375

' Arduino Serial Buffer = 64 byte
' Hardware buffer is 64 bytes but seems to work only up to 63 bytes
' Subtracting 8 bytes  (Sync + CmdID + PayloadLen + CRC + Terminator)
' the remaining payload max length is 55 bytes 

' PROTOCOL
' --------------------------------------
' 4 bytes - SYNC
' 1 byte  - CMD ID
' 1 byte  - Payload length
' n bytes - Payload (max 55 bytes)
' 1 byte  - CRC
' 1 byte  - Terminator


Imports System.IO.Ports

Class ArduinoSerialPort

    Friend UsePolling As Boolean = True ' <-- Start with the PollingMode enabled for modules with the FT232 chip

    Friend MyDeviceIsActive As Boolean = False

    Private WithEvents ComPort As New SerialPort()

    Friend Shared Function GetPortNames() As String()
        Return SerialPort.GetPortNames()
    End Function

    Friend Function COM_Open(ByVal portName As String, ByVal speed As Int32) As Boolean
        ' -------------------------------------------- If the port is Open then close it
        COM_Close()
        ' -------------------------------------------- Set port name and SPEED
        ComPort.PortName = portName
        ComPort.BaudRate = speed
        ComPort.Parity = Parity.None
        ComPort.DataBits = 8
        ComPort.StopBits = StopBits.One
        ' -------------------------------------------- Set params
        ComPort.ReceivedBytesThreshold = 1
        ComPort.ReadBufferSize = 5000
        ComPort.WriteBufferSize = 1000
        ' -------------------------------------------- Flags
        'ComPort.DtrEnable = False
        'ComPort.RtsEnable = False
        ' -------------------------------------------- Try to open the port
        Try
            ComPort.Open()
            ComPort.DiscardInBuffer()
            Return True
        Catch
            Return False
        End Try
    End Function

    Friend Sub COM_Close()
        If ComPort.IsOpen Then
            ComPort.Close()
        End If
    End Sub

    Friend Function COM_IsOpened() As Boolean
        Return ComPort.IsOpen
    End Function

    ' ==============================================================================
    '   RECEIVE
    ' ==============================================================================
    Private Sub ComPort_DataReceived(ByVal sender As Object, _
                                     ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
                                     Handles ComPort.DataReceived
        If Not UsePolling Then
            TestDataReceived()
        End If
    End Sub

    Friend Function ReadByte() As Byte
        Try
            If Not ComPort.IsOpen Then Return 0
            If ComPort.BytesToRead = 0 Then Return 0
            Return CByte(ComPort.ReadByte)
        Catch
        End Try
    End Function

    Friend Sub ReceiveBufferFlush()
        If Not ComPort.IsOpen Then Return
        ComPort.DiscardInBuffer()
    End Sub

    Friend Sub TransmitBufferFlush()
        If Not ComPort.IsOpen Then Return
        ComPort.DiscardOutBuffer()
    End Sub

    ' ==============================================================================
    '   SEND
    ' ==============================================================================
    Friend Sub COM_SendText(ByVal text As String)
        If Not ComPort.IsOpen Then Return
        Try
            ComPort.Write(text)
        Catch
        End Try
    End Sub

    Friend Sub COM_SendBytes(ByVal bytes() As Byte)
        If Not ComPort.IsOpen Then Return
        Try
            ComPort.Write(bytes, 0, bytes.Length)
        Catch
        End Try
    End Sub


    ' ==============================================================================
    '   CRC
    ' ==============================================================================
    Private CRC As Byte
    Private Sub InitCrc()
        CRC = 0
    End Sub
    Private Sub AppendByteToCrc(ByVal new_byte As Byte)
        CRC = CByte(((CRC Xor new_byte) + 1) Mod 256)
    End Sub
    Private Sub AppendArrayToCrc(ByVal bytes() As Byte, ByVal nBytes As Byte)
        For i As Int32 = 0 To nBytes - 1
            CRC = CByte(((CRC Xor bytes(i)) + 1) Mod 256)
        Next
    End Sub
    Private Sub AppendArrayToCrc(ByVal bytes() As Byte)
        For i As Int32 = 0 To bytes.Length - 1
            CRC = CByte(((CRC Xor bytes(i)) + 1) Mod 256)
        Next
    End Sub

    ' ===============================================================================================
    '   ENUMS
    ' ===============================================================================================
    Private Enum CMD As Byte
        RECOGNIZE = 255
        DATA_EXCHANGE = 251
        SETUP_PROPS = 250
        SETUP_PINS = 249
        SET_NAME = 248
        NOCMD = 0
    End Enum


    ' ==============================================================================
    '  IN OUT BUFFERS
    ' ==============================================================================
    Private Const MaxPayloadBytes As Int32 = 55
    Friend OutputDataBuffer(MaxPayloadBytes) As Byte
    Friend InputDataBuffer(MaxPayloadBytes) As Byte


    ' ==============================================================================
    '   OUTPUT TO ARDUINO 
    ' ==============================================================================
    Private Const Terminator As Byte = 10
    Private Sync() As Byte = New Byte() {&H55, &HAA, &H55, &HAA}
    Private CmdArray() As Byte

    Private Const NumPins As Int32 = 22
    Private PinTypes(NumPins - 1) As Pin.PinTypes

    Private Sub COM_SendMessage()
        InitCrc()
        AppendArrayToCrc(CmdArray)
        ' ----------------------------------------------------------
        ' This sends multiple USB packets
        ' ----------------------------------------------------------
        'COM_SendBytes(Sync)
        'COM_SendBytes(CmdArray)
        'COM_SendBytes(New Byte() {CRC, Terminator})
        ' ----------------------------------------------------------
        ' This sends a single ComPort.Write for a single USB packet
        ' ----------------------------------------------------------
        Dim MsgArray(-1) As Byte
        AppendByteArray(Sync, MsgArray)
        AppendByteArray(CmdArray, MsgArray)
        AppendByteArray(New Byte() {CRC, Terminator}, MsgArray)
        COM_SendBytes(MsgArray)
    End Sub

    Friend Sub SetPinType(ByVal index As Int32, ByVal pintype As Pin.PinTypes)
        PinTypes(index) = pintype
    End Sub

    Friend Sub COM_SendDataExchange(ByVal OutputBytesCount As Int32)
        ReDim CmdArray(OutputBytesCount + 2 - 1)
        Dim i As Int32
        CmdArray(i) = CMD.DATA_EXCHANGE
        CmdArray(i + 1) = CByte(OutputBytesCount)
        For i = 0 To OutputBytesCount - 1
            CmdArray(i + 2) = OutputDataBuffer(i)
        Next
        COM_SendMessage()
    End Sub

    Friend Sub COM_SendModuleProps(ByVal AsyncMode As Boolean)
        COM_Result = ""
        ReDim CmdArray(3 - 1)
        Dim i As Int32
        CmdArray(i) = CMD.SETUP_PROPS
        CmdArray(i + 1) = 1
        CmdArray(i + 2) = CByte(AsyncMode)
        COM_SendMessage()
    End Sub

    Friend Sub COM_SendPinTypes()
        COM_Result = ""
        ReDim CmdArray(NumPins + 2 - 1)
        Dim i As Int32
        CmdArray(i) = CMD.SETUP_PINS
        CmdArray(i + 1) = CByte(NumPins)
        For i = 0 To NumPins - 1
            CmdArray(i + 2) = CByte(PinTypes(i))
        Next
        COM_SendMessage()
    End Sub

    Friend Sub COM_SendName(ByVal s As String)
        COM_Result = ""
        ReDim CmdArray(s.Length + 2 - 1)
        Dim i As Int32
        CmdArray(i) = CMD.SET_NAME
        CmdArray(i + 1) = CByte(s.Length)
        For i = 0 To s.Length - 1
            CmdArray(i + 2) = CByte(AscW(s(i)))
        Next
        COM_SendMessage()
    End Sub

    Friend Sub COM_SendRecognize()
        COM_Result = ""
        Identifier = ""
        Version = ""
        Name = ""
        CmdArray = New Byte() {CMD.RECOGNIZE, 0}
        COM_SendMessage()
    End Sub


    ' ==============================================================================
    '   INPUT FROM ARDUINO 
    ' ==============================================================================
    Private Enum ReceiveStates
        WAITING_SYNC = 0
        WAITING_END = 1
        FLUSH = 2
    End Enum
    Private Status As ReceiveStates

    Private ReceivedCommandID As Byte
    Private ReceivedPayloadBytes As Byte
    Private ReceivedCRC As Byte
    Private ReceivedTerminator As Byte
    Private BytesToWait As Int32

    Friend COM_Result As String
    Friend DataExchangeCompleted As Boolean = True
    Friend Identifier As String = ""
    Friend Version As String = ""
    Friend Name As String = ""

    Private Const SyncLen As Byte = 4
    Private Function testSync() As Boolean
        If ReadByte() <> &H55 Then Return False
        If ReadByte() <> &HAA Then Return False
        If ReadByte() <> &H55 Then Return False
        If ReadByte() <> &HAA Then Return False
        Return True
    End Function

    Private Sub EnterFlushStatus()
        ReceiveBufferFlush()
        Status = ReceiveStates.FLUSH
        BytesToWait = 1
        'SleepMyThread(200)

        ' ReceiveBufferFlush()
        ' Status = ReceiveStates.WAITING_SYNC
        ' BytesToWait = SyncLen + 2
        ' delay(200)
    End Sub

    Friend Sub TestDataReceived()
        '
        ' --------------------------------------------------------------
        If Not ComPort.IsOpen Then Return
        Try
            If (ComPort.BytesToRead < BytesToWait) Then Return
        Catch
            Return
        End Try
        '
        Select Case (Status)
            ' ---------------------------------------------------------- flush
            Case ReceiveStates.FLUSH
                ReceiveBufferFlush()
                Status = ReceiveStates.WAITING_SYNC
                BytesToWait = (SyncLen + 2)
                Return
                ' ------------------------------------------------------ waiting sync
            Case ReceiveStates.WAITING_SYNC
                If testSync() Then
                    ReceivedCommandID = ReadByte()
                    ReceivedPayloadBytes = ReadByte()
                    If (ReceivedPayloadBytes > MaxPayloadBytes) Then
                        COM_Result = "ERROR - PayloadBytes = " + ReceivedPayloadBytes.ToString
                        EnterFlushStatus()
                        Return
                    End If
                    Status = ReceiveStates.WAITING_END
                    BytesToWait = ReceivedPayloadBytes + 2
                Else
                    COM_Result = "ERROR - Sync error" + vbCrLf
                    'COM_FPS = 0
                    EnterFlushStatus()
                    Return
                End If
            Case ReceiveStates.WAITING_END
                ' ------------------------------------------------------ get all the bytes
                Dim i As Int32 = 0
                Do While (i < ReceivedPayloadBytes)
                    InputDataBuffer(i) = ReadByte()
                    i = (i + 1)
                Loop
                ReceivedCRC = ReadByte()
                ReceivedTerminator = ReadByte()
                ' ------------------------------------------------------ test terminator
                If (ReceivedTerminator <> Terminator) Then
                    COM_Result = "ERROR - Terminator not zero = " + ReceivedTerminator.ToString
                    EnterFlushStatus()
                    Return
                End If
                ' ------------------------------------------------------ test crc
                InitCrc()
                AppendByteToCrc(ReceivedCommandID)
                AppendByteToCrc(ReceivedPayloadBytes)
                AppendArrayToCrc(InputDataBuffer, ReceivedPayloadBytes)
                If (CRC <> ReceivedCRC) Then
                    COM_Result = "ERROR - CRC - Rec.=" + ReceivedCRC.ToString + _
                                        " Calc.=" + CRC.ToString + vbCrLf
                    EnterFlushStatus()
                    Return
                End If
                ' ------------------------------------------------------ execute command
                Select Case (ReceivedCommandID)
                    Case CMD.RECOGNIZE
                        Dim s As String() = ReadReceivedDataBufferStrings()
                        If s.Length = 3 Then
                            Identifier = s(0)
                            Version = s(1)
                            Name = s(2)
                        End If
                        COM_Result = "Recognize OK"
                    Case CMD.SETUP_PROPS
                        ' Dim s As String() = ReadReceivedDataBufferStrings()
                        ' s(0) contains OutputBytesCount but we do not use it
                        ' s(1) contains InputBytesCount but we do not use it
                        COM_Result = "SetupProps OK"
                    Case CMD.SETUP_PINS
                        ' Dim s As String() = ReadReceivedDataBufferStrings()
                        ' s(0) contains OutputBytesCount but we do not use it
                        ' s(1) contains InputBytesCount but we do not use it
                        COM_Result = "SetupPins OK"
                    Case CMD.SET_NAME
                        ' Dim s As String() = ReadReceivedDataBufferStrings()
                        ' s(0) contains the received name but we do not use it
                        COM_Result = "SetName OK"
                    Case CMD.DATA_EXCHANGE
                        COM_Result = "DataExchange OK"
                        DataExchangeCompleted = True
                    Case Else
                        EnterFlushStatus()
                        Return
                End Select
                Status = ReceiveStates.WAITING_SYNC
                BytesToWait = SyncLen + 2
        End Select
    End Sub

    Private Function ReadReceivedDataBufferStrings() As String()
        Dim s As String = ""
        For i As Int32 = 0 To ReceivedPayloadBytes - 1
            s += ChrW(InputDataBuffer(i))
        Next
        Return s.Split(ChrW(13))
    End Function

End Class
