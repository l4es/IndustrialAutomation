﻿
' ==================================================================================================
'   CLASS Module_InOut
' ==================================================================================================

Partial Friend Class Module_InOut

    Private PollingMode As Boolean = True ' <-- Start with the PollingMode enabled for modules with the FT232 chip

    Friend ArduPort As ArduinoSerialPort

    Private mActionLock As Object = New Object
    Private mMaxFps As Int32

    Friend ConfigId As Int32
    Friend ConfigValid As Boolean

    Friend ModuleId As Int32
    Friend ModuleVersion As String
    Private ModuleName As String

    Friend CommSpeed As Int32
    Friend CommMillisec As Single
    Friend CommFps As Single

    Private AsyncMode As Boolean

    Friend ErrorRate As Single

    Friend Sub SetCommSpeed(ByVal _speed As Int32)
        CommSpeed = _speed
        Select Case CommSpeed
            Case 1 : mMaxFps = 10
            Case 2 : mMaxFps = 20
            Case 3 : mMaxFps = 30
            Case 4 : mMaxFps = 50
            Case 5 : mMaxFps = 60
            Case 6 : mMaxFps = 100
            Case 7 : mMaxFps = 150
            Case 8 : mMaxFps = 200
            Case 9 : mMaxFps = 300
            Case 10 : mMaxFps = 400
            Case 11 : mMaxFps = 500
            Case Else : mMaxFps = 9999
        End Select
    End Sub

    Friend Sub SetName(ByVal _name As String)
        ModuleName = _name
    End Sub

    Friend Function GetName() As String
        Return ModuleName
    End Function

    Friend Sub SetAsyncMode(ByVal _AsyncMode As Boolean)
        AsyncMode = _AsyncMode
        SetupModuleProps()
    End Sub
    Friend Function GetAsyncMode() As Boolean
        Return AsyncMode
    End Function

    Friend Sub SetPollingMode(ByVal _PollingMode As Boolean)
        PollingMode = _PollingMode
        ArduPort.UsePolling = PollingMode
    End Sub
    Friend Function GetPollingMode() As Boolean
        Return PollingMode
    End Function

    Friend Sub New(ByVal _moduleid As Int32)
        ModuleName = ""
        ModuleId = _moduleid
        ModuleVersion = "NoVersion"
        SetCommSpeed(7)
        CommFps = 100
        InitDefaultPins()
    End Sub


    ' ==========================================================================================
    '   PUBLIC COMMANDS
    ' ==========================================================================================
    Friend Sub CalibrateZero()
        For Each p As Pin In Pins
            p.CalibrateZero()
        Next
    End Sub

    Friend Sub SetSpeed(ByVal _Speed As Int32)
        StopTimedOperations()
        SyncLock mActionLock
            SetCommSpeed(_Speed)
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Sub SetOutputPinsToParkingPosition()
        StopTimedOperations()
        SyncLock mActionLock
            For Each p As Pin In Pins
                If p.Direction = Pin.Directions.HostToModule Then
                    ' -------------------------------------------
                    p.Value = p.Value_Parking
                    If Single.IsNaN(p.Value) Then
                        Slots.WriteSlot(p.Slot, p.Value)
                    Else
                        p.ConvertValueToHardwareFormat()
                        Slots.WriteSlot(p.Slot, p.Value_RawUinteger)
                    End If
                End If
            Next
            ' --------------------------------------------------- update phisical module immediately
            DataExchange()
            System.Threading.Thread.Sleep(32)
        End SyncLock
        StartTimedOperations()
    End Sub

    ' ==============================================================================
    '   Prepare all communications index and counts
    ' ==============================================================================
    Private InputBytesCount As Int32
    Private OutputBytesCount As Int32

    Friend Sub SetCommunicationIndexesToPins()
        ' ------------------------------------------------------- 
        InputBytesCount = 0
        OutputBytesCount = 0
        ' ------------------------------------------------------- byte index starting from zero
        Dim CommByteIndex_HostToHardware As Int32 = 0
        ' ------------------------------------------------------- byte index starting from zero
        Dim CommByteIndex_HardwareToHost As Int32 = 0
        '
        For Each p As Pin In Pins
            ' --------------------------------------------------- communication byte index
            Select Case p.Direction
                Case Pin.Directions.HostToModule
                    p.CommByteIndex_ = CommByteIndex_HostToHardware
                    CommByteIndex_HostToHardware += p.CommBytesCount
                    OutputBytesCount += p.CommBytesCount
                Case Pin.Directions.ModuleToHost
                    p.CommByteIndex_ = CommByteIndex_HardwareToHost
                    CommByteIndex_HardwareToHost += p.CommBytesCount
                    InputBytesCount += p.CommBytesCount
            End Select
        Next
    End Sub


    ' ==========================================================================================
    '   PINS
    ' ==========================================================================================
    Friend Pins As List(Of Pin)

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        For i As Int32 = 0 To 21
            Pins.Add(New Pin(Pin.PinTypes.UNUSED, ModuleId, i))
        Next
    End Sub

    Friend Sub ConfigurePin(ByVal npin As Int32, ByVal pinType As Pin.PinTypes)
        Select Case pinType
            Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                If ValidPwmPin(Pins(npin)) Then Pins(npin).SetPinType(pinType)

            Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                If ValidServoPin(Pins(npin)) Then Pins(npin).SetPinType(pinType)

            Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                 Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                If ValidCounterPeriodPin(Pins(npin)) Then Pins(npin).SetPinType(pinType)

            Case Pin.PinTypes.ADC_8, _
                 Pin.PinTypes.ADC_16
                If ValidAdcPin(Pins(npin)) Then Pins(npin).SetPinType(pinType)

            Case Else
                Pins(npin).SetPinType(pinType)
        End Select
    End Sub

    Friend Sub FillTypeCombo(ByVal cmb As ComboBox, ByRef p As Pin)
        cmb.Items.Clear()
        '
        If p.PinId > 1 Then
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
            '
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT))

            If ValidPwmPin(p) Then
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8))
                'cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16))
            End If

            If ValidServoPin(p) Then
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16))
            End If

            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN))
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU))

            If ValidAdcPin(p) Then
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16))
            End If
        End If

        'If ValidCounterPeriodPin(p) Then
        '    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER))
        '    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU))
        '    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD))
        '    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU))
        'End If
        '
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
        '
        If ValidGenericPin(1) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_OUT_8))
        If ValidGenericPin(2) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_OUT_16))
        If ValidGenericPin(3) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_OUT_24))
        If ValidGenericPin(1) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_IN_8))
        If ValidGenericPin(2) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_IN_16))
        If ValidGenericPin(3) Then cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.GEN_IN_24))
    End Sub

    Private Function ValidPwmPin(ByVal p As Pin) As Boolean
        Select Case p.PinId
            Case 3, 5, 6, 9, 10, 11 : Return True
        End Select
        Return False
    End Function

    Private Function ValidServoPin(ByVal p As Pin) As Boolean
        'Select Case p.PinId
        '    Case 3, 5, 6, 9, 10, 11 : Return True
        'End Select
        Return True
    End Function

    Private Function ValidAdcPin(ByVal p As Pin) As Boolean
        If p.PinId < 14 Then Return False
        Return True
    End Function

    Private Function ValidCounterPeriodPin(ByVal p As Pin) As Boolean
        'Select Case p.PinId
        '    Case 3, 5, 6, 9, 10, 11 : Return True
        'End Select
        Return False
    End Function

    Private Function ValidGenericPin(ByVal size As Int32) As Boolean
        'If nummmmm + size > 54 Then Return False
        Return True
    End Function



    ' ##########################################################################################
    ' ******************************************************************************************
    '   COMMUNICATION WITH THE HARDWARE MODULES
    ' ******************************************************************************************
    ' ##########################################################################################

    Private Sub Execution_Error(ByVal ErrorString As String)
        ErrorRate += 0.01F
        'Debug.Print("ERROR - " & ErrorString)
    End Sub

    Private Sub Execution_OK()
        ErrorRate *= 0.95F
    End Sub

    ' ==========================================================================================
    '   LOOPS AND COMMUNICATIONS
    ' ==========================================================================================
    Private sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch
    Private rawFps As Single
    Private delayMs As Int32
    Private Sub DataExchange()
        ' ------------------------------------------------------------- if disconnected return
        If Not ArduPort.MyDeviceIsActive Then
            CommFps = 0
            ErrorRate = 100
            Threading.Thread.Sleep(10)
            Return
        End If
        ' ------------------------------------------------------------- ExecuteDataExchange
        ExecuteDataExchange()
        ' ------------------------------------------------------------- CommMillisec
        'CommMillisec = CSng(sw1.Elapsed.TotalMilliseconds)
        CommMillisec = CSng(sw1.ElapsedMilliseconds)
        rawFps = 1000.0F / CommMillisec
        sw1.Reset()
        sw1.Start()
        If CommMillisec >= 1 Then
            SmoothValue(CommFps, rawFps, 0.1, True, CommFps)
        End If
        ' ------------------------------------------------------------- adaptive FPS
        If mMaxFps < 9999 Then
            delayMs += Math.Sign(rawFps - mMaxFps)
            If delayMs > 100 Then delayMs = 100
            If delayMs <= 0 Then
                delayMs = 0
            Else
                System.Threading.Thread.Sleep(delayMs)
            End If
        End If
    End Sub

    Private Sub ExecuteDataExchange()
        If Not ArduPort.DataExchangeCompleted Then Return

        ' ----------------------------------------------------------- SLOTS to COM-BUFFER
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.HostToModule Then
                p.ReadValueFromSlot()
                p.ConvertValueToHardwareFormat()
                p.WriteValueToOutputBuffer()
            End If
        Next
        ' ----------------------------------------------------------- COM_SendDataExchange
        ArduPort.DataExchangeCompleted = False
        ArduPort.COM_SendDataExchange(OutputBytesCount)

        ' ----------------------------------------------------------- Wait response or 100 mS timeout
        Static timeout As Stopwatch = New Stopwatch
        Static errorCounter As Int32
        While Not ArduPort.DataExchangeCompleted
            timeout.Start()
            SleepMyThread(1)
            If PollingMode Then ArduPort.TestDataReceived()

            If timeout.ElapsedMilliseconds > 30 Then
                timeout.Reset()
                ArduPort.DataExchangeCompleted = True
                Execution_Error("FastDataExchange timeout")
                errorCounter += 1
                If errorCounter > 20 Then
                    ArduPort.MyDeviceIsActive = False
                End If
                Return
            End If
        End While
        errorCounter = 0
        timeout.Reset()
        Execution_OK()
        ' ----------------------------------------------------------- COM-BUFFER to SLOTS
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.ModuleToHost Then
                p.ReadValueFromInputBuffer()
                p.ConvertValueFromHardwareFormat()
                p.WriteValueToSlot()
            End If
        Next
        ' ------------------------------- this helps the FT232
        ArduPort.ReceiveBufferFlush()
    End Sub

    Friend Sub SetupModuleProps()
        StopTimedOperations()
        SyncLock mActionLock
            ' ------------------------------------------------------- retry 10 times
            For retry As Int32 = 1 To 10
                ' --------------------------------------------------- send module props
                ArduPort.COM_SendModuleProps(AsyncMode)
                ' --------------------------------------------------- wait and test for errors
                For i As Int32 = 0 To 100
                    SleepMyThread(1)
                    If PollingMode Then ArduPort.TestDataReceived()

                    If ArduPort.COM_Result <> "" Then
                        If ArduPort.COM_Result.StartsWith("ERROR") Then
                            Execution_Error("SetupProps")
                        Else
                            Execution_OK()
                            retry = 9999
                        End If
                        Exit For
                    End If
                Next
            Next
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Sub SetupModulePins()
        StopTimedOperations()
        SyncLock mActionLock
            ' ------------------------------------------------------- retry 10 times
            For retry As Int32 = 1 To 10
                ' --------------------------------------------------- set com indexes to pins
                SetCommunicationIndexesToPins()
                ' --------------------------------------------------- send pin types
                For i As Int32 = 0 To Pins.Count - 1
                    ArduPort.SetPinType(i, Pins(i).GetPinType)
                Next
                ArduPort.COM_SendPinTypes()
                ' --------------------------------------------------- wait and test for errors
                For i As Int32 = 0 To 100
                    SleepMyThread(1)
                    If PollingMode Then ArduPort.TestDataReceived()

                    If ArduPort.COM_Result <> "" Then
                        If ArduPort.COM_Result.StartsWith("ERROR") Then
                            Execution_Error("SetupPins")
                        Else
                            Execution_OK()
                            retry = 9999
                        End If
                        Exit For
                    End If
                Next
            Next
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Sub WriteNameToHardware()
        StopTimedOperations()
        SyncLock mActionLock
            ' ------------------------------------------------------- retry 10 times
            For retry As Int32 = 1 To 10
                ' --------------------------------------------------- send name
                ArduPort.COM_SendName(ModuleName)
                ' --------------------------------------------------- wait and test for errors
                For i As Int32 = 0 To 100
                    SleepMyThread(1)
                    If PollingMode Then ArduPort.TestDataReceived()

                    If ArduPort.COM_Result <> "" Then
                        If ArduPort.COM_Result.StartsWith("ERROR") Then
                            Execution_Error("SetupPins")
                        Else
                            Execution_OK()
                            retry = 9999
                        End If
                        Exit For
                    End If
                Next
            Next
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Sub ReadInfoFromHardware()
        StopTimedOperations()
        SyncLock mActionLock
            ' ------------------------------------------------- retry 10 times
            For retry As Int32 = 1 To 10
                ArduPort.MyDeviceIsActive = False
                ArduPort.COM_SendRecognize()
                ' --------------------------------------------- test with 100 mS timeout
                For i As Int32 = 0 To 100
                    SleepMyThread(1)
                    If PollingMode Then ArduPort.TestDataReceived()

                    If ArduPort.Identifier = "Arduino" Then
                        ModuleVersion = ArduPort.Version
                        ModuleName = ArduPort.Name
                        ArduPort.MyDeviceIsActive = True
                        retry = 9999
                        Exit For
                    End If
                Next
            Next
            ' ------------------------------------------------- test errors
            If ArduPort.MyDeviceIsActive Then
                Execution_OK()
            Else
                Execution_Error("Recognize")
            End If
        End SyncLock
        StartTimedOperations()
    End Sub

End Class

