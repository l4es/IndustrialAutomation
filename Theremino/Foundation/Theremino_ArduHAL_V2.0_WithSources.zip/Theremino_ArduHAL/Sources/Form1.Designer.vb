﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As Theremino_ArduHAL.DesignerRectTracker = New Theremino_ArduHAL.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim CBlendItems1 As Theremino_ArduHAL.cBlendItems = New Theremino_ArduHAL.cBlendItems
        Dim CBlendItems2 As Theremino_ArduHAL.cBlendItems = New Theremino_ArduHAL.cBlendItems
        Dim DesignerRectTracker2 As Theremino_ArduHAL.DesignerRectTracker = New Theremino_ArduHAL.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_ArduHAL.DesignerRectTracker = New Theremino_ArduHAL.DesignerRectTracker
        Dim CBlendItems3 As Theremino_ArduHAL.cBlendItems = New Theremino_ArduHAL.cBlendItems
        Dim CBlendItems4 As Theremino_ArduHAL.cBlendItems = New Theremino_ArduHAL.cBlendItems
        Dim DesignerRectTracker4 As Theremino_ArduHAL.DesignerRectTracker = New Theremino_ArduHAL.DesignerRectTracker
        Me.Timer_10Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_ModuleProps = New System.Windows.Forms.GroupBox
        Me.chk_PollingMode = New System.Windows.Forms.CheckBox
        Me.chk_AsyncMode = New System.Windows.Forms.CheckBox
        Me.btn_ModuleName = New Theremino_ArduHAL.MyButton
        Me.cmb_ModuleNames = New Theremino_ArduHAL.MyComboBox
        Me.lbl_ErrorRate = New System.Windows.Forms.Label
        Me.Label_ErrorRate = New System.Windows.Forms.Label
        Me.lbl_RepeatFrequency = New System.Windows.Forms.Label
        Me.Label_RepFreq = New System.Windows.Forms.Label
        Me.txt_CommSpeed = New Theremino_ArduHAL.MyTextBox
        Me.Label_CommSpeed = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label_MinValue = New System.Windows.Forms.Label
        Me.Label_MaxValue = New System.Windows.Forms.Label
        Me.GroupBox_PinProps = New System.Windows.Forms.GroupBox
        Me.Label_ResponseSpeed = New Theremino_ArduHAL.MyButton
        Me.txt_Slot = New Theremino_ArduHAL.MyTextBox
        Me.cmb_PinType = New Theremino_ArduHAL.MyComboBox
        Me.Label_PinType = New System.Windows.Forms.Label
        Me.txt_MaxValue = New Theremino_ArduHAL.MyTextBox
        Me.txt_ResponseSpeed = New Theremino_ArduHAL.MyTextBox
        Me.txt_MinValue = New Theremino_ArduHAL.MyTextBox
        Me.Timer_1Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_ServoPwmProps = New System.Windows.Forms.GroupBox
        Me.chk_LogResponse = New System.Windows.Forms.CheckBox
        Me.txt_ServoMaxTime = New Theremino_ArduHAL.MyTextBox
        Me.Label_MinTime = New System.Windows.Forms.Label
        Me.txt_ServoMinTime = New Theremino_ArduHAL.MyTextBox
        Me.Label_MaxTime = New System.Windows.Forms.Label
        Me.GroupBox_FrequencyProps = New System.Windows.Forms.GroupBox
        Me.chk_ConvertToFrequency = New System.Windows.Forms.CheckBox
        Me.txt_MaxFreq = New Theremino_ArduHAL.MyTextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txt_MinFreq = New Theremino_ArduHAL.MyTextBox
        Me.Label_MaxFreq = New System.Windows.Forms.Label
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_Recognize = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Validate = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_BeepOnErrors = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_CommOptions = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Disconnect = New System.Windows.Forms.ToolStripButton
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_EditSlotNames = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_EditConfigurations = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_EditCommOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_BackupConfigurations = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_LoadConfigurations = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_English = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Italian = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Francais = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Espanol = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Portoguese = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Deutsch = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Japanese = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Chinese = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer_60Hz = New System.Windows.Forms.Timer(Me.components)
        Me.MyListView1 = New Theremino_ArduHAL.ListViewFlickerFree
        Me.GroupBox_ModuleProps.SuspendLayout()
        Me.GroupBox_PinProps.SuspendLayout()
        Me.GroupBox_ServoPwmProps.SuspendLayout()
        Me.GroupBox_FrequencyProps.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer_10Hz
        '
        '
        'GroupBox_ModuleProps
        '
        Me.GroupBox_ModuleProps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_ModuleProps.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_ModuleProps.Controls.Add(Me.chk_PollingMode)
        Me.GroupBox_ModuleProps.Controls.Add(Me.chk_AsyncMode)
        Me.GroupBox_ModuleProps.Controls.Add(Me.btn_ModuleName)
        Me.GroupBox_ModuleProps.Controls.Add(Me.cmb_ModuleNames)
        Me.GroupBox_ModuleProps.Controls.Add(Me.lbl_ErrorRate)
        Me.GroupBox_ModuleProps.Controls.Add(Me.Label_ErrorRate)
        Me.GroupBox_ModuleProps.Controls.Add(Me.lbl_RepeatFrequency)
        Me.GroupBox_ModuleProps.Controls.Add(Me.Label_RepFreq)
        Me.GroupBox_ModuleProps.Controls.Add(Me.txt_CommSpeed)
        Me.GroupBox_ModuleProps.Controls.Add(Me.Label_CommSpeed)
        Me.GroupBox_ModuleProps.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ModuleProps.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox_ModuleProps.Location = New System.Drawing.Point(439, 53)
        Me.GroupBox_ModuleProps.Name = "GroupBox_ModuleProps"
        Me.GroupBox_ModuleProps.Size = New System.Drawing.Size(180, 151)
        Me.GroupBox_ModuleProps.TabIndex = 137
        Me.GroupBox_ModuleProps.TabStop = False
        Me.GroupBox_ModuleProps.Text = "Module properties"
        '
        'chk_PollingMode
        '
        Me.chk_PollingMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_PollingMode.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_PollingMode.Location = New System.Drawing.Point(9, 127)
        Me.chk_PollingMode.Name = "chk_PollingMode"
        Me.chk_PollingMode.Size = New System.Drawing.Size(159, 17)
        Me.chk_PollingMode.TabIndex = 181
        Me.chk_PollingMode.Text = "Polling mode"
        Me.chk_PollingMode.UseVisualStyleBackColor = True
        '
        'chk_AsyncMode
        '
        Me.chk_AsyncMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AsyncMode.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_AsyncMode.Location = New System.Drawing.Point(9, 108)
        Me.chk_AsyncMode.Name = "chk_AsyncMode"
        Me.chk_AsyncMode.Size = New System.Drawing.Size(159, 17)
        Me.chk_AsyncMode.TabIndex = 180
        Me.chk_AsyncMode.Text = "Async mode"
        Me.chk_AsyncMode.UseVisualStyleBackColor = True
        '
        'btn_ModuleName
        '
        Me.btn_ModuleName.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ModuleName.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(133, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ModuleName.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ModuleName.ColorFillBlendChecked = CBlendItems2
        Me.btn_ModuleName.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ModuleName.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ModuleName.Corners.All = CType(2, Short)
        Me.btn_ModuleName.Corners.LowerLeft = CType(2, Short)
        Me.btn_ModuleName.Corners.LowerRight = CType(2, Short)
        Me.btn_ModuleName.Corners.UpperLeft = CType(2, Short)
        Me.btn_ModuleName.Corners.UpperRight = CType(2, Short)
        Me.btn_ModuleName.DimFactorGray = -10
        Me.btn_ModuleName.DimFactorOver = 40
        Me.btn_ModuleName.FillType = Theremino_ArduHAL.MyButton.eFillType.LinearVertical
        Me.btn_ModuleName.FillTypeChecked = Theremino_ArduHAL.MyButton.eFillType.LinearVertical
        Me.btn_ModuleName.FocalPoints.CenterPtX = 0.4318182!
        Me.btn_ModuleName.FocalPoints.CenterPtY = 0.2666667!
        Me.btn_ModuleName.FocalPoints.FocusPtX = 0.0!
        Me.btn_ModuleName.FocalPoints.FocusPtY = 0.0!
        Me.btn_ModuleName.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_ModuleName.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_ModuleName.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ModuleName.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ModuleName.FocusPtTracker = DesignerRectTracker2
        Me.btn_ModuleName.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ModuleName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btn_ModuleName.Image = Nothing
        Me.btn_ModuleName.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ModuleName.ImageIndex = 0
        Me.btn_ModuleName.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ModuleName.Location = New System.Drawing.Point(13, 23)
        Me.btn_ModuleName.Name = "btn_ModuleName"
        Me.btn_ModuleName.Shape = Theremino_ArduHAL.MyButton.eShape.Rectangle
        Me.btn_ModuleName.SideImage = Nothing
        Me.btn_ModuleName.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ModuleName.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ModuleName.Size = New System.Drawing.Size(44, 15)
        Me.btn_ModuleName.TabIndex = 179
        Me.btn_ModuleName.Text = "Name"
        Me.btn_ModuleName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ModuleName.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ModuleName.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ModuleName.TextShadow = System.Drawing.Color.Transparent
        '
        'cmb_ModuleNames
        '
        Me.cmb_ModuleNames.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_ModuleNames.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_ModuleNames.BackColor = System.Drawing.Color.MintCream
        Me.cmb_ModuleNames.BackColor_Focused = System.Drawing.Color.MintCream
        Me.cmb_ModuleNames.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_ModuleNames.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_ModuleNames.BorderSize = 1
        Me.cmb_ModuleNames.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_ModuleNames.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_ModuleNames.DropDown_BackSelected = System.Drawing.Color.LightBlue
        Me.cmb_ModuleNames.DropDown_BorderColor = System.Drawing.Color.Gainsboro
        Me.cmb_ModuleNames.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_ModuleNames.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_ModuleNames.DropDownHeight = 500
        Me.cmb_ModuleNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_ModuleNames.DropDownWidth = 122
        Me.cmb_ModuleNames.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_ModuleNames.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ModuleNames.ForeColor = System.Drawing.Color.Black
        Me.cmb_ModuleNames.IntegralHeight = False
        Me.cmb_ModuleNames.ItemHeight = 10
        Me.cmb_ModuleNames.Location = New System.Drawing.Point(61, 22)
        Me.cmb_ModuleNames.MaxDropDownItems = 99
        Me.cmb_ModuleNames.Name = "cmb_ModuleNames"
        Me.cmb_ModuleNames.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_ModuleNames.Size = New System.Drawing.Size(109, 16)
        Me.cmb_ModuleNames.TabIndex = 178
        Me.cmb_ModuleNames.TabStop = False
        Me.cmb_ModuleNames.TextPosition = 1
        '
        'lbl_ErrorRate
        '
        Me.lbl_ErrorRate.BackColor = System.Drawing.Color.Transparent
        Me.lbl_ErrorRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_ErrorRate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ErrorRate.Location = New System.Drawing.Point(118, 65)
        Me.lbl_ErrorRate.Name = "lbl_ErrorRate"
        Me.lbl_ErrorRate.Size = New System.Drawing.Size(51, 17)
        Me.lbl_ErrorRate.TabIndex = 177
        Me.lbl_ErrorRate.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_ErrorRate
        '
        Me.Label_ErrorRate.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ErrorRate.Location = New System.Drawing.Point(10, 66)
        Me.Label_ErrorRate.Name = "Label_ErrorRate"
        Me.Label_ErrorRate.Size = New System.Drawing.Size(102, 13)
        Me.Label_ErrorRate.TabIndex = 176
        Me.Label_ErrorRate.Text = "Error rate (%)"
        Me.Label_ErrorRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl_RepeatFrequency
        '
        Me.lbl_RepeatFrequency.BackColor = System.Drawing.Color.Transparent
        Me.lbl_RepeatFrequency.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RepeatFrequency.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RepeatFrequency.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl_RepeatFrequency.Location = New System.Drawing.Point(118, 46)
        Me.lbl_RepeatFrequency.Name = "lbl_RepeatFrequency"
        Me.lbl_RepeatFrequency.Size = New System.Drawing.Size(51, 17)
        Me.lbl_RepeatFrequency.TabIndex = 175
        Me.lbl_RepeatFrequency.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_RepFreq
        '
        Me.Label_RepFreq.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_RepFreq.Location = New System.Drawing.Point(10, 45)
        Me.Label_RepFreq.Name = "Label_RepFreq"
        Me.Label_RepFreq.Size = New System.Drawing.Size(102, 13)
        Me.Label_RepFreq.TabIndex = 174
        Me.Label_RepFreq.Text = "Rep freq. (fps)"
        Me.Label_RepFreq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_CommSpeed
        '
        Me.txt_CommSpeed.ArrowsIncrement = 1
        Me.txt_CommSpeed.BackColor = System.Drawing.Color.MintCream
        Me.txt_CommSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_CommSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_CommSpeed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_CommSpeed.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CommSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_CommSpeed.Increment = 0.2
        Me.txt_CommSpeed.Location = New System.Drawing.Point(129, 87)
        Me.txt_CommSpeed.MaxValue = 12
        Me.txt_CommSpeed.MinValue = 1
        Me.txt_CommSpeed.Name = "txt_CommSpeed"
        Me.txt_CommSpeed.NumericValue = 7
        Me.txt_CommSpeed.NumericValueInteger = 7
        Me.txt_CommSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_CommSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_CommSpeed.RoundingStep = 0
        Me.txt_CommSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_CommSpeed.Size = New System.Drawing.Size(40, 15)
        Me.txt_CommSpeed.SuppressZeros = True
        Me.txt_CommSpeed.TabIndex = 2
        Me.txt_CommSpeed.Text = "7"
        Me.txt_CommSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_CommSpeed
        '
        Me.Label_CommSpeed.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_CommSpeed.Location = New System.Drawing.Point(10, 88)
        Me.Label_CommSpeed.Name = "Label_CommSpeed"
        Me.Label_CommSpeed.Size = New System.Drawing.Size(112, 13)
        Me.Label_CommSpeed.TabIndex = 162
        Me.Label_CommSpeed.Text = "Comm. speed"
        Me.Label_CommSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(10, 50)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 13)
        Me.Label13.TabIndex = 174
        Me.Label13.Text = "Slot"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_MinValue
        '
        Me.Label_MinValue.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MinValue.Location = New System.Drawing.Point(10, 92)
        Me.Label_MinValue.Name = "Label_MinValue"
        Me.Label_MinValue.Size = New System.Drawing.Size(102, 13)
        Me.Label_MinValue.TabIndex = 166
        Me.Label_MinValue.Text = "Min value"
        Me.Label_MinValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_MaxValue
        '
        Me.Label_MaxValue.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxValue.Location = New System.Drawing.Point(10, 71)
        Me.Label_MaxValue.Name = "Label_MaxValue"
        Me.Label_MaxValue.Size = New System.Drawing.Size(102, 13)
        Me.Label_MaxValue.TabIndex = 162
        Me.Label_MaxValue.Text = "Max value"
        Me.Label_MaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox_PinProps
        '
        Me.GroupBox_PinProps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_PinProps.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_PinProps.Controls.Add(Me.Label_ResponseSpeed)
        Me.GroupBox_PinProps.Controls.Add(Me.txt_Slot)
        Me.GroupBox_PinProps.Controls.Add(Me.cmb_PinType)
        Me.GroupBox_PinProps.Controls.Add(Me.Label_PinType)
        Me.GroupBox_PinProps.Controls.Add(Me.Label_MaxValue)
        Me.GroupBox_PinProps.Controls.Add(Me.Label13)
        Me.GroupBox_PinProps.Controls.Add(Me.txt_MaxValue)
        Me.GroupBox_PinProps.Controls.Add(Me.txt_ResponseSpeed)
        Me.GroupBox_PinProps.Controls.Add(Me.txt_MinValue)
        Me.GroupBox_PinProps.Controls.Add(Me.Label_MinValue)
        Me.GroupBox_PinProps.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_PinProps.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox_PinProps.Location = New System.Drawing.Point(439, 209)
        Me.GroupBox_PinProps.Name = "GroupBox_PinProps"
        Me.GroupBox_PinProps.Size = New System.Drawing.Size(180, 136)
        Me.GroupBox_PinProps.TabIndex = 138
        Me.GroupBox_PinProps.TabStop = False
        Me.GroupBox_PinProps.Text = "Pin properties"
        Me.GroupBox_PinProps.Visible = False
        '
        'Label_ResponseSpeed
        '
        Me.Label_ResponseSpeed.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Label_ResponseSpeed.CenterPtTracker = DesignerRectTracker3
        Me.Label_ResponseSpeed.CheckButton = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.Label_ResponseSpeed.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.Label_ResponseSpeed.ColorFillBlendChecked = CBlendItems4
        Me.Label_ResponseSpeed.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.Label_ResponseSpeed.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.Label_ResponseSpeed.Corners.All = CType(3, Short)
        Me.Label_ResponseSpeed.Corners.LowerLeft = CType(3, Short)
        Me.Label_ResponseSpeed.Corners.LowerRight = CType(3, Short)
        Me.Label_ResponseSpeed.Corners.UpperLeft = CType(3, Short)
        Me.Label_ResponseSpeed.Corners.UpperRight = CType(3, Short)
        Me.Label_ResponseSpeed.DimFactorGray = -10
        Me.Label_ResponseSpeed.DimFactorOver = 30
        Me.Label_ResponseSpeed.FillType = Theremino_ArduHAL.MyButton.eFillType.LinearVertical
        Me.Label_ResponseSpeed.FillTypeChecked = Theremino_ArduHAL.MyButton.eFillType.LinearVertical
        Me.Label_ResponseSpeed.FocalPoints.CenterPtX = 0.0!
        Me.Label_ResponseSpeed.FocalPoints.CenterPtY = 0.4074074!
        Me.Label_ResponseSpeed.FocalPoints.FocusPtX = 0.0!
        Me.Label_ResponseSpeed.FocalPoints.FocusPtY = 0.0!
        Me.Label_ResponseSpeed.FocalPointsChecked.CenterPtX = 0.5925926!
        Me.Label_ResponseSpeed.FocalPointsChecked.CenterPtY = 0.2352941!
        Me.Label_ResponseSpeed.FocalPointsChecked.FocusPtX = 0.0!
        Me.Label_ResponseSpeed.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.Label_ResponseSpeed.FocusPtTracker = DesignerRectTracker4
        Me.Label_ResponseSpeed.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResponseSpeed.ForeColorChecked = System.Drawing.Color.Black
        Me.Label_ResponseSpeed.Image = Nothing
        Me.Label_ResponseSpeed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label_ResponseSpeed.ImageIndex = 0
        Me.Label_ResponseSpeed.ImageSize = New System.Drawing.Size(16, 16)
        Me.Label_ResponseSpeed.Location = New System.Drawing.Point(7, 112)
        Me.Label_ResponseSpeed.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Label_ResponseSpeed.Name = "Label_ResponseSpeed"
        Me.Label_ResponseSpeed.Shape = Theremino_ArduHAL.MyButton.eShape.Rectangle
        Me.Label_ResponseSpeed.SideImage = Nothing
        Me.Label_ResponseSpeed.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label_ResponseSpeed.SideImageSize = New System.Drawing.Size(32, 32)
        Me.Label_ResponseSpeed.Size = New System.Drawing.Size(108, 15)
        Me.Label_ResponseSpeed.TabIndex = 220
        Me.Label_ResponseSpeed.Text = "Response speed"
        Me.Label_ResponseSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label_ResponseSpeed.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.Label_ResponseSpeed.TextMargin = New System.Windows.Forms.Padding(0)
        Me.Label_ResponseSpeed.TextShadow = System.Drawing.Color.Transparent
        Me.Label_ResponseSpeed.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_Slot
        '
        Me.txt_Slot.ArrowsIncrement = 1
        Me.txt_Slot.BackColor = System.Drawing.Color.MintCream
        Me.txt_Slot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Slot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Slot.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Slot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Slot.ForeColor = System.Drawing.Color.Black
        Me.txt_Slot.Increment = 0.2
        Me.txt_Slot.Location = New System.Drawing.Point(118, 49)
        Me.txt_Slot.MaxValue = 999
        Me.txt_Slot.MinValue = 0
        Me.txt_Slot.Name = "txt_Slot"
        Me.txt_Slot.NumericValue = 0
        Me.txt_Slot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Slot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Slot.RoundingStep = 0
        Me.txt_Slot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Slot.Size = New System.Drawing.Size(51, 15)
        Me.txt_Slot.SuppressZeros = True
        Me.txt_Slot.TabIndex = 11
        Me.txt_Slot.Text = "0"
        Me.txt_Slot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmb_PinType
        '
        Me.cmb_PinType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_PinType.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_PinType.BackColor = System.Drawing.Color.MintCream
        Me.cmb_PinType.BackColor_Focused = System.Drawing.Color.MintCream
        Me.cmb_PinType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.cmb_PinType.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_PinType.BorderSize = 1
        Me.cmb_PinType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_PinType.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_PinType.DropDown_BackSelected = System.Drawing.Color.LightBlue
        Me.cmb_PinType.DropDown_BorderColor = System.Drawing.Color.Gainsboro
        Me.cmb_PinType.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_PinType.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_PinType.DropDownHeight = 500
        Me.cmb_PinType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_PinType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_PinType.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_PinType.ForeColor = System.Drawing.Color.Black
        Me.cmb_PinType.IntegralHeight = False
        Me.cmb_PinType.ItemHeight = 12
        Me.cmb_PinType.Location = New System.Drawing.Point(70, 22)
        Me.cmb_PinType.Name = "cmb_PinType"
        Me.cmb_PinType.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_PinType.Size = New System.Drawing.Size(99, 18)
        Me.cmb_PinType.TabIndex = 10
        Me.cmb_PinType.TabStop = False
        Me.cmb_PinType.TextPosition = 1
        '
        'Label_PinType
        '
        Me.Label_PinType.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_PinType.Location = New System.Drawing.Point(10, 24)
        Me.Label_PinType.Name = "Label_PinType"
        Me.Label_PinType.Size = New System.Drawing.Size(58, 13)
        Me.Label_PinType.TabIndex = 172
        Me.Label_PinType.Text = "Pin type"
        Me.Label_PinType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_MaxValue
        '
        Me.txt_MaxValue.ArrowsIncrement = 1
        Me.txt_MaxValue.BackColor = System.Drawing.Color.MintCream
        Me.txt_MaxValue.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxValue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxValue.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_MaxValue.Decimals = 3
        Me.txt_MaxValue.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxValue.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxValue.Increment = 0.2
        Me.txt_MaxValue.Location = New System.Drawing.Point(113, 70)
        Me.txt_MaxValue.MaxValue = 16777216
        Me.txt_MaxValue.MinValue = -16777216
        Me.txt_MaxValue.Name = "txt_MaxValue"
        Me.txt_MaxValue.NumericValue = 1000
        Me.txt_MaxValue.NumericValueInteger = 1000
        Me.txt_MaxValue.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxValue.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxValue.RoundingStep = 0
        Me.txt_MaxValue.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxValue.Size = New System.Drawing.Size(56, 15)
        Me.txt_MaxValue.SuppressZeros = True
        Me.txt_MaxValue.TabIndex = 12
        Me.txt_MaxValue.Text = "1000"
        Me.txt_MaxValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_ResponseSpeed
        '
        Me.txt_ResponseSpeed.ArrowsIncrement = 1
        Me.txt_ResponseSpeed.BackColor = System.Drawing.Color.MintCream
        Me.txt_ResponseSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ResponseSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ResponseSpeed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ResponseSpeed.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ResponseSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_ResponseSpeed.Increment = 0.2
        Me.txt_ResponseSpeed.Location = New System.Drawing.Point(118, 112)
        Me.txt_ResponseSpeed.MaxValue = 100
        Me.txt_ResponseSpeed.MinValue = 1
        Me.txt_ResponseSpeed.Name = "txt_ResponseSpeed"
        Me.txt_ResponseSpeed.NumericValue = 30
        Me.txt_ResponseSpeed.NumericValueInteger = 30
        Me.txt_ResponseSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ResponseSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ResponseSpeed.RoundingStep = 0
        Me.txt_ResponseSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ResponseSpeed.Size = New System.Drawing.Size(51, 15)
        Me.txt_ResponseSpeed.SuppressZeros = True
        Me.txt_ResponseSpeed.TabIndex = 14
        Me.txt_ResponseSpeed.Text = "30"
        Me.txt_ResponseSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_MinValue
        '
        Me.txt_MinValue.ArrowsIncrement = 1
        Me.txt_MinValue.BackColor = System.Drawing.Color.MintCream
        Me.txt_MinValue.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinValue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinValue.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_MinValue.Decimals = 3
        Me.txt_MinValue.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinValue.ForeColor = System.Drawing.Color.Black
        Me.txt_MinValue.Increment = 0.2
        Me.txt_MinValue.Location = New System.Drawing.Point(113, 91)
        Me.txt_MinValue.MaxValue = 9999999
        Me.txt_MinValue.MinValue = -999999
        Me.txt_MinValue.Name = "txt_MinValue"
        Me.txt_MinValue.NumericValue = 0
        Me.txt_MinValue.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinValue.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinValue.RoundingStep = 0
        Me.txt_MinValue.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinValue.Size = New System.Drawing.Size(56, 15)
        Me.txt_MinValue.SuppressZeros = True
        Me.txt_MinValue.TabIndex = 13
        Me.txt_MinValue.Text = "0"
        Me.txt_MinValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Timer_1Hz
        '
        '
        'GroupBox_ServoPwmProps
        '
        Me.GroupBox_ServoPwmProps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_ServoPwmProps.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_ServoPwmProps.Controls.Add(Me.chk_LogResponse)
        Me.GroupBox_ServoPwmProps.Controls.Add(Me.txt_ServoMaxTime)
        Me.GroupBox_ServoPwmProps.Controls.Add(Me.Label_MinTime)
        Me.GroupBox_ServoPwmProps.Controls.Add(Me.txt_ServoMinTime)
        Me.GroupBox_ServoPwmProps.Controls.Add(Me.Label_MaxTime)
        Me.GroupBox_ServoPwmProps.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ServoPwmProps.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox_ServoPwmProps.Location = New System.Drawing.Point(439, 351)
        Me.GroupBox_ServoPwmProps.Name = "GroupBox_ServoPwmProps"
        Me.GroupBox_ServoPwmProps.Size = New System.Drawing.Size(180, 92)
        Me.GroupBox_ServoPwmProps.TabIndex = 177
        Me.GroupBox_ServoPwmProps.TabStop = False
        Me.GroupBox_ServoPwmProps.Text = "Servo properties"
        Me.GroupBox_ServoPwmProps.Visible = False
        '
        'chk_LogResponse
        '
        Me.chk_LogResponse.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_LogResponse.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_LogResponse.Location = New System.Drawing.Point(10, 69)
        Me.chk_LogResponse.Name = "chk_LogResponse"
        Me.chk_LogResponse.Size = New System.Drawing.Size(156, 17)
        Me.chk_LogResponse.TabIndex = 165
        Me.chk_LogResponse.Text = "Logarithmic response  "
        Me.chk_LogResponse.UseVisualStyleBackColor = True
        '
        'txt_ServoMaxTime
        '
        Me.txt_ServoMaxTime.ArrowsIncrement = 1
        Me.txt_ServoMaxTime.BackColor = System.Drawing.Color.MintCream
        Me.txt_ServoMaxTime.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ServoMaxTime.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ServoMaxTime.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ServoMaxTime.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ServoMaxTime.ForeColor = System.Drawing.Color.Black
        Me.txt_ServoMaxTime.Increment = 0.2
        Me.txt_ServoMaxTime.Location = New System.Drawing.Point(119, 25)
        Me.txt_ServoMaxTime.MaxValue = 4000
        Me.txt_ServoMaxTime.MinValue = 0
        Me.txt_ServoMaxTime.Name = "txt_ServoMaxTime"
        Me.txt_ServoMaxTime.NumericValue = 2500
        Me.txt_ServoMaxTime.NumericValueInteger = 2500
        Me.txt_ServoMaxTime.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ServoMaxTime.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ServoMaxTime.RoundingStep = 0
        Me.txt_ServoMaxTime.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ServoMaxTime.Size = New System.Drawing.Size(51, 15)
        Me.txt_ServoMaxTime.SuppressZeros = True
        Me.txt_ServoMaxTime.TabIndex = 19
        Me.txt_ServoMaxTime.Text = "2500"
        Me.txt_ServoMaxTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_MinTime
        '
        Me.Label_MinTime.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MinTime.Location = New System.Drawing.Point(10, 47)
        Me.Label_MinTime.Name = "Label_MinTime"
        Me.Label_MinTime.Size = New System.Drawing.Size(106, 13)
        Me.Label_MinTime.TabIndex = 163
        Me.Label_MinTime.Text = "Min time  ( uS )"
        Me.Label_MinTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_ServoMinTime
        '
        Me.txt_ServoMinTime.ArrowsIncrement = 1
        Me.txt_ServoMinTime.BackColor = System.Drawing.Color.MintCream
        Me.txt_ServoMinTime.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ServoMinTime.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ServoMinTime.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_ServoMinTime.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ServoMinTime.ForeColor = System.Drawing.Color.Black
        Me.txt_ServoMinTime.Increment = 0.2
        Me.txt_ServoMinTime.Location = New System.Drawing.Point(119, 46)
        Me.txt_ServoMinTime.MaxValue = 4000
        Me.txt_ServoMinTime.MinValue = 0
        Me.txt_ServoMinTime.Name = "txt_ServoMinTime"
        Me.txt_ServoMinTime.NumericValue = 500
        Me.txt_ServoMinTime.NumericValueInteger = 500
        Me.txt_ServoMinTime.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ServoMinTime.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ServoMinTime.RoundingStep = 0
        Me.txt_ServoMinTime.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ServoMinTime.Size = New System.Drawing.Size(51, 15)
        Me.txt_ServoMinTime.SuppressZeros = True
        Me.txt_ServoMinTime.TabIndex = 20
        Me.txt_ServoMinTime.Text = "500"
        Me.txt_ServoMinTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_MaxTime
        '
        Me.Label_MaxTime.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxTime.Location = New System.Drawing.Point(10, 26)
        Me.Label_MaxTime.Name = "Label_MaxTime"
        Me.Label_MaxTime.Size = New System.Drawing.Size(106, 13)
        Me.Label_MaxTime.TabIndex = 161
        Me.Label_MaxTime.Text = "Max time ( uS )"
        Me.Label_MaxTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox_FrequencyProps
        '
        Me.GroupBox_FrequencyProps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_FrequencyProps.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox_FrequencyProps.Controls.Add(Me.chk_ConvertToFrequency)
        Me.GroupBox_FrequencyProps.Controls.Add(Me.txt_MaxFreq)
        Me.GroupBox_FrequencyProps.Controls.Add(Me.Label14)
        Me.GroupBox_FrequencyProps.Controls.Add(Me.txt_MinFreq)
        Me.GroupBox_FrequencyProps.Controls.Add(Me.Label_MaxFreq)
        Me.GroupBox_FrequencyProps.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_FrequencyProps.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox_FrequencyProps.Location = New System.Drawing.Point(226, 339)
        Me.GroupBox_FrequencyProps.Name = "GroupBox_FrequencyProps"
        Me.GroupBox_FrequencyProps.Size = New System.Drawing.Size(180, 86)
        Me.GroupBox_FrequencyProps.TabIndex = 178
        Me.GroupBox_FrequencyProps.TabStop = False
        Me.GroupBox_FrequencyProps.Text = "Freq. properties"
        Me.GroupBox_FrequencyProps.Visible = False
        '
        'chk_ConvertToFrequency
        '
        Me.chk_ConvertToFrequency.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ConvertToFrequency.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ConvertToFrequency.Location = New System.Drawing.Point(10, 20)
        Me.chk_ConvertToFrequency.Name = "chk_ConvertToFrequency"
        Me.chk_ConvertToFrequency.Size = New System.Drawing.Size(156, 17)
        Me.chk_ConvertToFrequency.TabIndex = 164
        Me.chk_ConvertToFrequency.Text = "Convert to frequency  "
        Me.chk_ConvertToFrequency.UseVisualStyleBackColor = True
        '
        'txt_MaxFreq
        '
        Me.txt_MaxFreq.ArrowsIncrement = 1
        Me.txt_MaxFreq.BackColor = System.Drawing.Color.MintCream
        Me.txt_MaxFreq.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxFreq.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxFreq.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_MaxFreq.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxFreq.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxFreq.Increment = 0.2
        Me.txt_MaxFreq.Location = New System.Drawing.Point(107, 43)
        Me.txt_MaxFreq.MaxValue = 50000000
        Me.txt_MaxFreq.MinValue = 1
        Me.txt_MaxFreq.Name = "txt_MaxFreq"
        Me.txt_MaxFreq.NumericValue = 1000
        Me.txt_MaxFreq.NumericValueInteger = 1000
        Me.txt_MaxFreq.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxFreq.RoundingStep = 0
        Me.txt_MaxFreq.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxFreq.Size = New System.Drawing.Size(67, 15)
        Me.txt_MaxFreq.SuppressZeros = True
        Me.txt_MaxFreq.TabIndex = 22
        Me.txt_MaxFreq.Text = "1000"
        Me.txt_MaxFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(10, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(96, 13)
        Me.Label14.TabIndex = 163
        Me.Label14.Text = "Min freq ( Hz )"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_MinFreq
        '
        Me.txt_MinFreq.ArrowsIncrement = 1
        Me.txt_MinFreq.BackColor = System.Drawing.Color.MintCream
        Me.txt_MinFreq.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinFreq.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinFreq.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_MinFreq.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinFreq.ForeColor = System.Drawing.Color.Black
        Me.txt_MinFreq.Increment = 0.2
        Me.txt_MinFreq.Location = New System.Drawing.Point(107, 63)
        Me.txt_MinFreq.MaxValue = 50000000
        Me.txt_MinFreq.MinValue = 0
        Me.txt_MinFreq.Name = "txt_MinFreq"
        Me.txt_MinFreq.NumericValue = 0
        Me.txt_MinFreq.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinFreq.RoundingStep = 0
        Me.txt_MinFreq.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinFreq.Size = New System.Drawing.Size(67, 15)
        Me.txt_MinFreq.SuppressZeros = True
        Me.txt_MinFreq.TabIndex = 23
        Me.txt_MinFreq.Text = "0"
        Me.txt_MinFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_MaxFreq
        '
        Me.Label_MaxFreq.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxFreq.Location = New System.Drawing.Point(10, 44)
        Me.Label_MaxFreq.Name = "Label_MaxFreq"
        Me.Label_MaxFreq.Size = New System.Drawing.Size(96, 13)
        Me.Label_MaxFreq.TabIndex = 161
        Me.Label_MaxFreq.Text = "Max freq ( Hz )"
        Me.Label_MaxFreq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_Recognize, Me.ToolStripSeparator11, Me.ToolStripButton_Validate, Me.ToolStripSeparator3, Me.ToolStripButton_BeepOnErrors, Me.ToolStripSeparator8, Me.ToolStripButton_CommOptions, Me.ToolStripSeparator5, Me.ToolStripButton_Disconnect})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(624, 25)
        Me.ToolStrip1.TabIndex = 219
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_Recognize
        '
        Me.ToolStripButton_Recognize.CheckOnClick = True
        Me.ToolStripButton_Recognize.Image = CType(resources.GetObject("ToolStripButton_Recognize.Image"), System.Drawing.Image)
        Me.ToolStripButton_Recognize.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Recognize.Name = "ToolStripButton_Recognize"
        Me.ToolStripButton_Recognize.Size = New System.Drawing.Size(81, 22)
        Me.ToolStripButton_Recognize.Text = "Recognize"
        Me.ToolStripButton_Recognize.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_Validate
        '
        Me.ToolStripButton_Validate.CheckOnClick = True
        Me.ToolStripButton_Validate.Image = CType(resources.GetObject("ToolStripButton_Validate.Image"), System.Drawing.Image)
        Me.ToolStripButton_Validate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Validate.Name = "ToolStripButton_Validate"
        Me.ToolStripButton_Validate.Size = New System.Drawing.Size(68, 22)
        Me.ToolStripButton_Validate.Text = "Validate"
        Me.ToolStripButton_Validate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_BeepOnErrors
        '
        Me.ToolStripButton_BeepOnErrors.CheckOnClick = True
        Me.ToolStripButton_BeepOnErrors.Image = CType(resources.GetObject("ToolStripButton_BeepOnErrors.Image"), System.Drawing.Image)
        Me.ToolStripButton_BeepOnErrors.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_BeepOnErrors.Name = "ToolStripButton_BeepOnErrors"
        Me.ToolStripButton_BeepOnErrors.Size = New System.Drawing.Size(81, 22)
        Me.ToolStripButton_BeepOnErrors.Text = "Error beep"
        Me.ToolStripButton_BeepOnErrors.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_CommOptions
        '
        Me.ToolStripButton_CommOptions.CheckOnClick = True
        Me.ToolStripButton_CommOptions.Image = CType(resources.GetObject("ToolStripButton_CommOptions.Image"), System.Drawing.Image)
        Me.ToolStripButton_CommOptions.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_CommOptions.Name = "ToolStripButton_CommOptions"
        Me.ToolStripButton_CommOptions.Size = New System.Drawing.Size(157, 22)
        Me.ToolStripButton_CommOptions.Text = "Communication options"
        Me.ToolStripButton_CommOptions.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_Disconnect
        '
        Me.ToolStripButton_Disconnect.CheckOnClick = True
        Me.ToolStripButton_Disconnect.Image = CType(resources.GetObject("ToolStripButton_Disconnect.Image"), System.Drawing.Image)
        Me.ToolStripButton_Disconnect.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Disconnect.Name = "ToolStripButton_Disconnect"
        Me.ToolStripButton_Disconnect.Size = New System.Drawing.Size(130, 22)
        Me.ToolStripButton_Disconnect.Text = "Disconnect Module"
        Me.ToolStripButton_Disconnect.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tools, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(624, 24)
        Me.MenuStrip1.TabIndex = 218
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_OpenProgramFolder, Me.Menu_File_EditSlotNames, Me.Menu_File_EditConfigurations, Me.Menu_File_EditCommOptions, Me.ToolStripSeparator1, Me.Menu_File_BackupConfigurations, Me.Menu_File_LoadConfigurations, Me.ToolStripSeparator4, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_OpenProgramFolder
        '
        Me.Menu_File_OpenProgramFolder.Image = CType(resources.GetObject("Menu_File_OpenProgramFolder.Image"), System.Drawing.Image)
        Me.Menu_File_OpenProgramFolder.Name = "Menu_File_OpenProgramFolder"
        Me.Menu_File_OpenProgramFolder.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_OpenProgramFolder.Text = "Open program folder"
        '
        'Menu_File_EditSlotNames
        '
        Me.Menu_File_EditSlotNames.Image = CType(resources.GetObject("Menu_File_EditSlotNames.Image"), System.Drawing.Image)
        Me.Menu_File_EditSlotNames.Name = "Menu_File_EditSlotNames"
        Me.Menu_File_EditSlotNames.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_EditSlotNames.Text = "Edit SlotNames"
        '
        'Menu_File_EditConfigurations
        '
        Me.Menu_File_EditConfigurations.Image = CType(resources.GetObject("Menu_File_EditConfigurations.Image"), System.Drawing.Image)
        Me.Menu_File_EditConfigurations.Name = "Menu_File_EditConfigurations"
        Me.Menu_File_EditConfigurations.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_EditConfigurations.Text = "Edit configurations"
        '
        'Menu_File_EditCommOptions
        '
        Me.Menu_File_EditCommOptions.Image = CType(resources.GetObject("Menu_File_EditCommOptions.Image"), System.Drawing.Image)
        Me.Menu_File_EditCommOptions.Name = "Menu_File_EditCommOptions"
        Me.Menu_File_EditCommOptions.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_EditCommOptions.Text = "Edit the communication options file"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(282, 6)
        '
        'Menu_File_BackupConfigurations
        '
        Me.Menu_File_BackupConfigurations.Image = CType(resources.GetObject("Menu_File_BackupConfigurations.Image"), System.Drawing.Image)
        Me.Menu_File_BackupConfigurations.Name = "Menu_File_BackupConfigurations"
        Me.Menu_File_BackupConfigurations.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_BackupConfigurations.Text = "Save configurations to backup folder"
        '
        'Menu_File_LoadConfigurations
        '
        Me.Menu_File_LoadConfigurations.Image = CType(resources.GetObject("Menu_File_LoadConfigurations.Image"), System.Drawing.Image)
        Me.Menu_File_LoadConfigurations.Name = "Menu_File_LoadConfigurations"
        Me.Menu_File_LoadConfigurations.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_LoadConfigurations.Text = "Load configurations from backup folder"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(282, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Image = CType(resources.GetObject("Menu_File_Exit.Image"), System.Drawing.Image)
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(285, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tools
        '
        Me.Menu_Tools.Enabled = False
        Me.Menu_Tools.Name = "Menu_Tools"
        Me.Menu_Tools.Size = New System.Drawing.Size(47, 20)
        Me.Menu_Tools.Text = "Tools"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_English, Me.Menu_Language_Italian, Me.Menu_Language_Francais, Me.Menu_Language_Espanol, Me.Menu_Language_Portoguese, Me.Menu_Language_Deutsch, Me.Menu_Language_Japanese, Me.Menu_Language_Chinese})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_English
        '
        Me.Menu_Language_English.Image = CType(resources.GetObject("Menu_Language_English.Image"), System.Drawing.Image)
        Me.Menu_Language_English.Name = "Menu_Language_English"
        Me.Menu_Language_English.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_English.Text = "English"
        '
        'Menu_Language_Italian
        '
        Me.Menu_Language_Italian.Image = CType(resources.GetObject("Menu_Language_Italian.Image"), System.Drawing.Image)
        Me.Menu_Language_Italian.Name = "Menu_Language_Italian"
        Me.Menu_Language_Italian.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Italian.Text = "Italiano"
        '
        'Menu_Language_Francais
        '
        Me.Menu_Language_Francais.Image = CType(resources.GetObject("Menu_Language_Francais.Image"), System.Drawing.Image)
        Me.Menu_Language_Francais.Name = "Menu_Language_Francais"
        Me.Menu_Language_Francais.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Francais.Text = "Francais"
        '
        'Menu_Language_Espanol
        '
        Me.Menu_Language_Espanol.Image = CType(resources.GetObject("Menu_Language_Espanol.Image"), System.Drawing.Image)
        Me.Menu_Language_Espanol.Name = "Menu_Language_Espanol"
        Me.Menu_Language_Espanol.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Espanol.Text = "Espanol"
        '
        'Menu_Language_Portoguese
        '
        Me.Menu_Language_Portoguese.Image = CType(resources.GetObject("Menu_Language_Portoguese.Image"), System.Drawing.Image)
        Me.Menu_Language_Portoguese.Name = "Menu_Language_Portoguese"
        Me.Menu_Language_Portoguese.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Portoguese.Text = "Portoguese"
        '
        'Menu_Language_Deutsch
        '
        Me.Menu_Language_Deutsch.Image = CType(resources.GetObject("Menu_Language_Deutsch.Image"), System.Drawing.Image)
        Me.Menu_Language_Deutsch.Name = "Menu_Language_Deutsch"
        Me.Menu_Language_Deutsch.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Deutsch.Text = "Deutsch"
        '
        'Menu_Language_Japanese
        '
        Me.Menu_Language_Japanese.Image = CType(resources.GetObject("Menu_Language_Japanese.Image"), System.Drawing.Image)
        Me.Menu_Language_Japanese.Name = "Menu_Language_Japanese"
        Me.Menu_Language_Japanese.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Japanese.Text = "Japanese"
        '
        'Menu_Language_Chinese
        '
        Me.Menu_Language_Chinese.Image = CType(resources.GetObject("Menu_Language_Chinese.Image"), System.Drawing.Image)
        Me.Menu_Language_Chinese.Name = "Menu_Language_Chinese"
        Me.Menu_Language_Chinese.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_Chinese.Text = "Chinese"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(146, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program help"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'Timer_60Hz
        '
        Me.Timer_60Hz.Interval = 10
        '
        'MyListView1
        '
        Me.MyListView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MyListView1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MyListView1.Location = New System.Drawing.Point(4, 52)
        Me.MyListView1.MultiSelect = False
        Me.MyListView1.Name = "MyListView1"
        Me.MyListView1.ShowGroups = False
        Me.MyListView1.Size = New System.Drawing.Size(430, 394)
        Me.MyListView1.TabIndex = 100
        Me.MyListView1.TabStop = False
        Me.MyListView1.UseCompatibleStateImageBehavior = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(624, 449)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox_FrequencyProps)
        Me.Controls.Add(Me.GroupBox_ServoPwmProps)
        Me.Controls.Add(Me.MyListView1)
        Me.Controls.Add(Me.GroupBox_PinProps)
        Me.Controls.Add(Me.GroupBox_ModuleProps)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(640, 488)
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino HAL"
        Me.GroupBox_ModuleProps.ResumeLayout(False)
        Me.GroupBox_ModuleProps.PerformLayout()
        Me.GroupBox_PinProps.ResumeLayout(False)
        Me.GroupBox_PinProps.PerformLayout()
        Me.GroupBox_ServoPwmProps.ResumeLayout(False)
        Me.GroupBox_ServoPwmProps.PerformLayout()
        Me.GroupBox_FrequencyProps.ResumeLayout(False)
        Me.GroupBox_FrequencyProps.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer_10Hz As System.Windows.Forms.Timer
    Friend WithEvents GroupBox_ModuleProps As System.Windows.Forms.GroupBox
    Friend WithEvents txt_CommSpeed As MyTextBox
    Friend WithEvents Label_CommSpeed As System.Windows.Forms.Label
    Friend WithEvents txt_ResponseSpeed As MyTextBox
    Friend WithEvents txt_MinValue As MyTextBox
    Friend WithEvents Label_MinValue As System.Windows.Forms.Label
    Friend WithEvents txt_MaxValue As MyTextBox
    Friend WithEvents Label_MaxValue As System.Windows.Forms.Label
    Friend WithEvents MyListView1 As ListViewFlickerFree
    Friend WithEvents GroupBox_PinProps As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_PinType As MyComboBox
    Friend WithEvents Label_PinType As System.Windows.Forms.Label
    Friend WithEvents txt_Slot As MyTextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Timer_1Hz As System.Windows.Forms.Timer
    Friend WithEvents GroupBox_ServoPwmProps As System.Windows.Forms.GroupBox
    Friend WithEvents txt_ServoMaxTime As MyTextBox
    Friend WithEvents Label_MinTime As System.Windows.Forms.Label
    Friend WithEvents txt_ServoMinTime As MyTextBox
    Friend WithEvents Label_MaxTime As System.Windows.Forms.Label
    Friend WithEvents GroupBox_FrequencyProps As System.Windows.Forms.GroupBox
    Friend WithEvents txt_MaxFreq As MyTextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txt_MinFreq As MyTextBox
    Friend WithEvents Label_MaxFreq As System.Windows.Forms.Label
    Friend WithEvents Label_RepFreq As System.Windows.Forms.Label
    Friend WithEvents lbl_ErrorRate As System.Windows.Forms.Label
    Friend WithEvents Label_ErrorRate As System.Windows.Forms.Label
    Friend WithEvents lbl_RepeatFrequency As System.Windows.Forms.Label
    Friend WithEvents chk_ConvertToFrequency As System.Windows.Forms.CheckBox
    Friend WithEvents chk_LogResponse As System.Windows.Forms.CheckBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_Recognize As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton_Validate As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton_BeepOnErrors As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_EditConfigurations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmb_ModuleNames As MyComboBox
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_English As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Italian As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Francais As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Espanol As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Deutsch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Japanese As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_CommOptions As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer_60Hz As System.Windows.Forms.Timer
    Friend WithEvents Menu_File_EditSlotNames As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_BackupConfigurations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_LoadConfigurations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_EditCommOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_Disconnect As System.Windows.Forms.ToolStripButton
    Friend WithEvents chk_PollingMode As System.Windows.Forms.CheckBox
    Friend WithEvents chk_AsyncMode As System.Windows.Forms.CheckBox
    Friend WithEvents Menu_Language_Chinese As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Portoguese As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents btn_ModuleName As Theremino_ArduHAL.MyButton
    Private WithEvents Label_ResponseSpeed As Theremino_ArduHAL.MyButton
End Class
