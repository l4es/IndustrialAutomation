﻿
' TODO - MAIN LIST 
' -------------------------------------------------------------
' 

' DONE - MAIN LIST
' -------------------------------------------------------------
' Version 1.4 
' - PollingMode for FT232
' - Easy AsyncMode control with a checkbox in the ArduHal app 

' -------------------------------------------------------------
'  Comm. Callback(multithread) or Polling(single thread) 
' -------------------------------------------------------------
'  CH340 - AsyncMode_OFF - Callback - All unused  - 398 FPS
'  CH340 - AsyncMode_OFF - Callback - 8Adc_8Servo - 203 FPS
'  CH340 - AsyncMode_ON  - Callback - All unused  - 253 FPS
'  CH340 - AsyncMode_ON  - Callback - 8Adc_8Servo - 171 FPS

'  CH340 - AsyncMode_OFF - Polling  - All unused  - 236 FPS
'  CH340 - AsyncMode_OFF - Polling  - 8Adc_8Servo - 158 FPS
'  CH340 - AsyncMode_ON  - Polling  - All unused  - 175 FPS
'  CH340 - AsyncMode_ON  - Polling  - 8Adc_8Servo - 132 FPS

'  FT232 - AsyncMode_OFF - Callback - All unused  - ERRORS
'  FT232 - AsyncMode_OFF - Callback - 8Adc_8Servo - ERRORS
'  FT232 - AsyncMode_ON  - Callback - All unused  - ERRORS
'  FT232 - AsyncMode_ON  - Callback - 8Adc_8Servo - ERRORS

'  FT232 - AsyncMode_OFF - Polling  - All unused  - 257 FPS
'  FT232 - AsyncMode_OFF - Polling  - 8Adc_8Servo - 191 FPS
'  FT232 - AsyncMode_ON  - Polling  - All unused  - 182 FPS
'  FT232 - AsyncMode_ON  - Polling  - 8Adc_8Servo - 157 FPS


' -------------------------------------------------------------
'  Slot zero commands
' -------------------------------------------------------------
' Send 333, wait 50mS, send 666, wait 50 mS, send command
' Command 1 = Recognize
' Command 2 = Calibrate



Public Class Form1

    Private EventsLock As Object = New Object

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SchedulerMaxPrecision()
        Load_INI()
        Load_ConfigDatabase()
        LoadCommOptions()
        SetLocales()
        ToolTips_Init()
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------------------- REAL-TIME
        System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Normal
        System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime
        ' ---------------------------------------------------------------- Init and recognize MODULES
        TheSystem_InitModules()
        TheSystem_AssignConfigurationToModules()
        TheSystem_StartTimers()
        ' ---------------------------------------------------------------- Timer1 = 100mS = 10Hz 
        Timer_10Hz.Interval = 100
        Timer_10Hz.Start()
        ' ---------------------------------------------------------------- Timer_1Hz = 1000mS = 1Hz
        Timer_1Hz.Interval = 1000
        Timer_1Hz.Start()
        ' ---------------------------------------------------------------- Timer_60Hz = 16.6mS = 60Hz
        Timer_60Hz.Interval = 10
        Timer_60Hz.Start()
        ' ---------------------------------------------------------------- WINDOW
        If Not OperatingSystemIsWindows Then
            Me.MinimumSize = New Size(650, 500)
        End If
        If Not ConfigurationIsValid Then
            WindowState = FormWindowState.Normal
        End If
        If Form2_VisibleAtStart Then
            Form2.Show()
        Else
            Form2.Visible = False
        End If
        Text = AppTitleAndVersion("Theremino ArduHAL")
        ' ----------------------------------------------------------------
        EventsAreEnabled = True
        ' ----------------------------------------------------------------
        ListView_SelectLine(MyListView1, 0)
        ShowProps()
        Form2.RestoreSelectedPins()

        EventsAreEnabled = False
        MyListView1.Focus()
        ShowInTaskbar = False
        ShowInTaskbar = True
        EventsAreEnabled = True

        Refresh()
        Form2.Refresh()
        Me.Opacity = 1
        Form2.Opacity = 1

        InvalidConfigMessage()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Return
        CloseAllAndExit()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub CloseAllAndExit()
        TheSystem_StopTimers()
        TheSystem_SetParkingPositions()
        TheSystem_UpdateAndSaveConfigDatabase()
        Save_INI()
        SchedulerDefaultPrecision()
    End Sub

    Private Sub InvalidConfigMessage()
        If ConfigurationIsValid = False Then
            If DuplicateNames Then
                MessageBox.Show(Msg_Warning + vbCrLf + vbCrLf + _
                                Msg_Duplicate1 + vbCrLf + vbCrLf + _
                                Msg_Duplicate2, _
                                Msg_HalMessage, _
                                MessageBoxButtons.OK)
            Else
                MessageBox.Show(Msg_Warning + vbCrLf + vbCrLf + _
                    Msg_Validate2 + vbCrLf + vbCrLf + _
                    Msg_Validate3 + vbCrLf + vbCrLf + _
                    Msg_Validate4 + vbCrLf + vbCrLf + _
                    Msg_Validate5, _
                    Msg_HalMessage, _
                    MessageBoxButtons.OK)
            End If
        End If
    End Sub


    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    <DebuggerStepThrough()> _
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub

    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(240, 240, 240), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer

        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_OpenProgramFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_OpenProgramFolder.Click
        Process.Start(Application.StartupPath)
    End Sub
    Private Sub Menu_File_EditSlotNames_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_EditSlotNames.Click
        Me.Opacity = 0.7
        Dim fname As String = Application.StartupPath & "\SlotNames.txt"
        If Not FileExists(fname) Then IO.File.Create(fname)
        ProcessStartAndWait(PlatformAdjustedFileName(fname))
        Me.Opacity = 1
        TheSystem_ListComponents()
        ListView_SetAllLineColors()
    End Sub
    Private Sub Menu_File_EditConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_EditConfigurations.Click
        Me.Opacity = 0.7
        ProcessStartAndWait(PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_ConfigDatabase.txt"))
        Cmd_Recognize()
        Me.Opacity = 1
    End Sub
    Private Sub Menu_File_EditCommOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_EditCommOptions.Click
        Me.Opacity = 0.7
        Dim fname As String = Application.StartupPath & "\CommOptions.txt"
        If Not FileExists(fname) Then IO.File.Create(fname)
        ProcessStartAndWait(PlatformAdjustedFileName(fname))
        Me.Opacity = 1
        LoadCommOptions()
        Cmd_Recognize()
    End Sub
    Private BackupFolder As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\Theremino\HalBackups\"
    Private HalFolder As String = Application.StartupPath + "\"
    Private Sub Menu_File_BackupConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_BackupConfigurations.Click
        Dim DestFolder As String = BackupFolder + Date.Now.ToString("yyyy_MM_dd_HH_mm_ss") + "\"
        My.Computer.FileSystem.CreateDirectory(DestFolder)
        CopyFileIfExists(HalFolder, DestFolder, AssemblyName() & "_ConfigDatabase.txt")
        CopyFileIfExists(HalFolder, DestFolder, "SlotNames.txt")
        'CopyFileIfExists(HalFolder, DestFolder, "Theremino_HAL_INI.txt")
        'CopyFileIfExists(HalFolder, DestFolder, "Theremino_SlotViewer_INI.txt")
    End Sub
    Private Sub Menu_File_LoadConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_LoadConfigurations.Click
        Dim SourceFolder As String = SelectFolder(BackupFolder)
        If SourceFolder <> "" Then
            CopyFileIfExists(SourceFolder, HalFolder, AssemblyName() & "_ConfigDatabase.txt")
            CopyFileIfExists(SourceFolder, HalFolder, "SlotNames.txt")
            'CopyFileIfExists(SourceFolder, HalFolder, "Theremino_HAL_INI.txt")
            'CopyFileIfExists(SourceFolder, HalFolder, "Theremino_SlotViewer_INI.txt")
            TheSystem_AssignConfigurationToModules()
        End If
    End Sub

    Friend Sub CopyFileIfExists(ByVal srcFolder As String, ByVal destFolder As String, ByVal fileName As String)
        Dim src As String = srcFolder + fileName
        Dim dest As String = destFolder + fileName
        If IO.File.Exists(src) Then
            IO.File.Copy(src, dest, True)
        End If
    End Sub
    Friend Function SelectFolder(ByVal folder As String) As String
        Dim FBD As System.Windows.Forms.FolderBrowserDialog
        FBD = New System.Windows.Forms.FolderBrowserDialog()
        With FBD
            .Reset()
            .ShowNewFolderButton = False
            ' -- USE ROOTFOLDER TO LIMIT USER CHOOSE AREA -- ( No RootFolder NO limits )
            '.RootFolder = Environment.SpecialFolder.MyDocuments
            .RootFolder = Environment.SpecialFolder.MyComputer
            ' --------------------------------------------------------------------------
            .SelectedPath = folder
            .Description = vbCr & "Select the backup folder"
            SendKeys.Send("{TAB}{TAB}{RIGHT}")
            If .ShowDialog = DialogResult.OK Then
                Return .SelectedPath
            End If
        End With
        Return ""
    End Function

    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        CloseAllAndExit()
        Me.Close()
    End Sub


    ' =======================================================================================
    '   MENU LANGUAGE
    ' =======================================================================================
    Private Sub Menu_Language_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language.DropDownOpening
        For Each item As ToolStripMenuItem In Menu_Language.DropDownItems
            If item.Name.EndsWith(Language, StringComparison.InvariantCultureIgnoreCase) Then
                item.Select()
            End If
        Next
    End Sub
    Private Sub Menu_Language_Deutsch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Deutsch.Click
        Language = "Deutsch"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_English_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_English.Click
        Language = "English"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Espanol_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Espanol.Click
        Language = "Espanol"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Portoguese_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Portoguese.Click
        Language = "Portoguese"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Francais_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Francais.Click
        Language = "Francais"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Italian_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Italian.Click
        Language = "Italian"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Japanese_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Language_Japanese.Click
        Language = "Japanese"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub
    Private Sub Menu_Language_Chinese_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Language_Chinese.Click
        Language = "Chinese"
        SetLocales()
        Save_INI()
        ToolTips_Init()
        ShowProps()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_ENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        OpenLocalizedHelp("Theremino_ArduHAL_Help", ".pdf")
    End Sub
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")
        Dim LangName As String = Strings.Left(Language, 3).ToUpper.Replace("JAP", "JPN")
        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & LangName & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog()
    End Sub

    ' =======================================================================================
    '   TOOLBAR
    ' =======================================================================================
    Private Sub ToolStripButton_Recognize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Recognize.Click
        Cmd_Recognize()
        ToolStripButton_Recognize.Checked = False
    End Sub
    Private Sub ToolStripButton_Validate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Validate.Click
        Cmd_Validate()
        ToolStripButton_Validate.Checked = False
    End Sub
    Private Sub ToolStripButton_EditCommOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_CommOptions.Click
        Menu_File_EditCommOptions_Click(Nothing, Nothing)
        ToolStripButton_CommOptions.Checked = False
    End Sub
    Private Sub ToolStripButton_Disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Disconnect.Click
        Cmd_DisconnectSelectedModule()
        ToolStripButton_Disconnect.Checked = False
    End Sub

    'Private Sub ToolStripButton_EditConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Menu_File_EditConfigurations_Click(Nothing, Nothing)
    'End Sub
    'Private Sub ToolStripButton_EditSlotNames_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Menu_File_EditSlotNames_Click(Nothing, Nothing)
    'End Sub


    ' ===========================================================================================================
    '   Commands execution
    ' ===========================================================================================================
    Private Sub Cmd_Recognize()
        EventsAreEnabled = False
        Dim OldSelectedLine As Int32 = SelectedLine
        Load_ConfigDatabase()
        Timer_10Hz.Stop()
        TheSystem_StopTimers()
        TheSystem_InitModules()
        TheSystem_AssignConfigurationToModules()
        ShowProps()
        TheSystem_StartTimers()
        Timer_10Hz.Start()
        EventsAreEnabled = True
        If OldSelectedLine < 0 Then OldSelectedLine = 0
        ListView_SelectLine(MyListView1, OldSelectedLine)
        Form2.RestoreSelectedPins()
        ' ------------------------------------------ eventually show the message
        InvalidConfigMessage()
    End Sub
    Private Sub Cmd_Validate()
        If Not EventsAreEnabled Then Return
        EventsAreEnabled = False
        Dim OldSelectedLine As Int32 = SelectedLine
        TheSystem_ValidateConfiguration()
        TheSystem_UpdateAndSaveConfigDatabase()
        TheSystem_StartTimers()
        EventsAreEnabled = True
        ListView_SelectLine(MyListView1, OldSelectedLine)
    End Sub
    Private Sub Cmd_DisconnectSelectedModule()
        EventsAreEnabled = False
        Load_ConfigDatabase()
        Timer_10Hz.Stop()
        TheSystem_StopTimers()
        ' -----------------------------------------------------
        TheSystem_DisconnectModule(FindModuleByListLine(SelectedLine))
        TheSystem_ListComponents()
        ListView_SetAllLineColors()
        SelectedLine = -1
        ' -----------------------------------------------------
        ShowProps()
        TheSystem_StartTimers()
        Timer_10Hz.Start()
        EventsAreEnabled = True
        ListView_SelectLine(MyListView1, 0)
    End Sub


    ' ===========================================================================================================
    '   UPDATES
    ' ===========================================================================================================
    Private Sub Timer_10Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_10Hz.Tick
        If Not EventsAreEnabled Then Return
        If Not ConfigurationIsValid Then Return
        ' ----------------------------------------------------------------- Test Module Error
        TheSystem_TestModuleError()
        ' ----------------------------------------------------------------- updates
        SyncLock EventsLock
            '
            If WindowState <> FormWindowState.Minimized Then
                ' ---------------------------------------------------------- UpdateListedValues
                TheSystem_UpdateListedValues()
                ' ---------------------------------------------------------- update RepeatFrequency
                Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
                If m IsNot Nothing Then
                    lbl_RepeatFrequency.Text = m.CommFps.ToString("0")
                    If m.CommFps < 50 Then
                        lbl_RepeatFrequency.BackColor = Color.LightSalmon
                    Else
                        lbl_RepeatFrequency.BackColor = Color.Transparent
                    End If
                    lbl_ErrorRate.Text = m.ErrorRate.ToString("0.00", GCI)
                    If m.ErrorRate >= 0.1 Then
                        lbl_ErrorRate.BackColor = Color.LightSalmon
                        'm.SetSpeed()
                    Else
                        lbl_ErrorRate.BackColor = Color.Transparent
                    End If
                    If m.ErrorRate >= 0.01 Then
                        If ToolStripButton_BeepOnErrors.Checked Then Beep_RepetitionLimited(150)
                    End If
                End If
            End If
            ' ---------------------------------------------------------- edit
            If EditValue_MouseEditFlag Then
                If LeftMousePressed() Then
                    EditValue_MouseMove()
                Else
                    ShowCursor()
                    EditValue_MouseEditFlag = False
                End If
            End If
            '
        End SyncLock
    End Sub

    ' ===========================================================================================================
    '   Commands from Slot Zero
    ' ===========================================================================================================
    Private cmdZeroStatus As Int32 = 0
    Private Sub Timer_60Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_60Hz.Tick
        Dim n As Single = Slots.ReadSlot_NoNan(0)
        Select Case cmdZeroStatus
            Case 0                                  ' Waiting 333
                If n = 333 Then cmdZeroStatus = 1
            Case 1                                  ' Waiting 666
                Select Case n
                    Case 333
                        '
                    Case 666
                        cmdZeroStatus = 2
                    Case Else
                        cmdZeroStatus = 0
                End Select
            Case 2                                  ' Waiting command
                Select Case n
                    Case 1
                        cmdZeroStatus = 0
                        Cmd_Recognize()
                    Case 2
                        cmdZeroStatus = 0
                        'DoCalibrationAndResetTime()
                    Case 666
                        '
                    Case Else
                        cmdZeroStatus = 0
                End Select
        End Select
    End Sub


    ' ===========================================================================================================
    '   EDIT VALUES
    ' ===========================================================================================================
    Private EditValue_MouseEditFlag As Boolean = False
    Private EditValue_Slot As Int32
    Private EditValue_Multiplier As Int32
    Private EditValue_StartCursorPos As Point
    Private EditValue_MaxValue As Single
    Private EditValue_MinValue As Single
    Private EditValue_IsServoPin As Boolean

    Private Sub MyListView1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseDown
        If Not ConfigurationIsValid Then Return
        StartMouseEdit()
    End Sub

    Private Sub StartMouseEdit()
        If EditValue_MouseEditFlag Then Return
        Dim column As Int32 = ListView_GetColumnIndex(MyListView1)
        Dim line As Int32 = ListView_GetLineIndex(MyListView1)
        If line >= 0 Then
            Dim slotString As String = MyListView1.Items(line).SubItems(3).Text
            If slotString <> "" Then
                Dim p As Pin = FindPinByListLine(line)
                If p IsNot Nothing AndAlso p.Direction <> Pin.Directions.Unused Then
                    HideCursor()
                    EditValue_MouseEditFlag = True
                    EditValue_StartCursorPos = Cursor.Position
                    ' ----------------------------------------------------------------------
                    EditValue_Slot = p.Slot
                    EditValue_IsServoPin = False
                    If p.GetPinType() = Pin.PinTypes.SERVO_8 Then EditValue_IsServoPin = True
                    If p.GetPinType() = Pin.PinTypes.SERVO_16 Then EditValue_IsServoPin = True
                    EditValue_MaxValue = CSng(Math.Max(p.Value_Max, p.Value_Min))
                    EditValue_MinValue = CSng(Math.Min(p.Value_Max, p.Value_Min))
                    EditValue_Multiplier = 1
                    Dim range As Int32 = CInt(Math.Abs(p.Value_Max - p.Value_Min))
                    If range > 500 Then EditValue_Multiplier = 2
                    If range > 1000 Then EditValue_Multiplier = 5
                    If range > 2000 Then EditValue_Multiplier = 10
                    If range > 5000 Then EditValue_Multiplier = 20
                    If range > 10000 Then EditValue_Multiplier = 50
                End If
            End If
        End If
    End Sub

    Private Sub MyListView1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseMove
        If Not EventsAreEnabled Then Return
        If EditValue_MouseEditFlag Then
            EditValue_MouseMove()
        End If
    End Sub

    Private Sub EditValue_MouseMove()
        Dim delta As Int32 = EditValue_StartCursorPos.Y - Cursor.Position.Y
        Cursor.Position = EditValue_StartCursorPos
        ChangeValueByDelta(delta)
    End Sub

    Private Sub ChangeValueByDelta(ByVal delta As Single)
        ' Do not limit the value if not moving
        If delta = 0 Then Return

        'Form2.StopTimer()
        EventsAreEnabled = False

        Dim v As Single
        v = Slots.ReadSlot(EditValue_Slot)

        If Single.IsNaN(v) Then
            v = EditValue_MinValue - 9
        End If
        '
        v += delta * EditValue_Multiplier
        v = Math.Min(v, EditValue_MaxValue)
        'v = Math.Max(v, EditValue_MinValue)
        '
        If v < EditValue_MinValue Then
            If v < -8 AndAlso EditValue_IsServoPin Then
                v = NAN_Sleep
            Else
                v = EditValue_MinValue
            End If
        End If
        '
        Slots.WriteSlot(EditValue_Slot, v)
        '
        Application.DoEvents()

        EventsAreEnabled = True
        'Form2.StartTimer()
    End Sub

    Private Sub MyListView1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseDoubleClick
        Dim p As Pin = GetSelectedPin()
        If p Is Nothing Then Return
        If p.Direction = Pin.Directions.Unused Then Return
        Form2.Show()
    End Sub

    Private Sub MyListView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseUp
        Dim p As Pin = GetSelectedPin()
        If p Is Nothing Then Return
        If p.Direction = Pin.Directions.Unused Then Return
        Form2.SetPinDetails()
    End Sub

    ' ------------------------------------------------------------------
    '  Call ListViewResize from Form.Resize (not from ListView.resize)
    '  (otherwise the listview scroll produces problems)
    ' ------------------------------------------------------------------
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        TheSystem_ListViewResize()
    End Sub

    ' ---------------------------------------------------------------------------------------------------
    '  MyListView1.Activation = ItemActivation.Standard   <<<< USE THIS OR THE CURSOR CAN NOT BE CHANGED
    ' ---------------------------------------------------------------------------------------------------
    Private BlankCursor As Cursor = New Cursor(New IO.MemoryStream(My.Resources.Blank))
    Private Sub HideCursor()
        Cursor.Hide()
        MyListView1.Cursor = BlankCursor
    End Sub
    Private Sub ShowCursor()
        Cursor.Show()
        MyListView1.Cursor = Cursors.Hand
    End Sub



    ' ===========================================================================================================
    '   SET MODULE AND PIN PROPERTIES
    ' ===========================================================================================================
    Private Sub btn_ModuleName_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ModuleName.ClickButtonArea
        Dim newName As String
        newName = InputBox("New name for the selected module", _
                           "Edit Module name", _
                           cmb_ModuleNames.Text, _
                           Me.Right - 370, _
                           Me.Top + 125)

        newName = newName.Trim
        If newName <> "" Then
            Change_SelectedModule_Name(newName)
        End If
    End Sub

    Private Sub Change_SelectedModule_Name(ByVal newName As String)
        Me.Cursor = Cursors.AppStarting
        ' --------------------------------------------------------------------- init module
        Dim m As Module_InOut
        m = FindModuleByListLine(SelectedLine)
        If m Is Nothing Then
            Me.Cursor = Cursors.Default
            Return
        End If
        '
        newName = Strings.Left(newName, 16)
        '
        Dim oldName As String = m.GetName
        ' ----------------------------------------------------- try to change the hardware name
        If newName <> oldName Then
            For i As Int32 = 1 To 3
                m.SetName(newName)
                m.WriteNameToHardware()
                m.ReadInfoFromHardware()
                If m.GetName = newName Then
                    ' ----------------------------------------- if the new name is not in the database
                    If oldName <> "" And FindConfigByName(newName) < 0 Then
                        Dim configid As Int32 = FindConfigByName(oldName)
                        If configid >= 0 Then
                            Dim config As String() = CType(CType(ConfigDatabase(configid), String()).Clone, String())
                            config(0) = config(0).Replace(oldName, newName)
                            AddToConfigDatabase(config)
                            TheSystem_SaveConfigDatabase()
                        End If
                    End If
                    ' ----------------------------------------- 
                    Cmd_Recognize()
                    TheSystem_UpdateListedSubtypes()
                    TheSystem_UpdateConfigDatabase()
                    TheSystem_SaveConfigDatabase()
                    Exit For
                End If
            Next
        End If
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub CommSpeed_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_CommSpeed.TextChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        Timer_10Hz.Stop()
        Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
        If m IsNot Nothing Then
            m.SetSpeed(txt_CommSpeed.NumericValueInteger)
            txt_CommSpeed.Refresh()
            ChangedConfigParams = True
        End If
        Timer_10Hz.Start()
    End Sub

    Private Sub chk_AsyncMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_AsyncMode.CheckedChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
        If m IsNot Nothing Then
            m.SetAsyncMode(chk_AsyncMode.Checked)
            ChangedConfigParams = True
        End If
    End Sub

    Private Sub chk_PollingMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_PollingMode.CheckedChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
        If m IsNot Nothing Then
            m.SetPollingMode(chk_PollingMode.Checked)
            ChangedConfigParams = True
        End If
    End Sub

    Private Sub PinProps_Changed(ByVal sender As System.Object, _
                                 ByVal e As System.EventArgs) _
                                        Handles txt_Slot.TextChanged, _
                                                 txt_MaxValue.TextChanged, _
                                                 txt_MinValue.TextChanged, _
                                                 Label_ResponseSpeed.CheckedChanged, _
                                                 txt_ResponseSpeed.TextChanged, _
                                                 txt_ServoMaxTime.TextChanged, _
                                                 txt_ServoMinTime.TextChanged, _
                                                 chk_LogResponse.CheckedChanged, _
                                                 txt_MaxFreq.TextChanged, _
                                                 txt_MinFreq.TextChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        SetPinProps()
        ChangedConfigParams = True
    End Sub

    Private Sub SetPinProps()
        Select Case LineType(SelectedLine)
            Case "Pin"
                Dim p As Pin = FindPinByListLine(SelectedLine)
                Dim n As Int32 = txt_Slot.NumericValueInteger
                Dim str As String
                With MyListView1.Items(SelectedLine)
                    If n <> p.Slot Then
                        p.Slot = n
                        str = p.Slot.ToString()
                        If str <> .SubItems(3).Text Then .SubItems(3).Text = str
                    End If
                    If p.GetPinType = Pin.PinTypes.UNUSED Then
                        str = ""
                    Else
                        str = SlotNames(p.Slot)
                    End If
                    If str <> .SubItems(5).Text Then .SubItems(5).Text = str
                End With
                '
                p.Value_Max = CSng(txt_MaxValue.NumericValue)
                p.Value_Min = CSng(txt_MinValue.NumericValue)
                p.AdaptiveSpeed = Label_ResponseSpeed.Checked
                p.ResponseSpeed = txt_ResponseSpeed.NumericValueInteger
                '
                Select Case p.GetPinType
                    Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                        p.MaxTime = CSng(txt_ServoMaxTime.NumericValue)
                        p.MinTime = CSng(txt_ServoMinTime.NumericValue)
                        p.LogResponse = chk_LogResponse.Checked
                    Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                        p.MaxTime = CSng(txt_ServoMaxTime.NumericValue)
                        p.MinTime = CSng(txt_ServoMinTime.NumericValue)

                    Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                         Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                        p.MaxFreq = CSng(txt_MaxFreq.NumericValue)
                        p.MinFreq = CSng(txt_MinFreq.NumericValue)
                        p.ConvertToFreq = chk_ConvertToFrequency.Checked

                End Select
        End Select
        ' --------------------------------------------------------- show slot conflicts
        TestSlotConflicts()
        ' --------------------------------------------------------- show servo-pwm conflicts
        TestServoPwmConflicts()
    End Sub

    Friend Sub TestSlotConflicts()
        If Not ConfigurationIsValid Then Return
        ' ------------------------------------------------------- remove old markers
        For ii As Int32 = 0 To MyListView1.Items.Count - 1
            Dim itm As ListViewItem = MyListView1.Items(ii)
            If itm.SubItems(5).Text = "SLOT CONFLICT" Then
                itm.SubItems(5).Text = SlotNames(FindPinByListLine(ii).Slot)
                ListView_SetLineColors(MyListView1, ii)
            End If
        Next
        ' ------------------------------------------------------- mark new conflicts
        Dim i As Int32 = 0
        Dim dic As Dictionary(Of Int32, Int32) = New Dictionary(Of Int32, Int32)
        For Each m As Module_InOut In InOutModules
            i += 1
            For Each p As Pin In m.Pins
                If p.Direction = Pin.Directions.ModuleToHost Then
                    If dic.ContainsKey(p.Slot) Then
                        MarkSlotConflicts(i)
                        MarkSlotConflicts(dic(p.Slot))
                    End If
                    dic(p.Slot) = i
                End If
                i += 1
            Next
        Next
    End Sub

    Private Sub MarkSlotConflicts(ByVal LineNumber As Int32)
        With MyListView1.Items(LineNumber)
            .SubItems(5).Text = "SLOT CONFLICT"
            If .Selected Then
                .BackColor = Color.FromArgb(49, 106, 197)
                .ForeColor = Color.White
            Else
                .BackColor = Color.FromArgb(255, 150, 150)
                .ForeColor = Color.Black
            End If
        End With
    End Sub

    Private Sub TestServoPwmConflicts()
        If Not ConfigurationIsValid Then Return
        ' ------------------------------------------------------- remove old markers
        For ii As Int32 = 0 To MyListView1.Items.Count - 1
            Dim itm As ListViewItem = MyListView1.Items(ii)
            If itm.SubItems(5).Text = "PWM NOT VALID" Then
                itm.SubItems(5).Text = SlotNames(FindPinByListLine(ii).Slot)
                ListView_SetLineColors(MyListView1, ii)
            End If
        Next
        ' ------------------------------------------------------- mark new conflicts
        Dim ServoUsed As Boolean = False
        Dim i As Int32 = 0
        For Each m As Module_InOut In InOutModules
            For Each p As Pin In m.Pins
                If p.GetPinType = Pin.PinTypes.SERVO_8 Or p.GetPinType = Pin.PinTypes.SERVO_16 Then
                    ServoUsed = True
                    Exit For
                End If
            Next
            If ServoUsed Then
                If m.Pins(9).GetPinType = Pin.PinTypes.PWM_8 Or _
                   m.Pins(9).GetPinType = Pin.PinTypes.PWM_16 Then MarkServoPwmConflicts(i + 10)
                If m.Pins(10).GetPinType = Pin.PinTypes.PWM_8 Or _
                   m.Pins(10).GetPinType = Pin.PinTypes.PWM_16 Then MarkServoPwmConflicts(i + 11)
            End If
            i += m.Pins.Count + 1
        Next
    End Sub

    Private Sub MarkServoPwmConflicts(ByVal LineNumber As Int32)
        With MyListView1.Items(LineNumber)
            .SubItems(5).Text = "PWM NOT VALID"
            .BackColor = Color.FromArgb(255, 150, 150)
            .ForeColor = Color.Black
        End With
    End Sub

    Friend Sub MarkAllLinesWithDuplicateName(ByVal m As Module_InOut)
        For i As Int32 = 0 To MyListView1.Items.Count - 1
            If FindModuleByListLine(i) Is m Then
                With MyListView1.Items(i)
                    .SubItems(5).Text = "Duplicate name"
                    .BackColor = Color.FromArgb(255, 150, 150)
                    .ForeColor = Color.Black
                End With
            End If
        Next
    End Sub



    ' ====================================================================================================
    '   CONFIG PARAMS LOST FOCUS - SaveConfigDatabase 
    ' ====================================================================================================
    Private ChangedConfigParams As Boolean
    Private Sub ConfigParams_MouseLeave(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) _
                                        Handles _
                                        txt_CommSpeed.MouseLeave, _
                                        chk_AsyncMode.MouseLeave, _
                                        chk_PollingMode.MouseLeave, _
                                        txt_Slot.MouseLeave, _
                                        txt_MaxValue.MouseLeave, _
                                        txt_MinValue.MouseLeave, _
                                        Label_ResponseSpeed.MouseLeave, _
                                        txt_ResponseSpeed.MouseLeave, _
                                        txt_ServoMaxTime.MouseLeave, _
                                        txt_ServoMinTime.MouseLeave, _
                                        chk_LogResponse.MouseLeave, _
                                        txt_MaxFreq.MouseLeave, _
                                        txt_MinFreq.MouseLeave
        If ChangedConfigParams Then
            ChangedConfigParams = False
            TheSystem_UpdateAndSaveConfigDatabase()
        End If
    End Sub

    ' ====================================================================================================
    '   COMBO MODULE NAMES
    ' ====================================================================================================
    Private Sub cmb_ModuleNames_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ModuleNames.DropDown
        Dim oldname As String = cmb_ModuleNames.Items(0).ToString
        cmb_ModuleNames.ItemHeight = 16
        cmb_ModuleNames.Items.Clear()
        Load_ConfigDatabase()
        FillConfigNamesCombo(cmb_ModuleNames)
        Combo_SetIndex_FromString(cmb_ModuleNames, oldname)
    End Sub
    Private Sub cmb_ModuleNames_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ModuleNames.DropDownClosed
        cmb_ModuleNames.ItemHeight = 12
        Combo_Init(cmb_ModuleNames, cmb_ModuleNames.Text)
        MyListView1.Focus()
    End Sub
    Private Sub cmb_ModuleNames_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ModuleNames.SelectionChangeCommitted
        Change_SelectedModule_Name(cmb_ModuleNames.Text)
    End Sub


    ' ====================================================================================================
    '   COMBO PIN TYPE
    ' ====================================================================================================
    Private Sub cmb_PinType_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.DropDown
        cmb_PinType.ItemHeight = 16
        Dim p As Pin = FindPinByListLine(SelectedLine)
        If p Is Nothing Then Return
        InOutModules(p.ModuleId).FillTypeCombo(cmb_PinType, p)
        Combo_SetIndex_FromString(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
        LimitComboDropDownHeight(cmb_PinType)
    End Sub
    Private Sub cmb_PinType_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.DropDownClosed
        cmb_PinType.ItemHeight = 12
    End Sub
    Private Sub cmb_PinType_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.SelectionChangeCommitted
        Dim p As Pin = FindPinByListLine(SelectedLine)
        If p Is Nothing Then Return


        Dim str As String = cmb_PinType.Items(cmb_PinType.SelectedIndex).ToString

        p.SetPinType(Pin.StringToPinType(str))
        ' --------------------------------------------------------------

        InOutModules(p.ModuleId).SetupModulePins()
        ' ---------------------------------------------------------------------------------------

        ' -------------------------------------------------------------------------- 
        Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
        ' -------------------------------------------------------------------------- set PinType and Direction
        TheSystem_UpdateListedSubtypes()

        SetListViewLineFields(MyListView1.Items(SelectedLine), p)

        ' -------------------------------------------------------------------------- set Color
        ListView_SetAllLineColors()
        ' -------------------------------------------------------------------------- set pin props
        ShowProps()
        SetPinProps()
        TheSystem_UpdateAndSaveConfigDatabase()
        ' -------------------------------------------------------------------------- 
    End Sub

    Private Sub SetListViewLineFields(ByVal l As ListViewItem, ByVal p As Pin)
        If SelectedLine < 0 Then Return
        With l
            .SubItems(2).Text = Pin.PinTypeToString(p.GetPinType)
            .SubItems(3).Text = If(p.Direction = Pin.Directions.Unused, "", p.Slot.ToString())
            .SubItems(4).Text = ""
        End With
    End Sub

    ' ===========================================================================================================
    '   SHOW PROPS
    ' ===========================================================================================================
    Friend Sub ListView_SetAllLineColors()
        ' -------------------------------------------------------------------- select the listview "SelectedLine"
        If SelectedLine >= 0 And SelectedLine < MyListView1.Items.Count Then
            MyListView1.Items(SelectedLine).Selected = True
        End If
        ' -------------------------------------------------------------------- show listview colors
        For i As Int32 = 0 To MyListView1.Items.Count - 1
            ListView_SetLineColors(MyListView1, i)
        Next
    End Sub


    Private Sub ListView_SetLineColors(ByVal lv As ListView, ByVal line As Int32)
        If line < 0 Or line >= lv.Items.Count Then Return
        '
        Dim fc As Color
        Dim bc As Color
        If lv.Items(line).Selected Then
            ' ----------------------------------------------------------------- selected colors
            bc = Color.FromArgb(49, 106, 197)
            fc = Color.White
        Else
            ' ----------------------------------------------------------------- deselected colors
            If line >= 0 Then
                Select Case LineType(line)
                    Case "Module" : bc = Color.FromArgb(180, 205, 255) '(190, 215, 255)
                    Case "Pin"
                        If LineSubType(line) <> "Unused" Then
                            If FindPinByListLine(line).Direction = Pin.Directions.HostToModule Then
                                bc = Color.FromArgb(245, 245, 215) '(255, 255, 225)
                            Else
                                bc = Color.FromArgb(225, 245, 230) '(235, 255, 240)
                            End If
                        Else
                            bc = Color.FromArgb(255, 255, 255)
                        End If
                End Select
                fc = Color.Black
            End If
        End If
        lv.Items(line).ForeColor = fc
        lv.Items(line).BackColor = bc
    End Sub

    Private Function LineType(ByVal line As Int32) As String
        If line < 0 Then Return ""
        If line > MyListView1.Items.Count - 1 Then Return ""
        Return MyListView1.Items(line).SubItems(0).Text.Trim
    End Function
    Private Function LineSubType(ByVal line As Int32) As String
        Return MyListView1.Items(line).SubItems(2).Text.Trim
    End Function

    Friend SelectedLine As Int32 = -1
    Private Sub MyListView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyListView1.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        LockFormUpdate(Me)
        SyncLock EventsLock
            ' --------------------------------------------------------- change line colors and update "SelectedLine"
            If MyListView1.SelectedIndices.Count > 0 Then
                SelectedLine = MyListView1.SelectedIndices(0)
                If ConfigurationIsValid Then ListView_SetLineColors(MyListView1, SelectedLine)
            Else
                If ConfigurationIsValid Then ListView_SetLineColors(MyListView1, SelectedLine)
                SelectedLine = -1
            End If
            ' --------------------------------------------------------- show line props
            ShowProps()
            ' --------------------------------------------------------- show slot conflicts
            TestSlotConflicts()
            TestServoPwmConflicts()
        End SyncLock
        UnlockFormUpdate()
        If SelectedLine >= 0 Then Refresh()
    End Sub

    Private Sub ShowProps()
        '
        EventsAreEnabled = False
        '
        GroupBox_PinProps.Visible = False
        GroupBox_ServoPwmProps.Visible = False
        GroupBox_FrequencyProps.Visible = False
        '
        If SelectedLine < 0 Or SelectedLine > MyListView1.Items.Count - 1 Then
            GroupBox_ModuleProps.Enabled = False
            txt_CommSpeed.Text = "-"
        Else
            GroupBox_ModuleProps.Enabled = True
            '
            Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
            Dim p As Pin = FindPinByListLine(SelectedLine)
            '
            If Not ConfigurationIsValid Then
                GroupBox_ModuleProps.Height = cmb_ModuleNames.Bottom + 6
                If m IsNot Nothing Then
                    Combo_Init(cmb_ModuleNames, m.GetName)
                Else
                    Combo_Init(cmb_ModuleNames, "")
                    GroupBox_ModuleProps.Enabled = False
                    txt_CommSpeed.Text = "-"
                End If
            Else
                GroupBox_ModuleProps.Height = chk_PollingMode.Bottom + 6 '130
                '
                Select Case LineType(SelectedLine)
                    Case "Module"
                        GroupBox_PinProps.Visible = False
                        GroupBox_ServoPwmProps.Visible = False
                    Case "Pin"
                        GroupBox_PinProps.Visible = True
                        GroupBox_PinProps.Left = GroupBox_ModuleProps.Left
                        GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 8
                End Select
                '
                If m IsNot Nothing Then
                    Combo_Init(cmb_ModuleNames, m.GetName)
                    txt_CommSpeed.NumericValueInteger = m.CommSpeed
                    chk_AsyncMode.Checked = m.GetAsyncMode
                    chk_PollingMode.Checked = m.GetPollingMode
                    '
                    ToolTips_Init()
                    '
                    If p IsNot Nothing Then
                        Label_MaxValue.Text = Msg_MaxValue
                        Label_MinValue.Text = Msg_MinValue
                        Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
                        txt_Slot.NumericValue = p.Slot
                        txt_MaxValue.NumericValue = p.Value_Max
                        txt_MinValue.NumericValue = p.Value_Min
                        Label_ResponseSpeed.Checked = p.AdaptiveSpeed
                        txt_ResponseSpeed.NumericValueInteger = p.ResponseSpeed
                        txt_MaxValue.Visible = True
                        Select Case p.GetPinType
                            Case Pin.PinTypes.UNUSED
                                GroupBox_PinProps.Height = cmb_PinType.Bottom + 8
                                ' ------------------------------------------------------------------ OUT
                            Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                                GroupBox_ServoPwmProps.Text = Msg_PwmProps
                                txt_ServoMaxTime.MaxValue = 2000
                                txt_ServoMaxTime.NumericValue = p.MaxTime
                                txt_ServoMinTime.NumericValue = p.MinTime
                                chk_LogResponse.Checked = p.LogResponse
                                GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left
                                GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_ServoPwmProps.Height = chk_LogResponse.Bottom + 7
                                GroupBox_ServoPwmProps.Visible = True
                            Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                                GroupBox_ServoPwmProps.Text = Msg_ServoProps
                                txt_ServoMaxTime.MaxValue = 4000
                                txt_ServoMaxTime.NumericValue = p.MaxTime
                                txt_ServoMinTime.NumericValue = p.MinTime
                                GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left
                                GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_ServoPwmProps.Height = txt_ServoMinTime.Bottom + 8
                                GroupBox_ServoPwmProps.Visible = True
                            Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                                 Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                                chk_ConvertToFrequency.Checked = p.ConvertToFreq
                                txt_MaxFreq.NumericValue = p.MaxFreq
                                txt_MinFreq.NumericValue = p.MinFreq
                                If chk_ConvertToFrequency.Checked Then
                                    GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 10
                                    GroupBox_FrequencyProps.Height = txt_MinFreq.Bottom + 8
                                Else
                                    GroupBox_PinProps.Height = txt_Slot.Bottom + 7
                                    GroupBox_FrequencyProps.Height = chk_ConvertToFrequency.Bottom + 10
                                End If
                                GroupBox_FrequencyProps.Left = GroupBox_PinProps.Left
                                GroupBox_FrequencyProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_FrequencyProps.Visible = True
                        End Select
                    End If
                End If
            End If
        End If
        '
        EventsAreEnabled = True
    End Sub


    ' ==============================================================================================================
    '  AUTO CALIBRATION
    ' ==============================================================================================================
    Private Sub Timer_1Hz_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer_1Hz.Tick
        If Not EventsAreEnabled Then Return

    End Sub

    ' ==============================================================================================================
    '   ToolTips
    ' ==============================================================================================================
    Private WithEvents ttp1 As ToolTip = New ToolTip
    Private Sub ToolTips_Init()
        ttp1.ShowAlways = True
        ttp1.UseAnimation = True
        ttp1.UseFading = True
        ttp1.IsBalloon = True
        ttp1.AutoPopDelay = 32700
        ttp1.InitialDelay = 500
        ttp1.ReshowDelay = 500
        ' --------------------------------------------------------------- Add here Controls and ToolTip-Text
        Dim m As Module_InOut = FindModuleByListLine(SelectedLine)
        If m IsNot Nothing Then
            ttp1.SetToolTip(txt_CommSpeed, _
                 Msg_CommSpeed1 & vbCrLf & _
                 "- - - - - - - - - - - - - - -" & vbCrLf & _
                 "  1  =  10 fps" & vbCrLf & _
                 "  2  =  20 fps" & vbCrLf & _
                 "  3  =  30 fps" & vbCrLf & _
                 "  4  =  50 fps" & vbCrLf & _
                 "  5  =  60 fps" & vbCrLf & _
                 "  6  = 100 fps" & vbCrLf & _
                 "  7  = 150 fps" & vbCrLf & _
                 "  8  = 200 fps" & vbCrLf & _
                 "  9  = 300 fps" & vbCrLf & _
                 "10  =  400 fps" & vbCrLf & _
                 "11  =  500 fps" & vbCrLf & _
                 "12  =  Max fps")
        End If

        ttp1.SetToolTip(chk_AsyncMode, Msg_AsyncMode1 & vbCrLf & _
                                       Msg_AsyncMode2 & vbCrLf & _
                                       Msg_AsyncMode3 & vbCrLf & _
                                       Msg_AsyncMode4 & vbCrLf & _
                                       Msg_AsyncMode5)

        ttp1.SetToolTip(chk_PollingMode, Msg_PollingMode1 & vbCrLf & _
                                         Msg_PollingMode2 & vbCrLf & _
                                         Msg_PollingMode3 & vbCrLf & _
                                         Msg_PollingMode4 & vbCrLf & _
                                         Msg_PollingMode5)

        ttp1.SetToolTip(Label_ResponseSpeed, Msg_Filter1 & vbCrLf & _
                                             Msg_Filter2 & vbCrLf & _
                                             Msg_Filter3 & vbCrLf & _
                                             Msg_Filter4 & vbCrLf & _
                                             Msg_Filter5)

        ToolStripButton_Recognize.ToolTipText = Msg_Recognize1
        ToolStripButton_Validate.ToolTipText = Msg_Validate1
        ToolStripButton_BeepOnErrors.ToolTipText = Msg_BeepOnErrors1
        ToolStripButton_CommOptions.ToolTipText = Msg_CommOptions1
    End Sub

    ' --------------------- this corrects the XP bug that causes tooltip disappearing for ever 
    Private Sub controls_MouseEnter(ByVal sender As Object, _
                                   ByVal e As System.EventArgs) Handles txt_CommSpeed.MouseEnter
        ttp1.Active = False
        ttp1.Active = True
    End Sub

End Class


