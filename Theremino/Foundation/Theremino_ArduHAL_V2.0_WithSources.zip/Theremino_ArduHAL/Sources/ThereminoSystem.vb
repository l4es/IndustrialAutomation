﻿
Module ThereminoSystem

    Friend DuplicateNames As Boolean = False
    Friend ConfigurationIsValid As Boolean = False
    Friend InOutModules As List(Of Module_InOut)
    Friend FreeRunningTimer As Stopwatch = New Stopwatch

    Friend Sub TheSystem_InitModules()
        Form1.Cursor = Cursors.WaitCursor

        ' ------------------------------------------------ used for timers with "convert to frequency"
        FreeRunningTimer.Start()

        ' ------------------------------------------------ clear module list
        If InOutModules IsNot Nothing Then
            For Each m As Module_InOut In InOutModules
                m.ArduPort.COM_Close()
            Next
            InOutModules.Clear()
        Else
            InOutModules = New List(Of Module_InOut)
        End If

        ' ------------------------------------------------
        Dim moduleID As Int32 = 0
        For Each co As CommOption In CommOptions
            ' --------------------------------------------------------- test for empty arrays
            If co.Ports Is Nothing OrElse co.Ports.Length = 0 OrElse co.Ports(0) = "all" Then
                co.Ports = ArduinoSerialPort.GetPortNames
            End If
            If co.Bauds Is Nothing OrElse co.Bauds.Length = 0 OrElse co.Bauds(0) = 0 Then
                co.Bauds = CommOptions_DefaultBaudRates
            End If
            If co.Names Is Nothing OrElse co.Names.Length = 0 OrElse co.Names(0) = "all" Then
                ReDim co.Names(-1)
            End If
            ' ---------------------------------------------------------- 
            For Each portname As String In co.Ports
                For Each baud As Int32 In co.Bauds
                    Dim _module As Module_InOut
                    _module = New Module_InOut(moduleID)
                    _module.ArduPort = New ArduinoSerialPort
                    If _module.ArduPort.COM_Open(portname, baud) Then
                        ' ------------------------------------------- read info from hardware
                        _module.ReadInfoFromHardware()
                        ' ------------------------------------------- If there are names then test the Module-name
                        If co.Names.Length > 0 Then
                            If Array.IndexOf(co.Names, _module.GetName()) < 0 Then
                                _module.ArduPort.MyDeviceIsActive = False
                            End If
                        End If
                        ' ------------------------------------------- if OK add the module
                        If _module.ArduPort.MyDeviceIsActive Then
                            InOutModules.Add(_module)
                            moduleID += 1
                        Else
                            _module.ArduPort.COM_Close()
                        End If
                    End If
                Next
            Next
        Next
        ' ------------------------------------------------ Sort Modules
        InOutModules.Sort(AddressOf ModuleComparer)
        ' ------------------------------------------------ and reorder ID
        SetAllModuleId()
        ' -------------------------------------------------------------- 
        Form1.Cursor = Cursors.Default
        ' -------------------------------------------------------------- eventually clear a SlotZero MasterError
        If Single.IsNaN(Slots.ReadSlot(0)) Then
            Slots.WriteSlot(0, 0)
        End If
    End Sub

    Private Function ModuleComparer(ByVal m1 As Module_InOut, ByVal m2 As Module_InOut) As Integer
        Return String.Compare(m1.GetName(), m2.GetName(), True)
    End Function

    Friend Sub TheSystem_DisconnectModule(ByVal m As Module_InOut)
        If m Is Nothing Then Return
        m.ArduPort.COM_Close()
        InOutModules.Remove(m)
        SetAllModuleId()
    End Sub

    Private Sub SetAllModuleId()
        For i As Int32 = 0 To InOutModules.Count - 1
            InOutModules(i).ModuleId = i
            If InOutModules(i).Pins IsNot Nothing Then
                For Each p As Pin In InOutModules(i).Pins
                    p.ModuleId = i
                Next
            End If
        Next
    End Sub

    Friend Sub TheSystem_StartTimers()
        If Not ConfigurationIsValid Then Exit Sub
        For Each m As Module_InOut In InOutModules
            m.StartTimedOperations()
        Next
    End Sub

    Friend Sub TheSystem_StopTimers()
        For Each m As Module_InOut In InOutModules
            m.StopTimedOperations()
        Next
    End Sub

    Friend Sub TheSystem_AssignConfigurationToModules()
        ' ------------------------------------------------ assign configuration
        AssignDefaultSlotsToPins()
        AssignConfigurationsToModules()
        SetConfigurationParamsToDevices()
        TestConfigErrors()
        ' ------------------------------------------------ show pins in the list
        Form1.SelectedLine = -1
        TheSystem_ListComponents()
        Form1.ListView_SetAllLineColors()
        MarkErrorLines()
        Form1.ToolStripButton_Validate.Enabled = Not ConfigurationIsValid And Not DuplicateNames
    End Sub

    Private Sub AssignDefaultSlotsToPins()
        Dim i As Int32 = 0
        For Each m As Module_InOut In InOutModules
            Dim j As Int32 = i
            i += 100
            For Each p As Pin In m.Pins
                p.Slot = j
                j += 1
            Next
        Next
    End Sub

    Friend Sub TheSystem_CalibrateZero()
        For Each m As Module_InOut In InOutModules
            m.CalibrateZero()
        Next
    End Sub

    Friend Sub TheSystem_SetParkingPositions()
        For Each m As Module_InOut In InOutModules
            m.SetOutputPinsToParkingPosition()
        Next
    End Sub


    ' ==================================================================================================
    '   FIND COMPONENTS FROM LIST
    ' ==================================================================================================
    Friend Function FindModuleByListLine(ByVal line As Int32) As Module_InOut
        If InOutModules Is Nothing Then Return Nothing
        Dim n As Int32 = 0
        For Each m As Module_InOut In InOutModules
            If n = line Then Return m
            n += 1
            For Each p As Pin In m.Pins
                If n = line Then Return m
                n += 1
            Next
        Next
        Return Nothing
    End Function

    Friend Function FindPinByListLine(ByVal line As Int32) As Pin
        Dim n As Int32 = 0
        For Each m As Module_InOut In InOutModules
            n += 1
            For Each p As Pin In m.Pins
                If n = line Then Return p
                n += 1
            Next
        Next
        Return Nothing
    End Function

    Friend Function GetSelectedPin() As Pin
        Return FindPinByListLine(Form1.SelectedLine)
    End Function

    Friend Function GetSelectedListLine() As Int32
        Return Form1.SelectedLine
    End Function


    ' ==================================================================================================
    '   LIST COMPONENTS
    ' ==================================================================================================
    Friend Sub TheSystem_ListComponents()

        LoadSlotNames()

        Dim item As ListViewItem
        With Form1.MyListView1
            .OwnerDraw = True
            .GridLines = True
            .FullRowSelect = True
            .View = View.Details
            .LabelEdit = False
            .Font = New Font("Courier new", 8)
            ' ----------------------------------------------------------------- column headers
            .Header_BackColor1 = Color.FromArgb(255, 255, 200)
            .Header_BackColor2 = Color.FromArgb(200, 200, 200)
            .Header_ForeColor = Color.FromArgb(20, 20, 20)
            .Header_ShadowColor = Color.FromArgb(0, 255, 255, 200)
            .Header_Font = New Font("Microsoft Sans Serif", 9, FontStyle.Regular)
            '
            ' -----------------------------------------------------------------
            .Clear()
            .Header_TextVerticalPosition = -1
            .Header_TextAlignments = New StringAlignment() {StringAlignment.Near, _
                                                            StringAlignment.Center, _
                                                            StringAlignment.Near, _
                                                            StringAlignment.Center, _
                                                            StringAlignment.Center, _
                                                            StringAlignment.Near}

            .Columns.Add(" Type", 56, HorizontalAlignment.Left)
            .Columns.Add("ID", 34, HorizontalAlignment.Left)
            .Columns.Add(" Subtype", 105, HorizontalAlignment.Left)
            .Columns.Add("Slot", 35, HorizontalAlignment.Center)
            .Columns.Add("Value", 62, HorizontalAlignment.Right)
            .Columns.Add("    Notes", 100, HorizontalAlignment.Left)
            .Refresh()
            ' -----------------------------------------------------------------
            For Each m As Module_InOut In InOutModules
                item = .Items.Add("Module")
                item.SubItems.Add((m.ModuleId + 1).ToString)
                item.SubItems.Add(m.GetName)
                item.SubItems.Add("")
                item.SubItems.Add("")
                item.SubItems.Add(m.ModuleVersion)
                For Each p As Pin In m.Pins
                    item = .Items.Add(" Pin")
                    ' ------------------------------------------- select if listed pins starting from 1 or 0
                    If p.PinId < 14 Then
                        'item.SubItems.Add((p.PinId + 1).ToString)
                        item.SubItems.Add("D" + (p.PinId).ToString)
                    Else
                        item.SubItems.Add("A" + (p.PinId - 14).ToString)
                    End If
                    ' ---------------------------------------------------
                    item.SubItems.Add(Pin.PinTypeToString(p.GetPinType))
                    If p.Direction <> Pin.Directions.Unused Then
                        item.SubItems.Add(p.Slot.ToString)
                        item.SubItems.Add("0.0")
                    Else
                        item.SubItems.Add("")
                        item.SubItems.Add("")
                    End If

                    If p.GetPinType = Pin.PinTypes.UNUSED Then
                        item.SubItems.Add("")
                    Else
                        item.SubItems.Add(SlotNames(p.Slot))
                    End If
                Next
            Next
            TheSystem_ListViewResize()
        End With
    End Sub


    ' ------------------------------------------------------------------
    '  Call this function from Form.Resize (not from ListView.resize)
    '  (otherwise the listview scroll produces problems)
    ' ------------------------------------------------------------------
    Friend Sub TheSystem_ListViewResize()
        ' -------------------------------------------- ResizeLastColumn
        With Form1.MyListView1
            If .Columns.Count > 1 Then
                .Columns(.Columns.Count - 1).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
            End If
        End With
    End Sub



    ' ==================================================================================================
    '   LIST COMPONENTS - UPDATE VALUES
    ' ==================================================================================================
    Friend Sub TheSystem_UpdateListedSubtypes()
        Dim str As String
        With Form1.MyListView1
            Dim n As Int32 = 0
            For Each m As Module_InOut In InOutModules
                If m.GetName <> .Items(n).SubItems(2).Text Then .Items(n).SubItems(2).Text = m.GetName
                n += 1
                For Each p As Pin In m.Pins
                    str = Pin.PinTypeToString(p.GetPinType)
                    If str <> .Items(n).SubItems(2).Text Then .Items(n).SubItems(2).Text = str
                    n += 1
                Next
            Next
        End With
    End Sub

    Friend Sub TheSystem_TestModuleError()
        For Each m As Module_InOut In InOutModules
            If Not m.ArduPort.MyDeviceIsActive Then
                Slots.WriteSlot(0, NAN_MasterError)
            End If
        Next
    End Sub

    Friend Sub TheSystem_UpdateListedValues()
        Dim str As String
        With Form1.MyListView1
            Dim n As Int32 = 0
            For Each m As Module_InOut In InOutModules
                If Not m.ArduPort.MyDeviceIsActive Then
                    .Items(n).SubItems(5).Text = "DISCONNECTED"
                    .Items(n).BackColor = Color.FromArgb(255, 150, 150)
                    .Items(n).ForeColor = Color.Black
                End If
                n += 1
                For Each p As Pin In m.Pins
                    If p.Direction <> Pin.Directions.Unused Then
                        If Single.IsNaN(p.Value) Then
                            str = NAN_GetName(p.Value)
                        Else
                            str = p.Value.ToString("0.0", GCI)
                        End If
                        If str <> .Items(n).SubItems(4).Text Then .Items(n).SubItems(4).Text = str
                    End If
                    n += 1
                Next
            Next
        End With
    End Sub


    ' ==================================================================================================
    '   CONFIGURATIONS
    ' ==================================================================================================
    Friend ConfigDatabase() As Object

    Private Sub MarkErrorLines()
        Dim config(-1) As String
        Dim nline As Int32 = 0
        '
        DuplicateNames = False
        '
        For Each m As Module_InOut In InOutModules

            If AnotherModuleHasTheSameName(m) Then
                m.StopTimedOperations()
                m.ConfigValid = False
                ConfigurationIsValid = False
                DuplicateNames = True
                Form1.MarkAllLinesWithDuplicateName(m)
                Continue For
            End If

            Dim npin As Int32 = 0
            Dim sa() As String
            '
            If ConfigDatabase.Length > 0 Then
                config = TryCast(ConfigDatabase(m.ConfigId), String())
            End If

            If npin < config.Length Then
                sa = Split(config(npin), ",")
                If sa.Length < 2 OrElse sa(0).Trim <> "Module" OrElse sa(1).Trim <> m.GetName Then
                    MarkErrorLine(npin)
                End If
            Else
                MarkErrorLine(npin)
            End If
            npin += 1
            nline += 1
            For Each p As Pin In m.Pins
                If npin < config.Length Then
                    sa = Split(config(npin), ",")
                    If sa.Length < 2 OrElse sa(0).Trim <> "Pin" OrElse sa(1).Trim <> Pin.PinTypeToString(p.GetPinType) Then
                        MarkErrorLine(npin)
                    End If
                Else
                    MarkErrorLine(npin)
                End If
                npin += 1
                nline += 1
            Next
            '
            While (npin < config.Length)
                ' ------------------------------------------------------------ add pins to Master
                Dim s() As String = Split(config(npin), ",")
                Dim p As Pin = New Pin(Pin.StringToPinType(s(1)), m.ModuleId, npin)
                m.Pins.Add(p)
                ' ------------------------------------------------------------ add error line to ListView
                AddErrorLine(config, npin, nline)
                npin += 1
                nline += 1
            End While
        Next
    End Sub

    Private Sub MarkErrorLine(ByVal LineNumber As Int32)
        With Form1.MyListView1.Items(LineNumber)
            .SubItems(5).Text = "Not configured"
            .BackColor = Color.FromArgb(255, 150, 150)
            .ForeColor = Color.Black
        End With
    End Sub

    Private Sub AddErrorLine(ByVal config As String(), ByVal npin As Int32, ByVal nline As Int32)
        With Form1.MyListView1
            ' ------------------------------------------------------- prepare the item
            Dim itm As ListViewItem
            Dim s() As String = Split(config(npin), ",")
            If s(0) = "Slave" Then
                itm = New ListViewItem(" " + s(0))
            Else
                itm = New ListViewItem("  " + s(0))
            End If
            itm.SubItems.Add("")
            itm.SubItems.Add(s(1).Trim)
            itm.SubItems.Add("")
            itm.SubItems.Add("")
            itm.SubItems.Add("Not found")
            itm.BackColor = Color.FromArgb(255, 150, 150)
            itm.ForeColor = Color.Black
            ' ------------------------------------------------------- insert the item in position "nline"
            .Items.Insert(nline, itm)
        End With
    End Sub

    Private Function AnotherModuleHasTheSameName(ByVal m1 As Module_InOut) As Boolean
        For Each m2 As Module_InOut In InOutModules
            If m1 Is m2 Then Continue For
            If m1.GetName = m2.GetName Then Return True
        Next
        Return False
    End Function

    Private Function CountConfigErrors(ByVal m As Module_InOut, ByVal Config As String()) As Int32
        Dim Errors As Int32 = 0
        Dim n As Int32 = 0
        Dim sa() As String
        '
        If n < Config.Length Then
            sa = Split(Config(n), ",")
            If sa.Length < 2 OrElse sa(0).Trim <> "Module" Then 'OrElse sa(1).Trim <> m.Name Then
                Errors += 1
            End If
        Else
            Errors += 1
        End If
        n += 1
        For Each p As Pin In m.Pins
            If n < Config.Length Then
                sa = Split(Config(n), ",")
                If sa.Length < 2 OrElse sa(0).Trim <> "Pin" Then
                    Errors += 1
                End If
            Else
                Errors += 1
            End If
            n += 1
        Next
        '
        If Config.Length > n Then
            Errors += (Config.Length - n)
        End If
        '
        Return Errors
    End Function

    Private Sub TestConfigErrors()
        For i As Int32 = 0 To InOutModules.Count - 1
            If CountConfigErrors(InOutModules(i), _
                                 TryCast(ConfigDatabase(InOutModules(i).ConfigId), String())) > 0 Then
                InOutModules(i).StopTimedOperations()
                InOutModules(i).ConfigValid = False
                ConfigurationIsValid = False
            End If
        Next
    End Sub


    Friend Function GetConfigName(ByVal config As String()) As String
        Dim sa() As String
        sa = Split(config(0), ",")
        If sa.Length > 1 Then
            Return sa(1).Trim
        Else
            Return ""
        End If
    End Function

    Friend Function FindConfigByName(ByVal name As String) As Int32
        For i As Int32 = 0 To ConfigDatabase.Length - 1
            If name.ToUpper = GetConfigName(TryCast(ConfigDatabase(i), String())).ToUpper Then
                Return i
            End If
        Next
        Return -1
    End Function

    Friend Sub FillConfigNamesCombo(ByVal cmb As ComboBox)
        For i As Int32 = 0 To ConfigDatabase.Length - 1
            cmb.Items.Add(GetConfigName(TryCast(ConfigDatabase(i), String())))
        Next
    End Sub

    Private Sub AssignConfigurationsToModules()
        '
        ConfigurationIsValid = True
        '
        For i As Int32 = 0 To InOutModules.Count - 1
            InOutModules(i).ConfigValid = True
            ' ----------------------------------------------------------- find configuration by name
            InOutModules(i).ConfigId = FindConfigByName(InOutModules(i).GetName)
            ' ----------------------------------------------------------- if not found add a new configuration
            If InOutModules(i).ConfigId < 0 Then
                InOutModules(i).ConfigId = ConfigDatabase.Length
                Dim config As String() = CreateConfig_AsStringArray(InOutModules(i))
                AddToConfigDatabase(config)
                TheSystem_SaveConfigDatabase()
            End If
        Next
    End Sub

    Private Sub SetConfigurationParamsToDevices()
        Dim sa() As String
        For Each m As Module_InOut In InOutModules
            If m.ConfigId >= ConfigDatabase.Length Then Continue For
            Dim config As String() = TryCast(ConfigDatabase(m.ConfigId), String())
            If config Is Nothing Then Continue For
            Dim nline As Int32 = 0
            If nline >= config.Length Then Continue For
            sa = Split(config(nline), ",")
            nline += 1
            If sa.Length = 5 Then
                m.SetSpeed(CInt(Val(sa(2).Trim)))
                m.SetAsyncMode(sa(3).Trim = "True")
                m.SetPollingMode(sa(4).Trim = "True")
            End If

            For Each p As Pin In m.Pins
                If nline >= config.Length Then Continue For
                sa = Split(config(nline), ",")
                nline += 1

                Dim ConfPinType As Pin.PinTypes = Pin.StringToPinType(sa(1))
                If ConfPinType <> p.GetPinType Then
                    m.ConfigurePin(p.PinId, ConfPinType)
                End If

                If sa.Length >= 6 Then
                    p.Slot = CInt(Val(sa(2).Trim))
                    If p.Slot > 999 Then p.Slot = 999
                    p.Value_Max = CSng(Val(sa(3).Trim))
                    p.Value_Min = CSng(Val(sa(4).Trim))
                    '
                    Dim nn As Int32 = CInt(Val(sa(5).Trim))
                    p.AdaptiveSpeed = False
                    If nn >= 1000 Then
                        p.AdaptiveSpeed = True
                        nn -= 1000
                    End If
                    If nn > 100 Then nn = 100
                    If nn < 1 Then nn = 1
                    p.ResponseSpeed = nn
                    '
                    Select Case p.GetPinType
                        Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                            If sa.Length >= 9 Then
                                p.MaxTime = CSng(Val(sa(6).Trim))
                                p.MinTime = CSng(Val(sa(7).Trim))
                                p.LogResponse = sa(8).Trim = "True"
                            End If
                        Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                            If sa.Length >= 8 Then
                                p.MaxTime = CSng(Val(sa(6).Trim))
                                p.MinTime = CSng(Val(sa(7).Trim))
                            End If
                        Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                             Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                            If sa.Length >= 9 Then
                                p.MaxFreq = CSng(Val(sa(6).Trim))
                                p.MinFreq = CSng(Val(sa(7).Trim))
                                p.ConvertToFreq = sa(8).Trim = "True"
                            End If
                    End Select
                End If
            Next

            ' -------------------------------------- re-align all the pins 
            m.SetupModulePins()
            '
            m.SetCommunicationIndexesToPins()
        Next
    End Sub

    Private Function CreateConfig_AsStringArray(ByVal m As Module_InOut) As String()
        Dim i As Int32
        Dim config(0) As String
        config(0) = "Module"
        config(0) &= "," & m.GetName
        config(0) &= "," & m.CommSpeed.ToString
        config(0) &= "," & m.GetAsyncMode.ToString
        config(0) &= "," & m.GetPollingMode.ToString
        For Each p As Pin In m.Pins
            i = config.Length
            ReDim Preserve config(i)
            config(i) = "Pin"
            config(i) &= "," & Pin.PinTypeToString(p.GetPinType)
            config(i) &= "," & p.Slot.ToString
            config(i) &= "," & p.Value_Max.ToString(GCI)
            config(i) &= "," & p.Value_Min.ToString(GCI)
            Dim nn As Int32 = p.ResponseSpeed
            If p.AdaptiveSpeed Then nn += 1000
            config(i) &= "," & nn.ToString
            Select Case p.GetPinType
                Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                    config(i) &= "," & p.MaxTime.ToString
                    config(i) &= "," & p.MinTime.ToString
                    config(i) &= "," & p.LogResponse.ToString
                Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                    config(i) &= "," & p.MaxTime.ToString
                    config(i) &= "," & p.MinTime.ToString
                Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                     Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                    config(i) &= "," & p.MaxFreq.ToString
                    config(i) &= "," & p.MinFreq.ToString
                    config(i) &= "," & p.ConvertToFreq.ToString
            End Select
        Next
        Return config
    End Function

    Friend Sub TheSystem_ValidateConfiguration()
        For Each m As Module_InOut In InOutModules
            m.ConfigValid = True
        Next
        ConfigurationIsValid = True
        TheSystem_ListComponents()
        Form1.ListView_SetAllLineColors()
        Form1.ToolStripButton_Validate.Enabled = Not ConfigurationIsValid And Not DuplicateNames
    End Sub

    Friend Sub AddToConfigDatabase(ByVal config As String())
        If config.Length > 0 Then
            Dim count As Int32 = ConfigDatabase.Length
            ReDim Preserve ConfigDatabase(count)
            ConfigDatabase(count) = config
        End If
    End Sub

    Friend Sub TheSystem_UpdateAndSaveConfigDatabase()
        TheSystem_UpdateConfigDatabase()
        TheSystem_SaveConfigDatabase()
    End Sub

    Friend Sub TheSystem_UpdateConfigDatabase()
        If ConfigurationIsValid Then
            For Each m As Module_InOut In InOutModules
                If m.ConfigValid Then
                    If m.ConfigId <= ConfigDatabase.Length And ConfigDatabase.Length > 0 Then
                        ConfigDatabase(m.ConfigId) = CreateConfig_AsStringArray(m)
                    Else
                        m.StopTimedOperations()
                        m.ConfigValid = False
                        ConfigurationIsValid = False
                    End If
                End If
            Next
        End If
    End Sub

    Friend Sub TheSystem_SaveConfigDatabase()
        If ConfigurationIsValid Then
            Save_ConfigDatabase()
        Else
            'MsgBox("Invalid configuration - ""Config Database"" not saved.", MsgBoxStyle.Information)
        End If
    End Sub

End Module
