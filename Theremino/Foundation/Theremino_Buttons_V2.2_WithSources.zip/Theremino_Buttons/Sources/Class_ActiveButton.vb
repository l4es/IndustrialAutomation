﻿Public Class ActiveButton

    Inherits Windows.Forms.Button

    'Protected Overrides Sub OnCreateControl()
    '    MyBase.OnCreateControl()
    '    'Me.FlatAppearance.MouseOverBackColor = Me.BackColor
    '    'Me.FlatAppearance.MouseDownBackColor = Me.BackColor
    '    'Me.FlatAppearance.BorderSize = 0
    'End Sub

    'Protected Overrides Sub OnGotFocus(ByVal e As System.EventArgs)
    '    MyBase.OnGotFocus(e)
    '    'Me.FlatAppearance.BorderSize = 2
    'End Sub

    'Protected Overrides Sub OnLostFocus(ByVal e As System.EventArgs)
    '    MyBase.OnLostFocus(e)
    '    'Me.FlatAppearance.BorderSize = 0
    'End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        If Me.Focused Then
            e.Graphics.DrawRectangle(New Pen(Color.DarkGreen, 6), _
                                     1, 1, Me.Width - 3, Me.Height - 3)
        End If
    End Sub

    ' ====================================================================================
    '  On the TouchScreen the MouseDown event is not fired 
    '  On the TouchScreen the MouseUp event is fired correctly
    ' ------------------------------------------------------------------------------------
    '  This touch screen event PointerDown can be used as MouseDown
    ' ------------------------------------------------------------------------------------
    '  WM_POINTERUPDATE, WM_POINTERCAPTURECHANGED
    '   are temptatives to suppress the touch-screen right-button simulated rectangle
    ' ====================================================================================
    Friend Event PointerDown As PointerDownEventHandler
    Friend Delegate Sub PointerDownEventHandler(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

    Protected Overrides Sub WndProc(ByRef msg As System.Windows.Forms.Message)
        'Const WM_POINTERCAPTURECHANGED As Integer = &H24C
        'Const WM_POINTERUPDATE As Integer = &H245
        Const WM_POINTERDOWN As Integer = &H246
        Const WM_POINTERUP As Integer = &H247
        Select Case msg.Msg
            'Case WM_POINTERUPDATE, WM_POINTERCAPTURECHANGED
            Case WM_POINTERDOWN
                'Debug.WriteLine("DOWN")
                Dim pt As Point = PointToClient(lParamToPoint(msg.LParam))
                Dim args As MouseEventArgs = New MouseEventArgs(MouseButtons.Left, 1, pt.X, pt.Y, 0)
                RaiseEvent PointerDown(Me, args)
            Case WM_POINTERUP
                'Debug.WriteLine("UP")
        End Select
        MyBase.WndProc(msg)
    End Sub

    Private Function lParamToPoint(ByVal lParam As IntPtr) As Point
        Dim lp As UInt32 = CType(lParam, UInt32)
        Return New Point(CShort(lp And &HFFFF), CShort((lp >> 16) And &HFFFF))
    End Function

End Class


