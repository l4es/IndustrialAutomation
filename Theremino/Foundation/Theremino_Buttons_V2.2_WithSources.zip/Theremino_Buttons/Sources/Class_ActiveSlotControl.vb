﻿Public Class ActiveSlotControl

    Inherits Windows.Forms.Button

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        'e.Graphics.DrawRectangle(New Pen(Color.FromArgb(60, 255, 255, 0), 10), _
        '                         5, 5, Me.Width - 10, Me.Height - 10)

        e.Graphics.FillRectangle(New SolidBrush(Color.FromArgb(100, 0, 0, 0)), _
                                0, 0, Me.Width, 5)
        e.Graphics.FillRectangle(New SolidBrush(Color.FromArgb(100, 0, 0, 0)), _
                                0, Me.Height - 5, Me.Width, 5)
    End Sub

End Class
