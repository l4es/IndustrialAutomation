﻿Class ActiveSlots

    ' ======================================================================================
    '  ACTIVE SLOTS ARRAY
    ' ======================================================================================
    Friend Shared ActiveSlotsArray(-1) As ActiveSlots

    Friend Shared Sub Clear()
        ReDim ActiveSlotsArray(-1)
    End Sub

    Friend Shared Sub AddActiveSlot(ByVal ao As ActiveObject)
        ' ----------------------------------------------------- multiple slot are added as multiple active slots
        For i As Int32 = 0 To ao.SlotArray.Length - 1
            Dim ao2 As ActiveObject = ao
            ReDim ao2.SlotArray(0)
            ao2.SlotArray(0) = ao.SlotArray(i)
            ao2.SlotString = ao.SlotArray(i).ToString
            AddActiveSlot_Child_1(ao2)
        Next
    End Sub

    Private Shared Sub AddActiveSlot_Child_1(ByVal ao As ActiveObject)
        ' ----------------------------------------------------- test if the activeslot is already in the array
        For i As Int32 = 0 To ActiveSlotsArray.Length - 1
            If ActiveSlotsArray(i).Params.SlotString = ao.SlotString AndAlso _
               ActiveSlotsArray(i).Params.Type = ao.Type Then
                AddActiveSlot_Child_2(i, ao)
                Return
            End If
        Next
        ' ------------------------------------------------------ if not in the array make a new place and add it
        ReDim Preserve ActiveSlotsArray(ActiveSlotsArray.Length)
        ActiveSlotsArray(ActiveSlotsArray.Length - 1) = New ActiveSlots
        AddActiveSlot_Child_2(ActiveSlotsArray.Length - 1, ao)
    End Sub

    Private Shared Sub AddActiveSlot_Child_2(ByVal index As Int32, _
                                              ByVal ao As ActiveObject)

        With ActiveSlotsArray(index).Params
            .MousePressed = ao.MousePressed
            .Type = ao.Type
            .SlotString = ao.SlotString
            .SlotArray = ao.SlotArray
            If ao.Random <> 0 Then
                .pos = ao.Value
            Else
                If .SlotArray IsNot Nothing AndAlso .SlotArray.Length > 0 Then
                    .pos = Slots.ReadSlot_NoNan(.SlotArray(0))
                End If
            End If
            .TriggerSlot = ao.TriggerSlot
            .Value = ao.Value
            .Speed = ao.Speed
            .Random = ao.Random
            .MoveType = ao.MoveType
            If ao.MoveType = "Pulse" Then
                If ao.MousePressed Then
                    .PulseTimer = CInt(.Speed / 5) ' Speed in milliseconds (5 mS each loop) 
                Else
                    .Value = 0
                End If
            End If
        End With
    End Sub

   
    ' ======================================================================================
    '  ACTIVE SLOT
    ' ======================================================================================
    Friend Params As ActiveObject

    Friend Sub MoveSingleStep(ByVal i As Int32)

        With ActiveSlotsArray(i).Params
            Dim dest As Single = .Value
            Dim rand As Single = .Random
            ' ------------------------------------------------------- active slot
            If .Type = ActiveObjectType.ActiveSlot Then
                ' --------------------------------------------------- active slot Sine
                If .MoveType = "Sine" Then
                    Dim sp As Single
                    If .TriggerSlot >= 0 Then
                        sp = Slots.ReadSlot_NoNan(.TriggerSlot)
                        If sp <= 0 Then Return
                        sp = sp * .Speed * 0.0000038F
                    Else
                        sp = .Speed * 0.00038F
                    End If
                    Static sinecounter As Double
                    sinecounter = (sinecounter + sp) Mod 2 * Math.PI
                    Slots.WriteSlot(.SlotArray(0), 0.5 * dest * (Math.Sin(sinecounter) + 1))
                    Return
                End If
                ' --------------------------------------------------- active slot pos and dest
                If .MoveType = "OnOff" Then
                    If Slots.ReadSlot_NoNan(Params.TriggerSlot) < 500 Then
                        dest = 0
                        rand = 0
                    End If
                    .pos = Slots.ReadSlot_NoNan(.SlotArray(0))
                Else
                    dest = Slots.ReadSlot_NoNan(.TriggerSlot)
                End If
            End If
            ' ------------------------------------------------------- test Partial
            If .MoveType = "Partial" Then
                If Not .MousePressed Then
                    Return
                End If
            End If
            ' ------------------------------------------------------- if position <> destination then move
            If .pos <> dest Then
                If .Speed <= 0 Or .Speed > 1000 Then
                    .pos = dest
                Else
                    ' ----------------------------------------------- calc remaining distance
                    Dim distance As Single = Math.Abs(dest - .pos)
                    ' ----------------------------------------------- IF distance is short THEN set destination end return
                    If distance <= .Speed Then
                        .pos = dest
                        Slots.WriteSlot(.SlotArray(0), .pos)
                        Return
                    End If
                    ' ----------------------------------------------- ELSE do a single step
                    If dest > .pos Then
                        .pos = .pos + .Speed
                    Else
                        .pos = .pos - .Speed
                    End If
                End If
                Slots.WriteSlot(.SlotArray(0), .pos)
            End If
            ' ------------------------------------------------------- random
            If .Speed <> 0 AndAlso .Random <> 0 Then
                .SpeedCounter += .Speed
                If .SpeedCounter > 1000 Then
                    .SpeedCounter -= 1000
                    Slots.WriteSlot(.SlotArray(0), .pos + rand * Rnd())
                End If
            End If
            ' ------------------------------------------------------- pulse 100 * 5 mS = 500 mS
            If .PulseTimer > 0 Then
                .PulseTimer -= 1
                If .PulseTimer = 1 Then
                    .pos = 0
                    .Value = 0
                    Slots.WriteSlot(.SlotArray(0), .pos)
                End If
            End If
        End With
    End Sub

End Class
