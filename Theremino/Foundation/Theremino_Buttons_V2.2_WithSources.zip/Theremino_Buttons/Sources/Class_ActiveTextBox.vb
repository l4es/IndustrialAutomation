﻿Public Class ActiveTextBox
    Inherits Windows.Forms.TextBox

    Protected Overrides Sub WndProc(ByRef msg As System.Windows.Forms.Message)
        Const WM_SETFOCUS As Integer = 7
        Const WM_KILLFOCUS As Integer = 8
        Select Case msg.Msg
            Case WM_SETFOCUS
                If msg.Msg = WM_SETFOCUS And Not SelectionHighlightEnabled Then
                    msg.Msg = WM_KILLFOCUS
                End If
        End Select
        MyBase.WndProc(msg)
    End Sub

    Private mSelectionHighlightEnabled As Boolean = True
    Public Property SelectionHighlightEnabled() As Boolean
        Get
            Return mSelectionHighlightEnabled
        End Get
        Set(ByVal value As Boolean)
            mSelectionHighlightEnabled = value
        End Set
    End Property

End Class
