﻿
Public Class SpeedRegulator

    Private mMotorSlot As Int32
    Private mSensorSlot As Int32


    Friend Sub New(ByVal MotorSlot As Int32, ByVal SensorSlot As Int32)
        mMotorSlot = MotorSlot
        mSensorSlot = SensorSlot
        mOldValue = CInt(Slots.ReadSlot_NoNan(mSensorSlot))
    End Sub


    ' ====================================================================
    '  COUNTER READER
    ' ====================================================================
    '  This reads a 16 bit Counter or an Encoder 
    ' ====================================================================
    '  Counter 
    '    When increases after 65535 restarts from zero
    ' ====================================================================
    '  Encoder 
    '    When increases after 65535 restarts from zero
    '    When decreases below 0 restarts from 65535
    ' ====================================================================

    Private Const Limit1 As Int32 = 16384
    Private Const Limit2 As Int32 = 49152
    Private Const Limit3 As Int32 = 65536


    Private mNewValue As Int32
    Private mOldValue As Int32
    Private mValue As Int32

    Friend Function Counter_ReadValue() As Int32
        mNewValue = CInt(Slots.ReadSlot_NoNan(mSensorSlot))
        If mNewValue <> mOldValue Then
            mValue += mNewValue - mOldValue
            If mNewValue > Limit2 And mOldValue < Limit1 Then mValue -= Limit3
            If mNewValue < Limit1 And mOldValue > Limit2 Then mValue += Limit3
            mOldValue = mNewValue
        End If
        Return mValue
    End Function

    Friend Sub CounterReset()
        mValue = 0
    End Sub



    ' ------------------------------------------------------------------------
    '  SPEED CONTROLLER WITH COUNTER CONVERTED TO FREQUENCY IN THE HAL
    ' ------------------------------------------------------------------------
    '  JoyPad with SlotArray.Length = 4 are for motors with the counter disk
    '  This sub is called from the activator thread every 5 milliseconds
    ' ------------------------------------------------------------------------
    '  This method is used with counter pins set as:
    '  - PinType = Counter
    '  - Convert to frequency
    '  - Response speed not pressed
    '  - Response Speed = 5
    '  - Min value = 0
    '  - Max value = 1000 (with 20 holes disk directly on the wheeel)
    '  - Max value =   20 (with disk on the motor shaft)
    ' ------------------------------------------------------------------------
    Friend Sub UpdateMotorWithSpeedDisk_Frequency(ByVal DesiredSpeed As Single)

        Dim freq As Single = Slots.ReadSlot_NoNan(mSensorSlot)
        If freq < 1 Then freq = 1
        If freq > 15 Then freq = 15

        Dim m As Single = 500 + (DesiredSpeed - 500) * 10 / freq

        MinMax_0_1000(m)
        Slots.WriteSlot(mMotorSlot, m)

        ' ------------------------------------------------------- debug
        'If mMotorSlot Mod 2 <> 0 Then
        '    Slots.WriteSlot(10, m)
        'Else
        '    Slots.WriteSlot(20, m)
        'End If
    End Sub



    ' ------------------------------------------------------------------------
    '  SPEED CONTROLLER WITH SIMPLE COUNTER
    ' ------------------------------------------------------------------------
    '  JoyPad with SlotArray.Length = 4 are for motors with the counter disk
    '  This sub is called from the activator thread every 5 milliseconds
    ' ------------------------------------------------------------------------
    '  This method is used with counter pins set as:
    '  - PinType = Counter
    '  - Convert to frequency = NOT USED
    ' ------------------------------------------------------------------------
    Private mDesiredCount As Single
    Private mOldSign As Single
    Private mSpeed As Single

    Friend Sub UpdateMotorsWithSpeedDisk_Counter(ByVal DesiredSpeed As Single)

        Dim count As Single = Counter_ReadValue()
        Dim abs As Single = Math.Abs(DesiredSpeed - 500)
        Dim sign As Single = Math.Sign(DesiredSpeed - 500)

        If sign <> mOldSign Then
            mOldSign = sign
            CounterReset()
            mDesiredCount = 0
            mSpeed = 0
        End If

        mDesiredCount += 0.0001F * abs

        If mDesiredCount > count + 10 Then mDesiredCount = count + 10

        If mDesiredCount < count - 10 Then mDesiredCount = count - 10

        Dim newspeed As Single
        If mDesiredCount > count Then
            newspeed = mSpeed + 1.0F
        Else
            newspeed = 1
            mDesiredCount = count
        End If

        'SmoothValue_Pow_Adaptive(mSpeed, (mDesiredCount - count) * 2.0F, 0.1)
        'SmoothValue_Simple(mSpeed, (mDesiredCount - count) * 0.1F, 0.1)

        SmoothValue_Simple(mSpeed, newspeed, 0.05)

        If mSpeed > 10 Then mSpeed = 10
        If mSpeed < 1 Then mSpeed = 1


        Dim m As Single = 500 + sign * abs * 0.1F * mSpeed

        MinMax_0_1000(m)
        Slots.WriteSlot(mMotorSlot, m)

        ' ------------------------------------------------------- debug
        'If mMotorSlot Mod 2 <> 0 Then
        '    Slots.WriteSlot(10, mDesiredCount)
        '    Slots.WriteSlot(11, count)
        '    Slots.WriteSlot(12, mDesiredCount - count)
        '    Slots.WriteSlot(13, mSpeed)
        'Else
        '    Slots.WriteSlot(20, mDesiredCount)
        '    Slots.WriteSlot(21, count)
        '    Slots.WriteSlot(22, mDesiredCount - count)
        '    Slots.WriteSlot(23, mSpeed)
        'End If

    End Sub

End Class
