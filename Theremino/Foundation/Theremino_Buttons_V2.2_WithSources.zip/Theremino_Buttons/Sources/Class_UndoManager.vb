﻿Public Class UndoManager(Of T)

    Private UndoStack As Stack(Of T) = New Stack(Of T)
    Private RedoStack As Stack(Of T) = New Stack(Of T)
    Private CurrentItem As T

    Friend Sub Clear()
        UndoStack.Clear()
        RedoStack.Clear()
        CurrentItem = Nothing
    End Sub

    Friend Sub AddEntry(ByVal item As T)
        If CurrentItem IsNot Nothing Then
            If item.ToString = CurrentItem.ToString Then Return
            UndoStack.Push(CurrentItem)
        End If
        CurrentItem = item
        RedoStack.Clear()
    End Sub

    Friend Function GetUndoEntry() As T
        RedoStack.Push(CurrentItem)
        CurrentItem = UndoStack.Pop()
        Return CurrentItem
    End Function

    Friend Function GetRedoEntry() As T
        UndoStack.Push(CurrentItem)
        CurrentItem = RedoStack.Pop
        Return CurrentItem
    End Function

    Friend Function CanUndo() As Boolean
        Return UndoStack.Count > 0
    End Function

    Friend Function CanRedo() As Boolean
        Return RedoStack.Count > 0
    End Function

End Class
