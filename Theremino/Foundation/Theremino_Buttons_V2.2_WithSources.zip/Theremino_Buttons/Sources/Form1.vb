﻿
' TODO main list
' ---------------------------------------------
' All done


' Done
' -------------------------------------
' Version 2.1
' Speed 1000 = 10 Hz / 100 = 1 Hz
' TouchPad working also when opening right mouse click
' New align controls method
' New file Save and Load method
' JoyPad exponential
' JoyPad MarkerPosition
' Speed 1000 = 10 Hz / 100 = 1 Hz
' JoyPad
' Edit with CTRL + Mouse
' Open edit with doubleclick on form1 

' Version 2.0
' Working also while editor is open
' Sort by control position before AutoLayout
' Undo

Public Class Form1

    ' ===============================================================
    '   PREVENT FORM FLICKERING -  With style WS_EX_COMPOSITED
    '   (double-buffering on the form and all its child controls) 
    ' ===============================================================
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.ExStyle = cp.ExStyle Or 33554432
            Return cp
        End Get
    End Property

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Text = AppTitleAndVersion()
        Form2.Activate()
        ClearActiveObjects()
        Load_INI()
        Load_Configuration()
        InitActiveObjects()
        Form2.UpdateUndoButtons()
        Form2.ShowHideActiveSlots(False)
        Refresh()
        Opacity = 1
        ActivatorThread_Start()
        Timer1.Interval = 10
        Timer1.Start()
        ResetAllJoyPadTo500()
        EventsAreEnabled = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ActivatorThread_Stop()
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        If Not TestModifiedConfiguration() Then
            e.Cancel = True
            Return
        End If
        Save_INI()
        Me.Refresh()
        ClosingApplication = True
        Form2.Close()
        End
    End Sub

    Private Sub form1_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Not EventsAreEnabled Then Return
        If Not Form2.Visible Then Return
        Form2.ShowSelectedObjProps()
    End Sub

    Private Sub Form1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        If My.Computer.Keyboard.CtrlKeyDown Or Form2.Visible Then
            Form2.StartEditing(-1)
        End If
    End Sub

    Private Sub Form1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.DoubleClick
        If Not Form2.Visible Then
            Form2.StartEditing(-1)
        End If
    End Sub

    Friend Sub ShowTextAndFile()
        Text = AppTitleAndVersion() + " - File: " + IO.Path.GetFileName(LastFilePathAndName)
    End Sub

    ' =============================================================================
    '  Overrides are for ResizeEnd not fired by form move
    ' =============================================================================
    Dim OldSize As Size
    Protected Overrides Sub OnShown(ByVal e As EventArgs)
        OldSize = Me.Size
        MyBase.OnShown(e)
    End Sub
    Protected Overrides Sub OnResizeEnd(ByVal e As EventArgs)
        If (Me.Size = OldSize) Then Return
        OldSize = Me.Size
        MyBase.OnResizeEnd(e)
        CreateConfigString()
        Undo1.AddEntry(ConfigurationString)
        Form2.UpdateUndoButtons()
        ConfigurationModified = True
    End Sub


    ' =============================================================================
    '  ALIGN CONTROLS
    ' =============================================================================
    Friend Sub AlignControls()
        Form2.CopyPlacementFromControlsToActiveObjectsArray()
        ReorderControls_FromPositions()
        CompactControls()
        SetFormSize()
        Save_INI()
        Form2.ShowSelectedObjProps()
    End Sub

    Friend Sub SetFormSize()
        Dim sz As Size = CalcTotalSize()
        Me.Width = sz.Width + 2 * SystemInformation.FrameBorderSize.Width + 6
        Me.Height = sz.Height + SystemInformation.CaptionHeight + SystemInformation.FrameBorderSize.Width + 14
    End Sub

    ' =============================================================================
    '  REORDER CONTROLS FROM POSITIONS
    ' =============================================================================
    Private VerticalTolerance As Int32
    Structure CtrlSort
        Dim i As Int32
        Dim x As Int32
        Dim y As Int32
    End Structure
    Private Sub ReorderControls_FromPositions()
        Dim csortarray(ActiveObjectsArray.Length - 1) As CtrlSort
        Dim minHeight As Int32 = Integer.MaxValue
        ' ----------------------------------------------------------- get locations and min height
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            Dim c As Control = New Control
            With ActiveObjectsArray(i)
                Select Case .Type
                    Case ActiveObjectType.Button : If .Button IsNot Nothing Then c = .Button
                    Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then c = .TextBox
                    Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then c = .JoyPad
                    Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then c = .ActiveSlotControl
                End Select
            End With
            csortarray(i).i = i
            csortarray(i).x = c.Left
            csortarray(i).y = c.Top
            If c.Height < minHeight Then minHeight = c.Height
        Next
        ' ------------------------------------------------------------ calculate VerticalTolerance
        VerticalTolerance = minHeight \ 2
        If VerticalTolerance < 5 Then VerticalTolerance = 5
        ' ------------------------------------------------------------ sort locations
        Array.Sort(csortarray, AddressOf csortComparer)
        ' ------------------------------------------------------------ debug sort test
        'For i As Int32 = 0 To ActiveObjectsArray.Length - 1
        '    Debug.Print(csortarray(i).x.ToString + "  " + csortarray(i).y.ToString)
        'Next
        ' ------------------------------------------------------------ reorder the ActiveObjectsArray
        Dim TempArray(ActiveObjectsArray.Length - 1) As ActiveObject
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            TempArray(i) = ActiveObjectsArray(csortarray(i).i)
        Next
        ActiveObjectsArray = TempArray
        ' ------------------------------------------------------------ 
        Form2.ReinitAllActiveObjects()
        Form2.Focus()
        Form2.ShowSelectedObjProps()
    End Sub
    Private Function csortComparer(ByVal c1 As CtrlSort, ByVal c2 As CtrlSort) As Integer
        If c1.x = c2.x And c1.y = c2.y Then Return 0
        If c2.y > c1.y + VerticalTolerance Then Return -1
        If c2.y < c1.y - VerticalTolerance Then Return 1
        If c2.x > c1.x Then Return -1
        Return 1
    End Function

    ' =============================================================================
    '  COMPACT CONTROLS
    ' =============================================================================
    Private Sub CompactControls()
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            Dim maxOverlap As Int32 = 50
            Dim margin As Int32 = 6
            Dim delta As Int32
            Dim GoUpMax As Int32
            Dim GoLeftMax As Int32
            With ActiveObjectsArray(i)
                GoUpMax = .Top - margin
                GoLeftMax = .Left - margin
                If GoUpMax < -maxOverlap Then GoUpMax = -maxOverlap
                If GoLeftMax < -maxOverlap Then GoLeftMax = -maxOverlap
                For j As Int32 = 0 To ActiveObjectsArray.Length - 1
                    If j = i Then Continue For
                    Dim ao As ActiveObject = ActiveObjectsArray(j)
                    ' -----------------------------------------------------
                    delta = .Top - (ao.Top + ao.Height) - margin
                    If delta >= -maxOverlap Then
                        If delta < GoUpMax Then GoUpMax = delta
                    End If
                    ' -----------------------------------------------------
                    delta = .Left - (ao.Left + ao.Width) - margin
                    If delta >= -maxOverlap Then
                        If delta < GoLeftMax Then GoLeftMax = delta
                    End If
                Next
                .Top -= GoUpMax
                .Left -= GoLeftMax
            End With
        Next
        Form2.CopyPlacementFromActiveObjectsArrayToControls()
        ' ------------------------------------------------------------ 
        Form2.ReinitAllActiveObjects()
        Form2.Focus()
        Form2.ShowSelectedObjProps()
    End Sub


    ' =============================================================================
    '  VISUALIZATION TIMER
    ' =============================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                Select Case .Type
                    Case ActiveObjectType.TextBox
                        If .TextBox Is Nothing Then Continue For
                        Dim m As Single = Slots.ReadSlot_NoNan(.MultiplierSlot)
                        If m = 0 Then Continue For
                        If .SlotArray Is Nothing OrElse .SlotArray.Length = 0 Then Continue For
                        Dim n As Single = Slots.ReadSlot_NoNan(.SlotArray(0))
                        '
                        If .Speed <= 0 Or .Speed >= 1000 Then
                            n *= m
                            .TextBox.Text = n.ToString("0", CI)
                        Else
                            If .SpeedCounter >= 1000 / .Speed Then
                                n = .accumulator
                                n /= .SpeedCounter
                                n *= m
                                .TextBox.Text = n.ToString("0", CI)
                                .SpeedCounter = 0
                                .accumulator = 0
                            Else
                                .accumulator += n
                                .SpeedCounter += 1
                            End If
                        End If
                    Case ActiveObjectType.JoyPad
                        If .JoyPad Is Nothing Then Continue For
                End Select
            End With
        Next
    End Sub


    ' =============================================================================
    '  Move controls with keys
    ' =============================================================================
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, ByVal keyData As Keys) As Boolean
        '
        If Not Form2.Visible Then Return MyBase.ProcessCmdKey(msg, keyData)
        '
        Dim x, y As Int32
        keyData = keyData And Not Keys.Shift And Not Keys.Control
        Select Case keyData
            Case Keys.Up : y = -1 : ControlMoved = True
            Case Keys.Down : y = 1 : ControlMoved = True
            Case Keys.Left : x = -1 : ControlMoved = True
            Case Keys.Right : x = 1 : ControlMoved = True
            Case Else : Return MyBase.ProcessCmdKey(msg, keyData)
        End Select
        '
        If My.Computer.Keyboard.ShiftKeyDown Then
            Form2.ChangeSelectedObjectPositionAndDimension(0, 0, x, y)
        Else
            Form2.ChangeSelectedObjectPositionAndDimension(x, y, 0, 0)
        End If
        '
        Return True
    End Function

    Private ControlMoved As Boolean
    Private Sub Form1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If Form2.Visible Then
            If ControlMoved Then
                Form2.ReinitAllActiveObjects()
            End If
        End If
    End Sub

End Class



