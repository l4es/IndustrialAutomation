﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.btn_BackColor = New System.Windows.Forms.Button
        Me.lbl_ObjectOrder = New System.Windows.Forms.Label
        Me.lbl_ObjectType = New System.Windows.Forms.Label
        Me.cmb_ObjectType = New System.Windows.Forms.ComboBox
        Me.btn_TextColor = New System.Windows.Forms.Button
        Me.gbox_SelectedObj = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmb_ObjTextAlign = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_Left = New Theremino_Buttons.MyTextBox
        Me.txt_Top = New Theremino_Buttons.MyTextBox
        Me.txt_Text = New System.Windows.Forms.TextBox
        Me.btn_TextFont = New System.Windows.Forms.Button
        Me.lbl_Text = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.txt_Slots = New System.Windows.Forms.TextBox
        Me.txt_TriggerSlot = New Theremino_Buttons.MyTextBox
        Me.txt_MultiplierSlot = New Theremino_Buttons.MyTextBox
        Me.txt_Random = New System.Windows.Forms.TextBox
        Me.txt_Speed = New System.Windows.Forms.TextBox
        Me.txt_Value = New System.Windows.Forms.TextBox
        Me.lbl_TriggerSlot = New System.Windows.Forms.Label
        Me.lbl_MultiplierSlot = New System.Windows.Forms.Label
        Me.lbl_Random = New System.Windows.Forms.Label
        Me.lbl_Speed = New System.Windows.Forms.Label
        Me.cmb_MoveType = New System.Windows.Forms.ComboBox
        Me.lbl_Value = New System.Windows.Forms.Label
        Me.lbl_Slot = New System.Windows.Forms.Label
        Me.txt_Height = New Theremino_Buttons.MyTextBox
        Me.txt_Width = New Theremino_Buttons.MyTextBox
        Me.btn_MoveAfter = New System.Windows.Forms.Button
        Me.btn_MoveBefore = New System.Windows.Forms.Button
        Me.btn_AlignControls = New System.Windows.Forms.Button
        Me.btn_FormBackColor = New System.Windows.Forms.Button
        Me.btn_Edit = New System.Windows.Forms.Button
        Me.gbox_Configuration = New System.Windows.Forms.GroupBox
        Me.btn_SaveConfiguration = New System.Windows.Forms.Button
        Me.btn_LoadConfiguration = New System.Windows.Forms.Button
        Me.btn_SaveAs = New System.Windows.Forms.Button
        Me.btn_AddFonts = New System.Windows.Forms.Button
        Me.gbox_Global = New System.Windows.Forms.GroupBox
        Me.cmb_gTextAlign = New System.Windows.Forms.ComboBox
        Me.txt_gWidth = New Theremino_Buttons.MyTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btn_gTextFont = New System.Windows.Forms.Button
        Me.txt_gHeight = New Theremino_Buttons.MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btn_gTextColor = New System.Windows.Forms.Button
        Me.btn_gBackColor = New System.Windows.Forms.Button
        Me.gbox_Objects = New System.Windows.Forms.GroupBox
        Me.btn_Redo = New System.Windows.Forms.Button
        Me.btn_Undo = New System.Windows.Forms.Button
        Me.btn_SelectPreviousObj = New System.Windows.Forms.Button
        Me.btn_SelectNextObj = New System.Windows.Forms.Button
        Me.btn_DeleteSelectedObj = New System.Windows.Forms.Button
        Me.btn_AddNewObj = New System.Windows.Forms.Button
        Me.gbox_Utilities = New System.Windows.Forms.GroupBox
        Me.cmb_CopyProperty = New System.Windows.Forms.ComboBox
        Me.btn_CopyProperty = New System.Windows.Forms.Button
        Me.gbox_SelectedObj.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.gbox_Configuration.SuspendLayout()
        Me.gbox_Global.SuspendLayout()
        Me.gbox_Objects.SuspendLayout()
        Me.gbox_Utilities.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_BackColor
        '
        Me.btn_BackColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_BackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_BackColor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_BackColor.ForeColor = System.Drawing.Color.Black
        Me.btn_BackColor.Location = New System.Drawing.Point(13, 193)
        Me.btn_BackColor.Name = "btn_BackColor"
        Me.btn_BackColor.Size = New System.Drawing.Size(158, 30)
        Me.btn_BackColor.TabIndex = 70
        Me.btn_BackColor.Text = "Back color"
        Me.btn_BackColor.UseVisualStyleBackColor = False
        '
        'lbl_ObjectOrder
        '
        Me.lbl_ObjectOrder.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ObjectOrder.ForeColor = System.Drawing.Color.Black
        Me.lbl_ObjectOrder.Location = New System.Drawing.Point(125, -1)
        Me.lbl_ObjectOrder.Name = "lbl_ObjectOrder"
        Me.lbl_ObjectOrder.Size = New System.Drawing.Size(33, 20)
        Me.lbl_ObjectOrder.TabIndex = 1
        Me.lbl_ObjectOrder.Text = "999"
        Me.lbl_ObjectOrder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_ObjectType
        '
        Me.lbl_ObjectType.AutoSize = True
        Me.lbl_ObjectType.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ObjectType.ForeColor = System.Drawing.Color.Black
        Me.lbl_ObjectType.Location = New System.Drawing.Point(9, 92)
        Me.lbl_ObjectType.Name = "lbl_ObjectType"
        Me.lbl_ObjectType.Size = New System.Drawing.Size(35, 16)
        Me.lbl_ObjectType.TabIndex = 3
        Me.lbl_ObjectType.Text = "Type"
        '
        'cmb_ObjectType
        '
        Me.cmb_ObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_ObjectType.ForeColor = System.Drawing.Color.Black
        Me.cmb_ObjectType.FormattingEnabled = True
        Me.cmb_ObjectType.Items.AddRange(New Object() {"Button", "TextBox", "JoyPad", "ActiveSlot"})
        Me.cmb_ObjectType.Location = New System.Drawing.Point(46, 88)
        Me.cmb_ObjectType.Name = "cmb_ObjectType"
        Me.cmb_ObjectType.Size = New System.Drawing.Size(126, 26)
        Me.cmb_ObjectType.TabIndex = 30
        '
        'btn_TextColor
        '
        Me.btn_TextColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_TextColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_TextColor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TextColor.ForeColor = System.Drawing.Color.Black
        Me.btn_TextColor.Location = New System.Drawing.Point(13, 157)
        Me.btn_TextColor.Name = "btn_TextColor"
        Me.btn_TextColor.Size = New System.Drawing.Size(158, 30)
        Me.btn_TextColor.TabIndex = 60
        Me.btn_TextColor.Text = "Text color"
        Me.btn_TextColor.UseVisualStyleBackColor = False
        '
        'gbox_SelectedObj
        '
        Me.gbox_SelectedObj.BackColor = System.Drawing.Color.BlanchedAlmond
        Me.gbox_SelectedObj.Controls.Add(Me.Label7)
        Me.gbox_SelectedObj.Controls.Add(Me.cmb_ObjTextAlign)
        Me.gbox_SelectedObj.Controls.Add(Me.Label5)
        Me.gbox_SelectedObj.Controls.Add(Me.Label6)
        Me.gbox_SelectedObj.Controls.Add(Me.Label3)
        Me.gbox_SelectedObj.Controls.Add(Me.Label4)
        Me.gbox_SelectedObj.Controls.Add(Me.txt_Left)
        Me.gbox_SelectedObj.Controls.Add(Me.txt_Top)
        Me.gbox_SelectedObj.Controls.Add(Me.txt_Text)
        Me.gbox_SelectedObj.Controls.Add(Me.btn_TextFont)
        Me.gbox_SelectedObj.Controls.Add(Me.lbl_Text)
        Me.gbox_SelectedObj.Controls.Add(Me.Panel1)
        Me.gbox_SelectedObj.Controls.Add(Me.txt_Height)
        Me.gbox_SelectedObj.Controls.Add(Me.txt_Width)
        Me.gbox_SelectedObj.Controls.Add(Me.btn_TextColor)
        Me.gbox_SelectedObj.Controls.Add(Me.btn_BackColor)
        Me.gbox_SelectedObj.Controls.Add(Me.lbl_ObjectOrder)
        Me.gbox_SelectedObj.Controls.Add(Me.lbl_ObjectType)
        Me.gbox_SelectedObj.Controls.Add(Me.cmb_ObjectType)
        Me.gbox_SelectedObj.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbox_SelectedObj.ForeColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gbox_SelectedObj.Location = New System.Drawing.Point(373, 11)
        Me.gbox_SelectedObj.Name = "gbox_SelectedObj"
        Me.gbox_SelectedObj.Size = New System.Drawing.Size(363, 276)
        Me.gbox_SelectedObj.TabIndex = 40
        Me.gbox_SelectedObj.TabStop = False
        Me.gbox_SelectedObj.Text = "Selected object"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(198, 10)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 16)
        Me.Label7.TabIndex = 72
        Me.Label7.Text = "Move type"
        '
        'cmb_ObjTextAlign
        '
        Me.cmb_ObjTextAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_ObjTextAlign.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ObjTextAlign.ForeColor = System.Drawing.Color.Black
        Me.cmb_ObjTextAlign.FormattingEnabled = True
        Me.cmb_ObjTextAlign.Items.AddRange(New Object() {"Left", "Center", "Right"})
        Me.cmb_ObjTextAlign.Location = New System.Drawing.Point(94, 123)
        Me.cmb_ObjTextAlign.Name = "cmb_ObjTextAlign"
        Me.cmb_ObjTextAlign.Size = New System.Drawing.Size(77, 26)
        Me.cmb_ObjTextAlign.TabIndex = 50
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(55, 230)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 16)
        Me.Label5.TabIndex = 1005
        Me.Label5.Text = "Left"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(15, 230)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 16)
        Me.Label6.TabIndex = 1004
        Me.Label6.Text = "Top"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(133, 230)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 16)
        Me.Label3.TabIndex = 1003
        Me.Label3.Text = "Height"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(92, 230)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 16)
        Me.Label4.TabIndex = 1002
        Me.Label4.Text = "Width"
        '
        'txt_Left
        '
        Me.txt_Left.ArrowsIncrement = 1
        Me.txt_Left.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_Left.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Left.Increment = 0.2
        Me.txt_Left.Location = New System.Drawing.Point(52, 247)
        Me.txt_Left.MaxLength = 4
        Me.txt_Left.MaxValue = 9999
        Me.txt_Left.MinValue = 0
        Me.txt_Left.Name = "txt_Left"
        Me.txt_Left.NumericValue = 9999
        Me.txt_Left.NumericValueInteger = 9999
        Me.txt_Left.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_Left.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_Left.RoundingStep = 0
        Me.txt_Left.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Left.Size = New System.Drawing.Size(40, 22)
        Me.txt_Left.TabIndex = 81
        Me.txt_Left.Text = "9999"
        Me.txt_Left.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Top
        '
        Me.txt_Top.ArrowsIncrement = 1
        Me.txt_Top.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_Top.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Top.Increment = 0.2
        Me.txt_Top.Location = New System.Drawing.Point(11, 247)
        Me.txt_Top.MaxLength = 4
        Me.txt_Top.MaxValue = 9999
        Me.txt_Top.MinValue = 0
        Me.txt_Top.Name = "txt_Top"
        Me.txt_Top.NumericValue = 9999
        Me.txt_Top.NumericValueInteger = 9999
        Me.txt_Top.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_Top.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_Top.RoundingStep = 0
        Me.txt_Top.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Top.Size = New System.Drawing.Size(40, 22)
        Me.txt_Top.TabIndex = 80
        Me.txt_Top.Text = "9999"
        Me.txt_Top.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Text
        '
        Me.txt_Text.Location = New System.Drawing.Point(15, 35)
        Me.txt_Text.Multiline = True
        Me.txt_Text.Name = "txt_Text"
        Me.txt_Text.Size = New System.Drawing.Size(157, 44)
        Me.txt_Text.TabIndex = 20
        Me.txt_Text.Text = "0"
        '
        'btn_TextFont
        '
        Me.btn_TextFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_TextFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_TextFont.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TextFont.ForeColor = System.Drawing.Color.Black
        Me.btn_TextFont.Location = New System.Drawing.Point(13, 121)
        Me.btn_TextFont.Name = "btn_TextFont"
        Me.btn_TextFont.Size = New System.Drawing.Size(74, 30)
        Me.btn_TextFont.TabIndex = 40
        Me.btn_TextFont.Text = "Text font"
        Me.btn_TextFont.UseVisualStyleBackColor = False
        '
        'lbl_Text
        '
        Me.lbl_Text.AutoSize = True
        Me.lbl_Text.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Text.ForeColor = System.Drawing.Color.Black
        Me.lbl_Text.Location = New System.Drawing.Point(7, 20)
        Me.lbl_Text.Name = "lbl_Text"
        Me.lbl_Text.Size = New System.Drawing.Size(32, 16)
        Me.lbl_Text.TabIndex = 20
        Me.lbl_Text.Text = "Text"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.txt_Slots)
        Me.Panel1.Controls.Add(Me.txt_TriggerSlot)
        Me.Panel1.Controls.Add(Me.txt_MultiplierSlot)
        Me.Panel1.Controls.Add(Me.txt_Random)
        Me.Panel1.Controls.Add(Me.txt_Speed)
        Me.Panel1.Controls.Add(Me.txt_Value)
        Me.Panel1.Controls.Add(Me.lbl_TriggerSlot)
        Me.Panel1.Controls.Add(Me.lbl_MultiplierSlot)
        Me.Panel1.Controls.Add(Me.lbl_Random)
        Me.Panel1.Controls.Add(Me.lbl_Speed)
        Me.Panel1.Controls.Add(Me.cmb_MoveType)
        Me.Panel1.Controls.Add(Me.lbl_Value)
        Me.Panel1.Controls.Add(Me.lbl_Slot)
        Me.Panel1.Location = New System.Drawing.Point(185, 14)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(173, 256)
        Me.Panel1.TabIndex = 999
        '
        'txt_Slots
        '
        Me.txt_Slots.Location = New System.Drawing.Point(47, 51)
        Me.txt_Slots.Name = "txt_Slots"
        Me.txt_Slots.Size = New System.Drawing.Size(116, 25)
        Me.txt_Slots.TabIndex = 10
        Me.txt_Slots.Text = "0"
        '
        'txt_TriggerSlot
        '
        Me.txt_TriggerSlot.ArrowsIncrement = 1
        Me.txt_TriggerSlot.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_TriggerSlot.Increment = 0.2
        Me.txt_TriggerSlot.Location = New System.Drawing.Point(104, 217)
        Me.txt_TriggerSlot.MaxValue = 999
        Me.txt_TriggerSlot.MinValue = -1
        Me.txt_TriggerSlot.Name = "txt_TriggerSlot"
        Me.txt_TriggerSlot.NumericValue = 0
        Me.txt_TriggerSlot.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_TriggerSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_TriggerSlot.RoundingStep = 0
        Me.txt_TriggerSlot.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_TriggerSlot.Size = New System.Drawing.Size(59, 25)
        Me.txt_TriggerSlot.TabIndex = 70
        Me.txt_TriggerSlot.Text = "0"
        '
        'txt_MultiplierSlot
        '
        Me.txt_MultiplierSlot.ArrowsIncrement = 1
        Me.txt_MultiplierSlot.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_MultiplierSlot.Increment = 0.2
        Me.txt_MultiplierSlot.Location = New System.Drawing.Point(104, 184)
        Me.txt_MultiplierSlot.MaxValue = 999
        Me.txt_MultiplierSlot.MinValue = -1
        Me.txt_MultiplierSlot.Name = "txt_MultiplierSlot"
        Me.txt_MultiplierSlot.NumericValue = 0
        Me.txt_MultiplierSlot.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_MultiplierSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_MultiplierSlot.RoundingStep = 0
        Me.txt_MultiplierSlot.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_MultiplierSlot.Size = New System.Drawing.Size(59, 25)
        Me.txt_MultiplierSlot.TabIndex = 60
        Me.txt_MultiplierSlot.Text = "0"
        '
        'txt_Random
        '
        Me.txt_Random.Location = New System.Drawing.Point(84, 151)
        Me.txt_Random.Name = "txt_Random"
        Me.txt_Random.Size = New System.Drawing.Size(79, 25)
        Me.txt_Random.TabIndex = 50
        Me.txt_Random.Text = "0"
        '
        'txt_Speed
        '
        Me.txt_Speed.Location = New System.Drawing.Point(84, 118)
        Me.txt_Speed.Name = "txt_Speed"
        Me.txt_Speed.Size = New System.Drawing.Size(79, 25)
        Me.txt_Speed.TabIndex = 40
        Me.txt_Speed.Text = "0"
        '
        'txt_Value
        '
        Me.txt_Value.Location = New System.Drawing.Point(84, 85)
        Me.txt_Value.Name = "txt_Value"
        Me.txt_Value.Size = New System.Drawing.Size(79, 25)
        Me.txt_Value.TabIndex = 30
        Me.txt_Value.Text = "0"
        '
        'lbl_TriggerSlot
        '
        Me.lbl_TriggerSlot.AutoSize = True
        Me.lbl_TriggerSlot.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TriggerSlot.ForeColor = System.Drawing.Color.Black
        Me.lbl_TriggerSlot.Location = New System.Drawing.Point(9, 220)
        Me.lbl_TriggerSlot.Name = "lbl_TriggerSlot"
        Me.lbl_TriggerSlot.Size = New System.Drawing.Size(74, 16)
        Me.lbl_TriggerSlot.TabIndex = 26
        Me.lbl_TriggerSlot.Text = "Trigger Slot"
        '
        'lbl_MultiplierSlot
        '
        Me.lbl_MultiplierSlot.AutoSize = True
        Me.lbl_MultiplierSlot.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_MultiplierSlot.ForeColor = System.Drawing.Color.Black
        Me.lbl_MultiplierSlot.Location = New System.Drawing.Point(9, 187)
        Me.lbl_MultiplierSlot.Name = "lbl_MultiplierSlot"
        Me.lbl_MultiplierSlot.Size = New System.Drawing.Size(87, 16)
        Me.lbl_MultiplierSlot.TabIndex = 24
        Me.lbl_MultiplierSlot.Text = "Multiplier Slot"
        '
        'lbl_Random
        '
        Me.lbl_Random.AutoSize = True
        Me.lbl_Random.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Random.ForeColor = System.Drawing.Color.Black
        Me.lbl_Random.Location = New System.Drawing.Point(9, 154)
        Me.lbl_Random.Name = "lbl_Random"
        Me.lbl_Random.Size = New System.Drawing.Size(56, 16)
        Me.lbl_Random.TabIndex = 22
        Me.lbl_Random.Text = "Random"
        '
        'lbl_Speed
        '
        Me.lbl_Speed.AutoSize = True
        Me.lbl_Speed.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Speed.ForeColor = System.Drawing.Color.Black
        Me.lbl_Speed.Location = New System.Drawing.Point(9, 120)
        Me.lbl_Speed.Name = "lbl_Speed"
        Me.lbl_Speed.Size = New System.Drawing.Size(45, 16)
        Me.lbl_Speed.TabIndex = 20
        Me.lbl_Speed.Text = "Speed"
        '
        'cmb_MoveType
        '
        Me.cmb_MoveType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_MoveType.ForeColor = System.Drawing.Color.Black
        Me.cmb_MoveType.FormattingEnabled = True
        Me.cmb_MoveType.Location = New System.Drawing.Point(11, 14)
        Me.cmb_MoveType.Name = "cmb_MoveType"
        Me.cmb_MoveType.Size = New System.Drawing.Size(152, 26)
        Me.cmb_MoveType.TabIndex = 5
        '
        'lbl_Value
        '
        Me.lbl_Value.AutoSize = True
        Me.lbl_Value.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Value.ForeColor = System.Drawing.Color.Black
        Me.lbl_Value.Location = New System.Drawing.Point(9, 88)
        Me.lbl_Value.Name = "lbl_Value"
        Me.lbl_Value.Size = New System.Drawing.Size(40, 16)
        Me.lbl_Value.TabIndex = 18
        Me.lbl_Value.Text = "Value"
        '
        'lbl_Slot
        '
        Me.lbl_Slot.AutoSize = True
        Me.lbl_Slot.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Slot.ForeColor = System.Drawing.Color.Black
        Me.lbl_Slot.Location = New System.Drawing.Point(8, 54)
        Me.lbl_Slot.Name = "lbl_Slot"
        Me.lbl_Slot.Size = New System.Drawing.Size(38, 16)
        Me.lbl_Slot.TabIndex = 16
        Me.lbl_Slot.Text = "Slots"
        '
        'txt_Height
        '
        Me.txt_Height.ArrowsIncrement = 1
        Me.txt_Height.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_Height.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Height.Increment = 0.2
        Me.txt_Height.Location = New System.Drawing.Point(134, 247)
        Me.txt_Height.MaxLength = 4
        Me.txt_Height.MaxValue = 9999
        Me.txt_Height.MinValue = 0
        Me.txt_Height.Name = "txt_Height"
        Me.txt_Height.NumericValue = 9999
        Me.txt_Height.NumericValueInteger = 9999
        Me.txt_Height.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_Height.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_Height.RoundingStep = 0
        Me.txt_Height.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Height.Size = New System.Drawing.Size(40, 22)
        Me.txt_Height.TabIndex = 83
        Me.txt_Height.Text = "9999"
        Me.txt_Height.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Width
        '
        Me.txt_Width.ArrowsIncrement = 1
        Me.txt_Width.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_Width.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Width.Increment = 0.2
        Me.txt_Width.Location = New System.Drawing.Point(93, 247)
        Me.txt_Width.MaxLength = 4
        Me.txt_Width.MaxValue = 9999
        Me.txt_Width.MinValue = 0
        Me.txt_Width.Name = "txt_Width"
        Me.txt_Width.NumericValue = 9999
        Me.txt_Width.NumericValueInteger = 9999
        Me.txt_Width.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_Width.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_Width.RoundingStep = 0
        Me.txt_Width.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Width.Size = New System.Drawing.Size(40, 22)
        Me.txt_Width.TabIndex = 82
        Me.txt_Width.Text = "9999"
        Me.txt_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_MoveAfter
        '
        Me.btn_MoveAfter.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_MoveAfter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_MoveAfter.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_MoveAfter.ForeColor = System.Drawing.Color.Black
        Me.btn_MoveAfter.Location = New System.Drawing.Point(11, 167)
        Me.btn_MoveAfter.Name = "btn_MoveAfter"
        Me.btn_MoveAfter.Size = New System.Drawing.Size(126, 30)
        Me.btn_MoveAfter.TabIndex = 60
        Me.btn_MoveAfter.Text = "Move after"
        Me.btn_MoveAfter.UseVisualStyleBackColor = False
        '
        'btn_MoveBefore
        '
        Me.btn_MoveBefore.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_MoveBefore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_MoveBefore.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_MoveBefore.ForeColor = System.Drawing.Color.Black
        Me.btn_MoveBefore.Location = New System.Drawing.Point(11, 135)
        Me.btn_MoveBefore.Name = "btn_MoveBefore"
        Me.btn_MoveBefore.Size = New System.Drawing.Size(126, 30)
        Me.btn_MoveBefore.TabIndex = 50
        Me.btn_MoveBefore.Text = "Move before"
        Me.btn_MoveBefore.UseVisualStyleBackColor = False
        '
        'btn_AlignControls
        '
        Me.btn_AlignControls.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_AlignControls.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_AlignControls.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AlignControls.ForeColor = System.Drawing.Color.Black
        Me.btn_AlignControls.Location = New System.Drawing.Point(12, 28)
        Me.btn_AlignControls.Name = "btn_AlignControls"
        Me.btn_AlignControls.Size = New System.Drawing.Size(156, 30)
        Me.btn_AlignControls.TabIndex = 10
        Me.btn_AlignControls.Text = "Align controls"
        Me.btn_AlignControls.UseVisualStyleBackColor = False
        '
        'btn_FormBackColor
        '
        Me.btn_FormBackColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_FormBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_FormBackColor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_FormBackColor.ForeColor = System.Drawing.Color.Black
        Me.btn_FormBackColor.Location = New System.Drawing.Point(12, 68)
        Me.btn_FormBackColor.Name = "btn_FormBackColor"
        Me.btn_FormBackColor.Size = New System.Drawing.Size(156, 30)
        Me.btn_FormBackColor.TabIndex = 20
        Me.btn_FormBackColor.Text = "Form back color"
        Me.btn_FormBackColor.UseVisualStyleBackColor = False
        '
        'btn_Edit
        '
        Me.btn_Edit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Edit.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Edit.ForeColor = System.Drawing.Color.Black
        Me.btn_Edit.Location = New System.Drawing.Point(99, 98)
        Me.btn_Edit.Name = "btn_Edit"
        Me.btn_Edit.Size = New System.Drawing.Size(59, 30)
        Me.btn_Edit.TabIndex = 40
        Me.btn_Edit.Text = "Edit"
        Me.btn_Edit.UseVisualStyleBackColor = False
        '
        'gbox_Configuration
        '
        Me.gbox_Configuration.BackColor = System.Drawing.Color.AliceBlue
        Me.gbox_Configuration.Controls.Add(Me.btn_SaveConfiguration)
        Me.gbox_Configuration.Controls.Add(Me.btn_LoadConfiguration)
        Me.gbox_Configuration.Controls.Add(Me.btn_SaveAs)
        Me.gbox_Configuration.Controls.Add(Me.btn_Edit)
        Me.gbox_Configuration.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbox_Configuration.ForeColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gbox_Configuration.Location = New System.Drawing.Point(9, 8)
        Me.gbox_Configuration.Name = "gbox_Configuration"
        Me.gbox_Configuration.Size = New System.Drawing.Size(169, 139)
        Me.gbox_Configuration.TabIndex = 10
        Me.gbox_Configuration.TabStop = False
        Me.gbox_Configuration.Text = "Configuration"
        '
        'btn_SaveConfiguration
        '
        Me.btn_SaveConfiguration.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_SaveConfiguration.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SaveConfiguration.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveConfiguration.ForeColor = System.Drawing.Color.Black
        Me.btn_SaveConfiguration.Location = New System.Drawing.Point(12, 61)
        Me.btn_SaveConfiguration.Name = "btn_SaveConfiguration"
        Me.btn_SaveConfiguration.Size = New System.Drawing.Size(146, 30)
        Me.btn_SaveConfiguration.TabIndex = 20
        Me.btn_SaveConfiguration.Text = "Save configuration"
        Me.btn_SaveConfiguration.UseVisualStyleBackColor = False
        '
        'btn_LoadConfiguration
        '
        Me.btn_LoadConfiguration.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_LoadConfiguration.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_LoadConfiguration.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LoadConfiguration.ForeColor = System.Drawing.Color.Black
        Me.btn_LoadConfiguration.Location = New System.Drawing.Point(12, 24)
        Me.btn_LoadConfiguration.Name = "btn_LoadConfiguration"
        Me.btn_LoadConfiguration.Size = New System.Drawing.Size(146, 30)
        Me.btn_LoadConfiguration.TabIndex = 10
        Me.btn_LoadConfiguration.Text = "Load configuration"
        Me.btn_LoadConfiguration.UseVisualStyleBackColor = False
        '
        'btn_SaveAs
        '
        Me.btn_SaveAs.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_SaveAs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SaveAs.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveAs.ForeColor = System.Drawing.Color.Black
        Me.btn_SaveAs.Location = New System.Drawing.Point(12, 98)
        Me.btn_SaveAs.Name = "btn_SaveAs"
        Me.btn_SaveAs.Size = New System.Drawing.Size(81, 30)
        Me.btn_SaveAs.TabIndex = 30
        Me.btn_SaveAs.Text = "Save as"
        Me.btn_SaveAs.UseVisualStyleBackColor = False
        '
        'btn_AddFonts
        '
        Me.btn_AddFonts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_AddFonts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_AddFonts.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AddFonts.ForeColor = System.Drawing.Color.Black
        Me.btn_AddFonts.Location = New System.Drawing.Point(12, 24)
        Me.btn_AddFonts.Name = "btn_AddFonts"
        Me.btn_AddFonts.Size = New System.Drawing.Size(146, 27)
        Me.btn_AddFonts.TabIndex = 10
        Me.btn_AddFonts.Text = "Add fonts"
        Me.btn_AddFonts.UseVisualStyleBackColor = False
        '
        'gbox_Global
        '
        Me.gbox_Global.BackColor = System.Drawing.Color.Cornsilk
        Me.gbox_Global.Controls.Add(Me.btn_FormBackColor)
        Me.gbox_Global.Controls.Add(Me.btn_AlignControls)
        Me.gbox_Global.Controls.Add(Me.cmb_gTextAlign)
        Me.gbox_Global.Controls.Add(Me.txt_gWidth)
        Me.gbox_Global.Controls.Add(Me.Label2)
        Me.gbox_Global.Controls.Add(Me.btn_gTextFont)
        Me.gbox_Global.Controls.Add(Me.txt_gHeight)
        Me.gbox_Global.Controls.Add(Me.Label1)
        Me.gbox_Global.Controls.Add(Me.btn_gTextColor)
        Me.gbox_Global.Controls.Add(Me.btn_gBackColor)
        Me.gbox_Global.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbox_Global.ForeColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gbox_Global.Location = New System.Drawing.Point(187, 11)
        Me.gbox_Global.Name = "gbox_Global"
        Me.gbox_Global.Size = New System.Drawing.Size(177, 276)
        Me.gbox_Global.TabIndex = 30
        Me.gbox_Global.TabStop = False
        Me.gbox_Global.Text = "Global"
        '
        'cmb_gTextAlign
        '
        Me.cmb_gTextAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_gTextAlign.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_gTextAlign.ForeColor = System.Drawing.Color.Black
        Me.cmb_gTextAlign.FormattingEnabled = True
        Me.cmb_gTextAlign.Items.AddRange(New Object() {"Left", "Center", "Right"})
        Me.cmb_gTextAlign.Location = New System.Drawing.Point(91, 121)
        Me.cmb_gTextAlign.Name = "cmb_gTextAlign"
        Me.cmb_gTextAlign.Size = New System.Drawing.Size(76, 26)
        Me.cmb_gTextAlign.TabIndex = 40
        '
        'txt_gWidth
        '
        Me.txt_gWidth.ArrowsIncrement = 1
        Me.txt_gWidth.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_gWidth.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gWidth.Increment = 0.2
        Me.txt_gWidth.Location = New System.Drawing.Point(40, 246)
        Me.txt_gWidth.MaxLength = 4
        Me.txt_gWidth.MaxValue = 9999
        Me.txt_gWidth.MinValue = 0
        Me.txt_gWidth.Name = "txt_gWidth"
        Me.txt_gWidth.NumericValue = 9999
        Me.txt_gWidth.NumericValueInteger = 9999
        Me.txt_gWidth.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_gWidth.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_gWidth.RoundingStep = 0
        Me.txt_gWidth.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_gWidth.Size = New System.Drawing.Size(40, 22)
        Me.txt_gWidth.TabIndex = 70
        Me.txt_gWidth.Text = "9999"
        Me.txt_gWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(104, 229)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 16)
        Me.Label2.TabIndex = 71
        Me.Label2.Text = "Height"
        '
        'btn_gTextFont
        '
        Me.btn_gTextFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_gTextFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_gTextFont.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_gTextFont.ForeColor = System.Drawing.Color.Black
        Me.btn_gTextFont.Location = New System.Drawing.Point(12, 119)
        Me.btn_gTextFont.Name = "btn_gTextFont"
        Me.btn_gTextFont.Size = New System.Drawing.Size(74, 30)
        Me.btn_gTextFont.TabIndex = 30
        Me.btn_gTextFont.Text = "Text font"
        Me.btn_gTextFont.UseVisualStyleBackColor = False
        '
        'txt_gHeight
        '
        Me.txt_gHeight.ArrowsIncrement = 1
        Me.txt_gHeight.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_gHeight.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gHeight.Increment = 0.2
        Me.txt_gHeight.Location = New System.Drawing.Point(108, 247)
        Me.txt_gHeight.MaxLength = 4
        Me.txt_gHeight.MaxValue = 9999
        Me.txt_gHeight.MinValue = 0
        Me.txt_gHeight.Name = "txt_gHeight"
        Me.txt_gHeight.NumericValue = 9999
        Me.txt_gHeight.NumericValueInteger = 9999
        Me.txt_gHeight.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_gHeight.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_gHeight.RoundingStep = 0
        Me.txt_gHeight.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_gHeight.Size = New System.Drawing.Size(40, 21)
        Me.txt_gHeight.TabIndex = 80
        Me.txt_gHeight.Text = "9999"
        Me.txt_gHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(39, 230)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 16)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Width"
        '
        'btn_gTextColor
        '
        Me.btn_gTextColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_gTextColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_gTextColor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_gTextColor.ForeColor = System.Drawing.Color.Black
        Me.btn_gTextColor.Location = New System.Drawing.Point(12, 156)
        Me.btn_gTextColor.Name = "btn_gTextColor"
        Me.btn_gTextColor.Size = New System.Drawing.Size(156, 30)
        Me.btn_gTextColor.TabIndex = 50
        Me.btn_gTextColor.Text = "Text color"
        Me.btn_gTextColor.UseVisualStyleBackColor = False
        '
        'btn_gBackColor
        '
        Me.btn_gBackColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_gBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_gBackColor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_gBackColor.ForeColor = System.Drawing.Color.Black
        Me.btn_gBackColor.Location = New System.Drawing.Point(12, 193)
        Me.btn_gBackColor.Name = "btn_gBackColor"
        Me.btn_gBackColor.Size = New System.Drawing.Size(156, 30)
        Me.btn_gBackColor.TabIndex = 60
        Me.btn_gBackColor.Text = "Back color"
        Me.btn_gBackColor.UseVisualStyleBackColor = False
        '
        'gbox_Objects
        '
        Me.gbox_Objects.BackColor = System.Drawing.Color.Honeydew
        Me.gbox_Objects.Controls.Add(Me.btn_Redo)
        Me.gbox_Objects.Controls.Add(Me.btn_Undo)
        Me.gbox_Objects.Controls.Add(Me.btn_SelectPreviousObj)
        Me.gbox_Objects.Controls.Add(Me.btn_SelectNextObj)
        Me.gbox_Objects.Controls.Add(Me.btn_DeleteSelectedObj)
        Me.gbox_Objects.Controls.Add(Me.btn_AddNewObj)
        Me.gbox_Objects.Controls.Add(Me.btn_MoveBefore)
        Me.gbox_Objects.Controls.Add(Me.btn_MoveAfter)
        Me.gbox_Objects.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbox_Objects.ForeColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gbox_Objects.Location = New System.Drawing.Point(745, 11)
        Me.gbox_Objects.Name = "gbox_Objects"
        Me.gbox_Objects.Size = New System.Drawing.Size(148, 276)
        Me.gbox_Objects.TabIndex = 50
        Me.gbox_Objects.TabStop = False
        Me.gbox_Objects.Text = "Objects"
        '
        'btn_Redo
        '
        Me.btn_Redo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_Redo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Redo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Redo.ForeColor = System.Drawing.Color.Black
        Me.btn_Redo.Location = New System.Drawing.Point(75, 26)
        Me.btn_Redo.Name = "btn_Redo"
        Me.btn_Redo.Size = New System.Drawing.Size(61, 30)
        Me.btn_Redo.TabIndex = 20
        Me.btn_Redo.Text = "Redo"
        Me.btn_Redo.UseVisualStyleBackColor = False
        '
        'btn_Undo
        '
        Me.btn_Undo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_Undo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Undo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Undo.ForeColor = System.Drawing.Color.Black
        Me.btn_Undo.Location = New System.Drawing.Point(11, 26)
        Me.btn_Undo.Name = "btn_Undo"
        Me.btn_Undo.Size = New System.Drawing.Size(61, 30)
        Me.btn_Undo.TabIndex = 10
        Me.btn_Undo.Text = "Undo"
        Me.btn_Undo.UseVisualStyleBackColor = False
        '
        'btn_SelectPreviousObj
        '
        Me.btn_SelectPreviousObj.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_SelectPreviousObj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SelectPreviousObj.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SelectPreviousObj.ForeColor = System.Drawing.Color.Black
        Me.btn_SelectPreviousObj.Location = New System.Drawing.Point(11, 66)
        Me.btn_SelectPreviousObj.Name = "btn_SelectPreviousObj"
        Me.btn_SelectPreviousObj.Size = New System.Drawing.Size(126, 30)
        Me.btn_SelectPreviousObj.TabIndex = 30
        Me.btn_SelectPreviousObj.Text = "Select previous"
        Me.btn_SelectPreviousObj.UseVisualStyleBackColor = False
        '
        'btn_SelectNextObj
        '
        Me.btn_SelectNextObj.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_SelectNextObj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_SelectNextObj.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SelectNextObj.ForeColor = System.Drawing.Color.Black
        Me.btn_SelectNextObj.Location = New System.Drawing.Point(11, 98)
        Me.btn_SelectNextObj.Name = "btn_SelectNextObj"
        Me.btn_SelectNextObj.Size = New System.Drawing.Size(126, 30)
        Me.btn_SelectNextObj.TabIndex = 40
        Me.btn_SelectNextObj.Text = "Select next"
        Me.btn_SelectNextObj.UseVisualStyleBackColor = False
        '
        'btn_DeleteSelectedObj
        '
        Me.btn_DeleteSelectedObj.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_DeleteSelectedObj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_DeleteSelectedObj.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_DeleteSelectedObj.ForeColor = System.Drawing.Color.Black
        Me.btn_DeleteSelectedObj.Location = New System.Drawing.Point(11, 237)
        Me.btn_DeleteSelectedObj.Name = "btn_DeleteSelectedObj"
        Me.btn_DeleteSelectedObj.Size = New System.Drawing.Size(126, 30)
        Me.btn_DeleteSelectedObj.TabIndex = 80
        Me.btn_DeleteSelectedObj.Text = "Delete selected"
        Me.btn_DeleteSelectedObj.UseVisualStyleBackColor = False
        '
        'btn_AddNewObj
        '
        Me.btn_AddNewObj.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_AddNewObj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_AddNewObj.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AddNewObj.ForeColor = System.Drawing.Color.Black
        Me.btn_AddNewObj.Location = New System.Drawing.Point(11, 205)
        Me.btn_AddNewObj.Name = "btn_AddNewObj"
        Me.btn_AddNewObj.Size = New System.Drawing.Size(126, 30)
        Me.btn_AddNewObj.TabIndex = 70
        Me.btn_AddNewObj.Text = "Add new object"
        Me.btn_AddNewObj.UseVisualStyleBackColor = False
        '
        'gbox_Utilities
        '
        Me.gbox_Utilities.BackColor = System.Drawing.Color.AliceBlue
        Me.gbox_Utilities.Controls.Add(Me.btn_AddFonts)
        Me.gbox_Utilities.Controls.Add(Me.cmb_CopyProperty)
        Me.gbox_Utilities.Controls.Add(Me.btn_CopyProperty)
        Me.gbox_Utilities.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbox_Utilities.ForeColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gbox_Utilities.Location = New System.Drawing.Point(9, 156)
        Me.gbox_Utilities.Name = "gbox_Utilities"
        Me.gbox_Utilities.Size = New System.Drawing.Size(169, 131)
        Me.gbox_Utilities.TabIndex = 20
        Me.gbox_Utilities.TabStop = False
        Me.gbox_Utilities.Text = "Utilities"
        '
        'cmb_CopyProperty
        '
        Me.cmb_CopyProperty.DropDownHeight = 300
        Me.cmb_CopyProperty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_CopyProperty.DropDownWidth = 150
        Me.cmb_CopyProperty.ForeColor = System.Drawing.Color.Black
        Me.cmb_CopyProperty.FormattingEnabled = True
        Me.cmb_CopyProperty.IntegralHeight = False
        Me.cmb_CopyProperty.Items.AddRange(New Object() {"All properties", "All colors", "Text", "Type", "Font", "Alignment", "Text color", "Back color", "Size", "Slot", "Value", "Speed", "Random", "Multiplier slot", "Trigger slot", "MoveType"})
        Me.cmb_CopyProperty.Location = New System.Drawing.Point(22, 89)
        Me.cmb_CopyProperty.MaxDropDownItems = 30
        Me.cmb_CopyProperty.Name = "cmb_CopyProperty"
        Me.cmb_CopyProperty.Size = New System.Drawing.Size(127, 26)
        Me.cmb_CopyProperty.TabIndex = 30
        '
        'btn_CopyProperty
        '
        Me.btn_CopyProperty.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btn_CopyProperty.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_CopyProperty.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CopyProperty.ForeColor = System.Drawing.Color.Black
        Me.btn_CopyProperty.Location = New System.Drawing.Point(11, 60)
        Me.btn_CopyProperty.Name = "btn_CopyProperty"
        Me.btn_CopyProperty.Size = New System.Drawing.Size(147, 61)
        Me.btn_CopyProperty.TabIndex = 20
        Me.btn_CopyProperty.Text = "Copy"
        Me.btn_CopyProperty.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_CopyProperty.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.MintCream
        Me.ClientSize = New System.Drawing.Size(900, 292)
        Me.Controls.Add(Me.gbox_Utilities)
        Me.Controls.Add(Me.gbox_Objects)
        Me.Controls.Add(Me.gbox_Global)
        Me.Controls.Add(Me.gbox_Configuration)
        Me.Controls.Add(Me.gbox_SelectedObj)
        Me.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Buttons - Properties"
        Me.gbox_SelectedObj.ResumeLayout(False)
        Me.gbox_SelectedObj.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gbox_Configuration.ResumeLayout(False)
        Me.gbox_Global.ResumeLayout(False)
        Me.gbox_Global.PerformLayout()
        Me.gbox_Objects.ResumeLayout(False)
        Me.gbox_Utilities.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_BackColor As System.Windows.Forms.Button
    Friend WithEvents lbl_ObjectOrder As System.Windows.Forms.Label
    Friend WithEvents lbl_ObjectType As System.Windows.Forms.Label
    Friend WithEvents cmb_ObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents btn_TextColor As System.Windows.Forms.Button
    Friend WithEvents gbox_SelectedObj As System.Windows.Forms.GroupBox
    Friend WithEvents btn_FormBackColor As System.Windows.Forms.Button
    Friend WithEvents btn_Edit As System.Windows.Forms.Button
    Friend WithEvents gbox_Configuration As System.Windows.Forms.GroupBox
    Friend WithEvents gbox_Global As System.Windows.Forms.GroupBox
    Friend WithEvents btn_gTextColor As System.Windows.Forms.Button
    Friend WithEvents btn_gBackColor As System.Windows.Forms.Button
    Friend WithEvents btn_MoveAfter As System.Windows.Forms.Button
    Friend WithEvents btn_MoveBefore As System.Windows.Forms.Button
    Friend WithEvents btn_LoadConfiguration As System.Windows.Forms.Button
    Friend WithEvents btn_SaveAs As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_gWidth As MyTextBox
    Friend WithEvents txt_gHeight As MyTextBox
    Friend WithEvents txt_Height As MyTextBox
    Friend WithEvents txt_Width As MyTextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txt_Text As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Text As System.Windows.Forms.Label
    Friend WithEvents lbl_Slot As System.Windows.Forms.Label
    Friend WithEvents txt_Slots As System.Windows.Forms.TextBox
    Friend WithEvents lbl_TriggerSlot As System.Windows.Forms.Label
    Friend WithEvents txt_TriggerSlot As MyTextBox
    Friend WithEvents lbl_MultiplierSlot As System.Windows.Forms.Label
    Friend WithEvents txt_MultiplierSlot As MyTextBox
    Friend WithEvents lbl_Random As System.Windows.Forms.Label
    Friend WithEvents txt_Random As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Speed As System.Windows.Forms.Label
    Friend WithEvents txt_Speed As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Value As System.Windows.Forms.Label
    Friend WithEvents txt_Value As System.Windows.Forms.TextBox
    Friend WithEvents btn_AddFonts As System.Windows.Forms.Button
    Friend WithEvents gbox_Objects As System.Windows.Forms.GroupBox
    Friend WithEvents gbox_Utilities As System.Windows.Forms.GroupBox
    Friend WithEvents btn_SelectPreviousObj As System.Windows.Forms.Button
    Friend WithEvents btn_SelectNextObj As System.Windows.Forms.Button
    Friend WithEvents btn_DeleteSelectedObj As System.Windows.Forms.Button
    Friend WithEvents btn_AddNewObj As System.Windows.Forms.Button
    Friend WithEvents btn_gTextFont As System.Windows.Forms.Button
    Friend WithEvents btn_TextFont As System.Windows.Forms.Button
    Friend WithEvents cmb_CopyProperty As System.Windows.Forms.ComboBox
    Friend WithEvents btn_CopyProperty As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_Left As MyTextBox
    Friend WithEvents txt_Top As MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmb_ObjTextAlign As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_gTextAlign As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmb_MoveType As System.Windows.Forms.ComboBox
    Friend WithEvents btn_Undo As System.Windows.Forms.Button
    Friend WithEvents btn_Redo As System.Windows.Forms.Button
    Friend WithEvents btn_AlignControls As System.Windows.Forms.Button
    Friend WithEvents btn_SaveConfiguration As System.Windows.Forms.Button
End Class
