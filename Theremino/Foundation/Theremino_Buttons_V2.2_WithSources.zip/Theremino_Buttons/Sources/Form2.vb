﻿Public Class Form2

    Private FontDialog1 As FontDialog = New FontDialog
    Private ColorDialog1 As ColorDialog = New ColorDialog

    ' =============================================================================
    '  FORM EVENTS
    ' =============================================================================
    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ShowTextAndFile()
        btn_Edit.Focus()
    End Sub

    Friend Sub ShowTextAndFile()
        Text = AppTitleAndVersion("") + " --- File : " + IO.Path.GetFileName(LastFilePathAndName)
    End Sub

    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        mObjIndex = -1
        SetCopyPropertyFlag(False)
        If Not ClosingApplication Then
            ShowHideActiveSlots(False)
            Me.Hide()
            e.Cancel = True
        End If
        Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
    End Sub

    Private Sub Form2_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub


    ' =============================================================================
    '  START EDIT
    ' =============================================================================
    Friend mObjIndex As Int32

    Friend Sub StartEditing(ByVal objIndex As Int32)
        mObjIndex = objIndex
        ShowSelectedObjProps()
        Me.WindowState = FormWindowState.Normal
        If Not Me.Visible Then
            ShowHideActiveSlots(True)
            Me.Show()
            Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
            Form1.Focus()
            ' ------------------------------------------------------ Save the first Undo configuration
            If Not Undo1.CanUndo Then
                CreateConfigString()
                Undo1.AddEntry(ConfigurationString)
            End If
        End If
    End Sub

    Friend Sub ShowHideActiveSlots(ByVal visible As Boolean)
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                If .Type = ActiveObjectType.ActiveSlot Then
                    .ActiveSlotControl.Visible = visible
                End If
            End With
        Next
    End Sub

    Friend Sub ShowSelectedObjProps()
        EventsAreEnabled = False
        ' -------------------------------------- Globals
        Combo_SetIndex_FromString(cmb_gTextAlign, gTextAlign.ToString)
        txt_gWidth.Text = gWidth.ToString
        txt_gHeight.Text = gHeight.ToString
        ' -------------------------------------- Selected object
        If mObjIndex < 0 Then
            mObjIndex = 0
        End If
        If mObjIndex > ActiveObjectsArray.Length - 1 Then
            mObjIndex = ActiveObjectsArray.Length - 1
        End If
        If mObjIndex >= 0 Then
            With ActiveObjectsArray(mObjIndex)
                Combo_SetIndex_FromString(cmb_ObjectType, .Type.ToString)
                txt_Top.Text = .Top.ToString
                txt_Left.Text = .Left.ToString
                txt_Width.Text = .Width.ToString
                txt_Height.Text = .Height.ToString
                txt_Text.Text = .Text
                txt_Slots.Text = .SlotString
                lbl_Value.Text = "Value"
                lbl_Speed.Text = "Speed"
                lbl_Random.Text = "Random"
                lbl_MultiplierSlot.Text = "MultiplierSlot"
                lbl_TriggerSlot.Text = "TriggerSlot"
                Select Case .Type
                    Case ActiveObjectType.Button
                        '
                        cmb_MoveType.Items.Clear()
                        cmb_MoveType.Items.Add("Normal")
                        cmb_MoveType.Items.Add("Partial")
                        cmb_MoveType.Items.Add("Pulse")
                        Combo_SetIndex_FromString(cmb_MoveType, .MoveType)
                        '
                        Combo_SetIndex_FromString(cmb_ObjTextAlign, .ContentAlign.ToString.Replace("Middle", ""))
                        txt_Value.Text = .Value.ToString(CI) : txt_Value.Enabled = True
                        txt_Speed.Text = .Speed.ToString(CI) : txt_Speed.Enabled = True
                        txt_Random.Text = .Random.ToString(CI) : txt_Random.Enabled = True
                        txt_MultiplierSlot.Text = "" : txt_MultiplierSlot.Enabled = False
                        txt_TriggerSlot.Text = "" : txt_TriggerSlot.Enabled = False
                    Case ActiveObjectType.TextBox
                        '
                        cmb_MoveType.Items.Clear()
                        cmb_MoveType.Items.Add("Normal")
                        Combo_SetIndex_FromString(cmb_MoveType, .MoveType)
                        '
                        Combo_SetIndex_FromString(cmb_ObjTextAlign, .TextAlign.ToString)
                        txt_Value.Text = "" : txt_Value.Enabled = False
                        txt_Speed.Text = .Speed.ToString(CI) : txt_Speed.Enabled = True
                        txt_Random.Text = "" : txt_Random.Enabled = False
                        txt_MultiplierSlot.Text = .MultiplierSlot.ToString : txt_MultiplierSlot.Enabled = True
                        txt_TriggerSlot.Text = "" : txt_TriggerSlot.Enabled = False
                    Case ActiveObjectType.JoyPad
                        '
                        cmb_MoveType.Items.Clear()
                        cmb_MoveType.Items.Add("JoyPad")
                        cmb_MoveType.Items.Add("JoyPad (autozero)")
                        cmb_MoveType.Items.Add("JoyPad (counter)")
                        cmb_MoveType.Items.Add("Joy (counter-auto)")
                        cmb_MoveType.Items.Add("JoyPad (freq)")
                        cmb_MoveType.Items.Add("JoyPad (freq-auto)")
                        cmb_MoveType.Items.Add("X/Y")
                        cmb_MoveType.Items.Add("X/Y(autozero)")
                        Combo_SetIndex_FromString(cmb_MoveType, .MoveType)
                        '
                        Combo_SetIndex_FromString(cmb_ObjTextAlign, .TextAlign.ToString)
                        If .MoveType.StartsWith("Joy") Then
                            lbl_Value.Text = "Speed"
                            lbl_Speed.Text = "Steer (fast)"
                            lbl_Random.Text = "Steer (slow)"
                            lbl_MultiplierSlot.Text = ""
                            lbl_TriggerSlot.Text = ""
                            txt_Value.Text = .Value.ToString(CI) : txt_Value.Enabled = True
                            txt_Speed.Text = .Speed.ToString(CI) : txt_Speed.Enabled = True
                            txt_Random.Text = .Random.ToString(CI) : txt_Random.Enabled = True
                        Else
                            txt_Value.Text = "" : txt_Value.Enabled = False
                            txt_Speed.Text = "" : txt_Speed.Enabled = False
                            txt_Random.Text = "" : txt_Random.Enabled = False
                        End If
                        txt_MultiplierSlot.Text = "" : txt_MultiplierSlot.Enabled = False
                        txt_TriggerSlot.Text = "" : txt_TriggerSlot.Enabled = False
                    Case ActiveObjectType.ActiveSlot
                        '
                        cmb_MoveType.Items.Clear()
                        cmb_MoveType.Items.Add("Normal")
                        cmb_MoveType.Items.Add("OnOff")
                        cmb_MoveType.Items.Add("Sine")
                        Combo_SetIndex_FromString(cmb_MoveType, .MoveType)
                        '
                        Combo_SetIndex_FromString(cmb_ObjTextAlign, .ContentAlign.ToString.Replace("Middle", ""))
                        txt_Value.Text = .Value.ToString(CI) : txt_Value.Enabled = True
                        txt_Speed.Text = .Speed.ToString(CI) : txt_Speed.Enabled = True
                        txt_Random.Text = .Random.ToString(CI) : txt_Random.Enabled = True
                        txt_MultiplierSlot.Text = "" : txt_MultiplierSlot.Enabled = False
                        txt_TriggerSlot.Text = .TriggerSlot.ToString : txt_TriggerSlot.Enabled = True
                End Select
            End With
            gbox_SelectedObj.Enabled = True
        Else
            gbox_SelectedObj.Enabled = False
        End If
        lbl_ObjectOrder.Text = (mObjIndex + 1).ToString
        ' -------------------------------------- 
        EventsAreEnabled = True
        '
        ShowSelectedObjBorder()
    End Sub

    Private BorderPen As Pen = New Pen(Color.Green, 2)
    Private SelectedObjBorderVisible As Boolean
    Friend Sub ShowSelectedObjBorder()
        InitPanelImageAndGraphics(Form1)
        If mObjIndex >= 0 Then
            SelectedObjBorderVisible = True
            Dim p As Point
            Dim s As Size
            With ActiveObjectsArray(mObjIndex)
                If .TextBox IsNot Nothing Then
                    p = .TextBox.Location
                    s = .TextBox.Size
                End If
                If .Button IsNot Nothing Then
                    p = .Button.Location
                    s = .Button.Size
                End If
                If .JoyPad IsNot Nothing Then
                    p = .JoyPad.Location
                    s = .JoyPad.Size
                End If
                If .ActiveSlotControl IsNot Nothing Then
                    p = .ActiveSlotControl.Location
                    s = .ActiveSlotControl.Size
                End If
            End With
            FormGraphics.Clear(If(CopyPropertyFlag, CopyHilightColor, gFormColor))
            FormGraphics.FillRectangle(Brushes.Yellow, p.X - 5, p.Y - 5, s.Width + 10, s.Height + 10)
            FormGraphics.DrawRectangle(BorderPen, p.X - 5, p.Y - 5, s.Width + 10, s.Height + 10)
            Form1.Refresh()
        Else
            HideSelectedObjBorder()
        End If
    End Sub

    Friend Sub HideSelectedObjBorder()
        If Not SelectedObjBorderVisible Then Return
        SelectedObjBorderVisible = False
        FormGraphics.Clear(gFormColor)
        Form1.Refresh()
    End Sub

    Private FormGraphics As Graphics
    Private Sub InitPanelImageAndGraphics(ByVal frm As Form)
        With frm
            If .ClientSize.Width < 1 Or .ClientSize.Height < 1 Then Return
            If .BackgroundImage Is Nothing _
                        OrElse .BackgroundImage.Width <> .ClientSize.Width _
                        OrElse .BackgroundImage.Height <> .ClientSize.Height Then
                .BackgroundImage = New Bitmap(.ClientRectangle.Width, _
                                              .ClientRectangle.Height, _
                                              Imaging.PixelFormat.Format24bppRgb)
                FormGraphics = Graphics.FromImage(.BackgroundImage)
                FormGraphics.Clear(Form1.BackColor)
            End If
        End With
    End Sub



    ' =============================================================================
    '  SAVE/LOAD CONFIGURATION
    ' =============================================================================

    Private Sub btn_LoadConfiguration_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_LoadConfiguration.Click
        Dialog_LoadConf()
    End Sub

    Private Sub btn_SaveConfiguration_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveConfiguration.Click
        Save_Configuration()
    End Sub

    Private Sub btn_SaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveAs.Click
        Dialog_SaveConf()
    End Sub

    ' =============================================================================
    '  EDIT CONFIGURATION
    ' =============================================================================
    Private Sub btn_Edit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Edit.Click
        Form1.Opacity = 0.5
        Me.Opacity = 0.5
        Form1.Enabled = False
        Me.Enabled = False
        ProcessStartAndWait(LastFilePathAndName)
        SendKeys.Flush()
        Form1.Opacity = 1
        Me.Opacity = 1
        Form1.Enabled = True
        Me.Enabled = True
        Reload_Configuration()
        Me.Focus()
        ShowSelectedObjProps()
    End Sub

    Friend Sub Reload_Configuration()
        ActivatorThread_Stop()
        ActiveSlots.Clear()
        ClearActiveObjects()
        Load_Configuration()
        InitActiveObjects()
        ActivatorThread_Start()
    End Sub

    Friend Sub ReinitAllActiveObjects()
        CreateConfigString()
        Undo1.AddEntry(ConfigurationString)
        UpdateUndoButtons()
        ActivatorThread_Stop()
        ActiveSlots.Clear()
        ClearActiveObjects()
        DecodeConfigString(ConfigurationString)
        InitActiveObjects()
        ActivatorThread_Start()
        ConfigurationModified = True
    End Sub


    ' =============================================================================
    '  EDIT UTILITIES
    ' =============================================================================
    Private Sub btn_AddFonts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AddFonts.Click
        AddFonts()
    End Sub

    Private Sub btn_CopyProperty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CopyProperty.Click
        SetCopyPropertyFlag(Not CopyPropertyFlag)
    End Sub

    Private Sub SetCopyPropertyFlag(ByVal newFlagValue As Boolean)
        CopyPropertyFlag = newFlagValue
        If CopyPropertyFlag Then
            Form1.BackColor = CopyHilightColor
            btn_CopyProperty.Text = "Click destination obj"
            btn_CopyProperty.ForeColor = Color.White
            btn_CopyProperty.BackColor = Color.OrangeRed
            gbox_SelectedObj.BackColor = Color.Gold
        Else
            Form1.BackColor = gFormColor
            btn_CopyProperty.Text = "Copy"
            btn_CopyProperty.ForeColor = Color.Black
            btn_CopyProperty.BackColor = Color.FromArgb(255, 240, 150)
            gbox_SelectedObj.BackColor = Color.BlanchedAlmond
        End If
        ShowSelectedObjBorder()
    End Sub

    Friend Sub CopyProperty(ByVal DestObjIndex As Int32)
        Dim srcObj As ActiveObject = ActiveObjectsArray(mObjIndex)
        With ActiveObjectsArray(DestObjIndex)
            Select Case cmb_CopyProperty.Text
                Case "All properties"
                    .Type = srcObj.Type
                    .TextFont = srcObj.TextFont
                    .TextAlign = srcObj.TextAlign
                    .ContentAlign = srcObj.ContentAlign
                    .TextColor = srcObj.TextColor
                    .BackColor = srcObj.BackColor
                    .Left = srcObj.Left : .Top = srcObj.Top
                    .Width = srcObj.Width : .Height = srcObj.Height
                    .Text = srcObj.Text
                    .SlotString = srcObj.SlotString
                    .SlotArray = srcObj.SlotArray
                    .Value = srcObj.Value
                    .Speed = srcObj.Speed
                    .Random = srcObj.Random
                    .MultiplierSlot = srcObj.MultiplierSlot
                    .TriggerSlot = srcObj.TriggerSlot
                    .MoveType = srcObj.MoveType
                Case "All colors"
                    .TextColor = srcObj.TextColor
                    .BackColor = srcObj.BackColor
                Case "Text" : .Text = srcObj.Text
                Case "Type" : .Type = srcObj.Type
                Case "Font" : .TextFont = srcObj.TextFont
                Case "Alignment"
                    .TextAlign = srcObj.TextAlign
                    .ContentAlign = srcObj.ContentAlign
                Case "Text color" : .TextColor = srcObj.TextColor
                Case "Back color" : .BackColor = srcObj.BackColor
                Case "Size"
                    .Width = srcObj.Width
                    .Height = srcObj.Height
                Case "Slot"
                    .SlotString = srcObj.SlotString
                    .SlotArray = srcObj.SlotArray
                Case "Value" : .Value = srcObj.Value
                Case "Speed" : .Speed = srcObj.Speed
                Case "Random" : .Random = srcObj.Random
                Case "Multiplier slot" : .MultiplierSlot = srcObj.MultiplierSlot
                Case "Trigger slot" : .TriggerSlot = srcObj.TriggerSlot
                Case "MoveType" : .MoveType = srcObj.MoveType
            End Select
        End With
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub


    ' =============================================================================
    '  EDIT FORM PROPS
    ' =============================================================================
    Private Sub btn_AlignControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AlignControls.Click
        Form1.AlignControls()
        ShowSelectedObjBorder()
        Form1.Focus()
    End Sub

    Private Sub btn_FormBackColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_FormBackColor.Click
        ColorDialog1.Color = gFormColor
        SendKeys.Send("{TAB}{TAB}{ENTER}")
        If ColorDialog1.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            gFormColor = ColorDialog1.Color
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjBorder()
        End If
    End Sub

    ' =============================================================================
    '  EDIT GLOBALS
    ' =============================================================================
    Private Sub btn_gTextFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_gTextFont.Click
        FontDialog1.Font = gTextFont
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            gTextFont = FontDialog1.Font
            For i As Int32 = 0 To ActiveObjectsArray.Length - 1
                ActiveObjectsArray(i).TextFont = gTextFont
            Next
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub
    Private Sub cmb_gTextAlign_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_gTextAlign.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        gTextAlign = cmb_gTextAlign.Text
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                .ContentAlign = DecodeContentAlignment(gTextAlign)
                .TextAlign = DecodeHorizontalAlignment(gTextAlign)
            End With
        Next
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjProps()
    End Sub
    Private Sub btn_gTextColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_gTextColor.Click
        ColorDialog1.Color = gTextColor
        SendKeys.Send("{TAB}{TAB}{ENTER}")
        If ColorDialog1.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            gTextColor = ColorDialog1.Color
            For i As Int32 = 0 To ActiveObjectsArray.Length - 1
                ActiveObjectsArray(i).TextColor = gTextColor
            Next
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub
    Private Sub btn_gBackColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_gBackColor.Click
        ColorDialog1.Color = gBackColor
        SendKeys.Send("{TAB}{TAB}{ENTER}")
        If ColorDialog1.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            gBackColor = ColorDialog1.Color
            For i As Int32 = 0 To ActiveObjectsArray.Length - 1
                ActiveObjectsArray(i).BackColor = gBackColor
            Next
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub

    Private Sub txt_gSizeW_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_gWidth.TextChanged
        If Not EventsAreEnabled Then Return
        gWidth = CInt(Val(txt_gWidth.Text))
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            ActiveObjectsArray(i).Width = gWidth
        Next
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub
    Private Sub txt_gSizeH_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_gHeight.TextChanged
        If Not EventsAreEnabled Then Return
        gHeight = CInt(Val(txt_gHeight.Text))
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            ActiveObjectsArray(i).Height = gHeight
        Next
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub


    ' =============================================================================
    '  EDIT SELECTED OBJECT
    ' =============================================================================
    Private Sub txt_Text_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Text.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Text = txt_Text.Text
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub

    Private Sub cmb_ObjectType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ObjectType.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        If mObjIndex < 0 Then Return
        With ActiveObjectsArray(mObjIndex)
            Select Case cmb_ObjectType.SelectedItem.ToString
                Case "Button"
                    .Type = ActiveObjectType.Button
                    InitObjectDefaultProps(mObjIndex, "Button")
                    If .Text = "TextBox" Or .Text = "JoyPad" Or .Text = "ActiveSlot" Then .Text = "Button"
                Case "TextBox"
                    .Type = ActiveObjectType.TextBox
                    InitObjectDefaultProps(mObjIndex, "TextBox")
                    If .Text = "Button" Or .Text = "JoyPad" Or .Text = "ActiveSlot" Then .Text = "TextBox"
                Case "JoyPad"
                    .Type = ActiveObjectType.JoyPad
                    InitObjectDefaultProps(mObjIndex, "JoyPad")
                    If .Text = "Button" Or .Text = "TextBox" Or .Text = "ActiveSlot" Then .Text = "JoyPad"
                Case "ActiveSlot"
                    .Type = ActiveObjectType.ActiveSlot
                    InitObjectDefaultProps(mObjIndex, "ActiveSlot")
                    If .Text = "Button" Or .Text = "JoyPad" Or .Text = "TextBox" Then .Text = "ActiveSlot"
            End Select
        End With
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjProps()
    End Sub
    Private Sub cmb_ObjTextAlign_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_ObjTextAlign.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        If mObjIndex < 0 Then Return
        AlignmentFromText(mObjIndex, cmb_ObjTextAlign.Text)
        ShowSelectedObjProps()
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub

    Private Sub AlignmentFromText(ByVal objindex As Int32, ByVal alignment As String)
        With ActiveObjectsArray(objindex)
            Select Case .Type
                Case ActiveObjectType.TextBox
                    Select Case alignment
                        Case "Left" : .TextBox.TextAlign = HorizontalAlignment.Left
                        Case "Center" : .TextBox.TextAlign = HorizontalAlignment.Center
                        Case "Right" : .TextBox.TextAlign = HorizontalAlignment.Right
                    End Select
                    ActiveObjectsArray(objindex).TextAlign = DecodeHorizontalAlignment(alignment)
                Case ActiveObjectType.Button
                    Select Case alignment
                        Case "Left" : .Button.TextAlign = ContentAlignment.MiddleLeft
                        Case "Center" : .Button.TextAlign = ContentAlignment.MiddleCenter
                        Case "Right" : .Button.TextAlign = ContentAlignment.MiddleRight
                    End Select
                    ActiveObjectsArray(objindex).ContentAlign = DecodeContentAlignment(alignment)
                Case ActiveObjectType.JoyPad
                    Select Case alignment
                        Case "Left" : .JoyPad.TextAlign = HorizontalAlignment.Left
                        Case "Center" : .JoyPad.TextAlign = HorizontalAlignment.Center
                        Case "Right" : .JoyPad.TextAlign = HorizontalAlignment.Right
                    End Select
                    ActiveObjectsArray(objindex).TextAlign = DecodeHorizontalAlignment(alignment)
                Case ActiveObjectType.ActiveSlot
                    Select Case alignment
                        Case "Left" : .ActiveSlotControl.TextAlign = ContentAlignment.MiddleLeft
                        Case "Center" : .ActiveSlotControl.TextAlign = ContentAlignment.MiddleCenter
                        Case "Right" : .ActiveSlotControl.TextAlign = ContentAlignment.MiddleRight
                    End Select
                    ActiveObjectsArray(objindex).ContentAlign = DecodeContentAlignment(alignment)
            End Select
        End With
    End Sub

    Private Sub btn_TextFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_TextFont.Click
        FontDialog1.Font = ActiveObjectsArray(mObjIndex).TextFont
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            ActiveObjectsArray(mObjIndex).TextFont = FontDialog1.Font
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub

    Private Sub btn_TextColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_TextColor.Click
        ColorDialog1.Color = ActiveObjectsArray(mObjIndex).TextColor
        SendKeys.Send("{TAB}{TAB}{ENTER}")
        If ColorDialog1.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            ActiveObjectsArray(mObjIndex).TextColor = ColorDialog1.Color
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub
    Private Sub btn_BackColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_BackColor.Click
        ColorDialog1.Color = ActiveObjectsArray(mObjIndex).BackColor
        SendKeys.Send("{TAB}{TAB}{ENTER}")
        If ColorDialog1.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            ActiveObjectsArray(mObjIndex).BackColor = ColorDialog1.Color
            ReinitAllActiveObjects()
            Me.Focus()
        End If
    End Sub

    Private Sub txt_Left_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Left.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Left = CInt(Val(txt_Left.Text))
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub
    Private Sub txt_Top_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Top.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Top = CInt(Val(txt_Top.Text))
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub
    Private Sub txt_SizeW_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Width.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Width = CInt(Val(txt_Width.Text))
       ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub
    Private Sub txt_SizeH_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Height.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Height = CInt(Val(txt_Height.Text))
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjBorder()
    End Sub


    ' =============================================================================
    '  SLOTS PROPERTIES
    ' =============================================================================
    Private Sub txt_Slot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Slots.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).SlotString = txt_Slots.Text
        ActiveObjectsArray(mObjIndex).SlotArray = StringToSlotArray(txt_Slots.Text)
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub txt_Value_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Value.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Value = CSng(Val(txt_Value.Text))
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub txt_Speed_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Speed.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Speed = CSng(Val(txt_Speed.Text))
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub txt_Random_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Random.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).Random = CSng(Val(txt_Random.Text))
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub txt_MultiplierSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_MultiplierSlot.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).MultiplierSlot = CInt(Val(txt_MultiplierSlot.Text))
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub txt_TriggerSlot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_TriggerSlot.TextChanged
        If Not EventsAreEnabled Then Return
        ActiveObjectsArray(mObjIndex).TriggerSlot = CInt(Val(txt_TriggerSlot.Text))
        ReinitAllActiveObjects()
        Me.Focus()
    End Sub
    Private Sub cmb_MoveType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_MoveType.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        If mObjIndex < 0 Then Return
        ActiveObjectsArray(mObjIndex).MoveType = cmb_MoveType.Text
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjProps()
    End Sub


    ' =============================================================================
    '  EDIT OBJECTS
    ' =============================================================================
    Private Sub btn_Undo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Undo.Click
        If Undo1.CanUndo Then
            ActivatorThread_Stop()
            ActiveSlots.Clear()
            ClearActiveObjects()
            DecodeConfigString(Undo1.GetUndoEntry())
            UpdateUndoButtons()
            InitActiveObjects()
            ActivatorThread_Start()
            ShowSelectedObjProps()
            Me.Focus()
        End If
    End Sub
    Private Sub btn_Redo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Redo.Click
        If Undo1.CanRedo Then
            ActivatorThread_Stop()
            ActiveSlots.Clear()
            ClearActiveObjects()
            DecodeConfigString(Undo1.GetRedoEntry())
            UpdateUndoButtons()
            InitActiveObjects()
            ActivatorThread_Start()
            ShowSelectedObjProps()
            Me.Focus()
        End If
    End Sub
    Friend Sub UpdateUndoButtons()
        btn_Undo.Enabled = Undo1.CanUndo
        btn_Redo.Enabled = Undo1.CanRedo
        ConfigurationModified = btn_Undo.Enabled
    End Sub

    Private Sub btn_SelectPreviousObj_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SelectPreviousObj.Click
        If mObjIndex > 0 Then
            mObjIndex -= 1
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjProps()
        End If
    End Sub
    Private Sub btn_SelectNextObj_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SelectNextObj.Click
        If mObjIndex < ActiveObjectsArray.Length - 1 Then
            mObjIndex += 1
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjProps()
        End If
    End Sub

    Private Sub btn_MoveBefore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_MoveBefore.Click
        If mObjIndex > 0 Then
            Swap(ActiveObjectsArray(mObjIndex), ActiveObjectsArray(mObjIndex - 1))
            SwapGraphicControlsLocations(mObjIndex, mObjIndex - 1)
            mObjIndex -= 1
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjProps()
        End If
    End Sub
    Private Sub btn_MoveAfter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_MoveAfter.Click
        If mObjIndex < ActiveObjectsArray.Length - 1 Then
            Swap(ActiveObjectsArray(mObjIndex), ActiveObjectsArray(mObjIndex + 1))
            SwapGraphicControlsLocations(mObjIndex, mObjIndex + 1)
            mObjIndex += 1
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjProps()
        End If
    End Sub

    Private Sub btn_AddNewObj_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AddNewObj.Click
        Form1.AutoSize = True
        ReDim Preserve ActiveObjectsArray(ActiveObjectsArray.Length)
        If ActiveObjectsArray.Length = 1 Then
            mObjIndex = 0
            InitObjectDefaultProps(mObjIndex, "Button")
            ActiveObjectsArray(mObjIndex).Text = "Button"
        Else
            For i As Int32 = ActiveObjectsArray.Length - 2 To mObjIndex Step -1
                ActiveObjectsArray(i + 1) = ActiveObjectsArray(i)
            Next
            mObjIndex += 1

            Dim obj As ActiveObject = ActiveObjectsArray(mObjIndex - 1)
            With ActiveObjectsArray(mObjIndex)
                .Left = obj.Left + 30
                .Top = obj.Top + 30
            End With
        End If
        ReinitAllActiveObjects()
        Me.Focus()
        ShowSelectedObjProps()
        Dim s As Size = Form1.Size
        Form1.AutoSize = False
        Form1.Size = s
    End Sub
    Private Sub btn_DeleteSelectedObj_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_DeleteSelectedObj.Click
        If mObjIndex >= 0 Then
            For i As Int32 = mObjIndex To ActiveObjectsArray.Length - 2
                ActiveObjectsArray(i) = ActiveObjectsArray(i + 1)
            Next
            If mObjIndex >= ActiveObjectsArray.Length - 1 Then mObjIndex -= 1
            ReDim Preserve ActiveObjectsArray(ActiveObjectsArray.Length - 2)
            ReinitAllActiveObjects()
            Me.Focus()
            ShowSelectedObjProps()
        End If
    End Sub


    ' =============================================================================
    '  EDIT OBJECTS POSITION WITH ARROWS
    ' =============================================================================
    Friend Sub ChangeSelectedObjectPositionAndDimension(ByVal dx As Int32, _
                                                        ByVal dy As Int32, _
                                                        ByVal dw As Int32, _
                                                        ByVal dh As Int32)
        With ActiveObjectsArray(mObjIndex)
            If txt_Left.Enabled Then .Left += dx
            If txt_Top.Enabled Then .Top += dy
            .Width += dw
            .Height += dh
            '
            Limit(.Left, 0, 1999)
            Limit(.Top, 0, 1999)
            Limit(.Width, 10, 1999)
            Limit(.Height, 10, 1999)
            '
            If .TextBox IsNot Nothing Then
                .TextBox.Left = .Left
                .TextBox.Top = .Top
                .TextBox.Width = .Width
                .TextBox.Height = .Height
            End If
            If .Button IsNot Nothing Then
                .Button.Left = .Left
                .Button.Top = .Top
                .Button.Width = .Width
                .Button.Height = .Height
            End If
            If .JoyPad IsNot Nothing Then
                .JoyPad.Left = .Left
                .JoyPad.Top = .Top
                .JoyPad.Width = .Width
                .JoyPad.Height = .Height
            End If
            If .ActiveSlotControl IsNot Nothing Then
                .ActiveSlotControl.Left = .Left
                .ActiveSlotControl.Top = .Top
                .ActiveSlotControl.Width = .Width
                .ActiveSlotControl.Height = .Height
            End If
            '
            EventsAreEnabled = False
            txt_Left.Text = .Left.ToString
            txt_Top.Text = .Top.ToString
            txt_Width.Text = .Width.ToString
            txt_Height.Text = .Height.ToString
            EventsAreEnabled = True
        End With
        '
        HideSelectedObjBorder()
    End Sub

    Private Sub Limit(ByRef n As Int32, ByVal min As Int32, ByVal max As Int32)
        If n < min Then n = min
        If n > max Then n = max
    End Sub

    Friend Sub CopyPlacementFromControlsToActiveObjectsArray()
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                If .TextBox IsNot Nothing Then
                    .Left = .TextBox.Left
                    .Top = .TextBox.Top
                    .Width = .TextBox.Width
                    .Height = .TextBox.Height
                End If
                If .Button IsNot Nothing Then
                    .Left = .Button.Left
                    .Top = .Button.Top
                    .Width = .Button.Width
                    .Height = .Button.Height
                End If
                If .JoyPad IsNot Nothing Then
                    .Left = .JoyPad.Left
                    .Top = .JoyPad.Top
                    .Width = .JoyPad.Width
                    .Height = .JoyPad.Height
                End If
                If .ActiveSlotControl IsNot Nothing Then
                    .Left = .ActiveSlotControl.Left
                    .Top = .ActiveSlotControl.Top
                    .Width = .ActiveSlotControl.Width
                    .Height = .ActiveSlotControl.Height
                End If
            End With
        Next
    End Sub

    Friend Sub CopyPlacementFromActiveObjectsArrayToControls()
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                If .TextBox IsNot Nothing Then
                    .TextBox.Left = .Left
                    .TextBox.Top = .Top
                    .TextBox.Width = .Width
                    .TextBox.Height = .Height
                End If
                If .Button IsNot Nothing Then
                    .Button.Left = .Left
                    .Button.Top = .Top
                    .Button.Width = .Width
                    .Button.Height = .Height
                End If
                If .JoyPad IsNot Nothing Then
                    .JoyPad.Left = .Left
                    .JoyPad.Top = .Top
                    .JoyPad.Width = .Width
                    .JoyPad.Height = .Height
                End If
                If .ActiveSlotControl IsNot Nothing Then
                    .ActiveSlotControl.Left = .Left
                    .ActiveSlotControl.Top = .Top
                    .ActiveSlotControl.Width = .Width
                    .ActiveSlotControl.Height = .Height
                End If
            End With
        Next
    End Sub

End Class