﻿
Module Module_ActivatorThread

    ' =========================================================================
    '  WINDOWS SCHEDULER PRECISION
    ' ========================================================================= 
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Sub SchedulerMaxPrecision()
        If OperatingSystemIsWindows Then
            timeBeginPeriod(1)
        End If
    End Sub
    Private Sub SchedulerDefaultPrecision()
        If OperatingSystemIsWindows Then
            timeEndPeriod(1)
        End If
    End Sub

    ' =========================================================================
    '  ACTIVATOR THREAD
    ' ========================================================================= 
    Private ActivatorThread As System.Threading.Thread
    Private ThreadStopFlag As Boolean
    Private ThreadWorking As Boolean

    Friend Sub ActivatorThread_Start()
        ActivatorThread = New System.Threading.Thread(AddressOf ActivatorThread_Loop)
        ActivatorThread.Start()
        SchedulerMaxPrecision()
    End Sub

    Friend Sub ActivatorThread_Stop()
        ThreadStopFlag = True
        Do
            Threading.Thread.Sleep(10)
        Loop Until ThreadWorking = False
        SchedulerDefaultPrecision()
    End Sub

    Private Sub ActivatorThread_Loop()
        ThreadWorking = True
        Do
            Try
                ' -------------------------------------------------------------- activate ActiveSlots
                For i As Int32 = 0 To ActiveSlots.ActiveSlotsArray.Length - 1
                    ActiveSlots.ActiveSlotsArray(i).MoveSingleStep(i)
                Next
                ' -------------------------------------------------------------- activate ActiveObjects
                For i As Int32 = 0 To ActiveObjectsArray.Length - 1
                    With ActiveObjectsArray(i)
                        If .Type = ActiveObjectType.JoyPad Then
                            If .SpeedFeedbackType = SpeedFeedbackTypes.Frequency Then
                                .SpeedReg1.UpdateMotorWithSpeedDisk_Frequency(.Out1)
                                .SpeedReg2.UpdateMotorWithSpeedDisk_Frequency(.Out2)
                            ElseIf .SpeedFeedbackType = SpeedFeedbackTypes.Counter Then
                                .SpeedReg1.UpdateMotorsWithSpeedDisk_Counter(.Out1)
                                .SpeedReg2.UpdateMotorsWithSpeedDisk_Counter(.Out2)
                            End If
                        End If
                    End With
                Next
            Catch
            End Try
            Threading.Thread.Sleep(5)
        Loop Until ThreadStopFlag
        ThreadStopFlag = False
        ThreadWorking = False
    End Sub

End Module
