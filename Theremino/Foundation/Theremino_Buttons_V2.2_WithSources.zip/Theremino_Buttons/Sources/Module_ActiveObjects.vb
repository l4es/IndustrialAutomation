﻿
' ===================================================================
'  DATA FLOW
' ===================================================================
' File "Configuration.txt"
' Sub  "Load_Configuration"
'    Global parameters to : gButtonWidth, gButtonHeight, gFormColor, gBackColor, gTextColor, gTextFont, gTextSize, gTextBold
'    Single parameters to : Array "ActiveObjects" As "ActiveObject"
'
' Sub  "InitActiveObjects"
'    If ActiveObjects(i) is button
'       INITIALIZE Button
'    Else
'       ActiveSlots.AddActiveSlot
'
' ButtonClickHandler
'    ActiveSlots.AddActiveSlot


Module ActiveObjects

    Friend Structure ActiveObject
        Dim ArrayIndex As Int32
        Dim MousePressed As Boolean
        Dim Button As ActiveButton
        Dim TextBox As ActiveTextBox
        Dim JoyPad As ActiveJoyPad
        Dim ActiveSlotControl As ActiveSlotControl
        Dim Type As ActiveObjectType
        Dim MoveType As String
        Dim SlotString As String
        Dim SlotArray() As Int32
        Dim pos As Single
        Dim Value As Single
        Dim Speed As Single
        Dim Random As Single
        Dim accumulator As Single
        Dim SpeedCounter As Single
        Dim MultiplierSlot As Int32
        Dim TriggerSlot As Int32
        Dim PulseTimer As Int32
        Dim Text As String
        Dim TextAlign As HorizontalAlignment
        Dim ContentAlign As ContentAlignment
        Dim TextFont As Font
        Dim TextColor As Color
        Dim BackColor As Color
        Dim Left As Int32
        Dim Top As Int32
        Dim Width As Int32
        Dim Height As Int32
        Dim PadX, PadY As Single
        Dim Out1, Out2 As Single
        ' ---------------------------------- speed controllers with counters disks
        Dim JoyPadType As JoyPadTypes
        Dim AutoZero As Boolean
        Dim SpeedFeedbackType As SpeedFeedbackTypes
        Dim SpeedReg1 As SpeedRegulator
        Dim SpeedReg2 As SpeedRegulator
    End Structure

    Friend Enum ActiveObjectType
        Button
        TextBox
        JoyPad
        ActiveSlot
    End Enum

    Friend Enum SpeedFeedbackTypes
        None
        Frequency
        Counter
    End Enum

    Friend Enum JoyPadTypes
        JoyPad
        XY
    End Enum

    Friend ActiveObjectsArray(-1) As ActiveObject

    Friend gFormColor As Color = Color.White
    Friend gTextFont As Font = New Font("Arial", 12)
    Friend gTextColor As Color = Color.Black
    Friend gBackColor As Color = Color.White
    Friend gTextAlign As String = "Center"
    Friend gWidth As Int32 = 120
    Friend gHeight As Int32 = 90


    ' =============================================================================
    '  ACTIVE OBJECTS - INIT
    ' =============================================================================
    Friend Sub ClearActiveObjects()
        Form1.Controls.Clear()
        ReDim ActiveObjectsArray(-1)
    End Sub

    Friend Sub InitActiveObjects()
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            Dim obj As ActiveObject = ActiveObjectsArray(i)
            Select Case obj.Type
                Case ActiveObjectType.Button
                    obj.Button = New ActiveButton
                    Form1.Controls.Add(obj.Button)
                    With obj.Button
                        .Parent = Form1
                        .Tag = i.ToString
                        .FlatStyle = FlatStyle.Flat
                        '.Margin = New Padding(3, 3, 3, 3)
                        '.FlatAppearance.BorderColor = Color.DarkGreen
                        '.FlatAppearance.BorderSize = 0
                        .Text = obj.Text
                        .TextAlign = obj.ContentAlign
                        .Font = obj.TextFont
                        .ForeColor = obj.TextColor
                        .BackColor = obj.BackColor
                        .Left = obj.Left
                        .Top = obj.Top
                        .Size = New Size(obj.Width, obj.Height)
                        AddHandler .Click, AddressOf ClickHandler
                        AddHandler .PointerDown, AddressOf MouseDownHandler
                        AddHandler .MouseDown, AddressOf MouseDownHandler
                        AddHandler .MouseUp, AddressOf MouseUpHandler
                        AddHandler .MouseMove, AddressOf MouseMoveHandler
                    End With
                Case ActiveObjectType.TextBox
                    obj.TextBox = New ActiveTextBox
                    obj.TextBox.Text = obj.Text
                    Form1.Controls.Add(obj.TextBox)
                    With obj.TextBox
                        .TabStop = False
                        .Parent = Form1
                        .Tag = i.ToString
                        .Multiline = True
                        .ReadOnly = True
                        .SelectionHighlightEnabled = False
                        .Text = obj.Text
                        .TextAlign = obj.TextAlign
                        .Font = obj.TextFont
                        .ForeColor = obj.TextColor
                        .BackColor = obj.BackColor
                        .Left = obj.Left
                        .Top = obj.Top
                        .Size = New Size(obj.Width, obj.Height)
                        AddHandler .Click, AddressOf ClickHandler
                        AddHandler .MouseDown, AddressOf MouseDownHandler
                        AddHandler .MouseUp, AddressOf MouseUpHandler
                        AddHandler .MouseMove, AddressOf MouseMoveHandler
                    End With
                Case ActiveObjectType.JoyPad
                    obj.JoyPad = New ActiveJoyPad
                    Form1.Controls.Add(obj.JoyPad)
                    obj.Out1 = 500
                    obj.Out2 = 500
                    With obj.JoyPad
                        .Parent = Form1
                        .Tag = i.ToString
                        .Margin = New Padding(3, 3, 3, 3)
                        .BorderStyle = BorderStyle.Fixed3D
                        .Cursor = Cursors.Default
                        .Text = obj.Text
                        .TextAlign = obj.TextAlign
                        .Font = obj.TextFont
                        .ForeColor = obj.TextColor
                        .BackColor = obj.BackColor
                        .Left = obj.Left
                        .Top = obj.Top
                        .Size = New Size(obj.Width, obj.Height)
                        AddHandler .Click, AddressOf ClickHandler
                        AddHandler .PointerDown, AddressOf MouseDownHandler
                        AddHandler .MouseDown, AddressOf MouseDownHandler
                        AddHandler .MouseUp, AddressOf MouseUpHandler
                        'AddHandler .MouseMove, AddressOf MouseMoveHandler
                        AddHandler .MouseAndPointerMove, AddressOf MouseMoveHandler
                    End With
                    With obj
                        ' ------------------------------------------------------- Joypad types
                        Dim s As String = .MoveType.ToLower
                        If s.Contains("joy") Then
                            .JoyPadType = JoyPadTypes.JoyPad
                        Else
                            obj.JoyPadType = JoyPadTypes.XY
                        End If
                        obj.AutoZero = s.Contains("auto")
                        ' ------------------------------------------------------- speed controllers
                        obj.SpeedFeedbackType = SpeedFeedbackTypes.None
                        If obj.SlotArray.Length = 4 Then
                            If s.Contains("freq") Then obj.SpeedFeedbackType = SpeedFeedbackTypes.Frequency
                            If s.Contains("count") Then obj.SpeedFeedbackType = SpeedFeedbackTypes.Counter
                            obj.SpeedReg1 = New SpeedRegulator(obj.SlotArray(0), obj.SlotArray(2))
                            obj.SpeedReg2 = New SpeedRegulator(obj.SlotArray(1), obj.SlotArray(3))
                        End If
                    End With
                Case ActiveObjectType.ActiveSlot
                    obj.ActiveSlotControl = New ActiveSlotControl
                    Form1.Controls.Add(obj.ActiveSlotControl)
                    With obj.ActiveSlotControl
                        .TabStop = False
                        .Parent = Form1
                        .Tag = i.ToString
                        .FlatStyle = FlatStyle.Flat
                        .Text = obj.Text
                        .TextAlign = obj.ContentAlign
                        .Font = obj.TextFont
                        .ForeColor = obj.TextColor
                        .BackColor = obj.BackColor
                        .Left = obj.Left
                        .Top = obj.Top
                        .Size = New Size(obj.Width, obj.Height)
                        AddHandler .Click, AddressOf ClickHandler
                        AddHandler .MouseDown, AddressOf MouseDownHandler
                        AddHandler .MouseUp, AddressOf MouseUpHandler
                        AddHandler .MouseMove, AddressOf MouseMoveHandler
                    End With
                    ActiveSlots.AddActiveSlot(obj)
            End Select
            obj.ArrayIndex = i
            ActiveObjectsArray(i) = obj
        Next
    End Sub


    ' =============================================================================
    '  ACTIVE OBJECTS - CLICK
    ' =============================================================================
    Friend CopyPropertyFlag As Boolean
    Friend CopyHilightColor As Color = Color.OrangeRed

    Private Sub ClickHandler(ByVal sender As Object, ByVal e As EventArgs)
        Dim i As Int32 = GetActiveObjectIndex(sender)
        ' ---------------------------------------------------------- change obj props
        If CopyPropertyFlag Then
            Form2.CopyProperty(i)
            Return
        End If
        ' ---------------------------------------------------------- start editing
        If My.Computer.Keyboard.CtrlKeyDown Or Form2.Visible Then
            Form2.StartEditing(i)
        End If
    End Sub

    Private Function GetActiveObjectIndex(ByVal ctrl As Object) As Int32
        Dim n As Int32
        If TypeOf ctrl Is Button Then
            Dim b As System.Windows.Forms.Button = CType(ctrl, System.Windows.Forms.Button)
            n = CInt(Val(b.Tag))
        ElseIf TypeOf ctrl Is TextBox Then
            Dim t As System.Windows.Forms.TextBox = CType(ctrl, System.Windows.Forms.TextBox)
            n = CInt(Val(t.Tag))
        ElseIf TypeOf ctrl Is PictureBox Then
            Dim t As System.Windows.Forms.PictureBox = CType(ctrl, System.Windows.Forms.PictureBox)
            n = CInt(Val(t.Tag))
        ElseIf TypeOf ctrl Is ActiveSlotControl Then
            Dim t As ActiveSlotControl = CType(ctrl, ActiveSlotControl)
            n = CInt(Val(t.Tag))
        End If
        Return n
    End Function


    ' =============================================================================
    '  DRAG CONTROLS
    ' =============================================================================
    Private Dragging As Boolean
    Private StartMousePos As Point
    Private StartControlPos As Point
    Private StartControlSize As Size
    Private Sub MouseDownHandler(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim i As Int32 = GetActiveObjectIndex(sender)
        Dim obj As ActiveObject = ActiveObjectsArray(i)
        ' ----------------------------------------------------------
        If Form2.Visible And (My.Computer.Keyboard.CtrlKeyDown Or My.Computer.Keyboard.ShiftKeyDown) Then
            If Not CopyPropertyFlag Then
                Dim c As Control = CType(sender, Control)
                c.BringToFront()
                StartControlPos = c.Location
                StartControlSize = c.Size
                StartMousePos = Cursor.Position
                Dragging = True
                Form2.HideSelectedObjBorder()
                Return
            End If
        End If
        ' ---------------------------------------------------------- JoyPad MouseDown
        If TypeOf sender Is ActiveJoyPad Then
            JoyPadExec(sender, e, False)
            Cursor.Clip = obj.JoyPad.RectangleToScreen(obj.JoyPad.ClientRectangle)
        End If
        ' ---------------------------------------------------------- exclude TextBox and MyActiveSlotLabel
        If TypeOf sender Is ActiveTextBox Or _
           TypeOf sender Is ActiveSlotControl Then Return
        ' ---------------------------------------------------------- exclude JoyPad
        If TypeOf sender Is ActiveJoyPad Then Return
        ' ---------------------------------------------------------- add ActiveSlot
        obj.MousePressed = True
        ActiveSlots.AddActiveSlot(obj)
        If obj.Speed = 0 And obj.Random = 0 Then
            For j As Int32 = 0 To obj.SlotArray.Length - 1
                Slots.WriteSlot(obj.SlotArray(j), obj.Value)
            Next
        End If
    End Sub
    Private Sub MouseUpHandler(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim i As Int32 = GetActiveObjectIndex(sender)
        Dim obj As ActiveObject = ActiveObjectsArray(i)
        ' ----------------------------------------------------------
        If Dragging Then
            Dragging = False
            Form2.CopyPlacementFromControlsToActiveObjectsArray()
            Form2.ReinitAllActiveObjects()
        End If
        ' ---------------------------------------------------------- JoyPad MouseUP
        If TypeOf sender Is ActiveJoyPad Then
            Cursor.Clip = Nothing
            ' ----------- recenter the cursor --------------------------------------------
            ' (working only with mouse because finger can not be recentered)
            'Dim r As Rectangle = obj.JoyPad.RectangleToScreen(obj.JoyPad.ClientRectangle)
            'Cursor.Position = New Point(r.X + r.Width \ 2, r.Y + r.Height \ 2)
            ' ----------------------------------------------------------------------------
            JoyPadExec(sender, e, True)
            obj.JoyPad.MarkerPosition = New Point(-99, -99)
            Return
        End If
        ' ---------------------------------------------------------- update active slot with MousePressed = false
        obj.MousePressed = False
        ActiveSlots.AddActiveSlot(obj)
    End Sub
    Private Sub MouseMoveHandler(ByVal sender As Object, ByVal e As MouseEventArgs)
        If dragging Then
            Dim c As Control = CType(sender, Control)
            If My.Computer.Keyboard.ShiftKeyDown Then
                c.Width = Math.Max(StartControlSize.Width + Cursor.Position.X - StartMousePos.X, 20)
                c.Height = Math.Max(StartControlSize.Height + Cursor.Position.Y - StartMousePos.Y, 20)
            Else
                c.Left = StartControlPos.X + Cursor.Position.X - StartMousePos.X
                c.Top = StartControlPos.Y + Cursor.Position.Y - StartMousePos.Y
            End If
        End If
        ' ---------------------------------------------------------- JoyPad MouseMove
        If TypeOf sender Is ActiveJoyPad Then
            JoyPadExec(sender, e, False)
        End If
    End Sub

    Private Sub JoyPadExec(ByVal sender As Object, ByVal e As MouseEventArgs, ByVal MouseUp As Boolean)
        Dim i As Int32 = GetActiveObjectIndex(sender)
        With ActiveObjectsArray(i)
            Dim xw As Single = .JoyPad.ClientSize.Width - 4
            Dim yw As Single = .JoyPad.ClientSize.Height - 4
            If e.Button = MouseButtons.Left And Not MouseUp Then
                Dim x As Single = e.Location.X
                Dim y As Single = e.Location.Y
                x = MinMax(x, 0, xw)
                y = MinMax(y, 0, yw)
                .JoyPad.MarkerPosition = New Point(CInt(x), CInt(y))
                x = x / xw
                y = 1 - y / yw
                Select Case .JoyPadType
                    Case JoyPadTypes.JoyPad
                        Dim absx As Single = Math.Abs(2 * x - 1)
                        Dim expx As Single = CSng(absx ^ 1)
                        Dim signx As Single = Math.Sign(x - 0.5)

                        Dim absy As Single = Math.Abs(2 * y - 1)
                        Dim expy As Single = CSng(absy ^ Math.E)
                        Dim signy As Single = Math.Sign(y - 0.5)

                        .PadX = expx * signx * .Speed * (expy + .Random / 1000)
                        .PadY = (expy * signy * 0.5F + 0.5F) * 1000.0F
                        .Out1 = .PadY + .PadX
                        .Out2 = .PadY - .PadX

                        .Out1 = 500 + (.Out1 - 500) * .Value / 1000
                        .Out2 = 500 + (.Out2 - 500) * .Value / 1000

                    Case JoyPadTypes.XY
                        .PadX = x * 1000.0F
                        .PadY = y * 1000.0F
                        .Out1 = .PadX
                        .Out2 = .PadY
                End Select
                If .SpeedFeedbackType = SpeedFeedbackTypes.None Then
                    UpdateSlots_1_2(ActiveObjectsArray(i))
                End If
            Else
                If .AutoZero Then
                    .Out1 = 500
                    .Out2 = 500
                End If
                If MouseUp Then
                    UpdateSlots_1_2(ActiveObjectsArray(i))
                End If
            End If
        End With
    End Sub

    ' ------------------------------------------------------------------------
    '  Normal JoyPad without speed feedback output called from cursor movements
    ' ------------------------------------------------------------------------
    Friend Sub UpdateSlots_1_2(ByVal obj As ActiveObject)
        With obj
            If .SlotArray.Length >= 1 Then
                MinMax_0_1000(.Out1)
                Slots.WriteSlot(.SlotArray(0), .Out1)
            End If
            If .SlotArray.Length >= 2 Then
                MinMax_0_1000(.Out2)
                Slots.WriteSlot(.SlotArray(1), .Out2)
            End If
        End With
    End Sub

    Friend Sub ResetAllJoyPadTo500()
        For Each obj As ActiveObject In ActiveObjectsArray
            If obj.Type = ActiveObjectType.JoyPad Then
                If obj.SlotArray.Length >= 2 Then
                    Slots.WriteSlot(obj.SlotArray(0), 500)
                    Slots.WriteSlot(obj.SlotArray(1), 500)
                End If
            End If
        Next
    End Sub

    
End Module



