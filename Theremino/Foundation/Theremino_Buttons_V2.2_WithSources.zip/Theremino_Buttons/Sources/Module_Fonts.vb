﻿
Imports System.Runtime.InteropServices
Imports System.Drawing.Text

Module Fonts

    Private Function GetFontNames() As String()
        Dim fonts As New InstalledFontCollection
        Dim FontNames(fonts.Families.Length - 1) As String
        For i As Int32 = 0 To fonts.Families.Length - 1
            FontNames(i) = fonts.Families(i).Name
        Next
        Return FontNames
    End Function

    Private Function GetFontsPath() As String
        GetFontsPath = Environment.GetFolderPath(Environment.SpecialFolder.System)
        GetFontsPath = IO.Directory.GetParent(GetFontsPath).FullName
        GetFontsPath = IO.Path.Combine(GetFontsPath, "Fonts")
    End Function

    Private Function IsFontInstalled(ByVal fontName As String) As Boolean
        Dim testFont As Font = New Font(fontName, 8)
        Return fontName.Equals(testFont.Name, StringComparison.InvariantCultureIgnoreCase)
    End Function

    Friend Sub InstallFont(ByVal FontFile As String)
        Dim FontFileName As String = IO.Path.GetFileName(FontFile)
        Dim FontPath As String = GetFontsPath() + "\" + FontFileName
        Process.Start(FontFile)
    End Sub

    Friend Sub AddFonts()
        If Not IsFontInstalled("LCD") Then
            MessageBox.Show("Please press ""Install"" for each font")
            InstallFont(Application.StartupPath + "\Fonts\LCD-N___.TTF")
            InstallFont(Application.StartupPath + "\Fonts\LCD-BOLD.TTF")
            InstallFont(Application.StartupPath + "\Fonts\LCDMN___.TTF")
            InstallFont(Application.StartupPath + "\Fonts\LCDMB___.TTF")
            MessageBox.Show("Please close and restart the application")
        End If
    End Sub

End Module
