﻿
Module Module_SaveLoad

    Friend EventsAreEnabled As Boolean = False
    Friend ClosingApplication As Boolean = False
    Friend LastFilePathAndName As String

    Friend CI As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 150 - .Width) ' at least at left border + 150 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function


    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                               Optional ByVal Value As Double = Double.NaN, _
                               Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Private Function Val_Bool(ByVal l As String) As Boolean
        l = l.Trim.ToLower
        Select Case l
            Case "1", "true" : Return True
            Case "0", "false" : Return False
            Case Else
                ErrorMessage("Unrecognized boolean value : " + l)
                Return False
        End Select
    End Function
    Private Function Val_Color(ByVal l As String) As Color
        Dim c() As String = l.Split(" "c)
        If c.Length >= 3 Then
            Dim r As Int32 = Val_Int(c(0))
            Dim g As Int32 = Val_Int(c(1))
            Dim b As Int32 = Val_Int(c(2))
            If r > 255 Or r < 0 Or g > 255 Or g < 0 Or b > 255 Or b < 0 Then
                ErrorMessage("Unrecognized color : " + l)
                Return Color.Gray
            End If
            Return Color.FromArgb(r, g, b)
        Else
            ErrorMessage("Unrecognized color : " + l)
            Return Color.Gray
        End If
    End Function
    Private Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Int32
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function
    Private Function GetTextFromLine(ByVal s As String) As String
        ' ------------------- Returns the string beginning after the first "=" symbol
        Dim i As Int32
        i = InStr(s, "=")
        If i > 0 Then
            s = Mid(s, i + 1)
            If s.StartsWith(" ") Then s = Mid(s, 2)
        Else
            s = Trim(s)
        End If
        Return s
    End Function

    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function

    ' ==============================================================
    '  REPLACE MULTIPLE SPACES and TABS and TRIM
    ' ============================================================== 
    Friend Function ReplaceMultipleSpacesAndTrim(ByVal s As String) As String
        s = s.Replace(vbTab, " ")
        While s.Contains("  ")
            s = s.Replace("  ", " ")
        End While
        Return s.Trim
    End Function

    ' ========================================================
    '   PROCESS START AND WAIT
    ' ========================================================
    Friend Sub ProcessStartAndWait(ByVal fname As String)
        If Not My.Computer.FileSystem.FileExists(fname) Then Return
        Dim p As Process = Process.Start(fname)
        Do
            System.Threading.Thread.Sleep(100)
        Loop Until p.HasExited
    End Sub

    Public Function GetPath(ByVal str As String) As String
        Try
            Return IO.Path.GetDirectoryName(str) & "\"
        Catch
            Return str
        End Try
    End Function

    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub Save_INI()
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            f.WriteLine(TabString("Form1_Width", r.Width))
            f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            r = GetFormRectangle(Form2)
            f.WriteLine(TabString("Form2_Top", r.Top))
            f.WriteLine(TabString("Form2_Left", r.Left))
            'f.WriteLine(TabString("Form2_Width", r.Width))
            'f.WriteLine(TabString("Form2_Height", r.Height))
            'f.WriteLine(TabString("Form2_WindowState", Form2.WindowState))
            '
            f.WriteLine(TabString("CmbCopyText", Form2.cmb_CopyProperty.Text))
            '
            f.WriteLine(TabString("LastFile", LastFilePathAndName))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub


    Friend Sub Load_INI()
        ' ------------------------------------------------------------- defaults
        '
        Combo_SetIndex_FromString(Form2.cmb_CopyProperty, "Type")
        ' -------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = Application.StartupPath & "\" & AssemblyName() & "_INI.txt"
        If My.Computer.FileSystem.FileExists(iniFileName) Then
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)
            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = CInt(Val(l))
                    Case "Form1_Left" : Form1.Left = CInt(Val(l))
                    Case "Form1_Width" : form1.Width = CInt(Val(l))
                    Case "Form1_Height" : form1.Height = CInt(Val(l))
                    Case "Form1_WindowState" : form1.WindowState = CType((Val(l)), FormWindowState)
                    Case "Form2_Top" : Form2.Top = CInt(Val(l))
                    Case "Form2_Left" : Form2.Left = CInt(Val(l))
                        'Case "Form2_Width" : Form2.Width = CInt(Val(l))
                        'Case "Form2_Height" : Form2.Height = CInt(Val(l))
                    Case "Form2_WindowState" : Form2.WindowState = CType((Val(l)), FormWindowState)
                        ' ----------------------------------------------------------------- 
                    Case "CmbCopyText" : Combo_SetIndex_FromString(Form2.cmb_CopyProperty, l)
                        ' -----------------------------------------------------------------
                    Case "LastFile" : LastFilePathAndName = l
                End Select
            Loop
            f.Close()
        End If
        LimitFormPosition(Form1)
        LimitFormPosition(Form2)
    End Sub

    Friend Sub WaitSeconds(ByVal sec As Single)
        Threading.Thread.Sleep(CInt(sec * 1000))
    End Sub

    Friend Sub ErrorMessage(ByVal text As String)
        MessageBox.Show(text, "Message from Theremino Buttons", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub


    ' ==================================================================================================
    '  DIALOGS LOAD SAVE CONFIGURATION
    ' ==================================================================================================
    Friend ConfigurationModified As Boolean = False

    Friend Sub Dialog_LoadConf()
        ' ------------------------------------------------------------
        If Not TestModifiedConfiguration() Then
            Return
        End If
        ' ------------------------------------------------------------
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ' ------------------------------------------------------------ 
        If My.Computer.FileSystem.FileExists(LastFilePathAndName) Then
            ofd.InitialDirectory = GetPath(LastFilePathAndName)
            ' -------------------------------------------------------- filename selected (but conflicting with ShowHelp)
            SendKeys.Send("+{TAB}+{TAB}" + IO.Path.GetFileName(LastFilePathAndName) + "{TAB}{TAB}")
        Else
            ofd.InitialDirectory = Application.StartupPath & "\Configurations"
            IO.Directory.CreateDirectory(ofd.InitialDirectory)
        End If
        ' ------------------------------------------------------------ left part of filename not visible
        ofd.FileName = IO.Path.GetFileName(LastFilePathAndName)
        ' ------------------------------------------------------------ filename completely visible but no extension
        'ofd.FileName = IO.Path.GetFileNameWithoutExtension(LastFilePathAndName)
        'ofd.DefaultExt = IO.Path.GetExtension(LastFilePathAndName)
        ' ------------------------------------------------------------ filename completely visible and better dialog
        ' ofd.ShowHelp = True
        ' ------------------------------------------------------------
        ofd.AutoUpgradeEnabled = True
        ofd.Title = "Load configuration file"
        ofd.ValidateNames = False
        ofd.Multiselect = True
        ofd.Filter = "Configuration file (*.txt)|*txt"
        ofd.DefaultExt = ".txt"
        IO.Directory.CreateDirectory(ofd.InitialDirectory)
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            LastFilePathAndName = ofd.FileName
            Form2.Reload_Configuration()
            Form2.Focus()
            Undo1.Clear()
            Form2.UpdateUndoButtons()
            Form2.ShowSelectedObjProps()
            ConfigurationModified = False
            Save_INI()
            Form2.ShowTextAndFile()
        End If
    End Sub


    Friend Sub Dialog_SaveConf()
        Dim sfd As SaveFileDialog = New SaveFileDialog()
        ' ------------------------------------------------------------ 
        If My.Computer.FileSystem.FileExists(LastFilePathAndName) Then
            sfd.InitialDirectory = GetPath(LastFilePathAndName)
            ' -------------------------------------------------------- filename selected (but conflicting with ShowHelp)
            SendKeys.Send("+{TAB}+{TAB}" + IO.Path.GetFileName(LastFilePathAndName) + "{TAB}{TAB}")
        Else
            sfd.InitialDirectory = Application.StartupPath & "\Configurations"
            IO.Directory.CreateDirectory(sfd.InitialDirectory)
        End If
        ' ------------------------------------------------------------ left part of filename not visible
        sfd.FileName = IO.Path.GetFileName(LastFilePathAndName)
        ' ------------------------------------------------------------ filename completely visible but no extension
        'sfd.FileName = IO.Path.GetFileNameWithoutExtension(LastFilePathAndName)
        'sfd.DefaultExt = IO.Path.GetExtension(LastFilePathAndName)
        ' ------------------------------------------------------------ filename completely visible and better dialog
        ' sfd.ShowHelp = True
        ' ------------------------------------------------------------
        sfd.AutoUpgradeEnabled = True
        sfd.Title = "Save configuration file"
        sfd.ValidateNames = False
        sfd.DefaultExt = ".txt"
        sfd.AddExtension = True
        sfd.Filter = "Configuration file (*.txt)|*txt"
        IO.Directory.CreateDirectory(sfd.InitialDirectory)
        If sfd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            LastFilePathAndName = sfd.FileName
            Save_Configuration()
            Form2.ShowTextAndFile()
            Form1.ShowTextAndFile()
        End If
    End Sub


    ' ==================================================================================================
    '  SAVE CONFIGURATION
    ' ==================================================================================================
    Friend Function TestModifiedConfiguration() As Boolean
        While ConfigurationModified
            Select Case MessageBox.Show("Configuration modified." + vbCrLf + vbCrLf + _
                                        "Save to file: " + IO.Path.GetFileName(LastFilePathAndName) + " ?", _
                                        "WARNING from Theremino Buttons", _
                                        MessageBoxButtons.YesNoCancel, _
                                        MessageBoxIcon.Question)
                Case DialogResult.Yes
                    Save_Configuration()
                    Return True
                Case DialogResult.No
                    ConfigurationModified = False
                    Return True
                Case Else
                    Return False
            End Select
        End While
        Return True
    End Function

    Friend Sub Save_Configuration()
        Form1.Enabled = False
        Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Try
            Dim f As System.IO.StreamWriter
            f = IO.File.CreateText(LastFilePathAndName)
            CreateConfigString()
            f.Write(ConfigurationString)
            f.Close()
            ConfigurationModified = False
        Catch
        End Try
        If Form2.Visible Then
            Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
        End If
        Form1.Enabled = True
    End Sub

    Friend Sub CreateConfigString()
        ConfigurationString = ""
        AddTextLine("' =============================")
        AddTextLine("' General props")
        AddTextLine("' =============================")
        Dim r As Rectangle = GetFormRectangle(Form1)
        AddTextLine("FormWidth    = " + r.Width.ToString)
        AddTextLine("FormHeight   = " + r.Height.ToString)
        AddTextLine("FormColor    = " + ColorToString(gFormColor))
        AddTextLine("TextFont     = " + FontToString(gTextFont))
        AddTextLine("TextAlign    = " + gTextAlign)
        AddTextLine("TextColor    = " + ColorToString(gTextColor))
        AddTextLine("BackColor    = " + ColorToString(gBackColor))
        AddTextLine("Width        = " + gWidth.ToString)
        AddTextLine("Height       = " + gHeight.ToString)
        AddTextLine("")
        AddTextLine("' =============================")
        AddTextLine("' Controls")
        AddTextLine("' =============================")
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            Dim obj As ActiveObject = ActiveObjectsArray(i)
            Select Case obj.Type
                Case ActiveObjectType.Button
                    AddTextLine("Button")
                    AddTextLine("Slots        = " + obj.SlotString)
                    AddTextLine("Value        = " + obj.Value.ToString)

                    If obj.Speed <> 0 Then AddTextLine("Speed        = " + obj.Speed.ToString)
                    If obj.Random <> 0 Then AddTextLine("Random       = " + obj.Random.ToString)
                    If obj.MoveType <> "Normal" Then AddTextLine("MoveType     = " + obj.MoveType)

                    If obj.Text <> "" Then AddTextLine("Text         = " + Convert_NewLine_ToBackslashRN(obj.Text))
                    If obj.ContentAlign <> ContentAlignment.MiddleCenter Then AddTextLine("TextAlign    = " + obj.ContentAlign.ToString)
                    If FontToString(obj.TextFont) <> FontToString(gTextFont) Then AddTextLine("TextFont     = " + FontToString(obj.TextFont))
                    If obj.TextColor <> gTextColor Then AddTextLine("TextColor    = " + ColorToString(obj.TextColor))
                    If obj.BackColor <> gBackColor Then AddTextLine("BackColor    = " + ColorToString(obj.BackColor))
                    AddTextLine("Top          = " + obj.Top.ToString)
                    AddTextLine("Left         = " + obj.Left.ToString)
                    AddTextLine("Width        = " + obj.Width.ToString)
                    AddTextLine("Height       = " + obj.Height.ToString)
                    AddTextLine("")
                Case ActiveObjectType.TextBox
                    AddTextLine("TextBox")
                    AddTextLine("Slots          = " + obj.SlotString)

                    If obj.Speed <> 0 Then AddTextLine("Speed        = " + obj.Speed.ToString)
                    If obj.MultiplierSlot > -1 Then AddTextLine("MultiplierSlot = " + obj.MultiplierSlot.ToString)
                    If obj.MoveType <> "Normal" Then AddTextLine("MoveType     = " + obj.MoveType)

                    If obj.Text <> "" Then AddTextLine("Text           = " + Convert_NewLine_ToBackslashRN(obj.Text))
                    If obj.TextAlign <> HorizontalAlignment.Center Then AddTextLine("TextAlign      = " + obj.TextAlign.ToString)
                    If FontToString(obj.TextFont) <> FontToString(gTextFont) Then AddTextLine("TextFont     = " + FontToString(obj.TextFont))
                    If obj.TextColor <> gTextColor Then AddTextLine("TextColor    = " + ColorToString(obj.TextColor))
                    If obj.BackColor <> gBackColor Then AddTextLine("BackColor    = " + ColorToString(obj.BackColor))
                    AddTextLine("Top          = " + obj.Top.ToString)
                    AddTextLine("Left         = " + obj.Left.ToString)
                    AddTextLine("Width        = " + obj.Width.ToString)
                    AddTextLine("Height       = " + obj.Height.ToString)
                    AddTextLine("")
                Case ActiveObjectType.JoyPad
                    AddTextLine("JoyPad")
                    AddTextLine("Slots        = " + obj.SlotString)
                    AddTextLine("Value        = " + obj.Value.ToString)

                    If obj.Speed <> 0 Then AddTextLine("Speed        = " + obj.Speed.ToString)
                    If obj.Random <> 0 Then AddTextLine("Random       = " + obj.Random.ToString)
                    If obj.MoveType <> "Normal" Then AddTextLine("MoveType     = " + obj.MoveType)

                    If obj.Text <> "" Then AddTextLine("Text         = " + Convert_NewLine_ToBackslashRN(obj.Text))
                    If obj.TextAlign <> HorizontalAlignment.Center Then AddTextLine("TextAlign      = " + obj.TextAlign.ToString)
                    If FontToString(obj.TextFont) <> FontToString(gTextFont) Then AddTextLine("TextFont     = " + FontToString(obj.TextFont))
                    If obj.TextColor <> gTextColor Then AddTextLine("TextColor    = " + ColorToString(obj.TextColor))
                    If obj.BackColor <> gBackColor Then AddTextLine("BackColor    = " + ColorToString(obj.BackColor))
                    AddTextLine("Top          = " + obj.Top.ToString)
                    AddTextLine("Left         = " + obj.Left.ToString)
                    AddTextLine("Width        = " + obj.Width.ToString)
                    AddTextLine("Height       = " + obj.Height.ToString)
                    AddTextLine("")
                Case ActiveObjectType.ActiveSlot
                    AddTextLine("ActiveSlot")
                    AddTextLine("Slots        = " + obj.SlotString)
                    AddTextLine("Value        = " + obj.Value.ToString)

                    If obj.Speed <> 0 Then AddTextLine("Speed        = " + obj.Speed.ToString)
                    If obj.Random <> 0 Then AddTextLine("Random       = " + obj.Random.ToString)
                    If obj.TriggerSlot > -1 Then AddTextLine("TriggerSlot  = " + obj.TriggerSlot.ToString)
                    If obj.MoveType <> "Normal" Then AddTextLine("MoveType     = " + obj.MoveType)

                    If obj.Text <> "" Then AddTextLine("Text         = " + Convert_NewLine_ToBackslashRN(obj.Text))
                    If obj.ContentAlign <> ContentAlignment.MiddleCenter Then AddTextLine("TextAlign    = " + obj.ContentAlign.ToString)
                    If FontToString(obj.TextFont) <> FontToString(gTextFont) Then AddTextLine("TextFont     = " + FontToString(obj.TextFont))
                    If obj.TextColor <> gTextColor Then AddTextLine("TextColor    = " + ColorToString(obj.TextColor))
                    If obj.BackColor <> gBackColor Then AddTextLine("BackColor    = " + ColorToString(obj.BackColor))
                    AddTextLine("Top          = " + obj.Top.ToString)
                    AddTextLine("Left         = " + obj.Left.ToString)
                    AddTextLine("Width        = " + obj.Width.ToString)
                    AddTextLine("Height       = " + obj.Height.ToString)
                    AddTextLine("")
            End Select
        Next
    End Sub

    Friend Undo1 As UndoManager(Of String) = New UndoManager(Of String)
    Friend ConfigurationString As String
    Private Sub AddTextLine(ByVal s As String)
        ConfigurationString = ConfigurationString + s + vbCrLf
    End Sub

    Private Function ColorToString(ByVal c As Color) As String
        ColorToString = c.R.ToString("000 ") + c.G.ToString("000 ") + c.B.ToString("000")
    End Function

    Private Function BoolToString(ByVal b As Boolean) As String
        Return If(b, "1", "0")
    End Function

    Private Function Convert_NewLine_ToBackslashRN(ByVal s As String) As String
        Return s.Replace(vbCrLf, "\r\n")
    End Function

    Private Function Convert_BackslashRN_ToNewLine(ByVal s As String) As String
        Return s.Replace("\r\n", vbCrLf)
    End Function


    ' ==================================================================================================
    '  LOAD CONFIGURATION
    ' ==================================================================================================
    Friend Sub Load_Configuration()
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        'If filename = "" Then filename = LastFilePathAndName
        'LastFilePathAndName = filename
        ' -------------------------------------------------------------------------------
        If Not IO.File.Exists(LastFilePathAndName) Or _
               LastFilePathAndName.StartsWith("\\") Then
            LastFilePathAndName = FindFileInAppFolders(LastFilePathAndName)
        End If
        ' -------------------------------------------------------------------------------
        Dim line As String
        Dim l As String
        If IO.File.Exists(LastFilePathAndName) Then
            Form1.ShowTextAndFile()
            Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
            Dim reader As System.IO.TextReader
            reader = New System.IO.StreamReader(LastFilePathAndName)
            ConfigurationString = reader.ReadToEnd
            reader.Close()
            DecodeConfigString(ConfigurationString)
            If Form2.Visible Then
                Form1.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
            End If
        End If
    End Sub

    Private Function FindFileInAppFolders(ByVal PathAndName As String) As String
        Dim name As String = IO.Path.GetFileName(PathAndName)
        If name = "" Then Return ""
        Dim FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim wildcards() As String = {"*.txt"}
        Dim s As String = Application.StartupPath & "\Configurations\"
        FileNames = My.Computer.FileSystem.GetFiles(s, FileIO.SearchOption.SearchAllSubDirectories, wildcards)
        For Each str As String In FileNames
            If str.EndsWith(name) Then
                Return str
            End If
        Next
        Return ""
    End Function


    Friend Sub DecodeConfigString(ByVal s As String)
        Dim sa As String() = Strings.Split(s, vbCrLf)
        For i As Int32 = 0 To sa.Length - 1
            DecodeConfigLine(sa(i))
        Next
        If CopyPropertyFlag Then
            Form1.BackColor = CopyHilightColor
        Else
            Form1.BackColor = gFormColor
        End If
    End Sub

    Private Sub DecodeConfigLine(ByVal line As String)
        '
        Dim l As String = ReplaceMultipleSpacesAndTrim(line)
        If l = "" Then Return
        '
        Dim par As String
        par = ExtractParamName(l).ToLower.Trim
        If par.StartsWith("'") Then Return

        Select Case par
            Case "button", "textbox", "joypad", "activeslot"
                ReDim Preserve ActiveObjectsArray(ActiveObjectsArray.Length)
                InitObjectDefaultProps(ActiveObjectsArray.Length - 1, par)
                Return
            Case Else
                ' ErrorMessage("Unrecognized command : " + line)
        End Select

        If ActiveObjectsArray.Length = 0 Then
            Select Case par
                ' --------------------------------------------- form props
                Case "formwidth" : Form1.Width = Val_Int(l)
                Case "formheight" : Form1.Height = Val_Int(l)
                Case "formcolor" : gFormColor = Val_Color(l)
                    ' ----------------------------------------- global props
                Case "textfont" : gTextFont = StringToFont(l)
                Case "textalign" : gTextAlign = l
                Case "textcolor" : gTextColor = Val_Color(l)
                Case "backcolor" : gBackColor = Val_Color(l)
                Case "width" : gWidth = Val_Int(l)
                Case "height" : gHeight = Val_Int(l)
                Case Else : ErrorMessage("Unrecognized command : " + line)
            End Select
        Else
            With ActiveObjectsArray(ActiveObjectsArray.Length - 1)
                Select Case .Type
                    Case ActiveObjectType.Button
                        Select Case par
                            Case "slot", "slots" : .SlotString = l : .SlotArray = StringToSlotArray(l)
                            Case "value" : .Value = Val_Single(l)
                            Case "speed" : .Speed = Val_Single(l)
                            Case "random" : .Random = Val_Single(l)
                            Case "movetype" : .MoveType = l
                            Case "text" : .Text = Convert_BackslashRN_ToNewLine(GetTextFromLine(line))
                            Case "textalign" : .ContentAlign = DecodeContentAlignment(l)
                            Case "textfont" : .TextFont = StringToFont(l)
                            Case "textcolor" : .TextColor = Val_Color(l)
                            Case "backcolor" : .BackColor = Val_Color(l)
                            Case "top" : .Top = Val_Int(l)
                            Case "left" : .Left = Val_Int(l)
                            Case "width" : .Width = Val_Int(l)
                            Case "height" : .Height = Val_Int(l)
                            Case Else
                                ErrorMessage("Unrecognized command : " + line)
                        End Select
                    Case ActiveObjectType.TextBox
                        Select Case par
                            Case "slot", "slots" : .SlotString = l : .SlotArray = StringToSlotArray(l)
                            Case "speed" : .Speed = Val_Single(l)
                            Case "multiplierslot" : .MultiplierSlot = Val_Int(l)
                            Case "movetype" : .MoveType = l
                            Case "text" : .Text = Convert_BackslashRN_ToNewLine(GetTextFromLine(line))
                            Case "textalign" : .TextAlign = DecodeHorizontalAlignment(l)
                            Case "textfont" : .TextFont = StringToFont(l)
                            Case "textcolor" : .TextColor = Val_Color(l)
                            Case "backcolor" : .BackColor = Val_Color(l)
                            Case "top" : .Top = Val_Int(l)
                            Case "left" : .Left = Val_Int(l)
                            Case "width" : .Width = Val_Int(l)
                            Case "height" : .Height = Val_Int(l)
                            Case Else
                                ErrorMessage("Unrecognized command : " + line)
                        End Select
                    Case ActiveObjectType.JoyPad
                        Select Case par
                            Case "slot", "slots" : .SlotString = l : .SlotArray = StringToSlotArray(l)
                            Case "value" : .Value = Val_Single(l)
                            Case "speed" : .Speed = Val_Single(l)
                            Case "random" : .Random = Val_Single(l)
                            Case "movetype" : .MoveType = l
                            Case "text" : .Text = Convert_BackslashRN_ToNewLine(GetTextFromLine(line))
                            Case "textalign" : .TextAlign = DecodeHorizontalAlignment(l)
                            Case "textfont" : .TextFont = StringToFont(l)
                            Case "textcolor" : .TextColor = Val_Color(l)
                            Case "backcolor" : .BackColor = Val_Color(l)
                            Case "top" : .Top = Val_Int(l)
                            Case "left" : .Left = Val_Int(l)
                            Case "width" : .Width = Val_Int(l)
                            Case "height" : .Height = Val_Int(l)
                            Case Else
                                ErrorMessage("Unrecognized command : " + line)
                        End Select
                    Case ActiveObjectType.ActiveSlot
                        Select Case par
                            Case "slot", "slots" : .SlotString = l : .SlotArray = StringToSlotArray(l)
                            Case "value" : .Value = Val_Single(l)
                            Case "speed" : .Speed = Val_Single(l)
                            Case "random" : .Random = Val_Single(l)
                            Case "movetype" : .MoveType = l
                            Case "triggerslot" : .TriggerSlot = Val_Int(l)
                            Case "text" : .Text = Convert_BackslashRN_ToNewLine(GetTextFromLine(line))
                            Case "textalign" : .ContentAlign = DecodeContentAlignment(l)
                            Case "textfont" : .TextFont = StringToFont(l)
                            Case "textcolor" : .TextColor = Val_Color(l)
                            Case "backcolor" : .BackColor = Val_Color(l)
                            Case "top" : .Top = Val_Int(l)
                            Case "left" : .Left = Val_Int(l)
                            Case "width" : .Width = Val_Int(l)
                            Case "height" : .Height = Val_Int(l)
                            Case Else
                                ErrorMessage("Unrecognized command : " + line)
                        End Select
                End Select
            End With
        End If
    End Sub

    Friend Sub InitObjectDefaultProps(ByVal Index As Int32, ByVal Type As String)
        With ActiveObjectsArray(Index)
            ' ------------------------------------------ defaults
            .SlotString = ""
            ReDim .SlotArray(-1)
            .MultiplierSlot = -1
            .TriggerSlot = -1
            .Random = 0
            .Speed = 0
            .ContentAlign = ContentAlignment.MiddleCenter
            .TextAlign = HorizontalAlignment.Center
            .TextFont = gTextFont
            .TextColor = gTextColor
            .BackColor = gBackColor
            'If .Left = 0 Then .Left = Index * 20
            'If .Top = 0 Then .Top = Index * 20
            .Width = gWidth
            .Height = gHeight
            ' ------------------------------------------ type
            Select Case Type.ToLower
                Case "button"
                    .Type = ActiveObjectType.Button
                    .MoveType = "Normal"
                Case "textbox"
                    .Type = ActiveObjectType.TextBox
                    .MoveType = "Normal"
                Case "joypad"
                    .BackColor = Color.FromArgb(72, 108, 164)
                    .Type = ActiveObjectType.JoyPad
                    .MoveType = "Joy (auto)"
                Case Is = "activeslot"
                    .Type = ActiveObjectType.ActiveSlot
                    .MoveType = "Normal"
            End Select
        End With
    End Sub

End Module
