﻿Imports System.Runtime.InteropServices

Module Utils

    ' =============================================================================
    '  COMBO
    ' =============================================================================
    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString.Trim = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub

    ' =============================================================================
    '  SWAP
    ' =============================================================================
    Friend Sub Swap(Of T)(ByRef x As T, ByRef y As T)
        Dim temp As T = y
        y = x
        x = temp
    End Sub

    ' =============================================================================
    '  MinMax
    ' =============================================================================
    Friend Function MinMax(ByVal n As Single, ByVal min As Single, ByVal max As Single) As Single
        If n > max Then Return max
        If n < min Then Return min
        Return n
    End Function

    Friend Sub MinMax_0_1000(ByRef n As Single)
        If n > 1000 Then n = 1000
        If n < 0 Then n = 0
    End Sub

    ' =============================================================================
    '  FONT CONVERSIONS
    ' =============================================================================
    Public Function FontToString(ByVal font As Font) As String
        Dim fc As FontConverter = New FontConverter
        Return fc.ConvertToString(Nothing, Globalization.CultureInfo.InvariantCulture, font)
    End Function

    Public Function StringToFont(ByVal s As String) As Font
        Dim fc As FontConverter = New FontConverter
        Return CType(fc.ConvertFromString(Nothing, Globalization.CultureInfo.InvariantCulture, s), Font)
    End Function


    ' =============================================================================
    '  STRING TO SLOTARRAY
    ' =============================================================================
    Friend Function StringToSlotArray(ByVal slotstring As String) As Int32()
        Dim s(-1) As Int32
        Dim t() As String = slotstring.Split(" "c)
        For i As Int32 = 0 To t.Length - 1
            t(i) = t(i).Trim
            If t(i) <> "" Then
                ReDim Preserve s(s.Length)
                s(s.Length - 1) = CInt(Math.Min(Val(t(i)), 999))
            End If
        Next
        Return s
    End Function

    ' =============================================================================
    '  ALIGNMENTS
    ' =============================================================================
    Friend Function DecodeHorizontalAlignment(ByVal s As String) As HorizontalAlignment
        Select Case s.ToLower
            Case "left" : Return HorizontalAlignment.Left
            Case "center" : Return HorizontalAlignment.Center
            Case "right" : Return HorizontalAlignment.Right
            Case Else : Return HorizontalAlignment.Center
        End Select
    End Function

    Friend Function DecodeContentAlignment(ByVal s As String) As ContentAlignment
        Select Case s.ToLower
            Case "topleft" : Return ContentAlignment.TopLeft
            Case "topcenter" : Return ContentAlignment.TopCenter
            Case "topright" : Return ContentAlignment.TopRight
            Case "middleleft", "left" : Return ContentAlignment.MiddleLeft
            Case "middlecenter", "center" : Return ContentAlignment.MiddleCenter
            Case "middleright", "right" : Return ContentAlignment.MiddleRight
            Case "bottomleft" : Return ContentAlignment.BottomLeft
            Case "bottomcenter" : Return ContentAlignment.BottomCenter
            Case "bottomright" : Return ContentAlignment.BottomRight
            Case Else : Return ContentAlignment.MiddleCenter
        End Select
    End Function

    ' =============================================================================
    '  SWAP controls locations
    ' =============================================================================
    Friend Sub SwapGraphicControlsLocations(ByVal i1 As Int32, ByVal i2 As Int32)
        Dim p1 As Point = GetActiveObjPlacement(i1)
        SetActiveObjAndGraphicControlPlacement(i1, GetActiveObjPlacement(i2))
        SetActiveObjAndGraphicControlPlacement(i2, p1)
        ReorderGraphicControls_FrontToBack_FromArrayOrder_Up()
    End Sub

    Friend Function GetActiveObjPlacement(ByVal i As Int32) As Point
        Return New Point(ActiveObjectsArray(i).Left, ActiveObjectsArray(i).Top)
    End Function

    Friend Sub SetActiveObjAndGraphicControlPlacement(ByVal i As Int32, ByVal p As Point)
        With ActiveObjectsArray(i)
            .Left = p.X
            .Top = p.Y
            Select Case .Type
                Case ActiveObjectType.Button : If .Button IsNot Nothing Then .Button.Location = p
                Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then .TextBox.Location = p
                Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then .JoyPad.Location = p
                Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then .ActiveSlotControl.Location = p
            End Select
        End With
    End Sub

    ' =============================================================================
    '  REORDER FRONT to BACK
    ' =============================================================================
    Friend Sub ReorderGraphicControls_FrontToBack_FromArrayOrder_Up()
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                Select Case .Type
                    Case ActiveObjectType.Button : If .Button IsNot Nothing Then .Button.SendToBack()
                    Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then .TextBox.SendToBack()
                    Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then .JoyPad.SendToBack()
                    Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then .ActiveSlotControl.SendToBack()
                End Select
            End With
        Next
    End Sub

    ' =============================================================================
    '  CALC TOTAL SIZE
    ' =============================================================================
    Friend Function CalcTotalSize() As Size
        Dim x, y As Int32
        Dim maxx, maxy As Int32
        Dim c As Control = Nothing
        For i As Int32 = 0 To ActiveObjectsArray.Length - 1
            With ActiveObjectsArray(i)
                Select Case .Type
                    Case ActiveObjectType.Button : If .Button IsNot Nothing Then c = .Button
                    Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then c = .TextBox
                    Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then c = .JoyPad
                    Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then c = .ActiveSlotControl
                End Select
            End With
            If c IsNot Nothing Then
                x = c.Left + c.Width
                y = c.Top + c.Height
                If x > maxx Then maxx = x
                If y > maxy Then maxy = y
            End If
        Next
        Return New Size(maxx, maxy)
    End Function


    ' =============================================================
    '    SmoothValue
    ' =============================================================
    Friend Sub SmoothValue_Pow_Adaptive(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        Dim delta As Single = new_value - value
        Dim delta_sgn As Single = Math.Sign(delta)
        Dim delta_abs As Single = Math.Abs(delta)
        Dim delta_pow As Single = CSng(delta_abs ^ 2) * speed
        If value <> 0 Then delta_pow /= Math.abs(value)
        If delta_pow >= delta_abs Then
            value = new_value
        Else
            value += delta_sgn * delta_pow
        End If
    End Sub

    Friend Sub SmoothValue_Simple(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        value += (new_value - value) * speed
    End Sub


    ' =============================================================================
    '  UNUSED FUNCTIONS
    ' =============================================================================
    'Friend Sub ReorderGraphicControls_FrontToBack_FromArrayOrder_Down()
    '    For i As Int32 = 0 To ActiveObjectsArray.Length - 1
    '        With ActiveObjectsArray(i)
    '            Select Case .Type
    '                Case ActiveObjectType.Button : If .Button IsNot Nothing Then .Button.BringToFront()
    '                Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then .TextBox.BringToFront()
    '                Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then .JoyPad.BringToFront()
    '                Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then .ActiveSlotControl.BringToFront()
    '            End Select
    '        End With
    '    Next
    'End Sub

    'Friend Sub Copy_All_ActiveObjLeftTop_ToGraphicControlsPlacement()
    '    For i As Int32 = 0 To ActiveObjectsArray.Length - 1
    '        With ActiveObjectsArray(i)
    '            SetActiveObjAndGraphicControlPlacement(i, New Point(.Left, .Top))
    '        End With
    '    Next
    'End Sub

    'Friend Function GetGraphicControlPlacement(ByVal i As Int32) As Point
    '    Dim p As Point = New Point
    '    With ActiveObjectsArray(i)
    '        Select Case .Type
    '            Case ActiveObjectType.Button : If .Button IsNot Nothing Then p = .Button.Location
    '            Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then p = .TextBox.Location
    '            Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then p = .JoyPad.Location
    '            Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then p = .ActiveSlotControl.Location
    '        End Select
    '    End With
    '    Return p
    'End Function

    'Friend Sub Copy_All_GraphicControlsPlacements_ToActiveObjLeftTop()
    '    For i As Int32 = 0 To ActiveObjectsArray.Length - 1
    '        Dim p As Point = GetGraphicControlPlacement(i)
    '        With ActiveObjectsArray(i)
    '            .Left = p.X
    '            .Top = p.Y
    '        End With
    '    Next
    'End Sub

    'Friend Sub DebugControlsData()
    '    Dim s As String
    '    s = "Nobj = " + ActiveObjectsArray.Length.ToString + vbCrLf
    '    For i As Int32 = 0 To ActiveObjectsArray.Length - 1
    '        Dim c As Control = New Control
    '        With ActiveObjectsArray(i)
    '            Select Case .Type
    '                Case ActiveObjectType.Button : If .Button IsNot Nothing Then c = .Button
    '                Case ActiveObjectType.TextBox : If .TextBox IsNot Nothing Then c = .TextBox
    '                Case ActiveObjectType.JoyPad : If .JoyPad IsNot Nothing Then c = .JoyPad
    '                Case ActiveObjectType.ActiveSlot : If .ActiveSlotControl IsNot Nothing Then c = .ActiveSlotControl
    '            End Select
    '            s += " Loc x/y = " + c.Location.X.ToString("000") + " " + c.Location.Y.ToString("000") + _
    '                 "    Left/Top = " + .Left.ToString("000") + " " + .Top.ToString("000") + vbCrLf
    '        End With
    '    Next
    '    Debug.Print(s)
    'End Sub

    ' =============================================================================
    '  DEBUG FUNCTIONS
    ' =============================================================================
    'Friend Sub CompareUndoStrings(ByVal s1 As String, ByVal s2 As String)
    '    Dim sa1 As String() = Strings.Split(s1, vbCrLf)
    '    Dim sa2 As String() = Strings.Split(s2, vbCrLf)
    '    If sa1.Length <> sa2.Length Then
    '        Debug.Print("Different length" + vbCrLf + vbCrLf)
    '        Return
    '    End If
    '    For i As Int32 = 0 To sa1.Length - 1
    '        If sa1(i) <> sa2(i) Then
    '            Debug.Print("-------- Line = " + i.ToString)
    '            Debug.Print(sa1(i))
    '            Debug.Print(sa2(i))
    '            Debug.Print("---------------------------")
    '        End If
    '    Next
    'End Sub

End Module
