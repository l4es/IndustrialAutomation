using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL.My
{

	// The following events are available for MyApplication:
	// 
	// Startup: Raised when the application starts, before the startup form is created.
	// Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
	// UnhandledException: Raised if the application encounters an unhandled exception.
	// StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
	// NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
	internal partial class MyApplication
	{

		private void MyApplication_Startup(object sender, Microsoft.VisualBasic.ApplicationServices.StartupEventArgs e)
		{
			AddAssemblyResolveHandler();
		}

		// ================================================================================================
		//  Embedded DLL loader
		// ================================================================================================
		//  Open " Project / Properties / Application " and press "View Application Events"
		//  Open file "ApplicationEvents.vb" and select "MyApplication Events" in the upper left combo
		//  In the upper right combo select the event "Startup" 
		//  In the "MyApplication_Startup" event  add the call to "AddAssemblyResolveHandler()"
		//  Copy the "Embedded DLL Loader" after the "Startup" event and before the "End Class"
		//  The DLL must be one of the project files with "Build action" = "Embedded resource" 
		//  Ensure also the DLL property "Copy to output" = "Do not copy"
		//  If the DLL contains controls add the DLL in the references with "Copy local" = "False"
		// ================================================================================================
		private void AddAssemblyResolveHandler()
		{
			AppDomain.CurrentDomain.AssemblyResolve += LoadDLLFromStream;
		}

		private System.Reflection.Assembly LoadDLLFromStream(object sender, System.ResolveEventArgs args)
		{
			string resourceName = null;
            resourceName = Module_SaveLoad.ApplicationName + ".";
			resourceName += new System.Reflection.AssemblyName(args.Name).Name + ".dll";

			using (System.IO.Stream stream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName)) {
				byte[] assemblyData = new byte[(int)stream.Length - 1 + 1];
				stream.Read(assemblyData, 0, assemblyData.Length);
				return System.Reflection.Assembly.Load(assemblyData);
			}
		}
		// ================================================================================================

	}

}

