﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Theremino_HAL
{
    class Class_DataScope
    {
        private PictureBox m_pbox;
        private Graphics g1;
        private float oldy1 = 1000000;
        private float oldy2 = 1000000;
        private float py1;
        private float py2;
        private float px;
        private float py;
        private float ymid;
        private float speedCounter = 0;
        private Pen p1 = new Pen(Color.FromArgb(140, 140, 140));
        private Pen p2 = new Pen(Color.FromArgb(210, 210, 210));
        private Pen p3 = new Pen(Color.DarkBlue, 2);
        private Pen p4 = new Pen(Color.DarkRed, 2);
        private float ScaleDeltaY;
        private float ScaleY;
        private Int32 ScaleIndex;

        internal Class_DataScope(PictureBox pbox)
        {
            m_pbox = pbox;
            px = (m_pbox.ClientSize.Width - 1);
            py = m_pbox.ClientSize.Height;
            ymid = py / 2f;
            ScaleDeltaY = py / 10.1F / 2f;
            //  ----------------------------------------------------- main pbox
            Module_ImageFilters.InitPictureboxImage(m_pbox);
            g1 = Graphics.FromImage(m_pbox.Image);
            g1.Clear(m_pbox.BackColor);
            g1.CompositingQuality = CompositingQuality.HighSpeed;
            g1.SmoothingMode = SmoothingMode.AntiAlias;
            g1.InterpolationMode = InterpolationMode.Low;
        }

        private Int32 TimeCounter;
        internal void Display(float V1, float V2, float speed)
        {
            // ----------------------------------------------------------- time scale
            if (speed >= 6)
            {
                TimeCounter += 1;
                if (TimeCounter >= 60)
                {
                    TimeCounter = 0;
                    g1.DrawLine(p2, px, 0, px, ScaleY);
                }
            }
            //  ----------------------------------------------------- speed
            speedCounter += speed;
            if ((speedCounter < 60)) return;
            speedCounter -= 60;
            //  ----------------------------------------------------- remove possible errors
            if (float.IsNaN(V1)) V1 = 100000;
            if (float.IsNaN(V2)) V2 = 100000;
            if (V1 < -100000) V1 = 100000;
            if (V2 < -100000) V2 = 100000;
            if (V1 > 100000) V1 = 100000;
            if (V2 > 100000) V2 = 100000;
            //  ----------------------------------------------------- draw scale divisions
            ScaleY = 1;
            for (ScaleIndex = 0; ScaleIndex <= 10; ScaleIndex++)
            {
                g1.DrawLine(p1, px, ScaleY, px + 1, ScaleY);
                ScaleY += ScaleDeltaY;
                g1.DrawLine(p2, px, ScaleY, px + 1, ScaleY);
                ScaleY += ScaleDeltaY;
            }
            //  ----------------------------------------------------- draw indicators
            py1 = ymid + 2.0F * V1;
            py2 = ymid + 2.0F * V2;
            if (Math.Abs(oldy1 - py1) > 1000) oldy1 = py1;
            if (Math.Abs(oldy2 - py2) > 1000) oldy2 = py2;
            g1.DrawLine(p3, px - 1, oldy1, px, py1);
            g1.DrawLine(p4, px - 1, oldy2, px, py2);
            oldy1 = py1;
            oldy2 = py2;
            if (Theremino.OperatingSystemIs_XP_or_Vista)
            {
                //  ------------------------------------------------- clone only if XP or Vista
                g1.DrawImage((Image)m_pbox.Image.Clone(), -1, 0);
            }
            else
            {
                //  ------------------------------------------------- Linux or Windows7/8
                g1.DrawImage(m_pbox.Image, -1, 0);
            }
            g1.DrawLine(Pens.AliceBlue, px, 0, px, py);
            m_pbox.Invalidate();
        }
    }
}
