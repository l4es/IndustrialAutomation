using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Theremino_HAL
{

	internal class TheHidApi
	{
		private IntPtr dev;
		public TheHidApi()
		{
			dev = IntPtr.Zero;
		}

		public bool IsHidOpen()
		{
			return dev != IntPtr.Zero;
		}

		public void HidOpen(ushort vid, ushort pid, string serial)
		{
			if (dev != IntPtr.Zero) {
				throw new Exception("a device is already opened; close it first.");
			}
			the_hid_init();
			IntPtr ret = the_hid_open(vid, pid, serial);
			dev = ret;
		}

		public int HidRead(byte[] buffer, int length)
		{
			HidAssertValidDev();
			int ret = the_hid_read(dev, buffer, (uint)length);
			if (ret < 0) {
				throw new Exception("Failed to Read.");
			}
			return ret;
		}

		public int HidWrite(byte[] buffer)
		{
			HidAssertValidDev();
			int ret = the_hid_write(dev, buffer, (uint)buffer.Length);
			//if (ret < 0)
			//	throw new Exception ("failed to send feature report");
			return ret;
		}

		public void HidClose()
		{
			HidAssertValidDev();
			the_hid_close(dev);
			the_hid_exit();
			dev = IntPtr.Zero;
		}

		private void HidAssertValidDev()
		{
			if (dev == IntPtr.Zero) {
				throw new Exception("No device opened");
			}
		}


		[DllImport("ThereminoHidApi")]
		private static extern int the_hid_init();

		[DllImport("ThereminoHidApi")]
		private static extern int the_hid_exit();

		[DllImport("ThereminoHidApi")]
		private static extern int the_hid_read(IntPtr device, 		[Out(), MarshalAs(UnmanagedType.LPArray)]
byte[] data, uint length);

		[DllImport("ThereminoHidApi")]
		private static extern IntPtr the_hid_open(ushort vid, ushort pid, 		[MarshalAs(UnmanagedType.LPWStr)]
string serial);

		[DllImport("ThereminoHidApi")]
		private static extern void the_hid_close(IntPtr device);

		[DllImport("ThereminoHidApi")]
		private static extern int the_hid_write(IntPtr device, 		[In(), MarshalAs(UnmanagedType.LPArray)]
byte[] data, uint length);

		// unused
		//public static extern void   hid_free_enumeration(struct hid_device_info *devs)
		//public static extern struct hid_device_info * hid_enumerate(unsigned short vendor_id, unsigned short product_id);
	}
}
namespace Theremino_HAL
{

	// #################################################################################################
	//  PARTIAL THEREMINO_HID CLASS
	// #################################################################################################
    public partial class Theremino_HID
	{

		private TheHidApi HidDevice_Unix;

		// =================================================================================================
		//  PRIVATE FUNCTIONS  -  READ REPORT and WRITE REPORT
		// =================================================================================================
		private bool ReadReport_Unix()
		{
			bool functionReturnValue = false;
			functionReturnValue = false;

			// -------------------------------------------- Read data from the device.
			int NumberOfBytesRead = 0;
			// -------------------------------------------- Allocate a buffer for the report.
			// -------------------------------------------- Byte 0 is the report ID
			// -------------------------------------------- and the ReadBuffer array begins at 0,
			// -------------------------------------------- so subtract 1 from the number of bytes.
			byte[] ReadBuffer = new byte[65];

			// -------------------------------------------- byref objects are to be pinned
			GCHandle pinnedReadBuffer = default(GCHandle);
			pinnedReadBuffer = GCHandle.Alloc(ReadBuffer, GCHandleType.Pinned);

			NumberOfBytesRead = HidDevice_Unix.HidRead(ReadBuffer, 65);

			if (NumberOfBytesRead > 0) {
				// ------------------------------------------------------ copy data to USB_RxData()
                for (Int32 Count = 0; Count < ReadBuffer.Length; Count++)
                {
					USB_RxData[Count] = ReadBuffer[Count];
				}
				functionReturnValue = true;
			}

			// -------------------------------------------- release the pinned objects
			pinnedReadBuffer.Free();
			return functionReturnValue;
		}

		private void WriteReport_Unix()
		{
			// -------------------------------------------- Send data to the device.
			Int32 Count = default(Int32);
			int NumberOfBytesWritten = 0;

			// -------------------------------------------- The SendBuffer array begins at 0,
			// -------------------------------------------- so subtract 1 from the number of bytes.
			byte[] SendBuffer = new byte[65];

			// -------------------------------------------- The first byte is the Report ID
			SendBuffer[0] = 0;
			// -------------------------------------------- The next bytes are data
            for (Count = 1; Count < SendBuffer.Length; Count++)
            {
                SendBuffer[Count] = USB_TxData[Count - 1];
			}

			NumberOfBytesWritten = HidDevice_Unix.HidWrite(SendBuffer);
		}


		// =================================================================================================
		//  "PUBLIC" FUNCTIONS
		// =================================================================================================
		public void New_Unix()
		{
			Finalize_Unix();
			HidDevice_Unix = new TheHidApi();
		}

		public void Finalize_Unix()
		{
			if (HidDevice_Unix != null && HidDevice_Unix.IsHidOpen()) {
				HidDevice_Unix.HidClose();
			}
			HidDevice_Unix = null;
		}


		// =================================================================================================
		//  Shared methods
		// =================================================================================================
		public static void FindThereminoHids_Unix(bool Reconnect)
		{
			const ushort USB_VendorID = 0x4d8;   // VendorID  = Microchip
			const ushort USB_ProductID = 0x3eff; // ProductID = Theremino

			bool LastDevice = false;
			bool bResult = false;

			LastDevice = false;

			// ------------------------------------------- 
			Int32 masterID = 0;
			Master _master = null;
			_master = new Master(masterID);
			_master.Hid = new Theremino_HID();

			bool Detected = false;

			do {
				Detected = false;

				bResult = true;
				LastDevice = true;

				// ------------------------------------------- If a device exists, display the information returned.

				if (bResult) {
					if (!_master.Hid.HidDevice_Unix.IsHidOpen()) {
						_master.Hid.HidDevice_Unix.HidOpen(USB_VendorID, USB_ProductID, null);
					}

					if (_master.Hid.HidDevice_Unix.IsHidOpen()) {
						Detected = true;
					}

				}

				// -------------------------------------------- Keep looking until we find the device or there are no more left to examine.

				if (Detected) {
					// ---------------------------------------- insert Master and Hid in the Masters list
					_master.Hid.MyDeviceDetected = true;
                    ThereminoSystem.Masters.Add(_master);
					masterID += 1;

					// ---------------------------------------- prepare a new master
					_master = new Master(masterID);
					_master.Hid = new Theremino_HID();

				}

			}
			while (!((LastDevice == true)));

		}

	}
}


