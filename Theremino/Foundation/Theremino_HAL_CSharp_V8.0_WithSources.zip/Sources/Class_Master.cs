using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL
{

	// ==================================================================================================
	//   CLASS MASTER
	// ==================================================================================================

	internal partial class Master
	{

		private object mActionLock = new object();
		private string mName;
		private Int32 mSlaveCount;
        private Int32 mMaxFps;

        internal Theremino_HID Hid;
		internal Int32 ConfigId;
		internal bool ConfigValid;
		internal List<Slave> Slaves;
		internal Int32 MasterId;
        internal Int32 MasterFirmwareVersion;
		
		internal Int32 CommSpeed;
		internal bool FastComm;
		internal float CommMillisec;
		internal float CommFps;
		internal float ErrorRate;
        internal bool HasPhysicalSlaves;

		internal Int32 SlaveCount 
        {
			get { return mSlaveCount; }
		}

        internal void SetCommSpeed(Int32 _speed)
        {
            CommSpeed = _speed;
            switch (CommSpeed)
            {
                case 1: mMaxFps = 10; break;
                case 2: mMaxFps = 20; break;
                case 3: mMaxFps = 30; break;
                case 4: mMaxFps = 50; break;
                case 5: mMaxFps = 60; break;
                case 6: mMaxFps = 100; break;
                case 7: mMaxFps = 150; break;
                case 8: mMaxFps = 200; break;
                case 9: mMaxFps = 300; break;
                case 10: mMaxFps = 400; break;
                case 11: mMaxFps = 500; break;
                default: mMaxFps = 9999; break;
            }
        }

		internal void SetName(string _name)
		{
			mName = _name;
		}

		internal string GetName()
		{
			return mName;
		}

		internal Master(Int32 _masterid)
		{
			mName = "NoName";
			MasterId = _masterid;
            MasterFirmwareVersion = 10; // Initial Master firmware version
			mSlaveCount = 0;
			SetCommSpeed(7);
			FastComm = false;
			CommFps = 100;
			Slaves = new List<Slave>();
		}

		//Protected Overrides Sub Finalize()
        //    If Not Module_SaveLoad.CanUseWindowsDlls() Then
		//        If Hid.HidDevice_Unix.IsHidOpen() Then
		//            Hid.HidDevice_Unix.HidClose()
		//        End If
		//    End If
		//End Sub



		// ==========================================================================================
		//   HOST TO MASTER COMMANDS
		// ==========================================================================================

		internal enum Cmd : byte
		{
			// --------------------------------------- commands that master expands for the slaves
			RECOG_START = 254,
			//CMD_RECOG 						= 253 ( Master to Slaves only )
			FAST_DATA_EXCHANGE = 251,
			//
			// --------------------------------------- commands that master repeats to slaves
			SETUP_SLAVE_PINS = 249,
			SET_MASTER_NAME = 248,
			GET_MASTER_NAME = 247,
			SEND_VALUES = 246,
			GET_VALUES = 245,
			SEND_BYTES = 244,
			GET_BYTES = 243,
			//
			// --------------------------------------- commands to master only  ( < 200 )
			SPEED = 199,
			NOCMD = 0
		}

        internal enum CommandsToHardware : int
        {
            SendStepperParams = 100,
            GetMasterFirmwareVersion = 101,
            SendAdc24Config = 102
        }


		// ==========================================================================================
		//   PUBLIC COMMANDS
		// ==========================================================================================

		internal void Calibrate()
		{
			if (!CalibrationNeeded()) return;
 
			DataExchangeThread_Stop();
			lock (mActionLock) {
                System.Threading.Thread.Sleep(10);
				DataExchange();
                System.Threading.Thread.Sleep(10);
				for (Int32 i = 0; i <= SlaveCount - 1; i++) {
                    Slaves[i].Calibrate();
				}
			}
			DataExchangeThread_Start();
		}

		internal void CalibrateZero()
		{
			for (Int32 i = 0; i <= SlaveCount - 1; i++) {
				Slaves[i].CalibrateZero();
			}
		}

        internal bool CalibrationNeeded()
        {
            for (Int32 i = 0; i <= SlaveCount - 1; i++)
            {
                if (Slaves[i].CalibrationNeeded())
                {
                    return true;
                }
            }
            return false;
        }

		internal void SetSpeed()
		{
			DataExchangeThread_Stop();
			lock (mActionLock) {
				SendSpeedToSlaves();
			}
			DataExchangeThread_Start();
		}

		internal void SetSpeed(Int32 _Speed)
		{
			DataExchangeThread_Stop();
			lock (mActionLock) {
				SetCommSpeed(_Speed);
				SendSpeedToSlaves();
			}
			DataExchangeThread_Start();
		}



		internal void Recognize()
		{
			//' ------------------------------------------------- try to unlock slaves
			//Dim b(60) As Byte
			//SendBytesToSlave(255, b)
            //Module_Utils.SleepMyThread(100)
			//' -------------------------------------------------

			DataExchangeThread_Stop();
			lock (mActionLock) {
				Slaves.Clear();
                // --------------------------------------------- SPEED - TODO test with a great number of slaves
				SendSpeedToSlaves();
				SendSpeedToSlaves();
				//SendSpeedToSlaves()
				//SendSpeedToSlaves()
				//SendSpeedToSlaves()
				//SendSpeedToSlaves()
				// --------------------------------------------- DETECT
				Hid.USB_TxData[0] = (byte)Cmd.RECOG_START;
				Hid.USB_TxData[1] = 0;
				// --------------------------------------------- WRITE-READ
				Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
                mSlaveCount = Hid.USB_RxData[1];
                Slave.SlaveTypes[] slave_types = new Slave.SlaveTypes[SlaveCount];
                for (Int32 i = 0; i <= SlaveCount - 1; i++)
                {
                    slave_types[i] = (Slave.SlaveTypes)Hid.USB_RxData[i + 2];
                }
				// --------------------------------------------- ERROR ?
				if (Hid.USB_RxData[0] != 0) 
                {
					Execution_Error("Recognize");
				}
				else 
                {
					Execution_OK();
				}
                // --------------------------------------------- Master firmware version
                GetMasterFirmwareVersion();
				// --------------------------------------------- INIT 
                HasPhysicalSlaves = false;
				
				for (Int32 i = 0; i <= mSlaveCount - 1; i++) 
                {
                    Slave.SlaveTypes s = slave_types[i];
					switch (s) 
                    {
						case Slave.SlaveTypes.CapSensor:
							Slaves.Add(new Slave_CapSensor(MasterId, i));
                            HasPhysicalSlaves = true;
							break;
						case Slave.SlaveTypes.Servo:
							Slaves.Add(new Slave_Servo(MasterId, i));
                            HasPhysicalSlaves = true;
							break;
						case Slave.SlaveTypes.Generic:
							Slaves.Add(new Slave_Generic(MasterId, i));
                            HasPhysicalSlaves = true;
							break;
						case Slave.SlaveTypes.InOut:
							Slaves.Add(new Slave_InOut(MasterId, i));
                            HasPhysicalSlaves = true;
							break;
						case Slave.SlaveTypes.MasterPins:
							Slaves.Add(new Slave_MasterPins(MasterId, i));
							break;
                        case Slave.SlaveTypes.MasterPinsV2:
                            Slaves.Add(new Slave_MasterPinsV2(MasterId, i));
                            break;
                        case Slave.SlaveTypes.MasterPinsV4:
                            Slaves.Add(new Slave_MasterPinsV4(MasterId, i));
                            break;
						default:
							mSlaveCount = 0;
							Slaves.Clear();
							break;
					}
				}
			}
			DataExchangeThread_Start();
		}

        internal void  GetMasterFirmwareVersion()
        {
            Int32 slavesCount = Hid.USB_RxData[1];
            Slave.SlaveTypes virtualSlaveType =  (Slave.SlaveTypes)Hid.USB_RxData[2];
            if (slavesCount > 0)
            {
                switch (virtualSlaveType)
                {
                    case Slave.SlaveTypes.MasterPins:
                        MasterFirmwareVersion = 20;                       // Version 2.0 - six Master Pins
                        break;
                    case Slave.SlaveTypes.MasterPinsV2:
                        MasterFirmwareVersion = 32;                       // Version 3.2 - ten Master Pins with Stepper and PwmFast management
                        break;
                    case Slave.SlaveTypes.MasterPinsV4:
                        MasterFirmwareVersion = 40;                       // by now Version 4.0 - twelve Master Pins with Encoder management
                        ReadFirmwareVersionFromHardware();
                        if (MasterFirmwareVersion < 41)
                            MasterFirmwareVersion = 40;                   // Version 4.0 - twelve Master Pins with Encoder management
                        break;
                }
            }
        }

        internal void  ReadFirmwareVersionFromHardware()
        {
            // ---------------------------------------------------- send CMD / SlaveId / Nbytes
            Hid.USB_TxData[0] = (byte)Cmd.SEND_BYTES;
            Hid.USB_TxData[1] = 0; //unused SlaveId
            Hid.USB_TxData[2] = 1; //bytes.Length
            Hid.USB_TxData[3] = (byte)CommandsToHardware.GetMasterFirmwareVersion;

            Hid.USB_Write_Read();
            Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
            // --------------------------------------------- if not error
            if (Hid.USB_RxData[0] == 0)
            {
                MasterFirmwareVersion = Hid.USB_RxData[1];   // Version 4.1 and following - twelve Master Pins with Adc24 management
            }
        }


		internal void SetupSlavePins(Int32 slaveID)
		{
			DataExchangeThread_Stop();
			lock (mActionLock) {
				Slave s = Slaves[slaveID];
                Hid.USB_TxData[0] = (byte)Cmd.SETUP_SLAVE_PINS;
				Hid.USB_TxData[1] = (byte)slaveID;
				Hid.USB_TxData[2] = (byte)s.Pins.Count;
				for (Int32 i = 0; i <= s.Pins.Count - 1; i++) 
                {
					Hid.USB_TxData[i + 3] = (byte)s.Pins[i].GetPinType();
				}
				Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
				// --------------------------------------------- error ?
				if (Hid.USB_RxData[0] != 0) {
					Execution_Error("SetupSlavePins");
				}
				else {
					Execution_OK();
				}
				// ---------------------------------------------
				SetCommunicationIndexesToPins();
			}
			DataExchangeThread_Start();
		}

		internal void WriteNameToHardware()
		{
			DataExchangeThread_Stop();
			lock (mActionLock) 
            {
                Hid.USB_TxData[0] = (byte)Cmd.SET_MASTER_NAME;
				Int32 i = default(Int32);
				for (i = 1; i <= mName.Length; i++) {
					Hid.USB_TxData[i] = (byte)Strings.Asc(Strings.Mid(mName, i, 1));
				}
				Hid.USB_TxData[i] = (byte)0;
				Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
				// --------------------------------------------- error ?
				if (Hid.USB_RxData[0] != 0) {
					Execution_Error("WriteNameToHardware");
				}
				else {
					Execution_OK();
				}
			}
			DataExchangeThread_Start();
		}

		internal void ReadNameFromHardware()
		{
			DataExchangeThread_Stop();
			lock (mActionLock) {
				mName = "";
                Hid.USB_TxData[0] = (byte)Cmd.GET_MASTER_NAME;
				Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
				// --------------------------------------------- error ?
				if (Hid.USB_RxData[0] == 0) 
                {
					Int32 i = 1;
					do 
                    {
						if (Hid.USB_RxData[i] == 0) break;
 
						mName += Strings.Chr(Hid.USB_RxData[i]);
						i += 1;
					}
					while (true);
                    mName = mName.Trim();
					Execution_OK();
				}
				else {
					Execution_Error("ReadNameFromHardware");
				}
			}
			DataExchangeThread_Start();
		}



		internal void SetOutputPinsToParkingPosition()
		{
			DataExchangeThread_Stop();
			lock (mActionLock) {
				foreach (Slave s in Slaves) 
                {
					foreach (Pin p in s.Pins) 
                    {
						if (p.Direction == Pin.Directions.HostToMaster) 
                        {

                            // ------------------------------------------------------
                            //  Steppers excluded to avoid problems
                            //  (maybe in the future we could implement a NAN_Sleep)
                            // ------------------------------------------------------
                            if (p.GetPinType() == Pin.PinTypes.STEPPER) continue;
                            // ------------------------------------------------------

                            p.Value = p.Value_Parking;
                            if (float.IsNaN(p.Value))
                            {
                                ThereminoSlots.WriteSlot(p.Slot, p.Value);
                            }
                            else
                            {
                                p.ConvertValueToHardwareFormat();
                                ThereminoSlots.WriteSlot(p.Slot, p.Value_RawUinteger);
                            }
						}
					}
				}
				// ------------------------------------------------- USB <> Master <> Slaves
				DataExchange();
                System.Threading.Thread.Sleep(32);
			}
			DataExchangeThread_Start();
		}

		internal void SetCommunicationIndexesToPins()
		{
			// ---------------------------------------------------- byte 0 is the command
			Int32 UsbByteIndex_HostToHardware = 1;
			// ---------------------------------------------------- byte 0 is the response
			Int32 UsbByteIndex_HardwareToHost = 1;
			//
			foreach (Slave s in Slaves) 
            {
				foreach (Pin p in s.Pins)
                {
					// --------------------------------------------------- USB communication byte index
					switch (p.Direction) 
                    {
						case Pin.Directions.HostToMaster:
							p.UsbByteIndex = UsbByteIndex_HostToHardware;
							UsbByteIndex_HostToHardware += p.UsbBytesCount;
							break;
						case Pin.Directions.MasterToHost:
							p.UsbByteIndex = UsbByteIndex_HardwareToHost;
							UsbByteIndex_HardwareToHost += p.UsbBytesCount;
							break;
					}
					//Debug.Print(p.PinId.ToString & "  " & Pin.PinTypeToString(p.GetPinType) & "  " & p.UsbByteIndex)
				}
			}
		}


		// ==========================================================================================
		//   INTERNAL COMMANDS
		// ==========================================================================================
		private void SendSpeedToSlaves()
		{
			//
            Hid.USB_TxData[0] = (byte)Cmd.SPEED;
			Hid.USB_TxData[1] = (byte)CommSpeed;
			//
			Hid.USB_Write_Read();
            Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
			// --------------------------------------------- error ?
			if (Hid.USB_RxData[0] != 0) {
				Execution_Error("SendSpeedToSlaves");
			}
			else {
				Execution_OK();
			}
		}

        // ==========================================================================================
        //   GET/SEND - VALUES/BYTES - FROM/TO SLAVES
        // ==========================================================================================
        internal bool GetValuesFromSlave(Int32 SlaveId, ref byte[] ByteArray)
        {
            // ----------------------------------------------------
            // SyncLock not needed because called from timer
            // ---------------------------------------------------- send CMD / SlaveId / Nbytes
            Hid.USB_TxData[0] = (byte)Cmd.GET_VALUES;
            Hid.USB_TxData[1] = (byte)SlaveId;
            Hid.USB_TxData[2] = (byte)ByteArray.Length;
            // ---------------------------------------------------- send and receive
            Hid.USB_Write_Read();
            Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
            // ---------------------------------------------------- get bytes
            for (Int32 i = 0; i <= ByteArray.Length - 1; i++)
            {
                ByteArray[i] = Hid.USB_RxData[i + 1];
            }
            // ---------------------------------------------------- manage errors
            if (Hid.USB_RxData[0] != 0)
            {
                Execution_Error("GetValuesFromSlave");
                return false;
            }
            else
            {
                Execution_OK();
            }
            return true;
        }

        internal void SendValuesToSlave(Int32 SlaveId, ref byte[] bytes)
        {
            // ----------------------------------------------------
            // SyncLock not needed because called from timer
            // ---------------------------------------------------- send CMD / SlaveId / Nbytes
            Hid.USB_TxData[0] = (byte)Cmd.SEND_VALUES;
            Hid.USB_TxData[1] = (byte)SlaveId;
            Hid.USB_TxData[2] = (byte)bytes.Length;
            // ---------------------------------------------------- send bytes
            for (Int32 i = 0; i <= bytes.Length - 1; i++)
            {
                Hid.USB_TxData[3 + i] = bytes[i];
            }
            // ---------------------------------------------------- send and receive
            Hid.USB_Write_Read();
            Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
            // ---------------------------------------------------- manage errors
            if (Hid.USB_RxData[0] != 0)
            {
                Execution_Error("SendValuesToSlave");
            }
            else
            {
                Execution_OK();
            }
        }



        internal void GetBytesFromSlave(Int32 SlaveId, ref byte[] ByteArray)
        {
            DataExchangeThread_Stop();
            lock (mActionLock)
            {
                // ---------------------------------------------------- send CMD / SlaveId / Nbytes
                Hid.USB_TxData[0] = (byte)Cmd.GET_BYTES;
                Hid.USB_TxData[1] = (byte)SlaveId;
                Hid.USB_TxData[2] = (byte)ByteArray.Length;
                // ---------------------------------------------------- send and receive
                Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
                // ---------------------------------------------------- get bytes
                for (Int32 i = 0; i <= ByteArray.Length - 1; i++)
                {
                    ByteArray[i] = Hid.USB_RxData[i + 1];
                }
                // ---------------------------------------------------- manage errors
                if (Hid.USB_RxData[0] != 0)
                {
                    Execution_Error("GetBytesFromSlave");
                }
                else
                {
                    Execution_OK();
                }
            }
            DataExchangeThread_Start();
        }

        internal void SendBytesToSlave(Int32 SlaveId, ref byte[] bytes)
        {
            DataExchangeThread_Stop();
            lock (mActionLock)
            {
                // ---------------------------------------------------- send CMD / SlaveId / Nbytes
                Hid.USB_TxData[0] = (byte)Cmd.SEND_BYTES;
                Hid.USB_TxData[1] = (byte)SlaveId;
                Hid.USB_TxData[2] = (byte)bytes.Length;
                // ---------------------------------------------------- send bytes
                for (Int32 i = 0; i <= bytes.Length - 1; i++)
                {
                    Hid.USB_TxData[3 + i] = bytes[i];
                }
                // ---------------------------------------------------- send and receive
                Hid.USB_Write_Read();
                Hid.USB_TxData[0] = (byte)Cmd.NOCMD;
                // ---------------------------------------------------- manage errors
                if (Hid.USB_RxData[0] != 0)
                {
                    Execution_Error("SendBytesToSlave");
                }
                else
                {
                    Execution_OK();
                }
            }
            DataExchangeThread_Start();
        }


        private void Execution_Error(string ErrorString)
        {
            ErrorRate += 0.01f;
            Debug.Print("ERROR - " + ErrorString);
        }

        private void Execution_OK()
        {
            ErrorRate *= 0.95f;
        }



		// ==========================================================================================
		//   SMOOTHING FUNCTIONS
		// ==========================================================================================
        internal void SmoothValue(ref float value, float new_value, float speed, bool pow_speed)
		{
            if (speed == 100 || float.IsNaN(value) || float.IsNaN(new_value)) 
            {
				value = new_value;
				return;
			}

            // --------------------------------------------------- exclude gradually the smoothing 
            switch (Convert.ToInt32(speed))
            {
                case 98: speed = 150; break;
                case 99: speed = 200; break;
            }

            if (pow_speed)
            {
                // ------------------------------------------------ correction to have a similar response
                speed *= 27;
                //
                float delta = new_value - value;
                float delta_sgn = Math.Sign(delta);
                float delta_abs = Math.Abs(delta);

                float delta_pow = (float)Math.Pow(delta_abs, 2) * speed / CommFps;
                if (value != 0) delta_pow /= Math.Abs(value);
                
                if (delta_pow >= delta_abs)
                {
                    value = new_value;
                }
                else
                {
                    value += delta_sgn * delta_pow;
                }
            }
            else
            {
                float delta = new_value - value;
                float delta_sgn = Math.Sign(delta);
                float delta_abs = Math.Abs(delta);
                float delta_pow = (float)speed / CommFps * delta_abs;
                if (delta_pow >= delta_abs)
                {
                    value = new_value;
                }
                else
                {
                    value += delta_sgn * delta_pow;
                }
            }
		}


		// ==========================================================================================
		//   LOOPS AND COMMUNICATIONS
		// ==========================================================================================
        private System.Diagnostics.Stopwatch sw1 = new System.Diagnostics.Stopwatch();
        private float rawMs;
        private Int32 delayMs;
		private void DataExchange()
		{
            // ---------------------------------------------------------- if disconnected return
            if (!Hid.MyDeviceDetected)
            {
                CommFps = 0;
                ErrorRate = 100;
                System.Threading.Thread.Sleep(10);
                return;
            }
            // ---------------------------------------------------------- 
            //CommMillisec = (float)(sw1.Elapsed.TotalMilliseconds - 0.1);
            //CommMillisec = (float)(sw1.Elapsed.TotalMilliseconds);
			CommMillisec = (float)(sw1.ElapsedMilliseconds);
            rawMs = 1000f / CommMillisec;
			sw1.Reset();
			sw1.Start();
			if (CommMillisec >= 1) 
            {
                SmoothValue(ref CommFps, rawMs, 1, true);
			}
			try {
				if (FastComm) 
                {
					FastDataExchange();
				}
				else 
                {
					SlowDataExchange();
				}
                // -------------------------------------------------------- adaptive FPS
                if (mMaxFps < 9999)
                {
                    if (!HasPhysicalSlaves)
                    {
                        delayMs += Math.Sign(rawMs - mMaxFps);
                        if (delayMs > 100) delayMs = 100;
                        if (delayMs <= 0)
                        {
                            delayMs = 0;
                        }
                        else
                        {
                            System.Threading.Thread.Sleep(delayMs);
                        }
                    }
                }
			}

			catch {
                	#if DEBUG
                    Module_Utils.Beep_RepetitionLimited(150);
				    //MsgBox("Exception in ""DataExchange""")
				    Debug.Print("Exception in \"DataExchange\"");	
                    #endif
                  }
        }


        // ==========================================================================================
        //   SLOW DATA EXCHANGE
        // ==========================================================================================
		private void SlowDataExchange()
		{
			Int32 ix = default(Int32);
			byte[] b = null;
			bool ExchangedFlag = false;
			// -------------------------------------------------------- MMF to USB
			foreach (Slave s in Slaves) 
            {
				Int32 nbytes = s.GetHostToMasterBytesCount();
				if (nbytes > 0) 
                {
					foreach (Pin p in s.Pins) 
                    {
						if (p.Direction == Pin.Directions.HostToMaster) 
                        {
							p.ReadValueFromMMF();
							p.ConvertValueToHardwareFormat();
						}
					}
                    // ------------------------------------------------ 
                    StepperInterpolate(s);
                    // ------------------------------------------------
                    ix = 0;
                    b = new byte[nbytes];
                    foreach (Pin p in s.Pins)
                    {
                        if (p.Direction == Pin.Directions.HostToMaster)
                        {
                            p.WriteValueToByteArray(ref b, ref ix);
                        }
                    }
                    // ------------------------------------------------
					SendValuesToSlave(s.mSlaveId, ref b);
					ExchangedFlag = true;
				}
			}
			// -------------------------------------------------------- USB to MMF
			foreach (Slave s in Slaves) 
            {
				Int32 nbytes = s.GetMasterToHostBytesCount();
				if (nbytes > 0) 
                {
					ExchangedFlag = true;
					ix = 0;
					b = new byte[nbytes];
					if (GetValuesFromSlave(s.mSlaveId, ref b)) 
                    {
						foreach (Pin p in s.Pins) 
                        {
							if (p.Direction == Pin.Directions.MasterToHost) 
                            {
                                p.SetValueFromByteArray(b, ref ix);
								p.ConvertValueFromHardwareFormat();
								p.WriteValueToMMF();
							}
						}
					}
				}
			}
			// --------------------------------------------------------  do not charge the cpu if not exchanged
			if (!ExchangedFlag) 
            {
				Hid.USB_Write_Read();
			}
		}

        // ==========================================================================================
        //   FAST DATA EXCHANGE
        // ==========================================================================================
		private void FastDataExchange()
		{
			// -------------------------------------------------------- fast data exchange
            Hid.USB_TxData[0] = (byte)Cmd.FAST_DATA_EXCHANGE;

			// -------------------------------------------------------- MMF to USB
			foreach (Slave s in Slaves) 
            {
				foreach (Pin p in s.Pins) 
                {
					if (p.Direction == Pin.Directions.HostToMaster) 
                    {
						p.ReadValueFromMMF();
						p.ConvertValueToHardwareFormat();
					}
				}
                // ----------------------------------------------------
                StepperInterpolate(s);
                // ----------------------------------------------------
                foreach (Pin p in s.Pins)
                {
                    if (p.Direction == Pin.Directions.HostToMaster)
                    {
                        p.WriteValueToUsbBuffer();
                    }
                }
			}

			// -------------------------------------------------------- USB <> Master <> Slaves
			//Hid.disable_for_test = True
			Hid.USB_Write_Read();
			//Hid.disable_for_test = False
            Hid.USB_TxData[0] = (byte)Cmd.NOCMD;

			// -------------------------------------------------------- manage errors
			if (Hid.USB_RxData[0] == 0) {
				// ---------------------------------------------------- USB to MMF
				foreach (Slave s in Slaves) 
                {
					foreach (Pin p in s.Pins) 
                    {
						if (p.Direction == Pin.Directions.MasterToHost) 
                        {
							p.ReadValueFromUsbBuffer();
							p.ConvertValueFromHardwareFormat();
							p.WriteValueToMMF();
						}
					}
				}
				Execution_OK();
			}
			else {
				Execution_Error("FastDataExchange");
			}

		}


        // ==========================================================================================
        //   STEPPER INTERPOLATE
        // ==========================================================================================
        private void StepperInterpolate(Slave s)
        {
        }

	}
}

