using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL
{

	internal partial class Master
	{

		private bool TimerEnabled = false;
		private bool ThreadStop = false;

		private System.Threading.Thread objThread;
		private void DataExchangeThread()
		{
			do 
            {
				if (!TimerEnabled) break; 
				if (ThreadStop) break;
				DataExchange();
			}
			while (true);
		}

		private void DataExchangeThread_Start()
		{
			if (!TimerEnabled) return; 
			lock (mActionLock) 
            {
				if (objThread == null) {
					objThread = new System.Threading.Thread(DataExchangeThread);
					// --------------------------------------------------------- make the thread as background thread.
                    objThread.IsBackground = true;
					// --------------------------------------------------------- set the Priority of the thread.
                    objThread.Priority = System.Threading.ThreadPriority.Highest;
					// --------------------------------------------------------- start the thread.
					ThreadStop = false;
					objThread.Start();
				}
				System.Threading.Thread.Sleep(0);
			}
		}

		private void DataExchangeThread_Stop()
		{
			ThreadStop = true;
            if (objThread != null) objThread.Join(2000);
			objThread = null;
		}

		internal void StartTimedOperations()
		{
            if (ConfigValid == false) return;
			lock (mActionLock) 
            {
                TimerEnabled = true;
                DataExchangeThread_Start();
			}
		}

		internal void StopTimedOperations()
		{
			lock (mActionLock) 
            {
                TimerEnabled = false;
                DataExchangeThread_Stop();
			}
		}

	}
}
