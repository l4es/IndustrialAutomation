using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

using System.Globalization;
//using System.Math;
namespace Theremino_HAL
{

	// ==================================================================================================
	//   CLASS PIN
	// ==================================================================================================
	class Pin
	{
		internal enum Directions : int
		{
			Unused = 0,
			HostToMaster = 1,
			MasterToHost = 2
		}

		internal enum PinTypes : int
		{
			UNUSED = 0,

			DIG_OUT = 1,
			PWM_8 = 2,
			PWM_16 = 3,
			SERVO_8 = 4,
			SERVO_16 = 5,
            STEPPER = 6,
            PWM_FAST = 7,

			DIG_IN = 129,
			DIG_IN_PU = 130,

			ADC_8 = 131,
			ADC_16 = 132,
			CAP_8 = 133,
			CAP_16 = 134,
			RES_8 = 135,
			RES_16 = 136,

			COUNTER = 140,
			COUNTER_PU = 141,

			FAST_COUNTER = 142,
			FAST_COUNTER_PU = 143,

			PERIOD = 144,
			PERIOD_PU = 145,

            SLOW_PERIOD = 146,
            SLOW_PERIOD_PU = 147,

			USOUND_SENSOR = 150,

			CAP_SENSOR = 160,

            STEPPER_DIR = 165, // STEPPER_DIR is an hardware output but it sends steps-from-destination to USB

			//I2C_SDA = 170,
			//I2C_SCL = 171,

            ADC_24 = 173,
            ADC_24_DIN = 174,
            ADC_24_DOUT = 175,
            ADC_24_CH = 176,
            ADC_24_CH_B = 177,

            ENCODER_A = 180,
            ENCODER_A_PU = 181,
            ENCODER_B = 182,
            ENCODER_B_PU = 183,

			//SNIFFER = 190,
		}


		public static PinTypes StringToPinType(string PinTypeString)
		{
			switch (Strings.UCase(PinTypeString.Trim())) {
				case "UNUSED": return PinTypes.UNUSED;

				case "DIG_OUT": return PinTypes.DIG_OUT;
				case "PWM_8": return PinTypes.PWM_8;
				case "PWM_16": return PinTypes.PWM_16;
				case "SERVO_8": return PinTypes.SERVO_8;
				case "SERVO_16": return PinTypes.SERVO_16;
                case "STEPPER": return PinTypes.STEPPER;
                case "STEPPER_DIR": return PinTypes.STEPPER_DIR; // This is an input but also an hardware output
                case "PWM_FAST": return PinTypes.PWM_FAST;

				case "DIG_IN": return PinTypes.DIG_IN;
				case "DIG_IN_PU": return PinTypes.DIG_IN_PU;

                case "CAP_8": return PinTypes.CAP_8;
                case "CAP_16": return PinTypes.CAP_16;
                case "RES_8": return PinTypes.RES_8;
                case "RES_16": return PinTypes.RES_16;

				case "ADC_8": return PinTypes.ADC_8;
				case "ADC_16": return PinTypes.ADC_16;
                case "ADC_24": return PinTypes.ADC_24;
                case "ADC_24_DIN": return PinTypes.ADC_24_DIN;
                case "ADC_24_DOUT": return PinTypes.ADC_24_DOUT;
                case "ADC_24_CH": return PinTypes.ADC_24_CH;
                case "ADC_24_CH_B": return PinTypes.ADC_24_CH_B;

				case "COUNTER": return PinTypes.COUNTER;
				case "COUNTER_PU": return PinTypes.COUNTER_PU;

				case "FAST_COUNTER": return PinTypes.FAST_COUNTER;
				case "FAST_COUNTER_PU": return PinTypes.FAST_COUNTER_PU;
				
                case "PERIOD": return PinTypes.PERIOD;
				case "PERIOD_PU": return PinTypes.PERIOD_PU;

                case "SLOW_PERIOD": return PinTypes.SLOW_PERIOD;
                case "SLOW_PERIOD_PU": return PinTypes.SLOW_PERIOD_PU;

				case "USOUND_SENSOR": return PinTypes.USOUND_SENSOR;

                case "CAP_SENSOR": return PinTypes.CAP_SENSOR;

                case "ENCODER_A" : return PinTypes.ENCODER_A;
                case "ENCODER_A_PU" : return PinTypes.ENCODER_A_PU;
                case "ENCODER_B" : return PinTypes.ENCODER_B;
                case "ENCODER_B_PU" : return PinTypes.ENCODER_B_PU;
			}
            return PinTypes.UNUSED;
		}

		public static string PinTypeToString(PinTypes pintype)
		{
			string s = "";
			switch (pintype) {
				case PinTypes.UNUSED: s = "UNUSED"; break;
				case PinTypes.DIG_OUT: s = "DIG_OUT"; break;
				case PinTypes.PWM_8: s = "PWM_8"; break;
				case PinTypes.PWM_16: s = "PWM_16"; break;
				case PinTypes.SERVO_8: s = "SERVO_8"; break;
				case PinTypes.SERVO_16: s = "SERVO_16"; break;
                case PinTypes.STEPPER: s = "STEPPER"; break;
                case PinTypes.STEPPER_DIR: s = "STEPPER_DIR"; break; // This is an input but also an hardware output
                case PinTypes.PWM_FAST: s = "PWM_FAST"; break;

				case PinTypes.DIG_IN: s = "DIG_IN"; break;
				case PinTypes.DIG_IN_PU: s = "DIG_IN_PU"; break;

                case PinTypes.CAP_8: s = "CAP_8"; break;
                case PinTypes.CAP_16: s = "CAP_16"; break;
                case PinTypes.RES_8: s = "RES_8"; break;
                case PinTypes.RES_16: s = "RES_16"; break;

				case PinTypes.ADC_8: s = "ADC_8"; break;
				case PinTypes.ADC_16: s = "ADC_16"; break;
                case PinTypes.ADC_24: s = "ADC_24"; break;
                case PinTypes.ADC_24_DIN: s = "ADC_24_DIN"; break;
                case PinTypes.ADC_24_DOUT: s = "ADC_24_DOUT"; break;
                case PinTypes.ADC_24_CH: s = "ADC_24_CH"; break;
                case PinTypes.ADC_24_CH_B: s = "ADC_24_CH_B"; break;

				case PinTypes.COUNTER: s = "COUNTER"; break;
				case PinTypes.COUNTER_PU: s = "COUNTER_PU"; break;
				case PinTypes.FAST_COUNTER: s = "FAST_COUNTER"; break;
				case PinTypes.FAST_COUNTER_PU: s = "FAST_COUNTER_PU"; break;
				case PinTypes.PERIOD: s = "PERIOD"; break;
				case PinTypes.PERIOD_PU: s = "PERIOD_PU"; break;
                case PinTypes.SLOW_PERIOD: s = "SLOW_PERIOD"; break;
                case PinTypes.SLOW_PERIOD_PU: s = "SLOW_PERIOD_PU"; break;
				case PinTypes.USOUND_SENSOR: s = "USOUND_SENSOR"; break;
				case PinTypes.CAP_SENSOR: s = "CAP_SENSOR"; break;
                case PinTypes.ENCODER_A: s = "ENCODER_A"; break;
                case PinTypes.ENCODER_A_PU: s = "ENCODER_A_PU"; break;
                case PinTypes.ENCODER_B: s = "ENCODER_B"; break;
                case PinTypes.ENCODER_B_PU: s = "ENCODER_B_PU"; break;
			}
            return Module_Utils.CamelCaseString(s);
		}

		internal Int32 MasterId;
		internal Int32 SlaveId;
		internal Int32 PinId;
		private PinTypes PinType;
		internal Directions Direction;
		// ------------------------------------------- slot 0 to 999 starting from the pin near to master
		internal Int32 Slot;
		// ------------------------------------------- byte index in the USB buffer ( HostToMaster or MasterToHost )
		internal Int32 UsbByteIndex;
		// ------------------------------------------- bytes used by this pin in the USB(Host-Master) communications
		internal Int32 UsbBytesCount;
		// ------------------------------------------- bytes used by this pin in the COM(Master-Slave) communications

		internal Int32 ComBytesCount;
		// ------------------------------------------- all pins
        internal Int32 Value_RawInteger;
        internal UInt32 Value_RawUinteger;
		internal UInt32 Value_RawUinteger_Old;
        internal UInt32 Value_RawUinteger_Zero;
		internal float Value_RawSmoothed;
        internal UInt32 Value_Uinteger_Max;
        internal UInt32 Value_Uinteger_Min;
		internal float Value;
		internal float Value_Max;
		internal float Value_Min;
		internal float Value_Parking;
        internal float Value_Normalized = 0;
		internal float Value_Normalized_New;
        internal float Value_Zero;
        internal bool  AdaptiveSpeed;
		internal Int32 ResponseSpeed;
		internal Int32 RepTime;
        internal Double OldTimeMilliseconds;
        internal Double NewTimeMilliseconds;
		// ------------------------------------------ Servo and Pwm specific
		internal float MaxTime;
		internal float MinTime;
		internal bool LogResponse;
        // ------------------------------------------ Stepper specific
        internal float MaxSpeed;
        internal float MaxAcc;
        internal float StepsPerMillimeter;
        internal Int32 StepperSpeed_Hz;
        internal Int32 StepperAcc_Hz_per_mS; 
        internal bool LinkedToPrevious;
        // ------------------------------------------ Pwm Fast specific
        internal float PwmFastFrequency;
        internal float PwmFastDutyCycle;
        internal bool FrequencyFromSlot;
        internal bool DutyCycleFromSlot;
		// ------------------------------------------ Counter and Period specific
		internal bool ConvertToFreq;
		internal float MaxFreq;
		internal float MinFreq;
		// ------------------------------------------ Usound_sensor and Cap_sensor specific
        internal bool RemoveErrors;
		internal float Dist_mm;
		internal float MaxDist_mm;
		internal float MinDist_mm;
		// ------------------------------------------ Touch specific
		internal float MinVariation;
		internal float ProportionalArea;
		internal float MeanValue;
        private float Velocity = 0;
        private float oldDelta1;
        private float oldDelta2;
        private float oldDelta3;

		// ------------------------------------------ Adc_24 specific
        internal Int32 Adc24Npins;              // Number of desired adc24 pins
        internal Int32 Adc24Sps;                // Samples per second
        internal Int32 Adc24Filter;             // Filters 0 to 7

        // ------------------------------------------ Adc_24_channel specific
        internal Int32 Adc24ChType;             // (0 to 2) Diff / Pseudo / Single ended
        internal Int32 Adc24ChGain;             // (0 to 7) 1,2,4,8,16,32,64,128
        internal bool Adc24ChBias;              // Bias on off

		// ------------------------------------------ Cap_sensor specific
		internal Int32 ErrorCounter;
		internal Int32 TimerDivision;
		internal Int32 TimerFrequencyKhz;
		internal float Inductor_uh;
		internal float Area_cmq;
		//
		internal float Millisec;
		internal float Freq;
		//
        private string IntegratedFreqString = "";
        private double IntegratedFreq;
        private Int32 IntegratedlFreqCounter;
        //
		internal double Cap_serial;
		internal float Cap_total;
		internal float Cap_zero;

		internal float Cap_input;


		internal Pin(PinTypes _pintype, Int32 _masterid, Int32 _slaveid, Int32 _pinid)
		{
			MasterId = _masterid;
			SlaveId = _slaveid;
			PinId = _pinid;
			RepTime = 1;
			SetPinType(_pintype);
		}

		internal PinTypes GetPinType()
		{
			return PinType;
		}


		// ==================================================================================================
		//   DEFAULTS
		// ==================================================================================================

		internal void SetPinType(PinTypes _pintype)
		{
			if (PinType == _pintype) return; 
			PinType = _pintype;
			//
            Value_Parking = 0;
            Value_Max = 1000;
            Value_Min = 0;
            MaxFreq = 1000;
            MinFreq = 0;
            AdaptiveSpeed = false;
			ResponseSpeed = 100;
            LogResponse = false;
			// --------------------------------------------------------- defaults
			switch (PinType) {

				// ----------------------------------------------------- outputs
				case PinTypes.DIG_OUT:
					UsbBytesCount = 1;
					ComBytesCount = 1;
					break;
				case PinTypes.PWM_8:
					MaxTime = 4000;
					MinTime = 0;
					UsbBytesCount = 1;
					ComBytesCount = 1;
					break;
				case PinTypes.PWM_16:
					MaxTime = 4000;
					MinTime = 0;
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;
				case PinTypes.SERVO_8:
                    Value_Parking = Theremino.NAN_Sleep;
					MaxTime = 2500;
					MinTime = 500;
					UsbBytesCount = 1;
					ComBytesCount = 1;
					break;
				case PinTypes.SERVO_16:
                    Value_Parking = Theremino.NAN_Sleep;
					MaxTime = 2500;
					MinTime = 500;
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;
                case PinTypes.STEPPER:
                    MaxSpeed = 200;
                    MaxAcc = 50;
                    LinkedToPrevious = false;
                    StepsPerMillimeter = 200;
                    UsbBytesCount = 4;
                    ComBytesCount = 4;
                    break;
                case PinTypes.PWM_FAST:
                    PwmFastFrequency = 1000;
                    PwmFastDutyCycle = 500;
                    FrequencyFromSlot = false;
                    DutyCycleFromSlot = false;
                    UsbBytesCount = 5;
                    ComBytesCount = 5;
                    break;

				// ------------------------------------------------- inputs
				case PinTypes.DIG_IN:
				case PinTypes.DIG_IN_PU:
					Value_Parking = 0;
					UsbBytesCount = 1;
					ComBytesCount = 1;
					break;

                case PinTypes.CAP_8:
                    MinVariation = 20;
                    ProportionalArea = 0;
                    MeanValue = 0;
                    ResponseSpeed = 30;
                    UsbBytesCount = 1;
                    ComBytesCount = 1;
                    break;
                case PinTypes.CAP_16:
                    MinVariation = 20;
                    ProportionalArea = 0;
                    MeanValue = 0;
                    ResponseSpeed = 30;
                    UsbBytesCount = 2;
                    ComBytesCount = 2;
                    break;
                case PinTypes.RES_8:
                    ResponseSpeed = 30;
                    UsbBytesCount = 1;
                    ComBytesCount = 1;
                    break;
                case PinTypes.RES_16:
                    ResponseSpeed = 30;
                    UsbBytesCount = 2;
                    ComBytesCount = 2;
                    break;

				case PinTypes.ADC_8:
					ResponseSpeed = 30;
					UsbBytesCount = 1;
					ComBytesCount = 1;
					break;
				case PinTypes.ADC_16:
					ResponseSpeed = 30;
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;

                case PinTypes.ADC_24:
                    Adc24Npins = 16;
                    Adc24Sps = 100;
                    Adc24Filter = 0;
                    UsbBytesCount = 0;
                    ComBytesCount = 0;
                    break;
                case PinTypes.ADC_24_DIN:
                    UsbBytesCount = 0;
                    ComBytesCount = 0;
                    break;
                case PinTypes.ADC_24_DOUT:
                    UsbBytesCount = 1;
                    ComBytesCount = 1;
                    break;
                case PinTypes.ADC_24_CH:
                    Adc24ChType = 0;
                    Adc24ChGain = 0;
                    Adc24ChBias = false;
                    UsbBytesCount = 3;
                    ComBytesCount = 3;
                    break;
                case PinTypes.ADC_24_CH_B:
                    Adc24ChType = 0;
                    Adc24ChGain = 0;
                    Adc24ChBias = false;
                    UsbBytesCount = 0;
                    ComBytesCount = 0;
                    break;

				case PinTypes.COUNTER:
				case PinTypes.COUNTER_PU:
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;
				case PinTypes.FAST_COUNTER:
				case PinTypes.FAST_COUNTER_PU:
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;
				case PinTypes.PERIOD:
				case PinTypes.PERIOD_PU:
					ResponseSpeed = 30;
					UsbBytesCount = 4;
					ComBytesCount = 4;
					break;
                case PinTypes.SLOW_PERIOD:
                case PinTypes.SLOW_PERIOD_PU:
                    ResponseSpeed = 30;
                    UsbBytesCount = 4;
                    ComBytesCount = 4;
                    break;
				case PinTypes.USOUND_SENSOR:
					MaxDist_mm = 1000;
					MinDist_mm = 0;
					ResponseSpeed = 30;
                    RemoveErrors = true;
					UsbBytesCount = 2;
					ComBytesCount = 2;
					break;
				case PinTypes.CAP_SENSOR:
					TimerDivision = 65536;
					TimerFrequencyKhz = 16000;
					Inductor_uh = 330;
					Cap_serial = 16;   //11.5   0 = infinite  ( normally 16 pF )
					MaxDist_mm = 500;
					MinDist_mm = 50;
					ResponseSpeed = 30;
					Area_cmq = 50;
					UsbBytesCount = 3;
					ComBytesCount = 3;
					break;

                case PinTypes.STEPPER_DIR:
                    UsbBytesCount = 4;
                    ComBytesCount = 4;
                    break;

                case PinTypes.ENCODER_A:
                case PinTypes.ENCODER_A_PU:
                    UsbBytesCount = 2;
                    ComBytesCount = 2;
                    break;

                case PinTypes.ENCODER_B: 
                case PinTypes.ENCODER_B_PU:
                    UsbBytesCount = 0;
                    ComBytesCount = 0;
                    break;

				case PinTypes.UNUSED:
					MaxTime = 1;
					MinTime = 0;
					Value_Parking = 0;
					UsbBytesCount = 0;
					ComBytesCount = 0;
					break;
				default:
					PinType = PinTypes.UNUSED;
					MaxTime = 1;
					MinTime = 0;
					Value_Parking = 0;
					UsbBytesCount = 0;
					ComBytesCount = 0;
					break;
			}

			// --------------------------------------------------------- direction
            if (UsbBytesCount == 0)
            {
				Direction = Directions.Unused;
			}
			else if (PinType < (PinTypes)128) 
            {
				Direction = Directions.HostToMaster;
			}
			else 
            {
				Direction = Directions.MasterToHost;
			}

		}



		// ==================================================================================================
		//  OUTPUTS  ( from SLOT to HARDWARE )
		// ==================================================================================================

		internal void ReadValueFromMMF()
		{
            Value = ThereminoSlots.ReadSlot(Slot);
		}


		internal void ConvertValueToHardwareFormat()
		{
            switch (PinType) 
            {
				case PinTypes.DIG_OUT:
                case PinTypes.PWM_8:
                case PinTypes.PWM_16:
                case PinTypes.SERVO_8:
                case PinTypes.SERVO_16:
                    // -------------------------------------------------------------- min and max
			        if (Value_Max != Value_Min) 
                    {
				        Value_Normalized_New = (Value - Value_Min) / (Value_Max - Value_Min);
			        }
			        else 
                    {
				        Value_Normalized_New = Value;
			        }
                    // -------------------------------------------------------------- limit to 0..1
                    if (Value_Normalized_New < 0) Value_Normalized_New = 0;
                    if (Value_Normalized_New > 1) Value_Normalized_New = 1; 
			        // -------------------------------------------------------------- exponential passing by 0 and 1
			        //                                                                a little less that the log base ( 2.7182 ) 
			        if (LogResponse && (PinType == PinTypes.PWM_8 | PinType == PinTypes.PWM_16)) 
                    {
				        Value_Normalized_New = (float)Math.Pow(Value_Normalized_New, 2);
			        }
			        // -------------------------------------------------------------- speed 
                    ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized, 
                                                                  Value_Normalized_New, 
                                                                  ResponseSpeed,
                                                                  AdaptiveSpeed);
                    break;

                case PinTypes.PWM_FAST:
                    // -------------------------------------------------------------- min and max
                    if (Value_Max != Value_Min)
                    {
                        Value_Normalized_New = (Value - Value_Min) / (Value_Max - Value_Min);
                    }
                    else
                    {
                        Value_Normalized_New = Value;
                    }
                    // -------------------------------------------------------------- limit to 0..1
                    if (DutyCycleFromSlot)
                    {
                        if (Value_Normalized_New < 0) Value_Normalized_New = 0;
                        if (Value_Normalized_New > 1) Value_Normalized_New = 1;
                    }
                    // -------------------------------------------------------------- speed 
                    ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized,
                                                                  Value_Normalized_New,
                                                                  ResponseSpeed,
                                                                  AdaptiveSpeed);
                    break;

                case PinTypes.STEPPER:
                    if (Single.IsNaN(Value))
                    {
                        Value_Normalized = Value;
                    }
                    else
                    {
                        // -------------------------------------------------------------- normalize to 0..1
                        Value_Normalized_New = Value / 1000;
                        // -------------------------------------------------------------- scaling to 0 .. 1000 mm 
                        Value_Normalized_New = (Value_Normalized_New * (Value_Max - Value_Min) + Value_Min) / 1000;

                        // -------------------------------------------------------------- with speed = 100 smoothing is excluded 
                        ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized,
                                                                          Value_Normalized_New,
                                                                          ResponseSpeed,
                                                                          AdaptiveSpeed);
                    }
                    break;
            }

			switch (PinType) 
            {
				case PinTypes.DIG_OUT:
					if (float.IsNaN(Value_Normalized)) 
                    {
						Value_Normalized = 0;
					}

					if (Value_Normalized > 0.5) 
                    {
						Value_RawUinteger = 1;
					}
					else {
						Value_RawUinteger = 0;
					}
					break;

				case PinTypes.PWM_8:
				case PinTypes.SERVO_8:
					if (float.IsNaN(Value_Normalized)) 
                    {
						Value_Normalized = Value_Max > Value_Min ? 0 : 1;
						Value_RawUinteger = 0;
					}
					else 
                    {
						Value_RawUinteger = (uint)(16f * (Value_Normalized * (MaxTime - MinTime) + MinTime));
					}
					if (Value_RawUinteger < 0) Value_RawUinteger = 0; 
					if (Value_RawUinteger > 64000) Value_RawUinteger = 64000; 
					break;

				case PinTypes.PWM_16:
				case PinTypes.SERVO_16:
					if (float.IsNaN(Value_Normalized)) 
                    {
						Value_Normalized = Value_Max > Value_Min ? 0 : 1;
						Value_RawUinteger = 0;
					}
					else 
                    {
						Value_RawUinteger = (uint)(16f * (Value_Normalized * (MaxTime - MinTime) + MinTime));
					}
					if (Value_RawUinteger < 0) Value_RawUinteger = 0; 
					if (Value_RawUinteger > 64000) Value_RawUinteger = 64000; 
					break;

                case PinTypes.STEPPER:
                    if (Theremino.IsNanReset(Value_Normalized))
                    {
                        Value_RawUinteger = 0xFFFFFFFFU;
                    }
                    else
                    {
                        if (Single.IsNaN(Value_Normalized)) Value_Normalized = 0; 
                        Value_RawUinteger = Convert.ToUInt32(
                                           (Convert.ToInt64(Value_Normalized * 1000 * StepsPerMillimeter) + 
                                            0x80000000U));
                    }
                    break;

                case PinTypes.PWM_FAST:
                    if (float.IsNaN(Value_Normalized)) Value_Normalized = 0;
                    if (FrequencyFromSlot) PwmFastFrequency = Value_Normalized * 1000;
                    if (DutyCycleFromSlot) PwmFastDutyCycle = Value_Normalized * 1000;
                    if (PwmFastFrequency < 0) PwmFastFrequency = 0;
                    if (PwmFastFrequency > 8000000) PwmFastFrequency = 8000000;
                    if (PwmFastDutyCycle < 0) PwmFastDutyCycle = 0;
                    if (PwmFastDutyCycle > 1000) PwmFastDutyCycle = 1000;
                    break;
			}
		}

		internal void WriteValueToUsbBuffer()
		{
            byte[] bytes;
			switch (PinType) 
            {
				case PinTypes.DIG_OUT:
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex] = (byte)Value_RawUinteger;
					break;
				case PinTypes.PWM_8:
				case PinTypes.SERVO_8:
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex] = (byte)(Value_RawUinteger / 256);
					break;
				case PinTypes.PWM_16:
				case PinTypes.SERVO_16:
                    bytes = Module_Utils.ByteArrayFromUint16((ushort)Value_RawUinteger);
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex] = bytes[0];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 1] = bytes[1];
					break;
                case PinTypes.STEPPER:
                    bytes = Module_Utils.StepperByteArray_FromUint32(Value_RawUinteger);
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex] = bytes[0];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 1] = bytes[1];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 2] = bytes[2];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 3] = bytes[3];
                    break;
                case PinTypes.PWM_FAST:
                    bytes = Module_Utils.ByteArrayFromUint24((uint)PwmFastFrequency);
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex] = bytes[0];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 1] = bytes[1];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 2] = bytes[2];
                    // ----------------------------------------------------------------------
                    // This 65534 (instead of 65535) removes a random glitch
                    // when setting PwmFastDutyCycle around 999...1000
                    // (maybe the bug could be in the Master firmware)
                    // ----------------------------------------------------------------------
                    bytes = Module_Utils.ByteArrayFromUint16((ushort)(PwmFastDutyCycle * 65.534));
                    // ----------------------------------------------------------------------
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 3] = bytes[0];
                    ThereminoSystem.Masters[MasterId].Hid.USB_TxData[UsbByteIndex + 4] = bytes[1];
                    break;
			}
		}

        internal void WriteValueToByteArray(ref byte[] b, ref Int32 ix)
        {
            byte[] bytes = null;
            switch (GetPinType())
            {
                case Pin.PinTypes.DIG_OUT:
                    b[ix++] = (byte)Value_RawUinteger;
                    break;
                case Pin.PinTypes.PWM_8:
                case Pin.PinTypes.SERVO_8:
                    b[ix++] = (byte)(Value_RawUinteger / 256);
                    break;
                case Pin.PinTypes.PWM_16:
                case Pin.PinTypes.SERVO_16:
                    bytes = Module_Utils.ByteArrayFromUint16((ushort)Value_RawUinteger);
                    b[ix++] = bytes[0];
                    b[ix++] = bytes[1];
                    break;
                case Pin.PinTypes.STEPPER:
                    bytes = Module_Utils.StepperByteArray_FromUint32(Value_RawUinteger);
                    b[ix++] = bytes[0];
                    b[ix++] = bytes[1];
                    b[ix++] = bytes[2];
                    b[ix++] = bytes[3];
                    break;
                case Pin.PinTypes.PWM_FAST:
                    bytes = Module_Utils.ByteArrayFromUint24((uint)(PwmFastFrequency));
                    b[ix++] = bytes[0];
                    b[ix++] = bytes[1];
                    b[ix++] = bytes[2];
                    // ----------------------------------------------------------------------
                    // This 65534 (instead of 65535) removes a random glitch
                    // when setting PwmFastDutyCycle around 999...1000
                    // (maybe the bug could be in the Master firmware)
                    // ----------------------------------------------------------------------
                    bytes = Module_Utils.ByteArrayFromUint16((ushort)(PwmFastDutyCycle * 65.534));
                    // ----------------------------------------------------------------------
                    b[ix++] = bytes[0];
                    b[ix++] = bytes[1];
                    break;
            }
        }




		// ==================================================================================================
		//  INPUTS  ( from HARDWARE to SLOT )
		// ==================================================================================================

		internal void ReadValueFromUsbBuffer()
		{
			{
				switch (UsbBytesCount) {
					case 1:
                        Value_RawUinteger = ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 0];
						break;
					case 2:
                        Value_RawUinteger = ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 0] * 256u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 1];
						break;
					case 3:
                        Value_RawUinteger = ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 0] * 65536u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 1] * 256u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 2];
						break;
					case 4:
                        Value_RawUinteger = ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 0] * 256u * 65536u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 1] * 65536u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 2] * 256u + ThereminoSystem.Masters[MasterId].Hid.USB_RxData[UsbByteIndex + 3];
						break;
				}
			}
		}

        internal void SetValueFromByteArray(byte[] b, ref Int32 ix)
        {
            switch (UsbBytesCount)
            {
                case 1:
                    Value_RawUinteger = b[ix];
                    ix += 1;
                    break;
                case 2:
                    Value_RawUinteger = b[ix] * 256u + b[ix + 1];
                    ix += 2;
                    break;
                case 3:
                    Value_RawUinteger = b[ix] * 65536u + b[ix + 1] * 256u + b[ix + 2];
                    ix += 3;
                    break;
                case 4:
                    Value_RawUinteger = b[ix] * 256u * 65536u + b[ix + 1] * 65536u + b[ix + 2] * 256u + b[ix + 3];
                    ix += 4;
                    break;
            }
        }


		internal void ConvertValueFromHardwareFormat()
		{
			switch (PinType) {

				case PinTypes.DIG_IN:
				case PinTypes.DIG_IN_PU:
					if (Value_RawUinteger != 0) Value_RawUinteger = 1; 
					Value_Normalized_New = Value_RawUinteger;
					break;

                case PinTypes.CAP_8:
                    Value_RawUinteger *= 3; // correction for (PIC24)Master and Servo values from (0 to 60 instead of 0 to 255)
                    break;
                case PinTypes.CAP_16:
                    Value_RawUinteger *= 3; // correction for (PIC24)Master and Servo values from (0 to 16000 instead of 0 to 65535)
                    break;

                case PinTypes.RES_8:
                    Value_Normalized_New = Value_RawUinteger / 255f;
                    break;
                case PinTypes.RES_16:
                    Value_Normalized_New = Value_RawUinteger / 65535f;
                    break;

				case PinTypes.ADC_8:
					Value_Normalized_New = Value_RawUinteger / 255f;
					break;
				case PinTypes.ADC_16:
					Value_Normalized_New = Value_RawUinteger / 65535f;
					break;

                case PinTypes.ADC_24:
                    break;
                case PinTypes.ADC_24_DIN:
                    break;
                case PinTypes.ADC_24_DOUT:
                    Value_Normalized_New = Value_RawUinteger / 255.0f;
                    break;
                case PinTypes.ADC_24_CH:
                    Value_Normalized_New = Value_RawUinteger / 16777215.0f;
                    break;
                case PinTypes.ADC_24_CH_B:
                    break;

				case PinTypes.COUNTER:
				case PinTypes.COUNTER_PU:
				case PinTypes.FAST_COUNTER:
				case PinTypes.FAST_COUNTER_PU:
					break;

				case PinTypes.PERIOD:
				case PinTypes.PERIOD_PU:
					break;

                case PinTypes.SLOW_PERIOD:
                case PinTypes.SLOW_PERIOD_PU:
                    break;

                case PinTypes.STEPPER_DIR:
                    if (Value_RawUinteger > 0)
                    {
                        Value_RawInteger = (int)((long)(Value_RawUinteger) - 0x80000000U);
                    }
                    break;

				case PinTypes.USOUND_SENSOR:
                    if (RemoveErrors) UsoundSensor_RemoveErrors();
					UsoundSensor_CalculatePosition();
					break;

				case PinTypes.CAP_SENSOR:
					CapSensor_CalculateAll();
					break;

                case PinTypes.ENCODER_A:
                case PinTypes.ENCODER_A_PU:
                case PinTypes.ENCODER_B:
                case PinTypes.ENCODER_B_PU:
                    break;
			}



			switch (PinType) 
            {
				case PinTypes.DIG_IN:
				case PinTypes.DIG_IN_PU:
				case PinTypes.ADC_8:
				case PinTypes.ADC_16:
				case PinTypes.RES_8:
				case PinTypes.RES_16:
				case PinTypes.USOUND_SENSOR:
				case PinTypes.CAP_SENSOR:
					// -------------------------------------------------------------- limit to 0..1
					if (Value_Normalized_New < 0) Value_Normalized_New = 0; 
					if (Value_Normalized_New > 1) Value_Normalized_New = 1;
                    // -------------------------------------------------------------- speed 
                    ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized,
                                                                  Value_Normalized_New,
                                                                  ResponseSpeed,
                                                                  AdaptiveSpeed);
					// -------------------------------------------------------------- min and max
					Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min;
					break;

                case PinTypes.ADC_24:
                case PinTypes.ADC_24_DIN:
                    break;
                case PinTypes.ADC_24_DOUT:
                    Value = Value_Normalized_New * 1000.0F;
                    Value_Normalized = Value_Normalized_New;

                    break;
                case PinTypes.ADC_24_CH:
                    // -------------------------------------------------------------- speed 
                    ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized,
                                                                  Value_Normalized_New,
                                                                  ResponseSpeed,
                                                                  AdaptiveSpeed);
                    // -------------------------------------------------------------- min and max
                    Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min;
                    break;
                case PinTypes.ADC_24_CH_B:
                    break;
                //case PinTypes.ADC_24:
                //    Value_Normalized_New = (float)(Value_RawUinteger & 0xFF) / 255f;
                //    Value_Normalized = Value_Normalized_New;
                //    Value = Value_RawUinteger & 0xFF;
                //    break;


                case PinTypes.CAP_8:
                case PinTypes.CAP_16:
                    // -------------------------------------------------------------- speed before trigger
                    if (PinType == PinTypes.CAP_8)
                    {
                        ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_RawSmoothed,
                                                                      Value_RawUinteger * (1000.0F / 255.0F),
                                                                      ResponseSpeed,
                                                                      AdaptiveSpeed);
                    }
                    else
                    {
                        ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_RawSmoothed,
                                                                      Value_RawUinteger * (1000.0F / 65535.0F),
                                                                      ResponseSpeed,
                                                                      AdaptiveSpeed);
                    }

                    if (MinVariation > 0)
                    {
                        // -------------------------------------------
                        //   CAP TOUCH KEYS
                        // -------------------------------------------


                        // ------------------------------------------------------------------ calculate delta
                        float delta = MeanValue - Value_RawSmoothed;

                        // ------------------------------------------------------------------ increase min value
                        if (delta < 0)
                        {
                            MeanValue += (Value_RawSmoothed - MeanValue) * 0.01f;
                            delta = 0;
                        }

                        // ------------------------------------------------------------------ MinVariation reduced for sliders
                        if (ProportionalArea > 0)
                        {
                            delta -= MinVariation / 100;
                        }
                        else
                        {
                            delta -= MinVariation;
                        }


                        if (ProportionalArea > 0)
                        {
                            // -------------------------------------------------------------- proportional limited 0..1
                            Value_Normalized = delta / ProportionalArea;
                            if (Value_Normalized < 0) Value_Normalized = 0;
                            if (Value_Normalized > 1) Value_Normalized = 1;
                        }
                        else if (ProportionalArea == 0)
                        {
                            //--------------------------------------------------------------- on/off (0 or 1)
                            Value_Normalized = delta > 0 ? 1 : 0;
                        }
                        else
                        {
                            // -------------------------------------------------------------- with velocity
                            if (delta > 0)
                            {
                                if (Velocity == 0)
                                {
                                    Velocity = (delta - oldDelta3) / -ProportionalArea;
                                    if (Velocity > 1) Velocity = 1;
                                    Velocity = Velocity * Velocity;
                                }
                            }
                            else
                            {
                                Velocity = 0;
                            }
                            oldDelta3 = oldDelta2;
                            oldDelta2 = oldDelta1;
                            oldDelta1 = delta;
                            Value_Normalized = Velocity;
                        }
                    }
                    else
                    {
                        // -------------------------------------------
                        //   RAW CAPACITIVE SENSORS
                        // -------------------------------------------
                        Value_Normalized = (-MinVariation - Value_RawSmoothed) / ProportionalArea;
                        if (Value_Normalized < 0) Value_Normalized = 0;
                        if (Value_Normalized > 1) Value_Normalized = 1;
                    }

                    // ------------------------------------------------------------------ min and max
                    Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min;

                    // ---------------------------------------------------------------------- values min and max for calibrate Inhibit
                    if (Value_RawSmoothed > Value_Uinteger_Max) Value_Uinteger_Max = (UInt32)(Value_RawSmoothed * 10);
                    if (Value_RawSmoothed < Value_Uinteger_Min) Value_Uinteger_Min = (UInt32)(Value_RawSmoothed * 10);

                    break;

				case PinTypes.COUNTER:
				case PinTypes.COUNTER_PU:
				case PinTypes.FAST_COUNTER:
				case PinTypes.FAST_COUNTER_PU:
					if (ConvertToFreq) 
                    {
                        NewTimeMilliseconds = ThereminoSystem.FreeRunningTimer.Elapsed.TotalMilliseconds;
                        double dt = NewTimeMilliseconds - OldTimeMilliseconds;
                        //  ------------------------------------------------------------------ update every 100 mS
                        double SamplingTimeMs = 100000 / MaxFreq;
                        if (SamplingTimeMs > 1000) SamplingTimeMs = 1000;
                        if (SamplingTimeMs < 10) SamplingTimeMs = 10;
                        if (dt >= SamplingTimeMs)
                        {
                            //  -------------------------------------------------------------- delta counts
                            UInt32 diff;
                            if (Value_RawUinteger >= Value_RawUinteger_Old)
                            {
                                diff = Value_RawUinteger - Value_RawUinteger_Old;
                            }
                            else
                            {
                                diff = (0xFFFF - Value_RawUinteger_Old) + Value_RawUinteger + 1;
                            }
                            Value_RawUinteger_Old = Value_RawUinteger;
                            //  -------------------------------------------------------------- frequency
                            if (Value_RawUinteger > 0 && dt > 0)
                            {
                                Freq = (float)(1000 * diff / dt);
                            }
                            else
                            {
                                Freq = 0;
                            }
                            OldTimeMilliseconds = NewTimeMilliseconds;
                        }
                        //  ------------------------------------------------------------------ range
                        double range = MaxFreq - MinFreq;
                        if (range < 0.1) range = 0.1;
                        Value_Normalized_New = (float)((Freq - MinFreq) / range);
                        //  ------------------------------------------------------------------ speed
                        ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized, 
                                                                          Value_Normalized_New, 
                                                                          ResponseSpeed, 
                                                                          AdaptiveSpeed);
                        //  ------------------------------------------------------------------ min and max
                        Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min;
					}
					else 
                    {
						Value_Normalized_New = Value_RawUinteger / 65535f;
						Value_Normalized = Value_Normalized_New;
						Value = Value_RawUinteger;
					}
					break;

				case PinTypes.PERIOD:
				case PinTypes.PERIOD_PU:
                case PinTypes.SLOW_PERIOD:
                case PinTypes.SLOW_PERIOD_PU:
					// Value_RawUinteger = 0.0625 uSec ( 16 MHz )
					if (ConvertToFreq) 
                    {
						// -------------------------------------------------------------- range
						if (Value_RawUinteger > 0) 
                        {
							Freq = 1.6E+07f / Value_RawUinteger;
						}
						else {
							Freq = 0;
						}
						double range = MaxFreq - MinFreq;
						if (range < 0.1) range = 0.1; 
						Value_Normalized_New = (float)((Freq - MinFreq) / range);
						// -------------------------------------------------------------- speed
						ThereminoSystem.Masters[MasterId].SmoothValue(ref Value_Normalized, 
                                                                      Value_Normalized_New, 
                                                                      ResponseSpeed,
                                                                      AdaptiveSpeed);
                        // -------------------------------------------------------------- min and max
						Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min;
					}
					else 
                    {
						Value_Normalized_New = Value_RawUinteger / 1.677722E+07f / 2f;
						Value_Normalized = Value_Normalized_New;
						Value = Value_RawUinteger;
					}
					break;

                case PinTypes.STEPPER_DIR:
                    if (PinId > 0)
                    {
                        Value = Value_RawInteger /
                                ThereminoSystem.Masters[MasterId].Slaves[SlaveId].Pins[PinId - 1].StepsPerMillimeter;
                    }
                    Value_Normalized_New = Value / 1000;
                    Value_Normalized = Value_Normalized_New;
                    break;

                case PinTypes.ENCODER_A:
                case PinTypes.ENCODER_A_PU:
                    Value_Normalized_New = Value_RawUinteger / 65535.0F;
                    Value_Normalized = Value_Normalized_New;
                    Value = Value_RawUinteger;
                    break;

                case PinTypes.ENCODER_B:
                case PinTypes.ENCODER_B_PU:
                    Value_Normalized_New = Value_RawUinteger / 65535.0F;
                    Value_Normalized = Value_Normalized_New;
                    Value = Value_RawUinteger;
                    break;
			}

		}


		internal void WriteValueToMMF()
		{
            ThereminoSlots.WriteSlot(Slot, (float)Value);
		}

        // ==================================================================================================
        //   STEPPER PIN CONFIGURATION - BY ASYNChronous SendBytesToSlave -
        // ==================================================================================================
        internal void SendStepperParamsToHardware()
        {
            StepperSpeed_Hz = Convert.ToInt32(MaxSpeed * StepsPerMillimeter / 60);
            StepperAcc_Hz_per_mS = Convert.ToInt32(MaxAcc * StepsPerMillimeter / 1000);
            if (StepperSpeed_Hz > 65535) StepperSpeed_Hz = 65535;
            if (StepperAcc_Hz_per_mS > 65535) StepperAcc_Hz_per_mS = 65535;
            byte[] b = new byte[6];
            b[0] = (byte)Master.CommandsToHardware.SendStepperParams;
            b[1] = (byte)PinId;
            b[2] = (byte)(StepperSpeed_Hz >> 8);
            b[3] = (byte)(StepperSpeed_Hz & 255);
            b[4] = (byte)(StepperAcc_Hz_per_mS >> 8);
            b[5] = (byte)(StepperAcc_Hz_per_mS & 255);
            ThereminoSystem.Masters[MasterId].SendBytesToSlave(0, ref b);
        }

		// ==================================================================================================
		//   HELPER FUNCTIONS
		// ==================================================================================================
		internal void ResetPosMinMax()
		{
			Value_Uinteger_Min = 99999999;
			Value_Uinteger_Max = 0;
		}

		internal void Calibrate()
		{
			switch (PinType) {
				case PinTypes.CAP_SENSOR:
					// ----------------------------------------------- calibrate cap input
					Cap_zero = Cap_total;
					// ----------------------------------------------- calculate immediately the new position
					CapSensor_CalculatePosition();
					break;
                case PinTypes.CAP_8:
                case PinTypes.CAP_16:
                    // ----------------------------------------------- calibrate cap input
                    MeanValue = Value_RawSmoothed;
                    break;
			}
		}

		internal void CalibrateZero()
		{
			Value_RawUinteger_Zero = Value_RawUinteger;
            Value_Zero = Value;
		}

		internal string GetValueString()
		{
			CultureInfo ci = new CultureInfo("en-GB");
			switch (PinType) {

				// ------------------------------------------------------------------------- OUTPUTS
				case PinTypes.DIG_OUT:
					return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci) + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("0");

                case PinTypes.SERVO_8:
                case PinTypes.SERVO_16:
                    if (Single.IsNaN(Value))
                    {
                        return PinTypeToString(PinType) + Constants.vbCrLf +
                                "--------------" + Constants.vbCrLf +
                                " Slot: " + "Sleep" + Constants.vbCrLf +
                                " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                                "  Raw: " + Value_RawUinteger.ToString("0");
                    }
                    else
                    {
                        return PinTypeToString(PinType) + Constants.vbCrLf +
                                "--------------" + Constants.vbCrLf +
                                " Slot: " + Value.ToString("0.00", ci) + Constants.vbCrLf +
                                " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                                "  Raw: " + Value_RawUinteger.ToString("0");
                    }
	
                case PinTypes.PWM_8:
				case PinTypes.PWM_16:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci) + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("0");

                case PinTypes.STEPPER:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci) + Constants.vbCrLf +
                            " Filt: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Step: " + (Convert.ToInt64(Value_RawUinteger) - 0x80000000U).ToString("0") + Constants.vbCrLf +
                            "   Hz: " + StepperSpeed_Hz.ToString("0") + Constants.vbCrLf +
                            "Hz/mS: " + StepperAcc_Hz_per_mS.ToString("0");

                case PinTypes.PWM_FAST:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci) + Constants.vbCrLf +
                            " Filt: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            "   Hz: " + PwmFastFrequency.ToString("0") + Constants.vbCrLf +
                            " Duty: " + PwmFastDutyCycle.ToString("0");

				// --------------------------------------------------------------------- INPUTS 
				case PinTypes.DIG_IN:
				case PinTypes.DIG_IN_PU:
					return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("0") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);

                case PinTypes.CAP_8:
                case PinTypes.CAP_16:
                    if (MinVariation > 0)
                    {
                        return PinTypeToString(PinType) + Constants.vbCrLf +
                                        "--------------" + Constants.vbCrLf +
                                        "   Raw: " + Value_RawUinteger.ToString("000") + Constants.vbCrLf +
                                        " Smoot: " + Value_RawSmoothed.ToString("0.00") + Constants.vbCrLf +
                                        "  Mean: " + MeanValue.ToString("0.00") + Constants.vbCrLf +
                                        "  Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                                        "  Slot: " + Value.ToString("0.00", ci);
                    }
                    else
                    {
                        return PinTypeToString(PinType) + Constants.vbCrLf +
                                        "--------------" + Constants.vbCrLf +
                                        "   Raw: " + Value_RawUinteger.ToString("000") + Constants.vbCrLf +
                                        " Smoot: " + Value_RawSmoothed.ToString("0.00") + Constants.vbCrLf +
                                        "  Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                                        "  Slot: " + Value.ToString("0.00", ci);
                    }

                case PinTypes.RES_8:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);

                case PinTypes.RES_16:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);

                case PinTypes.ADC_8:
					return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);
				
                case PinTypes.ADC_16:
					return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);
    
                case PinTypes.ADC_24_DOUT:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                    "--------------" + Constants.vbCrLf +
                    "  Raw: " + Value_RawUinteger.ToString("000") + Constants.vbCrLf +
                    " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                    " Slot: " + Value.ToString("0.00", ci);

                case PinTypes.ADC_24_CH:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                        "--------------" + Constants.vbCrLf +
                        "  Raw: " + Value_RawUinteger.ToString("00000000") + Constants.vbCrLf +
                        " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                        " Slot: " + Value.ToString("0.000", ci);
					
                case PinTypes.COUNTER:
				case PinTypes.COUNTER_PU:
				case PinTypes.FAST_COUNTER:
				case PinTypes.FAST_COUNTER_PU:
				case PinTypes.PERIOD:
				case PinTypes.PERIOD_PU:
                case PinTypes.SLOW_PERIOD:
                case PinTypes.SLOW_PERIOD_PU:
					if (ConvertToFreq) {
						return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                            " Freq: " + Freq.ToString("00000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);
					}
					else {
						return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("00000");
					}

                case PinTypes.STEPPER_DIR:
                        return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawInteger.ToString("00000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            Constants.vbCrLf +
                            "Error" + Constants.vbCrLf +  " (mm): " + Value.ToString("0.00", ci);

				case PinTypes.USOUND_SENSOR:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                            "--------------" + Constants.vbCrLf +
                            "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                            "   mm: " + Dist_mm.ToString("0000") + Constants.vbCrLf +
                            " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                            " Slot: " + Value.ToString("0.00", ci);
				
                case PinTypes.CAP_SENSOR:
					if (Value_RawUinteger < 999999) 
                    {
						return "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf + 
                               "   mS: " + Millisec.ToString("0.0000", ci) + Constants.vbCrLf + 
                               "  MHz: " + IntegratedFreqString + Constants.vbCrLf + 
                               "C_tot: " + Cap_total.ToString("00.000", ci) + Constants.vbCrLf + 
                               " C_in: " + Cap_input.ToString("00.000", ci) + Constants.vbCrLf + 
                               "   mm: " + Dist_mm.ToString("0000") + Constants.vbCrLf + 
                               " Norm: " + Value_Normalized.ToString("0.00", ci);
					}
					break;

                case PinTypes.ENCODER_A:
                case PinTypes.ENCODER_A_PU:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                        "--------------" + Constants.vbCrLf +
                        "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                        " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                        " Slot: " + Value.ToString("00000");

                case PinTypes.ENCODER_B:
                case PinTypes.ENCODER_B_PU:
                    return PinTypeToString(PinType) + Constants.vbCrLf +
                        "--------------" + Constants.vbCrLf +
                        "  Raw: " + Value_RawUinteger.ToString("00000") + Constants.vbCrLf +
                        " Norm: " + Value_Normalized.ToString("0.00", ci) + Constants.vbCrLf +
                        " Slot: " + Value.ToString("00000");

				default:
					return PinTypeToString(PinType);

			}
			return "";
		}


		// ==================================================================================================
		//   USOUND SENSORS SPECIFIC
		// ==================================================================================================
		private void UsoundSensor_RemoveErrors()
		{
			//
            UInt32 diff = Module_MathFunctions.AbsUint32Difference(Value_RawUinteger, Value_RawUinteger_Old);
			Int32 maxErrorCount = 2 * (1 + Convert.ToInt32(30 / RepTime));
			//
			if (diff > 1000 & ErrorCounter < maxErrorCount) {
				Value_RawUinteger = Value_RawUinteger_Old;
				ErrorCounter += 1;
			}
			else {
				// ---------------------------------------------------------- use the new value
				Value_RawUinteger_Old = Value_RawUinteger;
				ErrorCounter = 0;
			}
		}

		private void UsoundSensor_CalculatePosition()
		{
			// -------------------------------------------------------------- distance in mm 
			Dist_mm = (Value_RawUinteger - 900f) * 0.173f;
			// -------------------------------------------------------------- distance limits
			if (Dist_mm < MinDist_mm) Dist_mm = MinDist_mm; 
			if (Dist_mm > MaxDist_mm) Dist_mm = MaxDist_mm; 
			// -------------------------------------------------------------- range
			double range = MaxDist_mm - MinDist_mm;
			if (range < 0.1) range = 0.1; 
			Value_Normalized_New = 1 - (float)((Dist_mm - MinDist_mm) / range);
		}



		// ==================================================================================================
		//   CAP SENSORS SPECIFIC
		// ==================================================================================================
		private void CapSensor_CalculateAll()
		{
            CapSensor_LatencyBitsExtractor();
			//CapSensor_RemoveErrors();
			CapSensor_UpdateMinMaxValues();
			CapSensor_CalculateTimeAndFreq();
			CapSensor_CalculateTotalCap();
			CapSensor_CalculatePosition();
		}

        Int32 LatencySelector = 0;
        private void CapSensor_LatencyBitsExtractor()
		{
            LatencySelector = (Int32)(Value_RawUinteger >> 20);
            Value_RawUinteger = Value_RawUinteger & 0xFFFFF;
        }

        //private void CapSensor_RemoveErrors()
        //{
        //    //
        //    Int32 MinCount = 200000;
        //    Int32 MinDiff = 35000;
        //    Int32 MaxDiff = 95000;
        //    Int32 maxErrorCount = 5 * (1 + Convert.ToInt32(30 / RepTime));
        //    //
        //    UInt32 diff = Module_MathFunctions.AbsUint32Difference(Value_RawUinteger, Value_RawUinteger_Old);
        //    //
        //    if ((Value_RawUinteger < MinCount || (diff > MinDiff & diff < MaxDiff)) & ErrorCounter < 5) {
        //        // ------------------------------------------------------ show the error
        //        //frmMain.txt_Reports.Text &= "Invalid sample  " & _
        //        //                            "  OLD=" & _slave.CountOld.ToString & _
        //        //                            "  NEW=" & _slave.CountNew.ToString & _
        //        //                            "  DIFF=" & diff.ToString & vbCrLf
        //        Value_RawUinteger = Value_RawUinteger_Old;
        //        ErrorCounter += 1;
        //    }
        //    else {
        //        // ------------------------------------------------------ use the new value
        //        Value_RawUinteger_Old = Value_RawUinteger;
        //        ErrorCounter = 0;
        //    }
        //}

		// ------------------------------------------------- RawInteger min and max for AutoCalibrate
		private void CapSensor_UpdateMinMaxValues()
		{
			if (Value_RawUinteger > Value_Uinteger_Max) Value_Uinteger_Max = Value_RawUinteger; 
			if (Value_RawUinteger < Value_Uinteger_Min) Value_Uinteger_Min = Value_RawUinteger; 
		}

		private void CapSensor_CalculateTimeAndFreq()
		{
			// ---------------------------------------------------------- time total
			float ms = (float)Value_RawUinteger / TimerFrequencyKhz;
			// ---------------------------------------------------------- frequency
			Freq = TimerDivision * 1000 / ms;
            // ---------------------------------------------------------- millisec corrected by latencyselector
            Millisec = ms / (float)(Math.Pow(2, LatencySelector));
            // ---------------------------------------------------------- integrated frequency (only visual info)
            IntegratedFreq += Freq;
            IntegratedlFreqCounter += 1;
            if (IntegratedlFreqCounter >= 50)
            {
                IntegratedFreqString = (IntegratedFreq / (1000000 * 50)).ToString("0.00000", CultureInfo.InvariantCulture);
                if (IntegratedFreqString == "Infinity") IntegratedFreqString = "---";
                IntegratedFreq = 0;
                IntegratedlFreqCounter = 0;
            }
		}

		private void CapSensor_CalculateTotalCap()
		{
			// ----------------------------------------------------------- total capacitance ( in parallel to inductor )
			Cap_total = (float)(2.53302955E+16 / (Inductor_uh * Math.Pow(Freq, 2)));
		}

		//Private Sub CapSensor_CalculatePosition()
		//    ' ----------------------------------------------------------- input capacitance ( after serial capacitor )
		//    If Cap_serial > 0 Then
        //        Cap_input = CSng(Module_ElectronicFormula.ELEC_C2_FromSerial(Cap_total - Cap_zero, Cap_serial))
		//    Else
		//        Cap_input = Cap_total - Cap_zero
		//    End If
		//    If Cap_input < 0 Then Cap_input = 0
		//    If Cap_input > 999.999 Then Cap_input = 999.999
		//    ' ----------------------------------------------------------- K area 
		//    ' Teoric K_Area is: 88 * 100 * Area_cmq
		//    ' from: 0.885F(cap. to dist. coeff.) * 100(cmq to mmq) * Area_cmq
		//    ' ---------
		//    ' A High coefficient ( 80 .. 160 ) expands the "Near" zone
		//    ' A Low coefficient  ( 40 .. 80 ) expands the "Far" zone
		//    ' ---------
		//    ' The user can change this Near-Far linearity 
		//    ' increasing or decreasing the parameter "Area_cmq" 
		//    ' ---------
		//    Dim K_Area As Single = 88 * Area_cmq
		//    ' ----------------------------------------------------------- distance in mm 
		//    Dist_mm = K_Area * MaxDist_mm / _
		//              (K_Area + Cap_input * MaxDist_mm * MaxDist_mm)
		//    ' ----------------------------------------------------------- distance limits
		//    If Dist_mm < 0 Then Dist_mm = 0
		//    If Dist_mm > MaxDist_mm Then Dist_mm = MaxDist_mm
		//    ' ----------------------------------------------------------- range
		//    Dim range As Double = MaxDist_mm - MinDist_mm
		//    If range < 0.1 Then range = 0.1
		//    Value_Normalized_New = 1 - CSng((Dist_mm - MinDist_mm) / range)
		//End Sub


		private void CapSensor_CalculatePosition()
        {
            if (Area_cmq > 0)
            {
                // ----------------------------------------------------------- input capacitance ( after serial capacitor )
                if (Cap_serial > 0)
                {
                    Cap_input = (float)Module_ElectronicFormula.ELEC_C2_FromSerial(Cap_total - Cap_zero, Cap_serial);
                }
                else
                {
                    Cap_input = Cap_total - Cap_zero;
                }
                if (Cap_input < 0) Cap_input = 0;
                if (Cap_input > 999.999F) Cap_input = 999.999F;
                // ----------------------------------------------------------- K area 
                // Teoric K_Area is: 88 * 100 * Area_cmq
                // from: 0.885F(cap. to dist. coeff.) * 100(cmq to mmq) * Area_cmq
                // ---------
                // A High coefficient ( 80 .. 160 ) expands the "Near" zone
                // A Low coefficient  ( 40 .. 80 ) expands the "Far" zone
                // ---------
                // The user can change this Near-Far linearity 
                // increasing or decreasing the parameter "Area_cmq" 
                // ---------
                float K_Area = 88 * Area_cmq;
                // ----------------------------------------------------------- MaxDist and MinDist correction for area
                float K2 = Area_cmq / 100f;
                float MinD = MinDist_mm * K2;
                float MaxD = MaxDist_mm * K2;
                // ----------------------------------------------------------- distance in mm 
                Dist_mm = K_Area * MaxD / (K_Area + Cap_input * MaxD * MaxD);
                // ----------------------------------------------------------- distance limits
                if (Dist_mm < 0) Dist_mm = 0;
                if (Dist_mm > MaxD) Dist_mm = MaxD;
                // ----------------------------------------------------------- range
                double range = MaxD - MinD;
                if (range < 0.1) range = 0.1;
                Value_Normalized_New = 1 - (float)((Dist_mm - MinD) / range);
            }
            else
            {
                Cap_input = 0;
                Dist_mm = 0;
                Value_Normalized_New = Cap_total / 1000;
            }
        }
	}
}


