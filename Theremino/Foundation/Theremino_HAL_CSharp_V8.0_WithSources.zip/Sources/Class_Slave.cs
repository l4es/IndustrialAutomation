using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

using System.Globalization;
//using System.Math;
namespace Theremino_HAL
{


	// ==================================================================================================
	//   CLASS SLAVE
	// ==================================================================================================
	class Slave
	{
		public enum SlaveTypes : int
		{
			Custom = 0,
			CapSensor = 1,
			Servo = 2,
			Generic = 3,
			InOut = 4,
			MasterPins = 5,
			//RmsLogger = 6,
			//Sniffer = 7,
            MasterPinsV2 = 8,
            MasterPinsV4 = 9,
			Unknown = 255
		}

		internal Int32 MasterId;
		internal Int32 mSlaveId;
		internal SlaveTypes SlaveType;
		internal List<Pin> Pins;

		internal Int32 LoadCurrent_mA;

		internal Int32 SlaveId {
			get { return mSlaveId; }
// test if mSlaveId ok
			set { mSlaveId = value; }
		}

        internal string FirmwareVersion()
        {
            Int32 version = ThereminoSystem.Masters[MasterId].MasterFirmwareVersion;
            return (version / 10).ToString() + "." + (version - (version / 10) * 10).ToString();
        }

		internal string SlaveTypeString()
		{
			switch (SlaveType) {
				case SlaveTypes.Custom:
					return "Custom";
				case SlaveTypes.CapSensor:
					return "CapSensor";
				case SlaveTypes.Servo:
					return "Servo";
				case SlaveTypes.Generic:
					return "Generic";
				case SlaveTypes.InOut:
					return "InOut";
				case SlaveTypes.MasterPins:
					return "MasterPins";
                case SlaveTypes.MasterPinsV2:
                    return "MasterPins";
                case SlaveTypes.MasterPinsV4:
                    return "MasterPins";
				case SlaveTypes.Unknown:
					return "Unknown";
				default:
					return "Unknown";
			}
		}

        public static SlaveTypes StringToSlaveType(String s)
        {
            switch (s.Trim().ToLower())
            {
                case "custom":
                    return SlaveTypes.Custom;
                case "capsensor":
                    return SlaveTypes.CapSensor;
                case "servo":
                    return SlaveTypes.Servo;
                case "generic":
                    return SlaveTypes.Generic;
                case "inout":
                    return SlaveTypes.InOut;
                case "masterpins":
                    return SlaveTypes.MasterPins;
                default:
                    return SlaveTypes.Unknown;
            }
        }

		internal Slave(SlaveTypes _slavetype, Int32 _masterid, Int32 _slaveid)
		{
			SlaveType = _slavetype;
			MasterId = _masterid;
			SlaveId = _slaveid;
			LoadCurrent_mA = 0;
		}

		internal Int32 GetHostToMasterBytesCount()
		{
			Int32 functionReturnValue = default(Int32);
			functionReturnValue = 0;
			foreach (Pin p in Pins) {
				if (p.Direction == Pin.Directions.HostToMaster) {
					functionReturnValue += p.UsbBytesCount;
				}
			}
			return functionReturnValue;
		}

		internal Int32 GetMasterToHostBytesCount()
		{
			Int32 functionReturnValue = default(Int32);
			functionReturnValue = 0;
			foreach (Pin p in Pins) {
				if (p.Direction == Pin.Directions.MasterToHost) {
					functionReturnValue += p.UsbBytesCount;
				}
			}
			return functionReturnValue;
		}

        internal bool CalibrationNeeded()
        {
            foreach (Pin p in Pins)
            {
                switch (p.GetPinType())
                {
                    case Pin.PinTypes.CAP_SENSOR:
                        if (p.Area_cmq > 0) return true;
                        break;
                    case Pin.PinTypes.CAP_8:
                    case Pin.PinTypes.CAP_16:
                        if (p.MinVariation > 0) return true;
                        break;
                }
            }
            return false;
        }

		internal virtual void Calibrate()
		{
			foreach (Pin p in Pins) {
				p.Calibrate();
			}
		}

		internal virtual void CalibrateZero()
		{
			foreach (Pin p in Pins) {
				p.CalibrateZero();
			}
		}

		internal virtual UInt32 Get_CapSensor_Or_Cap_Delta()
		{
			UInt32 maxdelta = 0;
            foreach (Pin p in Pins) 
            {
                switch (p.GetPinType())
                {
                    case Pin.PinTypes.CAP_8:
                    case Pin.PinTypes.CAP_16:
                    {
                        UInt32 n = Module_MathFunctions.AbsUint32Difference(p.Value_Uinteger_Max, p.Value_Uinteger_Min);
                        if (n > maxdelta) maxdelta = n;
                        p.ResetPosMinMax();
                    }
                    break;
                }
            }
            return maxdelta;
		}


		internal virtual void ConfigurePin(Int32 npin, Pin.PinTypes pinType)
		{
			switch (SlaveType) 
            {
                case SlaveTypes.Servo:
                case SlaveTypes.Generic:
                case SlaveTypes.InOut:
                {
                    switch (pinType)
                    {
                        case Pin.PinTypes.UNUSED:
                        case Pin.PinTypes.DIG_OUT:
                        case Pin.PinTypes.PWM_8:
                        case Pin.PinTypes.PWM_16:
                        case Pin.PinTypes.SERVO_8:
                        case Pin.PinTypes.SERVO_16:
                        case Pin.PinTypes.DIG_IN:
                        case Pin.PinTypes.DIG_IN_PU:
                        case Pin.PinTypes.COUNTER:
                        case Pin.PinTypes.COUNTER_PU:
                            Pins[npin].SetPinType(pinType);
                            break;
                        case Pin.PinTypes.ADC_8:
                        case Pin.PinTypes.ADC_16:
                        case Pin.PinTypes.CAP_8:
                        case Pin.PinTypes.CAP_16:
                        case Pin.PinTypes.RES_8:
                        case Pin.PinTypes.RES_16:
                            if (npin < 8) Pins[npin].SetPinType(pinType);
                            break;
                        case Pin.PinTypes.FAST_COUNTER:
                        case Pin.PinTypes.FAST_COUNTER_PU:
                            if (npin == 7) Pins[npin].SetPinType(pinType);
                            break;
                        case Pin.PinTypes.USOUND_SENSOR:
                        case Pin.PinTypes.PERIOD:
                        case Pin.PinTypes.PERIOD_PU:
                            if (npin == 8) Pins[npin].SetPinType(pinType);
                            break;
                    }
                    break;
                }
			}
		}

		internal virtual void FillTypeCombo(ComboBox cmb, ref Pin p)
		{
			switch (SlaveType) 
            {
				case SlaveTypes.Servo:
				case SlaveTypes.Generic:
				case SlaveTypes.InOut:
                {
					cmb.Items.Clear();
					//
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED));
					//
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16));
					//
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU));
					//
					if (p.PinId < 8) {
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16));
					}

					//
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER));
					cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU));

					if (p.PinId == 7) {
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU));
					}

					if (p.PinId == 8) {
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU));
						cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR));
					}
					break;
                }
				default:
					cmb.Items.Clear();
					cmb.Items.Add(Pin.PinTypeToString(p.GetPinType()));
					break;
			}
		}

        internal bool ValidLinkedToPrevious(Pin pinSelected)
        {
            if (pinSelected.GetPinType() != Pin.PinTypes.STEPPER) return false;
            if (pinSelected.PinId < 2) return false;
            if (Pins[pinSelected.PinId - 2].GetPinType() != Pin.PinTypes.STEPPER) return false;
            return false; // true;  // <<<<< TODO
        }
	}
}
namespace Theremino_HAL
{

	// ==================================================================================================
	// SUBCLASS - Slave_CapSensor
	// ==================================================================================================
	class Slave_CapSensor : Slave
	{

		internal Slave_CapSensor(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.CapSensor, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 12;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
		}

		internal override UInt32 Get_CapSensor_Or_Cap_Delta()
		{
			UInt32 functionReturnValue = default(UInt32);
			{
                UInt32 n = Module_MathFunctions.AbsUint32Difference(Pins[0].Value_Uinteger_Max, Pins[0].Value_Uinteger_Min);
				if (n < 0) n = 0; 
				if (n > 400000) n = 0; 
				functionReturnValue = n;
				Pins[0].ResetPosMinMax();
			}
			return functionReturnValue;
		}

		internal override void ConfigurePin(Int32 npin, Pin.PinTypes pinType)
		{
			switch (pinType) {
				case Pin.PinTypes.UNUSED:
				case Pin.PinTypes.CAP_SENSOR:
					Pins[npin].SetPinType(pinType);
					break;
			}
		}

		internal override void FillTypeCombo(ComboBox cmb, ref Pin p)
		{
			cmb.Items.Clear();
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_SENSOR));
		}

	}
}
namespace Theremino_HAL
{

	// ==================================================================================================
	//   SUBCLASS - Slave_Servo
	// ==================================================================================================
	class Slave_Servo : Slave
	{

		internal Slave_Servo(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.Servo, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 80;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9));
		}

	}
}

namespace Theremino_HAL
{
	// ==================================================================================================
	//   SUBCLASS - Slave_Generic
	// ==================================================================================================
	class Slave_Generic : Slave
	{

		internal Slave_Generic(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.Generic, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 80;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 10));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 11));
		}

	}
}

namespace Theremino_HAL
{
	// ==================================================================================================
	//   SUBCLASS - Slave_InOut
	// ==================================================================================================
	class Slave_InOut : Slave
	{

		internal Slave_InOut(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.InOut, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 80;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 10));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 11));
		}

	}
}

namespace Theremino_HAL
{
	// ==================================================================================================
	//   SUBCLASS - Slave_MasterPins
	// ==================================================================================================
	class Slave_MasterPins : Slave
	{

		internal Slave_MasterPins(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.MasterPins, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 10;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
		}

		internal override void ConfigurePin(Int32 npin, Pin.PinTypes pinType)
		{
			switch (pinType) 
            {
				case Pin.PinTypes.UNUSED:
				case Pin.PinTypes.DIG_OUT:
				case Pin.PinTypes.PWM_8:
				case Pin.PinTypes.PWM_16:
				case Pin.PinTypes.SERVO_8:
				case Pin.PinTypes.SERVO_16:
				case Pin.PinTypes.DIG_IN:
				case Pin.PinTypes.DIG_IN_PU:
				case Pin.PinTypes.ADC_8:
				case Pin.PinTypes.ADC_16:
				case Pin.PinTypes.CAP_8:
				case Pin.PinTypes.CAP_16:
				case Pin.PinTypes.RES_8:
				case Pin.PinTypes.RES_16:
				case Pin.PinTypes.COUNTER:
				case Pin.PinTypes.COUNTER_PU:
					Pins[npin].SetPinType(pinType);
					break;
				case Pin.PinTypes.FAST_COUNTER:
				case Pin.PinTypes.FAST_COUNTER_PU:
					if (!AlreadyUsed_FastCounter(Pins[npin])) Pins[npin].SetPinType(pinType); 
					break;
				case Pin.PinTypes.USOUND_SENSOR:
				case Pin.PinTypes.PERIOD:
				case Pin.PinTypes.PERIOD_PU:
					if (!AlreadyUsed_PeriodCounter(Pins[npin])) Pins[npin].SetPinType(pinType); 
					break;
			}
		}

		internal override void FillTypeCombo(ComboBox cmb, ref Pin p)
		{
			cmb.Items.Clear();
			//
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED));
			//
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16));
			//
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER));
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU));

			if (!AlreadyUsed_FastCounter(p)) 
            {
				cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER));
				cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU));
			}

			if (!AlreadyUsed_PeriodCounter(p)) 
            {
				cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD));
				cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU));
				cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR));
			}
		}

		private bool AlreadyUsed_FastCounter(Pin pinSelected)
		{
			foreach (Pin p in Pins) {
				if (object.ReferenceEquals(p, pinSelected)) continue; 
				if (p.GetPinType() == Pin.PinTypes.FAST_COUNTER || p.GetPinType() == Pin.PinTypes.FAST_COUNTER_PU) {
					return true;
				}
			}
			return false;
		}

		private bool AlreadyUsed_PeriodCounter(Pin pinSelected)
		{
			foreach (Pin p in Pins) {
				if (object.ReferenceEquals(p, pinSelected)) continue; 
				if (p.GetPinType() == Pin.PinTypes.PERIOD || p.GetPinType() == Pin.PinTypes.PERIOD_PU || p.GetPinType() == Pin.PinTypes.USOUND_SENSOR) {
					return true;
				}
			}
			return false;
		}
	}
}

namespace Theremino_HAL
{
	// ==================================================================================================
	//   SUBCLASS - Slave_MasterPinsV2
	// ==================================================================================================
	class Slave_MasterPinsV2 : Slave
	{

		internal Slave_MasterPinsV2(Int32 _masterid, Int32 _slaveid) : base(SlaveTypes.MasterPinsV2, _masterid, _slaveid)
		{
			InitDefaultPins();
			LoadCurrent_mA = 10;
		}

		private void InitDefaultPins()
		{
			Pins = new List<Pin>();
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
			Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9));
		}

		internal override void ConfigurePin(Int32 npin, Pin.PinTypes pinType)
		{
			switch (pinType) {

				case Pin.PinTypes.UNUSED:
                    Pins[npin].SetPinType(pinType);
                    break;

				case Pin.PinTypes.DIG_OUT:
				case Pin.PinTypes.PWM_8:
				case Pin.PinTypes.PWM_16:
				case Pin.PinTypes.SERVO_8:
				case Pin.PinTypes.SERVO_16:
				case Pin.PinTypes.DIG_IN:
				case Pin.PinTypes.DIG_IN_PU:
				case Pin.PinTypes.COUNTER:
				case Pin.PinTypes.COUNTER_PU:
                case Pin.PinTypes.SLOW_PERIOD:
                case Pin.PinTypes.SLOW_PERIOD_PU:
                    if (ValidGenericPin(Pins[npin])) Pins[npin].SetPinType(pinType);
					break;

                case Pin.PinTypes.ADC_8:
                case Pin.PinTypes.ADC_16:
                case Pin.PinTypes.CAP_8:
                case Pin.PinTypes.CAP_16:
                case Pin.PinTypes.RES_8:
                case Pin.PinTypes.RES_16:
                    if (ValidAdcPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.STEPPER:
                    if (ValidStepperPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.STEPPER_DIR:
                    if (ValidStepperDirPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.PWM_FAST:
                    if (ValidPwmFastPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

				case Pin.PinTypes.FAST_COUNTER:
				case Pin.PinTypes.FAST_COUNTER_PU:
					if (ValidFastCounterPin(Pins[npin])) Pins[npin].SetPinType(pinType); 
					break;

				case Pin.PinTypes.USOUND_SENSOR:
				case Pin.PinTypes.PERIOD:
				case Pin.PinTypes.PERIOD_PU:
					if (ValidPeriodCounterPin(Pins[npin])) Pins[npin].SetPinType(pinType); 
					break;
			}
		}

		internal override void FillTypeCombo(ComboBox cmb, ref Pin p)
		{
			cmb.Items.Clear();
			
			cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED));
			
            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16));
            }

            if (ValidStepperPin(p))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.STEPPER));
            if (ValidStepperDirPin(p))
            {
                cmb.Items.Clear();
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.STEPPER_DIR));
            }
            if (ValidPwmFastPin(p))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_FAST));

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU));
            }

            if (ValidAdcPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16));
            }

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU));
            }

            if (ValidFastCounterPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU));
            }

            if (ValidPeriodCounterPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR));
            }

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SLOW_PERIOD));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SLOW_PERIOD_PU));
            }
		}

        private bool ValidGenericPin(Pin pinSelected)
        {
            if (pinSelected.PinId > 0)
            {
                if (Pins[pinSelected.PinId - 1].GetPinType() == Pin.PinTypes.STEPPER)
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidAdcPin(Pin pinSelected)
        {
            if (!ValidGenericPin(pinSelected)) return false;
            if (pinSelected.PinId > 5) return false;
            return true;
        }

        private bool ValidStepperPin(Pin pinSelected)
        {
            if (CountUsedPwmPins(pinSelected) > 4) return false;
            switch (pinSelected.PinId)
            {
                case 0:
                case 2:
                case 4:
                case 6:
                case 8:
                    return true;
            }
            return false;
        }

        private bool ValidStepperDirPin(Pin pinSelected)
        {
            if (pinSelected.PinId < 1) return false;
            if (Pins[pinSelected.PinId - 1].GetPinType() != Pin.PinTypes.STEPPER) return false;
            return true;
        }

        private bool ValidPwmFastPin(Pin pinSelected)
        {
            if (!ValidGenericPin(pinSelected)) return false;
            if (CountUsedPwmPins(pinSelected) > 4) return false;
            return true;
        }

		private bool ValidFastCounterPin(Pin pinSelected)
		{
            if (!ValidGenericPin(pinSelected)) return false;
			foreach (Pin p in Pins) 
            {
				if (object.ReferenceEquals(p, pinSelected)) continue; 
				if (p.GetPinType() == Pin.PinTypes.FAST_COUNTER || p.GetPinType() == Pin.PinTypes.FAST_COUNTER_PU) {
					return false;
				}
			}
			return true;
		}

		private bool ValidPeriodCounterPin(Pin pinSelected)
		{
            if (!ValidGenericPin(pinSelected)) return false;
			foreach (Pin p in Pins) 
            {
				if (object.ReferenceEquals(p, pinSelected)) continue; 
				if (p.GetPinType() == Pin.PinTypes.PERIOD || p.GetPinType() == Pin.PinTypes.PERIOD_PU || 
                                                             p.GetPinType() == Pin.PinTypes.USOUND_SENSOR) 
                {
					return false;
				}
			}
			return true;
		}

        private Int32 CountUsedPwmPins(Pin pinSelected)
        {
            Int32 n = 0;
            foreach (Pin p in Pins)
            {
                if (object.ReferenceEquals(p, pinSelected)) continue;
                if (p.GetPinType() == Pin.PinTypes.STEPPER || p.GetPinType() == Pin.PinTypes.PWM_FAST)
                {
                    n++;
                }
            }
            return n;
        }

	}
}


namespace Theremino_HAL
{
    // ==================================================================================================
    //   SUBCLASS - Slave_MasterPinsV4
    // ==================================================================================================
    class Slave_MasterPinsV4 : Slave
    {

        internal Slave_MasterPinsV4(Int32 _masterid, Int32 _slaveid)
            : base(SlaveTypes.MasterPinsV4, _masterid, _slaveid)
        {
            InitDefaultPins();
            LoadCurrent_mA = 10;
        }

        private void InitDefaultPins()
        {
            Pins = new List<Pin>();
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 10));
            Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 11));
            // ------------------------------------------------------------ Adc24 pins
            if (ThereminoSystem.Masters[MasterId].MasterFirmwareVersion >= 50)
            {
                for (Int32 i = 0; i <= 15; i++)
                {
                    Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 12 + i));
                }
            }
        }

        internal override void ConfigurePin(Int32 npin, Pin.PinTypes pinType)
        {
            switch (pinType)
            {

                case Pin.PinTypes.UNUSED:
                    Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.DIG_OUT:
                case Pin.PinTypes.PWM_8:
                case Pin.PinTypes.PWM_16:
                case Pin.PinTypes.SERVO_8:
                case Pin.PinTypes.SERVO_16:
                case Pin.PinTypes.DIG_IN:
                case Pin.PinTypes.DIG_IN_PU:
                case Pin.PinTypes.COUNTER:
                case Pin.PinTypes.COUNTER_PU:
                case Pin.PinTypes.SLOW_PERIOD:
                case Pin.PinTypes.SLOW_PERIOD_PU:
                    if (ValidGenericPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.ADC_8:
                case Pin.PinTypes.ADC_16:
                case Pin.PinTypes.CAP_8:
                case Pin.PinTypes.CAP_16:
                case Pin.PinTypes.RES_8:
                case Pin.PinTypes.RES_16:
                    if (ValidAdcPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.ADC_24:
                    if (ValidAdc24Pin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;
                case Pin.PinTypes.ADC_24_DIN:
                    if (ValidAdc24DinPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;
                case Pin.PinTypes.ADC_24_DOUT:
                    if (ValidAdc24DoutPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;
                case Pin.PinTypes.ADC_24_CH:
                    if (ValidAdc24Channel_Pin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;
                case Pin.PinTypes.ADC_24_CH_B:
                    if (ValidAdc24ChannelB_Pin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.STEPPER:
                    if (ValidStepperPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.STEPPER_DIR:
                    if (ValidStepperDirPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.PWM_FAST:
                    if (ValidPwmFastPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.FAST_COUNTER:
                case Pin.PinTypes.FAST_COUNTER_PU:
                    if (ValidFastCounterPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.USOUND_SENSOR:
                case Pin.PinTypes.PERIOD:
                case Pin.PinTypes.PERIOD_PU:
                    if (ValidPeriodCounterPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.ENCODER_A:
                case Pin.PinTypes.ENCODER_A_PU:
                    if (ValidEncoderAPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;

                case Pin.PinTypes.ENCODER_B:
                case Pin.PinTypes.ENCODER_B_PU:
                    if (ValidEncoderBPin(Pins[npin])) Pins[npin].SetPinType(pinType);
                    break;
            }
        }

        internal override void FillTypeCombo(ComboBox cmb, ref Pin p)
        {
            cmb.Items.Clear();

            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED));

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16));
            }

            if (ValidStepperPin(p))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.STEPPER));
            if (ValidStepperDirPin(p))
            {
                cmb.Items.Clear();
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.STEPPER_DIR));
            }
            if (ValidPwmFastPin(p))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_FAST));

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU));
            }

            if (ValidAdcPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16));
            }

            if (ValidAdc24Pin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_24));
            }
            if (ValidAdc24DinPin(p))
            {
                cmb.Items.Clear();
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_24_DIN));
            }
            if (ValidAdc24DoutPin(p))
            {
                cmb.Items.Clear();
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_24_DOUT));
            }
            if (ValidAdc24Channel_Pin_ForComboList(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_24_CH));
            }
            if (ValidAdc24ChannelB_Pin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_24_CH_B));
            }

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU));
            }

            if (ValidFastCounterPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU));
            }

            if (ValidPeriodCounterPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR));
            }

            if (ValidEncoderAPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_A));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_A_PU));
            }
            if (ValidEncoderBPin(p))
            {
                cmb.Items.Clear();
                if (Pins[p.PinId - 1].GetPinType() == Pin.PinTypes.ENCODER_A) 
                {
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_B));
                }
                else
                {
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_B_PU));
                }
            }

            if (ValidGenericPin(p))
            {
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SLOW_PERIOD));
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SLOW_PERIOD_PU));
            }
        }

        private bool ValidGenericPin(Pin pinSelected)
        {
            if (pinSelected.PinId >= 12) return false;
            if (pinSelected.PinId > 0)
            {
                if (Pins[pinSelected.PinId - 1].GetPinType() == Pin.PinTypes.STEPPER)
                {
                    return false;
                }
                if (Pins[pinSelected.PinId - 1].GetPinType() == Pin.PinTypes.ENCODER_A)
                {
                    return false;
                }
                if (Pins[pinSelected.PinId - 1].GetPinType() == Pin.PinTypes.ENCODER_A_PU)
                {
                    return false;
                }
            }
            if (pinSelected.PinId == 7  &&  Pins[6].GetPinType() == Pin.PinTypes.ADC_24)  return false;
            if (pinSelected.PinId == 8  &&  Pins[6].GetPinType() == Pin.PinTypes.ADC_24)  return false;
            return true;
        }

        private bool ValidAdcPin(Pin pinSelected)
        {
            if (!ValidGenericPin(pinSelected)) return false;
            if (pinSelected.PinId > 5) return false;
            return true;
        }

        private bool ValidStepperPin(Pin pinSelected)
        {
            if (CountUsedPwmPins(pinSelected) > 4) return false;
            if (pinSelected.PinId == 8 && Pins[6].GetPinType() == Pin.PinTypes.ADC_24) return false;
            switch (pinSelected.PinId)
            {
                case 0:
                case 2:
                case 4:
                case 6:
                case 8:
                    return true;
            }
            return false;
        }

        private bool ValidStepperDirPin(Pin pinSelected)
        {
            if (pinSelected.PinId < 1) return false;
            if (Pins[pinSelected.PinId - 1].GetPinType() != Pin.PinTypes.STEPPER) return false;
            if (pinSelected.PinId == 9 && Pins[6].GetPinType() == Pin.PinTypes.ADC_24) return false;
            return true;
        }

        private bool ValidPwmFastPin(Pin pinSelected)
        {
            if (pinSelected.PinId > 9) return false;
            if (!ValidGenericPin(pinSelected)) return false;
            if (CountUsedPwmPins(pinSelected) > 4) return false;
            return true;
        }

        private bool ValidFastCounterPin(Pin pinSelected)
        {
            if (pinSelected.PinId > 9) return false;
            if (!ValidGenericPin(pinSelected)) return false;
            foreach (Pin p in Pins)
            {
                if (object.ReferenceEquals(p, pinSelected)) continue;
                if (p.GetPinType() == Pin.PinTypes.FAST_COUNTER || p.GetPinType() == Pin.PinTypes.FAST_COUNTER_PU)
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidPeriodCounterPin(Pin pinSelected)
        {
            if (pinSelected.PinId > 9) return false;
            if (!ValidGenericPin(pinSelected)) return false;
            foreach (Pin p in Pins)
            {
                if (object.ReferenceEquals(p, pinSelected)) continue;
                if (p.GetPinType() == Pin.PinTypes.PERIOD || p.GetPinType() == Pin.PinTypes.PERIOD_PU ||
                                                             p.GetPinType() == Pin.PinTypes.USOUND_SENSOR)
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidAdc24Pin(Pin pinSelected)
        {
            if (ThereminoSystem.Masters[MasterId].MasterFirmwareVersion < 41) return false;
            if (!ValidGenericPin(pinSelected)) return false;
            if (pinSelected.PinId != 6) return false;
            return true;
        }

        private bool ValidAdc24DinPin(Pin pinSelected)
        {
            if (pinSelected.PinId != 7) return false;
            if (Pins[6].GetPinType() != Pin.PinTypes.ADC_24) return false;
            return true;
        }

        private bool ValidAdc24DoutPin(Pin pinSelected)
        {
            if (pinSelected.PinId != 8) return false;
            if (Pins[6].GetPinType() != Pin.PinTypes.ADC_24) return false;
            return true;
        }

        private bool ValidAdc24Channel_Pin(Pin pinSelected)
        {
            if (Pins[6].GetPinType() != Pin.PinTypes.ADC_24) return false;
            if (pinSelected.PinId < 12) return false;
            return true;
        }

        private bool ValidAdc24Channel_Pin_ForComboList(Pin pinSelected)
        {
            if (Pins[6].GetPinType() != Pin.PinTypes.ADC_24) return false;
            if (pinSelected.PinId < 12) return false;
            if (pinSelected.PinId % 2 == 1)
            {
                if (pinSelected.Adc24ChType == 0) return false; // if differential
            }
            return true;
        }

        private bool ValidAdc24ChannelB_Pin(Pin pinSelected)
        {
            if (Pins[6].GetPinType() != Pin.PinTypes.ADC_24) return false; 
            if (pinSelected.PinId < 12) return false;
            if (pinSelected.PinId % 2 == 0) return false;
            if (pinSelected.Adc24ChType != 0) return false; // if not differential
            return true;
        }

        private bool ValidEncoderAPin(Pin pinSelected)
        {
            if (pinSelected.PinId > 10) return false;
            Pin.PinTypes pt = Pins[pinSelected.PinId + 1].GetPinType();

            if (pt == Pin.PinTypes.STEPPER) return false;
            if (pt == Pin.PinTypes.ENCODER_A) return false;
            if (pt == Pin.PinTypes.ENCODER_A_PU) return false;
            if (pinSelected.PinId > 0)
            {
                pt = Pins[pinSelected.PinId - 1].GetPinType();
                if (pt == Pin.PinTypes.STEPPER) return false;
                if (pt == Pin.PinTypes.ENCODER_A) return false;
                if (pt == Pin.PinTypes.ENCODER_A_PU) return false;
            }
            if (pinSelected.PinId == 7  ||  pinSelected.PinId == 8)
            {
                pt = Pins[6].GetPinType();
                if (pt == Pin.PinTypes.ADC_24) return false;
            }
            return true;
        }

        private bool ValidEncoderBPin(Pin pinSelected)
        {
            if (pinSelected.PinId < 1) return false;

            Pin.PinTypes pt = Pins[pinSelected.PinId - 1].GetPinType();

            if (pt != Pin.PinTypes.ENCODER_A
                && 
                pt != Pin.PinTypes.ENCODER_A_PU)
            {
                return false;
            }
            if (pinSelected.PinId == 9 && Pins[6].GetPinType() == Pin.PinTypes.ADC_24) return false;
            return true;
        }

        private Int32 CountUsedPwmPins(Pin pinSelected)
        {
            Int32 n = 0;
            foreach (Pin p in Pins)
            {
                if (object.ReferenceEquals(p, pinSelected)) continue;
                if (p.GetPinType() == Pin.PinTypes.STEPPER || p.GetPinType() == Pin.PinTypes.PWM_FAST)
                {
                    n++;
                }
            }
            return n;
        }

        internal void Adc24_AddRemovePins()
        {
            if (Pins[6].GetPinType() == Pin.PinTypes.ADC_24)
            {
                //
                Int32 delta = Pins[6].Adc24Npins + 12 - Pins.Count;
                // ------------------------------------ remove redundant pins
                if (delta < 0)
                {
                    for (Int32 i = 1; i <= -delta; i++)
                    {
                        Pins.Remove(Pins[Pins.Count - 1]);
                    }
                }
                // ------------------------------------ add lacking pins
                if (delta > 0)
                {
                    for (Int32 i = 1; i <= delta; i++)
                    {
                        Pins.Add(new Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, Pins.Count));
                        Pin p = Pins[Pins.Count - 1];
                        p.Slot = MasterId * 100 + p.PinId + 1;
                    }
                }
            }
            else
            {
                Int32 c = Pins.Count;
                for (Int32 i = 1; i <= c - 12; i++)
                {
                    Pins.Remove(Pins[Pins.Count - 1]);
                }
            }
        }


        // ==================================================================================================
        //   ADC_24 SEND CONFIGURATIONS and START
        // ==================================================================================================
        //private Int32[] Adc24SpsArray = new Int32[] {10, 20, 50, 100, 200, 500, 1000, 2000, 
        //                                             3200, 3840, 4800, 6400, 9600, 19200};
        //Adc24Fsck_KHz = 31,36,42,50,63,83,125,143,167,200,250,333,500,
        //                571,667,800,1000,1333,2000,2286,2667,3200,4000

        internal void Adc24ConfigAndStart()
        {
            Int32 Sps;                               // Samples per second
            Int32 Fsck_KHz;                          // SPI clock (comm from PIC to ADC24)
            bool MultipleSetups;
            bool FiltersSingleCycle;

            Int32 Adc24PreFilterType;        // Pre filter type 0b000 to 0b111 
            Int32 Adc24PostFilterType;       // Post filter type 0b000 to 0b111 
            Int32 Adc24ActiveChannels;       // The channel is active (bit0 = ch0)
            Int32 Adc24BiasedChannels;       // Channels biased with 1.65 Volt (vcc / 2) 
            Int32 Adc24DiffChannels;         // Differential / SingleEnded channels
            Int32 Adc24PseudoChannels;       // Pseudo channels referred to Input 15
            Int32 Adc24ChannelsGains;        // Gain 1 to 128 (low 3 bits are for channel 0)

            Sps = Pins[6].Adc24Sps;

            // --------------------------------------------------------------------------
            // at 19200 SPS each sample = 52 uS
            // at 1000 KHz
            // 5 bytes = 40 bit = 40 uS + 10 uS(worst case interrupt latency) = 50 uS
            // --------------------------------------------------------------------------
            // Select the appropriate Fsck from Sps
            // valid sps are: 19200 9600 4800 3840 3200 2742.8 2400 2133.3 1920 .... 10
            if (Sps > 9600)  Fsck_KHz = 1000;
            else if (Sps > 4800) Fsck_KHz = 500;
            else Fsck_KHz = 250;
            
            // --------------------------------------------------------------------------
            // Override
            // Fsck_KHz = 31;
            // --------------------------------------------------------------------------
            // Valid Fsck (KHz)
            // 31,36,42,50,63,83,125,143,167,200,250,333,500,571,667,800,1000,1333,2000,2286,2667,3200,4000
            // --------------------------------------------------------------------------
     
            MultipleSetups = true;      // Every channel's couple uses a different setup
            FiltersSingleCycle = false; // All filters not using SingleCycle 

            // ---------------- FILTER LIST
            // Max Speed 
            // Fast
            // Medium
            // Slow
            // Post Max 
            // Post Fast
            // Post Medium
            // Post Slow

            switch (Pins[6].Adc24Filter)
            {
                default:
                case 0: // Sync3
                    Adc24PreFilterType = Convert.ToInt32("010", 2);
                    Adc24PostFilterType = Convert.ToInt32("011", 2); // unused
                    break;
                case 1: // Sync4
                    Adc24PreFilterType = Convert.ToInt32("000", 2);
                    Adc24PostFilterType = Convert.ToInt32("011", 2); // unused
                    break;
                case 2: // Sync3 FastSettling
                    Adc24PreFilterType = Convert.ToInt32("101", 2);
                    Adc24PostFilterType = Convert.ToInt32("011", 2); // unused
                    break;
                case 3: // Sync4 FastSettling
                    Adc24PreFilterType = Convert.ToInt32("100", 2);
                    Adc24PostFilterType = Convert.ToInt32("011", 2); // unused
                    break;
                case 4: // Post1
                    Adc24PreFilterType = Convert.ToInt32("111", 2);
                    Adc24PostFilterType = Convert.ToInt32("010", 2);
                    break;
                case 5: // Post2
                    Adc24PreFilterType = Convert.ToInt32("111", 2);
                    Adc24PostFilterType = Convert.ToInt32("011", 2);
                    break;
                case 6: // Post3
                    Adc24PreFilterType = Convert.ToInt32("111", 2);
                    Adc24PostFilterType = Convert.ToInt32("101", 2); 
                    break;
                case 7: // Post4
                    Adc24PreFilterType = Convert.ToInt32("111", 2);
                    Adc24PostFilterType = Convert.ToInt32("110", 2);
                    break;
            }

            // ------------------------------------------------------------- FILL MASKS
            Adc24ActiveChannels = 0;
            Adc24DiffChannels = 0;
            Adc24PseudoChannels = 0;
            Adc24ChannelsGains = 0;
            Adc24BiasedChannels = 0;
            Int32 pow2 = 1;
            Int32 pow8 = 1;
            Pin p;
            for (Int32 i = 0; i <= 15; i++)
            {
                if (i + 12 >= Pins.Count) break;
                p = Pins[i + 12];
                if (p.GetPinType() == Pin.PinTypes.ADC_24_CH || p.GetPinType() == Pin.PinTypes.ADC_24_CH_B)
                {
                    // ----------------------------------------------------- If differential couple, set only first pin
                    if (p.PinId % 2 == 0 | p.Adc24ChType != 0)
                    {
                        Adc24ActiveChannels += pow2;
                    }
                    // ----------------------------------------------------- Pseudo
                    if (p.Adc24ChType == 0) Adc24DiffChannels += pow2;
                    if (p.Adc24ChType == 1) Adc24PseudoChannels += pow2;
                    // ----------------------------------------------------- Gains
                    if (p.GetPinType() != Pin.PinTypes.UNUSED)
                    {
                        Adc24ChannelsGains |= p.Adc24ChGain * pow8;
                    }
                    // ----------------------------------------------------- Biased
                    if (p.Adc24ChBias) Adc24BiasedChannels += pow2;
                }
                pow2 *= 2;
                if (p.PinId % 2 == 1)
                {
                    pow8 *= 8;
                }
            }

            if (Adc24PseudoChannels != 0)
            {
                Adc24BiasedChannels |= Convert.ToInt32("1000000000000000", 2);
            }

            // ------------------------------------------------------------- OVERRIDE MASKS
            //// active
            //Adc24ActiveChannels = Convert.ToInt32("0000000000000001", 2);
            //// Combo - Diff Pseudo Single
            //Adc24DiffChannels = Convert.ToInt32("0000000000000001", 2);
            //Adc24PseudoChannels = Convert.ToInt32("0000000000000000", 2);
            //// Combo - Gain 1 2 4 8 16 32 64 128
            //Adc24ChannelsGains = Convert.ToInt32("111111111111111111111111", 2);  // 000=1 001=2 010=4 011=8 100=16 ... 110=64 111=128
            //// Check - Biased
            //Adc24BiasedChannels = Convert.ToInt32("0000000000000000", 2);

            // --------------------------------------------------------------------------------
            //   ADC_24 CONFIG - BY ASYNChronous SendBytesToSlave - SendAdc24ConfigToHardware
            // --------------------------------------------------------------------------------
            byte[] b = new byte[20];
            b[0] = Convert.ToByte(Master.CommandsToHardware.SendAdc24Config);
            b[1] = Convert.ToByte((Sps >> 8) & 255);
            b[2] = Convert.ToByte(Sps & 255);
            b[3] = Convert.ToByte((Fsck_KHz >> 8) & 255);
            b[4] = Convert.ToByte(Fsck_KHz & 255);
            b[5] = Convert.ToByte(MultipleSetups ? 1 : 0);
            b[6] = Convert.ToByte(FiltersSingleCycle ? 1 : 0);
            b[7] = Convert.ToByte(Adc24PreFilterType & 255);
            b[8] = Convert.ToByte(Adc24PostFilterType & 255);
            b[9] = Convert.ToByte((Adc24ActiveChannels >> 8) & 255);
            b[10] = Convert.ToByte(Adc24ActiveChannels & 255);
            b[11] = Convert.ToByte((Adc24BiasedChannels >> 8) & 255);
            b[12] = Convert.ToByte(Adc24BiasedChannels & 255);
            b[13] = Convert.ToByte((Adc24DiffChannels >> 8) & 255);
            b[14] = Convert.ToByte(Adc24DiffChannels & 255);
            b[15] = Convert.ToByte((Adc24PseudoChannels >> 8) & 255);
            b[16] = Convert.ToByte(Adc24PseudoChannels & 255);
            b[17] = Convert.ToByte((Adc24ChannelsGains >> 16) & 255);
            b[18] = Convert.ToByte((Adc24ChannelsGains >> 8) & 255);
            b[19] = Convert.ToByte(Adc24ChannelsGains & 255);
            ThereminoSystem.Masters[MasterId].SendBytesToSlave(0, ref b);
        }

    }
}


