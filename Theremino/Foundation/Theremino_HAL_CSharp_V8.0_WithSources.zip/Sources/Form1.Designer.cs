﻿namespace Theremino_HAL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            CustomControlsLib.DesignerRectTracker designerRectTracker1 = new CustomControlsLib.DesignerRectTracker();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            CustomControlsLib.cBlendItems cBlendItems1 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems2 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker2 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.DesignerRectTracker designerRectTracker3 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.cBlendItems cBlendItems3 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems4 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker4 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.DesignerRectTracker designerRectTracker5 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.cBlendItems cBlendItems5 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems6 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker6 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.DesignerRectTracker designerRectTracker7 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.cBlendItems cBlendItems7 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems8 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker8 = new CustomControlsLib.DesignerRectTracker();
            this.GroupBox_TouchProps = new System.Windows.Forms.GroupBox();
            this.txt_MinVariation = new CustomControlsLib.MyTextBox();
            this.txt_ProportionalArea = new CustomControlsLib.MyTextBox();
            this.Label_ProportionalArea = new System.Windows.Forms.Label();
            this.Label_MinVariation = new System.Windows.Forms.Label();
            this.GroupBox_FrequencyProps = new System.Windows.Forms.GroupBox();
            this.chk_ConvertToFrequency = new System.Windows.Forms.CheckBox();
            this.txt_MaxFreq = new CustomControlsLib.MyTextBox();
            this.Label_MinFreq = new System.Windows.Forms.Label();
            this.txt_MinFreq = new CustomControlsLib.MyTextBox();
            this.Label_MaxFreq = new System.Windows.Forms.Label();
            this.GroupBox_ServoPwmProps = new System.Windows.Forms.GroupBox();
            this.chk_LogResponse = new System.Windows.Forms.CheckBox();
            this.txt_ServoMaxTime = new CustomControlsLib.MyTextBox();
            this.Label_MinTime = new System.Windows.Forms.Label();
            this.txt_ServoMinTime = new CustomControlsLib.MyTextBox();
            this.Label_MaxTime = new System.Windows.Forms.Label();
            this.GroupBox_CapSensorProps = new System.Windows.Forms.GroupBox();
            this.chk_RemoveErrors = new System.Windows.Forms.CheckBox();
            this.txt_CapMaxDist = new CustomControlsLib.MyTextBox();
            this.Label_MinDist = new System.Windows.Forms.Label();
            this.txt_CapMinDist = new CustomControlsLib.MyTextBox();
            this.txt_CapArea = new CustomControlsLib.MyTextBox();
            this.Label_Area = new System.Windows.Forms.Label();
            this.Label_MaxDist = new System.Windows.Forms.Label();
            this.GroupBox_PinProps = new System.Windows.Forms.GroupBox();
            this.Label_ResponseSpeed = new CustomControlsLib.MyButton();
            this.txt_Slot = new CustomControlsLib.MyTextBox();
            this.cmb_PinType = new CustomControlsLib.MyComboBox();
            this.Label_PinType = new System.Windows.Forms.Label();
            this.Label_MaxValue = new System.Windows.Forms.Label();
            this.Label_Slot = new System.Windows.Forms.Label();
            this.txt_MaxValue = new CustomControlsLib.MyTextBox();
            this.txt_ResponseSpeed = new CustomControlsLib.MyTextBox();
            this.txt_MinValue = new CustomControlsLib.MyTextBox();
            this.Label_MinValue = new System.Windows.Forms.Label();
            this.GroupBox_MasterProps = new System.Windows.Forms.GroupBox();
            this.btn_MasterName = new CustomControlsLib.MyButton();
            this.cmb_MasterNames = new CustomControlsLib.MyComboBox();
            this.chk_FastDataExchange = new System.Windows.Forms.CheckBox();
            this.lbl_ErrorRate = new System.Windows.Forms.Label();
            this.Label_ErrorRate = new System.Windows.Forms.Label();
            this.lbl_RepeatFrequency = new System.Windows.Forms.Label();
            this.Label_RepFreq = new System.Windows.Forms.Label();
            this.txt_CommSpeed = new CustomControlsLib.MyTextBox();
            this.Label_CommSpeed = new System.Windows.Forms.Label();
            this.Timer_10Hz = new System.Windows.Forms.Timer(this.components);
            this.Timer_1Hz = new System.Windows.Forms.Timer(this.components);
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButton_Recognize = new System.Windows.Forms.ToolStripButton();
            this.ToolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButton_Validate = new System.Windows.Forms.ToolStripButton();
            this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButton_BeepOnErrors = new System.Windows.Forms.ToolStripButton();
            this.ToolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButton_Lock = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButton_Disconnect = new System.Windows.Forms.ToolStripButton();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Menu_File = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_File_OpenProgramFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_File_EditSlotNames = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_File_EditConfigurations = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Menu_File_BackupConfigurations = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_File_LoadConfigurations = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Menu_File_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Tools = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_English = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Italian = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Francais = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Espanol = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Portoguese = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Deutsch = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Japanese = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Language_Chinese = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Help_ProgramHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_About = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_Calibrate = new CustomControlsLib.MyButton();
            this.txt_MinChange = new CustomControlsLib.MyTextBox();
            this.Pic_CalibrateTime = new System.Windows.Forms.PictureBox();
            this.GroupBox_StepperProps = new System.Windows.Forms.GroupBox();
            this.chk_LinkedToPrevious = new System.Windows.Forms.CheckBox();
            this.Label_StepsPerMillim = new System.Windows.Forms.Label();
            this.txt_StepsPerMillim = new CustomControlsLib.MyTextBox();
            this.txt_MaxSpeed = new CustomControlsLib.MyTextBox();
            this.Label_MaxAcc = new System.Windows.Forms.Label();
            this.txt_MaxAcc = new CustomControlsLib.MyTextBox();
            this.Label_MaxSpeed = new System.Windows.Forms.Label();
            this.GroupBox_PwmFastProps = new System.Windows.Forms.GroupBox();
            this.chk_DutyCycleFromSlot = new System.Windows.Forms.CheckBox();
            this.chk_FrequencyFromSlot = new System.Windows.Forms.CheckBox();
            this.txt_PwmFastFrequency = new CustomControlsLib.MyTextBox();
            this.Label_PwmFastDutyCycle = new System.Windows.Forms.Label();
            this.txt_PwmFastDutyCycle = new CustomControlsLib.MyTextBox();
            this.Label_PwmFastFrequency = new System.Windows.Forms.Label();
            this.btn_Reconnect = new CustomControlsLib.MyButton();
            this.GroupBox_Adc24Props = new System.Windows.Forms.GroupBox();
            this.cmb_Adc24Sps = new CustomControlsLib.MyComboBox();
            this.cmb_Adc24Filter = new CustomControlsLib.MyComboBox();
            this.Label_Adc24Filter = new System.Windows.Forms.Label();
            this.txt_NumberOfPins = new CustomControlsLib.MyTextBox();
            this.Label_SamplesPerSec = new System.Windows.Forms.Label();
            this.Label_NumberOfPins = new System.Windows.Forms.Label();
            this.chk_Adc24ChBiased = new System.Windows.Forms.CheckBox();
            this.GroupBox_Adc24ChProps = new System.Windows.Forms.GroupBox();
            this.cmb_Adc24ChGain = new CustomControlsLib.MyComboBox();
            this.cmb_Adc24ChType = new CustomControlsLib.MyComboBox();
            this.Label_Adc24ChGain = new System.Windows.Forms.Label();
            this.Label_Adc24ChType = new System.Windows.Forms.Label();
            this.Timer_60Hz = new System.Windows.Forms.Timer(this.components);
            this.MyListView1 = new CustomControlsLib.ListViewFlickerFree();
            this.GroupBox_TouchProps.SuspendLayout();
            this.GroupBox_FrequencyProps.SuspendLayout();
            this.GroupBox_ServoPwmProps.SuspendLayout();
            this.GroupBox_CapSensorProps.SuspendLayout();
            this.GroupBox_PinProps.SuspendLayout();
            this.GroupBox_MasterProps.SuspendLayout();
            this.ToolStrip1.SuspendLayout();
            this.MenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_CalibrateTime)).BeginInit();
            this.GroupBox_StepperProps.SuspendLayout();
            this.GroupBox_PwmFastProps.SuspendLayout();
            this.GroupBox_Adc24Props.SuspendLayout();
            this.GroupBox_Adc24ChProps.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox_TouchProps
            // 
            this.GroupBox_TouchProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_TouchProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_TouchProps.Controls.Add(this.txt_MinVariation);
            this.GroupBox_TouchProps.Controls.Add(this.txt_ProportionalArea);
            this.GroupBox_TouchProps.Controls.Add(this.Label_ProportionalArea);
            this.GroupBox_TouchProps.Controls.Add(this.Label_MinVariation);
            this.GroupBox_TouchProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_TouchProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_TouchProps.Location = new System.Drawing.Point(234, 159);
            this.GroupBox_TouchProps.Name = "GroupBox_TouchProps";
            this.GroupBox_TouchProps.Size = new System.Drawing.Size(180, 71);
            this.GroupBox_TouchProps.TabIndex = 193;
            this.GroupBox_TouchProps.TabStop = false;
            this.GroupBox_TouchProps.Text = "Touch properties";
            this.GroupBox_TouchProps.Visible = false;
            // 
            // txt_MinVariation
            // 
            this.txt_MinVariation.ArrowsIncrement = 1;
            this.txt_MinVariation.BackColor = System.Drawing.Color.MintCream;
            this.txt_MinVariation.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MinVariation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MinVariation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MinVariation.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinVariation.ForeColor = System.Drawing.Color.Black;
            this.txt_MinVariation.Increment = 0.2;
            this.txt_MinVariation.Location = new System.Drawing.Point(129, 25);
            this.txt_MinVariation.MaxValue = 500;
            this.txt_MinVariation.MinValue = -1000;
            this.txt_MinVariation.Name = "txt_MinVariation";
            this.txt_MinVariation.NumericValue = 10;
            this.txt_MinVariation.NumericValueInteger = 10;
            this.txt_MinVariation.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MinVariation.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MinVariation.RoundingStep = 0;
            this.txt_MinVariation.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MinVariation.Size = new System.Drawing.Size(40, 15);
            this.txt_MinVariation.SuppressZeros = true;
            this.txt_MinVariation.TabIndex = 17;
            this.txt_MinVariation.Text = "10";
            this.txt_MinVariation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ProportionalArea
            // 
            this.txt_ProportionalArea.ArrowsIncrement = 1;
            this.txt_ProportionalArea.BackColor = System.Drawing.Color.MintCream;
            this.txt_ProportionalArea.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ProportionalArea.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ProportionalArea.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ProportionalArea.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProportionalArea.ForeColor = System.Drawing.Color.Black;
            this.txt_ProportionalArea.Increment = 0.2;
            this.txt_ProportionalArea.Location = new System.Drawing.Point(129, 46);
            this.txt_ProportionalArea.MaxValue = 1000;
            this.txt_ProportionalArea.MinValue = -500;
            this.txt_ProportionalArea.Name = "txt_ProportionalArea";
            this.txt_ProportionalArea.NumericValue = 0;
            this.txt_ProportionalArea.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ProportionalArea.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ProportionalArea.RoundingStep = 0;
            this.txt_ProportionalArea.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ProportionalArea.Size = new System.Drawing.Size(40, 15);
            this.txt_ProportionalArea.SuppressZeros = true;
            this.txt_ProportionalArea.TabIndex = 18;
            this.txt_ProportionalArea.Text = "0";
            this.txt_ProportionalArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_ProportionalArea
            // 
            this.Label_ProportionalArea.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ProportionalArea.Location = new System.Drawing.Point(10, 47);
            this.Label_ProportionalArea.Name = "Label_ProportionalArea";
            this.Label_ProportionalArea.Size = new System.Drawing.Size(118, 13);
            this.Label_ProportionalArea.TabIndex = 163;
            this.Label_ProportionalArea.Text = "Proportional area";
            this.Label_ProportionalArea.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_MinVariation
            // 
            this.Label_MinVariation.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MinVariation.Location = new System.Drawing.Point(10, 26);
            this.Label_MinVariation.Name = "Label_MinVariation";
            this.Label_MinVariation.Size = new System.Drawing.Size(118, 13);
            this.Label_MinVariation.TabIndex = 161;
            this.Label_MinVariation.Text = "Min variation";
            this.Label_MinVariation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox_FrequencyProps
            // 
            this.GroupBox_FrequencyProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_FrequencyProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_FrequencyProps.Controls.Add(this.chk_ConvertToFrequency);
            this.GroupBox_FrequencyProps.Controls.Add(this.txt_MaxFreq);
            this.GroupBox_FrequencyProps.Controls.Add(this.Label_MinFreq);
            this.GroupBox_FrequencyProps.Controls.Add(this.txt_MinFreq);
            this.GroupBox_FrequencyProps.Controls.Add(this.Label_MaxFreq);
            this.GroupBox_FrequencyProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_FrequencyProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_FrequencyProps.Location = new System.Drawing.Point(232, 337);
            this.GroupBox_FrequencyProps.Name = "GroupBox_FrequencyProps";
            this.GroupBox_FrequencyProps.Size = new System.Drawing.Size(180, 91);
            this.GroupBox_FrequencyProps.TabIndex = 192;
            this.GroupBox_FrequencyProps.TabStop = false;
            this.GroupBox_FrequencyProps.Text = "Freq. properties";
            this.GroupBox_FrequencyProps.Visible = false;
            // 
            // chk_ConvertToFrequency
            // 
            this.chk_ConvertToFrequency.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_ConvertToFrequency.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_ConvertToFrequency.Location = new System.Drawing.Point(10, 20);
            this.chk_ConvertToFrequency.Name = "chk_ConvertToFrequency";
            this.chk_ConvertToFrequency.Size = new System.Drawing.Size(160, 17);
            this.chk_ConvertToFrequency.TabIndex = 164;
            this.chk_ConvertToFrequency.Text = "Convert to frequency  ";
            this.chk_ConvertToFrequency.UseVisualStyleBackColor = true;
            // 
            // txt_MaxFreq
            // 
            this.txt_MaxFreq.ArrowsIncrement = 1;
            this.txt_MaxFreq.BackColor = System.Drawing.Color.MintCream;
            this.txt_MaxFreq.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MaxFreq.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaxFreq.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MaxFreq.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaxFreq.ForeColor = System.Drawing.Color.Black;
            this.txt_MaxFreq.Increment = 0.2;
            this.txt_MaxFreq.Location = new System.Drawing.Point(107, 48);
            this.txt_MaxFreq.MaxValue = 50000000;
            this.txt_MaxFreq.MinValue = 1;
            this.txt_MaxFreq.Name = "txt_MaxFreq";
            this.txt_MaxFreq.NumericValue = 1000;
            this.txt_MaxFreq.NumericValueInteger = 1000;
            this.txt_MaxFreq.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MaxFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MaxFreq.RoundingStep = 0;
            this.txt_MaxFreq.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MaxFreq.Size = new System.Drawing.Size(67, 15);
            this.txt_MaxFreq.SuppressZeros = true;
            this.txt_MaxFreq.TabIndex = 22;
            this.txt_MaxFreq.Text = "1000";
            this.txt_MaxFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MinFreq
            // 
            this.Label_MinFreq.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MinFreq.Location = new System.Drawing.Point(10, 69);
            this.Label_MinFreq.Name = "Label_MinFreq";
            this.Label_MinFreq.Size = new System.Drawing.Size(96, 13);
            this.Label_MinFreq.TabIndex = 163;
            this.Label_MinFreq.Text = "Min freq ( Hz )";
            this.Label_MinFreq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_MinFreq
            // 
            this.txt_MinFreq.ArrowsIncrement = 1;
            this.txt_MinFreq.BackColor = System.Drawing.Color.MintCream;
            this.txt_MinFreq.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MinFreq.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MinFreq.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MinFreq.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinFreq.ForeColor = System.Drawing.Color.Black;
            this.txt_MinFreq.Increment = 0.2;
            this.txt_MinFreq.Location = new System.Drawing.Point(107, 68);
            this.txt_MinFreq.MaxValue = 50000000;
            this.txt_MinFreq.MinValue = 0;
            this.txt_MinFreq.Name = "txt_MinFreq";
            this.txt_MinFreq.NumericValue = 0;
            this.txt_MinFreq.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MinFreq.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MinFreq.RoundingStep = 0;
            this.txt_MinFreq.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MinFreq.Size = new System.Drawing.Size(67, 15);
            this.txt_MinFreq.SuppressZeros = true;
            this.txt_MinFreq.TabIndex = 23;
            this.txt_MinFreq.Text = "0";
            this.txt_MinFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MaxFreq
            // 
            this.Label_MaxFreq.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxFreq.Location = new System.Drawing.Point(10, 49);
            this.Label_MaxFreq.Name = "Label_MaxFreq";
            this.Label_MaxFreq.Size = new System.Drawing.Size(96, 13);
            this.Label_MaxFreq.TabIndex = 161;
            this.Label_MaxFreq.Text = "Max freq ( Hz )";
            this.Label_MaxFreq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox_ServoPwmProps
            // 
            this.GroupBox_ServoPwmProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_ServoPwmProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_ServoPwmProps.Controls.Add(this.chk_LogResponse);
            this.GroupBox_ServoPwmProps.Controls.Add(this.txt_ServoMaxTime);
            this.GroupBox_ServoPwmProps.Controls.Add(this.Label_MinTime);
            this.GroupBox_ServoPwmProps.Controls.Add(this.txt_ServoMinTime);
            this.GroupBox_ServoPwmProps.Controls.Add(this.Label_MaxTime);
            this.GroupBox_ServoPwmProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_ServoPwmProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_ServoPwmProps.Location = new System.Drawing.Point(234, 237);
            this.GroupBox_ServoPwmProps.Name = "GroupBox_ServoPwmProps";
            this.GroupBox_ServoPwmProps.Size = new System.Drawing.Size(180, 92);
            this.GroupBox_ServoPwmProps.TabIndex = 191;
            this.GroupBox_ServoPwmProps.TabStop = false;
            this.GroupBox_ServoPwmProps.Text = "Servo properties";
            this.GroupBox_ServoPwmProps.Visible = false;
            // 
            // chk_LogResponse
            // 
            this.chk_LogResponse.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_LogResponse.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_LogResponse.Location = new System.Drawing.Point(10, 69);
            this.chk_LogResponse.Name = "chk_LogResponse";
            this.chk_LogResponse.Size = new System.Drawing.Size(159, 17);
            this.chk_LogResponse.TabIndex = 165;
            this.chk_LogResponse.Text = "Logarithmic response";
            this.chk_LogResponse.UseVisualStyleBackColor = true;
            // 
            // txt_ServoMaxTime
            // 
            this.txt_ServoMaxTime.ArrowsIncrement = 1;
            this.txt_ServoMaxTime.BackColor = System.Drawing.Color.MintCream;
            this.txt_ServoMaxTime.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ServoMaxTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ServoMaxTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ServoMaxTime.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServoMaxTime.ForeColor = System.Drawing.Color.Black;
            this.txt_ServoMaxTime.Increment = 0.2;
            this.txt_ServoMaxTime.Location = new System.Drawing.Point(119, 25);
            this.txt_ServoMaxTime.MaxValue = 4000;
            this.txt_ServoMaxTime.MinValue = 0;
            this.txt_ServoMaxTime.Name = "txt_ServoMaxTime";
            this.txt_ServoMaxTime.NumericValue = 2500;
            this.txt_ServoMaxTime.NumericValueInteger = 2500;
            this.txt_ServoMaxTime.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ServoMaxTime.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ServoMaxTime.RoundingStep = 0;
            this.txt_ServoMaxTime.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ServoMaxTime.Size = new System.Drawing.Size(51, 15);
            this.txt_ServoMaxTime.SuppressZeros = true;
            this.txt_ServoMaxTime.TabIndex = 19;
            this.txt_ServoMaxTime.Text = "2500";
            this.txt_ServoMaxTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MinTime
            // 
            this.Label_MinTime.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MinTime.Location = new System.Drawing.Point(10, 47);
            this.Label_MinTime.Name = "Label_MinTime";
            this.Label_MinTime.Size = new System.Drawing.Size(106, 13);
            this.Label_MinTime.TabIndex = 163;
            this.Label_MinTime.Text = "Min time  ( uS )";
            // 
            // txt_ServoMinTime
            // 
            this.txt_ServoMinTime.ArrowsIncrement = 1;
            this.txt_ServoMinTime.BackColor = System.Drawing.Color.MintCream;
            this.txt_ServoMinTime.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ServoMinTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ServoMinTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ServoMinTime.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServoMinTime.ForeColor = System.Drawing.Color.Black;
            this.txt_ServoMinTime.Increment = 0.2;
            this.txt_ServoMinTime.Location = new System.Drawing.Point(119, 46);
            this.txt_ServoMinTime.MaxValue = 4000;
            this.txt_ServoMinTime.MinValue = 0;
            this.txt_ServoMinTime.Name = "txt_ServoMinTime";
            this.txt_ServoMinTime.NumericValue = 500;
            this.txt_ServoMinTime.NumericValueInteger = 500;
            this.txt_ServoMinTime.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ServoMinTime.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ServoMinTime.RoundingStep = 0;
            this.txt_ServoMinTime.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ServoMinTime.Size = new System.Drawing.Size(51, 15);
            this.txt_ServoMinTime.SuppressZeros = true;
            this.txt_ServoMinTime.TabIndex = 20;
            this.txt_ServoMinTime.Text = "500";
            this.txt_ServoMinTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MaxTime
            // 
            this.Label_MaxTime.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxTime.Location = new System.Drawing.Point(10, 26);
            this.Label_MaxTime.Name = "Label_MaxTime";
            this.Label_MaxTime.Size = new System.Drawing.Size(106, 13);
            this.Label_MaxTime.TabIndex = 161;
            this.Label_MaxTime.Text = "Max time ( uS )";
            // 
            // GroupBox_CapSensorProps
            // 
            this.GroupBox_CapSensorProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_CapSensorProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_CapSensorProps.Controls.Add(this.chk_RemoveErrors);
            this.GroupBox_CapSensorProps.Controls.Add(this.txt_CapMaxDist);
            this.GroupBox_CapSensorProps.Controls.Add(this.Label_MinDist);
            this.GroupBox_CapSensorProps.Controls.Add(this.txt_CapMinDist);
            this.GroupBox_CapSensorProps.Controls.Add(this.txt_CapArea);
            this.GroupBox_CapSensorProps.Controls.Add(this.Label_Area);
            this.GroupBox_CapSensorProps.Controls.Add(this.Label_MaxDist);
            this.GroupBox_CapSensorProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_CapSensorProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_CapSensorProps.Location = new System.Drawing.Point(439, 329);
            this.GroupBox_CapSensorProps.Name = "GroupBox_CapSensorProps";
            this.GroupBox_CapSensorProps.Size = new System.Drawing.Size(180, 111);
            this.GroupBox_CapSensorProps.TabIndex = 189;
            this.GroupBox_CapSensorProps.TabStop = false;
            this.GroupBox_CapSensorProps.Text = "Cap sensor properties";
            this.GroupBox_CapSensorProps.Visible = false;
            // 
            // chk_RemoveErrors
            // 
            this.chk_RemoveErrors.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_RemoveErrors.Checked = true;
            this.chk_RemoveErrors.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_RemoveErrors.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_RemoveErrors.Location = new System.Drawing.Point(10, 89);
            this.chk_RemoveErrors.Name = "chk_RemoveErrors";
            this.chk_RemoveErrors.Size = new System.Drawing.Size(156, 17);
            this.chk_RemoveErrors.TabIndex = 170;
            this.chk_RemoveErrors.Text = "Remove errors";
            this.chk_RemoveErrors.UseVisualStyleBackColor = true;
            // 
            // txt_CapMaxDist
            // 
            this.txt_CapMaxDist.ArrowsIncrement = 1;
            this.txt_CapMaxDist.BackColor = System.Drawing.Color.MintCream;
            this.txt_CapMaxDist.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_CapMaxDist.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CapMaxDist.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_CapMaxDist.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CapMaxDist.ForeColor = System.Drawing.Color.Black;
            this.txt_CapMaxDist.Increment = 0.2;
            this.txt_CapMaxDist.Location = new System.Drawing.Point(118, 25);
            this.txt_CapMaxDist.MaxValue = 9999;
            this.txt_CapMaxDist.MinValue = 50;
            this.txt_CapMaxDist.Name = "txt_CapMaxDist";
            this.txt_CapMaxDist.NumericValue = 150;
            this.txt_CapMaxDist.NumericValueInteger = 150;
            this.txt_CapMaxDist.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_CapMaxDist.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_CapMaxDist.RoundingStep = 0;
            this.txt_CapMaxDist.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_CapMaxDist.Size = new System.Drawing.Size(51, 15);
            this.txt_CapMaxDist.SuppressZeros = true;
            this.txt_CapMaxDist.TabIndex = 15;
            this.txt_CapMaxDist.Text = "150";
            this.txt_CapMaxDist.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MinDist
            // 
            this.Label_MinDist.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MinDist.Location = new System.Drawing.Point(10, 47);
            this.Label_MinDist.Name = "Label_MinDist";
            this.Label_MinDist.Size = new System.Drawing.Size(108, 13);
            this.Label_MinDist.TabIndex = 163;
            this.Label_MinDist.Text = "Min dist  ( mm )";
            this.Label_MinDist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_CapMinDist
            // 
            this.txt_CapMinDist.ArrowsIncrement = 1;
            this.txt_CapMinDist.BackColor = System.Drawing.Color.MintCream;
            this.txt_CapMinDist.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_CapMinDist.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CapMinDist.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_CapMinDist.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CapMinDist.ForeColor = System.Drawing.Color.Black;
            this.txt_CapMinDist.Increment = 0.2;
            this.txt_CapMinDist.Location = new System.Drawing.Point(118, 46);
            this.txt_CapMinDist.MaxValue = 5000;
            this.txt_CapMinDist.MinValue = 0;
            this.txt_CapMinDist.Name = "txt_CapMinDist";
            this.txt_CapMinDist.NumericValue = 30;
            this.txt_CapMinDist.NumericValueInteger = 30;
            this.txt_CapMinDist.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_CapMinDist.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_CapMinDist.RoundingStep = 0;
            this.txt_CapMinDist.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_CapMinDist.Size = new System.Drawing.Size(51, 15);
            this.txt_CapMinDist.SuppressZeros = true;
            this.txt_CapMinDist.TabIndex = 16;
            this.txt_CapMinDist.Text = "30";
            this.txt_CapMinDist.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_CapArea
            // 
            this.txt_CapArea.ArrowsIncrement = 1;
            this.txt_CapArea.BackColor = System.Drawing.Color.MintCream;
            this.txt_CapArea.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_CapArea.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CapArea.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_CapArea.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CapArea.ForeColor = System.Drawing.Color.Black;
            this.txt_CapArea.Increment = 0.2;
            this.txt_CapArea.Location = new System.Drawing.Point(118, 67);
            this.txt_CapArea.MaxValue = 9999;
            this.txt_CapArea.MinValue = 0;
            this.txt_CapArea.Name = "txt_CapArea";
            this.txt_CapArea.NumericValue = 10;
            this.txt_CapArea.NumericValueInteger = 10;
            this.txt_CapArea.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_CapArea.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_CapArea.RoundingStep = 0;
            this.txt_CapArea.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_CapArea.Size = new System.Drawing.Size(51, 15);
            this.txt_CapArea.SuppressZeros = true;
            this.txt_CapArea.TabIndex = 12;
            this.txt_CapArea.Text = "10";
            this.txt_CapArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_Area
            // 
            this.Label_Area.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Area.Location = new System.Drawing.Point(9, 68);
            this.Label_Area.Name = "Label_Area";
            this.Label_Area.Size = new System.Drawing.Size(108, 13);
            this.Label_Area.TabIndex = 168;
            this.Label_Area.Text = "Area      ( cmq )";
            this.Label_Area.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_MaxDist
            // 
            this.Label_MaxDist.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxDist.Location = new System.Drawing.Point(10, 26);
            this.Label_MaxDist.Name = "Label_MaxDist";
            this.Label_MaxDist.Size = new System.Drawing.Size(108, 13);
            this.Label_MaxDist.TabIndex = 161;
            this.Label_MaxDist.Text = "Max dist ( mm )";
            this.Label_MaxDist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox_PinProps
            // 
            this.GroupBox_PinProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_PinProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_PinProps.Controls.Add(this.Label_ResponseSpeed);
            this.GroupBox_PinProps.Controls.Add(this.txt_Slot);
            this.GroupBox_PinProps.Controls.Add(this.cmb_PinType);
            this.GroupBox_PinProps.Controls.Add(this.Label_PinType);
            this.GroupBox_PinProps.Controls.Add(this.Label_MaxValue);
            this.GroupBox_PinProps.Controls.Add(this.Label_Slot);
            this.GroupBox_PinProps.Controls.Add(this.txt_MaxValue);
            this.GroupBox_PinProps.Controls.Add(this.txt_ResponseSpeed);
            this.GroupBox_PinProps.Controls.Add(this.txt_MinValue);
            this.GroupBox_PinProps.Controls.Add(this.Label_MinValue);
            this.GroupBox_PinProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_PinProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_PinProps.Location = new System.Drawing.Point(439, 188);
            this.GroupBox_PinProps.Name = "GroupBox_PinProps";
            this.GroupBox_PinProps.Size = new System.Drawing.Size(180, 136);
            this.GroupBox_PinProps.TabIndex = 188;
            this.GroupBox_PinProps.TabStop = false;
            this.GroupBox_PinProps.Text = "Pin properties";
            this.GroupBox_PinProps.Visible = false;
            // 
            // Label_ResponseSpeed
            // 
            this.Label_ResponseSpeed.BorderColor = System.Drawing.Color.Gray;
            designerRectTracker1.IsActive = false;
            designerRectTracker1.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker1.TrackerRectangle")));
            this.Label_ResponseSpeed.CenterPtTracker = designerRectTracker1;
            this.Label_ResponseSpeed.CheckButton = true;
            cBlendItems1.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))))};
            cBlendItems1.iPoint = new float[] {
        0F,
        0.5017921F,
        1F};
            this.Label_ResponseSpeed.ColorFillBlend = cBlendItems1;
            cBlendItems2.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems2.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.Label_ResponseSpeed.ColorFillBlendChecked = cBlendItems2;
            this.Label_ResponseSpeed.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.Label_ResponseSpeed.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.Label_ResponseSpeed.Corners.All = ((short)(3));
            this.Label_ResponseSpeed.Corners.LowerLeft = ((short)(3));
            this.Label_ResponseSpeed.Corners.LowerRight = ((short)(3));
            this.Label_ResponseSpeed.Corners.UpperLeft = ((short)(3));
            this.Label_ResponseSpeed.Corners.UpperRight = ((short)(3));
            this.Label_ResponseSpeed.DimFactorGray = -10;
            this.Label_ResponseSpeed.DimFactorOver = 30;
            this.Label_ResponseSpeed.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.Label_ResponseSpeed.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.Label_ResponseSpeed.FocalPoints.CenterPtX = 0F;
            this.Label_ResponseSpeed.FocalPoints.CenterPtY = 0.4074074F;
            this.Label_ResponseSpeed.FocalPoints.FocusPtX = 0F;
            this.Label_ResponseSpeed.FocalPoints.FocusPtY = 0F;
            this.Label_ResponseSpeed.FocalPointsChecked.CenterPtX = 0.5925926F;
            this.Label_ResponseSpeed.FocalPointsChecked.CenterPtY = 0.2352941F;
            this.Label_ResponseSpeed.FocalPointsChecked.FocusPtX = 0F;
            this.Label_ResponseSpeed.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker2.IsActive = false;
            designerRectTracker2.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker2.TrackerRectangle")));
            this.Label_ResponseSpeed.FocusPtTracker = designerRectTracker2;
            this.Label_ResponseSpeed.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ResponseSpeed.ForeColorChecked = System.Drawing.Color.Black;
            this.Label_ResponseSpeed.Image = null;
            this.Label_ResponseSpeed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Label_ResponseSpeed.ImageIndex = 0;
            this.Label_ResponseSpeed.ImageSize = new System.Drawing.Size(16, 16);
            this.Label_ResponseSpeed.Location = new System.Drawing.Point(7, 112);
            this.Label_ResponseSpeed.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Label_ResponseSpeed.Name = "Label_ResponseSpeed";
            this.Label_ResponseSpeed.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.Label_ResponseSpeed.SideImage = null;
            this.Label_ResponseSpeed.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_ResponseSpeed.SideImageSize = new System.Drawing.Size(32, 32);
            this.Label_ResponseSpeed.Size = new System.Drawing.Size(108, 15);
            this.Label_ResponseSpeed.TabIndex = 221;
            this.Label_ResponseSpeed.Text = "Response speed";
            this.Label_ResponseSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_ResponseSpeed.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.Label_ResponseSpeed.TextMargin = new System.Windows.Forms.Padding(0);
            this.Label_ResponseSpeed.TextShadow = System.Drawing.Color.Transparent;
            this.Label_ResponseSpeed.TextShadowChecked = System.Drawing.Color.Empty;
            // 
            // txt_Slot
            // 
            this.txt_Slot.ArrowsIncrement = 1;
            this.txt_Slot.BackColor = System.Drawing.Color.MintCream;
            this.txt_Slot.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_Slot.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Slot.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Slot.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Slot.ForeColor = System.Drawing.Color.Black;
            this.txt_Slot.Increment = 0.2;
            this.txt_Slot.Location = new System.Drawing.Point(118, 49);
            this.txt_Slot.MaxValue = 999;
            this.txt_Slot.MinValue = 0;
            this.txt_Slot.Name = "txt_Slot";
            this.txt_Slot.NumericValue = 0;
            this.txt_Slot.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_Slot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_Slot.RoundingStep = 0;
            this.txt_Slot.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_Slot.Size = new System.Drawing.Size(51, 15);
            this.txt_Slot.SuppressZeros = true;
            this.txt_Slot.TabIndex = 11;
            this.txt_Slot.Text = "0";
            this.txt_Slot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmb_PinType
            // 
            this.cmb_PinType.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_PinType.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_PinType.BackColor = System.Drawing.Color.MintCream;
            this.cmb_PinType.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_PinType.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_PinType.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_PinType.BorderSize = 1;
            this.cmb_PinType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_PinType.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_PinType.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_PinType.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_PinType.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_PinType.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_PinType.DropDownHeight = 500;
            this.cmb_PinType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_PinType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_PinType.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_PinType.ForeColor = System.Drawing.Color.Black;
            this.cmb_PinType.IntegralHeight = false;
            this.cmb_PinType.ItemHeight = 12;
            this.cmb_PinType.Location = new System.Drawing.Point(70, 22);
            this.cmb_PinType.Name = "cmb_PinType";
            this.cmb_PinType.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_PinType.Size = new System.Drawing.Size(99, 18);
            this.cmb_PinType.TabIndex = 10;
            this.cmb_PinType.TabStop = false;
            this.cmb_PinType.TextPosition = 1;
            this.cmb_PinType.DropDownClosed += new System.EventHandler(this.cmb_PinType_DropDownClosed);
            // 
            // Label_PinType
            // 
            this.Label_PinType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PinType.Location = new System.Drawing.Point(10, 24);
            this.Label_PinType.Name = "Label_PinType";
            this.Label_PinType.Size = new System.Drawing.Size(58, 13);
            this.Label_PinType.TabIndex = 172;
            this.Label_PinType.Text = "Pin type";
            this.Label_PinType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_MaxValue
            // 
            this.Label_MaxValue.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxValue.Location = new System.Drawing.Point(10, 71);
            this.Label_MaxValue.Name = "Label_MaxValue";
            this.Label_MaxValue.Size = new System.Drawing.Size(102, 13);
            this.Label_MaxValue.TabIndex = 162;
            this.Label_MaxValue.Text = "Max value";
            this.Label_MaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_Slot
            // 
            this.Label_Slot.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Slot.Location = new System.Drawing.Point(10, 50);
            this.Label_Slot.Name = "Label_Slot";
            this.Label_Slot.Size = new System.Drawing.Size(108, 13);
            this.Label_Slot.TabIndex = 174;
            this.Label_Slot.Text = "Slot";
            this.Label_Slot.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_MaxValue
            // 
            this.txt_MaxValue.ArrowsIncrement = 1;
            this.txt_MaxValue.BackColor = System.Drawing.Color.MintCream;
            this.txt_MaxValue.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MaxValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaxValue.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MaxValue.Decimals = 3;
            this.txt_MaxValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaxValue.ForeColor = System.Drawing.Color.Black;
            this.txt_MaxValue.Increment = 0.2;
            this.txt_MaxValue.Location = new System.Drawing.Point(113, 70);
            this.txt_MaxValue.MaxValue = 9999999;
            this.txt_MaxValue.MinValue = -999999;
            this.txt_MaxValue.Name = "txt_MaxValue";
            this.txt_MaxValue.NumericValue = 1000;
            this.txt_MaxValue.NumericValueInteger = 1000;
            this.txt_MaxValue.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MaxValue.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MaxValue.RoundingStep = 0;
            this.txt_MaxValue.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MaxValue.Size = new System.Drawing.Size(56, 15);
            this.txt_MaxValue.SuppressZeros = true;
            this.txt_MaxValue.TabIndex = 12;
            this.txt_MaxValue.Text = "1000";
            this.txt_MaxValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ResponseSpeed
            // 
            this.txt_ResponseSpeed.ArrowsIncrement = 1;
            this.txt_ResponseSpeed.BackColor = System.Drawing.Color.MintCream;
            this.txt_ResponseSpeed.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ResponseSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ResponseSpeed.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ResponseSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ResponseSpeed.ForeColor = System.Drawing.Color.Black;
            this.txt_ResponseSpeed.Increment = 0.2;
            this.txt_ResponseSpeed.Location = new System.Drawing.Point(118, 112);
            this.txt_ResponseSpeed.MaxValue = 100;
            this.txt_ResponseSpeed.MinValue = 1;
            this.txt_ResponseSpeed.Name = "txt_ResponseSpeed";
            this.txt_ResponseSpeed.NumericValue = 30;
            this.txt_ResponseSpeed.NumericValueInteger = 30;
            this.txt_ResponseSpeed.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ResponseSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ResponseSpeed.RoundingStep = 0;
            this.txt_ResponseSpeed.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ResponseSpeed.Size = new System.Drawing.Size(51, 15);
            this.txt_ResponseSpeed.SuppressZeros = true;
            this.txt_ResponseSpeed.TabIndex = 14;
            this.txt_ResponseSpeed.Text = "30";
            this.txt_ResponseSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_MinValue
            // 
            this.txt_MinValue.ArrowsIncrement = 1;
            this.txt_MinValue.BackColor = System.Drawing.Color.MintCream;
            this.txt_MinValue.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MinValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MinValue.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MinValue.Decimals = 3;
            this.txt_MinValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinValue.ForeColor = System.Drawing.Color.Black;
            this.txt_MinValue.Increment = 0.2;
            this.txt_MinValue.Location = new System.Drawing.Point(113, 91);
            this.txt_MinValue.MaxValue = 9999999;
            this.txt_MinValue.MinValue = -999999;
            this.txt_MinValue.Name = "txt_MinValue";
            this.txt_MinValue.NumericValue = 0;
            this.txt_MinValue.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MinValue.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MinValue.RoundingStep = 0;
            this.txt_MinValue.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MinValue.Size = new System.Drawing.Size(56, 15);
            this.txt_MinValue.SuppressZeros = true;
            this.txt_MinValue.TabIndex = 13;
            this.txt_MinValue.Text = "0";
            this.txt_MinValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MinValue
            // 
            this.Label_MinValue.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MinValue.Location = new System.Drawing.Point(10, 92);
            this.Label_MinValue.Name = "Label_MinValue";
            this.Label_MinValue.Size = new System.Drawing.Size(102, 13);
            this.Label_MinValue.TabIndex = 166;
            this.Label_MinValue.Text = "Min value";
            this.Label_MinValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox_MasterProps
            // 
            this.GroupBox_MasterProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_MasterProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_MasterProps.Controls.Add(this.btn_MasterName);
            this.GroupBox_MasterProps.Controls.Add(this.cmb_MasterNames);
            this.GroupBox_MasterProps.Controls.Add(this.chk_FastDataExchange);
            this.GroupBox_MasterProps.Controls.Add(this.lbl_ErrorRate);
            this.GroupBox_MasterProps.Controls.Add(this.Label_ErrorRate);
            this.GroupBox_MasterProps.Controls.Add(this.lbl_RepeatFrequency);
            this.GroupBox_MasterProps.Controls.Add(this.Label_RepFreq);
            this.GroupBox_MasterProps.Controls.Add(this.txt_CommSpeed);
            this.GroupBox_MasterProps.Controls.Add(this.Label_CommSpeed);
            this.GroupBox_MasterProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_MasterProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_MasterProps.Location = new System.Drawing.Point(439, 53);
            this.GroupBox_MasterProps.Name = "GroupBox_MasterProps";
            this.GroupBox_MasterProps.Size = new System.Drawing.Size(180, 130);
            this.GroupBox_MasterProps.TabIndex = 187;
            this.GroupBox_MasterProps.TabStop = false;
            this.GroupBox_MasterProps.Text = "Master properties";
            // 
            // btn_MasterName
            // 
            this.btn_MasterName.BorderColor = System.Drawing.Color.DarkGray;
            designerRectTracker3.IsActive = false;
            designerRectTracker3.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker3.TrackerRectangle")));
            this.btn_MasterName.CenterPtTracker = designerRectTracker3;
            cBlendItems3.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(240)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(164)))), ((int)(((byte)(133)))))};
            cBlendItems3.iPoint = new float[] {
        0F,
        0.5017921F,
        1F};
            this.btn_MasterName.ColorFillBlend = cBlendItems3;
            cBlendItems4.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems4.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_MasterName.ColorFillBlendChecked = cBlendItems4;
            this.btn_MasterName.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_MasterName.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_MasterName.Corners.All = ((short)(2));
            this.btn_MasterName.Corners.LowerLeft = ((short)(2));
            this.btn_MasterName.Corners.LowerRight = ((short)(2));
            this.btn_MasterName.Corners.UpperLeft = ((short)(2));
            this.btn_MasterName.Corners.UpperRight = ((short)(2));
            this.btn_MasterName.DimFactorGray = -10;
            this.btn_MasterName.DimFactorOver = 40;
            this.btn_MasterName.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_MasterName.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_MasterName.FocalPoints.CenterPtX = 0.3863636F;
            this.btn_MasterName.FocalPoints.CenterPtY = 0.2F;
            this.btn_MasterName.FocalPoints.FocusPtX = 0F;
            this.btn_MasterName.FocalPoints.FocusPtY = 0F;
            this.btn_MasterName.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_MasterName.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_MasterName.FocalPointsChecked.FocusPtX = 0F;
            this.btn_MasterName.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker4.IsActive = false;
            designerRectTracker4.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker4.TrackerRectangle")));
            this.btn_MasterName.FocusPtTracker = designerRectTracker4;
            this.btn_MasterName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MasterName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btn_MasterName.Image = null;
            this.btn_MasterName.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_MasterName.ImageIndex = 0;
            this.btn_MasterName.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_MasterName.Location = new System.Drawing.Point(13, 23);
            this.btn_MasterName.Name = "btn_MasterName";
            this.btn_MasterName.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_MasterName.SideImage = null;
            this.btn_MasterName.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_MasterName.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_MasterName.Size = new System.Drawing.Size(44, 15);
            this.btn_MasterName.TabIndex = 180;
            this.btn_MasterName.Text = "Name";
            this.btn_MasterName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_MasterName.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_MasterName.TextMargin = new System.Windows.Forms.Padding(0);
            this.btn_MasterName.TextShadow = System.Drawing.Color.Transparent;
            this.btn_MasterName.ClickButtonArea += new CustomControlsLib.MyButton.ClickButtonAreaEventHandler(this.btn_MasterName_ClickButtonArea);
            // 
            // cmb_MasterNames
            // 
            this.cmb_MasterNames.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_MasterNames.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_MasterNames.BackColor = System.Drawing.Color.MintCream;
            this.cmb_MasterNames.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_MasterNames.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_MasterNames.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_MasterNames.BorderSize = 1;
            this.cmb_MasterNames.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_MasterNames.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_MasterNames.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_MasterNames.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_MasterNames.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_MasterNames.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_MasterNames.DropDownHeight = 500;
            this.cmb_MasterNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_MasterNames.DropDownWidth = 122;
            this.cmb_MasterNames.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_MasterNames.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_MasterNames.ForeColor = System.Drawing.Color.Black;
            this.cmb_MasterNames.IntegralHeight = false;
            this.cmb_MasterNames.ItemHeight = 10;
            this.cmb_MasterNames.Location = new System.Drawing.Point(60, 22);
            this.cmb_MasterNames.MaxDropDownItems = 99;
            this.cmb_MasterNames.Name = "cmb_MasterNames";
            this.cmb_MasterNames.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_MasterNames.Size = new System.Drawing.Size(109, 16);
            this.cmb_MasterNames.TabIndex = 179;
            this.cmb_MasterNames.TabStop = false;
            this.cmb_MasterNames.TextPosition = 1;
            this.cmb_MasterNames.SelectionChangeCommitted += new System.EventHandler(this.cmb_MasterNames_SelectionChangeCommitted);
            this.cmb_MasterNames.DropDownClosed += new System.EventHandler(this.cmb_MasterNames_DropDownClosed);
            this.cmb_MasterNames.DropDown += new System.EventHandler(this.cmb_MasterNames_DropDown);
            // 
            // chk_FastDataExchange
            // 
            this.chk_FastDataExchange.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_FastDataExchange.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_FastDataExchange.Location = new System.Drawing.Point(10, 108);
            this.chk_FastDataExchange.Name = "chk_FastDataExchange";
            this.chk_FastDataExchange.Size = new System.Drawing.Size(157, 17);
            this.chk_FastDataExchange.TabIndex = 5;
            this.chk_FastDataExchange.Text = "Fast data exchange     ";
            this.chk_FastDataExchange.UseVisualStyleBackColor = true;
            // 
            // lbl_ErrorRate
            // 
            this.lbl_ErrorRate.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ErrorRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_ErrorRate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ErrorRate.Location = new System.Drawing.Point(118, 65);
            this.lbl_ErrorRate.Name = "lbl_ErrorRate";
            this.lbl_ErrorRate.Size = new System.Drawing.Size(51, 17);
            this.lbl_ErrorRate.TabIndex = 177;
            this.lbl_ErrorRate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Label_ErrorRate
            // 
            this.Label_ErrorRate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ErrorRate.Location = new System.Drawing.Point(10, 66);
            this.Label_ErrorRate.Name = "Label_ErrorRate";
            this.Label_ErrorRate.Size = new System.Drawing.Size(102, 13);
            this.Label_ErrorRate.TabIndex = 176;
            this.Label_ErrorRate.Text = "Error rate (%)";
            this.Label_ErrorRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_RepeatFrequency
            // 
            this.lbl_RepeatFrequency.BackColor = System.Drawing.Color.Transparent;
            this.lbl_RepeatFrequency.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_RepeatFrequency.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RepeatFrequency.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_RepeatFrequency.Location = new System.Drawing.Point(118, 46);
            this.lbl_RepeatFrequency.Name = "lbl_RepeatFrequency";
            this.lbl_RepeatFrequency.Size = new System.Drawing.Size(51, 17);
            this.lbl_RepeatFrequency.TabIndex = 175;
            this.lbl_RepeatFrequency.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Label_RepFreq
            // 
            this.Label_RepFreq.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_RepFreq.Location = new System.Drawing.Point(10, 45);
            this.Label_RepFreq.Name = "Label_RepFreq";
            this.Label_RepFreq.Size = new System.Drawing.Size(102, 13);
            this.Label_RepFreq.TabIndex = 174;
            this.Label_RepFreq.Text = "Rep freq. (fps)";
            this.Label_RepFreq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_CommSpeed
            // 
            this.txt_CommSpeed.ArrowsIncrement = 1;
            this.txt_CommSpeed.BackColor = System.Drawing.Color.MintCream;
            this.txt_CommSpeed.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_CommSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CommSpeed.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_CommSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CommSpeed.ForeColor = System.Drawing.Color.Black;
            this.txt_CommSpeed.Increment = 0.2;
            this.txt_CommSpeed.Location = new System.Drawing.Point(129, 87);
            this.txt_CommSpeed.MaxValue = 12;
            this.txt_CommSpeed.MinValue = 1;
            this.txt_CommSpeed.Name = "txt_CommSpeed";
            this.txt_CommSpeed.NumericValue = 7;
            this.txt_CommSpeed.NumericValueInteger = 7;
            this.txt_CommSpeed.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_CommSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_CommSpeed.RoundingStep = 0;
            this.txt_CommSpeed.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_CommSpeed.Size = new System.Drawing.Size(40, 15);
            this.txt_CommSpeed.SuppressZeros = true;
            this.txt_CommSpeed.TabIndex = 2;
            this.txt_CommSpeed.Text = "7";
            this.txt_CommSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_CommSpeed
            // 
            this.Label_CommSpeed.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CommSpeed.Location = new System.Drawing.Point(10, 88);
            this.Label_CommSpeed.Name = "Label_CommSpeed";
            this.Label_CommSpeed.Size = new System.Drawing.Size(112, 13);
            this.Label_CommSpeed.TabIndex = 162;
            this.Label_CommSpeed.Text = "Comm. speed";
            this.Label_CommSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Timer_1Hz
            // 
            this.Timer_1Hz.Tick += new System.EventHandler(this.Timer_1Hz_Tick);
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripSeparator12,
            this.ToolStripButton_Recognize,
            this.ToolStripSeparator11,
            this.ToolStripButton_Validate,
            this.ToolStripSeparator3,
            this.ToolStripButton_BeepOnErrors,
            this.ToolStripSeparator8,
            this.ToolStripButton_Lock,
            this.toolStripSeparator5,
            this.ToolStripButton_Disconnect});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 24);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ToolStrip1.Size = new System.Drawing.Size(624, 25);
            this.ToolStrip1.TabIndex = 221;
            this.ToolStrip1.Text = "ToolStrip1";
            this.ToolStrip1.Paint += new System.Windows.Forms.PaintEventHandler(this.ToolStrip1_Paint);
            // 
            // ToolStripSeparator12
            // 
            this.ToolStripSeparator12.Name = "ToolStripSeparator12";
            this.ToolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripButton_Recognize
            // 
            this.ToolStripButton_Recognize.CheckOnClick = true;
            this.ToolStripButton_Recognize.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton_Recognize.Image")));
            this.ToolStripButton_Recognize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton_Recognize.Name = "ToolStripButton_Recognize";
            this.ToolStripButton_Recognize.Size = new System.Drawing.Size(81, 22);
            this.ToolStripButton_Recognize.Text = "Recognize";
            this.ToolStripButton_Recognize.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ToolStripButton_Recognize.Click += new System.EventHandler(this.ToolStripButton_Recognize_Click);
            // 
            // ToolStripSeparator11
            // 
            this.ToolStripSeparator11.Name = "ToolStripSeparator11";
            this.ToolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripButton_Validate
            // 
            this.ToolStripButton_Validate.CheckOnClick = true;
            this.ToolStripButton_Validate.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton_Validate.Image")));
            this.ToolStripButton_Validate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton_Validate.Name = "ToolStripButton_Validate";
            this.ToolStripButton_Validate.Size = new System.Drawing.Size(68, 22);
            this.ToolStripButton_Validate.Text = "Validate";
            this.ToolStripButton_Validate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ToolStripButton_Validate.Click += new System.EventHandler(this.ToolStripButton_Validate_Click);
            // 
            // ToolStripSeparator3
            // 
            this.ToolStripSeparator3.Name = "ToolStripSeparator3";
            this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripButton_BeepOnErrors
            // 
            this.ToolStripButton_BeepOnErrors.CheckOnClick = true;
            this.ToolStripButton_BeepOnErrors.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton_BeepOnErrors.Image")));
            this.ToolStripButton_BeepOnErrors.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton_BeepOnErrors.Name = "ToolStripButton_BeepOnErrors";
            this.ToolStripButton_BeepOnErrors.Size = new System.Drawing.Size(81, 22);
            this.ToolStripButton_BeepOnErrors.Text = "Error beep";
            this.ToolStripButton_BeepOnErrors.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // ToolStripSeparator8
            // 
            this.ToolStripSeparator8.Name = "ToolStripSeparator8";
            this.ToolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripButton_Lock
            // 
            this.ToolStripButton_Lock.CheckOnClick = true;
            this.ToolStripButton_Lock.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton_Lock.Image")));
            this.ToolStripButton_Lock.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton_Lock.Name = "ToolStripButton_Lock";
            this.ToolStripButton_Lock.Size = new System.Drawing.Size(96, 22);
            this.ToolStripButton_Lock.Text = "Lock Masters";
            this.ToolStripButton_Lock.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ToolStripButton_Lock.Click += new System.EventHandler(this.ToolStripButton_Lock_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripButton_Disconnect
            // 
            this.ToolStripButton_Disconnect.CheckOnClick = true;
            this.ToolStripButton_Disconnect.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton_Disconnect.Image")));
            this.ToolStripButton_Disconnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton_Disconnect.Name = "ToolStripButton_Disconnect";
            this.ToolStripButton_Disconnect.Size = new System.Drawing.Size(125, 22);
            this.ToolStripButton_Disconnect.Text = "Disconnect Master";
            this.ToolStripButton_Disconnect.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ToolStripButton_Disconnect.Click += new System.EventHandler(this.ToolStripButton_Disconnect_Click);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.AutoSize = false;
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_File,
            this.Menu_Tools,
            this.Menu_Language,
            this.Menu_Help,
            this.Menu_About});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(624, 24);
            this.MenuStrip1.TabIndex = 220;
            this.MenuStrip1.Text = "MenuStrip1";
            this.MenuStrip1.Paint += new System.Windows.Forms.PaintEventHandler(this.MenuStrip1_Paint);
            // 
            // Menu_File
            // 
            this.Menu_File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_File_OpenProgramFolder,
            this.Menu_File_EditSlotNames,
            this.Menu_File_EditConfigurations,
            this.toolStripSeparator1,
            this.Menu_File_BackupConfigurations,
            this.Menu_File_LoadConfigurations,
            this.ToolStripSeparator4,
            this.Menu_File_Exit});
            this.Menu_File.Name = "Menu_File";
            this.Menu_File.Size = new System.Drawing.Size(37, 20);
            this.Menu_File.Text = "File";
            // 
            // Menu_File_OpenProgramFolder
            // 
            this.Menu_File_OpenProgramFolder.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_OpenProgramFolder.Image")));
            this.Menu_File_OpenProgramFolder.Name = "Menu_File_OpenProgramFolder";
            this.Menu_File_OpenProgramFolder.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_OpenProgramFolder.Text = "Open program folder";
            this.Menu_File_OpenProgramFolder.Click += new System.EventHandler(this.Menu_File_OpenProgramFolder_Click);
            // 
            // Menu_File_EditSlotNames
            // 
            this.Menu_File_EditSlotNames.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_EditSlotNames.Image")));
            this.Menu_File_EditSlotNames.Name = "Menu_File_EditSlotNames";
            this.Menu_File_EditSlotNames.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_EditSlotNames.Text = "Edit SlotNames";
            this.Menu_File_EditSlotNames.Click += new System.EventHandler(this.Menu_File_EditSlotNames_Click);
            // 
            // Menu_File_EditConfigurations
            // 
            this.Menu_File_EditConfigurations.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_EditConfigurations.Image")));
            this.Menu_File_EditConfigurations.Name = "Menu_File_EditConfigurations";
            this.Menu_File_EditConfigurations.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_EditConfigurations.Text = "Edit configurations";
            this.Menu_File_EditConfigurations.Click += new System.EventHandler(this.Menu_File_EditConfigurations_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(282, 6);
            // 
            // Menu_File_BackupConfigurations
            // 
            this.Menu_File_BackupConfigurations.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_BackupConfigurations.Image")));
            this.Menu_File_BackupConfigurations.Name = "Menu_File_BackupConfigurations";
            this.Menu_File_BackupConfigurations.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_BackupConfigurations.Text = "Save configurations to backup folder";
            this.Menu_File_BackupConfigurations.Click += new System.EventHandler(this.Menu_File_BackupConfigurations_Click);
            // 
            // Menu_File_LoadConfigurations
            // 
            this.Menu_File_LoadConfigurations.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_LoadConfigurations.Image")));
            this.Menu_File_LoadConfigurations.Name = "Menu_File_LoadConfigurations";
            this.Menu_File_LoadConfigurations.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_LoadConfigurations.Text = "Load configurations from backup folder";
            this.Menu_File_LoadConfigurations.Click += new System.EventHandler(this.Menu_File_LoadConfigurations_Click);
            // 
            // ToolStripSeparator4
            // 
            this.ToolStripSeparator4.Name = "ToolStripSeparator4";
            this.ToolStripSeparator4.Size = new System.Drawing.Size(282, 6);
            // 
            // Menu_File_Exit
            // 
            this.Menu_File_Exit.Image = ((System.Drawing.Image)(resources.GetObject("Menu_File_Exit.Image")));
            this.Menu_File_Exit.Name = "Menu_File_Exit";
            this.Menu_File_Exit.Size = new System.Drawing.Size(285, 22);
            this.Menu_File_Exit.Text = "Exit";
            this.Menu_File_Exit.Click += new System.EventHandler(this.Menu_File_Exit_Click);
            // 
            // Menu_Tools
            // 
            this.Menu_Tools.Enabled = false;
            this.Menu_Tools.Name = "Menu_Tools";
            this.Menu_Tools.Size = new System.Drawing.Size(47, 20);
            this.Menu_Tools.Text = "Tools";
            // 
            // Menu_Language
            // 
            this.Menu_Language.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_Language_English,
            this.Menu_Language_Italian,
            this.Menu_Language_Francais,
            this.Menu_Language_Espanol,
            this.Menu_Language_Portoguese,
            this.Menu_Language_Deutsch,
            this.Menu_Language_Japanese,
            this.Menu_Language_Chinese});
            this.Menu_Language.Name = "Menu_Language";
            this.Menu_Language.Size = new System.Drawing.Size(71, 20);
            this.Menu_Language.Text = "Language";
            this.Menu_Language.DropDownOpening += new System.EventHandler(this.Menu_Language_DropDownOpening);
            // 
            // Menu_Language_English
            // 
            this.Menu_Language_English.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_English.Image")));
            this.Menu_Language_English.Name = "Menu_Language_English";
            this.Menu_Language_English.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_English.Text = "English";
            this.Menu_Language_English.Click += new System.EventHandler(this.Menu_Language_English_Click);
            // 
            // Menu_Language_Italian
            // 
            this.Menu_Language_Italian.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Italian.Image")));
            this.Menu_Language_Italian.Name = "Menu_Language_Italian";
            this.Menu_Language_Italian.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Italian.Text = "Italiano";
            this.Menu_Language_Italian.Click += new System.EventHandler(this.Menu_Language_Italian_Click);
            // 
            // Menu_Language_Francais
            // 
            this.Menu_Language_Francais.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Francais.Image")));
            this.Menu_Language_Francais.Name = "Menu_Language_Francais";
            this.Menu_Language_Francais.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Francais.Text = "Francais";
            this.Menu_Language_Francais.Click += new System.EventHandler(this.Menu_Language_Francais_Click);
            // 
            // Menu_Language_Espanol
            // 
            this.Menu_Language_Espanol.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Espanol.Image")));
            this.Menu_Language_Espanol.Name = "Menu_Language_Espanol";
            this.Menu_Language_Espanol.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Espanol.Text = "Espanol";
            this.Menu_Language_Espanol.Click += new System.EventHandler(this.Menu_Language_Espanol_Click);
            // 
            // Menu_Language_Portoguese
            // 
            this.Menu_Language_Portoguese.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Portoguese.Image")));
            this.Menu_Language_Portoguese.Name = "Menu_Language_Portoguese";
            this.Menu_Language_Portoguese.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Portoguese.Text = "Portoguese";
            this.Menu_Language_Portoguese.Click += new System.EventHandler(this.Menu_Language_Portoguese_Click);
            // 
            // Menu_Language_Deutsch
            // 
            this.Menu_Language_Deutsch.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Deutsch.Image")));
            this.Menu_Language_Deutsch.Name = "Menu_Language_Deutsch";
            this.Menu_Language_Deutsch.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Deutsch.Text = "Deutsch";
            this.Menu_Language_Deutsch.Click += new System.EventHandler(this.Menu_Language_Deutsch_Click);
            // 
            // Menu_Language_Japanese
            // 
            this.Menu_Language_Japanese.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Japanese.Image")));
            this.Menu_Language_Japanese.Name = "Menu_Language_Japanese";
            this.Menu_Language_Japanese.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Japanese.Text = "Japanese";
            this.Menu_Language_Japanese.Click += new System.EventHandler(this.Menu_Language_Japanese_Click);
            // 
            // Menu_Language_Chinese
            // 
            this.Menu_Language_Chinese.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Language_Chinese.Image")));
            this.Menu_Language_Chinese.Name = "Menu_Language_Chinese";
            this.Menu_Language_Chinese.Size = new System.Drawing.Size(134, 22);
            this.Menu_Language_Chinese.Text = "Chinese";
            this.Menu_Language_Chinese.Click += new System.EventHandler(this.Menu_Language_Chinese_Click);
            // 
            // Menu_Help
            // 
            this.Menu_Help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_Help_ProgramHelp});
            this.Menu_Help.Name = "Menu_Help";
            this.Menu_Help.Size = new System.Drawing.Size(44, 20);
            this.Menu_Help.Text = "Help";
            // 
            // Menu_Help_ProgramHelp
            // 
            this.Menu_Help_ProgramHelp.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Help_ProgramHelp.Image")));
            this.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp";
            this.Menu_Help_ProgramHelp.Size = new System.Drawing.Size(146, 22);
            this.Menu_Help_ProgramHelp.Text = "Program help";
            this.Menu_Help_ProgramHelp.Click += new System.EventHandler(this.Menu_Help_ProgramHelp_Click);
            // 
            // Menu_About
            // 
            this.Menu_About.Name = "Menu_About";
            this.Menu_About.Size = new System.Drawing.Size(52, 20);
            this.Menu_About.Text = "About";
            this.Menu_About.Click += new System.EventHandler(this.Menu_About_Click);
            // 
            // btn_Calibrate
            // 
            this.btn_Calibrate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Calibrate.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Calibrate.BorderColor = System.Drawing.Color.DarkGray;
            designerRectTracker5.IsActive = false;
            designerRectTracker5.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker5.TrackerRectangle")));
            this.btn_Calibrate.CenterPtTracker = designerRectTracker5;
            cBlendItems5.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))))};
            cBlendItems5.iPoint = new float[] {
        0F,
        1F};
            this.btn_Calibrate.ColorFillBlend = cBlendItems5;
            cBlendItems6.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems6.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_Calibrate.ColorFillBlendChecked = cBlendItems6;
            this.btn_Calibrate.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_Calibrate.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_Calibrate.Corners.All = ((short)(0));
            this.btn_Calibrate.Corners.LowerLeft = ((short)(0));
            this.btn_Calibrate.Corners.LowerRight = ((short)(0));
            this.btn_Calibrate.Corners.UpperLeft = ((short)(0));
            this.btn_Calibrate.Corners.UpperRight = ((short)(0));
            this.btn_Calibrate.DimFactorGray = -10;
            this.btn_Calibrate.DimFactorOver = 30;
            this.btn_Calibrate.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Calibrate.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Calibrate.FocalPoints.CenterPtX = 1F;
            this.btn_Calibrate.FocalPoints.CenterPtY = 0.2962963F;
            this.btn_Calibrate.FocalPoints.FocusPtX = 0F;
            this.btn_Calibrate.FocalPoints.FocusPtY = 0F;
            this.btn_Calibrate.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_Calibrate.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_Calibrate.FocalPointsChecked.FocusPtX = 0F;
            this.btn_Calibrate.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker6.IsActive = false;
            designerRectTracker6.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker6.TrackerRectangle")));
            this.btn_Calibrate.FocusPtTracker = designerRectTracker6;
            this.btn_Calibrate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Calibrate.Image = null;
            this.btn_Calibrate.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Calibrate.ImageIndex = 0;
            this.btn_Calibrate.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_Calibrate.Location = new System.Drawing.Point(510, 0);
            this.btn_Calibrate.Name = "btn_Calibrate";
            this.btn_Calibrate.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_Calibrate.SideImage = null;
            this.btn_Calibrate.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Calibrate.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_Calibrate.Size = new System.Drawing.Size(106, 22);
            this.btn_Calibrate.TabIndex = 222;
            this.btn_Calibrate.TabStop = false;
            this.btn_Calibrate.Text = "Calibrate";
            this.btn_Calibrate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Calibrate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Calibrate.TextMargin = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Calibrate.TextShadow = System.Drawing.Color.Transparent;
            // 
            // txt_MinChange
            // 
            this.txt_MinChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_MinChange.ArrowsIncrement = 1;
            this.txt_MinChange.BackColor = System.Drawing.Color.OldLace;
            this.txt_MinChange.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MinChange.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MinChange.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MinChange.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinChange.ForeColor = System.Drawing.Color.Black;
            this.txt_MinChange.Increment = 0.2;
            this.txt_MinChange.Location = new System.Drawing.Point(578, 3);
            this.txt_MinChange.MaxValue = 100;
            this.txt_MinChange.MinValue = 0;
            this.txt_MinChange.Name = "txt_MinChange";
            this.txt_MinChange.NumericValue = 30;
            this.txt_MinChange.NumericValueInteger = 30;
            this.txt_MinChange.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MinChange.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MinChange.RoundingStep = 0;
            this.txt_MinChange.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MinChange.Size = new System.Drawing.Size(33, 13);
            this.txt_MinChange.SuppressZeros = true;
            this.txt_MinChange.TabIndex = 223;
            this.txt_MinChange.Text = "30";
            this.txt_MinChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Pic_CalibrateTime
            // 
            this.Pic_CalibrateTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pic_CalibrateTime.BackColor = System.Drawing.Color.LightGray;
            this.Pic_CalibrateTime.Location = new System.Drawing.Point(517, 17);
            this.Pic_CalibrateTime.Name = "Pic_CalibrateTime";
            this.Pic_CalibrateTime.Size = new System.Drawing.Size(93, 3);
            this.Pic_CalibrateTime.TabIndex = 224;
            this.Pic_CalibrateTime.TabStop = false;
            // 
            // GroupBox_StepperProps
            // 
            this.GroupBox_StepperProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_StepperProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_StepperProps.Controls.Add(this.chk_LinkedToPrevious);
            this.GroupBox_StepperProps.Controls.Add(this.Label_StepsPerMillim);
            this.GroupBox_StepperProps.Controls.Add(this.txt_StepsPerMillim);
            this.GroupBox_StepperProps.Controls.Add(this.txt_MaxSpeed);
            this.GroupBox_StepperProps.Controls.Add(this.Label_MaxAcc);
            this.GroupBox_StepperProps.Controls.Add(this.txt_MaxAcc);
            this.GroupBox_StepperProps.Controls.Add(this.Label_MaxSpeed);
            this.GroupBox_StepperProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_StepperProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_StepperProps.Location = new System.Drawing.Point(18, 190);
            this.GroupBox_StepperProps.Name = "GroupBox_StepperProps";
            this.GroupBox_StepperProps.Size = new System.Drawing.Size(180, 106);
            this.GroupBox_StepperProps.TabIndex = 225;
            this.GroupBox_StepperProps.TabStop = false;
            this.GroupBox_StepperProps.Text = "Stepper properties";
            this.GroupBox_StepperProps.Visible = false;
            // 
            // chk_LinkedToPrevious
            // 
            this.chk_LinkedToPrevious.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_LinkedToPrevious.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_LinkedToPrevious.Location = new System.Drawing.Point(9, 85);
            this.chk_LinkedToPrevious.Name = "chk_LinkedToPrevious";
            this.chk_LinkedToPrevious.Size = new System.Drawing.Size(156, 17);
            this.chk_LinkedToPrevious.TabIndex = 168;
            this.chk_LinkedToPrevious.Text = "Linked to previous";
            this.chk_LinkedToPrevious.UseVisualStyleBackColor = true;
            // 
            // Label_StepsPerMillim
            // 
            this.Label_StepsPerMillim.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_StepsPerMillim.Location = new System.Drawing.Point(9, 66);
            this.Label_StepsPerMillim.Name = "Label_StepsPerMillim";
            this.Label_StepsPerMillim.Size = new System.Drawing.Size(100, 13);
            this.Label_StepsPerMillim.TabIndex = 167;
            this.Label_StepsPerMillim.Text = "Steps per mm";
            this.Label_StepsPerMillim.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_StepsPerMillim
            // 
            this.txt_StepsPerMillim.ArrowsIncrement = 1;
            this.txt_StepsPerMillim.BackColor = System.Drawing.Color.MintCream;
            this.txt_StepsPerMillim.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_StepsPerMillim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_StepsPerMillim.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_StepsPerMillim.Decimals = 3;
            this.txt_StepsPerMillim.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_StepsPerMillim.ForeColor = System.Drawing.Color.Black;
            this.txt_StepsPerMillim.Increment = 0.002;
            this.txt_StepsPerMillim.Location = new System.Drawing.Point(111, 65);
            this.txt_StepsPerMillim.MaxValue = 99999;
            this.txt_StepsPerMillim.MinValue = 0.01;
            this.txt_StepsPerMillim.Name = "txt_StepsPerMillim";
            this.txt_StepsPerMillim.NumericValue = 400;
            this.txt_StepsPerMillim.NumericValueInteger = 400;
            this.txt_StepsPerMillim.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_StepsPerMillim.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_StepsPerMillim.RoundingStep = 0;
            this.txt_StepsPerMillim.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_StepsPerMillim.Size = new System.Drawing.Size(58, 15);
            this.txt_StepsPerMillim.SuppressZeros = true;
            this.txt_StepsPerMillim.TabIndex = 166;
            this.txt_StepsPerMillim.Text = "400";
            this.txt_StepsPerMillim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_MaxSpeed
            // 
            this.txt_MaxSpeed.ArrowsIncrement = 1;
            this.txt_MaxSpeed.BackColor = System.Drawing.Color.MintCream;
            this.txt_MaxSpeed.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MaxSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaxSpeed.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MaxSpeed.Decimals = 1;
            this.txt_MaxSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaxSpeed.ForeColor = System.Drawing.Color.Black;
            this.txt_MaxSpeed.Increment = 0.2;
            this.txt_MaxSpeed.Location = new System.Drawing.Point(129, 23);
            this.txt_MaxSpeed.MaxValue = 99999;
            this.txt_MaxSpeed.MinValue = 1;
            this.txt_MaxSpeed.Name = "txt_MaxSpeed";
            this.txt_MaxSpeed.NumericValue = 100;
            this.txt_MaxSpeed.NumericValueInteger = 100;
            this.txt_MaxSpeed.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MaxSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MaxSpeed.RoundingStep = 0;
            this.txt_MaxSpeed.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MaxSpeed.Size = new System.Drawing.Size(40, 15);
            this.txt_MaxSpeed.SuppressZeros = true;
            this.txt_MaxSpeed.TabIndex = 17;
            this.txt_MaxSpeed.Text = "100";
            this.txt_MaxSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MaxAcc
            // 
            this.Label_MaxAcc.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxAcc.Location = new System.Drawing.Point(10, 45);
            this.Label_MaxAcc.Name = "Label_MaxAcc";
            this.Label_MaxAcc.Size = new System.Drawing.Size(118, 13);
            this.Label_MaxAcc.TabIndex = 163;
            this.Label_MaxAcc.Text = "Max acc. (mm/s/s)";
            this.Label_MaxAcc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_MaxAcc
            // 
            this.txt_MaxAcc.ArrowsIncrement = 1;
            this.txt_MaxAcc.BackColor = System.Drawing.Color.MintCream;
            this.txt_MaxAcc.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_MaxAcc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaxAcc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MaxAcc.Decimals = 1;
            this.txt_MaxAcc.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaxAcc.ForeColor = System.Drawing.Color.Black;
            this.txt_MaxAcc.Increment = 0.2;
            this.txt_MaxAcc.Location = new System.Drawing.Point(129, 44);
            this.txt_MaxAcc.MaxValue = 9999;
            this.txt_MaxAcc.MinValue = 5;
            this.txt_MaxAcc.Name = "txt_MaxAcc";
            this.txt_MaxAcc.NumericValue = 10;
            this.txt_MaxAcc.NumericValueInteger = 10;
            this.txt_MaxAcc.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_MaxAcc.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_MaxAcc.RoundingStep = 0;
            this.txt_MaxAcc.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_MaxAcc.Size = new System.Drawing.Size(40, 15);
            this.txt_MaxAcc.SuppressZeros = true;
            this.txt_MaxAcc.TabIndex = 18;
            this.txt_MaxAcc.Text = "10";
            this.txt_MaxAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_MaxSpeed
            // 
            this.Label_MaxSpeed.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MaxSpeed.Location = new System.Drawing.Point(10, 24);
            this.Label_MaxSpeed.Name = "Label_MaxSpeed";
            this.Label_MaxSpeed.Size = new System.Drawing.Size(118, 13);
            this.Label_MaxSpeed.TabIndex = 161;
            this.Label_MaxSpeed.Text = "Max sp. (mm/min)";
            this.Label_MaxSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox_PwmFastProps
            // 
            this.GroupBox_PwmFastProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_PwmFastProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_PwmFastProps.Controls.Add(this.chk_DutyCycleFromSlot);
            this.GroupBox_PwmFastProps.Controls.Add(this.chk_FrequencyFromSlot);
            this.GroupBox_PwmFastProps.Controls.Add(this.txt_PwmFastFrequency);
            this.GroupBox_PwmFastProps.Controls.Add(this.Label_PwmFastDutyCycle);
            this.GroupBox_PwmFastProps.Controls.Add(this.txt_PwmFastDutyCycle);
            this.GroupBox_PwmFastProps.Controls.Add(this.Label_PwmFastFrequency);
            this.GroupBox_PwmFastProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_PwmFastProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_PwmFastProps.Location = new System.Drawing.Point(18, 320);
            this.GroupBox_PwmFastProps.Name = "GroupBox_PwmFastProps";
            this.GroupBox_PwmFastProps.Size = new System.Drawing.Size(180, 106);
            this.GroupBox_PwmFastProps.TabIndex = 226;
            this.GroupBox_PwmFastProps.TabStop = false;
            this.GroupBox_PwmFastProps.Text = "Pwm_Fast properties";
            this.GroupBox_PwmFastProps.Visible = false;
            // 
            // chk_DutyCycleFromSlot
            // 
            this.chk_DutyCycleFromSlot.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_DutyCycleFromSlot.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_DutyCycleFromSlot.Location = new System.Drawing.Point(9, 83);
            this.chk_DutyCycleFromSlot.Name = "chk_DutyCycleFromSlot";
            this.chk_DutyCycleFromSlot.Size = new System.Drawing.Size(156, 17);
            this.chk_DutyCycleFromSlot.TabIndex = 167;
            this.chk_DutyCycleFromSlot.Text = "Duty cycle from slot";
            this.chk_DutyCycleFromSlot.UseVisualStyleBackColor = true;
            // 
            // chk_FrequencyFromSlot
            // 
            this.chk_FrequencyFromSlot.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_FrequencyFromSlot.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_FrequencyFromSlot.Location = new System.Drawing.Point(9, 65);
            this.chk_FrequencyFromSlot.Name = "chk_FrequencyFromSlot";
            this.chk_FrequencyFromSlot.Size = new System.Drawing.Size(156, 17);
            this.chk_FrequencyFromSlot.TabIndex = 166;
            this.chk_FrequencyFromSlot.Text = "Frequency from slot";
            this.chk_FrequencyFromSlot.UseVisualStyleBackColor = true;
            // 
            // txt_PwmFastFrequency
            // 
            this.txt_PwmFastFrequency.ArrowsIncrement = 1;
            this.txt_PwmFastFrequency.BackColor = System.Drawing.Color.MintCream;
            this.txt_PwmFastFrequency.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_PwmFastFrequency.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PwmFastFrequency.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_PwmFastFrequency.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PwmFastFrequency.ForeColor = System.Drawing.Color.Black;
            this.txt_PwmFastFrequency.Increment = 0.2;
            this.txt_PwmFastFrequency.Location = new System.Drawing.Point(107, 23);
            this.txt_PwmFastFrequency.MaxValue = 5300000;
            this.txt_PwmFastFrequency.MinValue = 245;
            this.txt_PwmFastFrequency.Name = "txt_PwmFastFrequency";
            this.txt_PwmFastFrequency.NumericValue = 1000;
            this.txt_PwmFastFrequency.NumericValueInteger = 1000;
            this.txt_PwmFastFrequency.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_PwmFastFrequency.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_PwmFastFrequency.RoundingStep = 0;
            this.txt_PwmFastFrequency.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_PwmFastFrequency.Size = new System.Drawing.Size(62, 15);
            this.txt_PwmFastFrequency.SuppressZeros = true;
            this.txt_PwmFastFrequency.TabIndex = 17;
            this.txt_PwmFastFrequency.Text = "1000";
            this.txt_PwmFastFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_PwmFastDutyCycle
            // 
            this.Label_PwmFastDutyCycle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PwmFastDutyCycle.Location = new System.Drawing.Point(10, 45);
            this.Label_PwmFastDutyCycle.Name = "Label_PwmFastDutyCycle";
            this.Label_PwmFastDutyCycle.Size = new System.Drawing.Size(118, 13);
            this.Label_PwmFastDutyCycle.TabIndex = 163;
            this.Label_PwmFastDutyCycle.Text = "Duty cycle 0-1000";
            this.Label_PwmFastDutyCycle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_PwmFastDutyCycle
            // 
            this.txt_PwmFastDutyCycle.ArrowsIncrement = 1;
            this.txt_PwmFastDutyCycle.BackColor = System.Drawing.Color.MintCream;
            this.txt_PwmFastDutyCycle.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_PwmFastDutyCycle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PwmFastDutyCycle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_PwmFastDutyCycle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PwmFastDutyCycle.ForeColor = System.Drawing.Color.Black;
            this.txt_PwmFastDutyCycle.Increment = 0.2;
            this.txt_PwmFastDutyCycle.Location = new System.Drawing.Point(129, 44);
            this.txt_PwmFastDutyCycle.MaxValue = 1000;
            this.txt_PwmFastDutyCycle.MinValue = 0;
            this.txt_PwmFastDutyCycle.Name = "txt_PwmFastDutyCycle";
            this.txt_PwmFastDutyCycle.NumericValue = 500;
            this.txt_PwmFastDutyCycle.NumericValueInteger = 500;
            this.txt_PwmFastDutyCycle.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_PwmFastDutyCycle.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_PwmFastDutyCycle.RoundingStep = 0;
            this.txt_PwmFastDutyCycle.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_PwmFastDutyCycle.Size = new System.Drawing.Size(40, 15);
            this.txt_PwmFastDutyCycle.SuppressZeros = true;
            this.txt_PwmFastDutyCycle.TabIndex = 18;
            this.txt_PwmFastDutyCycle.Text = "500";
            this.txt_PwmFastDutyCycle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_PwmFastFrequency
            // 
            this.Label_PwmFastFrequency.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PwmFastFrequency.Location = new System.Drawing.Point(10, 24);
            this.Label_PwmFastFrequency.Name = "Label_PwmFastFrequency";
            this.Label_PwmFastFrequency.Size = new System.Drawing.Size(94, 13);
            this.Label_PwmFastFrequency.TabIndex = 161;
            this.Label_PwmFastFrequency.Text = "Frequency (Hz)";
            this.Label_PwmFastFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_Reconnect
            // 
            this.btn_Reconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Reconnect.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Reconnect.BorderColor = System.Drawing.Color.DarkGray;
            designerRectTracker7.IsActive = false;
            designerRectTracker7.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker7.TrackerRectangle")));
            this.btn_Reconnect.CenterPtTracker = designerRectTracker7;
            this.btn_Reconnect.CheckButton = true;
            cBlendItems7.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))))};
            cBlendItems7.iPoint = new float[] {
        0F,
        1F};
            this.btn_Reconnect.ColorFillBlend = cBlendItems7;
            cBlendItems8.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(210)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(240)))), ((int)(((byte)(190)))))};
            cBlendItems8.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_Reconnect.ColorFillBlendChecked = cBlendItems8;
            this.btn_Reconnect.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_Reconnect.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_Reconnect.Corners.All = ((short)(0));
            this.btn_Reconnect.Corners.LowerLeft = ((short)(0));
            this.btn_Reconnect.Corners.LowerRight = ((short)(0));
            this.btn_Reconnect.Corners.UpperLeft = ((short)(0));
            this.btn_Reconnect.Corners.UpperRight = ((short)(0));
            this.btn_Reconnect.DimFactorGray = -10;
            this.btn_Reconnect.DimFactorOver = 30;
            this.btn_Reconnect.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Reconnect.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Reconnect.FocalPoints.CenterPtX = 1F;
            this.btn_Reconnect.FocalPoints.CenterPtY = 0.2962963F;
            this.btn_Reconnect.FocalPoints.FocusPtX = 0F;
            this.btn_Reconnect.FocalPoints.FocusPtY = 0F;
            this.btn_Reconnect.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_Reconnect.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_Reconnect.FocalPointsChecked.FocusPtX = 0F;
            this.btn_Reconnect.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker8.IsActive = false;
            designerRectTracker8.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker8.TrackerRectangle")));
            this.btn_Reconnect.FocusPtTracker = designerRectTracker8;
            this.btn_Reconnect.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reconnect.ForeColorChecked = System.Drawing.Color.Black;
            this.btn_Reconnect.Image = null;
            this.btn_Reconnect.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Reconnect.ImageIndex = 0;
            this.btn_Reconnect.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_Reconnect.Location = new System.Drawing.Point(401, 0);
            this.btn_Reconnect.Name = "btn_Reconnect";
            this.btn_Reconnect.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_Reconnect.SideImage = null;
            this.btn_Reconnect.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Reconnect.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_Reconnect.Size = new System.Drawing.Size(107, 22);
            this.btn_Reconnect.TabIndex = 227;
            this.btn_Reconnect.TabStop = false;
            this.btn_Reconnect.Text = "Auto reconnect";
            this.btn_Reconnect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Reconnect.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Reconnect.TextMargin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.btn_Reconnect.TextShadow = System.Drawing.Color.Transparent;
            this.btn_Reconnect.TextShadowChecked = System.Drawing.Color.Transparent;
            this.btn_Reconnect.Visible = false;
            // 
            // GroupBox_Adc24Props
            // 
            this.GroupBox_Adc24Props.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_Adc24Props.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_Adc24Props.Controls.Add(this.cmb_Adc24Sps);
            this.GroupBox_Adc24Props.Controls.Add(this.cmb_Adc24Filter);
            this.GroupBox_Adc24Props.Controls.Add(this.Label_Adc24Filter);
            this.GroupBox_Adc24Props.Controls.Add(this.txt_NumberOfPins);
            this.GroupBox_Adc24Props.Controls.Add(this.Label_SamplesPerSec);
            this.GroupBox_Adc24Props.Controls.Add(this.Label_NumberOfPins);
            this.GroupBox_Adc24Props.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_Adc24Props.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_Adc24Props.Location = new System.Drawing.Point(18, 72);
            this.GroupBox_Adc24Props.Name = "GroupBox_Adc24Props";
            this.GroupBox_Adc24Props.Size = new System.Drawing.Size(180, 95);
            this.GroupBox_Adc24Props.TabIndex = 228;
            this.GroupBox_Adc24Props.TabStop = false;
            this.GroupBox_Adc24Props.Text = "Adc24 properties";
            this.GroupBox_Adc24Props.Visible = false;
            // 
            // cmb_Adc24Sps
            // 
            this.cmb_Adc24Sps.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Sps.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Sps.BackColor = System.Drawing.Color.MintCream;
            this.cmb_Adc24Sps.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_Adc24Sps.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_Adc24Sps.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_Adc24Sps.BorderSize = 1;
            this.cmb_Adc24Sps.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_Adc24Sps.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_Adc24Sps.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_Adc24Sps.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_Adc24Sps.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24Sps.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_Adc24Sps.DropDownHeight = 500;
            this.cmb_Adc24Sps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Adc24Sps.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Adc24Sps.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Adc24Sps.ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24Sps.IntegralHeight = false;
            this.cmb_Adc24Sps.ItemHeight = 12;
            this.cmb_Adc24Sps.Items.AddRange(new object[] {
            "19200",
            "9600",
            "4800",
            "3840",
            "3200",
            "2400",
            "1600",
            "1200",
            "1000",
            "600",
            "500",
            "300",
            "200",
            "120",
            "100",
            "60",
            "50",
            "30",
            "20",
            "12",
            "10"});
            this.cmb_Adc24Sps.Location = new System.Drawing.Point(111, 45);
            this.cmb_Adc24Sps.Name = "cmb_Adc24Sps";
            this.cmb_Adc24Sps.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Sps.Size = new System.Drawing.Size(55, 18);
            this.cmb_Adc24Sps.TabIndex = 172;
            this.cmb_Adc24Sps.TabStop = false;
            this.cmb_Adc24Sps.TextPosition = 1;
            this.cmb_Adc24Sps.SelectionChangeCommitted += new System.EventHandler(this.cmb_Adc24Sps_SelectionChangeCommitted);
            this.cmb_Adc24Sps.DropDownClosed += new System.EventHandler(this.cmb_Adc24Sps_DropDownClosed);
            this.cmb_Adc24Sps.DropDown += new System.EventHandler(this.cmb_Adc24Sps_DropDown);
            // 
            // cmb_Adc24Filter
            // 
            this.cmb_Adc24Filter.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Filter.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Filter.BackColor = System.Drawing.Color.MintCream;
            this.cmb_Adc24Filter.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_Adc24Filter.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_Adc24Filter.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_Adc24Filter.BorderSize = 1;
            this.cmb_Adc24Filter.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_Adc24Filter.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_Adc24Filter.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_Adc24Filter.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_Adc24Filter.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24Filter.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_Adc24Filter.DropDownHeight = 500;
            this.cmb_Adc24Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Adc24Filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Adc24Filter.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Adc24Filter.ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24Filter.IntegralHeight = false;
            this.cmb_Adc24Filter.ItemHeight = 12;
            this.cmb_Adc24Filter.Items.AddRange(new object[] {
            "Max Speed",
            "Fast",
            "Medium",
            "Slow",
            "Post Max",
            "Post Fast",
            "Post Medium",
            "Post Slow"});
            this.cmb_Adc24Filter.Location = new System.Drawing.Point(83, 68);
            this.cmb_Adc24Filter.Name = "cmb_Adc24Filter";
            this.cmb_Adc24Filter.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24Filter.Size = new System.Drawing.Size(83, 18);
            this.cmb_Adc24Filter.TabIndex = 171;
            this.cmb_Adc24Filter.TabStop = false;
            this.cmb_Adc24Filter.TextPosition = 1;
            this.cmb_Adc24Filter.SelectionChangeCommitted += new System.EventHandler(this.cmb_Adc24Filter_SelectionChangeCommitted);
            this.cmb_Adc24Filter.DropDownClosed += new System.EventHandler(this.cmb_Adc24Filter_DropDownClosed);
            this.cmb_Adc24Filter.DropDown += new System.EventHandler(this.cmb_Adc24Filter_DropDown);
            // 
            // Label_Adc24Filter
            // 
            this.Label_Adc24Filter.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Adc24Filter.Location = new System.Drawing.Point(10, 70);
            this.Label_Adc24Filter.Name = "Label_Adc24Filter";
            this.Label_Adc24Filter.Size = new System.Drawing.Size(55, 13);
            this.Label_Adc24Filter.TabIndex = 170;
            this.Label_Adc24Filter.Text = "Filter";
            this.Label_Adc24Filter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_NumberOfPins
            // 
            this.txt_NumberOfPins.ArrowsIncrement = 1;
            this.txt_NumberOfPins.BackColor = System.Drawing.Color.MintCream;
            this.txt_NumberOfPins.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_NumberOfPins.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_NumberOfPins.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_NumberOfPins.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumberOfPins.ForeColor = System.Drawing.Color.Black;
            this.txt_NumberOfPins.Increment = 0.2;
            this.txt_NumberOfPins.Location = new System.Drawing.Point(125, 25);
            this.txt_NumberOfPins.MaxValue = 16;
            this.txt_NumberOfPins.MinValue = 0;
            this.txt_NumberOfPins.Name = "txt_NumberOfPins";
            this.txt_NumberOfPins.NumericValue = 10;
            this.txt_NumberOfPins.NumericValueInteger = 10;
            this.txt_NumberOfPins.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_NumberOfPins.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_NumberOfPins.RoundingStep = 0;
            this.txt_NumberOfPins.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_NumberOfPins.Size = new System.Drawing.Size(40, 15);
            this.txt_NumberOfPins.SuppressZeros = true;
            this.txt_NumberOfPins.TabIndex = 168;
            this.txt_NumberOfPins.Text = "10";
            this.txt_NumberOfPins.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SamplesPerSec
            // 
            this.Label_SamplesPerSec.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SamplesPerSec.Location = new System.Drawing.Point(10, 45);
            this.Label_SamplesPerSec.Name = "Label_SamplesPerSec";
            this.Label_SamplesPerSec.Size = new System.Drawing.Size(88, 13);
            this.Label_SamplesPerSec.TabIndex = 163;
            this.Label_SamplesPerSec.Text = "Samples/sec.";
            this.Label_SamplesPerSec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_NumberOfPins
            // 
            this.Label_NumberOfPins.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NumberOfPins.Location = new System.Drawing.Point(10, 24);
            this.Label_NumberOfPins.Name = "Label_NumberOfPins";
            this.Label_NumberOfPins.Size = new System.Drawing.Size(94, 13);
            this.Label_NumberOfPins.TabIndex = 161;
            this.Label_NumberOfPins.Text = "Number of pins";
            this.Label_NumberOfPins.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chk_Adc24ChBiased
            // 
            this.chk_Adc24ChBiased.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_Adc24ChBiased.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Adc24ChBiased.Location = new System.Drawing.Point(10, 69);
            this.chk_Adc24ChBiased.Name = "chk_Adc24ChBiased";
            this.chk_Adc24ChBiased.Size = new System.Drawing.Size(156, 17);
            this.chk_Adc24ChBiased.TabIndex = 165;
            this.chk_Adc24ChBiased.Text = "Biased to Vmax / 2";
            this.chk_Adc24ChBiased.UseVisualStyleBackColor = true;
            // 
            // GroupBox_Adc24ChProps
            // 
            this.GroupBox_Adc24ChProps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox_Adc24ChProps.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox_Adc24ChProps.Controls.Add(this.cmb_Adc24ChGain);
            this.GroupBox_Adc24ChProps.Controls.Add(this.cmb_Adc24ChType);
            this.GroupBox_Adc24ChProps.Controls.Add(this.chk_Adc24ChBiased);
            this.GroupBox_Adc24ChProps.Controls.Add(this.Label_Adc24ChGain);
            this.GroupBox_Adc24ChProps.Controls.Add(this.Label_Adc24ChType);
            this.GroupBox_Adc24ChProps.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox_Adc24ChProps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GroupBox_Adc24ChProps.Location = new System.Drawing.Point(234, 62);
            this.GroupBox_Adc24ChProps.Name = "GroupBox_Adc24ChProps";
            this.GroupBox_Adc24ChProps.Size = new System.Drawing.Size(180, 92);
            this.GroupBox_Adc24ChProps.TabIndex = 229;
            this.GroupBox_Adc24ChProps.TabStop = false;
            this.GroupBox_Adc24ChProps.Text = "Adc24_channel props";
            this.GroupBox_Adc24ChProps.Visible = false;
            // 
            // cmb_Adc24ChGain
            // 
            this.cmb_Adc24ChGain.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChGain.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChGain.BackColor = System.Drawing.Color.MintCream;
            this.cmb_Adc24ChGain.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_Adc24ChGain.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_Adc24ChGain.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_Adc24ChGain.BorderSize = 1;
            this.cmb_Adc24ChGain.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_Adc24ChGain.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_Adc24ChGain.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_Adc24ChGain.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_Adc24ChGain.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24ChGain.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_Adc24ChGain.DropDownHeight = 500;
            this.cmb_Adc24ChGain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Adc24ChGain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Adc24ChGain.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Adc24ChGain.ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24ChGain.IntegralHeight = false;
            this.cmb_Adc24ChGain.ItemHeight = 12;
            this.cmb_Adc24ChGain.Items.AddRange(new object[] {
            "1",
            "2",
            "4",
            "8",
            "16",
            "32",
            "64",
            "128"});
            this.cmb_Adc24ChGain.Location = new System.Drawing.Point(110, 47);
            this.cmb_Adc24ChGain.Name = "cmb_Adc24ChGain";
            this.cmb_Adc24ChGain.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChGain.Size = new System.Drawing.Size(57, 18);
            this.cmb_Adc24ChGain.TabIndex = 167;
            this.cmb_Adc24ChGain.TabStop = false;
            this.cmb_Adc24ChGain.TextPosition = 1;
            this.cmb_Adc24ChGain.SelectionChangeCommitted += new System.EventHandler(this.cmb_Adc24ChGain_SelectionChangeCommitted);
            this.cmb_Adc24ChGain.DropDownClosed += new System.EventHandler(this.cmb_Adc24ChGain_DropDownClosed);
            this.cmb_Adc24ChGain.DropDown += new System.EventHandler(this.cmb_Adc24ChGain_DropDown);
            // 
            // cmb_Adc24ChType
            // 
            this.cmb_Adc24ChType.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChType.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChType.BackColor = System.Drawing.Color.MintCream;
            this.cmb_Adc24ChType.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_Adc24ChType.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_Adc24ChType.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_Adc24ChType.BorderSize = 1;
            this.cmb_Adc24ChType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_Adc24ChType.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_Adc24ChType.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_Adc24ChType.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_Adc24ChType.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24ChType.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_Adc24ChType.DropDownHeight = 500;
            this.cmb_Adc24ChType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Adc24ChType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Adc24ChType.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Adc24ChType.ForeColor = System.Drawing.Color.Black;
            this.cmb_Adc24ChType.IntegralHeight = false;
            this.cmb_Adc24ChType.ItemHeight = 12;
            this.cmb_Adc24ChType.Items.AddRange(new object[] {
            "Differential",
            "Pseudo Diff",
            "Single ended"});
            this.cmb_Adc24ChType.Location = new System.Drawing.Point(68, 26);
            this.cmb_Adc24ChType.Name = "cmb_Adc24ChType";
            this.cmb_Adc24ChType.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_Adc24ChType.Size = new System.Drawing.Size(99, 18);
            this.cmb_Adc24ChType.TabIndex = 166;
            this.cmb_Adc24ChType.TabStop = false;
            this.cmb_Adc24ChType.TextPosition = 1;
            this.cmb_Adc24ChType.SelectionChangeCommitted += new System.EventHandler(this.cmb_Adc24ChType_SelectionChangeCommitted);
            this.cmb_Adc24ChType.DropDownClosed += new System.EventHandler(this.cmb_Adc24ChType_DropDownClosed);
            this.cmb_Adc24ChType.DropDown += new System.EventHandler(this.cmb_Adc24ChType_DropDown);
            // 
            // Label_Adc24ChGain
            // 
            this.Label_Adc24ChGain.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Adc24ChGain.Location = new System.Drawing.Point(10, 47);
            this.Label_Adc24ChGain.Name = "Label_Adc24ChGain";
            this.Label_Adc24ChGain.Size = new System.Drawing.Size(72, 13);
            this.Label_Adc24ChGain.TabIndex = 163;
            this.Label_Adc24ChGain.Text = "Gain";
            this.Label_Adc24ChGain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label_Adc24ChType
            // 
            this.Label_Adc24ChType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Adc24ChType.Location = new System.Drawing.Point(10, 26);
            this.Label_Adc24ChType.Name = "Label_Adc24ChType";
            this.Label_Adc24ChType.Size = new System.Drawing.Size(72, 13);
            this.Label_Adc24ChType.TabIndex = 161;
            this.Label_Adc24ChType.Text = "Type";
            this.Label_Adc24ChType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Timer_60Hz
            // 
            this.Timer_60Hz.Interval = 10;
            this.Timer_60Hz.Tick += new System.EventHandler(this.Timer_60Hz_Tick);
            // 
            // MyListView1
            // 
            this.MyListView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.MyListView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MyListView1.Location = new System.Drawing.Point(4, 52);
            this.MyListView1.MultiSelect = false;
            this.MyListView1.Name = "MyListView1";
            this.MyListView1.ShowGroups = false;
            this.MyListView1.Size = new System.Drawing.Size(430, 386);
            this.MyListView1.TabIndex = 186;
            this.MyListView1.TabStop = false;
            this.MyListView1.UseCompatibleStateImageBehavior = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.GroupBox_Adc24ChProps);
            this.Controls.Add(this.GroupBox_Adc24Props);
            this.Controls.Add(this.btn_Reconnect);
            this.Controls.Add(this.GroupBox_PwmFastProps);
            this.Controls.Add(this.GroupBox_StepperProps);
            this.Controls.Add(this.txt_MinChange);
            this.Controls.Add(this.Pic_CalibrateTime);
            this.Controls.Add(this.btn_Calibrate);
            this.Controls.Add(this.ToolStrip1);
            this.Controls.Add(this.MenuStrip1);
            this.Controls.Add(this.GroupBox_TouchProps);
            this.Controls.Add(this.GroupBox_FrequencyProps);
            this.Controls.Add(this.GroupBox_ServoPwmProps);
            this.Controls.Add(this.MyListView1);
            this.Controls.Add(this.GroupBox_CapSensorProps);
            this.Controls.Add(this.GroupBox_PinProps);
            this.Controls.Add(this.GroupBox_MasterProps);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "Form1";
            this.Opacity = 0;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Theremino HAL";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.GroupBox_TouchProps.ResumeLayout(false);
            this.GroupBox_TouchProps.PerformLayout();
            this.GroupBox_FrequencyProps.ResumeLayout(false);
            this.GroupBox_FrequencyProps.PerformLayout();
            this.GroupBox_ServoPwmProps.ResumeLayout(false);
            this.GroupBox_ServoPwmProps.PerformLayout();
            this.GroupBox_CapSensorProps.ResumeLayout(false);
            this.GroupBox_CapSensorProps.PerformLayout();
            this.GroupBox_PinProps.ResumeLayout(false);
            this.GroupBox_PinProps.PerformLayout();
            this.GroupBox_MasterProps.ResumeLayout(false);
            this.GroupBox_MasterProps.PerformLayout();
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_CalibrateTime)).EndInit();
            this.GroupBox_StepperProps.ResumeLayout(false);
            this.GroupBox_StepperProps.PerformLayout();
            this.GroupBox_PwmFastProps.ResumeLayout(false);
            this.GroupBox_PwmFastProps.PerformLayout();
            this.GroupBox_Adc24Props.ResumeLayout(false);
            this.GroupBox_Adc24Props.PerformLayout();
            this.GroupBox_Adc24ChProps.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox_TouchProps;
        internal CustomControlsLib.MyTextBox txt_MinVariation;
        internal System.Windows.Forms.Label Label_ProportionalArea;
        internal CustomControlsLib.MyTextBox txt_ProportionalArea;
        internal System.Windows.Forms.Label Label_MinVariation;
        internal System.Windows.Forms.GroupBox GroupBox_FrequencyProps;
        internal System.Windows.Forms.CheckBox chk_ConvertToFrequency;
        internal CustomControlsLib.MyTextBox txt_MaxFreq;
        internal System.Windows.Forms.Label Label_MinFreq;
        internal CustomControlsLib.MyTextBox txt_MinFreq;
        internal System.Windows.Forms.Label Label_MaxFreq;
        internal System.Windows.Forms.GroupBox GroupBox_ServoPwmProps;
        internal System.Windows.Forms.CheckBox chk_LogResponse;
        internal CustomControlsLib.MyTextBox txt_ServoMaxTime;
        internal System.Windows.Forms.Label Label_MinTime;
        internal CustomControlsLib.MyTextBox txt_ServoMinTime;
        internal System.Windows.Forms.Label Label_MaxTime;
        internal CustomControlsLib.ListViewFlickerFree MyListView1;
        internal System.Windows.Forms.GroupBox GroupBox_CapSensorProps;
        internal CustomControlsLib.MyTextBox txt_CapMaxDist;
        internal System.Windows.Forms.Label Label_MinDist;
        internal CustomControlsLib.MyTextBox txt_CapMinDist;
        internal CustomControlsLib.MyTextBox txt_CapArea;
        internal System.Windows.Forms.Label Label_Area;
        internal System.Windows.Forms.Label Label_MaxDist;
        internal System.Windows.Forms.GroupBox GroupBox_PinProps;
        internal CustomControlsLib.MyTextBox txt_Slot;
        internal CustomControlsLib.MyComboBox cmb_PinType;
        internal System.Windows.Forms.Label Label_PinType;
        internal System.Windows.Forms.Label Label_MaxValue;
        internal System.Windows.Forms.Label Label_Slot;
        internal CustomControlsLib.MyTextBox txt_MaxValue;
        internal CustomControlsLib.MyTextBox txt_ResponseSpeed;
        internal CustomControlsLib.MyTextBox txt_MinValue;
        internal System.Windows.Forms.Label Label_MinValue;
        internal System.Windows.Forms.GroupBox GroupBox_MasterProps;
        internal System.Windows.Forms.CheckBox chk_FastDataExchange;
        internal System.Windows.Forms.Label lbl_ErrorRate;
        internal System.Windows.Forms.Label Label_ErrorRate;
        internal System.Windows.Forms.Label lbl_RepeatFrequency;
        internal System.Windows.Forms.Label Label_RepFreq;
        internal CustomControlsLib.MyTextBox txt_CommSpeed;
        internal System.Windows.Forms.Label Label_CommSpeed;
        internal System.Windows.Forms.Timer Timer_10Hz;
        internal System.Windows.Forms.Timer Timer_1Hz;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator12;
        internal System.Windows.Forms.ToolStripButton ToolStripButton_Recognize;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator11;
        internal System.Windows.Forms.ToolStripButton ToolStripButton_Validate;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator3;
        internal System.Windows.Forms.ToolStripButton ToolStripButton_BeepOnErrors;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator8;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_EditConfigurations;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_OpenProgramFolder;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator4;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_Exit;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Tools;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Help;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Help_ProgramHelp;
        internal System.Windows.Forms.ToolStripMenuItem Menu_About;
        internal CustomControlsLib.MyButton btn_Calibrate;
        internal CustomControlsLib.MyTextBox txt_MinChange;
        internal System.Windows.Forms.PictureBox Pic_CalibrateTime;
        internal CustomControlsLib.MyComboBox cmb_MasterNames;
        internal CustomControlsLib.MyButton btn_MasterName;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_English;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Italian;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Francais;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Espanol;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Deutsch;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Japanese;
        internal System.Windows.Forms.CheckBox chk_RemoveErrors;
        internal CustomControlsLib.MyButton Label_ResponseSpeed;
        internal System.Windows.Forms.ToolStripButton ToolStripButton_Lock;
        internal System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        internal System.Windows.Forms.ToolStripButton ToolStripButton_Disconnect;
        internal System.Windows.Forms.GroupBox GroupBox_StepperProps;
        internal CustomControlsLib.MyTextBox txt_MaxSpeed;
        internal System.Windows.Forms.Label Label_MaxAcc;
        internal CustomControlsLib.MyTextBox txt_MaxAcc;
        internal System.Windows.Forms.Label Label_MaxSpeed;
        internal System.Windows.Forms.Label Label_StepsPerMillim;
        internal CustomControlsLib.MyTextBox txt_StepsPerMillim;
        internal System.Windows.Forms.CheckBox chk_LinkedToPrevious;
        internal System.Windows.Forms.GroupBox GroupBox_PwmFastProps;
        internal System.Windows.Forms.CheckBox chk_DutyCycleFromSlot;
        internal System.Windows.Forms.CheckBox chk_FrequencyFromSlot;
        internal CustomControlsLib.MyTextBox txt_PwmFastFrequency;
        internal System.Windows.Forms.Label Label_PwmFastDutyCycle;
        internal CustomControlsLib.MyTextBox txt_PwmFastDutyCycle;
        internal System.Windows.Forms.Label Label_PwmFastFrequency;
        internal CustomControlsLib.MyButton btn_Reconnect;
        internal System.Windows.Forms.GroupBox GroupBox_Adc24Props;
        internal System.Windows.Forms.Label Label_SamplesPerSec;
        internal System.Windows.Forms.Label Label_NumberOfPins;
        internal CustomControlsLib.MyTextBox txt_NumberOfPins;
        internal System.Windows.Forms.CheckBox chk_Adc24ChBiased;
        internal System.Windows.Forms.GroupBox GroupBox_Adc24ChProps;
        internal CustomControlsLib.MyComboBox cmb_Adc24ChType;
        internal System.Windows.Forms.Label Label_Adc24ChGain;
        internal System.Windows.Forms.Label Label_Adc24ChType;
        internal CustomControlsLib.MyComboBox cmb_Adc24ChGain;
        internal CustomControlsLib.MyComboBox cmb_Adc24Filter;
        internal System.Windows.Forms.Label Label_Adc24Filter;
        internal CustomControlsLib.MyComboBox cmb_Adc24Sps;
        internal System.Windows.Forms.Timer Timer_60Hz;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_EditSlotNames;
        internal System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_BackupConfigurations;
        internal System.Windows.Forms.ToolStripMenuItem Menu_File_LoadConfigurations;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Chinese;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Language_Portoguese;

    }
}

