﻿
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Diagnostics;
using System.Drawing.Drawing2D;

namespace Theremino_HAL
{
    public partial class Form1 : Form
    {
        private object EventsLock = new object();

        private void Form1_Load(object sender, System.EventArgs e)
        {
            Timer_10Hz.Tick += Timer_10Hz_Tick;
            MyListView1.MouseUp += MyListView1_MouseUp;
            MyListView1.MouseDown += MyListView1_MouseDown;
            MyListView1.MouseMove += MyListView1_MouseMove;
            MyListView1.MouseDoubleClick += MyListView1_MouseDoubleClick;
            btn_Calibrate.ClickButtonArea += btn_Calibrate_ClickButtonArea;
            // ------------------------------------------------------------- MasterProps_Changed
            txt_CommSpeed.TextChanged += CommSpeed_TextChanged;
            chk_FastDataExchange.CheckedChanged += chk_FastDataExchange_CheckedChanged;
            // ------------------------------------------------------------- PinProps_Changed
            txt_Slot.TextChanged += PinProps_Changed;
            txt_MaxValue.TextChanged += PinProps_Changed;
            txt_MinValue.TextChanged += PinProps_Changed;
            txt_MaxSpeed.TextChanged += PinProps_Changed;
            txt_MaxAcc.TextChanged += PinProps_Changed;
            chk_LinkedToPrevious.CheckedChanged += PinProps_Changed;
            txt_StepsPerMillim.TextChanged += PinProps_Changed;
            txt_PwmFastFrequency.TextChanged += PinProps_Changed;
            txt_PwmFastDutyCycle.TextChanged += PinProps_Changed;
            Label_ResponseSpeed.CheckedChanged += PinProps_Changed;
            txt_ResponseSpeed.TextChanged += PinProps_Changed;
            txt_ServoMaxTime.TextChanged += PinProps_Changed;
            txt_ServoMinTime.TextChanged += PinProps_Changed;
            chk_LogResponse.CheckedChanged += PinProps_Changed;
            chk_RemoveErrors.CheckedChanged += PinProps_Changed;
            txt_CapMaxDist.TextChanged += PinProps_Changed;
            txt_CapMinDist.TextChanged += PinProps_Changed;
            txt_CapArea.TextChanged += PinProps_Changed;
            txt_MinVariation.TextChanged += PinProps_Changed;
            txt_MaxFreq.TextChanged += PinProps_Changed;
            txt_MinFreq.TextChanged += PinProps_Changed;
            txt_ProportionalArea.TextChanged += PinProps_Changed;
            txt_NumberOfPins.TextChanged += PinProps_Changed;
            chk_Adc24ChBiased.CheckedChanged += PinProps_Changed;
            // ------------------------------------------------------------- 
            txt_MinChange.TextChanged += txt_MinChange_TextChanged;
            // ------------------------------------------------------------- must be done after PinProps_Changed
            txt_MinVariation.TextChanged += txt_MinVariation_TextChanged;
            txt_CapArea.TextChanged += txt_CapArea_TextChanged;
            // ------------------------------------------------------------- Mouse Leave
            txt_CommSpeed.MouseLeave += ConfigParams_MouseLeave;
            chk_FastDataExchange.MouseLeave += ConfigParams_MouseLeave;
            txt_Slot.MouseLeave += ConfigParams_MouseLeave;
            txt_MaxValue.MouseLeave += ConfigParams_MouseLeave;
            txt_MinValue.MouseLeave += ConfigParams_MouseLeave;
            txt_MaxSpeed.MouseLeave += ConfigParams_MouseLeave;
            txt_MaxAcc.MouseLeave += ConfigParams_MouseLeave;
            chk_LinkedToPrevious.MouseLeave += ConfigParams_MouseLeave;
            txt_StepsPerMillim.MouseLeave += ConfigParams_MouseLeave;
            txt_PwmFastFrequency.MouseLeave += ConfigParams_MouseLeave;
            txt_PwmFastDutyCycle.MouseLeave += ConfigParams_MouseLeave;
            Label_ResponseSpeed.MouseLeave += ConfigParams_MouseLeave;
            txt_ResponseSpeed.MouseLeave += ConfigParams_MouseLeave;
            txt_CapMaxDist.MouseLeave += ConfigParams_MouseLeave;
            txt_CapMinDist.MouseLeave += ConfigParams_MouseLeave;
            txt_CapArea.MouseLeave += ConfigParams_MouseLeave;
            txt_ServoMaxTime.MouseLeave += ConfigParams_MouseLeave;
            txt_ServoMinTime.MouseLeave += ConfigParams_MouseLeave;
            chk_LogResponse.MouseLeave += ConfigParams_MouseLeave;
            chk_RemoveErrors.MouseLeave += ConfigParams_MouseLeave;
            txt_MaxFreq.MouseLeave += ConfigParams_MouseLeave;
            txt_MinFreq.MouseLeave += ConfigParams_MouseLeave;
            txt_MinVariation.MouseLeave += ConfigParams_MouseLeave;
            txt_ProportionalArea.MouseLeave += ConfigParams_MouseLeave;
            txt_NumberOfPins.MouseLeave += ConfigParams_MouseLeave;
            chk_Adc24ChBiased.MouseLeave += ConfigParams_MouseLeave;
            // -------------------------------------------------------------
            txt_MinChange.MouseLeave += txt_MinChange_MouseLeave;
            // ------------------------------------------------------------- 
            chk_ConvertToFrequency.CheckedChanged += Special_CheckBoxes_CheckedChanged;
            chk_FrequencyFromSlot.CheckedChanged += Special_CheckBoxes_CheckedChanged;
            chk_DutyCycleFromSlot.CheckedChanged += Special_CheckBoxes_CheckedChanged;
            // ------------------------------------------------------------- 
            cmb_PinType.DropDown += cmb_PinType_DropDown;
            cmb_PinType.SelectionChangeCommitted += cmb_PinType_SelectionChangeCommitted;
            MyListView1.SelectedIndexChanged += MyListView1_SelectedIndexChanged;
            //
            SchedulerMaxPrecision();
            Module_SaveLoad.Load_INI();
            Module_SaveLoad.Load_ConfigDatabase();
            Utils_LocaleNames.SetLocales();
            ToolTips_Init();
            ToolStrip1.Renderer = new ToolStripButtonRenderer();
            // ---------------------------------------------------------------- REAL-TIME
            System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Normal;
            System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime;
            // ---------------------------------------------------------------- USB - MASTERS - SLAVES
            ThereminoSystem.TheSystem_InitMasters();
            ThereminoSystem.TheSystem_RecognizeSlaves();
            ThereminoSystem.TheSystem_StartTimers();
            // ---------------------------------------------------------------- Timer1 = 100mS = 10Hz 
            Timer_10Hz.Interval = 100;
            Timer_10Hz.Start();
            // ---------------------------------------------------------------- Timer_1Hz = 1000mS = 1Hz
            Timer_1Hz.Interval = 1000;
            Timer_1Hz.Start();
            // ---------------------------------------------------------------- Timer_60Hz = 16.6mS = 60Hz
            Timer_60Hz.Interval = 10;
            Timer_60Hz.Start();
            // ---------------------------------------------------------------- WINDOW
            if (!Theremino.OperatingSystemIsWindows)
            {
                this.MinimumSize = new Size(650, 500);
            }
            if (!ThereminoSystem.ConfigurationIsValid)
            {
                WindowState = FormWindowState.Normal;
            }
            if (Module_SaveLoad.Form2_VisibleAtStart)
            {
                My.MyProject.Forms.Form2.Show();
            }
            else
            {
                My.MyProject.Forms.Form2.Visible = false;
            }
            Text = Module_SaveLoad.AppTitleAndVersion("Theremino HAL - C#");
            // ----------------------------------------------------------------
            Module_SaveLoad.EventsAreEnabled = true;
            // ----------------------------------------------------------------
            Module_Utils.ListView_SelectLine(MyListView1, 0);
            ShowProps();
            EnableDisableLockedControls();
            My.MyProject.Forms.Form2.RestoreSelectedPins();
            //
            Module_SaveLoad.EventsAreEnabled = false;
            MyListView1.Focus();
            ShowInTaskbar = false;
            ShowInTaskbar = true;
            Module_SaveLoad.EventsAreEnabled = true;

            this.Refresh();
            My.MyProject.Forms.Form2.Refresh();
            this.Opacity = 1;
            My.MyProject.Forms.Form2.Opacity = 1;

            // ----------------------------------------------------------------
            // Button "AutoReconnect" Disabled 
            // (also commented in the "Timer_10Hz_Tick" function)
            // ----------------------------------------------------------------
            btn_Reconnect.Enabled = false;
            // ----------------------------------------------------------------

            InvalidConfigMessage();
        }


        private void Form1_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            CloseAllAndExit();
        }

        private void Form1_LocationChanged(object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;

            Module_SaveLoad.LimitFormPosition(this);
        }

        private void CloseAllAndExit()
        {
            ThereminoSystem.TheSystem_StopTimers();
            ThereminoSystem.TheSystem_SetParkingPositions();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
            Module_SaveLoad.Save_INI();
            SchedulerDefaultPrecision();
        }

        private void InvalidConfigMessage()
        {
            if (ThereminoSystem.ConfigurationIsValid == false)
            {
                if (ThereminoSystem.DuplicateNames)
                {
                    MessageBox.Show(Utils_LocaleNames.Msg_Warning + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Duplicate1 + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Duplicate2,
                                    Utils_LocaleNames.Msg_HalMessage,
                                    MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show(Utils_LocaleNames.Msg_Warning + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Validate2 + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Validate3 + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Validate4 + Constants.vbCrLf + Constants.vbCrLf +
                                    Utils_LocaleNames.Msg_Validate5,
                                    Utils_LocaleNames.Msg_HalMessage,
                                    MessageBoxButtons.OK);
                }
            }
        }

        // =========================================================================
        //  WINDOWS SCHEDULER PRECISION
        // ========================================================================= 
        [System.Runtime.InteropServices.DllImport("winmm.dll")]
        private static extern Int32 timeBeginPeriod(Int32 uPeriod);
        [System.Runtime.InteropServices.DllImport("winmm.dll")]
        private static extern Int32 timeEndPeriod(Int32 uPeriod);
        private void SchedulerMaxPrecision()
        {
            if (Theremino.OperatingSystemIsWindows) timeBeginPeriod(1);
        }
        private void SchedulerDefaultPrecision()
        {
            if (Theremino.OperatingSystemIsWindows) timeEndPeriod(1);
        }


        // ===================================================================================
        //  MenuStrip and ToolStrip accepting the first click
        //  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
        //  then the form is activated before to exec the message
        // ===================================================================================
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 528 && !this.Focused)
            {
                this.Activate();
            }
            base.WndProc(ref m);
        }


        // ===================================================================================
        //   MenuStrip and ToolStrip Gradients
        // ===================================================================================
        private void MenuStrip1_Paint(object sender, PaintEventArgs e)
        {
            Rectangle bounds = new Rectangle(0, 0,
                                             MenuStrip1.Width, MenuStrip1.Height);
            LinearGradientBrush brush = new LinearGradientBrush(bounds,
                                                                Color.FromArgb(240, 240, 240), 
                                                                Color.FromArgb(200, 200, 200), 
                                                                LinearGradientMode.Horizontal);
            e.Graphics.FillRectangle(brush, bounds);
        }
        private void ToolStrip1_Paint(object sender, PaintEventArgs e)
        {
            Rectangle bounds = new Rectangle(0, 0,
                                             ToolStrip1.Width, ToolStrip1.Height);
            LinearGradientBrush brush = new LinearGradientBrush(bounds, 
                                                                Color.White, 
                                                                Color.FromArgb(200, 200, 200),
                                                                LinearGradientMode.Vertical);
            e.Graphics.FillRectangle(brush, bounds);
        }


        // ===================================================================================
        //   ToolStrip PressedButton color
        // ===================================================================================
        class ToolStripButtonRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
            {
                ToolStripButton btn = e.Item as ToolStripButton;
                if (btn != null && btn.CheckOnClick && btn.Checked)
                {
                    Rectangle bounds = new Rectangle(0, 0, e.Item.Width-1, e.Item.Height -1);
                    LinearGradientBrush brush = new LinearGradientBrush(bounds,
                                                                        Color.Gold,
                                                                        Color.FromArgb(250, 250, 250),
                                                                        LinearGradientMode.Vertical);
                    e.Graphics.FillRectangle(brush, bounds);
                    e.Graphics.DrawRectangle(Pens.Orange, bounds);
                }
                else base.OnRenderButtonBackground(e);
            }
        }


        //  =======================================================================================
        //    MENU FILE
        //  =======================================================================================
        private void Menu_File_OpenProgramFolder_Click(object sender, System.EventArgs e)
        {
            Process.Start(Application.StartupPath);
        }
        private void Menu_File_EditSlotNames_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.7;
            String fname = Application.StartupPath + "\\SlotNames.txt";
            if (!Module_SaveLoad.FileExists(fname)) System.IO.File.Create(fname);
            Module_Utils.ProcessStartAndWait(Theremino.PlatformAdjustedFileName(fname, ""));
            this.Opacity = 1;
            ThereminoSystem.TheSystem_ListComponents();
            ListView_SetAllLineColors();
        }
        private void Menu_File_EditConfigurations_Click(object sender, System.EventArgs e)
        {
            this.Opacity = 0.7;
            Module_Utils.ProcessStartAndWait(Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\Theremino_HAL_ConfigDatabase.txt", ""));
            Cmd_Recognize();
            this.Opacity = 1;
        }

        string BackupFolder = Theremino_HAL.My.MyProject.Computer.FileSystem.SpecialDirectories.MyDocuments + "\\Theremino\\HalBackups\\";
        string HalFolder  = Application.StartupPath + "\\";
        private void Menu_File_BackupConfigurations_Click(object sender, EventArgs e)
        {
            string DestFolder  = BackupFolder + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + "\\";
            Theremino_HAL.My.MyProject.Computer.FileSystem.CreateDirectory(DestFolder);
            CopyFileIfExists(HalFolder, DestFolder, "Theremino_HAL_ConfigDatabase.txt");
            CopyFileIfExists(HalFolder, DestFolder, "SlotNames.txt");
            //CopyFileIfExists(HalFolder, DestFolder, "Theremino_HAL_INI.txt");
            //CopyFileIfExists(HalFolder, DestFolder, "Theremino_SlotViewer_INI.txt");
        }
        private void Menu_File_LoadConfigurations_Click(object sender, EventArgs e)
        {
            string SourceFolder = SelectFolder(BackupFolder);
            if (SourceFolder != "")
            {
                CopyFileIfExists(SourceFolder, HalFolder, "Theremino_HAL_ConfigDatabase.txt");
                CopyFileIfExists(SourceFolder, HalFolder, "SlotNames.txt");
                //CopyFileIfExists(SourceFolder, HalFolder, "Theremino_HAL_INI.txt");
                //CopyFileIfExists(SourceFolder, HalFolder, "Theremino_SlotViewer_INI.txt");
                ThereminoSystem.TheSystem_RecognizeSlaves();
            }
        }
        private void CopyFileIfExists(string srcFolder, string destFolder, string fileName)
        {
            string src  = srcFolder + fileName;
            string dest  = destFolder + fileName;
            if (System.IO.File.Exists(src))
            {
                System.IO.File.Copy(src, dest, true);
            }
        }
        internal string SelectFolder(string folder)
        {
            System.Windows.Forms.FolderBrowserDialog FBD;
            FBD = new System.Windows.Forms.FolderBrowserDialog();
            FBD.Reset();
            FBD.ShowNewFolderButton = false;
            // -- USE ROOTFOLDER TO LIMIT USER CHOOSE AREA -- ( No RootFolder NO limits )
            //FBD.RootFolder = Environment.SpecialFolder.MyDocuments;
            FBD.RootFolder = Environment.SpecialFolder.MyComputer;
            // --------------------------------------------------------------------------
            FBD.SelectedPath = folder;
            FBD.Description = ("\r" + "Select the backup folder");
            SendKeys.Send("{TAB}{TAB}{RIGHT}");
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                return FBD.SelectedPath;
            }
            return "";
        }

        private void Menu_File_Exit_Click(object sender, System.EventArgs e)
        {
            CloseAllAndExit();
            this.Close();
        }


        //  =======================================================================================
        //    MENU LANGUAGE
        //  =======================================================================================
        private void Menu_Language_DropDownOpening(object sender, System.EventArgs e)
        {
            foreach (ToolStripMenuItem item in Menu_Language.DropDownItems)
            {
                if (item.Name.EndsWith(Utils_LocaleNames.Language, StringComparison.InvariantCultureIgnoreCase))
                {
                    item.Select();
                }
            }
        }

        private void Menu_Language_Deutsch_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "Deutsch";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_English_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "English";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_Espanol_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "Espanol";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_Portoguese_Click(object sender, EventArgs e)
        {
            Utils_LocaleNames.Language = "Portoguese";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_Francais_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "Francais";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_Italian_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "Italian";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

        private void Menu_Language_Japanese_Click(object sender, System.EventArgs e)
        {
            Utils_LocaleNames.Language = "Japanese";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

          private void Menu_Language_Chinese_Click(object sender, EventArgs e)
        {
            Utils_LocaleNames.Language = "Chinese";
            Utils_LocaleNames.SetLocales();
            Module_SaveLoad.Save_INI();
            ToolTips_Init();
            ShowProps();
        }

      
        
        //  =======================================================================================
        //    MENU HELP
        //  =======================================================================================
        private void Menu_Help_ProgramHelp_Click(object sender, System.EventArgs e)
        {
            OpenLocalizedHelp("ThereminoHAL_Help", ".pdf");
        }

        private void OpenLocalizedHelp(string name, string ext)
        {
            if (ext == "") ext = ".rtf";

            string LangName = Utils_LocaleNames.Language.Substring(0, 3).ToUpper().Replace("JAP", "JPN");
            string fname = Theremino.PlatformAdjustedFileName((Application.StartupPath + ("\\Docs\\"
                            + (name + ("_"
                            + LangName + ext)))), "");
    
            if (Module_SaveLoad.FileExists(fname))
            {
                Process.Start(fname);
            }
            else
            {
                fname = Theremino.PlatformAdjustedFileName((Application.StartupPath + ("\\Docs\\"
                                + (name + ("_ENG" + ext)))), "");
                if (Module_SaveLoad.FileExists(fname))
                {
                    Process.Start(fname);
                }
                else
                {
                    fname = Theremino.PlatformAdjustedFileName((Application.StartupPath + ("\\Docs\\"
                                    + (name + ("_ITA" + ext)))), "");
                    if (Module_SaveLoad.FileExists(fname))
                    {
                        Process.Start(fname);
                    }
                    else
                    {
                        fname = Theremino.PlatformAdjustedFileName((Application.StartupPath + ("\\Docs\\"
                                        + (name + ext))), "");
                        if (Module_SaveLoad.FileExists(fname))
                        {
                            Process.Start(fname);
                        }
                    }
                }
            }
        }
        
        //  =======================================================================================
        //    MENU ABOUT
        //  =======================================================================================
        private void Menu_About_Click(object sender, System.EventArgs e)
        {
            My.MyProject.Forms.Form_About.ShowDialog();
        }
        
        //  =======================================================================================
        //    TOOLBAR
        //  =======================================================================================
        private void ToolStripButton_EditConfigurations_Click(object sender, System.EventArgs e)
        {
            Menu_File_EditConfigurations_Click(null, null);
        }

        private void ToolStripButton_EditSlotNames_Click(object sender, EventArgs e)
        {
            Menu_File_EditSlotNames_Click(null, null);
        }

        private void ToolStripButton_Recognize_Click(object sender, System.EventArgs e)
        {
            Cmd_Recognize();
            ToolStripButton_Recognize.Checked = false;
        }

        private void ToolStripButton_Validate_Click(object sender, System.EventArgs e)
        {
            Cmd_Validate();
            ToolStripButton_Validate.Checked = false;
        }

        private void ToolStripButton_Lock_Click(object sender, EventArgs e)
        {
            if (ToolStripButton_Lock.Checked)
            {
                Module_SaveLoad.ValidMasterNames_Init();
            }
            else
            {
                Module_SaveLoad.ValidMasterNames_Reset();
            }
            Module_SaveLoad.Save_INI();
            EnableDisableLockedControls();
        }

        private void ToolStripButton_Disconnect_Click(object sender, EventArgs e)
        {
            Cmd_DisconnectSelectedMaster();
            ToolStripButton_Disconnect.Checked = false;
        }

        private void EnableDisableLockedControls()
        {
            if (ToolStripButton_Lock.Checked)
            {
                ToolStripButton_Disconnect.Enabled = false;
                cmb_MasterNames.BackColor = Color.FromArgb(220, 220, 220);
                cmb_MasterNames.Enabled = false;
                btn_MasterName.Enabled = false;
            }
            else
            {
                ToolStripButton_Disconnect.Enabled = true;
                cmb_MasterNames.BackColor = Color.AliceBlue;
                cmb_MasterNames.Enabled = true;
                btn_MasterName.Enabled = true;
            }
        }
        

        // ===========================================================================================================
        //   Commands execution
        // ===========================================================================================================
        private void Cmd_Reconnect()
        {
            Module_SaveLoad.EventsAreEnabled = false;
            Timer_10Hz.Stop();
            ThereminoSystem.TheSystem_StopTimers();
            ThereminoSystem.TheSystem_ReconnectMasters();
            ThereminoSystem.TheSystem_StartTimers();
            Timer_10Hz.Start();
            Module_SaveLoad.EventsAreEnabled = true;
        }

        private void Cmd_Recognize()
        {
            Module_SaveLoad.EventsAreEnabled = false;
            Int32 OldSelectedLine = SelectedLine;
            Module_SaveLoad.Load_ConfigDatabase();
            Timer_10Hz.Stop();
            ThereminoSystem.TheSystem_StopTimers();
            ThereminoSystem.TheSystem_InitMasters();
            ThereminoSystem.TheSystem_RecognizeSlaves();
            ShowProps();
            ThereminoSystem.TheSystem_StartTimers();
            Timer_10Hz.Start();
            Module_SaveLoad.EventsAreEnabled = true;
            if (OldSelectedLine < 0) OldSelectedLine = 0;
            Module_Utils.ListView_SelectLine(MyListView1, OldSelectedLine);
            My.MyProject.Forms.Form2.RestoreSelectedPins();
            // ------------------------------------------ eventually show the message
            InvalidConfigMessage();
        }

        private void Cmd_Validate()
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            Module_SaveLoad.EventsAreEnabled = false;
            Int32 OldSelectedLine = SelectedLine;
            ThereminoSystem.TheSystem_ValidateConfiguration();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
            ThereminoSystem.TheSystem_StartTimers();
            Module_SaveLoad.EventsAreEnabled = true;
            Module_Utils.ListView_SelectLine(MyListView1, OldSelectedLine);
        }

        private void Cmd_DisconnectSelectedMaster()
        {
            Module_SaveLoad.EventsAreEnabled = false;
            Module_SaveLoad.Load_ConfigDatabase();
            Timer_10Hz.Stop();
            ThereminoSystem.TheSystem_StopTimers();
            // -----------------------------------------------------
            ThereminoSystem.TheSystem_DisconnectMaster(ThereminoSystem.FindMasterByListLine(SelectedLine));
            ThereminoSystem.TheSystem_ListComponents();
            ListView_SetAllLineColors();
            SelectedLine = -1;
            // -----------------------------------------------------
            ShowProps();
            ThereminoSystem.TheSystem_StartTimers();
            Timer_10Hz.Start();
            Module_SaveLoad.EventsAreEnabled = true;
            Module_Utils.ListView_SelectLine(MyListView1, 0);
            My.MyProject.Forms.Form2.RestoreSelectedPins();
        }

        private void btn_Calibrate_ClickButtonArea(object Sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled)
            {
                return;
            }
            Module_SaveLoad.EventsAreEnabled = false;
            DoCalibrationAndResetTime();
            CalibrationTime = 0.8;
            btn_Calibrate.Refresh();
            Module_SaveLoad.EventsAreEnabled = true;
        }


        // ===========================================================================================================
        //   UPDATES
        // ===========================================================================================================
        private void Timer_10Hz_Tick(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            if (!ThereminoSystem.ConfigurationIsValid) return;
            // ------------------------------------------------------------------ Test Master Error
            ThereminoSystem.TheSystem_TestMasterError();
            // ------------------------------------------------------------------ Updates
            lock (EventsLock)
            {
                //
                if (WindowState != FormWindowState.Minimized)
                {
                    // ---------------------------------------------------------- UpdateListedValues
                    ThereminoSystem.TheSystem_UpdateListedValues();
                    // ---------------------------------------------------------- update RepeatFrequency
                    Master m = ThereminoSystem.FindMasterByListLine(SelectedLine);
                    if (m != null)
                    {
                        lbl_RepeatFrequency.Text = m.CommFps.ToString("0");
                        if (m.CommFps < 50)
                        {
                            lbl_RepeatFrequency.BackColor = Color.LightSalmon;
                        }
                        else
                        {
                            lbl_RepeatFrequency.BackColor = Color.Transparent;
                        }
                        lbl_ErrorRate.Text = m.ErrorRate.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
                        if (m.ErrorRate >= 0.1)
                        {
                            lbl_ErrorRate.BackColor = Color.LightSalmon;
                            m.SetSpeed();
                        }
                        else
                        {
                            lbl_ErrorRate.BackColor = Color.Transparent;
                        }
                        if (m.ErrorRate >= 0.01)
                        {
                            if (ToolStripButton_BeepOnErrors.Checked) Module_Utils.Beep_RepetitionLimited(150);
                        }
                    }
                }
                // ---------------------------------------------------------- Auto Reconnect or Recognize
                //if (btn_Reconnect.Checked)
                //{
                //    foreach (Master m in ThereminoSystem.Masters)
                //    {
                //        if (!m.Hid.MyDeviceDetected)
                //        {
                //            Cmd_Reconnect();
                //            break;
                //        }
                //        if (((m.Hid.USB_RxData[0] == 0)
                //                && ((m.Hid.USB_RxData[1] == (byte)Slave.SlaveTypes.MasterPins)
                //                || (m.Hid.USB_RxData[1] == (byte)Slave.SlaveTypes.MasterPinsV2)
                //                || (m.Hid.USB_RxData[1] == (byte)Slave.SlaveTypes.MasterPinsV4))))
                //        {
                //            bool AllZero = true;
                //            for (Int32 i = 2; (i <= 200); i++)
                //            {
                //                if ((m.Hid.USB_RxData[i] != 0))
                //                {
                //                    AllZero = false;
                //                    break;
                //                }
                //            }
                //            if (AllZero)
                //            {
                //                Cmd_Recognize();
                //                break;
                //            }
                //        }
                //    }
                //}
                // ---------------------------------------------------------- edit
                if (EditValue_MouseEditFlag)
                {
                    if (Module_Utils.LeftMousePressed())
                    {
                        EditValue_MouseMove();
                    }
                    else
                    {
                        ShowCursor();
                        EditValue_MouseEditFlag = false;
                    }
                }
                //
            }
        }

        // ===========================================================================================================
        //   Commands from Slot Zero
        // ===========================================================================================================
        private Int32 cmdZeroStatus = 0;
        private void Timer_60Hz_Tick(object sender, EventArgs e)
        {
            float n = ThereminoSlots.ReadSlot_NoNan(0);
	        switch (cmdZeroStatus) 
            {
		        case 0:                         // Waiting 333
			        if (n == 333) cmdZeroStatus = 1;
			        break;
		        case 1:                         // Waiting 666
                    if (n == 333) {}
                    else if (n == 666) cmdZeroStatus = 2;
                    else cmdZeroStatus = 0;
                    break;
                case 2:                         // Waiting command
                    if (n == 1) 
                    {
                        cmdZeroStatus = 0;
                        Cmd_Recognize();
                    }
                    else if (n == 2)
                    {
                        cmdZeroStatus = 0;
                        DoCalibrationAndResetTime();
                    }
                    else if (n == 666)
                    {
                    }
                    else
                    {
                        cmdZeroStatus = 0;
                    }
			        break;
	        }
        }


        // ===========================================================================================================
        //   EDIT VALUES
        // ===========================================================================================================
        private bool EditValue_MouseEditFlag = false;
        private Int32 EditValue_Slot;
        private Int32 EditValue_Multiplier;
        private Point EditValue_StartCursorPos;
        private float EditValue_MaxValue;
        private float EditValue_MinValue;
        private bool EditValue_IsServoPin;

        private void MyListView1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (ThereminoSystem.ConfigurationIsValid == false) return;
            StartMouseEdit();
        }

        private void StartMouseEdit()
        {
            if (EditValue_MouseEditFlag) return;
            Int32 column = Module_Utils.ListView_GetColumnIndex(MyListView1);
            Int32 line = Module_Utils.ListView_GetLineIndex(MyListView1);
            if (line >= 0)
            {
                string slotString = MyListView1.Items[line].SubItems[3].Text;
                if (!string.IsNullOrEmpty(slotString))
                {
                    Pin p = ThereminoSystem.FindPinByListLine(line);
                    if (p != null && p.Direction != Pin.Directions.Unused)
                    {
                        HideCursor();
                        EditValue_MouseEditFlag = true;
                        EditValue_StartCursorPos = Cursor.Position;
                        // ----------------------------------------------------------------------
                        EditValue_Slot = p.Slot;
                        EditValue_IsServoPin = false;
                        if (p.GetPinType() == Pin.PinTypes.SERVO_8) EditValue_IsServoPin = true;
                        if (p.GetPinType() == Pin.PinTypes.SERVO_16) EditValue_IsServoPin = true;
                        if (p.GetPinType() == Pin.PinTypes.STEPPER)
                        {
                            EditValue_MaxValue = Single.MaxValue;
                            EditValue_MinValue = Single.MinValue;
                        }
                        else
                        {
                            EditValue_MaxValue = (float)Math.Max(p.Value_Max, p.Value_Min);
                            EditValue_MinValue = (float)Math.Min(p.Value_Max, p.Value_Min);
                        }
                        EditValue_Multiplier = 1;
                        Int32 range = Convert.ToInt32(Math.Abs(p.Value_Max - p.Value_Min));
                        if (range > 500) EditValue_Multiplier = 2;
                        if (range > 1000) EditValue_Multiplier = 5;
                        if (range > 2000) EditValue_Multiplier = 10;
                        if (range > 5000) EditValue_Multiplier = 20;
                        if (range > 10000) EditValue_Multiplier = 50;
                    }
                }
            }
        }

        private void MyListView1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;

            if (EditValue_MouseEditFlag)
            {
                EditValue_MouseMove();
            }
        }

        private void EditValue_MouseMove()
        {
            Int32 delta = EditValue_StartCursorPos.Y - Cursor.Position.Y;
            Cursor.Position = EditValue_StartCursorPos;
            ChangeValueByDelta(delta);
        }

        private void ChangeValueByDelta(float delta)
        {
            // do not limit the value if not moving
            if (delta == 0) return;

            //Form2.StopTimer()
            Module_SaveLoad.EventsAreEnabled = false;

            float v = 0;
            v = ThereminoSlots.ReadSlot(EditValue_Slot);

            if (float.IsNaN(v))
            {
                v = EditValue_MinValue - 9;
            }
            //
            v += delta * EditValue_Multiplier;
            v = Math.Min(v, EditValue_MaxValue);
            //v = Math.Max(v, EditValue_MinValue)
            //
            if (v < EditValue_MinValue)
            {
                if (v < -8 && EditValue_IsServoPin)
                {
                    v = Theremino.NAN_Sleep;
                }
                else
                {
                    v = EditValue_MinValue;
                }
            }
            //
            ThereminoSlots.WriteSlot(EditValue_Slot, v);
            //
            Application.DoEvents();

            Module_SaveLoad.EventsAreEnabled = true;
            //Form2.StartTimer()
        }

        private void MyListView1_MouseDoubleClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Pin p = ThereminoSystem.GetSelectedPin();
            if (p == null) return;
            if (p.Direction == Pin.Directions.Unused) return;
            My.MyProject.Forms.Form2.Show();
        }

        private void MyListView1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Pin p = ThereminoSystem.GetSelectedPin();
            if (p == null) return;
            if (p.Direction == Pin.Directions.Unused) return;
            My.MyProject.Forms.Form2.SetPinDetails();
        }

        // ------------------------------------------------------------------
        //  Call ListViewResize from Form.Resize (not from ListView.resize)
        //  (otherwise the listview scroll produces problems)
        // ------------------------------------------------------------------
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            ThereminoSystem.TheSystem_ListViewResize();
        }


        // ---------------------------------------------------------------------------------------------------
        //  MyListView1.Activation = ItemActivation.Standard   <<<< USE THIS OR THE CURSOR CAN NOT BE CHANGED
        // ---------------------------------------------------------------------------------------------------
        //private Cursor BlankCursor = new Cursor(new System.IO.MemoryStream(My.Resources.Resources.Blank));
        private void HideCursor()
        {
            Cursor.Hide();
            //MyListView1.Cursor = BlankCursor;
        }
        private void ShowCursor()
        {
            Cursor.Show();
            MyListView1.Cursor = Cursors.Hand;
        }


        // ===========================================================================================================
        //   SET MASTER AND PIN PROPERTIES
        // ===========================================================================================================
        private void btn_MasterName_ClickButtonArea(object Sender, EventArgs e)
        {
            string newName;
            newName = Microsoft.VisualBasic.Interaction.InputBox("New name for the selected master",
                                                                 "Edit Master name",
                                                                 cmb_MasterNames.Text,
                                                                 this.Right - 370,
                                                                 this.Top + 125);

            newName = newName.Trim();
            if (newName != "") Change_SelectedMaster_Name(newName);
        }

        private void Change_SelectedMaster_Name(string newName)
        {
            this.Cursor = Cursors.AppStarting;
            // --------------------------------------------------------------------- init master
            Master m;
            m = ThereminoSystem.FindMasterByListLine(SelectedLine);
            if (m == null)
            {
                this.Cursor = Cursors.Default;
                return;
            }
            //
            newName = Strings.Left(newName, 16);
            string oldName = m.GetName();
            // --------------------------------------------------------------------- try to change the hardware name
            if (newName != oldName)
            {
                for (Int32 i = 1; i <= 3; i++)
                {
                    m.SetName(newName);
                    m.WriteNameToHardware();
                    m.ReadNameFromHardware();
                    if (m.GetName() == newName)
                    {
                        // --------------------------------------------------------- if the new name is not in the database
                        if (oldName != "" && ThereminoSystem.FindConfigByName(newName) < 0)
                        {
                            Int32 configid = ThereminoSystem.FindConfigByName(oldName);
                            if (configid >= 0)
                            {
                                String[] config = (String[])(((String[])(ThereminoSystem.ConfigDatabase[configid])).Clone());
                                config[0] = config[0].Replace(oldName, newName);
                                ThereminoSystem.AddToConfigDatabase(config);
                                ThereminoSystem.TheSystem_SaveConfigDatabase();
                            }
                        }
                        // --------------------------------------------------------- 
                        Cmd_Recognize();
                        ThereminoSystem.TheSystem_UpdateListedSubtypes();
                        ThereminoSystem.TheSystem_UpdateConfigDatabase();
                        ThereminoSystem.TheSystem_SaveConfigDatabase();
                        break;
                    }
                }
            }
            this.Cursor = Cursors.Default;
        }


        //private const bool CommitOnlyWithEnterKey = false;

        //private void txt_Name_TextChanged(System.Object sender, System.EventArgs e)
        //{
        //    if (SelectedLine < 0) return;

        //    if (!Module_SaveLoad.EventsAreEnabled) return;

        //    Module_SaveLoad.EventsAreEnabled = false;

        //    // ------------------------------------------------------ commit only with ENTER key
        //    //if (CommitOnlyWithEnterKey)
        //    //{
        //    //    if (!txt_Name.Text.Contains(Constants.vbCrLf))
        //    //    {
        //    //        Module_SaveLoad.EventsAreEnabled = true;
        //    //        return;
        //    //    }
        //    //    Theremino_HAL.My.MyProject.Computer.Audio.PlaySystemSound(System.Media.SystemSounds.Exclamation);
        //    //}

        //    // ------------------------------------------------------ remove CrLf and initial annd final spaces
        //    Int32 oldCursorPos = txt_Name.SelectionStart;
        //    //
        //    txt_Name.Text = txt_Name.Text.Replace(Constants.vbCr, "");
        //    txt_Name.Text = txt_Name.Text.Replace(Constants.vbLf, "");
        //    txt_Name.Text = txt_Name.Text.Trim();
        //    //
        //    txt_Name.SelectionStart = oldCursorPos;

        //    // ------------------------------------------------------ init master
        //    Master m = null;
        //    m = ThereminoSystem.GetMasterByListLine(SelectedLine, LineType(SelectedLine));
        //    if (m == null)
        //    {
        //        Module_SaveLoad.EventsAreEnabled = true;
        //        return;
        //    }

        //    string oldName = m.GetName();
        //    string newName = txt_Name.Text;

        //    // ------------------------------------------------------ test the HID
        //    if (!m.Hid.MyDeviceDetected)
        //    {
        //        txt_Name.Text = oldName;
        //        txt_Name.SelectionStart = oldCursorPos;
        //        Module_SaveLoad.EventsAreEnabled = true;
        //        return;
        //    }

        //    // ------------------------------------------------------ detect if the NewName already exists in the database
        //    //Int32 ExistingConfigId = default(Int32);
        //    //ExistingConfigId = ThereminoSystem.FindConfigByName(newName);
        //    //if (ExistingConfigId >= 0 & ExistingConfigId != m.ConfigId)
        //    //{
        //    //    Interaction.MsgBox("The configuration: \"" + newName + "\" already exists." + Constants.vbCr + Constants.vbCr + "Please use another name.", MsgBoxStyle.OkOnly, "");
        //    //    txt_Name.Text = oldName;
        //    //    txt_Name.SelectionStart = oldCursorPos;
        //    //    Module_SaveLoad.EventsAreEnabled = true;
        //    //    return;
        //    //}

        //    //If newName = "NoName" Then
        //    //    MsgBox("The name: ""NoName"" is not allowed." & vbCr & vbCr & _
        //    //           "Please use another name.", MsgBoxStyle.OkOnly)
        //    //    txt_Name.Text = oldName
        //    //    txt_Name.SelectionStart = oldCursorPos
        //    //    Module_SaveLoad.EventsAreEnabled = True
        //    //    Return
        //    //End If

        //    //if (string.IsNullOrEmpty(newName))
        //    //{
        //    //    Interaction.MsgBox("Empty names are not allowed." + Constants.vbCr + Constants.vbCr + "Please use another name.", MsgBoxStyle.OkOnly, "");
        //    //    txt_Name.Text = oldName;
        //    //    txt_Name.SelectionStart = oldCursorPos;
        //    //    Module_SaveLoad.EventsAreEnabled = true;
        //    //    return;
        //    //}

        //    // -------------------------------------------------------- try to change the hardware name
        //    if (newName != oldName)
        //    {
        //        //
        //        for (Int32 i = 1; i <= 3; i++)
        //        {
        //            m.SetName(newName);
        //            m.WriteNameToHardware();
        //            m.ReadNameFromHardware();
        //            if (m.GetName() == newName) break; // TODO: might not be correct. Was : Exit For

        //        }
        //        //
        //        ThereminoSystem.TheSystem_UpdateListedSubtypes();
        //        ThereminoSystem.TheSystem_UpdateConfigDatabase();
        //    }

        //    Module_SaveLoad.EventsAreEnabled = true;
        //}

        private void CommSpeed_TextChanged(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;

            if (SelectedLine < 0) return;

            Timer_10Hz.Stop();
            Master m = ThereminoSystem.FindMasterByListLine(SelectedLine);
            if (m != null)
            {
                m.SetSpeed(txt_CommSpeed.NumericValueInteger);
                txt_CommSpeed.Refresh();
                ChangedConfigParams = true;
            }
            Timer_10Hz.Start();
        }

        private void chk_FastDataExchange_CheckedChanged(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;

            if (SelectedLine < 0) return;

            Master m = ThereminoSystem.FindMasterByListLine(SelectedLine);
            if (m != null)
            {
                m.FastComm = chk_FastDataExchange.Checked;
                ChangedConfigParams = true;
            }
        }

        private void txt_MinChange_TextChanged(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            ChangedAppParams = true;
        }

        private void txt_MinVariation_TextChanged(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            if (SelectedLine < 0) return;
            EnableCalibrateButton(ThereminoSystem.TheSystem_CalibrationNeeded());
        }

        private void txt_CapArea_TextChanged(object sender, EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            if (SelectedLine < 0) return;
            EnableCalibrateButton(ThereminoSystem.TheSystem_CalibrationNeeded());
        }

        private void PinProps_Changed(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            if (SelectedLine < 0) return;
            SetPinProps();
            ChangedConfigParams = true;
        }


        private void SetPinProps()
        {
            switch (LineType(SelectedLine))
            {
                case "Pin":
                case "Adc24":
                    Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
                    Slave sl = ThereminoSystem.Masters[p.MasterId].Slaves[0];
                    Int32 n = txt_Slot.NumericValueInteger;
                    String s;
                    if (n != p.Slot)
                    {
                        p.Slot = n;
                        s = p.Slot.ToString();
                        if (s != MyListView1.Items[SelectedLine].SubItems[3].Text) MyListView1.Items[SelectedLine].SubItems[3].Text = s;
                    }

                    if (p.GetPinType() == Pin.PinTypes.UNUSED || sl.Pins.Count > 6 &&
                         (sl.Pins[6].GetPinType() == Pin.PinTypes.ADC_24 & (p.PinId == 6 | p.PinId == 7)))
                        s = "";
                    else
                        s = Module_SaveLoad.SlotNames[p.Slot];

                    if (s != MyListView1.Items[SelectedLine].SubItems[5].Text) MyListView1.Items[SelectedLine].SubItems[5].Text = s;
                    //
                    p.Value_Max = (float)txt_MaxValue.NumericValue;
                    p.Value_Min = (float)txt_MinValue.NumericValue;
                    p.AdaptiveSpeed = Label_ResponseSpeed.Checked;
                    p.ResponseSpeed = txt_ResponseSpeed.NumericValueInteger;
                    //
                    switch (p.GetPinType())
                    {
                        case Pin.PinTypes.PWM_8:
                        case Pin.PinTypes.PWM_16:
                            p.MaxTime = (float)txt_ServoMaxTime.NumericValue;
                            p.MinTime = (float)txt_ServoMinTime.NumericValue;
                            p.LogResponse = chk_LogResponse.Checked;
                            break;
                        case Pin.PinTypes.SERVO_8:
                        case Pin.PinTypes.SERVO_16:
                            p.MaxTime = (float)txt_ServoMaxTime.NumericValue;
                            p.MinTime = (float)txt_ServoMinTime.NumericValue;
                            break;
                        case Pin.PinTypes.STEPPER:
                            p.MaxSpeed = (float)txt_MaxSpeed.NumericValue;
                            p.MaxAcc = (float)txt_MaxAcc.NumericValue;
                            p.LinkedToPrevious = chk_LinkedToPrevious.Checked;
                            p.StepsPerMillimeter = (float)txt_StepsPerMillim.NumericValue;
                            //  ------------------------------------------------------------------
                            //   STEPPER PIN CONFIGURATION - BY ASYNChronous SendBytesToSlave
                            //  ------------------------------------------------------------------
                            p.SendStepperParamsToHardware();
                            ShowStepperErrors(p);
                            //  ------------------------------------------------------------------
                            break;
                        case Pin.PinTypes.PWM_FAST:
                            p.PwmFastFrequency = (float)txt_PwmFastFrequency.NumericValue;
                            p.PwmFastDutyCycle = (float)txt_PwmFastDutyCycle.NumericValue;
                            p.FrequencyFromSlot = chk_FrequencyFromSlot.Checked;
                            p.DutyCycleFromSlot = chk_DutyCycleFromSlot.Checked;
                            break;
                        case Pin.PinTypes.CAP_8:
                        case Pin.PinTypes.CAP_16:
                            p.MinVariation = (float)txt_MinVariation.NumericValue;
                            p.ProportionalArea = (float)txt_ProportionalArea.NumericValue;
                            break;
                        case Pin.PinTypes.USOUND_SENSOR:
                            p.MaxDist_mm = (float)txt_CapMaxDist.NumericValue;
                            p.MinDist_mm = (float)txt_CapMinDist.NumericValue;
                            p.RemoveErrors = chk_RemoveErrors.Checked;
                            break;
                        case Pin.PinTypes.CAP_SENSOR:
                            p.MaxDist_mm = (float)txt_CapMaxDist.NumericValue;
                            p.MinDist_mm = (float)txt_CapMinDist.NumericValue;
                            p.Area_cmq = (float)txt_CapArea.NumericValue;
                            EnableDisableCapSensorProps(p);
                            break;
                        case Pin.PinTypes.COUNTER:
                        case Pin.PinTypes.COUNTER_PU:
                        case Pin.PinTypes.FAST_COUNTER:
                        case Pin.PinTypes.FAST_COUNTER_PU:
                        case Pin.PinTypes.PERIOD:
                        case Pin.PinTypes.PERIOD_PU:
                        case Pin.PinTypes.SLOW_PERIOD:
                        case Pin.PinTypes.SLOW_PERIOD_PU:
                            p.MaxFreq = (float)txt_MaxFreq.NumericValue;
                            p.MinFreq = (float)txt_MinFreq.NumericValue;
                            p.ConvertToFreq = chk_ConvertToFrequency.Checked;
                            break;
                        case Pin.PinTypes.ADC_24:
                            // ---------------------------------- do not remove used Pins
                            if (p.Adc24Npins > txt_NumberOfPins.NumericValueInteger)
                            {
                                if (Adc24_FindLastUsedPinIndex(p) >= txt_NumberOfPins.NumericValueInteger)
                                {
                                    txt_NumberOfPins.NumericValueInteger = p.Adc24Npins;
                                }
                            }
                            // ---------------------------------- add remove Pins
                            if (p.Adc24Npins != txt_NumberOfPins.NumericValueInteger)
                            {
                                p.Adc24Npins = txt_NumberOfPins.NumericValueInteger;
                                Adc24_AddRemovePinsAndUpdateListView(p);
                            }
                            p.Adc24Sps = (int)Conversion.Val(cmb_Adc24Sps.Text);
                            p.Adc24Filter = cmb_Adc24Filter.SelectedIndex;
                            break;
                        case Pin.PinTypes.ADC_24_DIN:
                        case Pin.PinTypes.ADC_24_DOUT:
                            break;
                        case Pin.PinTypes.ADC_24_CH:
                            p.Adc24ChBias = chk_Adc24ChBiased.Checked;
                            break;
                        case Pin.PinTypes.ADC_24_CH_B:
                            p.Adc24ChBias = chk_Adc24ChBiased.Checked;
                            break;
                        case Pin.PinTypes.ENCODER_B:
                        case Pin.PinTypes.ENCODER_B_PU:
                            break;
                    }
                    if (sl.Pins.Count > 6 && sl.Pins[6].GetPinType() == Pin.PinTypes.ADC_24)
                    {
                        (sl as Slave_MasterPinsV4).Adc24ConfigAndStart();
                    }
                    //
                    break;
            }
            // ------------------------------------------------------- show slot conflicts
            TestSlotConflicts();
        }

        internal void TestSlotConflicts()
        {
            if (ThereminoSystem.ConfigurationIsValid == false) return;
            // ------------------------------------------------------- remove old markers
            for (Int32 ii = 0; ii <= MyListView1.Items.Count - 1; ii++)
            {
                ListViewItem itm = MyListView1.Items[ii];
                if (itm.SubItems[5].Text == "SLOT CONFLICT")
                {
                    itm.SubItems[5].Text = Module_SaveLoad.SlotNames[ThereminoSystem.FindPinByListLine(ii).Slot];
                    ListView_SetLineColors(MyListView1, ii);
                }
            }
            // ------------------------------------------------------- mark new conflicts
            Int32 i = 0;
            Dictionary<Int32, Int32> dic = new Dictionary<Int32, Int32>();
            foreach (Master m in ThereminoSystem.Masters)
            {
                i += 1;
                foreach (Slave s in m.Slaves)
                {
                    i += 1;
                    foreach (Pin p in s.Pins)
                    {
                        if (p.Direction == Pin.Directions.MasterToHost)
                        {
                            if (dic.ContainsKey(p.Slot))
                            {
                                MarkSlotConflicts(i);
                                MarkSlotConflicts(dic[p.Slot]);
                            }
                            dic[p.Slot] = i;
                        }
                        i += 1;
                    }
                }
            }
        }

        private void MarkSlotConflicts(Int32 LineNumber)
        {
            var itm = MyListView1.Items[LineNumber];
            itm.SubItems[5].Text = "SLOT CONFLICT";
            if (itm.Selected)
            {
                itm.BackColor = Color.FromArgb(49, 106, 197);
                itm.ForeColor = Color.White;
            }
            else
            {
                itm.BackColor = Color.FromArgb(255, 150, 150);
                itm.ForeColor = Color.Black;
            }
        }

        internal void MarkAllLinesWithDuplicateName(Master m)
        {
            for (Int32 i = 0; i < MyListView1.Items.Count; i++)
            {
                if (ThereminoSystem.FindMasterByListLine(i) == m)
                {
                    ListViewItem itm = My.MyProject.Forms.Form1.MyListView1.Items[i];
                    itm.SubItems[5].Text = "Duplicate name";
                    itm.BackColor = Color.FromArgb(255, 150, 150);
                    itm.ForeColor = Color.Black;
                }
            }
        }



        private Int32 Adc24_FindLastUsedPinIndex(Pin p)
        {
            Int32 index = 0;
            Slave s = default(Slave);
            s = ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId] as Slave_MasterPinsV4;
            for (Int32 i = 12; i <= s.Pins.Count - 1; i++)
            {
                if (s.Pins[i].GetPinType() != Pin.PinTypes.UNUSED)
                {
                    index = i;
                }
            }
            return index - 12;
        }


        private void Adc24_AddRemovePinsAndUpdateListView(Pin p)
        {
            if (p.SlaveId != 0) return; // only for virtual slave
            if (ThereminoSystem.Masters[p.MasterId].MasterFirmwareVersion < 50) return;
            if (ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId].SlaveType != Slave.SlaveTypes.MasterPinsV4) return;
            //
            Slave s = ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId];
            (s as Slave_MasterPinsV4).Adc24_AddRemovePins();
            Module_Utils.LockFormUpdate(this);
            ThereminoSystem.TheSystem_ListComponents();
            ListView_SetAllLineColors();
            if (SelectedLine > MyListView1.Items.Count - 1) SelectedLine = -1;
            Module_Utils.UnlockFormUpdate();
        }


        // ====================================================================================================
        //   CONFIG PARAMS LOST FOCUS - SaveConfigDatabase 
        // ====================================================================================================
        private bool ChangedConfigParams;
        private void ConfigParams_MouseLeave(System.Object sender, System.EventArgs e)
        {
            if (ChangedConfigParams)
            {
                ChangedConfigParams = false;
                ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
            }
        }

        private bool ChangedAppParams;
        private void txt_MinChange_MouseLeave(object sender, System.EventArgs e)
        {
            if (ChangedAppParams)
            {
                ChangedAppParams = false;
                Module_SaveLoad.Save_INI();
            }
        }

        private void Special_CheckBoxes_CheckedChanged(object Sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            CheckBox c = (CheckBox)Sender;
            if (c.Checked) 
            {
                if ((Sender == chk_FrequencyFromSlot)) chk_DutyCycleFromSlot.Checked = false;
                if ((Sender == chk_DutyCycleFromSlot)) chk_FrequencyFromSlot.Checked = false;
            }
            SetPinProps();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
            ShowProps();
        }


        // ====================================================================================================
        //   COMBO MASTER NAMES
        // ====================================================================================================
        private void cmb_MasterNames_DropDown(object sender, EventArgs e)
        {
            string oldname = cmb_MasterNames.Items[0].ToString();
            cmb_MasterNames.ItemHeight = 16;
            cmb_MasterNames.Items.Clear();
            Module_SaveLoad.Load_ConfigDatabase();
            ThereminoSystem.FillConfigNamesCombo(cmb_MasterNames);
            Module_Utils.Combo_SetIndex_FromString(cmb_MasterNames, oldname);
        }
        private void cmb_MasterNames_DropDownClosed(object sender, EventArgs e)
        {
            cmb_MasterNames.ItemHeight = 12;
            Module_Utils.Combo_Init(cmb_MasterNames, cmb_MasterNames.Text);
            MyListView1.Focus();
        }
        private void cmb_MasterNames_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Change_SelectedMaster_Name(cmb_MasterNames.Text);
        }

        // ====================================================================================================
        //   COMBO PIN TYPE
        // ====================================================================================================

        private void cmb_PinType_DropDown(object sender, System.EventArgs e)
        {
            cmb_PinType.ItemHeight = 16;
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId].FillTypeCombo(cmb_PinType, ref p);
            Module_Utils.Combo_SetIndex_FromString(cmb_PinType, Pin.PinTypeToString(p.GetPinType()));
            Module_SaveLoad.LimitComboDropDownHeight(ref cmb_PinType);
        }
        private void cmb_PinType_DropDownClosed(object sender, EventArgs e)
        {
            cmb_PinType.ItemHeight = 12;
        }
        private void cmb_PinType_SelectionChangeCommitted(object sender, System.EventArgs e)
        {
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            Slave s = ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId];

            // -------------------------------------------------------------- critical section ? ------

            String str = cmb_PinType.Items[cmb_PinType.SelectedIndex].ToString();
            if (ThereminoSystem.Masters[s.MasterId].MasterFirmwareVersion < 41)
            {
                switch (str)
                {
                    case "ADC_24":
                    case "ADC_24_DIN":
                    case "ADC_24_DOUT":
                        str = "UNUSED";
                        break;
                }
            }
            if (ThereminoSystem.Masters[s.MasterId].MasterFirmwareVersion < 40)
            {
                switch (str)
                {
                    case "ENCODER_A":
                    case "ENCODER_A_PU":
                    case "ENCODER_B":
                    case "ENCODER_B_PU":
                        str = "UNUSED";
                        break;
                }
            }
            p.SetPinType(Pin.StringToPinType(str));

            // -------------------------------------------------------------- 
            if (p.GetPinType() == Pin.PinTypes.STEPPER)
            {
                Pin p2;
                p2 = s.Pins[p.PinId + 1];
                p2.SetPinType(Pin.PinTypes.STEPPER_DIR);
                SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                if (p.PinId < s.Pins.Count - 2)
                {
                    Pin p3;
                    p3 = s.Pins[p.PinId + 2];
                    if (p3.GetPinType() == Pin.PinTypes.ENCODER_B || p3.GetPinType() == Pin.PinTypes.ENCODER_B_PU)
                    {
                        p3.SetPinType(Pin.PinTypes.UNUSED);
                    }
                    SetListViewLineFields(MyListView1.Items[SelectedLine + 2], p3);
                }
            }

            if (p.GetPinType() != Pin.PinTypes.STEPPER)
            {
                if (p.PinId < s.Pins.Count - 1)
                {
                    Pin p2;
                    p2 = s.Pins[p.PinId + 1];
                    if (p2.GetPinType() == Pin.PinTypes.STEPPER_DIR) p2.SetPinType(Pin.PinTypes.UNUSED);
                    SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                }
            }

            // -------------------------------------------------------------- 
            if (p.GetPinType() == Pin.PinTypes.ENCODER_A
                ||
                p.GetPinType() == Pin.PinTypes.ENCODER_A_PU)
            {
                Pin p2;
                p2 = s.Pins[p.PinId + 1];
                if (p.GetPinType() == Pin.PinTypes.ENCODER_A)
                {
                    p2.SetPinType(Pin.PinTypes.ENCODER_B);
                }
                else
                {
                    p2.SetPinType(Pin.PinTypes.ENCODER_B_PU);
                }
                SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
            }

            if (p.GetPinType() != Pin.PinTypes.ENCODER_A
                &&
                p.GetPinType() != Pin.PinTypes.ENCODER_A_PU)
            {
                if (p.PinId < s.Pins.Count - 1)
                {
                    Pin p2;
                    p2 = s.Pins[p.PinId + 1];
                    if (p2.GetPinType() == Pin.PinTypes.ENCODER_B
                        ||
                        p2.GetPinType() == Pin.PinTypes.ENCODER_B_PU)
                    {
                        p2.SetPinType(Pin.PinTypes.UNUSED);
                    }
                    SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                }
            }

            // -------------------------------------------------------------- 
            if (p.GetPinType() == Pin.PinTypes.ADC_24)
            {
                Pin p2;
                p2 = s.Pins[p.PinId + 1];
                p2.SetPinType(Pin.PinTypes.ADC_24_DIN);
                SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                Pin p3;
                p3 = s.Pins[p.PinId + 2];
                p3.SetPinType(Pin.PinTypes.ADC_24_DOUT);
                SetListViewLineFields(MyListView1.Items[SelectedLine + 2], p3);
                Pin p4;
                p4 = s.Pins[p.PinId + 3];
                switch (p4.GetPinType())
                {
                    case Pin.PinTypes.ENCODER_B:
                    case Pin.PinTypes.ENCODER_B_PU:
                    case Pin.PinTypes.STEPPER_DIR:
                        p4.SetPinType(Pin.PinTypes.UNUSED);
                        SetListViewLineFields(MyListView1.Items[SelectedLine + 3], p4);
                        break;
                }
                Adc24_AddRemovePinsAndUpdateListView(p);
            }

            if (p.PinId == 6 && p.GetPinType() != Pin.PinTypes.ADC_24)
            {
                Pin p2;
                p2 = s.Pins[p.PinId + 1];
                if (p2.GetPinType() == Pin.PinTypes.ADC_24_DIN)
                {
                    p2.SetPinType(Pin.PinTypes.UNUSED);
                    SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                }
                Pin p3;
                p3 = s.Pins[p.PinId + 2];
                if (p3.GetPinType() == Pin.PinTypes.ADC_24_DOUT)
                {
                    p3.SetPinType(Pin.PinTypes.UNUSED);
                    SetListViewLineFields(MyListView1.Items[SelectedLine + 2], p3);
                }
                Adc24_AddRemovePinsAndUpdateListView(p);
            }

            Adc24_AlignCoupledPinParams(p);
            Adc24_TestSteppers(s);

            ThereminoSystem.Masters[p.MasterId].SetupSlavePins(p.SlaveId);
            // ----------------------------------------------------------------------------------------

            // -------------------------------------------------------------------------- 
            Module_Utils.Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType()));
            // -------------------------------------------------------------------------- set PinType and Direction
            ThereminoSystem.TheSystem_UpdateListedSubtypes();

            SetListViewLineFields(MyListView1.Items[SelectedLine], p);
            
            // -------------------------------------------------------------------------- set Color
            ListView_SetAllLineColors();
            // -------------------------------------------------------------------------- set pin props
            ShowProps();
            SetPinProps();
            // -------------------------------------------------------------------------- 
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
            // -------------------------------------------------------------------------- 
            EnableCalibrateButton(ThereminoSystem.TheSystem_CalibrationNeeded());
            if (btn_Calibrate.Enabled)
            {
                switch (p.GetPinType())
                { 
                    case Pin.PinTypes.CAP_SENSOR:
                    case Pin.PinTypes.CAP_8:
                    case Pin.PinTypes.CAP_16:
                        DoCalibrationAndResetTime();
                        break;
                }
            }
        }

        private void SetListViewLineFields(ListViewItem l, Pin p)
        {
            if (SelectedLine < 0) return;
            l.SubItems[2].Text = Pin.PinTypeToString(p.GetPinType());
            l.SubItems[3].Text = p.Direction == Pin.Directions.Unused ? "" : p.Slot.ToString();
            l.SubItems[4].Text = "";
        }

        private void Adc24_TestSteppers(Slave s)
        {
            if (s.Pins.Count < 12)
                return;
            if (s.Pins[6].GetPinType() == Pin.PinTypes.ADC_24)
            {
                foreach (Pin p in s.Pins)
                {
                    if (p.GetPinType() == Pin.PinTypes.STEPPER)
                    {
                        MessageBox.Show(Utils_LocaleNames.Msg_Warning + 
                                        Constants.vbCrLf + Constants.vbCrLf +
                                        Utils_LocaleNames.Msg_StepperWithAdc24,
                                        Utils_LocaleNames.Msg_HalMessage,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                        return;
                    }
                }
            }
        }

        // ====================================================================================================
        //   COMBO Adc24Sps
        // ====================================================================================================
        private void cmb_Adc24Sps_DropDown(object sender, EventArgs e)
        {
            cmb_Adc24Sps.ItemHeight = 16;
        }
        private void cmb_Adc24Sps_DropDownClosed(object sender, EventArgs e)
        {
            cmb_Adc24Sps.ItemHeight = 12;
        }
        private void cmb_Adc24Sps_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            if (p == null) return;
            p.Adc24Sps = cmb_Adc24Sps.SelectedIndex;
            SetPinProps();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
        }


        // ====================================================================================================
        //   COMBO Adc24Filter
        // ====================================================================================================
        private void cmb_Adc24Filter_DropDown(object sender, EventArgs e)
        {
            cmb_Adc24Filter.ItemHeight = 16;
        }
        private void cmb_Adc24Filter_DropDownClosed(object sender, EventArgs e)
        {
            cmb_Adc24Filter.ItemHeight = 12;
        }
        private void cmb_Adc24Filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            if (p == null) return;
            p.Adc24Filter = cmb_Adc24Filter.SelectedIndex;
            SetPinProps();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
        }

        // ====================================================================================================
        //   COMBO Adc24ChType
        // ====================================================================================================
        private void cmb_Adc24ChType_DropDown(object sender, EventArgs e)
        {
            cmb_Adc24ChType.ItemHeight = 16;
        }
        private void cmb_Adc24ChType_DropDownClosed(object sender, EventArgs e)
        {
            cmb_Adc24ChType.ItemHeight = 12;
        }
        private void cmb_Adc24ChType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            if (p == null) return;
            p.Adc24ChType = cmb_Adc24ChType.SelectedIndex;
            Adc24_AlignCoupledPinParams(p);
            ThereminoSystem.Masters[p.MasterId].SetupSlavePins(p.SlaveId);
            ShowProps();
            SetPinProps();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
        }

        // ====================================================================================================
        //   COMBO Adc24ChGain
        // ====================================================================================================
        private void cmb_Adc24ChGain_DropDown(object sender, EventArgs e)
        {
            cmb_Adc24ChGain.ItemHeight = 16;
        }
        private void cmb_Adc24ChGain_DropDownClosed(object sender, EventArgs e)
        {
            cmb_Adc24ChGain.ItemHeight = 12;
        }
        private void cmb_Adc24ChGain_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
            if (p == null) return;
            p.Adc24ChGain = cmb_Adc24ChGain.SelectedIndex;
            Adc24_AlignCoupledPinParams(p);
            SetPinProps();
            ThereminoSystem.TheSystem_UpdateAndSaveConfigDatabase();
        }

        // ====================================================================================================
        //   Adc24_AlignCoupledPinParams
        // ====================================================================================================
        private void Adc24_AlignCoupledPinParams(Pin p)
        {
            if (p.PinId < 12) return;
            Slave s = ThereminoSystem.Masters[p.MasterId].Slaves[p.SlaveId];

            // ----------------------------------------------------- return if not coupled 
            if (p.PinId % 2 == 0)
            {
                if (p.PinId >= s.Pins.Count - 1) return;
            }

            // ----------------------------------------------------- set CH and CH_B to coupled pin
            if (p.PinId % 2 == 0)
            {
                Pin p2 = s.Pins[p.PinId + 1];
                if (p.Adc24ChType == 0)  // if differential
                {
                    if (p2.GetPinType() == Pin.PinTypes.ADC_24_CH)
                    {
                        p2.SetPinType(Pin.PinTypes.ADC_24_CH_B);
                        SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                    }
                }
                else
                {
                    if (p2.GetPinType() == Pin.PinTypes.ADC_24_CH_B)
                    {
                        p2.SetPinType(Pin.PinTypes.ADC_24_CH);
                        SetListViewLineFields(MyListView1.Items[SelectedLine + 1], p2);
                    }
                }
            }

            // ----------------------------------------------------- set CH and CH_B to selected pin
            if (p.PinId % 2 == 1)
            {
                if (p.Adc24ChType == 0)  // if differential
                {
                    if (p.GetPinType() == Pin.PinTypes.ADC_24_CH)
                    {
                        s.Pins[p.PinId].SetPinType(Pin.PinTypes.ADC_24_CH_B);
                        SetListViewLineFields(MyListView1.Items[SelectedLine], p);
                    }
                }
                else
                {
                    if (p.GetPinType() == Pin.PinTypes.ADC_24_CH_B)
                    {
                        // ------------------------------------- save and restore old values
                        Int32 oldChType  = p.Adc24ChType;
                        Int32 oldChGain = p.Adc24ChGain;
                        s.Pins[p.PinId].SetPinType(Pin.PinTypes.ADC_24_CH);
                        p.Adc24ChType = oldChType;
                        p.Adc24ChGain = oldChGain;
                        SetListViewLineFields(MyListView1.Items[SelectedLine], p);
                    }
                }
            }

            // ----------------------------------------------------- copy to coupled pin
            if (p.PinId % 2 == 0)
            {
                if (p.PinId + 1 < s.Pins.Count)
                {
                    s.Pins[p.PinId + 1].Adc24ChType = p.Adc24ChType;
                    s.Pins[p.PinId + 1].Adc24ChGain = p.Adc24ChGain;
                }
            }
            else
            {
                s.Pins[p.PinId - 1].Adc24ChType = p.Adc24ChType;
                s.Pins[p.PinId - 1].Adc24ChGain = p.Adc24ChGain;
            }
            
        }


        // ===========================================================================================================
        //   SHOW PROPS
        // ===========================================================================================================
        internal void ListView_SetAllLineColors()
        {
            // -------------------------------------------------------------------- select the listview "SelectedLine"
            if (SelectedLine >= 0 & SelectedLine < MyListView1.Items.Count)
            {
                MyListView1.Items[SelectedLine].Selected = true;
            }
            // -------------------------------------------------------------------- show listview colors
            for (Int32 i = 0; i <= MyListView1.Items.Count - 1; i++)
            {
                ListView_SetLineColors(MyListView1, i);
            }
        }


        private void ListView_SetLineColors(ListView lv, Int32 line)
        {
            if (line < 0 | line >= lv.Items.Count) return;
            //
            Color fc = default(Color);
            Color bc = default(Color);
            if (lv.Items[line].Selected)
            {
                // ----------------------------------------------------------------- selected colors
                bc = Color.FromArgb(49, 106, 197);
                fc = Color.White;
            }
            else
            {
                // ----------------------------------------------------------------- deselected colors
                if (line >= 0)
                {
                    switch (LineType(line))
                    {
                        case "Master":
                            bc = Color.FromArgb(180, 205, 255);
                            //(190, 215, 255)
                            break;
                        case "Slave":
                            bc = Color.FromArgb(255, 200, 160);
                            //(245, 215, 185) '(255, 230, 200)
                            break;
                        case "Pin":
                            if (LineSubType(line) != "Unused")
                            {
                                if (ThereminoSystem.FindPinByListLine(line).Direction == Pin.Directions.HostToMaster)
                                {
                                    bc = Color.FromArgb(245, 245, 215);
                                    //(255, 255, 225)
                                }
                                else
                                {
                                    bc = Color.FromArgb(225, 245, 230);
                                    //(235, 255, 240)
                                }
                            }
                            else
                            {
                                bc = Color.FromArgb(255, 255, 255);
                            }
                            break;
                        case "Adc24":
                            if (LineSubType(line) != "Unused")
                            {
                                bc = Color.FromArgb(200, 235, 180);
                            }
                            else
                            {
                                bc = Color.FromArgb(255, 255, 255);
                            }
                            break;
                    }
                    fc = Color.Black;
                }
            }
            lv.Items[line].ForeColor = fc;
            lv.Items[line].BackColor = bc;
        }

        private string LineType(Int32 line)
        {
            if (line < 0) return "";
            if (line > MyListView1.Items.Count - 1) return "";
            return MyListView1.Items[line].SubItems[0].Text.Trim();
        }
        private string LineSubType(Int32 line)
        {
            return MyListView1.Items[line].SubItems[2].Text.Trim();
        }

        internal Int32 SelectedLine = -1;
        private void MyListView1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            Module_Utils.LockFormUpdate(this); // The FormUpdate must be outside the lock
            lock (EventsLock)
            {
                // --------------------------------------------------------- change line colors and update "SelectedLine"
                if (MyListView1.SelectedIndices.Count > 0)
                {
                    SelectedLine = MyListView1.SelectedIndices[0];
                    if (ThereminoSystem.ConfigurationIsValid)
                    {
                        ListView_SetLineColors(MyListView1, SelectedLine);
                    }
                }
                else
                {
                    if (ThereminoSystem.ConfigurationIsValid)
                    {
                        ListView_SetLineColors(MyListView1, SelectedLine);
                    }
                    SelectedLine = -1;
                }
                // --------------------------------------------------------- show line props
                ShowProps();
                // --------------------------------------------------------- show slot conflicts
                TestSlotConflicts();
            }
            Module_Utils.UnlockFormUpdate(); // The FormUpdate must be outside the lock
            if (SelectedLine >= 0) Refresh();
        }

        private void ShowProps()
        {
            //
            Module_SaveLoad.EventsAreEnabled = false;
            //
            GroupBox_PinProps.Visible = false;
            GroupBox_TouchProps.Visible = false;
            GroupBox_CapSensorProps.Visible = false;
            GroupBox_ServoPwmProps.Visible = false;
            GroupBox_StepperProps.Visible = false;
            GroupBox_PwmFastProps.Visible = false;
            GroupBox_FrequencyProps.Visible = false;
            GroupBox_Adc24Props.Visible = false;
            GroupBox_Adc24ChProps.Visible = false;
            //
            if (SelectedLine < 0 | SelectedLine > MyListView1.Items.Count - 1)
            {
                GroupBox_MasterProps.Enabled = false;
                txt_CommSpeed.Text = "-";
            }
            else
            {
                GroupBox_MasterProps.Enabled = true;
                //
                Master m = ThereminoSystem.FindMasterByListLine(SelectedLine);
                Pin p = ThereminoSystem.FindPinByListLine(SelectedLine);
                //
                if (!ThereminoSystem.ConfigurationIsValid)
                {
                    GroupBox_MasterProps.Height = cmb_MasterNames.Bottom + 6;
                    if (m != null)
                    {
                        Module_Utils.Combo_Init(cmb_MasterNames, m.GetName());
                    }
                    else
                    {
                        Module_Utils.Combo_Init(cmb_MasterNames, "");
                        GroupBox_MasterProps.Enabled = false;
                        txt_CommSpeed.Text = "-";
                    }
                }
                else
                {
                    GroupBox_MasterProps.Height = chk_FastDataExchange.Bottom + 6;
                    //
                    switch (LineType(SelectedLine))
                    {
                        case "Master":
                            GroupBox_PinProps.Visible = false;
                            GroupBox_CapSensorProps.Visible = false;
                            GroupBox_ServoPwmProps.Visible = false;
                            break;
                        case "Slave":
                            GroupBox_PinProps.Visible = false;
                            GroupBox_CapSensorProps.Visible = false;
                            GroupBox_ServoPwmProps.Visible = false;
                            break;
                        case "Pin":
                        case "Adc24":
                            GroupBox_PinProps.Visible = true;
                            GroupBox_PinProps.Left = GroupBox_MasterProps.Left;
                            GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 8;
                            break;
                    }
                    //
                    if (m != null)
                    {
                        Module_Utils.Combo_Init(cmb_MasterNames, m.GetName());
                        txt_CommSpeed.NumericValueInteger = m.CommSpeed;
                        chk_FastDataExchange.Checked = m.FastComm;

                        if (m.HasPhysicalSlaves)
                        {
                            chk_FastDataExchange.Enabled = true;
                        }
                        else
                        {
                            chk_FastDataExchange.Enabled = false;
                        }
                        ToolTips_Init();

                        if (p != null)
                        {
                            Label_MaxValue.Text = Utils_LocaleNames.Msg_MaxValue;
                            Label_MinValue.Text = Utils_LocaleNames.Msg_MinValue;
                            Module_Utils.Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType()));
                            txt_Slot.NumericValue = p.Slot;
                            txt_MaxValue.NumericValue = p.Value_Max;
                            txt_MinValue.NumericValue = p.Value_Min;
                            Label_ResponseSpeed.Checked = p.AdaptiveSpeed;
                            txt_ResponseSpeed.NumericValueInteger = p.ResponseSpeed;
                            txt_MaxValue.Visible = true;
                            switch (p.GetPinType())
                            {
                                case Pin.PinTypes.UNUSED:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 8;
                                    break;
                                    // ------------------------------------------------------------------ OUT
                                case Pin.PinTypes.PWM_8:
                                case Pin.PinTypes.PWM_16:
                                    GroupBox_ServoPwmProps.Text = Utils_LocaleNames.Msg_PwmProps;
                                    txt_ServoMaxTime.NumericValue = p.MaxTime;
                                    txt_ServoMinTime.NumericValue = p.MinTime;
                                    chk_LogResponse.Checked = p.LogResponse;
                                    GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_ServoPwmProps.Height = chk_LogResponse.Bottom + 7;
                                    GroupBox_ServoPwmProps.Visible = true;
                                    break;
                                case Pin.PinTypes.SERVO_8:
                                case Pin.PinTypes.SERVO_16:
                                    GroupBox_ServoPwmProps.Text = Utils_LocaleNames.Msg_ServoProps;
                                    txt_ServoMaxTime.NumericValue = p.MaxTime;
                                    txt_ServoMinTime.NumericValue = p.MinTime;
                                    GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_ServoPwmProps.Height = txt_ServoMinTime.Bottom + 8;
                                    GroupBox_ServoPwmProps.Visible = true;
                                    break;
                                case Pin.PinTypes.STEPPER:
                                    Label_MaxValue.Text = Utils_LocaleNames.Msg_MaxValueStepper;
                                    Label_MinValue.Text = Utils_LocaleNames.Msg_MinValueStepper;
                                    txt_MaxSpeed.NumericValue = p.MaxSpeed;
                                    txt_MaxAcc.NumericValue = p.MaxAcc;
                                    if (m.Slaves[p.SlaveId].ValidLinkedToPrevious(p))
                                    {
                                        chk_LinkedToPrevious.Checked = p.LinkedToPrevious;
                                        chk_LinkedToPrevious.Enabled = true;
                                    }
                                    else
                                    {
                                        chk_LinkedToPrevious.Checked = false;
                                        chk_LinkedToPrevious.Enabled = false;
                                    }
                                    chk_LinkedToPrevious.Checked = p.LinkedToPrevious;
                                    txt_StepsPerMillim.NumericValue = p.StepsPerMillimeter;
                                    GroupBox_StepperProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_StepperProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_StepperProps.Height = chk_LinkedToPrevious.Bottom + 8;
                                    GroupBox_StepperProps.Visible = true;
                                    ShowStepperErrors(p);
                                    break;
                                case Pin.PinTypes.PWM_FAST:
                                    txt_PwmFastFrequency.NumericValue = p.PwmFastFrequency;
                                    txt_PwmFastDutyCycle.NumericValue = p.PwmFastDutyCycle;
                                    chk_FrequencyFromSlot.Checked = p.FrequencyFromSlot;
                                    chk_DutyCycleFromSlot.Checked = p.DutyCycleFromSlot;

                                    if (chk_FrequencyFromSlot.Checked)
                                    {
                                        txt_PwmFastFrequency.Enabled = false;
                                        Label_PwmFastFrequency.Enabled = false;
                                    }
                                    else
                                    {
                                        txt_PwmFastFrequency.Enabled = true;
                                        Label_PwmFastFrequency.Enabled = true;
                                    }
                                    if (chk_DutyCycleFromSlot.Checked)
                                    {
                                        txt_PwmFastDutyCycle.Enabled = false;
                                        Label_PwmFastDutyCycle.Enabled = false;
                                    }
                                    else
                                    {
                                        txt_PwmFastDutyCycle.Enabled = true;
                                        Label_PwmFastDutyCycle.Enabled = true;
                                    }
                                    GroupBox_PwmFastProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_PwmFastProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_PwmFastProps.Height = chk_LinkedToPrevious.Bottom + 8;
                                    GroupBox_PwmFastProps.Visible = true;
                                    break;
                                    // ------------------------------------------------------------------ IN
                                case Pin.PinTypes.CAP_8:
                                case Pin.PinTypes.CAP_16:
                                    txt_MinVariation.NumericValue = p.MinVariation;
                                    txt_ProportionalArea.NumericValue = p.ProportionalArea;
                                    GroupBox_TouchProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_TouchProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_TouchProps.Visible = true;
                                    break;
                                case Pin.PinTypes.USOUND_SENSOR:
                                    GroupBox_CapSensorProps.Text = Utils_LocaleNames.Msg_UsoundProps;
                                    txt_CapMaxDist.NumericValue = p.MaxDist_mm;
                                    txt_CapMinDist.NumericValue = p.MinDist_mm;
                                    GroupBox_CapSensorProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_CapSensorProps.Top = GroupBox_PinProps.Bottom + 6;
                                    chk_RemoveErrors.Location = Label_Area.Location;
                                    chk_RemoveErrors.Visible = true;
                                    chk_RemoveErrors.Checked = p.RemoveErrors;
                                    Label_Area.Visible = false;
                                    txt_CapArea.Visible = false;
                                    GroupBox_CapSensorProps.Height = txt_CapArea.Bottom + 8;
                                    GroupBox_CapSensorProps.Visible = true;
                                    break;
                                case Pin.PinTypes.CAP_SENSOR:
                                    GroupBox_CapSensorProps.Text = Utils_LocaleNames.Msg_CapSensorProps;
                                    txt_CapMaxDist.NumericValue = p.MaxDist_mm;
                                    txt_CapMinDist.NumericValue = p.MinDist_mm;
                                    GroupBox_CapSensorProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_CapSensorProps.Top = GroupBox_PinProps.Bottom + 6;
                                    txt_CapArea.NumericValue = p.Area_cmq;
                                    chk_RemoveErrors.Visible = false;
                                    Label_Area.Visible = true;
                                    txt_CapArea.Visible = true;
                                    GroupBox_CapSensorProps.Height = txt_CapArea.Bottom + 8;
                                    GroupBox_CapSensorProps.Visible = true;
                                    EnableDisableCapSensorProps(p);
                                    break;
                                case Pin.PinTypes.COUNTER:
                                case Pin.PinTypes.COUNTER_PU:
                                case Pin.PinTypes.FAST_COUNTER:
                                case Pin.PinTypes.FAST_COUNTER_PU:
                                case Pin.PinTypes.PERIOD:
                                case Pin.PinTypes.PERIOD_PU:
                                case Pin.PinTypes.SLOW_PERIOD:
                                case Pin.PinTypes.SLOW_PERIOD_PU:
                                    chk_ConvertToFrequency.Checked = p.ConvertToFreq;
                                    txt_MaxFreq.NumericValue = p.MaxFreq;
                                    txt_MinFreq.NumericValue = p.MinFreq;
                                    if (chk_ConvertToFrequency.Checked)
                                    {
                                        GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 10;
                                        GroupBox_FrequencyProps.Height = txt_MinFreq.Bottom + 8;
                                    }
                                    else
                                    {
                                        GroupBox_PinProps.Height = txt_Slot.Bottom + 7;
                                        GroupBox_FrequencyProps.Height = chk_ConvertToFrequency.Bottom + 10;
                                    }

                                    GroupBox_FrequencyProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_FrequencyProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_FrequencyProps.Visible = true;
                                    break;
                                case Pin.PinTypes.STEPPER_DIR:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 7;
                                    txt_MaxValue.Visible = false;
                                    break;
                                case Pin.PinTypes.ADC_24:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 8;
                                    txt_NumberOfPins.NumericValueInteger = p.Adc24Npins;
                                    Module_Utils.Combo_SetIndex_FromString(cmb_Adc24Sps, p.Adc24Sps.ToString());
                                    if (cmb_Adc24Sps.Text == "") cmb_Adc24Sps.SelectedIndex = 0;
                                    Module_Utils.Combo_SetIndex(cmb_Adc24Filter, p.Adc24Filter);
                                    GroupBox_Adc24Props.Left = GroupBox_PinProps.Left;
                                    GroupBox_Adc24Props.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_Adc24Props.Height = cmb_Adc24Filter.Bottom + 7;
                                    GroupBox_Adc24Props.Visible = true;
                                    break;
                                case Pin.PinTypes.ADC_24_DIN:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 8;
                                    break;
                                case Pin.PinTypes.ADC_24_DOUT:
                                    GroupBox_PinProps.Height = txt_Slot.Bottom + 7;
                                    txt_MaxValue.Visible = false;
                                    break;
                                case Pin.PinTypes.ADC_24_CH:
                                    Module_Utils.Combo_SetIndex(cmb_Adc24ChType, p.Adc24ChType);
                                    Module_Utils.Combo_SetIndex(cmb_Adc24ChGain, p.Adc24ChGain);
                                    chk_Adc24ChBiased.Checked = p.Adc24ChBias;
                                    GroupBox_Adc24ChProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_Adc24ChProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_Adc24ChProps.Height = chk_Adc24ChBiased.Bottom + 7;
                                    GroupBox_Adc24ChProps.Visible = true;
                                    break;
                                case Pin.PinTypes.ADC_24_CH_B:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 8;
                                    Module_Utils.Combo_SetIndex(cmb_Adc24ChType, p.Adc24ChType);
                                    Module_Utils.Combo_SetIndex(cmb_Adc24ChGain, p.Adc24ChGain);
                                    chk_Adc24ChBiased.Checked = p.Adc24ChBias;
                                    GroupBox_Adc24ChProps.Left = GroupBox_PinProps.Left;
                                    GroupBox_Adc24ChProps.Top = GroupBox_PinProps.Bottom + 6;
                                    GroupBox_Adc24ChProps.Height = chk_Adc24ChBiased.Bottom + 7;
                                    GroupBox_Adc24ChProps.Visible = true;
                                    break;
                                case Pin.PinTypes.ENCODER_B:
                                case Pin.PinTypes.ENCODER_B_PU:
                                    GroupBox_PinProps.Height = cmb_PinType.Bottom + 8;
                                    break;
                            }
                        }
                    }
                }
            }
            //
            Module_SaveLoad.EventsAreEnabled = true;
        }

        private void ShowStepperErrors(Pin p)
        {
            if (p.MaxSpeed * p.StepsPerMillimeter / 60.0F > 65500)
            {
                Label_MaxSpeed.BackColor = Color.Yellow;
                Label_StepsPerMillim.BackColor = Color.Yellow;
                Label_MaxSpeed.ForeColor = Color.Red;
                Label_StepsPerMillim.ForeColor = Color.Red;
            }
            else
            {
                Label_MaxSpeed.BackColor = Label_MaxAcc.BackColor;
                Label_StepsPerMillim.BackColor = Label_MaxAcc.BackColor;
                Label_MaxSpeed.ForeColor = Label_MaxAcc.ForeColor;
                Label_StepsPerMillim.ForeColor = Label_MaxAcc.ForeColor;
            }
        }

        private void EnableDisableCapSensorProps(Pin p)
        {
            if (p.Area_cmq > 0)
            {
                Label_MaxDist.Enabled = true;
                Label_MinDist.Enabled = true;
                txt_CapMaxDist.Enabled = true;
                txt_CapMinDist.Enabled = true;
            }
            else
            {
                Label_MaxDist.Enabled = false;
                Label_MinDist.Enabled = false;
                txt_CapMaxDist.Enabled = false;
                txt_CapMinDist.Enabled = false;
            }
        }

        // ==============================================================================================================
        //  AUTO CALIBRATION
        // ==============================================================================================================
        private void Timer_1Hz_Tick(System.Object eventSender, System.EventArgs eventArgs)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            if (btn_Calibrate.Enabled)
            {
                if (txt_MinChange.NumericValueInteger > 0)
                {
                    TestDeltaToRestartCalibrationTime();
                    TestCalibrationTime();
                }
                else
                {
                    CalibrationTime = 0;
                }
                ShowCalibrationRedLine();
            }
        }


        // ==============================================================================================================
        //   AUTO CALIBRATION
        // ==============================================================================================================
        private double CalibrationTime;
        private void TestDeltaToRestartCalibrationTime()
        {
            foreach (Master m in ThereminoSystem.Masters)
            {
                for (Int32 i = 0; i <= m.SlaveCount - 1; i++)
                {
                    UInt32 rd = m.Slaves[i].Get_CapSensor_Or_Cap_Delta();
                    if (rd > txt_MinChange.NumericValueInteger)
                    {
                        CalibrationTime = 0;
                        ShowCalibrationRedLine();
                    }
                }
            }
        }

        private void TestCalibrationTime()
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            CalibrationTime += 0.033;
            if (CalibrationTime > 0.99)
            {
                DoCalibrationAndResetTime();
            }
        }

        private void DoCalibrationAndResetTime()
        {
            CalibrationTime = 0;
            btn_Calibrate.Checked = true;
            btn_Calibrate.Refresh();
            ThereminoSystem.TheSystem_Calibrate();
            System.Threading.Thread.Sleep(100);
            btn_Calibrate.Checked = false;
        }

        private void ShowCalibrationRedLine()
        {
            Module_FillBars.FillPictureBox_Horizontal(Pic_CalibrateTime, CalibrationTime, Color.FromArgb(255, 120, 0), Color.LightGray, 0);
        }

        internal void EnableCalibrateButton(bool enable)
        {
            if (enable)
            {
                CalibrationTime = 0.6; // start with 10 seconds delay
            }
            else
            {
                CalibrationTime = 0;
            }
            ShowCalibrationRedLine();
            btn_Calibrate.Enabled = enable;
            txt_MinChange.Enabled = enable;
        }



        // ==============================================================================================================
        //   ToolTips
        // ==============================================================================================================
        private ToolTip ttp1 = new ToolTip();
        private void ToolTips_Init()
        {
            ttp1.ShowAlways = true;
            ttp1.UseAnimation = true;
            ttp1.UseFading = true;
            ttp1.IsBalloon = true;
            ttp1.AutoPopDelay = 32700;
            ttp1.InitialDelay = 500;
            ttp1.ReshowDelay = 500;
            // --------------------------------------------------------------- Add here Controls and ToolTip-Text
            Master m = ThereminoSystem.FindMasterByListLine(SelectedLine);
            if (m != null)
            {
                if (m.HasPhysicalSlaves)
                {
                    ttp1.SetToolTip(txt_CommSpeed, Utils_LocaleNames.Msg_CommSpeed1 + Constants.vbCrLf +
                                                    "- - - - - - - - - - - - - - -" + Constants.vbCrLf +
                                                    "  1  =     1  Kilo-Baud" + Constants.vbCrLf +
                                                    "  2  =     2  Kilo-Baud" + Constants.vbCrLf +
                                                    "  3  =     5  Kilo-Baud" + Constants.vbCrLf +
                                                    "  4  =   10  Kilo-Baud" + Constants.vbCrLf +
                                                    "  5  =   20  Kilo-Baud" + Constants.vbCrLf +
                                                    "  6  =   50  Kilo-Baud" + Constants.vbCrLf +
                                                    "  7  = 100  Kilo-Baud" + Constants.vbCrLf +
                                                    "  8  = 200  Kilo-Baud" + Constants.vbCrLf +
                                                    "  9  = 500  Kilo-Baud" + Constants.vbCrLf +
                                                    "10  =  1  Mega-Baud" + Constants.vbCrLf +
                                                    "11  =  2  Mega-Baud" + Constants.vbCrLf + 
                                                    "12  =  4  Mega-Baud");
                }
                else
                {
                    ttp1.SetToolTip(txt_CommSpeed,
                                        Utils_LocaleNames.Msg_CommSpeed1 + Constants.vbCrLf +
                                        "- - - - - - - - - - - - - - -" + Constants.vbCrLf +
                                        "  1  =  10 fps" + Constants.vbCrLf +
                                        "  2  =  20 fps" + Constants.vbCrLf +
                                        "  3  =  30 fps" + Constants.vbCrLf +
                                        "  4  =  50 fps" + Constants.vbCrLf +
                                        "  5  =  80 fps" + Constants.vbCrLf +
                                        "  6  = 100 fps" + Constants.vbCrLf +
                                        "  7  = 150 fps" + Constants.vbCrLf +
                                        "  8  = 200 fps" + Constants.vbCrLf +
                                        "  9  = 300 fps" + Constants.vbCrLf +
                                        "10  =  400 fps" + Constants.vbCrLf +
                                        "11  =  500 fps" + Constants.vbCrLf +
                                        "12  =  Max fps");
                }
            }

            ttp1.SetToolTip(txt_MinChange, Utils_LocaleNames.Msg_MinChange1 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_MinChange2 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_MinChange3 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_MinChange4 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_MinChange5 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_MinChange6);

            ttp1.SetToolTip(txt_CapArea, Utils_LocaleNames.Msg_CapArea1 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea2 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea3 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea4 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea5 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea6 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea7 + Constants.vbCrLf +
                                            Utils_LocaleNames.Msg_CapArea8);

            ttp1.SetToolTip(Label_ResponseSpeed, Utils_LocaleNames.Msg_Filter1 + Constants.vbCrLf +
                                                Utils_LocaleNames.Msg_Filter2 + Constants.vbCrLf +
                                                Utils_LocaleNames.Msg_Filter3 + Constants.vbCrLf +
                                                Utils_LocaleNames.Msg_Filter4 + Constants.vbCrLf +
                                                Utils_LocaleNames.Msg_Filter5);
  
            ToolStripButton_Validate.ToolTipText = Utils_LocaleNames.Msg_Validate1;
            ToolStripButton_BeepOnErrors.ToolTipText = Utils_LocaleNames.Msg_BeepOnErrors1;
            ToolStripButton_Lock.ToolTipText = Utils_LocaleNames.Msg_Lock1 + Constants.vbCrLf + Utils_LocaleNames.Msg_Lock2;
            ToolStripButton_Disconnect.ToolTipText = Utils_LocaleNames.Msg_Disconnect1;
        }

        public Form1()
        {
            LocationChanged += Form1_LocationChanged;
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            InitializeComponent();
        }

    }

}



