﻿namespace Theremino_HAL
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            CustomControlsLib.DesignerRectTracker designerRectTracker5 = new CustomControlsLib.DesignerRectTracker();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            CustomControlsLib.cBlendItems cBlendItems5 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems6 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker6 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.DesignerRectTracker designerRectTracker7 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.cBlendItems cBlendItems7 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems8 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker8 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.DesignerRectTracker designerRectTracker1 = new CustomControlsLib.DesignerRectTracker();
            CustomControlsLib.cBlendItems cBlendItems1 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.cBlendItems cBlendItems2 = new CustomControlsLib.cBlendItems();
            CustomControlsLib.DesignerRectTracker designerRectTracker2 = new CustomControlsLib.DesignerRectTracker();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.pbox_ScrollingScope = new System.Windows.Forms.PictureBox();
            this.Label_Scale1b = new System.Windows.Forms.Label();
            this.Label_Scale2b = new System.Windows.Forms.Label();
            this.Label_Scale3b = new System.Windows.Forms.Label();
            this.Label_Scale3 = new System.Windows.Forms.Label();
            this.Label_Scale2 = new System.Windows.Forms.Label();
            this.Label_Scale1 = new System.Windows.Forms.Label();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_ScaleMin = new CustomControlsLib.MyTextBox();
            this.txt_ScaleMax = new CustomControlsLib.MyTextBox();
            this.Label_ScaleMin = new System.Windows.Forms.Label();
            this.Label_ScaleMax = new System.Windows.Forms.Label();
            this.btn_Run = new CustomControlsLib.MyButton();
            this.cmb_ScrollSpeed = new CustomControlsLib.MyComboBox();
            this.cmb_UnitsPerDivision = new CustomControlsLib.MyComboBox();
            this.Label_VerticalScale = new System.Windows.Forms.Label();
            this.Label_ScrollSpeed = new System.Windows.Forms.Label();
            this.btn_SetZero = new CustomControlsLib.MyButton();
            this.pbox_Details2 = new System.Windows.Forms.PictureBox();
            this.lbl_Details2 = new System.Windows.Forms.Label();
            this.LabelPin1 = new System.Windows.Forms.Label();
            this.LabelPin2 = new System.Windows.Forms.Label();
            this.btn_ShowRawCount = new CustomControlsLib.MyButton();
            this.pbox_Details1 = new System.Windows.Forms.PictureBox();
            this.lbl_Details1 = new System.Windows.Forms.Label();
            this.Timer_60Hz = new System.Windows.Forms.Timer(this.components);
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ScrollingScope)).BeginInit();
            this.GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Details2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Details1)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupBox1
            // 
            this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox1.Controls.Add(this.pbox_ScrollingScope);
            this.GroupBox1.Controls.Add(this.Label_Scale1b);
            this.GroupBox1.Controls.Add(this.Label_Scale2b);
            this.GroupBox1.Controls.Add(this.Label_Scale3b);
            this.GroupBox1.Controls.Add(this.Label_Scale3);
            this.GroupBox1.Controls.Add(this.Label_Scale2);
            this.GroupBox1.Controls.Add(this.Label_Scale1);
            this.GroupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.Location = new System.Drawing.Point(5, 5);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(502, 238);
            this.GroupBox1.TabIndex = 148;
            this.GroupBox1.TabStop = false;
            // 
            // pbox_ScrollingScope
            // 
            this.pbox_ScrollingScope.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pbox_ScrollingScope.BackColor = System.Drawing.Color.AliceBlue;
            this.pbox_ScrollingScope.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbox_ScrollingScope.Location = new System.Drawing.Point(10, 16);
            this.pbox_ScrollingScope.Name = "pbox_ScrollingScope";
            this.pbox_ScrollingScope.Size = new System.Drawing.Size(426, 213);
            this.pbox_ScrollingScope.TabIndex = 153;
            this.pbox_ScrollingScope.TabStop = false;
            // 
            // Label_Scale1b
            // 
            this.Label_Scale1b.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Scale1b.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale1b.ForeColor = System.Drawing.Color.Maroon;
            this.Label_Scale1b.Location = new System.Drawing.Point(436, 205);
            this.Label_Scale1b.Name = "Label_Scale1b";
            this.Label_Scale1b.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale1b.TabIndex = 180;
            this.Label_Scale1b.Text = "0";
            this.Label_Scale1b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_Scale2b
            // 
            this.Label_Scale2b.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Label_Scale2b.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale2b.ForeColor = System.Drawing.Color.Maroon;
            this.Label_Scale2b.Location = new System.Drawing.Point(436, 129);
            this.Label_Scale2b.Name = "Label_Scale2b";
            this.Label_Scale2b.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale2b.TabIndex = 179;
            this.Label_Scale2b.Text = "500";
            this.Label_Scale2b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_Scale3b
            // 
            this.Label_Scale3b.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Scale3b.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale3b.ForeColor = System.Drawing.Color.Maroon;
            this.Label_Scale3b.Location = new System.Drawing.Point(436, 25);
            this.Label_Scale3b.Name = "Label_Scale3b";
            this.Label_Scale3b.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale3b.TabIndex = 178;
            this.Label_Scale3b.Text = "1000";
            this.Label_Scale3b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_Scale3
            // 
            this.Label_Scale3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Scale3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale3.ForeColor = System.Drawing.Color.Blue;
            this.Label_Scale3.Location = new System.Drawing.Point(436, 13);
            this.Label_Scale3.Name = "Label_Scale3";
            this.Label_Scale3.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale3.TabIndex = 177;
            this.Label_Scale3.Text = "1000";
            this.Label_Scale3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_Scale2
            // 
            this.Label_Scale2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Label_Scale2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale2.ForeColor = System.Drawing.Color.Blue;
            this.Label_Scale2.Location = new System.Drawing.Point(436, 116);
            this.Label_Scale2.Name = "Label_Scale2";
            this.Label_Scale2.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale2.TabIndex = 176;
            this.Label_Scale2.Text = "500";
            this.Label_Scale2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_Scale1
            // 
            this.Label_Scale1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Scale1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Scale1.ForeColor = System.Drawing.Color.Blue;
            this.Label_Scale1.Location = new System.Drawing.Point(436, 218);
            this.Label_Scale1.Name = "Label_Scale1";
            this.Label_Scale1.Size = new System.Drawing.Size(65, 13);
            this.Label_Scale1.TabIndex = 175;
            this.Label_Scale1.Text = "0";
            this.Label_Scale1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.GroupBox3.Controls.Add(this.txt_ScaleMin);
            this.GroupBox3.Controls.Add(this.txt_ScaleMax);
            this.GroupBox3.Controls.Add(this.Label_ScaleMin);
            this.GroupBox3.Controls.Add(this.Label_ScaleMax);
            this.GroupBox3.Controls.Add(this.btn_Run);
            this.GroupBox3.Controls.Add(this.cmb_ScrollSpeed);
            this.GroupBox3.Controls.Add(this.cmb_UnitsPerDivision);
            this.GroupBox3.Controls.Add(this.Label_VerticalScale);
            this.GroupBox3.Controls.Add(this.Label_ScrollSpeed);
            this.GroupBox3.Controls.Add(this.btn_SetZero);
            this.GroupBox3.Controls.Add(this.pbox_Details2);
            this.GroupBox3.Controls.Add(this.lbl_Details2);
            this.GroupBox3.Controls.Add(this.LabelPin1);
            this.GroupBox3.Controls.Add(this.LabelPin2);
            this.GroupBox3.Controls.Add(this.btn_ShowRawCount);
            this.GroupBox3.Controls.Add(this.pbox_Details1);
            this.GroupBox3.Controls.Add(this.lbl_Details1);
            this.GroupBox3.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.GroupBox3.Location = new System.Drawing.Point(5, 249);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(502, 168);
            this.GroupBox3.TabIndex = 147;
            this.GroupBox3.TabStop = false;
            // 
            // txt_ScaleMin
            // 
            this.txt_ScaleMin.ArrowsIncrement = 1;
            this.txt_ScaleMin.BackColor = System.Drawing.Color.MintCream;
            this.txt_ScaleMin.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ScaleMin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ScaleMin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ScaleMin.Decimals = 3;
            this.txt_ScaleMin.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ScaleMin.ForeColor = System.Drawing.Color.Black;
            this.txt_ScaleMin.Increment = 0.2;
            this.txt_ScaleMin.Location = new System.Drawing.Point(430, 53);
            this.txt_ScaleMin.MaxValue = 9999999;
            this.txt_ScaleMin.MinValue = -999999;
            this.txt_ScaleMin.Name = "txt_ScaleMin";
            this.txt_ScaleMin.NumericValue = 0;
            this.txt_ScaleMin.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ScaleMin.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ScaleMin.RoundingStep = 0;
            this.txt_ScaleMin.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ScaleMin.Size = new System.Drawing.Size(56, 15);
            this.txt_ScaleMin.SuppressZeros = true;
            this.txt_ScaleMin.TabIndex = 182;
            this.txt_ScaleMin.Text = "0";
            this.txt_ScaleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_ScaleMin.TextChanged += new System.EventHandler(this.txt_ScaleMin_TextChanged);
            // 
            // txt_ScaleMax
            // 
            this.txt_ScaleMax.ArrowsIncrement = 1;
            this.txt_ScaleMax.BackColor = System.Drawing.Color.MintCream;
            this.txt_ScaleMax.BackColor_Over = System.Drawing.Color.Moccasin;
            this.txt_ScaleMax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ScaleMax.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ScaleMax.Decimals = 3;
            this.txt_ScaleMax.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ScaleMax.ForeColor = System.Drawing.Color.Black;
            this.txt_ScaleMax.Increment = 0.2;
            this.txt_ScaleMax.Location = new System.Drawing.Point(430, 33);
            this.txt_ScaleMax.MaxValue = 9999999;
            this.txt_ScaleMax.MinValue = -999999;
            this.txt_ScaleMax.Name = "txt_ScaleMax";
            this.txt_ScaleMax.NumericValue = 1000;
            this.txt_ScaleMax.NumericValueInteger = 1000;
            this.txt_ScaleMax.RectangleColor = System.Drawing.Color.PowderBlue;
            this.txt_ScaleMax.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed;
            this.txt_ScaleMax.RoundingStep = 0;
            this.txt_ScaleMax.ShadowColor = System.Drawing.Color.LightGray;
            this.txt_ScaleMax.Size = new System.Drawing.Size(56, 15);
            this.txt_ScaleMax.SuppressZeros = true;
            this.txt_ScaleMax.TabIndex = 181;
            this.txt_ScaleMax.Text = "1000";
            this.txt_ScaleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_ScaleMax.TextChanged += new System.EventHandler(this.txt_ScaleMax_TextChanged);
            // 
            // Label_ScaleMin
            // 
            this.Label_ScaleMin.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ScaleMin.Location = new System.Drawing.Point(395, 54);
            this.Label_ScaleMin.Name = "Label_ScaleMin";
            this.Label_ScaleMin.Size = new System.Drawing.Size(39, 13);
            this.Label_ScaleMin.TabIndex = 180;
            this.Label_ScaleMin.Text = "Min";
            this.Label_ScaleMin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_ScaleMax
            // 
            this.Label_ScaleMax.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ScaleMax.Location = new System.Drawing.Point(395, 34);
            this.Label_ScaleMax.Name = "Label_ScaleMax";
            this.Label_ScaleMax.Size = new System.Drawing.Size(39, 13);
            this.Label_ScaleMax.TabIndex = 179;
            this.Label_ScaleMax.Text = "Max";
            this.Label_ScaleMax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Run
            // 
            this.btn_Run.BorderColor = System.Drawing.Color.DimGray;
            designerRectTracker5.IsActive = false;
            designerRectTracker5.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker5.TrackerRectangle")));
            this.btn_Run.CenterPtTracker = designerRectTracker5;
            this.btn_Run.CheckButton = true;
            this.btn_Run.Checked = true;
            cBlendItems5.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))))};
            cBlendItems5.iPoint = new float[] {
        0F,
        0.5017921F,
        1F};
            this.btn_Run.ColorFillBlend = cBlendItems5;
            cBlendItems6.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems6.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_Run.ColorFillBlendChecked = cBlendItems6;
            this.btn_Run.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_Run.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_Run.Corners.All = ((short)(6));
            this.btn_Run.Corners.LowerLeft = ((short)(6));
            this.btn_Run.Corners.LowerRight = ((short)(6));
            this.btn_Run.Corners.UpperLeft = ((short)(6));
            this.btn_Run.Corners.UpperRight = ((short)(6));
            this.btn_Run.DimFactorGray = -10;
            this.btn_Run.DimFactorOver = 30;
            this.btn_Run.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Run.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_Run.FocalPoints.CenterPtX = 0.2727273F;
            this.btn_Run.FocalPoints.CenterPtY = 0.5F;
            this.btn_Run.FocalPoints.FocusPtX = 0F;
            this.btn_Run.FocalPoints.FocusPtY = 0F;
            this.btn_Run.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_Run.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_Run.FocalPointsChecked.FocusPtX = 0F;
            this.btn_Run.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker6.IsActive = false;
            designerRectTracker6.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker6.TrackerRectangle")));
            this.btn_Run.FocusPtTracker = designerRectTracker6;
            this.btn_Run.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Run.Image = null;
            this.btn_Run.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Run.ImageIndex = 0;
            this.btn_Run.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_Run.Location = new System.Drawing.Point(282, 32);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_Run.SideImage = null;
            this.btn_Run.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Run.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_Run.Size = new System.Drawing.Size(90, 36);
            this.btn_Run.TabIndex = 176;
            this.btn_Run.Text = "RUN";
            this.btn_Run.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Run.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Run.TextMargin = new System.Windows.Forms.Padding(0);
            this.btn_Run.TextShadow = System.Drawing.Color.Transparent;
            // 
            // cmb_ScrollSpeed
            // 
            this.cmb_ScrollSpeed.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_ScrollSpeed.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_ScrollSpeed.BackColor = System.Drawing.Color.MintCream;
            this.cmb_ScrollSpeed.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_ScrollSpeed.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_ScrollSpeed.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_ScrollSpeed.BorderSize = 1;
            this.cmb_ScrollSpeed.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_ScrollSpeed.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_ScrollSpeed.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_ScrollSpeed.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_ScrollSpeed.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_ScrollSpeed.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_ScrollSpeed.DropDownHeight = 500;
            this.cmb_ScrollSpeed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ScrollSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_ScrollSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ScrollSpeed.ForeColor = System.Drawing.Color.Black;
            this.cmb_ScrollSpeed.IntegralHeight = false;
            this.cmb_ScrollSpeed.ItemHeight = 12;
            this.cmb_ScrollSpeed.Items.AddRange(new object[] {
            " 60 pixel/sec",
            " 30 pixel/sec",
            " 20 pixel/sec",
            " 10 pixel/sec",
            "   5 pixel/sec",
            "   2 pixel/sec",
            "   1 pixel/sec",
            "0.5 pixel/sec",
            "0.2 pixel/sec",
            "0.1 pixel/sec"});
            this.cmb_ScrollSpeed.Location = new System.Drawing.Point(398, 139);
            this.cmb_ScrollSpeed.Name = "cmb_ScrollSpeed";
            this.cmb_ScrollSpeed.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_ScrollSpeed.Size = new System.Drawing.Size(88, 18);
            this.cmb_ScrollSpeed.TabIndex = 175;
            this.cmb_ScrollSpeed.TabStop = false;
            this.cmb_ScrollSpeed.TextPosition = 1;
            this.cmb_ScrollSpeed.SelectedIndexChanged += new System.EventHandler(this.cmb_ScrollSpeed_SelectedIndexChanged);
            this.cmb_ScrollSpeed.DropDownClosed += new System.EventHandler(this.cmb_ScrollSpeed_DropDownClosed);
            this.cmb_ScrollSpeed.DropDown += new System.EventHandler(this.cmb_ScrollSpeed_DropDown);
            // 
            // cmb_UnitsPerDivision
            // 
            this.cmb_UnitsPerDivision.ArrowButtonColor = System.Drawing.Color.Transparent;
            this.cmb_UnitsPerDivision.ArrowColor = System.Drawing.Color.Transparent;
            this.cmb_UnitsPerDivision.BackColor = System.Drawing.Color.MintCream;
            this.cmb_UnitsPerDivision.BackColor_Focused = System.Drawing.Color.MintCream;
            this.cmb_UnitsPerDivision.BackColor_Over = System.Drawing.Color.Moccasin;
            this.cmb_UnitsPerDivision.BorderColor = System.Drawing.Color.PowderBlue;
            this.cmb_UnitsPerDivision.BorderSize = 1;
            this.cmb_UnitsPerDivision.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_UnitsPerDivision.DropDown_BackColor = System.Drawing.Color.AliceBlue;
            this.cmb_UnitsPerDivision.DropDown_BackSelected = System.Drawing.Color.LightBlue;
            this.cmb_UnitsPerDivision.DropDown_BorderColor = System.Drawing.Color.Gainsboro;
            this.cmb_UnitsPerDivision.DropDown_ForeColor = System.Drawing.Color.Black;
            this.cmb_UnitsPerDivision.DropDown_ForeSelected = System.Drawing.Color.Black;
            this.cmb_UnitsPerDivision.DropDownHeight = 500;
            this.cmb_UnitsPerDivision.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_UnitsPerDivision.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_UnitsPerDivision.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_UnitsPerDivision.ForeColor = System.Drawing.Color.Black;
            this.cmb_UnitsPerDivision.IntegralHeight = false;
            this.cmb_UnitsPerDivision.ItemHeight = 12;
            this.cmb_UnitsPerDivision.Items.AddRange(new object[] {
            "Scale Min-Max",
            "50000",
            "20000",
            "10000",
            "5000",
            "2000",
            "1000",
            "500",
            "200",
            "100",
            "50",
            "20",
            "10",
            "5",
            "2",
            "1",
            "0.5",
            "0.2",
            "0.1",
            "0.05",
            "0.02",
            "0.01",
            "0.005",
            "0.002",
            "0.001",
            "0.0005",
            "0.0002",
            "0.0001"});
            this.cmb_UnitsPerDivision.Location = new System.Drawing.Point(398, 96);
            this.cmb_UnitsPerDivision.Name = "cmb_UnitsPerDivision";
            this.cmb_UnitsPerDivision.ShadowColor = System.Drawing.Color.Transparent;
            this.cmb_UnitsPerDivision.Size = new System.Drawing.Size(88, 18);
            this.cmb_UnitsPerDivision.TabIndex = 174;
            this.cmb_UnitsPerDivision.TabStop = false;
            this.cmb_UnitsPerDivision.TextPosition = 1;
            this.cmb_UnitsPerDivision.SelectedIndexChanged += new System.EventHandler(this.cmb_UnitsPerDivision_SelectedIndexChanged);
            this.cmb_UnitsPerDivision.DropDownClosed += new System.EventHandler(this.cmb_UnitsPerDivision_DropDownClosed);
            this.cmb_UnitsPerDivision.DropDown += new System.EventHandler(this.cmb_UnitsPerDivision_DropDown);
            // 
            // Label_VerticalScale
            // 
            this.Label_VerticalScale.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_VerticalScale.Location = new System.Drawing.Point(385, 79);
            this.Label_VerticalScale.Name = "Label_VerticalScale";
            this.Label_VerticalScale.Size = new System.Drawing.Size(112, 13);
            this.Label_VerticalScale.TabIndex = 173;
            this.Label_VerticalScale.Text = "Vertical scale";
            this.Label_VerticalScale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_ScrollSpeed
            // 
            this.Label_ScrollSpeed.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ScrollSpeed.Location = new System.Drawing.Point(385, 122);
            this.Label_ScrollSpeed.Name = "Label_ScrollSpeed";
            this.Label_ScrollSpeed.Size = new System.Drawing.Size(112, 13);
            this.Label_ScrollSpeed.TabIndex = 172;
            this.Label_ScrollSpeed.Text = "Scroll speed";
            this.Label_ScrollSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_SetZero
            // 
            this.btn_SetZero.BorderColor = System.Drawing.Color.DimGray;
            designerRectTracker7.IsActive = false;
            designerRectTracker7.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker7.TrackerRectangle")));
            this.btn_SetZero.CenterPtTracker = designerRectTracker7;
            cBlendItems7.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))))};
            cBlendItems7.iPoint = new float[] {
        0F,
        0.5017921F,
        1F};
            this.btn_SetZero.ColorFillBlend = cBlendItems7;
            cBlendItems8.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems8.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_SetZero.ColorFillBlendChecked = cBlendItems8;
            this.btn_SetZero.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_SetZero.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_SetZero.Corners.All = ((short)(6));
            this.btn_SetZero.Corners.LowerLeft = ((short)(6));
            this.btn_SetZero.Corners.LowerRight = ((short)(6));
            this.btn_SetZero.Corners.UpperLeft = ((short)(6));
            this.btn_SetZero.Corners.UpperRight = ((short)(6));
            this.btn_SetZero.DimFactorGray = -10;
            this.btn_SetZero.DimFactorOver = 30;
            this.btn_SetZero.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_SetZero.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_SetZero.FocalPoints.CenterPtX = 0.3218391F;
            this.btn_SetZero.FocalPoints.CenterPtY = 0.5F;
            this.btn_SetZero.FocalPoints.FocusPtX = 0F;
            this.btn_SetZero.FocalPoints.FocusPtY = 0F;
            this.btn_SetZero.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_SetZero.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_SetZero.FocalPointsChecked.FocusPtX = 0F;
            this.btn_SetZero.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker8.IsActive = false;
            designerRectTracker8.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker8.TrackerRectangle")));
            this.btn_SetZero.FocusPtTracker = designerRectTracker8;
            this.btn_SetZero.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SetZero.Image = null;
            this.btn_SetZero.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_SetZero.ImageIndex = 0;
            this.btn_SetZero.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_SetZero.Location = new System.Drawing.Point(282, 76);
            this.btn_SetZero.Name = "btn_SetZero";
            this.btn_SetZero.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_SetZero.SideImage = null;
            this.btn_SetZero.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_SetZero.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_SetZero.Size = new System.Drawing.Size(90, 36);
            this.btn_SetZero.TabIndex = 169;
            this.btn_SetZero.Text = "Reset zero";
            this.btn_SetZero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_SetZero.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_SetZero.TextMargin = new System.Windows.Forms.Padding(0);
            this.btn_SetZero.TextShadow = System.Drawing.Color.Transparent;
            // 
            // pbox_Details2
            // 
            this.pbox_Details2.BackColor = System.Drawing.Color.MintCream;
            this.pbox_Details2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbox_Details2.Location = new System.Drawing.Point(141, 144);
            this.pbox_Details2.Name = "pbox_Details2";
            this.pbox_Details2.Size = new System.Drawing.Size(124, 16);
            this.pbox_Details2.TabIndex = 167;
            this.pbox_Details2.TabStop = false;
            // 
            // lbl_Details2
            // 
            this.lbl_Details2.BackColor = System.Drawing.Color.MintCream;
            this.lbl_Details2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Details2.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details2.Location = new System.Drawing.Point(141, 32);
            this.lbl_Details2.Name = "lbl_Details2";
            this.lbl_Details2.Size = new System.Drawing.Size(124, 108);
            this.lbl_Details2.TabIndex = 166;
            // 
            // LabelPin1
            // 
            this.LabelPin1.AutoSize = true;
            this.LabelPin1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPin1.ForeColor = System.Drawing.Color.DarkBlue;
            this.LabelPin1.Location = new System.Drawing.Point(14, 13);
            this.LabelPin1.Name = "LabelPin1";
            this.LabelPin1.Size = new System.Drawing.Size(33, 13);
            this.LabelPin1.TabIndex = 165;
            this.LabelPin1.Text = "- - -";
            // 
            // LabelPin2
            // 
            this.LabelPin2.AutoSize = true;
            this.LabelPin2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPin2.ForeColor = System.Drawing.Color.Maroon;
            this.LabelPin2.Location = new System.Drawing.Point(142, 13);
            this.LabelPin2.Name = "LabelPin2";
            this.LabelPin2.Size = new System.Drawing.Size(33, 13);
            this.LabelPin2.TabIndex = 164;
            this.LabelPin2.Text = "- - -";
            // 
            // btn_ShowRawCount
            // 
            this.btn_ShowRawCount.BorderColor = System.Drawing.Color.DimGray;
            designerRectTracker1.IsActive = false;
            designerRectTracker1.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker1.TrackerRectangle")));
            this.btn_ShowRawCount.CenterPtTracker = designerRectTracker1;
            this.btn_ShowRawCount.CheckButton = true;
            cBlendItems1.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(192))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))))};
            cBlendItems1.iPoint = new float[] {
        0F,
        0.5017921F,
        1F};
            this.btn_ShowRawCount.ColorFillBlend = cBlendItems1;
            cBlendItems2.iColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))))};
            cBlendItems2.iPoint = new float[] {
        0F,
        0.3309608F,
        1F};
            this.btn_ShowRawCount.ColorFillBlendChecked = cBlendItems2;
            this.btn_ShowRawCount.ColorFillSolid = System.Drawing.SystemColors.Control;
            this.btn_ShowRawCount.ColorFillSolidChecked = System.Drawing.SystemColors.Control;
            this.btn_ShowRawCount.Corners.All = ((short)(6));
            this.btn_ShowRawCount.Corners.LowerLeft = ((short)(6));
            this.btn_ShowRawCount.Corners.LowerRight = ((short)(6));
            this.btn_ShowRawCount.Corners.UpperLeft = ((short)(6));
            this.btn_ShowRawCount.Corners.UpperRight = ((short)(6));
            this.btn_ShowRawCount.DimFactorGray = -10;
            this.btn_ShowRawCount.DimFactorOver = 30;
            this.btn_ShowRawCount.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_ShowRawCount.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical;
            this.btn_ShowRawCount.FocalPoints.CenterPtX = 0.2727273F;
            this.btn_ShowRawCount.FocalPoints.CenterPtY = 0.5F;
            this.btn_ShowRawCount.FocalPoints.FocusPtX = 0F;
            this.btn_ShowRawCount.FocalPoints.FocusPtY = 0F;
            this.btn_ShowRawCount.FocalPointsChecked.CenterPtX = 0.5F;
            this.btn_ShowRawCount.FocalPointsChecked.CenterPtY = 0.5F;
            this.btn_ShowRawCount.FocalPointsChecked.FocusPtX = 0F;
            this.btn_ShowRawCount.FocalPointsChecked.FocusPtY = 0F;
            designerRectTracker2.IsActive = false;
            designerRectTracker2.TrackerRectangle = ((System.Drawing.RectangleF)(resources.GetObject("designerRectTracker2.TrackerRectangle")));
            this.btn_ShowRawCount.FocusPtTracker = designerRectTracker2;
            this.btn_ShowRawCount.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowRawCount.Image = null;
            this.btn_ShowRawCount.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ShowRawCount.ImageIndex = 0;
            this.btn_ShowRawCount.ImageSize = new System.Drawing.Size(16, 16);
            this.btn_ShowRawCount.Location = new System.Drawing.Point(282, 121);
            this.btn_ShowRawCount.Name = "btn_ShowRawCount";
            this.btn_ShowRawCount.Shape = CustomControlsLib.MyButton.eShape.Rectangle;
            this.btn_ShowRawCount.SideImage = null;
            this.btn_ShowRawCount.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ShowRawCount.SideImageSize = new System.Drawing.Size(32, 32);
            this.btn_ShowRawCount.Size = new System.Drawing.Size(90, 36);
            this.btn_ShowRawCount.TabIndex = 155;
            this.btn_ShowRawCount.Text = "Show raw count";
            this.btn_ShowRawCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ShowRawCount.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ShowRawCount.TextMargin = new System.Windows.Forms.Padding(0);
            this.btn_ShowRawCount.TextShadow = System.Drawing.Color.Transparent;
            // 
            // pbox_Details1
            // 
            this.pbox_Details1.BackColor = System.Drawing.Color.MintCream;
            this.pbox_Details1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbox_Details1.Location = new System.Drawing.Point(9, 144);
            this.pbox_Details1.Name = "pbox_Details1";
            this.pbox_Details1.Size = new System.Drawing.Size(124, 16);
            this.pbox_Details1.TabIndex = 103;
            this.pbox_Details1.TabStop = false;
            // 
            // lbl_Details1
            // 
            this.lbl_Details1.BackColor = System.Drawing.Color.MintCream;
            this.lbl_Details1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Details1.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details1.Location = new System.Drawing.Point(9, 32);
            this.lbl_Details1.Name = "lbl_Details1";
            this.lbl_Details1.Size = new System.Drawing.Size(124, 108);
            this.lbl_Details1.TabIndex = 7;
            // 
            // Timer_60Hz
            // 
            this.Timer_60Hz.Tick += new System.EventHandler(this.Timer_60Hz_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 421);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.GroupBox3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(800, 540);
            this.MinimumSize = new System.Drawing.Size(528, 460);
            this.Name = "Form2";
            this.Opacity = 0;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Theremino HAL - Pin details";
            this.Resize += new System.EventHandler(this.Form2_Resize);
            this.GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ScrollingScope)).EndInit();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Details2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Details1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.PictureBox pbox_ScrollingScope;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal CustomControlsLib.MyButton btn_SetZero;
        internal System.Windows.Forms.PictureBox pbox_Details2;
        internal System.Windows.Forms.Label lbl_Details2;
        internal System.Windows.Forms.Label LabelPin1;
        internal System.Windows.Forms.Label LabelPin2;
        internal CustomControlsLib.MyButton btn_ShowRawCount;
        internal System.Windows.Forms.PictureBox pbox_Details1;
        internal System.Windows.Forms.Label lbl_Details1;
        internal System.Windows.Forms.Timer Timer_60Hz;
        internal System.Windows.Forms.Label Label_Scale3;
        internal System.Windows.Forms.Label Label_Scale2;
        internal System.Windows.Forms.Label Label_Scale1;
        internal System.Windows.Forms.Label Label_Scale1b;
        internal System.Windows.Forms.Label Label_Scale2b;
        internal System.Windows.Forms.Label Label_Scale3b;
        internal System.Windows.Forms.Label Label_VerticalScale;
        internal System.Windows.Forms.Label Label_ScrollSpeed;
        internal CustomControlsLib.MyComboBox cmb_UnitsPerDivision;
        internal CustomControlsLib.MyComboBox cmb_ScrollSpeed;
        internal CustomControlsLib.MyButton btn_Run;
        internal System.Windows.Forms.Label Label_ScaleMin;
        internal System.Windows.Forms.Label Label_ScaleMax;
        internal CustomControlsLib.MyTextBox txt_ScaleMin;
        internal CustomControlsLib.MyTextBox txt_ScaleMax;
    }
}