﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Theremino_HAL
{
    public partial class Form_About : Form
    {
        private void Form_About_Load(object sender, System.EventArgs e)
        {
            Label2.Text = Module_SaveLoad.AppTitleAndVersion("");
        }

        private void Button_OK_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void Label_OpenSite_Click(object sender, System.EventArgs e)
        {
            Process.Start("http://www.theremino.com");
        }

        private void Label_SendInfo_Click(object sender, System.EventArgs e)
        {
            Send_Mail("development@theremino.com", "Info on Theremino Theremin", "Dear Theremino team,\\n\\n");
        }

        private void Send_Mail(string sendto, string subject, string body)
        {
            subject = subject.Replace(" ", "%20");
            body = body.Replace("\\n", "%0d%0a");
            body = body.Replace(" ", "%20");

            //Shell(("Cmd /C START MAILTO:"
            //                + (sendto + ("\"?subject="
            //                + (subject + ("&body="
            //                + (body + "\"")))))));

            System.Diagnostics.Process.Start("Cmd.exe", "/C START MAILTO:"
                                                        + (sendto + ("\"?subject="
                                                        + (subject + ("&body="
                                                        + (body + "\""))))));
        }

        private void Labels_MouseEnter(object sender, System.EventArgs e)
        {
            Label lb = (Label)sender;
            lb.BackColor = Color.FromArgb(250, 240, 255);
        }
        private void Labels_MouseLeave(object sender, System.EventArgs e)
        {
            Label lb = (Label)sender;
            lb.BackColor = Color.Transparent;
        }
        private void Label_OpenSite_MouseEnter(object sender, EventArgs e)
        {
            Labels_MouseEnter(sender, e);
        }
        private void Label_OpenSite_MouseLeave(object sender, EventArgs e)
        {
            Labels_MouseLeave(sender, e);
        }
        private void Label_SendInfo_MouseEnter(object sender, EventArgs e)
        {
            Labels_MouseEnter(sender, e);
        }
        private void Label_SendInfo_MouseLeave(object sender, EventArgs e)
        {
            Labels_MouseLeave(sender, e);
        }

        public Form_About()
        {
            InitializeComponent();
        }



    }
}
