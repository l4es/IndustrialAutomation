using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
namespace Theremino_HAL
{


	static class Module_ImageFilters
	{


		public static void InitPictureboxImage(PictureBox pbox)
		{
			{
                if (pbox.ClientSize.Width < 1 || pbox.ClientSize.Height < 1) return;
                pbox.Image = new Bitmap(pbox.ClientSize.Width, pbox.ClientSize.Height);
			}
		}


		// ================================================================================
		//  ROTATIONS
		// ================================================================================

		public static Image ImageRotate(ref Image img, double angle)
		{
			Bitmap bmp = new Bitmap(img);
			Graphics g = Graphics.FromImage(bmp);
			// --------------------------------------------------- rotate from the middle
			g.Clear(Color.White);
			g.ResetTransform();
            g.TranslateTransform(Convert.ToInt32(img.Width / 2), Convert.ToInt32(img.Height / 2));
			g.RotateTransform((float)angle);
			// --------------------------------------------------- draw centered
			g.DrawImage(img, Convert.ToInt32(-bmp.Width / 2), Convert.ToInt32(-bmp.Height / 2));
			return bmp;
		}


		public static void ImageRotateInPlace(ref Image img, double angle)
		{
			Bitmap bmp = new Bitmap(img);
			Graphics g = Graphics.FromImage(img);
			// --------------------------------------------------- rotate from the middle
			g.Clear(Color.White);
			g.ResetTransform();
			g.TranslateTransform(Convert.ToInt32(bmp.Width / 2), Convert.ToInt32(bmp.Height / 2));
			g.RotateTransform((float)angle);
			// --------------------------------------------------- draw centered
			g.DrawImage(bmp, Convert.ToInt32(-img.Width / 2), Convert.ToInt32(-img.Height / 2));
		}


		public static void ImageRotateWithPositions(ref Image img, ref Image DestImage, double angle, double RotX, double RotY, double DrawX, double DrawY)
		{
			Graphics g = Graphics.FromImage(DestImage);
			SetQuality(g, 2);
			// --------------------------------------------------- rotate point
			g.Clear(Color.White);
			g.ResetTransform();
			g.TranslateTransform((float)RotX, (float)RotY);
			g.RotateTransform((float)angle);
			// --------------------------------------------------- draw point
			g.DrawImage(img, -(float)DrawX, -(float)DrawY);
		}


		private static void SetQuality(Graphics g, Int32 nQuality)
		{
			switch (nQuality) {
				case 1:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.NearestNeighbor;
					break;
				case 2:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.Low;
					break;
				case 3:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.Bilinear;
					break;
				case 4:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.HighQualityBilinear;
					break;
				case 5:
					g.CompositingQuality = CompositingQuality.HighQuality;
					g.SmoothingMode = SmoothingMode.HighQuality;
					g.InterpolationMode = InterpolationMode.NearestNeighbor;
					break;
				case 6:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.Bicubic;
					break;
				case 7:
					g.CompositingQuality = CompositingQuality.HighQuality;
					g.SmoothingMode = SmoothingMode.HighQuality;
					g.InterpolationMode = InterpolationMode.Bicubic;
					break;
				case 8:
					g.CompositingQuality = CompositingQuality.HighQuality;
					g.SmoothingMode = SmoothingMode.HighQuality;
					g.InterpolationMode = InterpolationMode.HighQualityBilinear;
					break;
				case 9:
					g.CompositingQuality = CompositingQuality.HighQuality;
					g.SmoothingMode = SmoothingMode.HighQuality;
					g.InterpolationMode = InterpolationMode.HighQualityBicubic;
					break;
				// --------------------------------------------------------------- ( zero or > 9 ) 
				default:
					g.CompositingQuality = CompositingQuality.HighSpeed;
					g.SmoothingMode = SmoothingMode.HighSpeed;
					g.InterpolationMode = InterpolationMode.Low;
					break;
			}
		}


		public static Image ImageResize(ref Image img, int w, int h, Int32 quality)
		{
			Bitmap bmp = new Bitmap(w, h);
			Graphics g = Graphics.FromImage(bmp);
			SetQuality(g, quality);
			g.DrawImage(img, 0, 0, w + 1, h + 1);
			return bmp;
		}


		//Friend Sub ImageResizeInPlace(ByRef img As Image, ByVal w As Integer, ByVal h As Integer, ByVal quality As Int32)
		//    If img Is Nothing Then Exit Sub
		//    Dim bmp As New Bitmap(w, h)
		//    Dim g As Graphics = Graphics.FromImage(bmp)
		//    SetQuality(g, quality)
		//    g.DrawImage(img, 0, 0, w + 1, h + 1)
		//    img = bmp
		//End Sub


		public static void ImageScrollInPlace( Image img, int dx, int dy, int quality)
		{
			if (img == null) return;
 
			Bitmap bmp = new Bitmap(img.Width, img.Height);
			Graphics g = Graphics.FromImage(bmp);
			SetQuality(g, quality);
			g.DrawImage(img, dx, dy);
			img = bmp;
		}


        public static void PictureScrollInPlace(PictureBox pbox, int dx, int dy, int quality)
        {
            // ------------------------------------------------ using a bitmap for best performance
            if (pbox.Image == null)
            {
                Module_ImageFilters.InitPictureboxImage(pbox);
            }
            Bitmap bmp = new Bitmap(pbox.Image.Width, pbox.Image.Height);
            Graphics g = Graphics.FromImage(bmp);
            SetQuality(g, quality);
            g.DrawImage(pbox.Image, dx, dy);
            pbox.Image = bmp;
        }

	}
}
