using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;
namespace Theremino_HAL
{

	public static class Module_SaveLoad
	{
  
        public static string ApplicationName
        {
            get
            {
                var entryAssembly = Assembly.GetEntryAssembly();
                var applicationTitle = ((AssemblyTitleAttribute)entryAssembly.GetCustomAttributes(typeof(AssemblyTitleAttribute), false)[0]).Title;
                if (string.IsNullOrEmpty(applicationTitle))
                {
                    applicationTitle = entryAssembly.GetName().Name;
                }
                return applicationTitle;
            }
        } 

		public static bool EventsAreEnabled = false;
		//Friend Form1_VisibleAtStart As Boolean

		public static bool Form2_VisibleAtStart;

		// =======================================================================================================
		//   APP TITLE AND VERSION
		// =======================================================================================================
        public static string AppTitleAndVersion([System.Runtime.InteropServices.OptionalAttribute, System.Runtime.InteropServices.DefaultParameterValueAttribute("")]  // ERROR: Optional parameters aren't supported in C#
string Title)
		{
            if (string.IsNullOrEmpty(Title)) Title = ApplicationName.Replace('_', ' '); 
			string[] s = Theremino_HAL.My.MyProject.Application.Info.Version.ToString().Split('.');
            String str;
            str = Title + " - V" + s[0] + "." + s[1];
            if (s[2] != "0") str += "." + s[2];
            if (s[3] != "0") str += "." + s[3];
            return str;
		}

        //  =======================================================================================
        //    FILES
        //  =======================================================================================
        public static bool FileExists(string fileName)
        {
            return System.IO.File.Exists(fileName);
        }



		// =======================================================================================
		//  FORM
		// =======================================================================================
        public static void LimitFormPosition(System.Windows.Forms.Form f)
		{
            if (f == null) return;
			if (f.WindowState != FormWindowState.Normal) return; 
			GetMaxScreenBounds();
			EnsureFormVisible(f);
            //EnsureFormCompletelyVisible(f);
		}

        private static Rectangle SB = new Rectangle(int.MaxValue, int.MaxValue, int.MinValue, int.MinValue);
        private static void GetMaxScreenBounds()
        {
	        foreach (Screen s in System.Windows.Forms.Screen.AllScreens) 
            {
		        SB = Rectangle.Union(SB, s.WorkingArea);
	        }
        }

        //private static void EnsureFormCompletelyVisible(Form f)
        //{
        //    f.Width = Math.Min(f.Width, SB.Width);              // not more than dimensions of a maximized window
        //    f.Height = Math.Min(f.Height, SB.Height);           // not more than dimensions of a maximized window
        //    f.Width = Math.Max(f.Width, 32);                    // at least 32x24
        //    f.Height = Math.Max(f.Height, 24);                  // at least 32x24
        //    f.Left = Math.Min(f.Left, SB.Right - f.Width);      // not beyond the right border
        //    f.Top = Math.Min(f.Top, SB.Bottom - f.Height);      // not beyond the bottom border
        //    f.Left = Math.Max(f.Left, SB.Left);                 // at least at the left border
        //    f.Top = Math.Max(f.Top, SB.Top);                    // at least at the top border
        //}

        private static void EnsureFormVisible(Form f)
        {
            f.Width = Math.Min(f.Width, SB.Width);              // not more than the VIRTUALSCREEN dimensions
            f.Height = Math.Min(f.Height, SB.Height);           // not more than the VIRTUALSCREEN dimensions 
            f.Width = Math.Max(f.Width, 32);                    // at least 32x24
            f.Height = Math.Max(f.Height, 24);                  // at least 32x24
            f.Left = Math.Min(f.Left, SB.Right - 50);           // not beyond the right border - 50 pixels
            f.Top = Math.Min(f.Top, SB.Bottom - 100);           // not beyond the bottom border - 50 pixels
            f.Left = Math.Max(f.Left, SB.Left + 100 - f.Width); // at least at the left border + 50 pixels
            f.Top = Math.Max(f.Top, SB.Top - 10);               // at least at the top border
        }


		// (The value of the RestoreBounds property is valid only 
		//   when the WindowState property of the Form class is not equal to Normal)
		public static Rectangle GetFormRectangle(Form frm)
		{
			Rectangle r = default(Rectangle);
			if (frm.WindowState == FormWindowState.Normal) {
				r = frm.Bounds;
			}
			else {
				r = frm.RestoreBounds;
			}
			return r;
		}

        public static void LimitComboDropDownHeight(ref CustomControlsLib.MyComboBox cmb)
        {
            // ---------------------------------------------------- get screen height
            Int32 screenHeight;
            screenHeight = Screen.PrimaryScreen.Bounds.Height;
            // ---------------------------------------------------- get required height
            Int32 h = cmb.ItemHeight * cmb.Items.Count;
            // ---------------------------------------------------- get screen positions
            Int32 yUp = cmb.PointToScreen(cmb.ClientRectangle.Location).Y;
            Int32 yDown = yUp + cmb.Height;
            // ---------------------------------------------------- set the combo height
            if (yDown + h > screenHeight - 1 & yUp - h < 4)
            {
                cmb.DropDownHeight = yUp - 4;
            }
            else
            {
                cmb.DropDownHeight = 999;
            }
        }


		// ================================================================================================
		//  Private Read-Write functions
		// ================================================================================================
		private static string TabString(string Name, double Value, string fmt)
		{
			Int32 nTab = Math.Max(0, 22 - Name.Length);
			if (double.IsNaN(Value)) {
				return Name;
			}
			else {
				return Name + "=" + Strings.StrDup(nTab, " ") + Value.ToString(fmt);
			}
		}

		private static string TabString(string Name, bool Value)
		{
			Int32 nTab = Math.Max(0, 22 - Name.Length);

			return Name + "=" + Strings.StrDup(nTab, " ") + Value.ToString();
		}

		private static string TabString(string Name, string Value)
		{
			Int32 nTab = Math.Max(0, 22 - Name.Length);

			return Name + "=" + Strings.StrDup(nTab, " ") + Value;
		}

		private static float Val_Single(string l)
		{
			return (float)Conversion.Val(l.Replace(",", "."));
		}

		private static double Val_Double(string l)
		{
			return Conversion.Val(l.Replace(",", "."));
		}

		private static Int32 Val_Int(string l)
		{
			return Convert.ToInt32(Conversion.Val(l));
		}

		public static string ExtractParamName(ref string s)
		{
			string functionReturnValue = null;
			// ------------------------- Returns the first field from begin to the first "=" symbol
			// -------------------------  and removes it from the string
			int i = 0;
			i = Strings.InStr(s, "=", Microsoft.VisualBasic.CompareMethod.Binary);
			if (i > 0) {
				functionReturnValue = Strings.Trim(Strings.Left(s, i - 1));
				s = Strings.Trim(Strings.Mid(s, i + 1));
			}
			else {
				functionReturnValue = Strings.Trim(s);
				s = "";
			}
			return functionReturnValue;
		}

		private static string AssemblyName()
		{
			return System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
		}


		// ==================================================================================================
		//  SAVE LOAD -- Program INI
		// ==================================================================================================
        public static void Save_INI()
		{
            string iniFileName = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\" + AssemblyName() + "_INI.txt", "");
			System.IO.StreamWriter f = null;
            try
            {
                f = System.IO.File.CreateText(iniFileName);
                //
                f.WriteLine("");
                f.WriteLine("===========================================");
                f.WriteLine(" Program Params");
                f.WriteLine("===========================================");
                // ------------------------------------------------------------------------------ FORM BOUNDS
                Rectangle r = default(Rectangle);
                r = GetFormRectangle(My.MyProject.Forms.Form1);
                f.WriteLine(TabString("Form1_Top", r.Top, ""));
                f.WriteLine(TabString("Form1_Left", r.Left, ""));
                f.WriteLine(TabString("Form1_Width", r.Width, ""));
                f.WriteLine(TabString("Form1_Height", r.Height, ""));
                f.WriteLine(TabString("Form1_WindowState", (int)My.MyProject.Forms.Form1.WindowState, ""));
                //f.WriteLine(TabString("Form1_VisibleAtStart", My.MyProject.Forms.Form1.Visible And My.MyProject.Forms.Form1.WindowState <> FormWindowState.Minimized))

                r = GetFormRectangle(My.MyProject.Forms.Form2);
                f.WriteLine(TabString("Form2_Top", r.Top, ""));
                f.WriteLine(TabString("Form2_Left", r.Left, ""));
                f.WriteLine(TabString("Form2_Width", r.Width, ""));
                f.WriteLine(TabString("Form2_Height", r.Height, ""));
                f.WriteLine(TabString("Form2_VisibleAtStart", My.MyProject.Forms.Form2.Visible & My.MyProject.Forms.Form2.WindowState != FormWindowState.Minimized));
                //
                f.WriteLine("");
                f.WriteLine(TabString("Language", Utils_LocaleNames.Language));
                f.WriteLine(TabString("Reconnect", My.MyProject.Forms.Form1.btn_Reconnect.Checked));
                f.WriteLine(TabString("MinChange", My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger, ""));
                f.WriteLine(TabString("BeepOnErrors", My.MyProject.Forms.Form1.ToolStripButton_BeepOnErrors.Checked));
                f.WriteLine(TabString("Lock", My.MyProject.Forms.Form1.ToolStripButton_Lock.Checked));
                //
                f.WriteLine(TabString("SelectedPinListLine", My.MyProject.Forms.Form2.SelectedPinListLine, ""));
                f.WriteLine(TabString("AlternatePinListLine", My.MyProject.Forms.Form2.AlternatePinListLine, ""));
                f.WriteLine(TabString("Scope_ShowRawCount", My.MyProject.Forms.Form2.btn_ShowRawCount.Checked));       
                f.WriteLine(TabString("Scope_UnitsPerDivision", My.MyProject.Forms.Form2.cmb_UnitsPerDivision.SelectedIndex, ""));        
                f.WriteLine(TabString("Scope_ScrollSpeed", My.MyProject.Forms.Form2.cmb_ScrollSpeed.SelectedIndex, ""));
                f.WriteLine(TabString("Scope_ScaleMax", My.MyProject.Forms.Form2.txt_ScaleMax.Text));
                f.WriteLine(TabString("Scope_ScaleMin", My.MyProject.Forms.Form2.txt_ScaleMin.Text));
                //
                f.WriteLine("");
                foreach (string s in ValidMasterNames)
                {
                    f.WriteLine(TabString("ValidMasterName", s));
                }
            }
            catch
            {
            }
            try
            {
                f.Close();
            }
            catch
            {
            }
		}

        public static void Load_INI()
		{
            // ReDimStatement is not supported in C# 
            ThereminoSystem.ConfigDatabase = new object[0]; 
			//
            ValidMasterNames= new string[0];
			// ------------------------------------------------------------- defaults
			//Form1_VisibleAtStart = True
			My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger = 30;
            My.MyProject.Forms.Form2.cmb_ScrollSpeed.SelectedIndex = 1;
            My.MyProject.Forms.Form2.cmb_UnitsPerDivision.SelectedIndex = 0;
			// -------------------------------------------------------------
		    string l = null;
            string iniFileName = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\" + AssemblyName() + "_INI.txt", "");
            if (Theremino_HAL.My.MyProject.Computer.FileSystem.FileExists(iniFileName))
            {
                //
                System.IO.StreamReader f = null;
                // ---------------------------------------------------------------------
                //  In C# it is not possible to implement a true "On Error Resume Next"
                //  So we use "try catch" that is slightly worse
                //  If there is an error, all the subsequent parameters are loosed
                // ---------------------------------------------------------------------
                try
                {
                    f = System.IO.File.OpenText(iniFileName);
                    //
                    while (!f.EndOfStream)
                    {
                        l = f.ReadLine();
                        switch (ExtractParamName(ref l))
                        {
                            case "Form1_Top":
                                My.MyProject.Forms.Form1.Top = Val_Int(l);
                                break;
                            case "Form1_Left":
                                My.MyProject.Forms.Form1.Left = Val_Int(l);
                                break;
                            case "Form1_Width":
                                My.MyProject.Forms.Form1.Width = Val_Int(l);
                                break;
                            case "Form1_Height":
                                My.MyProject.Forms.Form1.Height = Val_Int(l);
                                break;
                            case "Form1_WindowState":
                                My.MyProject.Forms.Form1.WindowState = (FormWindowState)(Conversion.Val(l));
                                My.MyProject.Forms.Form1.Refresh();
                                break;
                            //Case "Form1_VisibleAtStart" : Form1_VisibleAtStart = l = "True"
                            //
                            case "Form2_Top":
                                My.MyProject.Forms.Form2.Top = Val_Int(l);
                                break;
                            case "Form2_Left":
                                My.MyProject.Forms.Form2.Left = Val_Int(l);
                                break;
                            case "Form2_Width":
                                My.MyProject.Forms.Form2.Width = Val_Int(l);
                                break;
                            case "Form2_Height":
                                My.MyProject.Forms.Form2.Height = Val_Int(l);
                                break;
                            case "Form2_VisibleAtStart":
                                Form2_VisibleAtStart = l == "True";
                                break;
                            //
                            case "Language":
                                Utils_LocaleNames.Language = l;
                                break;
                            case "Reconnect":
                                My.MyProject.Forms.Form1.btn_Reconnect.Checked = l == "True";
                                break;
                            case "MinChange":
                                My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger = Val_Int(l);
                                break;
                            case "BeepOnErrors":
                                My.MyProject.Forms.Form1.ToolStripButton_BeepOnErrors.Checked = l == "True";
                                break;
                            case "Lock":
                                My.MyProject.Forms.Form1.ToolStripButton_Lock.Checked = l == "True";
                                break;
                            case "SelectedPinListLine":
                                My.MyProject.Forms.Form2.SelectedPinListLine = Val_Int(l);
                                break;
                            case "AlternatePinListLine":
                                My.MyProject.Forms.Form2.AlternatePinListLine = Val_Int(l);
                                break;
                            case "Scope_ShowRawCount":
                                My.MyProject.Forms.Form2.btn_ShowRawCount.Checked = l == "True";
                                break;
                            case "Scope_UnitsPerDivision":
                                Module_Utils.Combo_SetIndex(My.MyProject.Forms.Form2.cmb_UnitsPerDivision, Val_Int(l));
                                break;
                            case "Scope_ScrollSpeed":
                                Module_Utils.Combo_SetIndex(My.MyProject.Forms.Form2.cmb_ScrollSpeed, Val_Int(l));
                                break;
                            case "Scope_ScaleMax":
                                My.MyProject.Forms.Form2.txt_ScaleMax.Text = l;
                                break;
                            case "Scope_ScaleMin":
                                My.MyProject.Forms.Form2.txt_ScaleMin.Text = l;
                                break;
                            case "ValidMasterName":
                                Array.Resize(ref ValidMasterNames, ValidMasterNames.Length + 1);
                                ValidMasterNames[ValidMasterNames.Length - 1] = l;
                                break;
                        }
                    }
                }
                catch
                {
                }
                try
                {
                    f.Close();
                }
                catch
                {
                }
            }
            //
			{
				if (My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger < 0) My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger = 0; 
				if (My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger > 100) My.MyProject.Forms.Form1.txt_MinChange.NumericValueInteger = 100; 
			}
			//
            LimitFormPosition(My.MyProject.Forms.Form1);
            LimitFormPosition(My.MyProject.Forms.Form2);
		}


        // ==================================================================================================
        //  Valid Master Names
        // ==================================================================================================
        public static string[] ValidMasterNames;
        public static void ValidMasterNames_Reset()
        {
            ValidMasterNames = new string[0];
        }
        public static void ValidMasterNames_Init()
        {
            ValidMasterNames = new string[0];
            foreach (Master m in ThereminoSystem.Masters)
            {
                Array.Resize(ref ValidMasterNames, ValidMasterNames.Length + 1);
                ValidMasterNames[ValidMasterNames.Length - 1] = m.GetName();
            }
        }


		// ==================================================================================================
		//  SAVE LOAD -- Configurations
		// ==================================================================================================
        private static object SaveLoadConfigLocker = new object();

        public static void Save_ConfigDatabase()
		{
            lock (SaveLoadConfigLocker)
            {
                string tempFileName = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\" + 
                                                                         AssemblyName() + "_ConfigTemp.txt", "");
                string iniFileName = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\" + 
                                                                        AssemblyName() + "_ConfigDatabase.txt", "");
			    System.IO.StreamWriter f = null;
                f = System.IO.File.CreateText(tempFileName);
                //
                try
                {
                    for (Int32 c = 0; c <= ThereminoSystem.ConfigDatabase.Length - 1; c++)
                    {
                        string[] config = ThereminoSystem.ConfigDatabase[c] as string[];
                        AlignConfigurationSpacing(ref config);
                        f.WriteLine("");
                        f.WriteLine("Component  Name                Param1    Param2    Param3    Param4    Param5    Param6    Param7    Param8");
                        f.WriteLine("-----------------------------------------------------------------------------------------------------------");
                        for (Int32 i = 0; i <= config.Length - 1; i++)
                        {
                            f.WriteLine(config[i]);
                        }
                        f.WriteLine("");
                    }
                    f.Close();
                    Theremino_HAL.My.MyProject.Computer.FileSystem.CopyFile(tempFileName, iniFileName, true);
                    Theremino_HAL.My.MyProject.Computer.FileSystem.DeleteFile(tempFileName);
                }
                catch
                {
                }
            }
		}

        public static Int32[] SpacingTabs = new Int32[] { 10, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130};
		private static void AlignConfigurationSpacing(ref string[] config)
		{
			string[] sa = null;
			for (Int32 i = 0; i <= config.Length - 1; i++) {
				sa = config[i].Split(',');
				config[i] = sa[0].Trim();
				for (Int32 j = 1; j <= sa.Length - 1; j++) {
                    config[i] += "," + Strings.StrDup(Math.Max(0, Module_SaveLoad.SpacingTabs[j - 1] - config[i].Length), " ") + sa[j].Trim();
				}
			}
		}

        public static void Load_ConfigDatabase()
		{
            lock (SaveLoadConfigLocker)
            {
                ThereminoSystem.ConfigDatabase = new object[0];
                string[] Config = new string[-1 + 1];
                // ------------------------------------------------------------- 
                string l = null;
                string iniFileName = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\" + AssemblyName() + "_ConfigDatabase.txt", "");
                if (Theremino_HAL.My.MyProject.Computer.FileSystem.FileExists(iniFileName))
                {
                    System.IO.StreamReader f = null;
                    f = System.IO.File.OpenText(iniFileName);
                    try
                    {
                        while (!f.EndOfStream)
                        {
                            l = f.ReadLine();
                            if (!string.IsNullOrEmpty(l))
                            {
                                // ------------------------------------- store the previous configuration
                                if (l.StartsWith("Master,"))
                                {
                                    ThereminoSystem.AddToConfigDatabase(Config);
                                    Config = new string[-1 + 1];
                                }
                                if (l.StartsWith("Master,") | l.StartsWith("Slave,") | l.StartsWith("Pin,"))
                                {
                                    Array.Resize(ref Config, Config.Length + 1);
                                    Config[Config.Length - 1] = l;
                                }
                            }
                        }
                        f.Close();
                        // --------------------------------------------- store the last collected configuration
                        ThereminoSystem.AddToConfigDatabase(Config);
                    }
                    catch
                    {
                    }
                }
            }
		}

        // ==============================================================================================================
        //   Slot Names
        // ==============================================================================================================
        public static string[] SlotNames = new string[1000];
        public static void LoadSlotNames()
        {
            Array.Clear(SlotNames, 0, 999);
            string l;
            Int32 slot;
            string fname = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\SlotNames.txt", "");

            if (Theremino_HAL.My.MyProject.Computer.FileSystem.FileExists(fname))
            {
                System.IO.StreamReader f = null;
                f = System.IO.File.OpenText(fname);
                    //
                    while (!f.EndOfStream)
                    {
                        l = RemoveComments(f.ReadLine());
                        l = l.Replace("\t", " ").Trim();
                        Int32 i = l.IndexOf(" ");
                        if (i > 0)
                        {
                            slot = (int)Conversion.Val(l.Substring(0, i));
                            SlotNames[slot] = l.Substring(i).Trim();
                        }
                    }

                f.Close();
            }
        }

        public static string RemoveComments(string s)
        {
            Int32 i = s.IndexOf("'");
            if (i > 0) s = s.Remove(i).TrimEnd();
            if (i == 0) s = "";
            return s;
        }

	}
}

