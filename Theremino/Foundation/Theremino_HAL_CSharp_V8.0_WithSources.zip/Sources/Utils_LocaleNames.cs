﻿using System;
using System.Windows.Forms;

namespace Theremino_HAL
{
    static class Utils_LocaleNames
    {
        internal static string Language = "English";
        private static string[,] ls = new string [1,0];

        internal static void SetLocales()
        {
            //  ------------------------------------- read the file
            ReadLocaleFile();
            //  ------------------------------------- rename
            RenameControls(My.MyProject.Forms.Form1);
            RenameControls(My.MyProject.Forms.Form2);
            //  ------------------------------------- release the array
            Module_Utils.RedimPreserve_2D_Array(ref ls, -1, -1);
        }

        private static void ReadLocaleFile()
        {
            string LangName = Utils_LocaleNames.Language.Substring(0, 3).ToUpper().Replace("JAP", "JPN");
            string locfilename = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\Docs\\Language_" + LangName + ".txt", "");
            if (!Module_SaveLoad.FileExists(locfilename))
            {
                locfilename = Theremino.PlatformAdjustedFileName(Application.StartupPath + "\\Docs\\Language_ENG.txt", "");
            }
            if (Module_SaveLoad.FileExists(locfilename))
            {
                Int32 i = -1;
                string s0;
                string s1;
                // 
                System.IO.StreamReader f;
                f = new System.IO.StreamReader(locfilename, System.Text.Encoding.Default);
                //
				while (!f.EndOfStream) 
                {
                    s1 = f.ReadLine();
                    s1 = s1.Replace('\t', ' ').Trim();
                    s0 = Module_SaveLoad.ExtractParamName(ref s1);
                    if (((s0.Length > 1) && (s1.Length > 1)))
                    {
                        if (s0.StartsWith("Msg_"))
                        {
                            AddMessage(s0, s1);
                        }
                        else
                        {
                            i++;
                            Module_Utils.RedimPreserve_2D_Array(ref ls, 1, i);
                            ls[0, i] = s0;
                            ls[1, i] = s1;
                        }
                    }
                }
                f.Close();
            }
        }

        private static void RenameControls(Control container)
        {
            // 
            for (Int32 i = 0; (i <= (ls.GetLength(1) - 1)); i++)
            {
                if ((container.Name == ls[0, i]))
                {
                    container.Text = ls[1, i];
                }
            }
            // 
            foreach (Control ctrl in container.Controls)
            {
                for (Int32 i = 0; (i <= (ls.GetLength(1) - 1)); i++)
                {
                    if ((ctrl.Name == ls[0, i]))
                    {
                        ctrl.Text = ls[1, i];
                    }
                    if (ctrl is ToolStrip)
                    {
                        ToolStrip ts = (ToolStrip)ctrl;
                        RenameToolStripItems(ref ts);
                    }
                    if (ctrl is MenuStrip)
                    {
                        MenuStrip ms = (MenuStrip)ctrl;
                        RenameMenuStripItems(ref ms);
                    }
                }
                //  ---------------------------- Recursively call this function for any container controls.
                if (container.HasChildren)
                {
                    RenameControls(ctrl);
                }
            }
        }

        private static void RenameToolStripItems(ref ToolStrip ts)
        {
            for (Int32 i = 0; (i <= (ls.GetLength(1) - 1)); i++)
            {
                for (Int32 j = 0; (j <= (ts.Items.Count - 1)); j++)
                {
                    if ((ts.Items[j].Name == ls[0, i]))
                    {
                        ts.Items[j].Text = (" " + ls[1, i]);
                    }
                }
            }
        }

        private static void RenameMenuStripItems(ref MenuStrip ms)
        {
            for (Int32 i = 0; (i <= (ls.GetLength(1) - 1)); i++)
            {
                for (Int32 j = 0; (j <= (ms.Items.Count - 1)); j++)
                {
                    if ((ms.Items[j].Name == ls[0, i]))
                    {
                        ms.Items[j].Text = (" " + ls[1, i]);
                    }
                    ToolStripMenuItem tsmi = (ToolStripMenuItem)ms.Items[j];
                    for (Int32 k = 0; (k <= (tsmi.DropDownItems.Count - 1)); k++)
                    {
                        if ((tsmi.DropDownItems[k].Name == ls[0, i]))
                        {
                            tsmi.DropDownItems[k].Text = (" " + ls[1, i]);
                        }
                    }
                }
            }
        }
        
        // ===============================================================================================
        //  MESSAGES
        // ===============================================================================================
        internal static string Msg_CommSpeed1 = " Communication speed";

        internal static string Msg_MinChange1 = " Sensitivity to movements";
        internal static string Msg_MinChange2 = " - - - - - - - - - - - - - - - - -";
        internal static string Msg_MinChange3 = " 100 = large movements";
        internal static string Msg_MinChange4 = "   30 = normal";
        internal static string Msg_MinChange5 = "   10 = little movements";
        internal static string Msg_MinChange6 = "    0 = autocalibrate disabled";

        internal static string Msg_CapArea1 = " Approximate area of the sensor";
        internal static string Msg_CapArea2 = " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -";
        internal static string Msg_CapArea3 = " The linearity between zones 'Away' and 'Close' can be altered";
        internal static string Msg_CapArea4 = " setting a value-area more or less than the real one.";
        internal static string Msg_CapArea5 = " - A greater value compresses the 'far' area.";
        internal static string Msg_CapArea6 = " - A smaller value expands the 'far' area.";
        internal static string Msg_CapArea7 = " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -";
        internal static string Msg_CapArea8 = " With ZERO the C_tot value is used, instead of calculated value.";

        internal static string Msg_Filter1 = " Pressing this button the IIR filter becomes adaptive";
        internal static string Msg_Filter2 = " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -";
        internal static string Msg_Filter3 = " The IIR filter adapts itself to obtain a higher reactivity";
        internal static string Msg_Filter4 = " for wide variations and greater damping for minor changes.";
        internal static string Msg_Filter5 = " You get a good digits stability, without sacrificing the settling time.";

        internal static string Msg_Validate1  = " Validates a configuration after hardware changes";
        internal static string Msg_BeepOnErrors1  = " Make a beep for each serial error";
        internal static string Msg_Lock1 = " If pressed the HAL will connect only Masters with names actually listed";
        internal static string Msg_Lock2 = " (refer to the last pages of the help)";
        internal static string Msg_Disconnect1  = " Disconnect the selected Master";

        internal static string Msg_Warning = " WARNING";
        internal static string Msg_HalMessage = " Message from Theremino HAL";
        internal static string Msg_StepperWithAdc24 = " The Adc24 module performs poorly if, in the same Master, you enable also Stepper channels.";

        internal static string Msg_Validate2= " The configuration does not match the connected hardware.";
        internal static string Msg_Validate3= " Check the hardware and connections and try again with the 'Validate' button.";
        internal static string Msg_Validate4= " Or choose a valid configuration changing the 'Master Name'";
        internal static string Msg_Validate5= " Or replace the previous configuration with the current one, by pressing 'Valid'.";

        internal static string Msg_Duplicate1 = " There are two Master Modules with the same name.";
        internal static string Msg_Duplicate2 = " Please select the first Master and choose another name.";

        internal static string Msg_MaxValue = "Max value";
        internal static string Msg_MinValue = "Min value";
        internal static string Msg_MaxValueStepper = "1000 means mm";
        internal static string Msg_MinValueStepper = "zero means mm";
        internal static string Msg_PwmProps = "PWM properties";
        internal static string Msg_ServoProps = "Servo properties";
        internal static string Msg_UsoundProps = "UltraSound properties";
        internal static string Msg_CapSensorProps = "Cap sensor properties";


        private static void AddMessage(string s0, string s1)
        {
            switch (s0)
            {
                case "Msg_CommSpeed1": Msg_CommSpeed1 = s1; break;

                case "Msg_MinChange1": Msg_MinChange1 = s1; break;
                case "Msg_MinChange2": Msg_MinChange2 = s1; break;
                case "Msg_MinChange3": Msg_MinChange3 = s1; break;
                case "Msg_MinChange4": Msg_MinChange4 = s1; break;
                case "Msg_MinChange5": Msg_MinChange5 = s1; break;
                case "Msg_MinChange6": Msg_MinChange6 = s1; break;

                case "Msg_CapArea1": Msg_CapArea1 = s1; break;
                case "Msg_CapArea2": Msg_CapArea2 = s1; break;
                case "Msg_CapArea3": Msg_CapArea3 = s1; break;
                case "Msg_CapArea4": Msg_CapArea4 = s1; break;
                case "Msg_CapArea5": Msg_CapArea5 = s1; break;
                case "Msg_CapArea6": Msg_CapArea6 = s1; break;
                case "Msg_CapArea7": Msg_CapArea7 = s1; break;
                case "Msg_CapArea8": Msg_CapArea8 = s1; break;

                case "Msg_Filter1": Msg_Filter1 = s1; break;
                case "Msg_Filter2": Msg_Filter2 = s1; break;
                case "Msg_Filter3": Msg_Filter3 = s1; break;
                case "Msg_Filter4": Msg_Filter4 = s1; break;
                case "Msg_Filter5": Msg_Filter5 = s1; break;

                case "Msg_Validate1": Msg_Validate1 = s1; break;
                case "Msg_BeepOnErrors1": Msg_BeepOnErrors1 = s1; break;
                case "Msg_Lock1": Msg_Lock1 = s1; break;
                case "Msg_Lock2": Msg_Lock2 = s1; break;
                case "Msg_Disconnect1": Msg_Disconnect1 = s1; break;

                case "Msg_Warning": Msg_Warning = s1; break;
                case "Msg_HalMessage": Msg_HalMessage = s1; break;
                case "Msg_StepperWithAdc24": Msg_StepperWithAdc24 = s1; break;

                case "Msg_Validate2": Msg_Validate2 = s1; break;
                case "Msg_Validate3": Msg_Validate3 = s1; break;
                case "Msg_Validate4": Msg_Validate4 = s1; break;
                case "Msg_Validate5": Msg_Validate5 = s1; break;

                case "Msg_Duplicate1": Msg_Duplicate1 = s1; break;
                case "Msg_Duplicate2": Msg_Duplicate2 = s1; break;

                case "Msg_MaxValue" : Msg_MaxValue = s1; break;
                case "Msg_MinValue" : Msg_MinValue = s1; break;
                case "Msg_MaxValueStepper" : Msg_MaxValueStepper = s1; break;
                case "Msg_MinValueStepper" : Msg_MinValueStepper = s1; break;
                case "Msg_PwmProps" : Msg_PwmProps = s1; break;
                case "Msg_ServoProps" : Msg_ServoProps = s1; break;
                case "Msg_UsoundProps" : Msg_UsoundProps = s1; break;
                case "Msg_CapSensorProps": Msg_CapSensorProps = s1; break;
            }
        }

    }

}

