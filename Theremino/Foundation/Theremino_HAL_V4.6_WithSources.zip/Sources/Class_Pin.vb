﻿
Imports System.Globalization
Imports System.Math
Imports System.Collections.Generic


' ==================================================================================================
'   CLASS PIN
' ==================================================================================================
Class Pin

    Friend Enum Directions As Int32
        Unused = 0
        HostToMaster = 1
        MasterToHost = 2
    End Enum


    Friend Enum PinTypes As Int32
        UNUSED = 0

        DIG_OUT = 1
        PWM_8 = 2
        PWM_16 = 3
        SERVO_8 = 4
        SERVO_16 = 5

        DIG_IN = 129
        DIG_IN_PU = 130

        ADC_8 = 131
        ADC_16 = 132
        CAP_8 = 133
        CAP_16 = 134
        RES_8 = 135
        RES_16 = 136

        COUNTER = 140
        COUNTER_PU = 141

        FAST_COUNTER = 142
        FAST_COUNTER_PU = 143

        PERIOD = 144
        PERIOD_PU = 145

        USOUND_SENSOR = 150

        CAP_SENSOR = 160

        I2C_SDA = 170
        I2C_SCL = 171

        MCA_8_BYTES = 180
        MCA_16_BYTES = 181
        MCA_32_BYTES = 182

        SNIFFER = 190
    End Enum


    Friend Shared Function StringToPinType(ByVal PinTypeString As String) As PinTypes
        Select Case UCase(PinTypeString.Trim)
            Case "UNUSED" : Return PinTypes.UNUSED

            Case "DIG_OUT" : Return PinTypes.DIG_OUT
            Case "PWM_8" : Return PinTypes.PWM_8
            Case "PWM_16" : Return PinTypes.PWM_16
            Case "SERVO_8" : Return PinTypes.SERVO_8
            Case "SERVO_16" : Return PinTypes.SERVO_16

            Case "DIG_IN" : Return PinTypes.DIG_IN
            Case "DIG_IN_PU" : Return PinTypes.DIG_IN_PU

            Case "ADC_8" : Return PinTypes.ADC_8
            Case "ADC_16" : Return PinTypes.ADC_16
            Case "CAP_8" : Return PinTypes.CAP_8
            Case "CAP_16" : Return PinTypes.CAP_16
            Case "RES_8" : Return PinTypes.RES_8
            Case "RES_16" : Return PinTypes.RES_16

            Case "COUNTER" : Return PinTypes.COUNTER
            Case "COUNTER_PU" : Return PinTypes.COUNTER_PU

            Case "FAST_COUNTER" : Return PinTypes.FAST_COUNTER
            Case "FAST_COUNTER_PU" : Return PinTypes.FAST_COUNTER_PU

            Case "PERIOD" : Return PinTypes.PERIOD
            Case "PERIOD_PU" : Return PinTypes.PERIOD_PU

            Case "USOUND_SENSOR" : Return PinTypes.USOUND_SENSOR

            Case "CAP_SENSOR" : Return PinTypes.CAP_SENSOR

            Case "I2C_SDA" : Return PinTypes.I2C_SDA
            Case "I2C_SCL" : Return PinTypes.I2C_SCL

            Case "MCA_8_BYTES" : Return PinTypes.MCA_8_BYTES
            Case "MCA_16_BYTES" : Return PinTypes.MCA_16_BYTES
            Case "MCA_32_BYTES" : Return PinTypes.MCA_32_BYTES

            Case "SNIFFER" : Return PinTypes.SNIFFER

                'Case "UART_TX" : Return PinTypes.UART_TX
                'Case "UART_RX" : Return PinTypes.UART_RX
                'Case "UART_CTS" : Return PinTypes.UART_CTS
                'Case "UART_RTS" : Return PinTypes.UART_RTS
                'Case "VREF_POS" : Return PinTypes.VREF_POS
                'Case "VREF_NEG" : Return PinTypes.VREF_NEG
        End Select
        Return Nothing
    End Function

    Friend Shared Function PinTypeToString(ByVal pintype As PinTypes) As String
        Dim s As String = ""
        Select Case pintype
            Case PinTypes.UNUSED : s = "UNUSED"

            Case PinTypes.DIG_OUT : s = "DIG_OUT"
            Case PinTypes.PWM_8 : s = "PWM_8"
            Case PinTypes.PWM_16 : s = "PWM_16"
            Case PinTypes.SERVO_8 : s = "SERVO_8"
            Case PinTypes.SERVO_16 : s = "SERVO_16"

            Case PinTypes.DIG_IN : s = "DIG_IN"
            Case PinTypes.DIG_IN_PU : s = "DIG_IN_PU"

            Case PinTypes.ADC_8 : s = "ADC_8"
            Case PinTypes.ADC_16 : s = "ADC_16"
            Case PinTypes.CAP_8 : s = "CAP_8"
            Case PinTypes.CAP_16 : s = "CAP_16"
            Case PinTypes.RES_8 : s = "RES_8"
            Case PinTypes.RES_16 : s = "RES_16"

            Case PinTypes.COUNTER : s = "COUNTER"
            Case PinTypes.COUNTER_PU : s = "COUNTER_PU"

            Case PinTypes.FAST_COUNTER : s = "FAST_COUNTER"
            Case PinTypes.FAST_COUNTER_PU : s = "FAST_COUNTER_PU"

            Case PinTypes.PERIOD : s = "PERIOD"
            Case PinTypes.PERIOD_PU : s = "PERIOD_PU"

            Case PinTypes.USOUND_SENSOR : s = "USOUND_SENSOR"

            Case PinTypes.CAP_SENSOR : s = "CAP_SENSOR"

            Case PinTypes.I2C_SDA : s = "I2C_SDA"
            Case PinTypes.I2C_SCL : s = "I2C_SCL"

            Case PinTypes.MCA_8_BYTES : s = "MCA_8_BYTES"
            Case PinTypes.MCA_16_BYTES : s = "MCA_16_BYTES"
            Case PinTypes.MCA_32_BYTES : s = "MCA_32_BYTES"

            Case PinTypes.SNIFFER : s = "SNIFFER"

                'Case PinTypes.UART_TX : s = "UART_TX"
                'Case PinTypes.UART_RX : s = "UART_RX"
                'Case PinTypes.UART_CTS : s = "UART_CTS"
                'Case PinTypes.UART_RTS : s = "UART_RTS"
                'Case PinTypes.VREF_POS : s = "VREF_POS"
                'Case PinTypes.VREF_NEG : s = "VREF_NEG"
        End Select

        Return CamelCaseString(s)
    End Function




    Friend MasterId As Int32
    Friend SlaveId As Int32
    Friend PinId As Int32
    Private PinType As PinTypes
    Friend Direction As Directions
    ' ------------------------------------------- slot 0 to 999 starting from the pin near to master
    Friend Slot As Int32
    ' ------------------------------------------- byte index in the USB buffer ( HostToMaster or MasterToHost )
    Friend UsbByteIndex As Int32
    ' ------------------------------------------- bytes used by this pin in the USB(Host-Master) communications
    Friend UsbBytesCount As Int32
    ' ------------------------------------------- bytes used by this pin in the COM(Master-Slave) communications
    Friend ComBytesCount As Int32

    ' ------------------------------------------- all pins
    Friend Value_RawInteger As UInt32
    Friend Value_RawInteger_Old As UInt32
    Friend Value_RawInteger_Zero As UInt32
    Friend Value_RawSmoothed As Single
    Friend Value_Integer_Max As UInt32
    Friend Value_Integer_Min As UInt32
    Friend Value As Single
    Friend Value_Max As Single
    Friend Value_Min As Single
    Friend Value_Parking As Single
    Friend Value_Normalized As Single = 0
    Friend Value_Normalized_New As Single
    Friend Value_Normalized_Zero As Single
    Friend AdaptiveSpeed As Boolean
    Friend ResponseSpeed As Int32
    Friend RepTime As Int32
    ' ------------------------------------------ Servo and Pwm specific
    Friend MaxTime As Single
    Friend MinTime As Single
    Friend LogResponse As Boolean

    ' ------------------------------------------ Counter and Period specific
    Friend ConvertToFreq As Boolean
    Friend MaxFreq As Single
    Friend MinFreq As Single

    ' ------------------------------------------ Usound_sensor and Cap_sensor specific
    Friend RemoveErrors As Boolean
    Friend Dist_mm As Single
    Friend MaxDist_mm As Single
    Friend MinDist_mm As Single

    ' ------------------------------------------ Touch specific
    Friend MinVariation As Single
    Friend ProportionalArea As Single
    Friend MeanValue As Single
    Private oldDelta1 As Single
    Private oldDelta2 As Single
    Private oldDelta3 As Single
    Private Velocity As Single

    ' ------------------------------------------ Cap_sensor specific
    Friend ErrorCounter As Int32
    Friend TimerDivision As Int32
    Friend TimerFrequencyKhz As Int32
    Friend Inductor_uh As Single
    Friend Area_cmq As Single
    '
    Friend Millisec As Single
    Friend Freq As Single
    '
    Private IntegratedFreqString As String = ""
    Private IntegratedFreq As Double
    Private IntegratedlFreqCounter As Int32
    '
    Friend Cap_serial As Double
    Friend Cap_total As Single
    Friend Cap_zero As Single
    Friend Cap_input As Single

    ' ------------------------------------------ Sniffer specific
    Friend SnifferLogEnabled As Boolean
    Private nNewSniffedBytes As Int32
    Private nSniffedBytes As Int32
    Private SnifferStatus As Int32
    Private SniffedBytes(1000) As Int32
    Private SniffedFlags(1000) As Int32
    Private SnifferLogLock As Object = New Object


    Friend Sub New(ByVal _pintype As PinTypes, _
                   ByVal _masterid As Int32, _
                   ByVal _slaveid As Int32, _
                   ByVal _pinid As Int32)

        MasterId = _masterid
        SlaveId = _slaveid
        PinId = _pinid
        RepTime = 1
        SetPinType(_pintype)
    End Sub

    Friend Function GetPinType() As PinTypes
        Return PinType
    End Function

    Friend Function GetDirectionString() As String
        Select Case Direction
            Case Pin.Directions.HostToMaster
                Return "set"
            Case Pin.Directions.MasterToHost
                Return "get"
            Case Else
                Return ""
        End Select
    End Function


    ' ==================================================================================================
    '   DEFAULTS
    ' ==================================================================================================
    Friend Sub SetPinType(ByVal _pintype As PinTypes)
        If PinType = _pintype Then Return
        PinType = _pintype
        '
        AdaptiveSpeed = False
        ResponseSpeed = 100
        ' --------------------------------------------------------- defaults
        Select Case PinType

            ' ----------------------------------------------------- outputs
            Case PinTypes.DIG_OUT
                Value_Parking = NAN_Sleep
                Value_Max = 1000
                Value_Min = 0
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.PWM_8
                Value_Parking = 0
                Value_Max = 1000
                Value_Min = 0
                MaxTime = 4000
                MinTime = 0
                LogResponse = False
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.PWM_16
                Value_Parking = 0
                Value_Max = 1000
                Value_Min = 0
                MaxTime = 4000
                MinTime = 0
                LogResponse = False
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.SERVO_8
                Value_Parking = NAN_Sleep
                Value_Max = 1000
                Value_Min = 0
                MaxTime = 2500
                MinTime = 500
                Value_Parking = 0
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.SERVO_16
                Value_Parking = NAN_Sleep
                Value_Max = 1000
                Value_Min = 0
                MaxTime = 2500
                MinTime = 500
                Value_Parking = 0
                UsbBytesCount = 2
                ComBytesCount = 2


                ' ------------------------------------------------- inputs
            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                Value_Max = 1000
                Value_Min = 0
                Value_Parking = 0
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.ADC_8
                Value_Max = 1000
                Value_Min = 0
                ResponseSpeed = 30
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.ADC_16
                Value_Max = 1000
                Value_Min = 0
                ResponseSpeed = 30
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.CAP_8
                Value_Max = 1000
                Value_Min = 0
                MinVariation = 20
                ProportionalArea = 0
                MeanValue = 0
                ResponseSpeed = 30
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.CAP_16
                Value_Max = 1000
                Value_Min = 0
                MinVariation = 20
                ProportionalArea = 0
                MeanValue = 0
                ResponseSpeed = 30
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.RES_8
                Value_Max = 1000
                Value_Min = 0
                ResponseSpeed = 30
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.RES_16
                Value_Max = 1000
                Value_Min = 0
                ResponseSpeed = 30
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.COUNTER, PinTypes.COUNTER_PU
                Value_Max = 50000000
                Value_Min = 0
                MaxFreq = 50000000
                MinFreq = 0
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.FAST_COUNTER, PinTypes.FAST_COUNTER_PU
                Value_Max = 50000000
                Value_Min = 0
                MaxFreq = 50000000
                MinFreq = 0
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.PERIOD, PinTypes.PERIOD_PU
                Value_Max = 1000
                Value_Min = 0
                MaxFreq = 1000000
                MinFreq = 0
                ResponseSpeed = 30
                UsbBytesCount = 4
                ComBytesCount = 4

            Case PinTypes.USOUND_SENSOR
                Value_Max = 1000
                Value_Min = 0
                MaxDist_mm = 1000
                MinDist_mm = 0
                ResponseSpeed = 30
                RemoveErrors = True
                UsbBytesCount = 2
                ComBytesCount = 2

            Case PinTypes.CAP_SENSOR
                TimerDivision = 65536
                TimerFrequencyKhz = 16000
                Inductor_uh = 330
                Cap_serial = 16 '11.5       ' 0 = infinite  ( normally 16 pF )
                Value_Max = 1000
                Value_Min = 0
                MaxDist_mm = 500
                MinDist_mm = 50
                ResponseSpeed = 30
                Area_cmq = 50
                UsbBytesCount = 3
                ComBytesCount = 3

            Case PinTypes.I2C_SDA
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.I2C_SCL
                UsbBytesCount = 1
                ComBytesCount = 1

            Case PinTypes.MCA_8_BYTES
                Value_Max = 65535
                Value_Min = 0
                UsbBytesCount = 8
                ComBytesCount = 8

            Case PinTypes.MCA_16_BYTES
                Value_Max = 65535
                Value_Min = 0
                UsbBytesCount = 16
                ComBytesCount = 16

            Case PinTypes.MCA_32_BYTES
                Value_Max = 65535
                Value_Min = 0
                UsbBytesCount = 32
                ComBytesCount = 32


            Case PinTypes.SNIFFER
                Value_Max = 0
                Value_Min = 0
                UsbBytesCount = 50
                ComBytesCount = 0


            Case PinTypes.UNUSED
                Value_Max = 1
                Value_Min = 0
                MaxTime = 1
                MinTime = 0
                Value_Parking = 0
                UsbBytesCount = 0
                ComBytesCount = 0

            Case Else
                PinType = PinTypes.UNUSED
                Value_Max = 1
                Value_Min = 0
                MaxTime = 1
                MinTime = 0
                Value_Parking = 0
                UsbBytesCount = 0
                ComBytesCount = 0

        End Select

        ' --------------------------------------------------------- direction
        If PinType = PinTypes.UNUSED Then
            Direction = Directions.Unused
        ElseIf PinType < 128 Then
            Direction = Directions.HostToMaster
        Else
            Direction = Directions.MasterToHost
        End If

    End Sub



    ' ==================================================================================================
    '  OUTPUTS  ( form SLOT to HARDWARE )
    ' ==================================================================================================
    Friend Sub ReadValueFromMMF()
        If OperatingSystemIsWindows Then
            Value = ReadSlot(Slot)
        Else
            Value = ReadSlot_Unix(Slot)
        End If
    End Sub

    Friend Sub ConvertValueToHardwareFormat()
        ' -------------------------------------------------------------- min and max
        If Value_Max <> Value_Min Then
            Value_Normalized_New = (Value - Value_Min) / (Value_Max - Value_Min)
        Else
            Value_Normalized_New = Value
        End If
        ' -------------------------------------------------------------- exponential passing by 0 and 1
        '                                                                a little less that the log base ( 2.7182 ) 
        If LogResponse AndAlso _
           (PinType = PinTypes.PWM_8 Or PinType = PinTypes.PWM_16) Then
            Value_Normalized_New = CSng(Value_Normalized_New ^ 2)
        End If
        ' -------------------------------------------------------------- limit to 0..1
        If Value_Normalized_New < 0 Then Value_Normalized_New = 0
        If Value_Normalized_New > 1 Then Value_Normalized_New = 1
        ' -------------------------------------------------------------- speed 
        Masters(MasterId).SmoothValue(Value_Normalized, _
                                      Value_Normalized_New, _
                                      ResponseSpeed, _
                                      AdaptiveSpeed)
        ' --------------------------------------------------------------
        Select Case PinType
            Case PinTypes.DIG_OUT
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = 0
                End If
                If Value_Normalized > 0.5 Then
                    Value_RawInteger = 1
                Else
                    Value_RawInteger = 0
                End If

            Case PinTypes.PWM_8, PinTypes.SERVO_8
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = If(Value_Max > Value_Min, 0, 1)
                    Value_RawInteger = 0
                Else
                    Value_RawInteger = CUInt(16.0F * (Value_Normalized * (MaxTime - MinTime) + MinTime))
                End If
                If Value_RawInteger < 0 Then Value_RawInteger = 0
                If Value_RawInteger > 64000 Then Value_RawInteger = 64000

            Case PinTypes.PWM_16, PinTypes.SERVO_16
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = If(Value_Max > Value_Min, 0, 1)
                    Value_RawInteger = 0
                Else
                    Value_RawInteger = CUInt(16.0F * (Value_Normalized * (MaxTime - MinTime) + MinTime))
                End If
                If Value_RawInteger < 0 Then Value_RawInteger = 0
                If Value_RawInteger > 64000 Then Value_RawInteger = 64000
        End Select
    End Sub

    Friend Sub WriteValueToUsbBuffer()
        Select Case PinType
            Case PinTypes.DIG_OUT
                Masters(MasterId).Hid.USB_TxData(UsbByteIndex) = CByte(Value_RawInteger)
            Case PinTypes.PWM_8, PinTypes.SERVO_8
                Masters(MasterId).Hid.USB_TxData(UsbByteIndex) = CByte(Value_RawInteger / 256)
            Case PinTypes.PWM_16, PinTypes.SERVO_16
                Dim bytes() As Byte = ByteArrayFromUint16(CUShort(Value_RawInteger))
                Masters(MasterId).Hid.USB_TxData(UsbByteIndex) = bytes(0)
                Masters(MasterId).Hid.USB_TxData(UsbByteIndex + 1) = bytes(1)
        End Select
    End Sub




    ' ==================================================================================================
    '  INPUTS  ( form HARDWARE to SLOT )
    ' ==================================================================================================
    Friend Sub ReadValueFromUsbBuffer()
        With Masters(MasterId).Hid
            Select Case UsbBytesCount
                Case 1
                    Value_RawInteger = .USB_RxData(UsbByteIndex + 0)
                Case 2
                    Value_RawInteger = .USB_RxData(UsbByteIndex + 0) * 256UI + _
                                       .USB_RxData(UsbByteIndex + 1)
                Case 3
                    Value_RawInteger = .USB_RxData(UsbByteIndex + 0) * 65536UI + _
                   .USB_RxData(UsbByteIndex + 1) * 256UI + _
                   .USB_RxData(UsbByteIndex + 2)
                Case 4
                    Value_RawInteger = .USB_RxData(UsbByteIndex + 0) * 256UI * 65536UI + _
                   .USB_RxData(UsbByteIndex + 1) * 65536UI + _
                   .USB_RxData(UsbByteIndex + 2) * 256UI + _
                   .USB_RxData(UsbByteIndex + 3)
            End Select
            Select Case PinType
                Case PinTypes.SNIFFER
                    SyncLock SnifferLogLock
                        With Masters(MasterId).Hid
                            nNewSniffedBytes = .USB_RxData(UsbByteIndex + 0)
                            SnifferStatus = .USB_RxData(UsbByteIndex + 1)
                            If SnifferLogEnabled Then
                                For i As Int32 = 0 To nNewSniffedBytes - 1
                                    If nSniffedBytes >= SniffedBytes.Length - 1 Then Exit For
                                    SniffedBytes(nSniffedBytes) = .USB_RxData(i * 2 + 2)
                                    SniffedFlags(nSniffedBytes) = .USB_RxData(i * 2 + 3)
                                    nSniffedBytes += 1
                                Next
                            End If
                            Value_RawInteger = .USB_RxData(2)
                            Value_Normalized_New = Value_RawInteger / 255.0F
                        End With
                    End SyncLock
                Case PinTypes.MCA_8_BYTES, PinTypes.MCA_16_BYTES, PinTypes.MCA_32_BYTES
                    'TODO
            End Select
        End With
    End Sub


    Friend Sub ConvertValueFromHardwareFormat()

        Select Case PinType

            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                If Value_RawInteger <> 0 Then Value_RawInteger = 1
                Value_Normalized_New = Value_RawInteger

            Case PinTypes.ADC_8
                Value_Normalized_New = Value_RawInteger / 255.0F

            Case PinTypes.ADC_16
                Value_Normalized_New = Value_RawInteger / 65535.0F

            Case PinTypes.CAP_8
                Value_RawInteger *= 3UI ' correction for (PIC24)Master and Servo values (0 to 60 instead of 0 to 255)

            Case PinTypes.CAP_16
                Value_RawInteger *= 3UI ' correction for (PIC24)Master and Servo values (0 to 16000 instead of 0 to 65535)

            Case PinTypes.RES_8
                Value_Normalized_New = Value_RawInteger / 255.0F

            Case PinTypes.RES_16
                Value_Normalized_New = Value_RawInteger / 65535.0F

            Case PinTypes.COUNTER, PinTypes.COUNTER_PU, _
                 PinTypes.FAST_COUNTER, PinTypes.FAST_COUNTER_PU

            Case PinTypes.PERIOD, PinTypes.PERIOD_PU


            Case PinTypes.USOUND_SENSOR
                If RemoveErrors Then UsoundSensor_RemoveErrors()
                UsoundSensor_CalculatePosition()

            Case PinTypes.CAP_SENSOR
                CapSensor_CalculateAll()

        End Select



        Select Case PinType

            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU, _
                 PinTypes.ADC_8, PinTypes.ADC_16, _
                 PinTypes.RES_8, PinTypes.RES_16, _
                 PinTypes.USOUND_SENSOR, _
                 PinTypes.CAP_SENSOR
                ' ------------------------------------------------------------------ limit to 0..1
                If Value_Normalized_New < 0 Then Value_Normalized_New = 0
                If Value_Normalized_New > 1 Then Value_Normalized_New = 1
                ' -------------------------------------------------------------- speed 
                Masters(MasterId).SmoothValue(Value_Normalized, _
                                              Value_Normalized_New, _
                                              ResponseSpeed, _
                                              AdaptiveSpeed)
                ' ------------------------------------------------------------------ min and max
                Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min


            Case PinTypes.CAP_8, PinTypes.CAP_16
                ' -------------------------------------------------------------- speed before trigger
                If PinType = PinTypes.CAP_8 Then
                    Masters(MasterId).SmoothValue(Value_RawSmoothed, _
                                                      Value_RawInteger * (1000.0F / 255.0F), _
                                                      ResponseSpeed, _
                                                      AdaptiveSpeed)
                Else
                    Masters(MasterId).SmoothValue(Value_RawSmoothed, _
                                                      Value_RawInteger * (1000.0F / 65535.0F), _
                                                      ResponseSpeed, _
                                                      AdaptiveSpeed)
                End If

                If MinVariation > 0 Then
                    ' -------------------------------------------
                    '   CAP TOUCH KEYS
                    ' -------------------------------------------

                    ' ------------------------------------------------------------------ calculate delta
                    Dim delta As Single = MeanValue - Value_RawSmoothed

                    ' ------------------------------------------------------------------ increase min value
                    If delta < 0 Then
                        MeanValue += (Value_RawSmoothed - MeanValue) * 0.01F
                        delta = 0
                    End If
                    ' ------------------------------------------------------------------ MinVariation reduced for sliders
                    If ProportionalArea > 0 Then
                        delta -= MinVariation / 100
                    Else
                        delta -= MinVariation
                    End If
                    ' ------------------------------------------------------------------
                    If ProportionalArea > 0 Then
                        ' -------------------------------------------------------------- proportional limited to 0..1
                        Value_Normalized = delta / ProportionalArea
                        If Value_Normalized < 0 Then Value_Normalized = 0
                        If Value_Normalized > 1 Then Value_Normalized = 1
                    ElseIf ProportionalArea = 0 Then
                        ' -------------------------------------------------------------- on/off (0 or 1)
                        Value_Normalized = If(delta > 0, 1, 0)
                    Else
                        ' -------------------------------------------------------------- with velocity
                        If delta > 0 Then
                            If Velocity = 0 Then
                                Velocity = (delta - oldDelta3) / -ProportionalArea
                                If Velocity > 1 Then Velocity = 1
                                Velocity = Velocity * Velocity
                            End If
                        Else
                            Velocity = 0
                        End If
                        oldDelta3 = oldDelta2
                        oldDelta2 = oldDelta1
                        oldDelta1 = delta
                        Value_Normalized = Velocity
                    End If

                Else
                    ' -------------------------------------------
                    '   RAW CAPACITIVE SENSORS
                    ' -------------------------------------------
                    Value_Normalized = (-MinVariation - Value_RawSmoothed) / ProportionalArea
                    If Value_Normalized < 0 Then Value_Normalized = 0
                    If Value_Normalized > 1 Then Value_Normalized = 1

                End If
                ' ---------------------------------------------------------------------- min and max
                Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                ' ---------------------------------------------------------------------- values min and max for calibrate Inhibit
                If Value_RawSmoothed > Value_Integer_Max Then Value_Integer_Max = CUInt(Value_RawSmoothed * 10)
                If Value_RawSmoothed < Value_Integer_Min Then Value_Integer_Min = CUInt(Value_RawSmoothed * 10)


            Case PinTypes.COUNTER, PinTypes.COUNTER_PU, _
                 PinTypes.FAST_COUNTER, PinTypes.FAST_COUNTER_PU
                If ConvertToFreq Then
                    ' -------------------------------------------------------------- range
                    'If Value_RawInteger > 0 Then
                    '    Freq = 2000000.0F / Value_RawInteger
                    'Else
                    '    Freq = 0
                    'End If
                    'Dim range As Double = MaxFreq - MinFreq
                    'If range < 0.1 Then range = 0.1
                    'Value_Normalized_New = CSng((Freq - MinFreq) / range)
                    ' -------------------------------------------------------------- speed
                    'FilterValueNormalizedBySpeed()
                    ' -------------------------------------------------------------- min and max
                    'Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                Else
                    Value_Normalized_New = Value_RawInteger / 65535.0F
                    Value_Normalized = Value_Normalized_New
                    Value = Value_RawInteger
                End If

            Case PinTypes.PERIOD, PinTypes.PERIOD_PU  ' Value_RawInteger = 0.0625 uSec ( 16 MHz )
                If ConvertToFreq Then
                    ' -------------------------------------------------------------- range
                    If Value_RawInteger > 0 Then
                        Freq = 1.6E+7F / Value_RawInteger
                    Else
                        Freq = 0
                    End If
                    Dim range As Double = MaxFreq - MinFreq
                    If range < 0.1 Then range = 0.1
                    Value_Normalized_New = CSng((Freq - MinFreq) / range)
                    ' -------------------------------------------------------------- speed 
                    Masters(MasterId).SmoothValue(Value_Normalized, _
                                                  Value_Normalized_New, _
                                                  ResponseSpeed, _
                                                  AdaptiveSpeed)
                    ' -------------------------------------------------------------- min and max
                    Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                Else
                    Value_Normalized_New = Value_RawInteger / 16777215.0F / 2.0F
                    Value_Normalized = Value_Normalized_New
                    Value = Value_RawInteger
                End If

            Case PinTypes.MCA_8_BYTES, PinTypes.MCA_16_BYTES, PinTypes.MCA_32_BYTES
                ' TODO

            Case PinTypes.SNIFFER
                Value_Normalized = Value_Normalized_New
                Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                ' ValueNormalized ( barra ) must follow nSniffed from 0 to 24 (slowly ?)

        End Select
    End Sub

    Friend Sub WriteValueToMMF()
        If OperatingSystemIsWindows Then
            WriteSlot(Slot, CSng(Value))
        Else
            WriteSlot_Unix(Slot, CSng(Value))
        End If
    End Sub


    ' ==================================================================================================
    '   HELPER FUNCTIONS
    ' ==================================================================================================
    Friend Sub ResetPosMinMax()
        Value_Integer_Min = 99999999
        Value_Integer_Max = 0
    End Sub

    Friend Sub Calibrate()
        Select Case PinType
            Case PinTypes.CAP_SENSOR
                ' ----------------------------------------------- calibrate cap input
                Cap_zero = Cap_total
                ' ----------------------------------------------- calculate immediately the new position
                CapSensor_CalculatePosition()

            Case PinTypes.CAP_8, PinTypes.CAP_16
                ' ----------------------------------------------- calibrate cap input
                MeanValue = Value_RawSmoothed
        End Select
    End Sub

    Friend Sub CalibrateZero()
        Value_RawInteger_Zero = Value_RawInteger
        Value_Normalized_Zero = Value_Normalized
    End Sub

    Friend Function GetValueString() As String
        Dim ci As CultureInfo = New CultureInfo("en-GB")
        Select Case PinType

            ' ------------------------------------------------------------------------- OUTPUTS
            Case PinTypes.DIG_OUT
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci) & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        "  Out: " & Value_RawInteger.ToString("0")

            Case PinTypes.SERVO_8, PinTypes.SERVO_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value_RawInteger.ToString("0.00", ci) & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " uSec: " & Value_RawInteger.ToString("00000")

            Case PinTypes.PWM_8, PinTypes.PWM_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value_RawInteger.ToString("0.00", ci) & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " uSec: " & Value_RawInteger.ToString("0000")

                ' --------------------------------------------------------------------- INPUTS 
            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("0") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.ADC_8
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.ADC_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.CAP_8, PinTypes.CAP_16
                If MinVariation > 0 Then
                    Return PinTypeToString(PinType) & vbCrLf & _
                                    "--------------" & vbCrLf & _
                                    "   Raw: " & Value_RawInteger.ToString("000") & vbCrLf & _
                                    " Smoot: " & Value_RawSmoothed.ToString("0.00") & vbCrLf & _
                                    "  Mean: " & MeanValue.ToString("0.00") & vbCrLf & _
                                    "  Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                                    "  Slot: " & Value.ToString("0.00", ci)
                Else
                    Return PinTypeToString(PinType) & vbCrLf & _
                                    "--------------" & vbCrLf & _
                                    "   Raw: " & Value_RawInteger.ToString("000") & vbCrLf & _
                                    " Smoot: " & Value_RawSmoothed.ToString("0.00") & vbCrLf & _
                                    "  Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                                    "  Slot: " & Value.ToString("0.00", ci)
                End If
            Case PinTypes.RES_8
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.RES_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.COUNTER, PinTypes.COUNTER_PU, _
                 PinTypes.FAST_COUNTER, PinTypes.FAST_COUNTER_PU, _
                 PinTypes.PERIOD, PinTypes.PERIOD_PU
                If ConvertToFreq Then
                    Return PinTypeToString(PinType) & vbCrLf & _
                            "--------------" & vbCrLf & _
                            "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                            " Freq: " & Freq.ToString("00000") & vbCrLf & _
                            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                            " Slot: " & Value.ToString("0.00", ci)
                Else
                    Return PinTypeToString(PinType) & vbCrLf & _
                            "--------------" & vbCrLf & _
                            "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                            " Slot: " & Value.ToString("00000")
                End If

            Case PinTypes.USOUND_SENSOR
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                        "   mm: " & Dist_mm.ToString("0000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.CAP_SENSOR
                If Value_RawInteger < 999999 Then
                    '
                    Return "  Raw: " & Value_RawInteger.ToString("00000") & vbCrLf & _
                           "   mS: " & Millisec.ToString("0.0000", ci) & vbCrLf & _
                           "  MHz: " & IntegratedFreqString & vbCrLf & _
                           "C_tot: " & Cap_total.ToString("00.000", ci) & vbCrLf & _
                           " C_in: " & Cap_input.ToString("00.000", ci) & vbCrLf & _
                           "   mm: " & Dist_mm.ToString("0000") & vbCrLf & _
                           " Norm: " & Value_Normalized.ToString("0.00", ci)
                End If

            Case PinTypes.SNIFFER
                ' --------------------------------------------------------------------- 
                Dim s As String = PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "      N:" & nNewSniffedBytes.ToString() & vbCrLf & _
                        " Status:" & SnifferStatus.ToString() & vbCrLf

                ' --------------------------------------------------------------------- 
                If Form2.btn_TextLog.Checked Then
                    If SnifferLogEnabled Then
                        SyncLock SnifferLogLock
                            With Form2.rtb_SnifferLog
                                'nSniffedBytes = 1
                                For i As Int32 = 0 To nSniffedBytes - 1
                                    .SelectionStart = 2000000000
                                    .SelectedText = SnifferStatus.ToString("000") & _
                                                    DecodeSnifferStatus(SnifferStatus) & "   " & _
                                                    SniffedFlags(i).ToString("000") & _
                                                    DecodeSnifferFlags(SniffedFlags(i)) & "   " & _
                                                    SniffedBytes(i).ToString("000") & vbCrLf
                                    '.SelectionStart = .Text.Length - 1
                                    '.ScrollToCaret()
                                Next
                                nSniffedBytes = 0
                            End With
                        End SyncLock
                    End If
                End If

                Return s

                ' --------------------------------------------------------------------- 
            Case Else
                Return PinTypeToString(PinType)

        End Select
        Return ""
    End Function

    Private Function DecodeSnifferStatus(ByVal status As Int32) As String
        Dim s As String = "( "
        If (status And 64) <> 0 Then s &= "Full " Else s &= "---- "
        If (status And 128) <> 0 Then s &= "Over " Else s &= "---- "
        s &= " )   "
        Return s
    End Function

    Private Function DecodeSnifferFlags(ByVal flags As Int32) As String
        Dim s As String = "( "
        If (flags And 1) <> 0 Then s &= "P " Else s &= "p "
        If (flags And 2) <> 0 Then s &= "F " Else s &= "f "
        If (flags And 4) <> 0 Then s &= "O " Else s &= "o "
        If (flags And 8) <> 0 Then s &= "MtS " Else s &= "StM "
        s &= " )   "
        Return s
    End Function


    ' ==================================================================================================
    '   USOUND SENSORS SPECIFIC
    ' ==================================================================================================
    Private Sub UsoundSensor_RemoveErrors()
        Dim diff As UInt32 = AbsUint32Difference(Value_RawInteger, Value_RawInteger_Old)
        Dim maxErrorCount As Int32 = 2 * (1 + 30 \ RepTime)
        '
        If diff > 1000 And ErrorCounter < maxErrorCount Then
            Value_RawInteger = Value_RawInteger_Old
            ErrorCounter += 1
        Else
            ' ---------------------------------------------------------- use the new value
            Value_RawInteger_Old = Value_RawInteger
            ErrorCounter = 0
        End If
    End Sub

    Private Sub UsoundSensor_CalculatePosition()
        ' -------------------------------------------------------------- distance in mm 
        Dist_mm = (Value_RawInteger - 900.0F) * 0.173F
        ' -------------------------------------------------------------- distance limits
        If Dist_mm < MinDist_mm Then Dist_mm = MinDist_mm
        If Dist_mm > MaxDist_mm Then Dist_mm = MaxDist_mm
        ' -------------------------------------------------------------- range
        Dim range As Double = MaxDist_mm - MinDist_mm
        If range < 0.1 Then range = 0.1
        Value_Normalized_New = 1 - CSng((Dist_mm - MinDist_mm) / range)
    End Sub



    ' ==================================================================================================
    '   CAP SENSORS SPECIFIC
    ' ==================================================================================================
    Private Sub CapSensor_CalculateAll()
        CapSensor_LatencyBitsExtractor()
        'CapSensor_RemoveErrors()
        CapSensor_UpdateMinMaxValues()
        CapSensor_CalculateTimeAndFreq()
        CapSensor_CalculateTotalCap()
        CapSensor_CalculatePosition()
    End Sub

    Dim LatencySelector As Int32 = 0
    Private Sub CapSensor_LatencyBitsExtractor()
        LatencySelector = CType(Value_RawInteger >> 20, Int32)
        Value_RawInteger = Value_RawInteger And &HFFFFFUI
    End Sub


    'Private Sub CapSensor_RemoveErrors()
    '    Dim MinCount As Int32 = 200000
    '    Dim MinDiff As Int32 = 35000
    '    Dim MaxDiff As Int32 = 95000
    '    Dim maxErrorCount As Int32 = 5 * (1 + 30 \ RepTime)
    '    '
    '    Dim diff As UInt32 = AbsUint32Difference(Value_RawInteger, Value_RawInteger_Old)
    '    '
    '    If (Value_RawInteger < MinCount OrElse (diff > MinDiff And diff < MaxDiff)) And ErrorCounter < 5 Then
    '        ' ------------------------------------------------------ show the error
    '        'frmMain.txt_Reports.Text &= "Invalid sample  " & _
    '        '                            "  OLD=" & _slave.CountOld.ToString & _
    '        '                            "  NEW=" & _slave.CountNew.ToString & _
    '        '                            "  DIFF=" & diff.ToString & vbCrLf
    '        Value_RawInteger = Value_RawInteger_Old
    '        ErrorCounter += 1
    '    Else
    '        ' ------------------------------------------------------ use the new value
    '        Value_RawInteger_Old = Value_RawInteger
    '        ErrorCounter = 0
    '    End If
    'End Sub

    ' ------------------------------------------------- RawInteger min and max for AutoCalibrate
    Private Sub CapSensor_UpdateMinMaxValues()
        If Value_RawInteger > Value_Integer_Max Then Value_Integer_Max = Value_RawInteger
        If Value_RawInteger < Value_Integer_Min Then Value_Integer_Min = Value_RawInteger
    End Sub

    Private Sub CapSensor_CalculateTimeAndFreq()
        ' ---------------------------------------------------------- time total
        Dim mS As Single = CSng(Value_RawInteger / TimerFrequencyKhz)
        ' ---------------------------------------------------------- frequency
        Freq = TimerDivision * 1000 / mS
        ' ---------------------------------------------------------- millisec corrected by latencyselector
        Millisec = mS / CSng(2 ^ LatencySelector)
        ' ---------------------------------------------------------- integrated frequency (only visual info)
        IntegratedFreq += Freq
        IntegratedlFreqCounter += 1
        If IntegratedlFreqCounter >= 50 Then
            IntegratedFreqString = (IntegratedFreq / (1000000 * 50)).ToString("0.00000", CultureInfo.InvariantCulture)
            If IntegratedFreqString = "Infinity" Then IntegratedFreqString = "---"
            IntegratedFreq = 0
            IntegratedlFreqCounter = 0
        End If
    End Sub

    Private Sub CapSensor_CalculateTotalCap()
        ' ----------------------------------------------------------- total capacitance ( in parallel to inductor )
        Cap_total = CSng(2.53302955E+16 / (Inductor_uh * Freq ^ 2))
    End Sub

    'Private Sub CapSensor_CalculatePosition()
    '    ' ----------------------------------------------------------- input capacitance ( after serial capacitor )
    '    If Cap_serial > 0 Then
    '        Cap_input = CSng(ELEC_C2_FromSerial(Cap_total - Cap_zero, Cap_serial))
    '    Else
    '        Cap_input = Cap_total - Cap_zero
    '    End If
    '    If Cap_input < 0 Then Cap_input = 0
    '    If Cap_input > 999.999 Then Cap_input = 999.999
    '    ' ----------------------------------------------------------- K area 
    '    ' Teoric K_Area is: 88 * 100 * Area_cmq
    '    ' from: 0.885F(cap. to dist. coeff.) * 100(cmq to mmq) * Area_cmq
    '    ' ---------
    '    ' A High coefficient ( 80 .. 160 ) expands the "Near" zone
    '    ' A Low coefficient  ( 40 .. 80 ) expands the "Far" zone
    '    ' ---------
    '    ' The user can change this Near-Far linearity 
    '    ' increasing or decreasing the parameter "Area_cmq" 
    '    ' ---------
    '    Dim K_Area As Single = 88 * Area_cmq
    '    ' ----------------------------------------------------------- distance in mm 
    '    Dist_mm = K_Area * MaxDist_mm / _
    '              (K_Area + Cap_input * MaxDist_mm * MaxDist_mm)
    '    ' ----------------------------------------------------------- distance limits
    '    If Dist_mm < 0 Then Dist_mm = 0
    '    If Dist_mm > MaxDist_mm Then Dist_mm = MaxDist_mm
    '    ' ----------------------------------------------------------- range
    '    Dim range As Double = MaxDist_mm - MinDist_mm
    '    If range < 0.1 Then range = 0.1
    '    Value_Normalized_New = 1 - CSng((Dist_mm - MinDist_mm) / range)
    'End Sub


    Private Sub CapSensor_CalculatePosition()
        ' ----------------------------------------------------------- input capacitance ( after serial capacitor )
        If Cap_serial > 0 Then
            Cap_input = CSng(ELEC_C2_FromSerial(Cap_total - Cap_zero, Cap_serial))
        Else
            Cap_input = Cap_total - Cap_zero
        End If
        If Cap_input < 0 Then Cap_input = 0
        If Cap_input > 999.999 Then Cap_input = 999.999
        ' ----------------------------------------------------------- K area 
        ' Teoric K_Area is: 88 * 100 * Area_cmq
        ' from: 0.885F(cap. to dist. coeff.) * 100(cmq to mmq) * Area_cmq
        ' ---------
        ' A High coefficient ( 80 .. 160 ) expands the "Near" zone
        ' A Low coefficient  ( 40 .. 80 ) expands the "Far" zone
        ' ---------
        ' The user can change this Near-Far linearity 
        ' increasing or decreasing the parameter "Area_cmq" 
        ' ---------
        Dim K_Area As Single = 88 * Area_cmq
        ' ----------------------------------------------------------- MaxDist and MinDist correction for area
        Dim K2 As Single = Area_cmq / 100.0F
        Dim MinD As Single = MinDist_mm * K2
        Dim MaxD As Single = MaxDist_mm * K2
        ' ----------------------------------------------------------- distance in mm 
        Dist_mm = K_Area * MaxD / _
                 (K_Area + Cap_input * MaxD * MaxD)
        ' ----------------------------------------------------------- distance limits
        If Dist_mm < 0 Then Dist_mm = 0
        If Dist_mm > MaxD Then Dist_mm = MaxD
        ' ----------------------------------------------------------- range
        Dim range As Double = MaxD - MinD
        If range < 0.1 Then range = 0.1
        Value_Normalized_New = 1 - CSng((Dist_mm - MinD) / range)
    End Sub

End Class


