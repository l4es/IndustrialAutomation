﻿
Imports System.Globalization
Imports System.Math
Imports System.Collections.Generic



' ==================================================================================================
'   CLASS SLAVE
' ==================================================================================================

Class Slave

    Enum SlaveTypes As Int32
        Custom = 0
        CapSensor = 1
        Servo = 2
        Generic = 3
        InOut = 4
        MasterPins = 5
        RmsLogger = 6
        Sniffer = 7
        Unknown = 255
    End Enum

    Friend MasterId As Int32
    Friend mSlaveId As Int32
    Friend SlaveType As SlaveTypes
    Friend Pins As List(Of Pin)
    Friend LoadCurrent_mA As Int32


    Friend Property SlaveId() As Int32
        Get
            Return mSlaveId
        End Get
        Set(ByVal value As Int32)
            ' test if mSlaveId ok
            mSlaveId = value
        End Set
    End Property

    Friend Function SlaveTypeString() As String
        Select Case SlaveType
            Case SlaveTypes.Custom : Return "Custom"
            Case SlaveTypes.CapSensor : Return "CapSensor"
            Case SlaveTypes.Servo : Return "Servo"
            Case SlaveTypes.Generic : Return "Generic"
            Case SlaveTypes.InOut : Return "InOut"
            Case SlaveTypes.MasterPins : Return "MasterPins"
            Case SlaveTypes.RmsLogger : Return "RmsLogger"
            Case SlaveTypes.Sniffer : Return "Sniffer"
            Case SlaveTypes.Unknown : Return "Unknown"
            Case Else : Return "Unknown"
        End Select
    End Function


    Friend Sub New(ByVal _slavetype As SlaveTypes, ByVal _masterid As Int32, ByVal _slaveid As Int32)
        SlaveType = _slavetype
        MasterId = _masterid
        SlaveId = _slaveid
        LoadCurrent_mA = 0
    End Sub

    Friend Function GetHostToMasterBytesCount() As Int32
        GetHostToMasterBytesCount = 0
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.HostToMaster Then
                GetHostToMasterBytesCount += p.UsbBytesCount
            End If
        Next
    End Function

    Friend Function GetMasterToHostBytesCount() As Int32
        GetMasterToHostBytesCount = 0
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.MasterToHost Then
                GetMasterToHostBytesCount += p.UsbBytesCount
            End If
        Next
    End Function

    Friend Function CalibrationNeeded() As Boolean
        For Each p As Pin In Pins
            Select Case p.GetPinType()
                Case Pin.PinTypes.CAP_SENSOR
                    Return True
                Case Pin.PinTypes.CAP_8, Pin.PinTypes.CAP_16
                    If p.MinVariation > 0 Then
                        Return True
                    End If
            End Select
        Next
        Return False
    End Function

    Friend Overridable Sub Calibrate()
        For Each p As Pin In Pins
            p.Calibrate()
        Next
    End Sub

    Friend Overridable Sub CalibrateZero()
        For Each p As Pin In Pins
            p.CalibrateZero()
        Next
    End Sub

    Friend Overridable Function Get_CapSensor_Or_Cap_Delta() As UInt32
        Dim maxdelta As UInt32 = 0
        For Each p As Pin In Pins
            Select Case p.GetPinType()
                Case Pin.PinTypes.CAP_8, Pin.PinTypes.CAP_16
                    Dim n As UInt32 = AbsUint32Difference(p.Value_Integer_Max, p.Value_Integer_Min)
                    If n > maxdelta Then maxdelta = n
                    p.ResetPosMinMax()
            End Select
        Next
        Return maxdelta
    End Function


    Friend Overridable Sub ConfigurePin(ByVal npin As Int32, ByVal pinType As Pin.PinTypes)
        Select Case SlaveType
            Case SlaveTypes.Servo, SlaveTypes.Generic, SlaveTypes.InOut

                Select Case pinType

                    Case Pin.PinTypes.UNUSED, Pin.PinTypes.DIG_OUT, _
                                                Pin.PinTypes.PWM_8, _
                                                Pin.PinTypes.PWM_16, _
                                                Pin.PinTypes.SERVO_8, _
                                                Pin.PinTypes.SERVO_16, _
                                                Pin.PinTypes.DIG_IN, _
                                                Pin.PinTypes.DIG_IN_PU, _
                                                Pin.PinTypes.COUNTER, _
                                                Pin.PinTypes.COUNTER_PU
                        Pins(npin).SetPinType(pinType)

                    Case Pin.PinTypes.ADC_8, Pin.PinTypes.ADC_16, _
                         Pin.PinTypes.CAP_8, Pin.PinTypes.CAP_16, _
                         Pin.PinTypes.RES_8, Pin.PinTypes.RES_16
                        If npin < 8 Then Pins(npin).SetPinType(pinType)

                    Case Pin.PinTypes.FAST_COUNTER, Pin.PinTypes.FAST_COUNTER_PU
                        If npin = 7 Then Pins(npin).SetPinType(pinType)

                    Case Pin.PinTypes.USOUND_SENSOR, Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                        If npin = 8 Then Pins(npin).SetPinType(pinType)

                        ' TODO add MCA_8_BYTES, MCA_16_BYTES, MCA_32_BYTES
                End Select

        End Select
    End Sub

    Friend Overridable Sub FillTypeCombo(ByVal cmb As ComboBox, ByRef p As Pin)
        Select Case SlaveType

            Case SlaveTypes.Servo, SlaveTypes.Generic, SlaveTypes.InOut
                cmb.Items.Clear()
                '
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
                '
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16))
                '
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU))
                '
                If p.PinId < 8 Then
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16))
                End If
                '
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER))
                cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU))

                If p.PinId = 7 Then
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU))
                End If

                If p.PinId = 8 Then
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU))
                    cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR))
                End If

                ' TODO add MCA_8_BYTES, MCA_16_BYTES, MCA_32_BYTES

            Case Else
                cmb.Items.Clear()
                cmb.Items.Add(Pin.PinTypeToString(p.GetPinType))

        End Select
    End Sub

End Class





' ==================================================================================================
' SUBCLASS - Slave_CapSensor
' ==================================================================================================

Class Slave_CapSensor : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.CapSensor, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 12
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0))
    End Sub

    Friend Overrides Function Get_CapSensor_Or_Cap_Delta() As UInt32
        With Pins(0)
            Dim n As UInt32 = AbsUint32Difference(.Value_Integer_Max, .Value_Integer_Min)
            If n < 0 Then n = 0
            If n > 400000 Then n = 0
            Get_CapSensor_Or_Cap_Delta = n
            .ResetPosMinMax()
        End With
    End Function

    Friend Overrides Sub ConfigurePin(ByVal npin As Int32, ByVal pinType As Pin.PinTypes)
        Select Case pinType
            Case Pin.PinTypes.UNUSED, Pin.PinTypes.CAP_SENSOR
                Pins(npin).SetPinType(pinType)
        End Select
    End Sub

    Friend Overrides Sub FillTypeCombo(ByVal cmb As ComboBox, ByRef p As Pin)
        cmb.Items.Clear()
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_SENSOR))
    End Sub

End Class


' ==================================================================================================
'   SUBCLASS - Slave_Servo
' ==================================================================================================

Class Slave_Servo : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.Servo, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 80
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9))
    End Sub

End Class



' ==================================================================================================
'   SUBCLASS - Slave_Generic
' ==================================================================================================

Class Slave_Generic : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.Generic, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 80
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 10))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 11))
    End Sub

End Class



' ==================================================================================================
'   SUBCLASS - Slave_InOut
' ==================================================================================================

Class Slave_InOut : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.InOut, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 80
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 6))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 7))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 8))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 9))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 10))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 11))
    End Sub

End Class



' ==================================================================================================
'   SUBCLASS - Slave_MasterPins
' ==================================================================================================

Class Slave_MasterPins : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.MasterPins, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 10
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 0))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 1))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 2))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 3))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 4))
        Pins.Add(New Pin(Pin.PinTypes.UNUSED, MasterId, mSlaveId, 5))
    End Sub

    Friend Overrides Sub ConfigurePin(ByVal npin As Int32, ByVal pinType As Pin.PinTypes)
        Select Case pinType

            Case Pin.PinTypes.UNUSED, Pin.PinTypes.DIG_OUT, Pin.PinTypes.PWM_8, _
                                                            Pin.PinTypes.PWM_16, _
                                                            Pin.PinTypes.SERVO_8, _
                                                            Pin.PinTypes.SERVO_16, _
                                                            Pin.PinTypes.DIG_IN, _
                                                            Pin.PinTypes.DIG_IN_PU, _
                                                            Pin.PinTypes.ADC_8, _
                                                            Pin.PinTypes.ADC_16, _
                                                            Pin.PinTypes.CAP_8, _
                                                            Pin.PinTypes.CAP_16, _
                                                            Pin.PinTypes.RES_8, _
                                                            Pin.PinTypes.RES_16, _
                                                            Pin.PinTypes.COUNTER, _
                                                            Pin.PinTypes.COUNTER_PU
                Pins(npin).SetPinType(pinType)

            Case Pin.PinTypes.FAST_COUNTER, Pin.PinTypes.FAST_COUNTER_PU
                If Not AlreadyUsed_FastCounter(Pins(npin)) Then Pins(npin).SetPinType(pinType)

            Case Pin.PinTypes.USOUND_SENSOR, Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                If Not AlreadyUsed_PeriodCounter(Pins(npin)) Then Pins(npin).SetPinType(pinType)

                ' TODO add MCA_8_BYTES, MCA_16_BYTES, MCA_32_BYTES
        End Select
    End Sub

    Friend Overrides Sub FillTypeCombo(ByVal cmb As ComboBox, ByRef p As Pin)
        cmb.Items.Clear()
        '
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
        '
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_8))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_8))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16))
        '
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_8))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_8))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.CAP_16))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_8))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.RES_16))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER))
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU))

        If Not AlreadyUsed_FastCounter(p) Then
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER))
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.FAST_COUNTER_PU))
        End If

        If Not AlreadyUsed_PeriodCounter(p) Then
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD))
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU))
            cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.USOUND_SENSOR))
        End If

        ' TODO add MCA_8_BYTES, MCA_16_BYTES, MCA_32_BYTES
    End Sub

    Private Function AlreadyUsed_FastCounter(ByVal pinSelected As Pin) As Boolean
        For Each p As Pin In Pins
            If p Is pinSelected Then Continue For
            If p.GetPinType = Pin.PinTypes.FAST_COUNTER OrElse p.GetPinType = Pin.PinTypes.FAST_COUNTER_PU Then
                Return True
            End If
        Next
        Return False
    End Function

    Private Function AlreadyUsed_PeriodCounter(ByVal pinSelected As Pin) As Boolean
        For Each p As Pin In Pins
            If p Is pinSelected Then Continue For
            If p.GetPinType = Pin.PinTypes.PERIOD OrElse p.GetPinType = Pin.PinTypes.PERIOD_PU _
                                                  OrElse p.GetPinType = Pin.PinTypes.USOUND_SENSOR Then
                Return True
            End If
        Next
        Return False
    End Function
End Class



' ==================================================================================================
'   SUBCLASS - Slave_RmsLogger
' ==================================================================================================

Class Slave_RmsLogger : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.RmsLogger, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 10
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.ADC_16, MasterId, mSlaveId, 0))   ' ADC - Battery voltage 
    End Sub

End Class


' ==================================================================================================
'   SUBCLASS - Slave_Sniffer
' ==================================================================================================

Class Slave_Sniffer : Inherits Slave

    Friend Sub New(ByVal _masterid As Int32, ByVal _slaveid As Int32)
        MyBase.new(SlaveTypes.Sniffer, _masterid, _slaveid)
        InitDefaultPins()
        LoadCurrent_mA = 10
    End Sub

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        Pins.Add(New Pin(Pin.PinTypes.SNIFFER, MasterId, mSlaveId, 0))
    End Sub

End Class



