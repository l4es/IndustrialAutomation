﻿Public Class Form1

    Private EventsLock As Object = New Object

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '
        InitPlatformData()
        If OperatingSystemIsWindows Then
            MemoryMappedFile_Init()
            MemoryMappedFile_FillWithNanSleep()
        Else
            MemoryMappedFile_Init_Unix()
            MemoryMappedFile_FillWithNanSleep_Unix()
        End If
        '
        ShedulerMaxPrecision()
        Load_INI()
        Load_ConfigDatabase()
        SetLocales()
        ToolTips_Init()
        ToolStrip1.Renderer = New ToolStripButtonRenderer
        ' ---------------------------------------------------------------- REAL-TIME
        System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Normal
        System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime
        ' ---------------------------------------------------------------- USB - MASTERS - SLAVES
        TheSystem_InitMasters()
        TheSystem_RecognizeSlaves()
        TheSystem_StartTimers()
        ' ---------------------------------------------------------------- Timer1 = 100mS = 10Hz 
        Timer_10Hz.Interval = 200  'reduced 5 Hz to lower CPU charge
        Timer_10Hz.Start()
        ' ---------------------------------------------------------------- Timer_1Hz = 1000mS = 1Hz
        Timer_1Hz.Interval = 1000
        Timer_1Hz.Start()
        ' ---------------------------------------------------------------- WINDOW
        If Not OperatingSystemIsWindows Then
            Me.MinimumSize = New Size(650, 500)
        End If
        If Not ConfigurationIsValid Then
            WindowState = FormWindowState.Normal
        End If
        If Form2_VisibleAtStart Then
            Form2.Show()
        Else
            Form2.Visible = False
        End If
        Text = AppTitleAndVersion("Theremino HAL")
        ' ----------------------------------------------------------------
        EventsAreEnabled = True
        ' ----------------------------------------------------------------
        ListView_SelectLine(MyListView1, 0)
        ShowProps()
        EnableDisableLockedControls()
        '
        MyListView1.Focus()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EventsAreEnabled Then Return
        CloseAllAndExit()
    End Sub

    Private Sub Form1_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub CloseAllAndExit()
        TheSystem_StopTimers()
        TheSystem_SetParkingPositions()
        TheSystem_UpdateAndSaveConfigDatabase()
        Save_INI()
        ShedulerDefaultPrecision()
    End Sub

    ' =========================================================================
    '  WINDOWS SCHEDULER PRECISION
    ' ========================================================================= 
    Private Declare Function timeBeginPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Declare Function timeEndPeriod Lib "winmm.dll" (ByVal uPeriod As Int32) As Int32
    Private Sub ShedulerMaxPrecision()
        If OperatingSystemIsWindows Then
            timeBeginPeriod(1)
        End If
    End Sub
    Private Sub ShedulerDefaultPrecision()
        If OperatingSystemIsWindows Then
            timeEndPeriod(1)
        End If
    End Sub

    ' ===================================================================================
    '  MenuStrip and ToolStrip accepting the first click
    '  If the form receives a WM_PARENTNOTIFY (528) message and is not focused 
    '  then the form is activated before to exec the message
    ' ===================================================================================
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = 528 AndAlso Not Me.Focused Then
            Me.Activate()
        End If
        MyBase.WndProc(m)
    End Sub


    ' ===================================================================================
    '   MenuStrip and ToolStrip Gradients
    ' ===================================================================================
    Private Sub MenuStrip1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MenuStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    MenuStrip1.Width, MenuStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.FromArgb(240, 240, 240), _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Horizontal)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub
    Private Sub ToolStrip1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ToolStrip1.Paint
        Dim bounds As New Rectangle(0, 0, _
                                    ToolStrip1.Width, ToolStrip1.Height)
        Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                       Color.White, _
                                                       Color.FromArgb(200, 200, 200), _
                                                       Drawing2D.LinearGradientMode.Vertical)
        e.Graphics.FillRectangle(brush, bounds)
    End Sub

    ' ===================================================================================
    '   ToolStrip PressedButton color
    ' ===================================================================================
    Class ToolStripButtonRenderer
        Inherits System.Windows.Forms.ToolStripProfessionalRenderer

        Protected Overrides Sub OnRenderButtonBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim btn As ToolStripButton = CType(e.Item, ToolStripButton)
            If btn IsNot Nothing AndAlso btn.CheckOnClick AndAlso btn.Checked Then
                Dim bounds As Rectangle = New Rectangle(0, 0, e.Item.Width - 1, e.Item.Height - 1)
                Dim brush As New Drawing2D.LinearGradientBrush(bounds, _
                                                               Color.Gold, _
                                                               Color.FromArgb(250, 250, 250), _
                                                               Drawing2D.LinearGradientMode.Vertical)
                e.Graphics.FillRectangle(brush, bounds)
                e.Graphics.DrawRectangle(Pens.Orange, bounds)
            Else
                MyBase.OnRenderButtonBackground(e)
            End If
        End Sub
    End Class


    ' =======================================================================================
    '   MENU FILE
    ' =======================================================================================
    Private Sub Menu_File_EditConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_EditConfigurations.Click
        Process.Start(PlatformAdjustedFileName(Application.StartupPath & "\Theremino_HAL_ConfigDatabase.txt"))
    End Sub
    Private Sub Menu_File_OpenProgramFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_OpenProgramFolder.Click
        Process.Start(Application.StartupPath)
    End Sub
    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        CloseAllAndExit()
        Me.Close()
    End Sub

    ' =======================================================================================
    '   MENU LANGUAGE
    ' =======================================================================================
    Private Sub Menu_Language_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language.DropDownOpening
        For Each item As ToolStripMenuItem In Menu_Language.DropDownItems
            If item.Name.EndsWith(Language, StringComparison.InvariantCultureIgnoreCase) Then
                item.Select()
            End If
        Next
    End Sub
    Private Sub Menu_Language_Deutsch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Deutsch.Click
        Language = "Deutsch"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub
    Private Sub Menu_Language_English_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_English.Click
        Language = "English"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub
    Private Sub Menu_Language_Espanol_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Espanol.Click
        Language = "Espanol"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub
    Private Sub Menu_Language_Francais_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Francais.Click
        Language = "Francais"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub
    Private Sub Menu_Language_Italian_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Menu_Language_Italian.Click
        Language = "Italian"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub
    Private Sub Menu_Language_Japanese_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Language_Japanese.Click
        Language = "Japanese"
        SetLocales()
        Save_INI()
        ToolTips_Init()
    End Sub

    ' =======================================================================================
    '   MENU HELP
    ' =======================================================================================
    Private Sub Menu_Help_ProgramHelp_ENG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Help_ProgramHelp.Click
        OpenLocalizedHelp("ThereminoHAL_Help", ".pdf")
    End Sub
    Private Sub OpenLocalizedHelp(ByVal name As String, Optional ByVal ext As String = ".rtf")
        Dim LangName As String = Strings.Left(Language, 3).ToUpper.Replace("JAP", "JPN")
        Dim fname As String = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_" & LangName & ext)
        If FileExists(fname) Then
            Process.Start(fname)
        Else
            fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ENG" & ext)
            If FileExists(fname) Then
                Process.Start(fname)
            Else
                fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & "_ITA" & ext)
                If FileExists(fname) Then
                    Process.Start(fname)
                Else
                    fname = PlatformAdjustedFileName(Application.StartupPath & "\Docs\" & name & ext)
                    If FileExists(fname) Then
                        Process.Start(fname)
                    End If
                End If
            End If
        End If
    End Sub

    ' =======================================================================================
    '   MENU ABOUT
    ' =======================================================================================
    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        Form_About.ShowDialog()
    End Sub

    ' =======================================================================================
    '   TOOLBAR
    ' =======================================================================================
    Private Sub ToolStripButton_EditConfigurations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_EditConfig.Click
        Process.Start(Application.StartupPath & "\Theremino_HAL_ConfigDatabase.txt")
    End Sub
    Private Sub ToolStripButton_Recognize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Recognize.Click
        Cmd_Recognize()
        ToolStripButton_Recognize.Checked = False
    End Sub
    Private Sub ToolStripButton_Validate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Validate.Click
        Cmd_Validate()
        ToolStripButton_Validate.Checked = False
    End Sub
    Private Sub ToolStripButton_Lock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Lock.Click
        If ToolStripButton_Lock.Checked Then
            ValidMasterNames_Init()
        Else
            ValidMasterNames_Reset()
        End If
        Save_INI()
        EnableDisableLockedControls()
    End Sub
    Private Sub ToolStripButton_Disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Disconnect.Click
        Cmd_DisconnectSelectedMaster()
        ToolStripButton_Disconnect.Checked = False
    End Sub
    Private Sub EnableDisableLockedControls()
        If ToolStripButton_Lock.Checked Then
            ToolStripButton_Disconnect.Enabled = False
            cmb_MasterNames.BackColor = Color.FromArgb(220, 220, 220)
            cmb_MasterNames.Enabled = False
            btn_MasterName.Enabled = False
        Else
            ToolStripButton_Disconnect.Enabled = True
            cmb_MasterNames.BackColor = Color.AliceBlue
            cmb_MasterNames.Enabled = True
            btn_MasterName.Enabled = True
        End If
    End Sub

    ' ===========================================================================================================
    '   Commands execution
    ' ===========================================================================================================
    Private Sub Cmd_Recognize()
        EventsAreEnabled = False
        Dim OldSelectedLine As Int32 = SelectedLine
        Load_ConfigDatabase()
        Timer_10Hz.Stop()
        TheSystem_StopTimers()
        TheSystem_InitMasters()
        TheSystem_RecognizeSlaves()
        ShowProps()
        TheSystem_StartTimers()
        Timer_10Hz.Start()
        EventsAreEnabled = True
        If OldSelectedLine < 0 Then OldSelectedLine = 0
        ListView_SelectLine(MyListView1, OldSelectedLine)
        Form2.RestoreSelectedPins()
    End Sub
    Private Sub Cmd_Validate()
        If Not EventsAreEnabled Then Return
        EventsAreEnabled = False
        Dim OldSelectedLine As Int32 = SelectedLine
        TheSystem_ValidateConfiguration()
        TheSystem_UpdateAndSaveConfigDatabase()
        TheSystem_StartTimers()
        EventsAreEnabled = True
        ListView_SelectLine(MyListView1, OldSelectedLine)
    End Sub
    Private Sub Cmd_DisconnectSelectedMaster()
        EventsAreEnabled = False
        Load_ConfigDatabase()
        Timer_10Hz.Stop()
        TheSystem_StopTimers()
        ' -----------------------------------------------------
        TheSystem_DisconnectMaster(GetMasterByListLine(SelectedLine, LineType(SelectedLine)))
        TheSystem_ListComponents()
        ListView_SetAllLineColors()
        SelectedLine = -1
        ' -----------------------------------------------------
        ShowProps()
        TheSystem_StartTimers()
        Timer_10Hz.Start()
        EventsAreEnabled = True
        ListView_SelectLine(MyListView1, 0)
    End Sub
    Private Sub btn_Calibrate_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_Calibrate.ClickButtonArea
        If Not EventsAreEnabled Then Return
        EventsAreEnabled = False
        DoCalibrationAndResetTime()
        CalibrationTime = 0.8
        btn_Calibrate.Refresh()
        EventsAreEnabled = True
    End Sub


    ' ===========================================================================================================
    '   UPDATES
    ' ===========================================================================================================
    Private Sub Timer_10Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_10Hz.Tick
        If Not EventsAreEnabled Then Return
        SyncLock EventsLock
            '
            If WindowState <> FormWindowState.Minimized Then
                ' ---------------------------------------------------------- UpdateListedValues
                TheSystem_UpdateListedValues()
                ' ---------------------------------------------------------- update RepeatFrequency
                Dim m As Master = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
                If m IsNot Nothing Then
                    lbl_RepeatFrequency.Text = m.CommFps.ToString("0")
                    If m.CommFps < 50 Then
                        lbl_RepeatFrequency.BackColor = Color.LightSalmon
                    Else
                        lbl_RepeatFrequency.BackColor = Color.Transparent
                    End If
                    lbl_ErrorRate.Text = m.ErrorRate.ToString("0.00", Globalization.CultureInfo.InvariantCulture)
                    If m.ErrorRate >= 0.1 Then
                        lbl_ErrorRate.BackColor = Color.LightSalmon
                        m.SetSpeed()
                    Else
                        lbl_ErrorRate.BackColor = Color.Transparent
                    End If
                    If m.ErrorRate >= 0.01 Then
                        If ToolStripButton_BeepOnErrors.Checked Then Beep_RepetitionLimited(150)
                    End If
                    ' -----------------------------------------------------------
                    '  Auto Recognize
                    ' ----------------------------------------------------------- ToDo add a enable button 
                    'If m.ErrorRate >= 0.01 Or Not ConfigurationIsValid Then
                    '    Cmd_Recognize()
                    'End If
                End If
            End If
            '
            If EditValue_MouseEditFlag Then
                ' ---------------------------------------------------------- edit
                If LeftMousePressed() Then
                    EditValue_MouseMove()
                Else
                    ShowCursor()
                    EditValue_MouseEditFlag = False
                End If
            End If
            '
        End SyncLock
    End Sub

    Private Sub MyListView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseUp
        Form2.SetPinDetails()
    End Sub

    Private Sub MyListView1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyListView1.Resize
        If Not EventsAreEnabled Then Return
        TheSystem_ListViewResize()
    End Sub



    ' ===========================================================================================================
    '   EDIT VALUES
    ' ===========================================================================================================
    Private EditValue_MouseEditFlag As Boolean = False
    Private EditValue_Slot As Int32
    Private EditValue_Multiplier As Int32
    Private EditValue_StartCursorPos As Point
    Private EditValue_MaxValue As Single
    Private EditValue_MinValue As Single

    Private Sub MyListView1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseDown
        StartMouseEdit()
    End Sub

    Private Sub StartMouseEdit()
        If EditValue_MouseEditFlag Then Return
        Dim column As Int32 = ListView_GetColumnIndex(MyListView1)
        Dim line As Int32 = ListView_GetLineIndex(MyListView1)
        If column = 5 And line >= 0 Then
            Dim slotString As String = MyListView1.Items(line).SubItems(4).Text
            If slotString <> "" Then
                Dim p As Pin = FindPinByListLine(line)
                If p IsNot Nothing AndAlso p.GetPinType <> Pin.PinTypes.UNUSED Then
                    HideCursor()
                    EditValue_MouseEditFlag = True
                    EditValue_StartCursorPos = Cursor.Position
                    ' ----------------------------------------------------------------------
                    EditValue_Slot = p.Slot
                    EditValue_MaxValue = CSng(Math.Max(p.Value_Max, p.Value_Min))
                    EditValue_MinValue = CSng(Math.Min(p.Value_Max, p.Value_Min))
                    EditValue_Multiplier = 1
                    Dim range As Int32 = CInt(Math.Abs(p.Value_Max - p.Value_Min))
                    If range > 500 Then EditValue_Multiplier = 2
                    If range > 1000 Then EditValue_Multiplier = 5
                    If range > 2000 Then EditValue_Multiplier = 10
                    If range > 5000 Then EditValue_Multiplier = 20
                    If range > 10000 Then EditValue_Multiplier = 50
                End If
            End If
        End If
    End Sub

    Private Sub MyListView1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseMove
        If Not EventsAreEnabled Then Return
        If EditValue_MouseEditFlag Then
            EditValue_MouseMove()
        End If
    End Sub

    Private Sub EditValue_MouseMove()
        Dim delta As Int32 = EditValue_StartCursorPos.Y - Cursor.Position.Y
        Cursor.Position = EditValue_StartCursorPos
        ChangeValueByDelta(delta)
    End Sub

    Private Sub ChangeValueByDelta(ByVal delta As Single)
        'Form2.StopTimer()
        EventsAreEnabled = False

        Dim v As Single
        If OperatingSystemIsWindows Then
            v = ReadSlot(EditValue_Slot)
        Else
            v = ReadSlot_Unix(EditValue_Slot)
        End If

        If Single.IsNaN(v) Then
            v = EditValue_MinValue - 9
        End If
        '
        v += delta * EditValue_Multiplier
        v = Math.Min(v, EditValue_MaxValue)
        'v = Math.Max(v, EditValue_MinValue)
        '
        If v < EditValue_MinValue Then
            If v < -8 Then
                v = NAN_Sleep
            Else
                v = EditValue_MinValue
            End If
        End If
        '
        If OperatingSystemIsWindows Then
            WriteSlot(EditValue_Slot, v)
        Else
            WriteSlot_Unix(EditValue_Slot, v)
        End If
        '
        Application.DoEvents()

        EventsAreEnabled = True
        'Form2.StartTimer()
    End Sub

    Private Sub MyListView1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyListView1.MouseDoubleClick
        Form2.Show()
    End Sub


    ' ---------------------------------------------------------------------------------------------------
    '  MyListView1.Activation = ItemActivation.Standard   <<<< USE THIS OR THE CURSOR CAN NOT BE CHANGED
    ' ---------------------------------------------------------------------------------------------------
    Private BlankCursor As Cursor = New Cursor(New IO.MemoryStream(My.Resources.Blank))
    Private Sub HideCursor()
        Cursor.Hide()
        MyListView1.Cursor = BlankCursor
    End Sub
    Private Sub ShowCursor()
        Cursor.Show()
        MyListView1.Cursor = Cursors.Hand
    End Sub



    ' ===========================================================================================================
    '   SET MASTER AND PIN PROPERTIES
    ' ===========================================================================================================
    Private Sub btn_MasterName_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_MasterName.ClickButtonArea
        Dim newName As String
        newName = InputBox("New name for the selected master", _
                           "Edit Master name", _
                           cmb_MasterNames.Text, _
                           Me.Right - 370, _
                           Me.Top + 125)
        If newName <> "" Then




            Change_SelectedMaster_Name(newName)
        End If
    End Sub

    Private Sub Change_SelectedMaster_Name(ByVal newName As String)
        Me.Cursor = Cursors.AppStarting
        ' --------------------------------------------------------------------- init master
        Dim m As Master
        m = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
        If m Is Nothing Then
            Return
        End If
        Dim oldName As String = m.GetName
        ' --------------------------------------------------------------------- try to change the hardware name
        If newName <> oldName Then
            For i As Int32 = 1 To 3
                m.SetName(newName)
                m.WriteNameToHardware()
                m.ReadNameFromHardware()
                If m.GetName = newName Then
                    ' --------------------------------------------------------- if the new name is not in the database
                    If FindConfigByName(newName) < 0 Then
                        Dim configid As Int32 = FindConfigByName(oldName)
                        Dim config As String() = CType(CType(ConfigDatabase(configid), String()).Clone, String())
                        config(0) = config(0).Replace(oldName, newName)
                        AddToConfigDatabase(config)
                        TheSystem_SaveConfigDatabase()
                    End If
                    ' --------------------------------------------------------- 
                    Cmd_Recognize()
                    Combo_Init(cmb_MasterNames, newName)
                    TheSystem_UpdateListedSubtypes()
                    TheSystem_UpdateConfigDatabase()
                    TheSystem_SaveConfigDatabase()
                    Exit For
                End If
            Next
        End If
        Me.Cursor = Cursors.Default
    End Sub


    Private Sub CommSpeed_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_CommSpeed.TextChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        Timer_10Hz.Stop()
        Dim m As Master = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
        If m IsNot Nothing Then
            m.SetSpeed(txt_CommSpeed.NumericValueInteger)
            txt_CommSpeed.Refresh()
            ' -------------------------------------------------- save changes to database immediately
            TheSystem_UpdateConfigDatabase()
        End If
        Timer_10Hz.Start()
    End Sub

    Private Sub chk_FastDataExchange_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_FastDataExchange.CheckedChanged
        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        Dim m As Master = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
        If m IsNot Nothing Then
            m.FastComm = chk_FastDataExchange.Checked
            ' -------------------------------------------------- save changes to database immediately
            TheSystem_UpdateConfigDatabase()
        End If
    End Sub

    Private Sub txt_MinVariation_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_MinVariation.TextChanged


        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        EnableCalibrateButton(TheSystem_CalibrationNeeded())
    End Sub


    Private Sub PinProps_Changed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Slot.TextChanged, _
                                                                                                     txt_MaxValue.TextChanged, _
                                                                                                     txt_MinValue.TextChanged, _
                                                                                                     Label_ResponseSpeed.CheckedChanged, _
                                                                                                     txt_ResponseSpeed.TextChanged, _
                                                                                                     txt_ServoMaxTime.TextChanged, _
                                                                                                     txt_ServoMinTime.TextChanged, _
                                                                                                     chk_LogResponse.CheckedChanged, _
                                                                                                     chk_RemoveErrors.CheckedChanged, _
                                                                                                     txt_CapMaxDist.TextChanged, _
                                                                                                     txt_CapMinDist.TextChanged, _
                                                                                                     txt_CapArea.TextChanged, _
                                                                                                     txt_MaxFreq.TextChanged, _
                                                                                                     txt_MinFreq.TextChanged, _
                                                                                                     txt_MinVariation.TextChanged, _
                                                                                                     txt_ProportionalArea.TextChanged


        If Not EventsAreEnabled Then Return
        If SelectedLine < 0 Then Exit Sub
        SetPinProps()
    End Sub


    Private Sub SetPinProps()
        Select Case LineType(SelectedLine)
            Case "Pin"
                Dim p As Pin = FindPinByListLine(SelectedLine)
                Dim n As Int32 = txt_Slot.NumericValueInteger
                If n <> p.Slot Then
                    p.Slot = n
                    Dim Str As String = p.Slot.ToString()
                    With MyListView1.Items(SelectedLine)
                        If Str <> .SubItems(4).Text Then .SubItems(4).Text = Str
                    End With
                End If
                '
                p.Value_Max = CSng(txt_MaxValue.NumericValue)
                p.Value_Min = CSng(txt_MinValue.NumericValue)
                p.AdaptiveSpeed = Label_ResponseSpeed.Checked
                p.ResponseSpeed = txt_ResponseSpeed.NumericValueInteger
                '
                Select Case p.GetPinType
                    Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                        p.MaxTime = CSng(txt_ServoMaxTime.NumericValue)
                        p.MinTime = CSng(txt_ServoMinTime.NumericValue)
                    Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                        p.MaxTime = CSng(txt_ServoMaxTime.NumericValue)
                        p.MinTime = CSng(txt_ServoMinTime.NumericValue)
                        p.LogResponse = chk_LogResponse.Checked
                    Case Pin.PinTypes.CAP_8, Pin.PinTypes.CAP_16
                        p.MinVariation = CSng(txt_MinVariation.NumericValue)
                        p.ProportionalArea = CSng(txt_ProportionalArea.NumericValue)
                    Case Pin.PinTypes.USOUND_SENSOR
                        p.MaxDist_mm = CSng(txt_CapMaxDist.NumericValue)
                        p.MinDist_mm = CSng(txt_CapMinDist.NumericValue)
                        p.RemoveErrors = chk_RemoveErrors.Checked
                    Case Pin.PinTypes.CAP_SENSOR
                        p.MaxDist_mm = CSng(txt_CapMaxDist.NumericValue)
                        p.MinDist_mm = CSng(txt_CapMinDist.NumericValue)
                        p.Area_cmq = CSng(txt_CapArea.NumericValue)
                    Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                         Pin.PinTypes.FAST_COUNTER, Pin.PinTypes.FAST_COUNTER_PU, _
                         Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                        p.MaxFreq = CSng(txt_MaxFreq.NumericValue)
                        p.MinFreq = CSng(txt_MinFreq.NumericValue)
                        p.ConvertToFreq = chk_ConvertToFrequency.Checked
                End Select
                '
                TheSystem_UpdateConfigDatabase()
        End Select
    End Sub





    ' ====================================================================================================
    '   PARAMS LOST FOCUS - SaveConfigDatabase 
    ' ====================================================================================================

    Private Sub MasterProps_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Slot.LostFocus
        If Not EventsAreEnabled Then Return
        TheSystem_SaveConfigDatabase()
    End Sub

    Private Sub Master_CommProps_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_CommSpeed.LostFocus
        If Not EventsAreEnabled Then Return
        TheSystem_SaveConfigDatabase()
    End Sub

    Private Sub PinProps_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Slot.LostFocus, _
                                                                                                        txt_MaxValue.LostFocus, _
                                                                                                        txt_MinValue.LostFocus, _
                                                                                                        Label_ResponseSpeed.LostFocus, _
                                                                                                        txt_ResponseSpeed.LostFocus, _
                                                                                                        txt_CapMaxDist.LostFocus, _
                                                                                                        txt_CapMinDist.LostFocus, _
                                                                                                        txt_CapArea.LostFocus, _
                                                                                                        txt_ServoMaxTime.LostFocus, _
                                                                                                        txt_ServoMinTime.LostFocus, _
                                                                                                        chk_LogResponse.LostFocus, _
                                                                                                        chk_RemoveErrors.LostFocus, _
                                                                                                        txt_MaxFreq.LostFocus, _
                                                                                                        txt_MinFreq.LostFocus, _
                                                                                                        txt_MinVariation.LostFocus, _
                                                                                                        txt_ProportionalArea.LostFocus
        TheSystem_SaveConfigDatabase()
    End Sub


    Private Sub txt_MinChange_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_MinChange.LostFocus
        Save_INI()
    End Sub


    Private Sub chk_ConvertToFrequency_CheckedChanged(ByVal Sender As Object, ByVal e As System.EventArgs) Handles chk_ConvertToFrequency.CheckedChanged
        SetPinProps()
        TheSystem_SaveConfigDatabase()
        ShowProps()
    End Sub


    ' ====================================================================================================
    '   COMBO MASTER NAMES
    ' ====================================================================================================
    Private Sub cmb_MasterNames_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_MasterNames.DropDown
        Dim oldname As String = cmb_MasterNames.Items(0).ToString
        cmb_MasterNames.ItemHeight = 16
        cmb_MasterNames.Items.Clear()
        Load_ConfigDatabase()
        FillConfigNamesCombo(cmb_MasterNames)
        Combo_SetIndex_FromString(cmb_MasterNames, oldname)
    End Sub
    Private Sub cmb_MasterNames_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_MasterNames.DropDownClosed
        cmb_MasterNames.ItemHeight = 12
        Combo_Init(cmb_MasterNames, cmb_MasterNames.Text)
    End Sub
    Private Sub cmb_MasterNames_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_MasterNames.SelectionChangeCommitted
        Change_SelectedMaster_Name(cmb_MasterNames.Text)
    End Sub


    ' ====================================================================================================
    '   COMBO PIN TYPE
    ' ====================================================================================================
    Private Sub cmb_PinType_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.DropDown
        cmb_PinType.ItemHeight = 16
        Dim p As Pin = FindPinByListLine(SelectedLine)
        Masters(p.MasterId).Slaves(p.SlaveId).FillTypeCombo(cmb_PinType, p)
        Combo_SetIndex_FromString(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
    End Sub
    Private Sub cmb_PinType_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.DropDownClosed
        cmb_PinType.ItemHeight = 12
    End Sub
    Private Sub cmb_PinType_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_PinType.SelectionChangeCommitted
        Dim p As Pin = FindPinByListLine(SelectedLine)

        ' TODO -------------------------------------------------------------- This must be atomic
        p.SetPinType(Pin.StringToPinType(cmb_PinType.Items(cmb_PinType.SelectedIndex).ToString))
        Masters(p.MasterId).SetupSlavePins(p.SlaveId)
        ' ----------------------------------------------------------------------------------------

        ' -------------------------------------------------------------------------- 
        Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
        ' -------------------------------------------------------------------------- set PinType and Direction
        TheSystem_UpdateListedSubtypes()
        With MyListView1.Items(SelectedLine)
            .SubItems(2).Text = Pin.PinTypeToString(p.GetPinType)
            .SubItems(3).Text = p.GetDirectionString
            .SubItems(4).Text = If(p.GetPinType = Pin.PinTypes.UNUSED, "", p.Slot.ToString())
            .SubItems(5).Text = ""
        End With
        ' -------------------------------------------------------------------------- set Color
        ListView_SetAllLineColors()
        ' -------------------------------------------------------------------------- set pin props
        ShowProps()
        SetPinProps()
        ' -------------------------------------------------------------------------- 
        TheSystem_UpdateAndSaveConfigDatabase()
        ' -------------------------------------------------------------------------- 
        EnableCalibrateButton(TheSystem_CalibrationNeeded())
        If btn_Calibrate.Enabled Then
            Select Case p.GetPinType
                Case Pin.PinTypes.CAP_SENSOR, Pin.PinTypes.CAP_16, Pin.PinTypes.CAP_16
                    DoCalibrationAndResetTime()
            End Select
        End If
    End Sub



    ' ===========================================================================================================
    '   SHOW PROPS
    ' ===========================================================================================================

    Friend Sub ListView_SetAllLineColors()
        ' -------------------------------------------------------------------- select the listview "SelectedLine"
        If SelectedLine >= 0 And SelectedLine < MyListView1.Items.Count Then
            MyListView1.Items(SelectedLine).Selected = True
        End If
        ' -------------------------------------------------------------------- show listview colors
        For i As Int32 = 0 To MyListView1.Items.Count - 1
            ListView_SetLineColors(MyListView1, i)
        Next
    End Sub


    Private Sub ListView_SetLineColors(ByVal lv As ListView, ByVal line As Int32)
        If line < 0 Or line >= lv.Items.Count Then Return
        '
        Dim fc As Color
        Dim bc As Color
        If lv.Items(line).Selected Then
            ' ----------------------------------------------------------------- selected colors
            bc = Color.FromArgb(49, 106, 197)
            fc = Color.White
        Else
            ' ----------------------------------------------------------------- deselected colors
            If line >= 0 Then
                Select Case LineType(line)
                    Case "Master" : bc = Color.FromArgb(180, 205, 255) '(190, 215, 255)
                    Case "Slave" : bc = Color.FromArgb(255, 200, 160) '(245, 215, 185) '(255, 230, 200)
                    Case "Pin"
                        If LineSubType(line) <> "Unused" Then
                            If LineDirection(line) = "set" Then
                                bc = Color.FromArgb(245, 245, 215) '(255, 255, 225)
                            Else
                                bc = Color.FromArgb(225, 245, 230) '(235, 255, 240)
                            End If
                        Else
                            bc = Color.FromArgb(255, 255, 255)
                        End If
                End Select
                fc = Color.Black
            End If
        End If
        lv.Items(line).ForeColor = fc
        lv.Items(line).BackColor = bc
    End Sub

    Private Function LineType(ByVal line As Int32) As String
        If line < 0 Then Return ""
        Return MyListView1.Items(line).SubItems(0).Text.Trim
    End Function
    Private Function LineSubType(ByVal line As Int32) As String
        Return MyListView1.Items(line).SubItems(2).Text.Trim
    End Function
    Private Function LineDirection(ByVal line As Int32) As String
        Return MyListView1.Items(line).SubItems(3).Text.Trim
    End Function

    Friend SelectedLine As Int32 = -1
    Private Sub MyListView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyListView1.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        SyncLock EventsLock
            ' --------------------------------------------------------- change line colors and update "SelectedLine"
            If MyListView1.SelectedIndices.Count > 0 Then
                SelectedLine = MyListView1.SelectedIndices(0)
                If ConfigurationIsValid Then ListView_SetLineColors(MyListView1, SelectedLine)
            Else
                If ConfigurationIsValid Then ListView_SetLineColors(MyListView1, SelectedLine)
                SelectedLine = -1
            End If
            ' --------------------------------------------------------- show line props
            ShowProps()
        End SyncLock
    End Sub

    Private Sub ShowProps()
        '
        EventsAreEnabled = False
        '
        GroupBox_PinProps.Visible = False
        GroupBox_TouchProps.Visible = False
        GroupBox_CapSensorProps.Visible = False
        GroupBox_ServoPwmProps.Visible = False
        GroupBox_FrequencyProps.Visible = False
        '
        If SelectedLine < 0 Or SelectedLine > MyListView1.Items.Count - 1 Then
            GroupBox_MasterProps.Enabled = False
            txt_CommSpeed.Text = "-"
        Else
            GroupBox_MasterProps.Enabled = True
            '
            Dim m As Master = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
            Dim p As Pin = FindPinByListLine(SelectedLine)
            '
            If Not ConfigurationIsValid Then
                GroupBox_MasterProps.Height = cmb_MasterNames.Bottom + 7
                If m IsNot Nothing Then
                    Combo_Init(cmb_MasterNames, m.GetName)
                Else
                    Combo_Init(cmb_MasterNames, "")
                    GroupBox_MasterProps.Enabled = False
                    txt_CommSpeed.Text = "-"
                End If
            Else
                GroupBox_MasterProps.Height = chk_FastDataExchange.Bottom + 6 '130
                '
                Select Case LineType(SelectedLine)
                    Case "Master"
                        GroupBox_PinProps.Visible = False
                        GroupBox_CapSensorProps.Visible = False
                        GroupBox_ServoPwmProps.Visible = False
                    Case "Slave"
                        GroupBox_PinProps.Visible = False
                        GroupBox_CapSensorProps.Visible = False
                        GroupBox_ServoPwmProps.Visible = False
                    Case "Pin"
                        GroupBox_PinProps.Visible = True
                        GroupBox_PinProps.Left = GroupBox_MasterProps.Left
                        GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 8
                End Select
                '
                If m IsNot Nothing Then
                    Combo_Init(cmb_MasterNames, m.GetName)
                    txt_CommSpeed.NumericValueInteger = m.CommSpeed
                    chk_FastDataExchange.Checked = m.FastComm
                    '
                    If m.HasPhysicalSlaves Then
                        chk_FastDataExchange.Enabled = True
                    Else
                        chk_FastDataExchange.Enabled = False
                    End If
                    ToolTips_Init()
                    '
                    If p IsNot Nothing Then
                        Combo_Init(cmb_PinType, Pin.PinTypeToString(p.GetPinType))
                        txt_Slot.NumericValue = p.Slot
                        txt_MaxValue.NumericValue = p.Value_Max
                        txt_MinValue.NumericValue = p.Value_Min
                        Label_ResponseSpeed.Checked = p.AdaptiveSpeed
                        txt_ResponseSpeed.NumericValueInteger = p.ResponseSpeed
                        Select Case p.GetPinType
                            Case Pin.PinTypes.UNUSED
                                GroupBox_PinProps.Height = cmb_PinType.Bottom + 8
                            Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16
                                GroupBox_ServoPwmProps.Text = "Servo properties"
                                txt_ServoMaxTime.NumericValue = p.MaxTime
                                txt_ServoMinTime.NumericValue = p.MinTime
                                GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left
                                GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_ServoPwmProps.Height = txt_ServoMinTime.Bottom + 8
                                GroupBox_ServoPwmProps.Visible = True
                            Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16
                                GroupBox_ServoPwmProps.Text = "PWM properties"
                                txt_ServoMaxTime.NumericValue = p.MaxTime
                                txt_ServoMinTime.NumericValue = p.MinTime
                                chk_LogResponse.Checked = p.LogResponse
                                GroupBox_ServoPwmProps.Left = GroupBox_PinProps.Left
                                GroupBox_ServoPwmProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_ServoPwmProps.Height = chk_LogResponse.Bottom + 7
                                GroupBox_ServoPwmProps.Visible = True
                            Case Pin.PinTypes.CAP_8, Pin.PinTypes.CAP_16
                                GroupBox_TouchProps.Text = "Touch properties"
                                txt_MinVariation.NumericValue = p.MinVariation
                                txt_ProportionalArea.NumericValue = p.ProportionalArea
                                GroupBox_TouchProps.Left = GroupBox_PinProps.Left
                                GroupBox_TouchProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_TouchProps.Visible = True
                            Case Pin.PinTypes.USOUND_SENSOR
                                GroupBox_CapSensorProps.Text = "UltraSound properties"
                                txt_CapMaxDist.NumericValue = p.MaxDist_mm
                                txt_CapMinDist.NumericValue = p.MinDist_mm
                                GroupBox_CapSensorProps.Left = GroupBox_PinProps.Left
                                GroupBox_CapSensorProps.Top = GroupBox_PinProps.Bottom + 6
                                chk_RemoveErrors.Location = Label_Area.Location
                                chk_RemoveErrors.Visible = True
                                chk_RemoveErrors.Checked = p.RemoveErrors
                                Label_Area.Visible = False
                                txt_CapArea.Visible = False
                                GroupBox_CapSensorProps.Height = txt_CapArea.Bottom + 8
                                GroupBox_CapSensorProps.Visible = True
                            Case Pin.PinTypes.CAP_SENSOR
                                GroupBox_CapSensorProps.Text = "Cap sensor properties"
                                txt_CapMaxDist.NumericValue = p.MaxDist_mm
                                txt_CapMinDist.NumericValue = p.MinDist_mm
                                GroupBox_CapSensorProps.Left = GroupBox_PinProps.Left
                                GroupBox_CapSensorProps.Top = GroupBox_PinProps.Bottom + 6
                                txt_CapArea.NumericValue = p.Area_cmq
                                chk_RemoveErrors.Visible = False
                                Label_Area.Visible = True
                                txt_CapArea.Visible = True
                                GroupBox_CapSensorProps.Height = txt_CapArea.Bottom + 8
                                GroupBox_CapSensorProps.Visible = True
                            Case Pin.PinTypes.COUNTER, Pin.PinTypes.COUNTER_PU, _
                                 Pin.PinTypes.FAST_COUNTER, Pin.PinTypes.FAST_COUNTER_PU, _
                                 Pin.PinTypes.PERIOD, Pin.PinTypes.PERIOD_PU
                                GroupBox_FrequencyProps.Text = "Freq. properties"
                                chk_ConvertToFrequency.Checked = p.ConvertToFreq
                                txt_MaxFreq.NumericValue = p.MaxFreq
                                txt_MinFreq.NumericValue = p.MinFreq
                                If chk_ConvertToFrequency.Checked Then
                                    GroupBox_PinProps.Height = txt_ResponseSpeed.Bottom + 10
                                    GroupBox_FrequencyProps.Height = txt_MinFreq.Bottom + 8
                                Else
                                    GroupBox_PinProps.Height = txt_Slot.Bottom + 7
                                    GroupBox_FrequencyProps.Height = chk_ConvertToFrequency.Bottom + 10
                                End If
                                GroupBox_FrequencyProps.Left = GroupBox_PinProps.Left
                                GroupBox_FrequencyProps.Top = GroupBox_PinProps.Bottom + 6
                                GroupBox_FrequencyProps.Visible = True
                        End Select
                    End If
                End If
            End If
        End If
        '
        EventsAreEnabled = True
    End Sub



    ' ==============================================================================================================
    '  AUTO CALIBRATION
    ' ==============================================================================================================
    Private Sub Timer_1Hz_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer_1Hz.Tick
        If Not EventsAreEnabled Then Return
        If btn_Calibrate.Enabled Then
            If txt_MinChange.NumericValueInteger > 0 Then
                TestDeltaToRestartCalibrationTime()
                TestCalibrationTime()
            Else
                CalibrationTime = 0
            End If
            ShowCalibrationRedLine()
        End If
    End Sub


    ' ==============================================================================================================
    '   AUTO CALIBRATION
    ' ==============================================================================================================
    Private CalibrationTime As Double

    Private Sub TestDeltaToRestartCalibrationTime()
        For Each m As Master In Masters
            For i As Int32 = 0 To m.SlaveCount - 1
                Dim rd As UInt32 = m.Slaves(i).Get_CapSensor_Or_Cap_Delta
                If rd > txt_MinChange.NumericValueInteger Then
                    CalibrationTime = 0
                    ShowCalibrationRedLine()
                End If
            Next
        Next
    End Sub

    Private Sub TestCalibrationTime()
        If Not EventsAreEnabled Then Return
        CalibrationTime += 0.033
        If CalibrationTime > 0.99 Then
            DoCalibrationAndResetTime()
        End If
    End Sub

    Private Sub DoCalibrationAndResetTime()
        CalibrationTime = 0
        btn_Calibrate.Checked = True
        btn_Calibrate.Refresh()
        TheSystem_Calibrate()
        System.Threading.Thread.Sleep(100)
        btn_Calibrate.Checked = False
    End Sub

    Private Sub ShowCalibrationRedLine()
        FillPictureBox_Horizontal(Pic_CalibrateTime, CalibrationTime, Color.FromArgb(255, 120, 0), Color.LightGray)
    End Sub

    Friend Sub EnableCalibrateButton(ByVal enable As Boolean)
        If enable Then
            CalibrationTime = 0.6 ' start with 10 seconds delay
        Else
            CalibrationTime = 0
        End If
        ShowCalibrationRedLine()
        btn_Calibrate.Enabled = enable
        txt_MinChange.Enabled = enable
    End Sub


    ' ==============================================================================================================
    '   ToolTips
    ' ==============================================================================================================
    Private WithEvents ttp1 As ToolTip = New ToolTip
    Private Sub ToolTips_Init()
        ttp1.ShowAlways = True
        ttp1.UseAnimation = True
        ttp1.UseFading = True
        ttp1.IsBalloon = True
        ttp1.AutoPopDelay = 32700
        ttp1.InitialDelay = 500
        ttp1.ReshowDelay = 500
        ' --------------------------------------------------------------- Add here Controls and ToolTip-Text
        Dim m As Master = GetMasterByListLine(SelectedLine, LineType(SelectedLine))
        If m IsNot Nothing Then
            If m.HasPhysicalSlaves Then
                ttp1.SetToolTip(txt_CommSpeed, _
                     Msg_CommSpeed1 & vbCrLf & _
                     "- - - - - - - - - - - - - - -" & vbCrLf & _
                     "  1  =     1  Kilo-Baud" & vbCrLf & _
                     "  2  =     2  Kilo-Baud" & vbCrLf & _
                     "  3  =     5  Kilo-Baud" & vbCrLf & _
                     "  4  =   10  Kilo-Baud" & vbCrLf & _
                     "  5  =   20  Kilo-Baud" & vbCrLf & _
                     "  6  =   50  Kilo-Baud" & vbCrLf & _
                     "  7  = 100  Kilo-Baud" & vbCrLf & _
                     "  8  = 200  Kilo-Baud" & vbCrLf & _
                     "  9  = 500  Kilo-Baud" & vbCrLf & _
                     "10  =  1  Mega-Baud" & vbCrLf & _
                     "11  =  2  Mega-Baud" & vbCrLf & _
                     "12  =  4  Mega-Baud")
            Else
                ttp1.SetToolTip(txt_CommSpeed, _
                     Msg_CommSpeed1 & vbCrLf & _
                     "- - - - - - - - - - - - - - -" & vbCrLf & _
                     "  1  =  10 fps" & vbCrLf & _
                     "  2  =  20 fps" & vbCrLf & _
                     "  3  =  30 fps" & vbCrLf & _
                     "  4  =  50 fps" & vbCrLf & _
                     "  5  =  60 fps" & vbCrLf & _
                     "  6  = 100 fps" & vbCrLf & _
                     "  7  = 150 fps" & vbCrLf & _
                     "  8  = 200 fps" & vbCrLf & _
                     "  9  = 300 fps" & vbCrLf & _
                     "10  =  400 fps" & vbCrLf & _
                     "11  =  500 fps" & vbCrLf & _
                     "12  =  Max fps")
            End If
        End If

        ttp1.SetToolTip(txt_MinChange, Msg_MinChange1 & vbCrLf & _
                                        Msg_MinChange2 & vbCrLf & _
                                        Msg_MinChange3 & vbCrLf & _
                                        Msg_MinChange4 & vbCrLf & _
                                        Msg_MinChange5 & vbCrLf & _
                                        Msg_MinChange6)

        ttp1.SetToolTip(txt_CapArea, Msg_CapArea1 & vbCrLf & _
                                        Msg_CapArea2 & vbCrLf & _
                                        Msg_CapArea3 & vbCrLf & _
                                        Msg_CapArea4 & vbCrLf & _
                                        Msg_CapArea5 & vbCrLf & _
                                        Msg_CapArea6)

        ttp1.SetToolTip(Label_ResponseSpeed, Msg_Filter1 & vbCrLf & _
                                        Msg_Filter2 & vbCrLf & _
                                        Msg_Filter3 & vbCrLf & _
                                        Msg_Filter4 & vbCrLf & _
                                        Msg_Filter5)

        ToolStripButton_EditConfig.ToolTipText = Msg_Configuratons1
        ToolStripButton_Recognize.ToolTipText = Msg_Recognize1
        ToolStripButton_Validate.ToolTipText = Msg_Validate1
        ToolStripButton_BeepOnErrors.ToolTipText = Msg_BeepOnErrors1
        ToolStripButton_Lock.ToolTipText = Msg_Lock1 & vbCrLf & Msg_Lock2
        ToolStripButton_Disconnect.ToolTipText = Msg_Disconnect1
    End Sub

    ' --------------------- this corrects the XP bug that causes tooltip disappearing for ever 
    Private Sub controls_MouseEnter(ByVal sender As Object, _
                                   ByVal e As System.EventArgs) Handles txt_CommSpeed.MouseEnter, _
                                                                        txt_MinChange.MouseEnter, _
                                                                        txt_CapArea.MouseEnter
        ttp1.Active = False
        ttp1.Active = True
    End Sub

End Class


