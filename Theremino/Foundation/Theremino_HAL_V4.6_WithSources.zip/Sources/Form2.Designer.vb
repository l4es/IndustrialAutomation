﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Dim CBlendItems1 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems2 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker2 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker3 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems3 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems4 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker4 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker5 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems5 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems6 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker6 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim DesignerRectTracker7 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Dim CBlendItems7 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim CBlendItems8 As CustomControlsLib.cBlendItems = New CustomControlsLib.cBlendItems
        Dim DesignerRectTracker8 As CustomControlsLib.DesignerRectTracker = New CustomControlsLib.DesignerRectTracker
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btn_TextLog = New CustomControlsLib.MyButton
        Me.tkbar_VerticalScaleZoom = New System.Windows.Forms.TrackBar
        Me.Label_VerticalScaleZoom = New System.Windows.Forms.Label
        Me.btn_SetZero = New CustomControlsLib.MyButton
        Me.btn_BeepOnChange = New CustomControlsLib.MyButton
        Me.pbox_Details2 = New System.Windows.Forms.PictureBox
        Me.lbl_Details2 = New System.Windows.Forms.Label
        Me.LabelPin1 = New System.Windows.Forms.Label
        Me.LabelPin2 = New System.Windows.Forms.Label
        Me.btn_ShowRawCount = New CustomControlsLib.MyButton
        Me.tkbar_ScrollSpeed = New System.Windows.Forms.TrackBar
        Me.Label_ScrollSpeed = New System.Windows.Forms.Label
        Me.pbox_Details1 = New System.Windows.Forms.PictureBox
        Me.lbl_Details1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label_Scale1b = New System.Windows.Forms.Label
        Me.Label_Scale2b = New System.Windows.Forms.Label
        Me.Label_Scale3b = New System.Windows.Forms.Label
        Me.rtb_SnifferLog = New System.Windows.Forms.RichTextBox
        Me.pbox_ScrollingScope = New System.Windows.Forms.PictureBox
        Me.Label_Scale3 = New System.Windows.Forms.Label
        Me.Label_Scale2 = New System.Windows.Forms.Label
        Me.Label_Scale1 = New System.Windows.Forms.Label
        Me.Timer_60Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox3.SuspendLayout()
        CType(Me.tkbar_VerticalScaleZoom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox_Details2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tkbar_ScrollSpeed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox_Details1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pbox_ScrollingScope, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox3.Controls.Add(Me.btn_TextLog)
        Me.GroupBox3.Controls.Add(Me.tkbar_VerticalScaleZoom)
        Me.GroupBox3.Controls.Add(Me.Label_VerticalScaleZoom)
        Me.GroupBox3.Controls.Add(Me.btn_SetZero)
        Me.GroupBox3.Controls.Add(Me.btn_BeepOnChange)
        Me.GroupBox3.Controls.Add(Me.pbox_Details2)
        Me.GroupBox3.Controls.Add(Me.lbl_Details2)
        Me.GroupBox3.Controls.Add(Me.LabelPin1)
        Me.GroupBox3.Controls.Add(Me.LabelPin2)
        Me.GroupBox3.Controls.Add(Me.btn_ShowRawCount)
        Me.GroupBox3.Controls.Add(Me.tkbar_ScrollSpeed)
        Me.GroupBox3.Controls.Add(Me.Label_ScrollSpeed)
        Me.GroupBox3.Controls.Add(Me.pbox_Details1)
        Me.GroupBox3.Controls.Add(Me.lbl_Details1)
        Me.GroupBox3.Font = New System.Drawing.Font("Verdana", 9.75!)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 315)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(498, 170)
        Me.GroupBox3.TabIndex = 137
        Me.GroupBox3.TabStop = False
        '
        'btn_TextLog
        '
        Me.btn_TextLog.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TextLog.CenterPtTracker = DesignerRectTracker1
        Me.btn_TextLog.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TextLog.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_TextLog.ColorFillBlendChecked = CBlendItems2
        Me.btn_TextLog.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_TextLog.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_TextLog.Corners.All = CType(6, Short)
        Me.btn_TextLog.Corners.LowerLeft = CType(6, Short)
        Me.btn_TextLog.Corners.LowerRight = CType(6, Short)
        Me.btn_TextLog.Corners.UpperLeft = CType(6, Short)
        Me.btn_TextLog.Corners.UpperRight = CType(6, Short)
        Me.btn_TextLog.DimFactorGray = -10
        Me.btn_TextLog.DimFactorOver = 30
        Me.btn_TextLog.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_TextLog.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_TextLog.FocalPoints.CenterPtX = 0.2727273!
        Me.btn_TextLog.FocalPoints.CenterPtY = 0.5!
        Me.btn_TextLog.FocalPoints.FocusPtX = 0.0!
        Me.btn_TextLog.FocalPoints.FocusPtY = 0.0!
        Me.btn_TextLog.FocalPointsChecked.CenterPtX = 0.6216216!
        Me.btn_TextLog.FocalPointsChecked.CenterPtY = 0.4210526!
        Me.btn_TextLog.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_TextLog.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TextLog.FocusPtTracker = DesignerRectTracker2
        Me.btn_TextLog.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TextLog.Image = Nothing
        Me.btn_TextLog.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TextLog.ImageIndex = 0
        Me.btn_TextLog.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_TextLog.Location = New System.Drawing.Point(266, 140)
        Me.btn_TextLog.Name = "btn_TextLog"
        Me.btn_TextLog.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_TextLog.SideImage = Nothing
        Me.btn_TextLog.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TextLog.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TextLog.Size = New System.Drawing.Size(95, 19)
        Me.btn_TextLog.TabIndex = 173
        Me.btn_TextLog.Text = "Text log"
        Me.btn_TextLog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TextLog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_TextLog.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_TextLog.TextShadow = System.Drawing.Color.Transparent
        '
        'tkbar_VerticalScaleZoom
        '
        Me.tkbar_VerticalScaleZoom.AutoSize = False
        Me.tkbar_VerticalScaleZoom.LargeChange = 50
        Me.tkbar_VerticalScaleZoom.Location = New System.Drawing.Point(376, 48)
        Me.tkbar_VerticalScaleZoom.Maximum = 100
        Me.tkbar_VerticalScaleZoom.Minimum = 1
        Me.tkbar_VerticalScaleZoom.Name = "tkbar_VerticalScaleZoom"
        Me.tkbar_VerticalScaleZoom.Size = New System.Drawing.Size(110, 33)
        Me.tkbar_VerticalScaleZoom.TabIndex = 170
        Me.tkbar_VerticalScaleZoom.TickFrequency = 10
        Me.tkbar_VerticalScaleZoom.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tkbar_VerticalScaleZoom.Value = 1
        '
        'Label_VerticalScaleZoom
        '
        Me.Label_VerticalScaleZoom.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_VerticalScaleZoom.Location = New System.Drawing.Point(366, 26)
        Me.Label_VerticalScaleZoom.Name = "Label_VerticalScaleZoom"
        Me.Label_VerticalScaleZoom.Size = New System.Drawing.Size(128, 13)
        Me.Label_VerticalScaleZoom.TabIndex = 171
        Me.Label_VerticalScaleZoom.Text = "Vertical scale zoom"
        Me.Label_VerticalScaleZoom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_SetZero
        '
        Me.btn_SetZero.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetZero.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SetZero.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SetZero.ColorFillBlendChecked = CBlendItems4
        Me.btn_SetZero.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SetZero.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SetZero.Corners.All = CType(6, Short)
        Me.btn_SetZero.Corners.LowerLeft = CType(6, Short)
        Me.btn_SetZero.Corners.LowerRight = CType(6, Short)
        Me.btn_SetZero.Corners.UpperLeft = CType(6, Short)
        Me.btn_SetZero.Corners.UpperRight = CType(6, Short)
        Me.btn_SetZero.DimFactorGray = -10
        Me.btn_SetZero.DimFactorOver = 30
        Me.btn_SetZero.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_SetZero.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_SetZero.FocalPoints.CenterPtX = 0.3222222!
        Me.btn_SetZero.FocalPoints.CenterPtY = 0.4!
        Me.btn_SetZero.FocalPoints.FocusPtX = 0.0!
        Me.btn_SetZero.FocalPoints.FocusPtY = 0.0!
        Me.btn_SetZero.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_SetZero.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_SetZero.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SetZero.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SetZero.FocusPtTracker = DesignerRectTracker4
        Me.btn_SetZero.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SetZero.Image = Nothing
        Me.btn_SetZero.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZero.ImageIndex = 0
        Me.btn_SetZero.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SetZero.Location = New System.Drawing.Point(266, 63)
        Me.btn_SetZero.Name = "btn_SetZero"
        Me.btn_SetZero.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_SetZero.SideImage = Nothing
        Me.btn_SetZero.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZero.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SetZero.Size = New System.Drawing.Size(95, 32)
        Me.btn_SetZero.TabIndex = 169
        Me.btn_SetZero.Text = "Reset  zero"
        Me.btn_SetZero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SetZero.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SetZero.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SetZero.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_BeepOnChange
        '
        Me.btn_BeepOnChange.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BeepOnChange.CenterPtTracker = DesignerRectTracker5
        Me.btn_BeepOnChange.CheckButton = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_BeepOnChange.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_BeepOnChange.ColorFillBlendChecked = CBlendItems6
        Me.btn_BeepOnChange.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BeepOnChange.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BeepOnChange.Corners.All = CType(6, Short)
        Me.btn_BeepOnChange.Corners.LowerLeft = CType(6, Short)
        Me.btn_BeepOnChange.Corners.LowerRight = CType(6, Short)
        Me.btn_BeepOnChange.Corners.UpperLeft = CType(6, Short)
        Me.btn_BeepOnChange.Corners.UpperRight = CType(6, Short)
        Me.btn_BeepOnChange.DimFactorGray = -10
        Me.btn_BeepOnChange.DimFactorOver = 30
        Me.btn_BeepOnChange.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_BeepOnChange.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_BeepOnChange.FocalPoints.CenterPtX = 0.2727273!
        Me.btn_BeepOnChange.FocalPoints.CenterPtY = 0.5!
        Me.btn_BeepOnChange.FocalPoints.FocusPtX = 0.0!
        Me.btn_BeepOnChange.FocalPoints.FocusPtY = 0.0!
        Me.btn_BeepOnChange.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BeepOnChange.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BeepOnChange.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BeepOnChange.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BeepOnChange.FocusPtTracker = DesignerRectTracker6
        Me.btn_BeepOnChange.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_BeepOnChange.Image = Nothing
        Me.btn_BeepOnChange.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BeepOnChange.ImageIndex = 0
        Me.btn_BeepOnChange.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BeepOnChange.Location = New System.Drawing.Point(266, 101)
        Me.btn_BeepOnChange.Name = "btn_BeepOnChange"
        Me.btn_BeepOnChange.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_BeepOnChange.SideImage = Nothing
        Me.btn_BeepOnChange.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BeepOnChange.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_BeepOnChange.Size = New System.Drawing.Size(95, 32)
        Me.btn_BeepOnChange.TabIndex = 168
        Me.btn_BeepOnChange.Text = "Beep on change"
        Me.btn_BeepOnChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BeepOnChange.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_BeepOnChange.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BeepOnChange.TextShadow = System.Drawing.Color.Transparent
        '
        'pbox_Details2
        '
        Me.pbox_Details2.BackColor = System.Drawing.Color.MintCream
        Me.pbox_Details2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_Details2.Location = New System.Drawing.Point(133, 144)
        Me.pbox_Details2.Name = "pbox_Details2"
        Me.pbox_Details2.Size = New System.Drawing.Size(116, 16)
        Me.pbox_Details2.TabIndex = 167
        Me.pbox_Details2.TabStop = False
        '
        'lbl_Details2
        '
        Me.lbl_Details2.BackColor = System.Drawing.Color.MintCream
        Me.lbl_Details2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Details2.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Details2.Location = New System.Drawing.Point(133, 32)
        Me.lbl_Details2.Name = "lbl_Details2"
        Me.lbl_Details2.Size = New System.Drawing.Size(116, 108)
        Me.lbl_Details2.TabIndex = 166
        '
        'LabelPin1
        '
        Me.LabelPin1.AutoSize = True
        Me.LabelPin1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPin1.ForeColor = System.Drawing.Color.DarkBlue
        Me.LabelPin1.Location = New System.Drawing.Point(14, 13)
        Me.LabelPin1.Name = "LabelPin1"
        Me.LabelPin1.Size = New System.Drawing.Size(33, 13)
        Me.LabelPin1.TabIndex = 165
        Me.LabelPin1.Text = "- - -"
        '
        'LabelPin2
        '
        Me.LabelPin2.AutoSize = True
        Me.LabelPin2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPin2.ForeColor = System.Drawing.Color.Maroon
        Me.LabelPin2.Location = New System.Drawing.Point(134, 13)
        Me.LabelPin2.Name = "LabelPin2"
        Me.LabelPin2.Size = New System.Drawing.Size(33, 13)
        Me.LabelPin2.TabIndex = 164
        Me.LabelPin2.Text = "- - -"
        '
        'btn_ShowRawCount
        '
        Me.btn_ShowRawCount.BorderColor = System.Drawing.Color.DimGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ShowRawCount.CenterPtTracker = DesignerRectTracker7
        Me.btn_ShowRawCount.CheckButton = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ShowRawCount.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ShowRawCount.ColorFillBlendChecked = CBlendItems8
        Me.btn_ShowRawCount.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ShowRawCount.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ShowRawCount.Corners.All = CType(6, Short)
        Me.btn_ShowRawCount.Corners.LowerLeft = CType(6, Short)
        Me.btn_ShowRawCount.Corners.LowerRight = CType(6, Short)
        Me.btn_ShowRawCount.Corners.UpperLeft = CType(6, Short)
        Me.btn_ShowRawCount.Corners.UpperRight = CType(6, Short)
        Me.btn_ShowRawCount.DimFactorGray = -10
        Me.btn_ShowRawCount.DimFactorOver = 30
        Me.btn_ShowRawCount.FillType = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_ShowRawCount.FillTypeChecked = CustomControlsLib.MyButton.eFillType.LinearVertical
        Me.btn_ShowRawCount.FocalPoints.CenterPtX = 0.2727273!
        Me.btn_ShowRawCount.FocalPoints.CenterPtY = 0.5!
        Me.btn_ShowRawCount.FocalPoints.FocusPtX = 0.0!
        Me.btn_ShowRawCount.FocalPoints.FocusPtY = 0.0!
        Me.btn_ShowRawCount.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_ShowRawCount.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_ShowRawCount.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ShowRawCount.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ShowRawCount.FocusPtTracker = DesignerRectTracker8
        Me.btn_ShowRawCount.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ShowRawCount.Image = Nothing
        Me.btn_ShowRawCount.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRawCount.ImageIndex = 0
        Me.btn_ShowRawCount.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ShowRawCount.Location = New System.Drawing.Point(266, 25)
        Me.btn_ShowRawCount.Name = "btn_ShowRawCount"
        Me.btn_ShowRawCount.Shape = CustomControlsLib.MyButton.eShape.Rectangle
        Me.btn_ShowRawCount.SideImage = Nothing
        Me.btn_ShowRawCount.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRawCount.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ShowRawCount.Size = New System.Drawing.Size(95, 32)
        Me.btn_ShowRawCount.TabIndex = 155
        Me.btn_ShowRawCount.Text = "Show raw count"
        Me.btn_ShowRawCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ShowRawCount.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ShowRawCount.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ShowRawCount.TextShadow = System.Drawing.Color.Transparent
        '
        'tkbar_ScrollSpeed
        '
        Me.tkbar_ScrollSpeed.AutoSize = False
        Me.tkbar_ScrollSpeed.Location = New System.Drawing.Point(376, 128)
        Me.tkbar_ScrollSpeed.Maximum = 100
        Me.tkbar_ScrollSpeed.Minimum = 1
        Me.tkbar_ScrollSpeed.Name = "tkbar_ScrollSpeed"
        Me.tkbar_ScrollSpeed.Size = New System.Drawing.Size(110, 33)
        Me.tkbar_ScrollSpeed.TabIndex = 160
        Me.tkbar_ScrollSpeed.TickFrequency = 10
        Me.tkbar_ScrollSpeed.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tkbar_ScrollSpeed.Value = 50
        '
        'Label_ScrollSpeed
        '
        Me.Label_ScrollSpeed.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ScrollSpeed.Location = New System.Drawing.Point(366, 106)
        Me.Label_ScrollSpeed.Name = "Label_ScrollSpeed"
        Me.Label_ScrollSpeed.Size = New System.Drawing.Size(128, 13)
        Me.Label_ScrollSpeed.TabIndex = 163
        Me.Label_ScrollSpeed.Text = "Scroll speed"
        Me.Label_ScrollSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbox_Details1
        '
        Me.pbox_Details1.BackColor = System.Drawing.Color.MintCream
        Me.pbox_Details1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_Details1.Location = New System.Drawing.Point(12, 144)
        Me.pbox_Details1.Name = "pbox_Details1"
        Me.pbox_Details1.Size = New System.Drawing.Size(116, 16)
        Me.pbox_Details1.TabIndex = 103
        Me.pbox_Details1.TabStop = False
        '
        'lbl_Details1
        '
        Me.lbl_Details1.BackColor = System.Drawing.Color.MintCream
        Me.lbl_Details1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Details1.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Details1.Location = New System.Drawing.Point(12, 32)
        Me.lbl_Details1.Name = "lbl_Details1"
        Me.lbl_Details1.Size = New System.Drawing.Size(116, 108)
        Me.lbl_Details1.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox1.Controls.Add(Me.Label_Scale1b)
        Me.GroupBox1.Controls.Add(Me.Label_Scale2b)
        Me.GroupBox1.Controls.Add(Me.Label_Scale3b)
        Me.GroupBox1.Controls.Add(Me.rtb_SnifferLog)
        Me.GroupBox1.Controls.Add(Me.pbox_ScrollingScope)
        Me.GroupBox1.Controls.Add(Me.Label_Scale3)
        Me.GroupBox1.Controls.Add(Me.Label_Scale2)
        Me.GroupBox1.Controls.Add(Me.Label_Scale1)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(6, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(498, 303)
        Me.GroupBox1.TabIndex = 146
        Me.GroupBox1.TabStop = False
        '
        'Label_Scale1b
        '
        Me.Label_Scale1b.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale1b.ForeColor = System.Drawing.Color.Maroon
        Me.Label_Scale1b.Location = New System.Drawing.Point(444, 270)
        Me.Label_Scale1b.Name = "Label_Scale1b"
        Me.Label_Scale1b.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale1b.TabIndex = 177
        Me.Label_Scale1b.Text = "0"
        Me.Label_Scale1b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Scale2b
        '
        Me.Label_Scale2b.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale2b.ForeColor = System.Drawing.Color.Maroon
        Me.Label_Scale2b.Location = New System.Drawing.Point(444, 161)
        Me.Label_Scale2b.Name = "Label_Scale2b"
        Me.Label_Scale2b.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale2b.TabIndex = 176
        Me.Label_Scale2b.Text = "500"
        Me.Label_Scale2b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Scale3b
        '
        Me.Label_Scale3b.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale3b.ForeColor = System.Drawing.Color.Maroon
        Me.Label_Scale3b.Location = New System.Drawing.Point(444, 25)
        Me.Label_Scale3b.Name = "Label_Scale3b"
        Me.Label_Scale3b.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale3b.TabIndex = 175
        Me.Label_Scale3b.Text = "1000"
        Me.Label_Scale3b.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rtb_SnifferLog
        '
        Me.rtb_SnifferLog.Location = New System.Drawing.Point(32, 5)
        Me.rtb_SnifferLog.Name = "rtb_SnifferLog"
        Me.rtb_SnifferLog.ReadOnly = True
        Me.rtb_SnifferLog.Size = New System.Drawing.Size(72, 70)
        Me.rtb_SnifferLog.TabIndex = 154
        Me.rtb_SnifferLog.Text = ""
        Me.rtb_SnifferLog.Visible = False
        '
        'pbox_ScrollingScope
        '
        Me.pbox_ScrollingScope.BackColor = System.Drawing.Color.AliceBlue
        Me.pbox_ScrollingScope.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbox_ScrollingScope.Location = New System.Drawing.Point(10, 16)
        Me.pbox_ScrollingScope.Name = "pbox_ScrollingScope"
        Me.pbox_ScrollingScope.Size = New System.Drawing.Size(436, 278)
        Me.pbox_ScrollingScope.TabIndex = 153
        Me.pbox_ScrollingScope.TabStop = False
        '
        'Label_Scale3
        '
        Me.Label_Scale3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale3.ForeColor = System.Drawing.Color.Blue
        Me.Label_Scale3.Location = New System.Drawing.Point(444, 12)
        Me.Label_Scale3.Name = "Label_Scale3"
        Me.Label_Scale3.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale3.TabIndex = 174
        Me.Label_Scale3.Text = "1000"
        Me.Label_Scale3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Scale2
        '
        Me.Label_Scale2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale2.ForeColor = System.Drawing.Color.Blue
        Me.Label_Scale2.Location = New System.Drawing.Point(444, 148)
        Me.Label_Scale2.Name = "Label_Scale2"
        Me.Label_Scale2.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale2.TabIndex = 173
        Me.Label_Scale2.Text = "500"
        Me.Label_Scale2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Scale1
        '
        Me.Label_Scale1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Scale1.ForeColor = System.Drawing.Color.Blue
        Me.Label_Scale1.Location = New System.Drawing.Point(444, 283)
        Me.Label_Scale1.Name = "Label_Scale1"
        Me.Label_Scale1.Size = New System.Drawing.Size(50, 13)
        Me.Label_Scale1.TabIndex = 172
        Me.Label_Scale1.Text = "0"
        Me.Label_Scale1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer_100Hz
        '
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(512, 491)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino HAL - Pin details"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.tkbar_VerticalScaleZoom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox_Details2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tkbar_ScrollSpeed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox_Details1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.pbox_ScrollingScope, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Details1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_ShowRawCount As CustomControlsLib.MyButton
    Friend WithEvents pbox_ScrollingScope As System.Windows.Forms.PictureBox
    Friend WithEvents pbox_Details1 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer_60Hz As System.Windows.Forms.Timer
    Friend WithEvents tkbar_ScrollSpeed As System.Windows.Forms.TrackBar
    Friend WithEvents Label_ScrollSpeed As System.Windows.Forms.Label
    Friend WithEvents LabelPin2 As System.Windows.Forms.Label
    Friend WithEvents pbox_Details2 As System.Windows.Forms.PictureBox
    Friend WithEvents lbl_Details2 As System.Windows.Forms.Label
    Friend WithEvents LabelPin1 As System.Windows.Forms.Label
    Friend WithEvents btn_BeepOnChange As CustomControlsLib.MyButton
    Friend WithEvents btn_SetZero As CustomControlsLib.MyButton
    Friend WithEvents tkbar_VerticalScaleZoom As System.Windows.Forms.TrackBar
    Friend WithEvents Label_VerticalScaleZoom As System.Windows.Forms.Label
    Friend WithEvents rtb_SnifferLog As System.Windows.Forms.RichTextBox
    Friend WithEvents btn_TextLog As CustomControlsLib.MyButton
    Friend WithEvents Label_Scale3 As System.Windows.Forms.Label
    Friend WithEvents Label_Scale2 As System.Windows.Forms.Label
    Friend WithEvents Label_Scale1 As System.Windows.Forms.Label
    Friend WithEvents Label_Scale3b As System.Windows.Forms.Label
    Friend WithEvents Label_Scale1b As System.Windows.Forms.Label
    Friend WithEvents Label_Scale2b As System.Windows.Forms.Label
End Class
