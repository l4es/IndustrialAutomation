﻿Public Class Form2

    Private Scope As Class_DataScope

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Scope = New Class_DataScope(pbox_ScrollingScope)
        rtb_SnifferLog.Location = pbox_ScrollingScope.Location
        rtb_SnifferLog.Size = pbox_ScrollingScope.Size
        SetScaleLabels()
    End Sub

    Private Sub Form2_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged, _
                                                                                                    Me.SizeChanged
        StartTimer()
    End Sub

    Friend Sub StopTimer()
        Timer_60Hz.Stop()
    End Sub

    Friend Sub StartTimer()
        If Visible And WindowState <> FormWindowState.Minimized Then
            Timer_60Hz.Interval = 15
            Timer_60Hz.Start()
        Else
            Timer_60Hz.Stop()
        End If
    End Sub

    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        GroupBox1.BackColor = Color.LightGoldenrodYellow
        TheSystem_StopAllSnifferLogs()
        Me.Hide()
        e.Cancel = True
    End Sub

    Private Sub Form2_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub Timer_60Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_60Hz.Tick
        If Not EventsAreEnabled Then Return
        ' --------------------------------------------------- 
        'TimerRepetition_TestMeter()
        ' --------------------------------------------------- 
        ShowPinDetails()
    End Sub

    'Private Sub TimerRepetition_TestMeter()
    '    Static t As Stopwatch = New Stopwatch
    '    Static newt As Double
    '    Static oldt As Double
    '    Static meant As Double
    '    t.Start()
    '    newt = t.Elapsed.TotalMilliseconds
    '    meant = meant + 0.03 * ((newt - oldt) - meant)
    '    oldt = newt
    '    Text = meant.ToString("0.00 mS")
    'End Sub

    Private SelectedPin As Pin
    Private AlternatePin As Pin
    Private SelectedPinListLine As Int32
    Private AlternatePinListLine As Int32

    Friend Sub RestoreSelectedPins()
        SelectedPin = Nothing
        AlternatePin = Nothing
        rtb_SnifferLog.Visible = False
        pbox_ScrollingScope.Visible = True
        TheSystem_StopAllSnifferLogs()
        LabelPin1.Text = "- - -"
        lbl_Details1.Text = ""
        FillPictureBox(pbox_Details1, 0, Color.Orange, Color.AliceBlue)
        LabelPin2.Text = "- - -"
        lbl_Details2.Text = ""
        FillPictureBox(pbox_Details2, 0, Color.Orange, Color.AliceBlue)
        ' ----------------------------------------------------------------- recover selected pins from list lines
        SelectedPin = FindPinByListLine(SelectedPinListLine)
        AlternatePin = FindPinByListLine(AlternatePinListLine)
        InitializePinDetails()
    End Sub

    Friend Sub SetPinDetails()
        Dim p As Pin = GetSelectedPin()
        Dim l As Int32 = GetSelectedListLine()
        If p Is Nothing Then Return
        If p Is SelectedPin Then
            AlternatePin = Nothing
            AlternatePinListLine = 0
            SelectedPin = p
            SelectedPinListLine = l
        Else
            AlternatePin = SelectedPin
            AlternatePinListLine = SelectedPinListLine
            SelectedPin = p
            SelectedPinListLine = l
        End If
        InitializePinDetails()
    End Sub

    Private Sub InitializePinDetails()
        If SelectedPin IsNot Nothing Then
            LabelPin1.Text = ComposePinString(SelectedPin)
        End If
        If AlternatePin IsNot Nothing Then
            LabelPin2.Text = ComposePinString(AlternatePin)
        Else
            LabelPin2.Text = "- - -"
            lbl_Details2.Text = ""
            FillPictureBox(pbox_Details2, 0, Color.Orange, Color.AliceBlue)
        End If
        ' ---------------------------------------------------------------------- visualize sniffer log
        If SelectedPin IsNot Nothing AndAlso SelectedPin.GetPinType = Pin.PinTypes.SNIFFER AndAlso Me.Visible Then
            If Not SelectedPin.SnifferLogEnabled Then
                If btn_TextLog.Checked Then
                    rtb_SnifferLog.Visible = True
                    pbox_ScrollingScope.Visible = False
                    GroupBox1.BackColor = Color.Tomato
                    TheSystem_StopAllSnifferLogs()
                    rtb_SnifferLog.Text = ""
                    SelectedPin.SnifferLogEnabled = True
                End If
            Else
                If Not btn_TextLog.Checked Then
                    rtb_SnifferLog.Visible = False
                    pbox_ScrollingScope.Visible = True
                End If
                GroupBox1.BackColor = Color.LightGoldenrodYellow
                TheSystem_StopAllSnifferLogs()
            End If
        End If
        '
        'TheSystem_CalibrateZero()
        '
        SetScaleLabels()
    End Sub

    Private Sub btn_GraphicLog_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_TextLog.ClickButtonArea
        If Not btn_TextLog.Checked Then
            rtb_SnifferLog.Visible = False
            pbox_ScrollingScope.Visible = True
            GroupBox1.BackColor = Color.LightGoldenrodYellow
            TheSystem_StopAllSnifferLogs()
        Else
            rtb_SnifferLog.Visible = True
            pbox_ScrollingScope.Visible = False
        End If
    End Sub

    Private Sub ShowPinDetails()
        ShowDetails()
        UpdateScrollingScope()
        If btn_BeepOnChange.Checked Then BeepOnChange()
    End Sub

    Private Function ComposePinString(ByVal p As Pin) As String
        Return "M:" & (p.MasterId + 1).ToString & " S:" & (p.SlaveId + 1).ToString & " Pin:" & (p.PinId + 1).ToString
    End Function

    Private Sub ShowDetails()
        Static divisor As Int32
        divisor += 1
        If divisor >= 2 Then ' 2 = 30 executions per second (timer 60Hz divided by 2)
            divisor = 0
            If SelectedPin IsNot Nothing Then
                lbl_Details1.Text = SelectedPin.GetValueString()
                FillPictureBox(pbox_Details1, SelectedPin.Value_Normalized, Color.Orange, Color.AliceBlue)
            End If
            If AlternatePin IsNot Nothing Then
                lbl_Details2.Text = AlternatePin.GetValueString()
                FillPictureBox(pbox_Details2, AlternatePin.Value_Normalized, Color.Orange, Color.AliceBlue)
            End If
        End If
    End Sub

    Private Sub BeepOnChange()
        If SelectedPin IsNot Nothing Then
            Dim c As Single = SelectedPin.Value
            Static oldc As Single
            If c <> oldc And c <> 0 And Not Single.IsNaN(c) Then
                oldc = c
                'Debug.Print(SelectedPin.Value.ToString)
                Beep_RepetitionLimited(150)
            End If
        End If
    End Sub

    Private Sub btn_SetZero_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_SetZero.ClickButtonArea
        TheSystem_CalibrateZero()
        SetScaleLabels()
    End Sub

    Private Sub btn_ShowRawCount_ClickButtonArea(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles btn_ShowRawCount.ClickButtonArea
        TheSystem_CalibrateZero()
        SetScaleLabels()
    End Sub

    Private Sub UpdateScrollingScope()
        If Not pbox_ScrollingScope.Visible Then Return
        Dim v1 As Single = -999
        Dim v2 As Single = -999
        Dim zoom As Single = tkbar_VerticalScaleZoom.Value
        If btn_ShowRawCount.Checked Then
            If SelectedPin IsNot Nothing Then
                v1 = (SelectedPin.Value_RawInteger_Zero - CInt(SelectedPin.Value_RawInteger)) * zoom / 100.0F
            End If
            If AlternatePin IsNot Nothing Then
                v2 = (AlternatePin.Value_RawInteger_Zero - CInt(AlternatePin.Value_RawInteger)) * zoom / 100.0F
            End If
        Else
            If zoom = 1.0F Then
                If SelectedPin IsNot Nothing Then
                    v1 = pbox_ScrollingScope.Height * 0.49F * (0.5F - SelectedPin.Value_Normalized)
                End If
                If AlternatePin IsNot Nothing Then
                    v2 = pbox_ScrollingScope.Height * 0.49F * (0.5F - AlternatePin.Value_Normalized)
                End If
            Else
                If SelectedPin IsNot Nothing Then
                    v1 = pbox_ScrollingScope.Height * 0.49F * (SelectedPin.Value_Normalized_Zero - SelectedPin.Value_Normalized) * zoom
                End If
                If AlternatePin IsNot Nothing Then
                    v2 = pbox_ScrollingScope.Height * 0.49F * (AlternatePin.Value_Normalized_Zero - AlternatePin.Value_Normalized) * zoom
                End If
            End If
        End If
        Scope.Display(v1, v2, tkbar_ScrollSpeed.Value)
    End Sub

    Private Sub SetScaleLabels()
        Label_Scale3.Text = ""
        Label_Scale2.Text = ""
        Label_Scale1.Text = ""
        Label_Scale3b.Text = ""
        Label_Scale2b.Text = ""
        Label_Scale1b.Text = ""
        Dim zoom As Double = tkbar_VerticalScaleZoom.Value
        If btn_ShowRawCount.Checked Then
            If SelectedPin IsNot Nothing Then
                Label_Scale3.Text = (SelectedPin.Value_RawInteger_Zero + 6800 / zoom).ToString("0")
                Label_Scale2.Text = SelectedPin.Value_RawInteger_Zero.ToString("0")
                Label_Scale1.Text = (SelectedPin.Value_RawInteger_Zero - 6800 / zoom).ToString("0")
            End If
            If AlternatePin IsNot Nothing Then
                Label_Scale3b.Text = (AlternatePin.Value_RawInteger_Zero + 6800 / zoom).ToString("0")
                Label_Scale2b.Text = AlternatePin.Value_RawInteger_Zero.ToString("0")
                Label_Scale1b.Text = (AlternatePin.Value_RawInteger_Zero - 6800 / zoom).ToString("0")
            End If
        Else
            If zoom = 1.0F Then
                Label_Scale3.Text = "1000"
                Label_Scale2.Text = "500"
                Label_Scale1.Text = "0"
            Else
                If SelectedPin IsNot Nothing Then
                    Dim zv As Single = SelectedPin.Value_Normalized_Zero * 1000.0F
                    Label_Scale3.Text = (zv + 500 / zoom).ToString("0")
                    Label_Scale2.Text = zv.ToString("0")
                    Label_Scale1.Text = (zv - 500 / zoom).ToString("0")
                End If
                If AlternatePin IsNot Nothing Then
                    Dim zv As Single = AlternatePin.Value_Normalized_Zero * 1000.0F
                    Label_Scale3b.Text = (zv + 500 / zoom).ToString("0")
                    Label_Scale2b.Text = zv.ToString("0")
                    Label_Scale1b.Text = (zv - 500 / zoom).ToString("0")
                End If
            End If
        End If
    End Sub

    Private Sub tkbar_VerticalScaleZoom_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tkbar_VerticalScaleZoom.Scroll
        SetScaleLabels()
    End Sub


End Class