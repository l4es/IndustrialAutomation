﻿
Imports System.Runtime.InteropServices
Imports System.Text


Module MemoryMappedFiles_Unix

    ' ======================================================================================
    '  MemoryMappedFile_Unix "theremino1.shared"
    ' ======================================================================================

    Friend MMF1_Unix As MemoryMappedFile_Unix

    'Friend Const NAN_Zero As Single = 0 + Single.NaN
    'Friend Const NAN_Sleep As Single = 1 + Single.NaN

    Friend Sub MemoryMappedFile_Init_Unix()
        ' ----------------------------------------- The DLL opens the file
        MMF1_Unix = New MemoryMappedFile_Unix
    End Sub

    Friend Function ReadSlot_Unix(ByVal Slot As Int32) As Single
        Return MMF1_Unix.ReadSlot(Slot)
    End Function

    Friend Function ReadSlot_NoNan_Unix(ByVal Slot As Int32) As Single
        Dim n As Single = MMF1_Unix.ReadSlot(Slot)
        If Single.IsNaN(n) Then n = 0
        Return n
    End Function

    Friend Function ReadSlot_NoNan_0_1000_Unix(ByVal Slot As Int32) As Single   'RCL
        Dim n As Single = MMF1_Unix.ReadSlot(Slot)
        If Single.IsNaN(n) Then n = 0
        If n < 0 Then n = 0
        If n > 1000 Then n = 1000
        Return n
    End Function

    Friend Sub WriteSlot_Unix(ByVal Slot As Int32, ByVal Value As Single)
        MMF1_Unix.WriteSlot(Slot, Value)
    End Sub

    Friend Sub MemoryMappedFile_FillWithNanSleep_Unix()
        For i As Int32 = 0 To 999
            MMF1_Unix.WriteSlot(i, NAN_Sleep)
        Next
    End Sub


    ' ======================================================================================
    '   CLASS MemoryMappedFile_Unix
    ' ======================================================================================
    Public Class MemoryMappedFile_Unix

        <DllImport("ThereminoSlots")> _
        Private Shared Function the_slot_init() As Integer
        End Function

        <DllImport("ThereminoSlots")> _
        Private Shared Function the_slot_exit() As Integer
        End Function

        <DllImport("ThereminoSlots")> _
        Private Shared Sub the_slot_write(ByVal slot As Integer, ByVal value As Single)
        End Sub

        <DllImport("ThereminoSlots")> _
        Private Shared Function the_slot_read(ByVal slot As Integer) As Single
        End Function

        ' ---------------------------------------------------------------- construction / destruction
        Friend Sub New()
            InitSlot()
        End Sub

        Protected Overrides Sub Finalize()
            Destroy()
            MyBase.Finalize()
        End Sub

        Friend Sub Destroy()
            ExitSlot()
        End Sub


        ' ======================================================================================
        '  PUBLIC FUNCTIONS
        ' ======================================================================================
        Public Function InitSlot() As Int32
            Return the_slot_init()
        End Function

        Public Function ExitSlot() As Int32
            Return the_slot_exit()
        End Function

        Public Sub WriteSlot(ByVal Slot As Int32, ByVal Value As Single)
            the_slot_write(Slot, Value)
        End Sub

        Public Function ReadSlot(ByVal Slot As Int32) As Single
            Return the_slot_read(Slot)
        End Function

    End Class

End Module

