﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.lbl_Display = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lbl_LogFileName = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.btn_Zero1 = New System.Windows.Forms.Button
        Me.btn_Zero2 = New System.Windows.Forms.Button
        Me.btn_Zero3 = New System.Windows.Forms.Button
        Me.btn_Zero6 = New System.Windows.Forms.Button
        Me.btn_Zero5 = New System.Windows.Forms.Button
        Me.btn_Zero4 = New System.Windows.Forms.Button
        Me.btn_Zero8 = New System.Windows.Forms.Button
        Me.btn_Zero7 = New System.Windows.Forms.Button
        Me.txt_RecInterval = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay8 = New Theremino_Logger.MyTextBox
        Me.cmb_Type8 = New Theremino_Logger.MyComboBox
        Me.txt_SensorMult8 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim8 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot8 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay7 = New Theremino_Logger.MyTextBox
        Me.cmb_Type7 = New Theremino_Logger.MyComboBox
        Me.txt_SensorMult7 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim7 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot7 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay6 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay5 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay4 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay3 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay2 = New Theremino_Logger.MyTextBox
        Me.txt_SlotDisplay1 = New Theremino_Logger.MyTextBox
        Me.cmb_Type6 = New Theremino_Logger.MyComboBox
        Me.cmb_Type5 = New Theremino_Logger.MyComboBox
        Me.cmb_Type4 = New Theremino_Logger.MyComboBox
        Me.cmb_Type3 = New Theremino_Logger.MyComboBox
        Me.cmb_Type2 = New Theremino_Logger.MyComboBox
        Me.cmb_Type1 = New Theremino_Logger.MyComboBox
        Me.txt_SensorMult6 = New Theremino_Logger.MyTextBox
        Me.txt_SensorMult5 = New Theremino_Logger.MyTextBox
        Me.txt_SensorMult4 = New Theremino_Logger.MyTextBox
        Me.txt_SensorMult3 = New Theremino_Logger.MyTextBox
        Me.txt_SensorMult2 = New Theremino_Logger.MyTextBox
        Me.txt_SensorMult1 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim6 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim5 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim4 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim3 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim2 = New Theremino_Logger.MyTextBox
        Me.txt_SensorTrim1 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot6 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot5 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot4 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot3 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot2 = New Theremino_Logger.MyTextBox
        Me.txt_NumSlot1 = New Theremino_Logger.MyTextBox
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(420, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 15)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Recording interval (sec.)"
        '
        'lbl_Display
        '
        Me.lbl_Display.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lbl_Display.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_Display.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Display.Location = New System.Drawing.Point(12, 48)
        Me.lbl_Display.Name = "lbl_Display"
        Me.lbl_Display.Size = New System.Drawing.Size(601, 23)
        Me.lbl_Display.TabIndex = 187
        Me.lbl_Display.Text = "0.000"
        Me.lbl_Display.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(9, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 15)
        Me.Label4.TabIndex = 199
        Me.Label4.Text = "Slot"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(9, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 15)
        Me.Label5.TabIndex = 200
        Me.Label5.Text = "Type"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(9, 193)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 15)
        Me.Label7.TabIndex = 201
        Me.Label7.Text = "Trim value"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(9, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 15)
        Me.Label6.TabIndex = 202
        Me.Label6.Text = "Multiply"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 15)
        Me.Label3.TabIndex = 234
        Me.Label3.Text = "Value"
        '
        'lbl_LogFileName
        '
        Me.lbl_LogFileName.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.lbl_LogFileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_LogFileName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_LogFileName.Location = New System.Drawing.Point(107, 13)
        Me.lbl_LogFileName.Name = "lbl_LogFileName"
        Me.lbl_LogFileName.Size = New System.Drawing.Size(303, 23)
        Me.lbl_LogFileName.TabIndex = 236
        Me.lbl_LogFileName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(10, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 15)
        Me.Label1.TabIndex = 237
        Me.Label1.Text = "LOG File Name:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(9, 218)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 15)
        Me.Label8.TabIndex = 254
        Me.Label8.Text = "Set zero"
        '
        'btn_Zero1
        '
        Me.btn_Zero1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero1.Location = New System.Drawing.Point(76, 216)
        Me.btn_Zero1.Name = "btn_Zero1"
        Me.btn_Zero1.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero1.TabIndex = 255
        Me.btn_Zero1.UseVisualStyleBackColor = True
        '
        'btn_Zero2
        '
        Me.btn_Zero2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero2.Location = New System.Drawing.Point(144, 216)
        Me.btn_Zero2.Name = "btn_Zero2"
        Me.btn_Zero2.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero2.TabIndex = 256
        Me.btn_Zero2.UseVisualStyleBackColor = True
        '
        'btn_Zero3
        '
        Me.btn_Zero3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero3.Location = New System.Drawing.Point(212, 216)
        Me.btn_Zero3.Name = "btn_Zero3"
        Me.btn_Zero3.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero3.TabIndex = 257
        Me.btn_Zero3.UseVisualStyleBackColor = True
        '
        'btn_Zero6
        '
        Me.btn_Zero6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero6.Location = New System.Drawing.Point(416, 216)
        Me.btn_Zero6.Name = "btn_Zero6"
        Me.btn_Zero6.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero6.TabIndex = 260
        Me.btn_Zero6.UseVisualStyleBackColor = True
        '
        'btn_Zero5
        '
        Me.btn_Zero5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero5.Location = New System.Drawing.Point(348, 216)
        Me.btn_Zero5.Name = "btn_Zero5"
        Me.btn_Zero5.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero5.TabIndex = 259
        Me.btn_Zero5.UseVisualStyleBackColor = True
        '
        'btn_Zero4
        '
        Me.btn_Zero4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero4.Location = New System.Drawing.Point(280, 216)
        Me.btn_Zero4.Name = "btn_Zero4"
        Me.btn_Zero4.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero4.TabIndex = 258
        Me.btn_Zero4.UseVisualStyleBackColor = True
        '
        'btn_Zero8
        '
        Me.btn_Zero8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero8.Location = New System.Drawing.Point(552, 216)
        Me.btn_Zero8.Name = "btn_Zero8"
        Me.btn_Zero8.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero8.TabIndex = 262
        Me.btn_Zero8.UseVisualStyleBackColor = True
        '
        'btn_Zero7
        '
        Me.btn_Zero7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Zero7.Location = New System.Drawing.Point(484, 216)
        Me.btn_Zero7.Name = "btn_Zero7"
        Me.btn_Zero7.Size = New System.Drawing.Size(61, 22)
        Me.btn_Zero7.TabIndex = 261
        Me.btn_Zero7.UseVisualStyleBackColor = True
        '
        'txt_RecInterval
        '
        Me.txt_RecInterval.ArrowsIncrement = 0.01
        Me.txt_RecInterval.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_RecInterval.Decimals = 3
        Me.txt_RecInterval.ForeColor = System.Drawing.Color.Black
        Me.txt_RecInterval.Increment = 0.01
        Me.txt_RecInterval.Location = New System.Drawing.Point(562, 14)
        Me.txt_RecInterval.MaxValue = 9999.99
        Me.txt_RecInterval.MinValue = 0.01
        Me.txt_RecInterval.Name = "txt_RecInterval"
        Me.txt_RecInterval.NumericValue = 1
        Me.txt_RecInterval.NumericValueInteger = 1
        Me.txt_RecInterval.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_RecInterval.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_RecInterval.RoundingStep = 0
        Me.txt_RecInterval.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_RecInterval.Size = New System.Drawing.Size(51, 20)
        Me.txt_RecInterval.SuppressZeros = True
        Me.txt_RecInterval.TabIndex = 253
        Me.txt_RecInterval.Text = "1"
        Me.txt_RecInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotDisplay8
        '
        Me.txt_SlotDisplay8.ArrowsIncrement = 0
        Me.txt_SlotDisplay8.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay8.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay8.Decimals = 5
        Me.txt_SlotDisplay8.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay8.Increment = 0
        Me.txt_SlotDisplay8.Location = New System.Drawing.Point(552, 84)
        Me.txt_SlotDisplay8.MaxValue = 99999.99999
        Me.txt_SlotDisplay8.MinValue = -99999.99999
        Me.txt_SlotDisplay8.Name = "txt_SlotDisplay8"
        Me.txt_SlotDisplay8.NumericValue = 0
        Me.txt_SlotDisplay8.ReadOnly = True
        Me.txt_SlotDisplay8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay8.RoundingStep = 0
        Me.txt_SlotDisplay8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay8.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay8.TabIndex = 8
        Me.txt_SlotDisplay8.Text = "0"
        Me.txt_SlotDisplay8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay8.WordWrap = False
        '
        'cmb_Type8
        '
        Me.cmb_Type8.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type8.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type8.BackColor = System.Drawing.Color.White
        Me.cmb_Type8.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type8.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type8.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type8.BorderSize = 1
        Me.cmb_Type8.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type8.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type8.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type8.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type8.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type8.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type8.DropDownHeight = 999
        Me.cmb_Type8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type8.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type8.IntegralHeight = False
        Me.cmb_Type8.ItemHeight = 13
        Me.cmb_Type8.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type8.Location = New System.Drawing.Point(552, 137)
        Me.cmb_Type8.Name = "cmb_Type8"
        Me.cmb_Type8.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type8.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type8.TabIndex = 251
        Me.cmb_Type8.TextPosition = 3
        '
        'txt_SensorMult8
        '
        Me.txt_SensorMult8.ArrowsIncrement = 0.001
        Me.txt_SensorMult8.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult8.Decimals = 5
        Me.txt_SensorMult8.Increment = 0.00001
        Me.txt_SensorMult8.Location = New System.Drawing.Point(552, 163)
        Me.txt_SensorMult8.MaxValue = 99999999
        Me.txt_SensorMult8.MinValue = -99999999
        Me.txt_SensorMult8.Name = "txt_SensorMult8"
        Me.txt_SensorMult8.NumericValue = 1
        Me.txt_SensorMult8.NumericValueInteger = 1
        Me.txt_SensorMult8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult8.RoundingStep = 0
        Me.txt_SensorMult8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult8.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult8.SuppressZeros = True
        Me.txt_SensorMult8.TabIndex = 250
        Me.txt_SensorMult8.Text = "1"
        Me.txt_SensorMult8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim8
        '
        Me.txt_SensorTrim8.ArrowsIncrement = 0.001
        Me.txt_SensorTrim8.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim8.Decimals = 4
        Me.txt_SensorTrim8.Increment = 0.0001
        Me.txt_SensorTrim8.Location = New System.Drawing.Point(552, 190)
        Me.txt_SensorTrim8.MaxValue = 99999999
        Me.txt_SensorTrim8.MinValue = -99999999
        Me.txt_SensorTrim8.Name = "txt_SensorTrim8"
        Me.txt_SensorTrim8.NumericValue = 0
        Me.txt_SensorTrim8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim8.RoundingStep = 0
        Me.txt_SensorTrim8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim8.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim8.SuppressZeros = True
        Me.txt_SensorTrim8.TabIndex = 249
        Me.txt_SensorTrim8.Text = "0"
        Me.txt_SensorTrim8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot8
        '
        Me.txt_NumSlot8.ArrowsIncrement = 1
        Me.txt_NumSlot8.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot8.Increment = 1
        Me.txt_NumSlot8.Location = New System.Drawing.Point(552, 111)
        Me.txt_NumSlot8.MaxValue = 999
        Me.txt_NumSlot8.MinValue = 1
        Me.txt_NumSlot8.Name = "txt_NumSlot8"
        Me.txt_NumSlot8.NumericValue = 1
        Me.txt_NumSlot8.NumericValueInteger = 1
        Me.txt_NumSlot8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot8.RoundingStep = 0
        Me.txt_NumSlot8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot8.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot8.TabIndex = 248
        Me.txt_NumSlot8.Text = "1"
        Me.txt_NumSlot8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotDisplay7
        '
        Me.txt_SlotDisplay7.ArrowsIncrement = 0
        Me.txt_SlotDisplay7.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay7.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay7.Decimals = 5
        Me.txt_SlotDisplay7.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay7.Increment = 0
        Me.txt_SlotDisplay7.Location = New System.Drawing.Point(484, 84)
        Me.txt_SlotDisplay7.MaxValue = 99999.99999
        Me.txt_SlotDisplay7.MinValue = -99999.99999
        Me.txt_SlotDisplay7.Name = "txt_SlotDisplay7"
        Me.txt_SlotDisplay7.NumericValue = 0
        Me.txt_SlotDisplay7.ReadOnly = True
        Me.txt_SlotDisplay7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay7.RoundingStep = 0
        Me.txt_SlotDisplay7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay7.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay7.TabIndex = 7
        Me.txt_SlotDisplay7.Text = "0"
        Me.txt_SlotDisplay7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay7.WordWrap = False
        '
        'cmb_Type7
        '
        Me.cmb_Type7.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type7.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type7.BackColor = System.Drawing.Color.White
        Me.cmb_Type7.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type7.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type7.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type7.BorderSize = 1
        Me.cmb_Type7.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type7.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type7.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type7.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type7.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type7.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type7.DropDownHeight = 999
        Me.cmb_Type7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type7.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type7.IntegralHeight = False
        Me.cmb_Type7.ItemHeight = 13
        Me.cmb_Type7.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type7.Location = New System.Drawing.Point(484, 137)
        Me.cmb_Type7.Name = "cmb_Type7"
        Me.cmb_Type7.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type7.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type7.TabIndex = 246
        Me.cmb_Type7.TextPosition = 3
        '
        'txt_SensorMult7
        '
        Me.txt_SensorMult7.ArrowsIncrement = 0.001
        Me.txt_SensorMult7.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult7.Decimals = 5
        Me.txt_SensorMult7.Increment = 0.00001
        Me.txt_SensorMult7.Location = New System.Drawing.Point(484, 163)
        Me.txt_SensorMult7.MaxValue = 99999999
        Me.txt_SensorMult7.MinValue = -99999999
        Me.txt_SensorMult7.Name = "txt_SensorMult7"
        Me.txt_SensorMult7.NumericValue = 1
        Me.txt_SensorMult7.NumericValueInteger = 1
        Me.txt_SensorMult7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult7.RoundingStep = 0
        Me.txt_SensorMult7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult7.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult7.SuppressZeros = True
        Me.txt_SensorMult7.TabIndex = 245
        Me.txt_SensorMult7.Text = "1"
        Me.txt_SensorMult7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim7
        '
        Me.txt_SensorTrim7.ArrowsIncrement = 0.001
        Me.txt_SensorTrim7.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim7.Decimals = 4
        Me.txt_SensorTrim7.Increment = 0.0001
        Me.txt_SensorTrim7.Location = New System.Drawing.Point(484, 190)
        Me.txt_SensorTrim7.MaxValue = 99999999
        Me.txt_SensorTrim7.MinValue = -99999999
        Me.txt_SensorTrim7.Name = "txt_SensorTrim7"
        Me.txt_SensorTrim7.NumericValue = 0
        Me.txt_SensorTrim7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim7.RoundingStep = 0
        Me.txt_SensorTrim7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim7.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim7.SuppressZeros = True
        Me.txt_SensorTrim7.TabIndex = 244
        Me.txt_SensorTrim7.Text = "0"
        Me.txt_SensorTrim7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot7
        '
        Me.txt_NumSlot7.ArrowsIncrement = 1
        Me.txt_NumSlot7.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot7.Increment = 1
        Me.txt_NumSlot7.Location = New System.Drawing.Point(484, 111)
        Me.txt_NumSlot7.MaxValue = 999
        Me.txt_NumSlot7.MinValue = 1
        Me.txt_NumSlot7.Name = "txt_NumSlot7"
        Me.txt_NumSlot7.NumericValue = 1
        Me.txt_NumSlot7.NumericValueInteger = 1
        Me.txt_NumSlot7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot7.RoundingStep = 0
        Me.txt_NumSlot7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot7.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot7.TabIndex = 243
        Me.txt_NumSlot7.Text = "1"
        Me.txt_NumSlot7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotDisplay6
        '
        Me.txt_SlotDisplay6.ArrowsIncrement = 0
        Me.txt_SlotDisplay6.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay6.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay6.Decimals = 5
        Me.txt_SlotDisplay6.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay6.Increment = 0
        Me.txt_SlotDisplay6.Location = New System.Drawing.Point(416, 84)
        Me.txt_SlotDisplay6.MaxValue = 99999.99999
        Me.txt_SlotDisplay6.MinValue = -99999.99999
        Me.txt_SlotDisplay6.Name = "txt_SlotDisplay6"
        Me.txt_SlotDisplay6.NumericValue = 0
        Me.txt_SlotDisplay6.ReadOnly = True
        Me.txt_SlotDisplay6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay6.RoundingStep = 0
        Me.txt_SlotDisplay6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay6.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay6.TabIndex = 6
        Me.txt_SlotDisplay6.Text = "0"
        Me.txt_SlotDisplay6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay6.WordWrap = False
        '
        'txt_SlotDisplay5
        '
        Me.txt_SlotDisplay5.ArrowsIncrement = 0
        Me.txt_SlotDisplay5.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay5.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay5.Decimals = 5
        Me.txt_SlotDisplay5.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay5.Increment = 0
        Me.txt_SlotDisplay5.Location = New System.Drawing.Point(348, 84)
        Me.txt_SlotDisplay5.MaxValue = 99999.99999
        Me.txt_SlotDisplay5.MinValue = -99999.99999
        Me.txt_SlotDisplay5.Name = "txt_SlotDisplay5"
        Me.txt_SlotDisplay5.NumericValue = 0
        Me.txt_SlotDisplay5.ReadOnly = True
        Me.txt_SlotDisplay5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay5.RoundingStep = 0
        Me.txt_SlotDisplay5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay5.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay5.TabIndex = 5
        Me.txt_SlotDisplay5.Text = "0"
        Me.txt_SlotDisplay5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay5.WordWrap = False
        '
        'txt_SlotDisplay4
        '
        Me.txt_SlotDisplay4.ArrowsIncrement = 0
        Me.txt_SlotDisplay4.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay4.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay4.Decimals = 5
        Me.txt_SlotDisplay4.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay4.Increment = 0
        Me.txt_SlotDisplay4.Location = New System.Drawing.Point(280, 84)
        Me.txt_SlotDisplay4.MaxValue = 99999.99999
        Me.txt_SlotDisplay4.MinValue = -99999.99999
        Me.txt_SlotDisplay4.Name = "txt_SlotDisplay4"
        Me.txt_SlotDisplay4.NumericValue = 0
        Me.txt_SlotDisplay4.ReadOnly = True
        Me.txt_SlotDisplay4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay4.RoundingStep = 0
        Me.txt_SlotDisplay4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay4.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay4.TabIndex = 4
        Me.txt_SlotDisplay4.Text = "0"
        Me.txt_SlotDisplay4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay4.WordWrap = False
        '
        'txt_SlotDisplay3
        '
        Me.txt_SlotDisplay3.ArrowsIncrement = 0
        Me.txt_SlotDisplay3.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay3.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay3.Decimals = 5
        Me.txt_SlotDisplay3.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay3.Increment = 0
        Me.txt_SlotDisplay3.Location = New System.Drawing.Point(212, 84)
        Me.txt_SlotDisplay3.MaxValue = 99999.99999
        Me.txt_SlotDisplay3.MinValue = -99999.99999
        Me.txt_SlotDisplay3.Name = "txt_SlotDisplay3"
        Me.txt_SlotDisplay3.NumericValue = 0
        Me.txt_SlotDisplay3.ReadOnly = True
        Me.txt_SlotDisplay3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay3.RoundingStep = 0
        Me.txt_SlotDisplay3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay3.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay3.TabIndex = 3
        Me.txt_SlotDisplay3.Text = "0"
        Me.txt_SlotDisplay3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay3.WordWrap = False
        '
        'txt_SlotDisplay2
        '
        Me.txt_SlotDisplay2.ArrowsIncrement = 0
        Me.txt_SlotDisplay2.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay2.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay2.Decimals = 5
        Me.txt_SlotDisplay2.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay2.Increment = 0
        Me.txt_SlotDisplay2.Location = New System.Drawing.Point(144, 84)
        Me.txt_SlotDisplay2.MaxValue = 99999.99999
        Me.txt_SlotDisplay2.MinValue = -99999.99999
        Me.txt_SlotDisplay2.Name = "txt_SlotDisplay2"
        Me.txt_SlotDisplay2.NumericValue = 0
        Me.txt_SlotDisplay2.ReadOnly = True
        Me.txt_SlotDisplay2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay2.RoundingStep = 0
        Me.txt_SlotDisplay2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay2.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay2.TabIndex = 2
        Me.txt_SlotDisplay2.Text = "0"
        Me.txt_SlotDisplay2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay2.WordWrap = False
        '
        'txt_SlotDisplay1
        '
        Me.txt_SlotDisplay1.ArrowsIncrement = 0
        Me.txt_SlotDisplay1.BackColor = System.Drawing.SystemColors.WindowText
        Me.txt_SlotDisplay1.BackColor_Over = System.Drawing.SystemColors.WindowFrame
        Me.txt_SlotDisplay1.Decimals = 5
        Me.txt_SlotDisplay1.ForeColor = System.Drawing.Color.Yellow
        Me.txt_SlotDisplay1.Increment = 0
        Me.txt_SlotDisplay1.Location = New System.Drawing.Point(76, 84)
        Me.txt_SlotDisplay1.MaxValue = 99999.99999
        Me.txt_SlotDisplay1.MinValue = -99999.99999
        Me.txt_SlotDisplay1.Name = "txt_SlotDisplay1"
        Me.txt_SlotDisplay1.NumericValue = 0
        Me.txt_SlotDisplay1.ReadOnly = True
        Me.txt_SlotDisplay1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotDisplay1.RoundingStep = 0
        Me.txt_SlotDisplay1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotDisplay1.Size = New System.Drawing.Size(61, 20)
        Me.txt_SlotDisplay1.TabIndex = 1
        Me.txt_SlotDisplay1.Text = "0"
        Me.txt_SlotDisplay1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_SlotDisplay1.WordWrap = False
        '
        'cmb_Type6
        '
        Me.cmb_Type6.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type6.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type6.BackColor = System.Drawing.Color.White
        Me.cmb_Type6.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type6.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type6.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type6.BorderSize = 1
        Me.cmb_Type6.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type6.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type6.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type6.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type6.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type6.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type6.DropDownHeight = 999
        Me.cmb_Type6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type6.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type6.IntegralHeight = False
        Me.cmb_Type6.ItemHeight = 13
        Me.cmb_Type6.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type6.Location = New System.Drawing.Point(416, 137)
        Me.cmb_Type6.Name = "cmb_Type6"
        Me.cmb_Type6.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type6.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type6.TabIndex = 232
        Me.cmb_Type6.TextPosition = 3
        '
        'cmb_Type5
        '
        Me.cmb_Type5.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type5.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type5.BackColor = System.Drawing.Color.White
        Me.cmb_Type5.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type5.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type5.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type5.BorderSize = 1
        Me.cmb_Type5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type5.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type5.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type5.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type5.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type5.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type5.DropDownHeight = 999
        Me.cmb_Type5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type5.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type5.IntegralHeight = False
        Me.cmb_Type5.ItemHeight = 13
        Me.cmb_Type5.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type5.Location = New System.Drawing.Point(348, 137)
        Me.cmb_Type5.Name = "cmb_Type5"
        Me.cmb_Type5.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type5.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type5.TabIndex = 231
        Me.cmb_Type5.TextPosition = 3
        '
        'cmb_Type4
        '
        Me.cmb_Type4.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type4.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type4.BackColor = System.Drawing.Color.White
        Me.cmb_Type4.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type4.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type4.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type4.BorderSize = 1
        Me.cmb_Type4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type4.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type4.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type4.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type4.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type4.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type4.DropDownHeight = 999
        Me.cmb_Type4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type4.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type4.IntegralHeight = False
        Me.cmb_Type4.ItemHeight = 13
        Me.cmb_Type4.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type4.Location = New System.Drawing.Point(280, 137)
        Me.cmb_Type4.Name = "cmb_Type4"
        Me.cmb_Type4.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type4.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type4.TabIndex = 230
        Me.cmb_Type4.TextPosition = 3
        '
        'cmb_Type3
        '
        Me.cmb_Type3.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type3.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type3.BackColor = System.Drawing.Color.White
        Me.cmb_Type3.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type3.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type3.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type3.BorderSize = 1
        Me.cmb_Type3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type3.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type3.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type3.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type3.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type3.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type3.DropDownHeight = 999
        Me.cmb_Type3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type3.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type3.IntegralHeight = False
        Me.cmb_Type3.ItemHeight = 13
        Me.cmb_Type3.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type3.Location = New System.Drawing.Point(212, 137)
        Me.cmb_Type3.Name = "cmb_Type3"
        Me.cmb_Type3.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type3.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type3.TabIndex = 229
        Me.cmb_Type3.TextPosition = 3
        '
        'cmb_Type2
        '
        Me.cmb_Type2.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type2.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type2.BackColor = System.Drawing.Color.White
        Me.cmb_Type2.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type2.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type2.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type2.BorderSize = 1
        Me.cmb_Type2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type2.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type2.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type2.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type2.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type2.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type2.DropDownHeight = 999
        Me.cmb_Type2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type2.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type2.IntegralHeight = False
        Me.cmb_Type2.ItemHeight = 13
        Me.cmb_Type2.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type2.Location = New System.Drawing.Point(144, 137)
        Me.cmb_Type2.Name = "cmb_Type2"
        Me.cmb_Type2.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type2.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type2.TabIndex = 228
        Me.cmb_Type2.TextPosition = 3
        '
        'cmb_Type1
        '
        Me.cmb_Type1.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Type1.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Type1.BackColor = System.Drawing.Color.White
        Me.cmb_Type1.BackColor_Focused = System.Drawing.Color.White
        Me.cmb_Type1.BackColor_Over = System.Drawing.Color.White
        Me.cmb_Type1.BorderColor = System.Drawing.Color.DarkGray
        Me.cmb_Type1.BorderSize = 1
        Me.cmb_Type1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Type1.DropDown_BackColor = System.Drawing.Color.Gainsboro
        Me.cmb_Type1.DropDown_BackSelected = System.Drawing.Color.Yellow
        Me.cmb_Type1.DropDown_BorderColor = System.Drawing.Color.DimGray
        Me.cmb_Type1.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Type1.DropDown_ForeSelected = System.Drawing.Color.DarkBlue
        Me.cmb_Type1.DropDownHeight = 999
        Me.cmb_Type1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Type1.ForeColor = System.Drawing.Color.Black
        Me.cmb_Type1.IntegralHeight = False
        Me.cmb_Type1.ItemHeight = 13
        Me.cmb_Type1.Items.AddRange(New Object() {"Unused", "Raw value", "Volt", "Millivolt", "Res-3", "Res-4", "PT100-3", "PT100-4", "PT500-3", "PT500-4", "PT1000-3", "PT1000-4", "LM35", "TSIC501", "UVM-30A", "ML8511"})
        Me.cmb_Type1.Location = New System.Drawing.Point(76, 137)
        Me.cmb_Type1.Name = "cmb_Type1"
        Me.cmb_Type1.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Type1.Size = New System.Drawing.Size(61, 19)
        Me.cmb_Type1.TabIndex = 227
        Me.cmb_Type1.TextPosition = 3
        '
        'txt_SensorMult6
        '
        Me.txt_SensorMult6.ArrowsIncrement = 0.001
        Me.txt_SensorMult6.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult6.Decimals = 5
        Me.txt_SensorMult6.Increment = 0.00001
        Me.txt_SensorMult6.Location = New System.Drawing.Point(416, 163)
        Me.txt_SensorMult6.MaxValue = 99999999
        Me.txt_SensorMult6.MinValue = -99999999
        Me.txt_SensorMult6.Name = "txt_SensorMult6"
        Me.txt_SensorMult6.NumericValue = 1
        Me.txt_SensorMult6.NumericValueInteger = 1
        Me.txt_SensorMult6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult6.RoundingStep = 0
        Me.txt_SensorMult6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult6.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult6.SuppressZeros = True
        Me.txt_SensorMult6.TabIndex = 226
        Me.txt_SensorMult6.Text = "1"
        Me.txt_SensorMult6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorMult5
        '
        Me.txt_SensorMult5.ArrowsIncrement = 0.001
        Me.txt_SensorMult5.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult5.Decimals = 5
        Me.txt_SensorMult5.Increment = 0.00001
        Me.txt_SensorMult5.Location = New System.Drawing.Point(348, 163)
        Me.txt_SensorMult5.MaxValue = 99999999
        Me.txt_SensorMult5.MinValue = -99999999
        Me.txt_SensorMult5.Name = "txt_SensorMult5"
        Me.txt_SensorMult5.NumericValue = 1
        Me.txt_SensorMult5.NumericValueInteger = 1
        Me.txt_SensorMult5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult5.RoundingStep = 0
        Me.txt_SensorMult5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult5.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult5.SuppressZeros = True
        Me.txt_SensorMult5.TabIndex = 225
        Me.txt_SensorMult5.Text = "1"
        Me.txt_SensorMult5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorMult4
        '
        Me.txt_SensorMult4.ArrowsIncrement = 0.001
        Me.txt_SensorMult4.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult4.Decimals = 5
        Me.txt_SensorMult4.Increment = 0.00001
        Me.txt_SensorMult4.Location = New System.Drawing.Point(280, 163)
        Me.txt_SensorMult4.MaxValue = 99999999
        Me.txt_SensorMult4.MinValue = -99999999
        Me.txt_SensorMult4.Name = "txt_SensorMult4"
        Me.txt_SensorMult4.NumericValue = 1
        Me.txt_SensorMult4.NumericValueInteger = 1
        Me.txt_SensorMult4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult4.RoundingStep = 0
        Me.txt_SensorMult4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult4.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult4.SuppressZeros = True
        Me.txt_SensorMult4.TabIndex = 224
        Me.txt_SensorMult4.Text = "1"
        Me.txt_SensorMult4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorMult3
        '
        Me.txt_SensorMult3.ArrowsIncrement = 0.001
        Me.txt_SensorMult3.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult3.Decimals = 5
        Me.txt_SensorMult3.Increment = 0.00001
        Me.txt_SensorMult3.Location = New System.Drawing.Point(212, 163)
        Me.txt_SensorMult3.MaxValue = 99999999
        Me.txt_SensorMult3.MinValue = -99999999
        Me.txt_SensorMult3.Name = "txt_SensorMult3"
        Me.txt_SensorMult3.NumericValue = 1
        Me.txt_SensorMult3.NumericValueInteger = 1
        Me.txt_SensorMult3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult3.RoundingStep = 0
        Me.txt_SensorMult3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult3.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult3.SuppressZeros = True
        Me.txt_SensorMult3.TabIndex = 223
        Me.txt_SensorMult3.Text = "1"
        Me.txt_SensorMult3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorMult2
        '
        Me.txt_SensorMult2.ArrowsIncrement = 0.001
        Me.txt_SensorMult2.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult2.Decimals = 5
        Me.txt_SensorMult2.Increment = 0.00001
        Me.txt_SensorMult2.Location = New System.Drawing.Point(144, 163)
        Me.txt_SensorMult2.MaxValue = 99999999
        Me.txt_SensorMult2.MinValue = -99999999
        Me.txt_SensorMult2.Name = "txt_SensorMult2"
        Me.txt_SensorMult2.NumericValue = 1
        Me.txt_SensorMult2.NumericValueInteger = 1
        Me.txt_SensorMult2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult2.RoundingStep = 0
        Me.txt_SensorMult2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult2.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult2.SuppressZeros = True
        Me.txt_SensorMult2.TabIndex = 222
        Me.txt_SensorMult2.Text = "1"
        Me.txt_SensorMult2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorMult1
        '
        Me.txt_SensorMult1.ArrowsIncrement = 0.001
        Me.txt_SensorMult1.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorMult1.Decimals = 5
        Me.txt_SensorMult1.Increment = 0.00001
        Me.txt_SensorMult1.Location = New System.Drawing.Point(76, 163)
        Me.txt_SensorMult1.MaxValue = 99999999
        Me.txt_SensorMult1.MinValue = -99999999
        Me.txt_SensorMult1.Name = "txt_SensorMult1"
        Me.txt_SensorMult1.NumericValue = 1
        Me.txt_SensorMult1.NumericValueInteger = 1
        Me.txt_SensorMult1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorMult1.RoundingStep = 0
        Me.txt_SensorMult1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorMult1.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorMult1.SuppressZeros = True
        Me.txt_SensorMult1.TabIndex = 221
        Me.txt_SensorMult1.Text = "1"
        Me.txt_SensorMult1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim6
        '
        Me.txt_SensorTrim6.ArrowsIncrement = 0.001
        Me.txt_SensorTrim6.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim6.Decimals = 4
        Me.txt_SensorTrim6.Increment = 0.0001
        Me.txt_SensorTrim6.Location = New System.Drawing.Point(416, 190)
        Me.txt_SensorTrim6.MaxValue = 99999999
        Me.txt_SensorTrim6.MinValue = -99999999
        Me.txt_SensorTrim6.Name = "txt_SensorTrim6"
        Me.txt_SensorTrim6.NumericValue = 0
        Me.txt_SensorTrim6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim6.RoundingStep = 0
        Me.txt_SensorTrim6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim6.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim6.SuppressZeros = True
        Me.txt_SensorTrim6.TabIndex = 220
        Me.txt_SensorTrim6.Text = "0"
        Me.txt_SensorTrim6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim5
        '
        Me.txt_SensorTrim5.ArrowsIncrement = 0.001
        Me.txt_SensorTrim5.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim5.Decimals = 4
        Me.txt_SensorTrim5.Increment = 0.0001
        Me.txt_SensorTrim5.Location = New System.Drawing.Point(348, 190)
        Me.txt_SensorTrim5.MaxValue = 99999999
        Me.txt_SensorTrim5.MinValue = -99999999
        Me.txt_SensorTrim5.Name = "txt_SensorTrim5"
        Me.txt_SensorTrim5.NumericValue = 0
        Me.txt_SensorTrim5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim5.RoundingStep = 0
        Me.txt_SensorTrim5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim5.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim5.SuppressZeros = True
        Me.txt_SensorTrim5.TabIndex = 219
        Me.txt_SensorTrim5.Text = "0"
        Me.txt_SensorTrim5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim4
        '
        Me.txt_SensorTrim4.ArrowsIncrement = 0.001
        Me.txt_SensorTrim4.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim4.Decimals = 4
        Me.txt_SensorTrim4.Increment = 0.0001
        Me.txt_SensorTrim4.Location = New System.Drawing.Point(280, 190)
        Me.txt_SensorTrim4.MaxValue = 99999999
        Me.txt_SensorTrim4.MinValue = -99999999
        Me.txt_SensorTrim4.Name = "txt_SensorTrim4"
        Me.txt_SensorTrim4.NumericValue = 0
        Me.txt_SensorTrim4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim4.RoundingStep = 0
        Me.txt_SensorTrim4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim4.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim4.SuppressZeros = True
        Me.txt_SensorTrim4.TabIndex = 218
        Me.txt_SensorTrim4.Text = "0"
        Me.txt_SensorTrim4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim3
        '
        Me.txt_SensorTrim3.ArrowsIncrement = 0.001
        Me.txt_SensorTrim3.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim3.Decimals = 4
        Me.txt_SensorTrim3.Increment = 0.0001
        Me.txt_SensorTrim3.Location = New System.Drawing.Point(212, 190)
        Me.txt_SensorTrim3.MaxValue = 99999999
        Me.txt_SensorTrim3.MinValue = -99999999
        Me.txt_SensorTrim3.Name = "txt_SensorTrim3"
        Me.txt_SensorTrim3.NumericValue = 0
        Me.txt_SensorTrim3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim3.RoundingStep = 0
        Me.txt_SensorTrim3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim3.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim3.SuppressZeros = True
        Me.txt_SensorTrim3.TabIndex = 217
        Me.txt_SensorTrim3.Text = "0"
        Me.txt_SensorTrim3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim2
        '
        Me.txt_SensorTrim2.ArrowsIncrement = 0.001
        Me.txt_SensorTrim2.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim2.Decimals = 4
        Me.txt_SensorTrim2.Increment = 0.0001
        Me.txt_SensorTrim2.Location = New System.Drawing.Point(144, 190)
        Me.txt_SensorTrim2.MaxValue = 99999999
        Me.txt_SensorTrim2.MinValue = -99999999
        Me.txt_SensorTrim2.Name = "txt_SensorTrim2"
        Me.txt_SensorTrim2.NumericValue = 0
        Me.txt_SensorTrim2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim2.RoundingStep = 0
        Me.txt_SensorTrim2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim2.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim2.SuppressZeros = True
        Me.txt_SensorTrim2.TabIndex = 216
        Me.txt_SensorTrim2.Text = "0"
        Me.txt_SensorTrim2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SensorTrim1
        '
        Me.txt_SensorTrim1.ArrowsIncrement = 0.001
        Me.txt_SensorTrim1.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SensorTrim1.Decimals = 4
        Me.txt_SensorTrim1.Increment = 0.0001
        Me.txt_SensorTrim1.Location = New System.Drawing.Point(76, 190)
        Me.txt_SensorTrim1.MaxValue = 99999999
        Me.txt_SensorTrim1.MinValue = -99999999
        Me.txt_SensorTrim1.Name = "txt_SensorTrim1"
        Me.txt_SensorTrim1.NumericValue = 0
        Me.txt_SensorTrim1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SensorTrim1.RoundingStep = 0
        Me.txt_SensorTrim1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SensorTrim1.Size = New System.Drawing.Size(61, 20)
        Me.txt_SensorTrim1.SuppressZeros = True
        Me.txt_SensorTrim1.TabIndex = 215
        Me.txt_SensorTrim1.Text = "0"
        Me.txt_SensorTrim1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot6
        '
        Me.txt_NumSlot6.ArrowsIncrement = 1
        Me.txt_NumSlot6.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot6.Increment = 1
        Me.txt_NumSlot6.Location = New System.Drawing.Point(416, 111)
        Me.txt_NumSlot6.MaxValue = 999
        Me.txt_NumSlot6.MinValue = 1
        Me.txt_NumSlot6.Name = "txt_NumSlot6"
        Me.txt_NumSlot6.NumericValue = 1
        Me.txt_NumSlot6.NumericValueInteger = 1
        Me.txt_NumSlot6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot6.RoundingStep = 0
        Me.txt_NumSlot6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot6.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot6.TabIndex = 208
        Me.txt_NumSlot6.Text = "1"
        Me.txt_NumSlot6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot5
        '
        Me.txt_NumSlot5.ArrowsIncrement = 1
        Me.txt_NumSlot5.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot5.Increment = 1
        Me.txt_NumSlot5.Location = New System.Drawing.Point(348, 111)
        Me.txt_NumSlot5.MaxValue = 999
        Me.txt_NumSlot5.MinValue = 1
        Me.txt_NumSlot5.Name = "txt_NumSlot5"
        Me.txt_NumSlot5.NumericValue = 1
        Me.txt_NumSlot5.NumericValueInteger = 1
        Me.txt_NumSlot5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot5.RoundingStep = 0
        Me.txt_NumSlot5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot5.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot5.TabIndex = 207
        Me.txt_NumSlot5.Text = "1"
        Me.txt_NumSlot5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot4
        '
        Me.txt_NumSlot4.ArrowsIncrement = 1
        Me.txt_NumSlot4.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot4.Increment = 1
        Me.txt_NumSlot4.Location = New System.Drawing.Point(280, 111)
        Me.txt_NumSlot4.MaxValue = 999
        Me.txt_NumSlot4.MinValue = 1
        Me.txt_NumSlot4.Name = "txt_NumSlot4"
        Me.txt_NumSlot4.NumericValue = 1
        Me.txt_NumSlot4.NumericValueInteger = 1
        Me.txt_NumSlot4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot4.RoundingStep = 0
        Me.txt_NumSlot4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot4.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot4.TabIndex = 206
        Me.txt_NumSlot4.Text = "1"
        Me.txt_NumSlot4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot3
        '
        Me.txt_NumSlot3.ArrowsIncrement = 1
        Me.txt_NumSlot3.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot3.Increment = 1
        Me.txt_NumSlot3.Location = New System.Drawing.Point(212, 111)
        Me.txt_NumSlot3.MaxValue = 999
        Me.txt_NumSlot3.MinValue = 1
        Me.txt_NumSlot3.Name = "txt_NumSlot3"
        Me.txt_NumSlot3.NumericValue = 1
        Me.txt_NumSlot3.NumericValueInteger = 1
        Me.txt_NumSlot3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot3.RoundingStep = 0
        Me.txt_NumSlot3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot3.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot3.TabIndex = 205
        Me.txt_NumSlot3.Text = "1"
        Me.txt_NumSlot3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot2
        '
        Me.txt_NumSlot2.ArrowsIncrement = 1
        Me.txt_NumSlot2.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot2.Increment = 1
        Me.txt_NumSlot2.Location = New System.Drawing.Point(144, 111)
        Me.txt_NumSlot2.MaxValue = 999
        Me.txt_NumSlot2.MinValue = 1
        Me.txt_NumSlot2.Name = "txt_NumSlot2"
        Me.txt_NumSlot2.NumericValue = 1
        Me.txt_NumSlot2.NumericValueInteger = 1
        Me.txt_NumSlot2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot2.RoundingStep = 0
        Me.txt_NumSlot2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot2.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot2.TabIndex = 204
        Me.txt_NumSlot2.Text = "1"
        Me.txt_NumSlot2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_NumSlot1
        '
        Me.txt_NumSlot1.ArrowsIncrement = 1
        Me.txt_NumSlot1.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_NumSlot1.ForeColor = System.Drawing.Color.Black
        Me.txt_NumSlot1.Increment = 1
        Me.txt_NumSlot1.Location = New System.Drawing.Point(76, 111)
        Me.txt_NumSlot1.MaxValue = 999
        Me.txt_NumSlot1.MinValue = 1
        Me.txt_NumSlot1.Name = "txt_NumSlot1"
        Me.txt_NumSlot1.NumericValue = 1
        Me.txt_NumSlot1.NumericValueInteger = 1
        Me.txt_NumSlot1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_NumSlot1.RoundingStep = 0
        Me.txt_NumSlot1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_NumSlot1.Size = New System.Drawing.Size(61, 20)
        Me.txt_NumSlot1.TabIndex = 203
        Me.txt_NumSlot1.Text = "1"
        Me.txt_NumSlot1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(624, 242)
        Me.Controls.Add(Me.btn_Zero8)
        Me.Controls.Add(Me.btn_Zero7)
        Me.Controls.Add(Me.btn_Zero6)
        Me.Controls.Add(Me.btn_Zero5)
        Me.Controls.Add(Me.btn_Zero4)
        Me.Controls.Add(Me.btn_Zero3)
        Me.Controls.Add(Me.btn_Zero2)
        Me.Controls.Add(Me.btn_Zero1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_RecInterval)
        Me.Controls.Add(Me.txt_SlotDisplay8)
        Me.Controls.Add(Me.cmb_Type8)
        Me.Controls.Add(Me.txt_SensorMult8)
        Me.Controls.Add(Me.txt_SensorTrim8)
        Me.Controls.Add(Me.txt_NumSlot8)
        Me.Controls.Add(Me.txt_SlotDisplay7)
        Me.Controls.Add(Me.cmb_Type7)
        Me.Controls.Add(Me.txt_SensorMult7)
        Me.Controls.Add(Me.txt_SensorTrim7)
        Me.Controls.Add(Me.txt_NumSlot7)
        Me.Controls.Add(Me.txt_SlotDisplay6)
        Me.Controls.Add(Me.txt_SlotDisplay5)
        Me.Controls.Add(Me.txt_SlotDisplay4)
        Me.Controls.Add(Me.txt_SlotDisplay3)
        Me.Controls.Add(Me.txt_SlotDisplay2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_LogFileName)
        Me.Controls.Add(Me.txt_SlotDisplay1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmb_Type6)
        Me.Controls.Add(Me.cmb_Type5)
        Me.Controls.Add(Me.cmb_Type4)
        Me.Controls.Add(Me.cmb_Type3)
        Me.Controls.Add(Me.cmb_Type2)
        Me.Controls.Add(Me.cmb_Type1)
        Me.Controls.Add(Me.txt_SensorMult6)
        Me.Controls.Add(Me.txt_SensorMult5)
        Me.Controls.Add(Me.txt_SensorMult4)
        Me.Controls.Add(Me.txt_SensorMult3)
        Me.Controls.Add(Me.txt_SensorMult2)
        Me.Controls.Add(Me.txt_SensorMult1)
        Me.Controls.Add(Me.txt_SensorTrim6)
        Me.Controls.Add(Me.txt_SensorTrim5)
        Me.Controls.Add(Me.txt_SensorTrim4)
        Me.Controls.Add(Me.txt_SensorTrim3)
        Me.Controls.Add(Me.txt_SensorTrim2)
        Me.Controls.Add(Me.txt_SensorTrim1)
        Me.Controls.Add(Me.txt_NumSlot6)
        Me.Controls.Add(Me.txt_NumSlot5)
        Me.Controls.Add(Me.txt_NumSlot4)
        Me.Controls.Add(Me.txt_NumSlot3)
        Me.Controls.Add(Me.txt_NumSlot2)
        Me.Controls.Add(Me.txt_NumSlot1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lbl_Display)
        Me.Controls.Add(Me.Label2)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Tag = ""
        Me.Text = "Theremino Datalogger MR"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Display As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_NumSlot1 As MyTextBox
    Friend WithEvents txt_NumSlot2 As MyTextBox
    Friend WithEvents txt_NumSlot3 As MyTextBox
    Friend WithEvents txt_NumSlot4 As MyTextBox
    Friend WithEvents txt_NumSlot5 As MyTextBox
    Friend WithEvents txt_NumSlot6 As MyTextBox
    Friend WithEvents txt_SensorTrim6 As MyTextBox
    Friend WithEvents txt_SensorTrim5 As MyTextBox
    Friend WithEvents txt_SensorTrim4 As MyTextBox
    Friend WithEvents txt_SensorTrim3 As MyTextBox
    Friend WithEvents txt_SensorTrim2 As MyTextBox
    Friend WithEvents txt_SensorTrim1 As MyTextBox
    Friend WithEvents txt_SensorMult6 As MyTextBox
    Friend WithEvents txt_SensorMult5 As MyTextBox
    Friend WithEvents txt_SensorMult4 As MyTextBox
    Friend WithEvents txt_SensorMult3 As MyTextBox
    Friend WithEvents txt_SensorMult2 As MyTextBox
    Friend WithEvents txt_SensorMult1 As MyTextBox
    Friend WithEvents cmb_Type1 As MyComboBox
    Friend WithEvents cmb_Type2 As MyComboBox
    Friend WithEvents cmb_Type3 As MyComboBox
    Friend WithEvents cmb_Type4 As MyComboBox
    Friend WithEvents cmb_Type5 As MyComboBox
    Friend WithEvents cmb_Type6 As MyComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_SlotDisplay1 As MyTextBox
    Friend WithEvents lbl_LogFileName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_SlotDisplay2 As MyTextBox
    Friend WithEvents txt_SlotDisplay3 As MyTextBox
    Friend WithEvents txt_SlotDisplay4 As MyTextBox
    Friend WithEvents txt_SlotDisplay5 As MyTextBox
    Friend WithEvents txt_SlotDisplay6 As MyTextBox
    Friend WithEvents txt_SlotDisplay7 As MyTextBox
    Friend WithEvents cmb_Type7 As MyComboBox
    Friend WithEvents txt_SensorMult7 As MyTextBox
    Friend WithEvents txt_SensorTrim7 As MyTextBox
    Friend WithEvents txt_NumSlot7 As MyTextBox
    Friend WithEvents txt_SlotDisplay8 As MyTextBox
    Friend WithEvents cmb_Type8 As MyComboBox
    Friend WithEvents txt_SensorMult8 As MyTextBox
    Friend WithEvents txt_SensorTrim8 As MyTextBox
    Friend WithEvents txt_NumSlot8 As MyTextBox
    Friend WithEvents txt_RecInterval As Theremino_Logger.MyTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btn_Zero1 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero2 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero3 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero6 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero5 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero4 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero8 As System.Windows.Forms.Button
    Friend WithEvents btn_Zero7 As System.Windows.Forms.Button

End Class
