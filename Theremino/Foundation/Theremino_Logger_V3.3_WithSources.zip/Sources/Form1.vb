﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Text = AppTitleAndVersion("Theremino Logger")
        '
        FileName = Date.Now.ToString("yyyyMMdd_HHmmss", GCI) + "_LOG.csv"
        lbl_LogFileName.Text = FileName
        FileName = ".\" + FileName
        '
        SetDefaultValues()
        Load_INI()
        '
        txt_SlotDisplay1.Focus()
        SetTimer1_Interval()
        Timer1.Start()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
    End Sub

    Private Sub SetDefaultValues()
        cmb_Type1.SelectedIndex = 0
        cmb_Type2.SelectedIndex = 0
        cmb_Type3.SelectedIndex = 0
        cmb_Type4.SelectedIndex = 0
        cmb_Type5.SelectedIndex = 0
        cmb_Type6.SelectedIndex = 0
        cmb_Type7.SelectedIndex = 0
        cmb_Type8.SelectedIndex = 0
        txt_NumSlot1.NumericValueInteger = 10
        txt_NumSlot2.NumericValueInteger = 20
        txt_NumSlot3.NumericValueInteger = 30
        txt_NumSlot4.NumericValueInteger = 40
        txt_NumSlot5.NumericValueInteger = 50
        txt_NumSlot6.NumericValueInteger = 60
        txt_NumSlot7.NumericValueInteger = 70
        txt_NumSlot8.NumericValueInteger = 80
    End Sub

    Private Sub SetTimer1_Interval()
        ' The value 8 is an approximate compensation for the 16 mS timer granularity 
        Dim n As Int32 = CInt(Val(txt_RecInterval.Text) * 1000 - 8)
        If n <= 0 Then n = 1
        Timer1.Interval = n
    End Sub


    ' ==============================================================================================================
    '  CONTROLS
    ' ==============================================================================================================
    Private Sub txt_RecInterval_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_RecInterval.TextChanged
        SetTimer1_Interval()
    End Sub

    Private Sub txt_NumSlot1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot1.TextChanged
        Slot(0) = CInt(txt_NumSlot1.Text)
    End Sub
    Private Sub txt_NumSlot2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot2.TextChanged
        Slot(1) = CInt(txt_NumSlot2.Text)
    End Sub
    Private Sub txt_NumSlot3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot3.TextChanged
        Slot(2) = CInt(txt_NumSlot3.Text)
    End Sub
    Private Sub txt_NumSlot4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot4.TextChanged
        Slot(3) = CInt(txt_NumSlot4.Text)
    End Sub
    Private Sub txt_NumSlot5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot5.TextChanged
        Slot(4) = CInt(txt_NumSlot5.Text)
    End Sub
    Private Sub txt_NumSlot6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot6.TextChanged
        Slot(5) = CInt(txt_NumSlot6.Text)
    End Sub
    Private Sub txt_NumSlot7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot7.TextChanged
        Slot(6) = CInt(txt_NumSlot7.Text)
    End Sub
    Private Sub txt_NumSlot8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_NumSlot8.TextChanged
        Slot(7) = CInt(txt_NumSlot8.Text)
    End Sub

    Private Sub cmb_Type1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type1.SelectedIndexChanged
        SensorType(0) = CStr(cmb_Type1.SelectedItem)
    End Sub
    Private Sub cmb_Type2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type2.SelectedIndexChanged
        SensorType(1) = CStr(cmb_Type2.SelectedItem)
    End Sub
    Private Sub cmb_Type3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type3.SelectedIndexChanged
        SensorType(2) = CStr(cmb_Type3.SelectedItem)
    End Sub
    Private Sub cmb_Type4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type4.SelectedIndexChanged
        SensorType(3) = CStr(cmb_Type4.SelectedItem)
    End Sub
    Private Sub cmb_Type5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type5.SelectedIndexChanged
        SensorType(4) = CStr(cmb_Type5.SelectedItem)
    End Sub
    Private Sub cmb_Type6_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type6.SelectedIndexChanged
        SensorType(5) = CStr(cmb_Type6.SelectedItem)
    End Sub
    Private Sub cmb_Type7_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type7.SelectedIndexChanged
        SensorType(6) = CStr(cmb_Type7.SelectedItem)
    End Sub
    Private Sub cmb_Type8_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type8.SelectedIndexChanged
        SensorType(7) = CStr(cmb_Type8.SelectedItem)
    End Sub

    Private Sub cmb_Type1_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type1.DropDown
        DropDown(cmb_Type1, txt_SensorMult1)
    End Sub
    Private Sub cmb_Type2_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type2.DropDown
        DropDown(cmb_Type2, txt_SensorMult2)
    End Sub
    Private Sub cmb_Type3_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type3.DropDown
        DropDown(cmb_Type3, txt_SensorMult3)
    End Sub
    Private Sub cmb_Type4_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type4.DropDown
        DropDown(cmb_Type4, txt_SensorMult4)
    End Sub
    Private Sub cmb_Type5_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type5.DropDown
        DropDown(cmb_Type5, txt_SensorMult5)
    End Sub
    Private Sub cmb_Type6_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type6.DropDown
        DropDown(cmb_Type6, txt_SensorMult6)
    End Sub
    Private Sub cmb_Type7_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type7.DropDown
        DropDown(cmb_Type7, txt_SensorMult7)
    End Sub
    Private Sub cmb_Type8_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type8.DropDown
        DropDown(cmb_Type8, txt_SensorMult8)
    End Sub
    Private Sub DropDown(ByRef cmb As MyComboBox, ByRef txt As MyTextBox)
        cmb.ItemHeight = 16
    End Sub

    Private Sub cmb_Type1_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type1.DropDownClosed
        DropDownClosed(cmb_Type1, txt_SensorMult1)
    End Sub
    Private Sub cmb_Type2_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type2.DropDownClosed
        DropDownClosed(cmb_Type2, txt_SensorMult2)
    End Sub
    Private Sub cmb_Type3_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type3.DropDownClosed
        DropDownClosed(cmb_Type3, txt_SensorMult3)
    End Sub
    Private Sub cmb_Type4_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type4.DropDownClosed
        DropDownClosed(cmb_Type4, txt_SensorMult4)
    End Sub
    Private Sub cmb_Type5_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type5.DropDownClosed
        DropDownClosed(cmb_Type5, txt_SensorMult5)
    End Sub
    Private Sub cmb_Type6_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type6.DropDownClosed
        DropDownClosed(cmb_Type6, txt_SensorMult6)
    End Sub
    Private Sub cmb_Type7_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type7.DropDownClosed
        DropDownClosed(cmb_Type7, txt_SensorMult7)
    End Sub
    Private Sub cmb_Type8_DropDownClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_Type8.DropDownClosed
        DropDownClosed(cmb_Type8, txt_SensorMult8)
    End Sub
    Private Sub DropDownClosed(ByRef cmb As MyComboBox, ByRef txt As MyTextBox)
        cmb.ItemHeight = 12
        If cmb.Text.StartsWith("PT") Then
            If txt.NumericValue < 10 Then txt.NumericValue = 10000
        Else
            If txt.NumericValue > 10 Then txt.NumericValue = 1
        End If
    End Sub

    Private Sub txt_SensorMult1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult1.TextChanged
        SensorMultiplier(0) = CSng(txt_SensorMult1.NumericValue)
    End Sub
    Private Sub txt_SensorMult2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult2.TextChanged
        SensorMultiplier(1) = CSng(txt_SensorMult2.NumericValue)
    End Sub
    Private Sub txt_SensorMult3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult3.TextChanged
        SensorMultiplier(2) = CSng(txt_SensorMult3.NumericValue)
    End Sub
    Private Sub txt_SensorMult4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult4.TextChanged
        SensorMultiplier(3) = CSng(txt_SensorMult4.NumericValue)
    End Sub
    Private Sub txt_SensorMult5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult5.TextChanged
        SensorMultiplier(4) = CSng(txt_SensorMult5.NumericValue)
    End Sub
    Private Sub txt_SensorMult6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult6.TextChanged
        SensorMultiplier(5) = CSng(txt_SensorMult6.NumericValue)
    End Sub
    Private Sub txt_SensorMult7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult7.TextChanged
        SensorMultiplier(6) = CSng(txt_SensorMult7.NumericValue)
    End Sub
    Private Sub txt_SensorMult8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorMult8.TextChanged
        SensorMultiplier(7) = CSng(txt_SensorMult8.NumericValue)
    End Sub

    Private Sub txt_SensorTrim1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim1.TextChanged
        SensorTrim(0) = CSng(txt_SensorTrim1.NumericValue)
    End Sub
    Private Sub txt_SensorTrim2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim2.TextChanged
        SensorTrim(1) = CSng(txt_SensorTrim2.NumericValue)
    End Sub
    Private Sub txt_SensorTrim3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim3.TextChanged
        SensorTrim(2) = CSng(txt_SensorTrim3.NumericValue)
    End Sub
    Private Sub txt_SensorTrim4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim4.TextChanged
        SensorTrim(3) = CSng(txt_SensorTrim4.NumericValue)
    End Sub
    Private Sub txt_SensorTrim5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim5.TextChanged
        SensorTrim(4) = CSng(txt_SensorTrim5.NumericValue)
    End Sub
    Private Sub txt_SensorTrim6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim6.TextChanged
        SensorTrim(5) = CSng(txt_SensorTrim6.NumericValue)
    End Sub
    Private Sub txt_SensorTrim7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim7.TextChanged
        SensorTrim(6) = CSng(txt_SensorTrim7.NumericValue)
    End Sub
    Private Sub txt_SensorTrim8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SensorTrim8.TextChanged
        SensorTrim(7) = CSng(txt_SensorTrim8.NumericValue)
    End Sub

    Private Sub btn_Zero1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero1.Click
        SetZero(0)
        txt_SensorTrim1.NumericValue = SensorTrim(0)
    End Sub
    Private Sub btn_Zero2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero2.Click
        SetZero(1)
        txt_SensorTrim2.NumericValue = SensorTrim(1)
    End Sub
    Private Sub btn_Zero3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero3.Click
        SetZero(2)
        txt_SensorTrim3.NumericValue = SensorTrim(2)
    End Sub
    Private Sub btn_Zero4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero4.Click
        SetZero(3)
        txt_SensorTrim4.NumericValue = SensorTrim(3)
    End Sub
    Private Sub btn_Zero5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero5.Click
        SetZero(4)
        txt_SensorTrim5.NumericValue = SensorTrim(4)
    End Sub
    Private Sub btn_Zero6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero6.Click
        SetZero(5)
        txt_SensorTrim6.NumericValue = SensorTrim(5)
    End Sub
    Private Sub btn_Zero7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero7.Click
        SetZero(6)
        txt_SensorTrim7.NumericValue = SensorTrim(6)
    End Sub
    Private Sub btn_Zero8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Zero8.Click
        SetZero(7)
        txt_SensorTrim8.NumericValue = SensorTrim(7)
    End Sub

    Private Sub SetZero(ByVal channel As Int32)
        SensorTrim(channel) = -MultipliedValue(channel)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' ----------------------------------------------------- Create and write log-line
        DataLogger_Tick
        ' ----------------------------------------------------- Show values to the user
        If WindowState = FormWindowState.Minimized Then Return
        lbl_Display.Text = LogLine
        txt_SlotDisplay1.Text = ConvertedValue(0).ToString("0.#####", GCI)
        txt_SlotDisplay2.Text = ConvertedValue(1).ToString("0.#####", GCI)
        txt_SlotDisplay3.Text = ConvertedValue(2).ToString("0.#####", GCI)
        txt_SlotDisplay4.Text = ConvertedValue(3).ToString("0.#####", GCI)
        txt_SlotDisplay5.Text = ConvertedValue(4).ToString("0.#####", GCI)
        txt_SlotDisplay6.Text = ConvertedValue(5).ToString("0.#####", GCI)
        txt_SlotDisplay7.Text = ConvertedValue(6).ToString("0.#####", GCI)
        txt_SlotDisplay8.Text = ConvertedValue(7).ToString("0.#####", GCI)
    End Sub

End Class
