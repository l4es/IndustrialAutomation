﻿Module Module_DataLogger

    Friend FieldSeparator As String = ";"
    Friend GCI As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture
    Friend FileName As String
    Friend Slot(7) As Int32
    Friend SensorType(7) As String
    Friend SensorTrim(7) As Single
    Friend SensorMultiplier(7) As Single
    Friend MultipliedValue(7) As Single
    Friend ConvertedValue(7) As Single
    Friend LogLine As String

    Friend Sub DataLogger_Tick()
        ' ----------------------------------------------------- Create log-line
        Dim d As Date = Date.Now
        LogLine = d.ToString("yyyy/MM/dd HH:mm:ss.fff", GCI)
        ' ----------------------------------------------------- OA date or Julian date
        'LogLine += FieldSeparator & DateToOADate(d)
        LogLine += FieldSeparator & DateToJulianDate(d)
        ' ----------------------------------------------------- log fields
        For i As Int32 = 0 To Slot.Length - 1
            If SensorType(i) <> "Unused" Then
                LogLine += FieldSeparator + ConvertSensorValue(i).ToString("0.000", GCI)
            End If
        Next
        ' ----------------------------------------------------- Write log-line to file
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(FileName, _
                                                         True, _
                                                         New System.Text.ASCIIEncoding())
        file.WriteLine(LogLine)
        file.Close()
    End Sub


    ' =======================================================================
    '  Date to OLE Automation date
    ' =======================================================================
    Public Function DateToOADate(ByVal dt As Date) As String
        Return dt.ToOADate.ToString("0.00000000", GCI)
    End Function

    ' =======================================================================
    '  Date to true Julian date
    ' =======================================================================
    '  OADate = number of days since midnight on the 31st December 1899
    '  Julian = number of days since midday on the 1st of January, 4713 BC
    '  2415018.5 = difference between the two dates
    ' =======================================================================
    Public Function DateToJulianDate(ByVal d As Date) As String
        Return (d.ToOADate + 2415018.5).ToString("0.00000000", GCI)
    End Function


    ' =======================================================================
    '  Convert sensor values
    ' =======================================================================
    Function ConvertSensorValue(ByVal SensorIndex As Int32) As Single
        ' 
        Dim r As Single
        Dim v As Single
        Dim i As Single
        '
        Select Case SensorType(SensorIndex)

            Case "Volt"
                ' ------------------------------------------- Volt from 0 to 3.3
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 3.3F / 1000 ' v = volts
                v = v * SensorMultiplier(SensorIndex)

            Case "Millivolt"
                ' ------------------------------------------- Millivolt from 0 to 3300
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 3.3F        ' v = millivolts
                v = v * SensorMultiplier(SensorIndex)

                ' ------------------------------------------- Resistance 3 wires
            Case "Res-3"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * (2.5F - 2.0F * v + i) / i
                v = r
                ' ------------------------------------------- Resistance 4 wires
            Case "Res-4"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * v / i
                v = r

                ' ------------------------------------------- °C with PT100 3 wires
            Case "PT100-3"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * (2.5F - 2.0F * v + i) / i
                v = TempFromPtRes(r, 100)
                ' ------------------------------------------- °C with PT100 4 wires
            Case "PT100-4"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * v / i
                v = TempFromPtRes(r, 100)

                ' ------------------------------------------- °C with PT500 3 wires
            Case "PT500-3"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * (2.5F - 2.0F * v + i) / i
                v = TempFromPtRes(r, 500)
                ' ------------------------------------------- °C with PT500 4 wires
            Case "PT500-4"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * v / i
                v = TempFromPtRes(r, 500)

                ' ------------------------------------------- °C with PT1000 3 wires
            Case "PT1000-3"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * (2.5F - 2.0F * v + i) / i
                v = TempFromPtRes(r, 1000)
                ' ------------------------------------------- °C with PT1000 4 wires
            Case "PT1000-4"
                v = Slots.ReadSlot(Slot(SensorIndex))
                i = Slots.ReadSlot(Slot(SensorIndex) + 1)
                r = SensorMultiplier(SensorIndex) * v / i
                v = TempFromPtRes(r, 1000)

            Case "LM35"
                ' ------------------------------------------- Temp. 0°C to 150°C +/-0.5°C
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 0.33F       ' v = millivolts/10
                v = v * SensorMultiplier(SensorIndex)

            Case "TSIC501"
                ' ------------------------------------------- Temp. -10°C to 60°C +/-0.2°C
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 3.3F / 1000 ' v = volts
                v = v * (60 + 10) - 10
                v = v * SensorMultiplier(SensorIndex)

            Case "UVM-30A"
                ' ------------------------------------------- UV Index (from 0 to 11) with UVM-30A module  
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 3.3F        ' v = millivolts
                If v < 227 Then
                    v = v / 227
                Else
                    v = 1 + 10 * (v - 227) / (1170 - 227)
                End If
                v = v * SensorMultiplier(SensorIndex)

            Case "ML8511"
                ' ------------------------------------------- UV from 0 a 15 mW/cmq with ML8511 module 
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * 3.3F / 1000 ' v = volts
                v = v - 1           ' subtract 1 Volt (see ML8511 datasheet) 
                v = v / 1.8F        ' normalize from 0 to 1 (range 1 Volt to 2.8 Volt) 
                v = v * 15          ' v = mW/cmq (from 0 to 15 mW/cmq)
                v = v * SensorMultiplier(SensorIndex)

            Case Else
                ' ------------------------------------------- Unconverted value
                v = Slots.ReadSlot(Slot(SensorIndex))
                v = v * SensorMultiplier(SensorIndex)
        End Select
        MultipliedValue(SensorIndex) = v
        ' --------------------------------------------------- Sensor Trim
        v = v + SensorTrim(SensorIndex)
        ' --------------------------------------------------- Value for labels
        ConvertedValue(SensorIndex) = v
        Return v
    End Function

    ' ==============================================================================
    '  Resistance to Temperature for Platinum RTD with Rational Polynomial Function
    '  https://en.wikipedia.org/wiki/Polynomial_and_rational_function_modeling
    '
    '  More info in the Theremino Adc24 Data-sheet: 
    '  http://www.theremino.com/wp-content/uploads/files/Theremino_ADC24_ITA.pdf
    '  
    '  Average absolute error 0.015°C over the PTxxx full range (-200 to +850°C)
    '  Valid for any PTxxx (PT100, PT500, PT1000 and so on)
    ' ==============================================================================
    Const c0 As Single = -245.19
    Const c1 As Single = 2.5293
    Const c2 As Single = -0.066046
    Const c3 As Single = 0.0040422
    Const c4 As Single = -0.0000020697
    Const c5 As Single = -0.025422
    Const c6 As Single = 0.0016883
    Const c7 As Single = -0.0000013601
    Private Function TempFromPtRes(ByVal R As Single, ByVal Rzero As Single) As Single
        R = R * 100 / Rzero
        Return c0 + R * (c1 + R * (c2 + R * (c3 + c4 * R))) / _
                         (1 + R * (c5 + R * (c6 + c7 * R)))
    End Function


End Module
