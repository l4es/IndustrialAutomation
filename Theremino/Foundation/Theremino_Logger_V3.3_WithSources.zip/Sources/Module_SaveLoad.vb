﻿
Module Module_SaveLoad

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   Files
    ' =======================================================================================================
    ' returns lower-case extension with initial dot
    Public Function GetExtension(ByVal str As String) As String
        On Error Resume Next
        Return LCase(IO.Path.GetExtension(str))
    End Function
    Public Function RemoveExtension(ByVal str As String) As String
        On Error Resume Next
        Return PlatformAdjustedFileName(IO.Path.GetDirectoryName(str) & "\" & IO.Path.GetFileNameWithoutExtension(str))
    End Function
    Public Function FileExists(ByVal fileName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(fileName)
    End Function
    Public Function FolderExists(ByVal FolderName As String) As Boolean
        If FolderName.Length < 2 Then Return False
        FolderName = LCase(FolderName)
        Select Case FolderName
            Case "a:\", "b:\", "c:\", "d:\", "e:\", "f:\", "g:\", "h:\", "i:\", "j:\", "k:\", "l:\", "m:\", "n:\", "o, ", "p:\", "q:\", "r:\", "s:\", "t:\", "u:\", "v:\", "z:\", "x:\", "y:\"
                Return True
        End Select
        Return My.Computer.FileSystem.DirectoryExists(FolderName)
    End Function

    ' =======================================================================================
    '  FORM FUNCTIONS
    ' =======================================================================================
    Friend Sub LimitFormPosition(ByVal f As System.Windows.Forms.Form)
        If f.WindowState <> FormWindowState.Normal Then Return
        GetMaxScreenBounds()
        EnsureFormVisible(f)
        'EnsureFormCompletelyVisible(f)
    End Sub

    Private SB As Rectangle = New Rectangle(Integer.MaxValue, Integer.MaxValue, Integer.MinValue, Integer.MinValue)

    Private Sub GetMaxScreenBounds()
        For Each s As Screen In System.Windows.Forms.Screen.AllScreens
            SB = Rectangle.Union(SB, s.WorkingArea)
        Next
    End Sub

    'Private Sub EnsureFormCompletelyVisible(ByVal frm As Form)
    '    With frm
    '        .Width = Math.Min(.Width, SB.Width)         ' not more than a maximized window
    '        .Height = Math.Min(.Height, SB.Height)      ' not more than a maximized window
    '        .Width = Math.Max(.Width, 32)               ' at least 32x24
    '        .Height = Math.Max(.Height, 24)             ' at least 32x24
    '        .Left = Math.Min(.Left, SB.Right - .Width)  ' not beyond the right border
    '        .Top = Math.Min(.Top, SB.Bottom - .Height)  ' not beyond the bottom border
    '        .Left = Math.Max(.Left, SB.Left)            ' at least at the left border
    '        .Top = Math.Max(.Top, SB.Top)               ' at least at the top border
    '    End With
    'End Sub

    Private Sub EnsureFormVisible(ByVal frm As Form)
        With frm
            .Width = Math.Min(.Width, SB.Width)             ' not more than VIRTUALSCREEN dimensions
            .Height = Math.Min(.Height, SB.Height)          ' not more than VIRTUALSCREEN dimensions 
            .Width = Math.Max(.Width, 32)                   ' at least 32x24
            .Height = Math.Max(.Height, 24)                 ' at least 32x24
            .Left = Math.Min(.Left, SB.Right - 50)          ' not beyond right border - 50 pixels
            .Top = Math.Min(.Top, SB.Bottom - 100)          ' not beyond bottom border - 50 pixels
            .Left = Math.Max(.Left, SB.Left + 100 - .Width) ' at least at left border + 50 pixels
            .Top = Math.Max(.Top, SB.Top - 10)              ' at least at top border
        End With
    End Sub

    ' (The value of the RestoreBounds property is valid only 
    '   when the WindowState property of the Form class is not equal to Normal)
    Friend Function GetFormRectangle(ByVal frm As Form) As Rectangle
        Dim r As Rectangle
        If frm.WindowState = FormWindowState.Normal Then
            r = frm.Bounds
        Else
            r = frm.RestoreBounds
        End If
        Return r
    End Function

    
    ' ================================================================================================
    '  Private Read-Write functions
    ' ================================================================================================
    Private Function TabString(ByVal Name As String, _
                              Optional ByVal Value As Double = Double.NaN, _
                              Optional ByVal fmt As String = "") As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)
        If Double.IsNaN(Value) Then
            Return Name
        Else
            Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString(fmt)
        End If
    End Function
    Private Function TabString(ByVal Name As String, _
                                  ByVal Value As Boolean) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value.ToString
    End Function
    Private Function TabString(ByVal Name As String, _
                                ByVal Value As String) As String

        Dim nTab As Int32 = Math.Max(0, 22 - Name.Length)

        Return Name & "=" & Strings.StrDup(nTab, " ") & Value
    End Function
    Private Function Val_Single(ByVal l As String) As Single
        Return CSng(Val(l.Replace(",", ".")))
    End Function
    Private Function Val_Double(ByVal l As String) As Double
        Return Val(l.Replace(",", "."))
    End Function
    Private Function Val_Int(ByVal l As String) As Int32
        Return CInt(Val(l))
    End Function
    Friend Function ExtractParamName(ByRef s As String) As String
        ' ------------------------- Returns the first field from begin to the first "=" symbol
        ' -------------------------  and removes it from the string
        Dim i As Integer
        i = InStr(s, "=")
        If i > 0 Then
            ExtractParamName = Trim(Strings.Left(s, i - 1))
            s = Trim(Mid(s, i + 1))
        Else
            ExtractParamName = Trim(s)
            s = ""
        End If
    End Function
    Private Function AssemblyName() As String
        Return System.Reflection.Assembly.GetExecutingAssembly.GetName.Name
    End Function


    ' ==================================================================================================
    '  SAVE LOAD -- Program INI
    ' ==================================================================================================
    Friend Sub Save_INI()
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        Dim f As System.IO.StreamWriter = Nothing
        Try
            f = IO.File.CreateText(iniFileName)
            '
            f.WriteLine("")
            f.WriteLine("===========================================")
            f.WriteLine(" Program Params")
            f.WriteLine("===========================================")
            ' ------------------------------------------------------------------------------ FORM 1
            Dim r As Rectangle
            r = GetFormRectangle(Form1)
            f.WriteLine(TabString("Form1_Top", r.Top))
            f.WriteLine(TabString("Form1_Left", r.Left))
            'f.WriteLine(TabString("Form1_Width", r.Width))
            'f.WriteLine(TabString("Form1_Height", r.Height))
            f.WriteLine(TabString("Form1_WindowState", Form1.WindowState))
            ' ------------------------------------------------------------------------------
            f.WriteLine("")
            f.WriteLine(TabString("Recording Interval", Form1.txt_RecInterval.NumericValue))
            f.WriteLine(TabString("NumSlot1", Form1.txt_NumSlot1.NumericValue))
            f.WriteLine(TabString("NumSlot2", Form1.txt_NumSlot2.NumericValue))
            f.WriteLine(TabString("NumSlot3", Form1.txt_NumSlot3.NumericValue))
            f.WriteLine(TabString("NumSlot4", Form1.txt_NumSlot4.NumericValue))
            f.WriteLine(TabString("NumSlot5", Form1.txt_NumSlot5.NumericValue))
            f.WriteLine(TabString("NumSlot6", Form1.txt_NumSlot6.NumericValue))
            f.WriteLine(TabString("NumSlot7", Form1.txt_NumSlot7.NumericValue))
            f.WriteLine(TabString("NumSlot8", Form1.txt_NumSlot8.NumericValue))

            f.WriteLine(TabString("Type1", Form1.cmb_Type1.Text))
            f.WriteLine(TabString("Type2", Form1.cmb_Type2.Text))
            f.WriteLine(TabString("Type3", Form1.cmb_Type3.Text))
            f.WriteLine(TabString("Type4", Form1.cmb_Type4.Text))
            f.WriteLine(TabString("Type5", Form1.cmb_Type5.Text))
            f.WriteLine(TabString("Type6", Form1.cmb_Type6.Text))
            f.WriteLine(TabString("Type7", Form1.cmb_Type7.Text))
            f.WriteLine(TabString("Type8", Form1.cmb_Type8.Text))

            f.WriteLine(TabString("SensorMult1", Form1.txt_SensorMult1.NumericValue))
            f.WriteLine(TabString("SensorMult2", Form1.txt_SensorMult2.NumericValue))
            f.WriteLine(TabString("SensorMult3", Form1.txt_SensorMult3.NumericValue))
            f.WriteLine(TabString("SensorMult4", Form1.txt_SensorMult4.NumericValue))
            f.WriteLine(TabString("SensorMult5", Form1.txt_SensorMult5.NumericValue))
            f.WriteLine(TabString("SensorMult6", Form1.txt_SensorMult6.NumericValue))
            f.WriteLine(TabString("SensorMult7", Form1.txt_SensorMult7.NumericValue))
            f.WriteLine(TabString("SensorMult8", Form1.txt_SensorMult8.NumericValue))

            f.WriteLine(TabString("SensorTrim1", Form1.txt_SensorTrim1.NumericValue))
            f.WriteLine(TabString("SensorTrim2", Form1.txt_SensorTrim2.NumericValue))
            f.WriteLine(TabString("SensorTrim3", Form1.txt_SensorTrim3.NumericValue))
            f.WriteLine(TabString("SensorTrim4", Form1.txt_SensorTrim4.NumericValue))
            f.WriteLine(TabString("SensorTrim5", Form1.txt_SensorTrim5.NumericValue))
            f.WriteLine(TabString("SensorTrim6", Form1.txt_SensorTrim6.NumericValue))
            f.WriteLine(TabString("SensorTrim7", Form1.txt_SensorTrim7.NumericValue))
            f.WriteLine(TabString("SensorTrim8", Form1.txt_SensorTrim8.NumericValue))
        Catch
        End Try
        Try
            f.Close()
        Catch
        End Try
    End Sub

    Friend Sub Load_INI()
        ' ------------------------------------------------------------------------------- defaults
        'InitChannelsDefaults()
        ' -------------------------------------------------------------------------------
        ' ------------------------------------------------------------------------------- 
        ' With "Resume Next" subsequent parameters are loaded and f.Close() is executed
        ' -------------------------------------------------------------------------------
        On Error Resume Next  ' use Resume-Next instead of Try-Catch
        ' -------------------------------------------------------------------------------
        Dim l As String
        Dim iniFileName As String = PlatformAdjustedFileName(Application.StartupPath & "\" & AssemblyName() & "_INI.txt")
        If My.Computer.FileSystem.FileExists(iniFileName) Then
            '
            Dim f As System.IO.StreamReader
            f = IO.File.OpenText(iniFileName)
            '
            Dim ch As Int32 = 0
            Do While Not f.EndOfStream
                l = f.ReadLine()
                Select Case ExtractParamName(l)
                    Case "Form1_Top" : Form1.Top = Val_Int(l)
                    Case "Form1_Left" : Form1.Left = Val_Int(l)
                        'Case "Form1_Width" : Form1.Width = Val_Int(l)
                        'Case "Form1_Height" : Form1.Height = Val_Int(l)
                    Case "Form1_WindowState" : Form1.WindowState = CType(Val(l), FormWindowState) : Form1.Refresh()

                    Case "Recording Interval" : Form1.txt_RecInterval.NumericValue = Val_Single(l)
                    Case "NumSlot1" : Form1.txt_NumSlot1.NumericValue = Val_Single(l)
                    Case "NumSlot2" : Form1.txt_NumSlot2.NumericValue = Val_Single(l)
                    Case "NumSlot3" : Form1.txt_NumSlot3.NumericValue = Val_Single(l)
                    Case "NumSlot4" : Form1.txt_NumSlot4.NumericValue = Val_Single(l)
                    Case "NumSlot5" : Form1.txt_NumSlot5.NumericValue = Val_Single(l)
                    Case "NumSlot6" : Form1.txt_NumSlot6.NumericValue = Val_Single(l)
                    Case "NumSlot7" : Form1.txt_NumSlot7.NumericValue = Val_Single(l)
                    Case "NumSlot8" : Form1.txt_NumSlot8.NumericValue = Val_Single(l)

                    Case "Type1" : Form1.cmb_Type1.SelectedItem = l
                    Case "Type2" : Form1.cmb_Type2.SelectedItem = l
                    Case "Type3" : Form1.cmb_Type3.SelectedItem = l
                    Case "Type4" : Form1.cmb_Type4.SelectedItem = l
                    Case "Type5" : Form1.cmb_Type5.SelectedItem = l
                    Case "Type6" : Form1.cmb_Type6.SelectedItem = l
                    Case "Type7" : Form1.cmb_Type7.SelectedItem = l
                    Case "Type8" : Form1.cmb_Type8.SelectedItem = l

                    Case "SensorMult1" : Form1.txt_SensorMult1.NumericValue = Val_Single(l)
                    Case "SensorMult2" : Form1.txt_SensorMult2.NumericValue = Val_Single(l)
                    Case "SensorMult3" : Form1.txt_SensorMult3.NumericValue = Val_Single(l)
                    Case "SensorMult4" : Form1.txt_SensorMult4.NumericValue = Val_Single(l)
                    Case "SensorMult5" : Form1.txt_SensorMult5.NumericValue = Val_Single(l)
                    Case "SensorMult6" : Form1.txt_SensorMult6.NumericValue = Val_Single(l)
                    Case "SensorMult7" : Form1.txt_SensorMult7.NumericValue = Val_Single(l)
                    Case "SensorMult8" : Form1.txt_SensorMult8.NumericValue = Val_Single(l)

                    Case "SensorTrim1" : Form1.txt_SensorTrim1.NumericValue = Val_Single(l)
                    Case "SensorTrim2" : Form1.txt_SensorTrim2.NumericValue = Val_Single(l)
                    Case "SensorTrim3" : Form1.txt_SensorTrim3.NumericValue = Val_Single(l)
                    Case "SensorTrim4" : Form1.txt_SensorTrim4.NumericValue = Val_Single(l)
                    Case "SensorTrim5" : Form1.txt_SensorTrim5.NumericValue = Val_Single(l)
                    Case "SensorTrim6" : Form1.txt_SensorTrim6.NumericValue = Val_Single(l)
                    Case "SensorTrim7" : Form1.txt_SensorTrim7.NumericValue = Val_Single(l)
                    Case "SensorTrim8" : Form1.txt_SensorTrim8.NumericValue = Val_Single(l)
                End Select
            Loop
            f.Close()
        End If
        '
        LimitFormPosition(Form1)
    End Sub

End Module
