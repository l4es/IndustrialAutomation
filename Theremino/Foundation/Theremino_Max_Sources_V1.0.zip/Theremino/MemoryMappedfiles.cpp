
#include "stdafx.h"
#include "MemoryMappedFiles.h"

// ======================================================================================
//   CLASS MemoryMappedFile
// ======================================================================================

	MemoryMappedFile::MemoryMappedFile(LPCWSTR Filename, __int32 Length)
	{
		FileLength = 0;

		FileHandle = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, Length, Filename);
		if (FileHandle == 0)
		{
			//MessageBox.Show("Unable to create the MemoryMappedFile: " + Filename, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			Destroy();
			return;
		}

		MappingAddress = MapViewOfFile(FileHandle, FILE_MAP_ALL_ACCESS, 0, 0, 0);

		if (MappingAddress == NULL)
		{
			//MessageBox.Show("Unable to map the MemoryMappedFile: " + Filename, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			Destroy();
			return;
		}

		FileLength = Length;
		functionReturnValue = new char[FileLength];
	}


	MemoryMappedFile::~MemoryMappedFile()
	{
		Destroy();
	}


	void MemoryMappedFile::Destroy()
	{
		if (MappingAddress != NULL)
		{
			UnmapViewOfFile(MappingAddress);
		}
		if (FileHandle != 0)
		{
			CloseHandle(FileHandle);
			FileHandle = 0;
		}
		FileLength = 0;
		if (functionReturnValue) delete[] functionReturnValue;
	}


	// ======================================================================================
	//  PUBLIC FUNCTIONS
	// ======================================================================================

	// ---------------------------------------------------------------- String
	void MemoryMappedFile::WriteString(__int32 Offset, LPSTR Text)
	{
		if (MappingAddress == NULL) return;
		if (Offset < 0 || Offset + (int)strlen(Text) >= FileLength) return;
		Text += '\0';
		for (__int32 i = 0; i <= (__int32)(strlen(Text) - 1); i++)
		{
			*((BYTE *)MappingAddress + i + Offset) = (BYTE)Text[i];
		}
	}

	LPSTR MemoryMappedFile::ReadString(__int32 Offset)
	{
		if (MappingAddress == NULL) return "";
		if (Offset < 0 || Offset >= FileLength) return "";

		BYTE b = 0;
		for (__int32 i = 0; i <= FileLength - 1; i++)
		{
			b = *((BYTE *)MappingAddress + i + Offset);
			char c = b;
			functionReturnValue[i] = c;
			if (b == 0) break;
		}

		return functionReturnValue;
	}


	// ---------------------------------------------------------------- Int32
	void MemoryMappedFile::WriteInt32(__int32 Offset, __int32 Value)
	{
		if (MappingAddress == NULL) return;
		if (Offset < 0 || Offset >= FileLength) return;
		*((__int32 *)((int)MappingAddress + Offset)) = Value;
	}

	__int32 MemoryMappedFile::ReadInt32(__int32 Offset)
	{
		if (MappingAddress == NULL) return 0;
		if (Offset < 0 || Offset >= FileLength) return 0;
		return *((__int32 *)((int)MappingAddress + Offset));
	}


	// ---------------------------------------------------------------- Single
	void MemoryMappedFile::WriteSingle(__int32 Offset, float Value)
	{
		if (MappingAddress == NULL) return;
		if (Offset < 0 || Offset >= FileLength) return;
		__int32 i = *((__int32 *)&Value);
		*((__int32 *)((int)MappingAddress + Offset)) = i;
	}

	float MemoryMappedFile::ReadSingle(__int32 Offset)
	{
		if (MappingAddress == NULL) return 0;
		if (Offset < 0 || Offset >= FileLength) return 0;
		__int32 i = *((__int32 *)((int)MappingAddress + Offset));
		return *((float *)&i);
	}

