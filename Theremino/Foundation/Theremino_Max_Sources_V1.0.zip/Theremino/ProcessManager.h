
#pragma warning(disable : 4996)

#include <Shellapi.h>
#include <shlobj.h>
#include <psapi.h>
// To ensure correct resolution of symbols, add Psapi.lib to TARGETLIBS and compile with -DPSAPI_VERSION=1


short TestProcessName(DWORD processID, TCHAR* name)
{
    TCHAR szProcessName[MAX_PATH] = TEXT("");

    // ------------------------------------------------------------------- Get a handle to the process.
    HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
                                   PROCESS_VM_READ,
                                   FALSE, processID );

    // ------------------------------------------------------------------- Get the process name.
    if (NULL != hProcess )
    {
        HMODULE hMod;
        DWORD cbNeeded;

        if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), &cbNeeded) )
        {
            GetModuleBaseName( hProcess, hMod, szProcessName, 
                               sizeof(szProcessName)/sizeof(TCHAR) );
        }
    }

    // ------------------------------------------------------------------ Release the handle to the process.
    CloseHandle( hProcess );

	// ------------------------------------------------------------------ Print the process name and identifier.
    if (wcscmp(szProcessName, name) == 0)
		return true;
	else
		return false;
}




