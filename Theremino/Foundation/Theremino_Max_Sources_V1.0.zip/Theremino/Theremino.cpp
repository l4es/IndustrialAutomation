
// Theremino.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Theremino.h"


// This is the constructor of a class that has been exported.
// see Theremino.h for the class definition
//CTheremino::CTheremino()
//{
//	return;
//}



#include "ext.h"
#include "ext_obex.h"
#include "MemoryMappedFiles.h"
#include "ProcessManager.h"



typedef struct theremino
{
	struct	object m_ob;
	// ------------------------------
	__int32 m_BaseAddr;
	__int32 m_BasePinNumber;
	__int32 m_PinCount;
	void*	m_out[8];
} 
t_theremino;


// ----------------------------------------------------------------------------
void *theremino_class = NULL;
MemoryMappedFile *MMF1 = new MemoryMappedFile(L"Theremino1", 4080);


// ----------------------------------------------------------------------------
void theremino_bang(t_theremino *x);
//
void theremino_int(t_theremino *x, __int32 n);
void theremino_in1(t_theremino *x, __int32 n);
void theremino_in2(t_theremino *x, __int32 n);
void theremino_in3(t_theremino *x, __int32 n);
void theremino_in4(t_theremino *x, __int32 n);
void theremino_in5(t_theremino *x, __int32 n);
void theremino_in6(t_theremino *x, __int32 n);
void theremino_in7(t_theremino *x, __int32 n);
//
void theremino_float(t_theremino *x, double n);
void theremino_ft1(t_theremino *x, double n);
void theremino_ft2(t_theremino *x, double n);
void theremino_ft3(t_theremino *x, double n);
void theremino_ft4(t_theremino *x, double n);
void theremino_ft5(t_theremino *x, double n);
void theremino_ft6(t_theremino *x, double n);
void theremino_ft7(t_theremino *x, double n);
//
void theremino_assist(t_theremino *x, void *b, __int32 m, __int32 a, char *s);
void *theremino_new(t_symbol *s, short ac, t_atom *av);
void theremino_free(t_theremino *x);



THEREMINO_API int main()
{
	if (theremino_class == NULL)
	{
		t_class *c;
		c = class_new("theremino", (method)theremino_new, (method)theremino_free, (short)sizeof(t_theremino), 0L, A_GIMME, 0);
		
		// --------------------------------------------------------------- using "class_addmethod"
		class_addmethod(c, (method)theremino_bang, "bang", 0);
		
		class_addmethod(c, (method)theremino_int, "int");
		class_addmethod(c, (method)theremino_in1, "in1", A_LONG, 0);
		class_addmethod(c, (method)theremino_in2, "in2", A_LONG, 0);
		class_addmethod(c, (method)theremino_in3, "in3", A_LONG, 0);
		class_addmethod(c, (method)theremino_in4, "in4", A_LONG, 0);
		class_addmethod(c, (method)theremino_in5, "in5", A_LONG, 0);
		class_addmethod(c, (method)theremino_in6, "in6", A_LONG, 0);
		class_addmethod(c, (method)theremino_in7, "in7", A_LONG, 0);

		class_addmethod(c, (method)theremino_float, "float");
		class_addmethod(c, (method)theremino_ft1, "ft1", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft2, "ft2", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft3, "ft3", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft4, "ft4", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft5, "ft5", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft6, "ft6", A_FLOAT, 0);
		class_addmethod(c, (method)theremino_ft7, "ft7", A_FLOAT, 0);

		class_addmethod(c, (method)theremino_assist,"assist", A_CANT,0);


		// --------------------------------------------------------------- not using "class_addmethod" 
		//																   ( runtime errors ft1 to ft7 )
		//addbang((method)theremino_bang);

		//addint((method)theremino_int);
		//addinx((method)theremino_in1, 1);
		//addinx((method)theremino_in2, 2);
		//addinx((method)theremino_in3, 3);
		//addinx((method)theremino_in4, 4);
		//addinx((method)theremino_in5, 5);
		//addinx((method)theremino_in6, 6);
		//addinx((method)theremino_in7, 7);

		//addfloat((method)theremino_float);
		//addftx((method)theremino_ft1, 1);
		//addftx((method)theremino_ft2, 2);
		//addftx((method)theremino_ft3, 3);
		//addftx((method)theremino_ft4, 4);
		//addftx((method)theremino_ft5, 5);
		//addftx((method)theremino_ft6, 6);
		//addftx((method)theremino_ft7, 7);

		//addmess((method)theremino_assist, "assist", A_CANT, 0);



		class_register(CLASS_BOX, c);
		theremino_class = c;
	}
	return 0;
}


// ====================================================================================
//  OUTLETS ( from THEREMINO HARDWARE )
// ====================================================================================

void theremino_bang(t_theremino *x)
{
	for (__int32 i = 0; i < 8; i++)
	{
		if (x->m_out[i])
		{
			outlet_float(x->m_out[i], MMF1->ReadSingle(x->m_BaseAddr + i*4));
		}
	}
}



// ====================================================================================
//  INLETS ( MAX to THEREMINO HARDWARE )
// ====================================================================================

// -------------------------------------------------------------- INT
void theremino_int(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 0, n);
	//MessageBeep(0);
}
void theremino_in1(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 4, n);
}
void theremino_in2(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 8, n);
}
void theremino_in3(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 12, n);
}
void theremino_in4(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 16, n);
}
void theremino_in5(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 20, n);
}
void theremino_in6(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 24, n);
}
void theremino_in7(t_theremino *x, __int32 n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 28, n);
}


// --------------------------------------------------------- FLOAT
void theremino_float(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 0, (float)n);
	//MMF1->WriteInt32(x->m_BaseAddr + 0, (__int32)n);
}
void theremino_ft1(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 4, (float)n);
}
void theremino_ft2(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 8, (float)n);
}
void theremino_ft3(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 12, (float)n);
}
void theremino_ft4(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 16, (float)n);
}
void theremino_ft5(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 20, (float)n);
}
void theremino_ft6(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 24, (float)n);
}
void theremino_ft7(t_theremino *x, double n)
{
	MMF1->WriteSingle(x->m_BaseAddr + 28, (float)n);
}




void theremino_assist(t_theremino *x, void *b, __int32 m, __int32 a, char *s)
{
	if (m == ASSIST_INLET)
	{
		switch (a) 
		{	
			case 0:
				if (x->m_PinCount < 1)
					strcpy(s, "Urecognized params! Please test syntax and pin numbers.");
				else if (x->m_out[0])
					// If this is a Theremino-Get ( with Outlets ) then the first Inlet is the Bang input
					strcpy(s, "Bang input\n ( read Outlet values\n from Theremino hardware )");
				else
					strcpy(s, "Inlet 0\n ( from Max to Theremino hardware )");
				break;
			case 1:
				strcpy(s, "Inlet 1\n ( from Max to Theremino hardware )");
				break;
			case 2:
				strcpy(s, "Inlet 2\n ( from Max to Theremino hardware )");
				break;
			case 3:
				strcpy(s, "Inlet 3\n ( from Max to Theremino hardware )");
				break;
			case 4:
				strcpy(s, "Inlet 4\n ( from Max to Theremino hardware )");
				break;
			case 5:
				strcpy(s, "Inlet 5\n ( from Max to Theremino hardware )");
				break;
			case 6:
				strcpy(s, "Inlet 6\n ( from Max to Theremino hardware )");
				break;
			case 7:
				strcpy(s, "Inlet 7\n ( from Max to Theremino hardware )");
				break;
		}
	}
	else if (m == ASSIST_OUTLET)
	{
		switch (a) 
		{	
			case 0:
				strcpy(s, "Outlet 0\n ( from Theremino hardware to Max )");
				break;
			case 1:
				strcpy(s, "Outlet 1\n ( from Theremino hardware to Max )");
				break;
			case 2:
				strcpy(s, "Outlet 2\n ( from Theremino hardware to Max )");
				break;
			case 3:
				strcpy(s, "Outlet 3\n ( from Theremino hardware to Max )");
				break;
			case 4:
				strcpy(s, "Outlet 4\n ( from Theremino hardware to Max )");
				break;
			case 5:
				strcpy(s, "Outlet 5\n ( from Theremino hardware to Max )");
				break;
			case 6:
				strcpy(s, "Outlet 6\n ( from Theremino hardware to Max )");
				break;
			case 7:
				strcpy(s, "Outlet 7\n ( from Theremino hardware to Max )");
				break;
		}
	}
}




// Syntax					argc	argv	argv+1	argv+2	Meaning
// -------------------------------------------------------------------------------------------- implicit get
// "theremino"				0								get pin 0
// "theremino 0"			1		0						get pin 0
// "theremino 24"			1		24						get pin 24
// "theremino 24 31"		2		24		8				get pins 24 to 31 ( max 8 pins )
// -------------------------------------------------------------------------------------------- explicit get
// "theremino get"			1		get						get pin 0
// "theremino get 0"		2		get		0				get pin 0
// "theremino get 24"		2		get		24				get pin 24
// "theremino get 24 31"	3		get		24		8		get pins 24 to 31 ( max 8 pins )
// -------------------------------------------------------------------------------------------- set
// "theremino set"			1		set						set pin 0
// "theremino set 0"		2		set		0				set pin 0
// "theremino set 24"		2		set		24				set pin 24
// "theremino set 24 31"	3		set		24		8		set pins 24 to 31 ( max 8 pins )

// Each "theremino" block can access a maximum of "8 get pins" or "8 set pins"
// Valid pin numbers are: 0 to 999
// If pin numbers are invalid or there are syntax errors a default "theremino" ( get pin 0 ) is created. 
// Theremino pins are mapped to the input-output hardware only if theremino modules are connected to the USB
// Writing to a 'hardware-input-pin' does nothing ( changes a memory cell that is immediately restored by the hardware )
// Reading from a 'hardware-output-pin' can be used to re-read the actual output value.
// Writing and Reading pins not mapped with the hardware can be used for learning and tests without the hardware.
// Pins not connected with the hardware can also be used for inter-Pat and inter-Process communications.

void *theremino_new(t_symbol *s, short argc, t_atom *argv)
{
	t_theremino *x;
	x = (t_theremino *)object_alloc((t_class *)theremino_class);

	x->m_BasePinNumber	= 0;
	x->m_PinCount		= 1;

	short	isSet		= false;
	__int32 ArgCounter	= 0;

	if (argc)
	{
		// --------------------------------------------------------------------- test for "set" and "get"
		if ( strcmp(strlwr(atom_getsym(argv)->s_name), "set") == 0 )
		{
			isSet = true;
			ArgCounter++;
		}
		else if ( strcmp(strlwr(atom_getsym(argv)->s_name), "get") == 0 )
		{
			ArgCounter++;
		}

		// --------------------------------------------------------------------- read params
		if (argc >= ArgCounter + 1)
		{
			x->m_BasePinNumber = atom_getlong(argv + ArgCounter);
			if ((argv + ArgCounter)->a_type != A_LONG)
			{
				x->m_BasePinNumber = -1;
			}
		}
		if (argc == ArgCounter + 2)
		{
			x->m_PinCount = atom_getlong(argv + ArgCounter + 1);
		}
		
		// --------------------------------------------------------------------- test syntax and pin numbers
		if (x->m_BasePinNumber < 0 ||
			x->m_BasePinNumber + x->m_PinCount > 1000 ||
			x->m_PinCount < 1 || 
			x->m_PinCount > 8)
		{
			isSet = true;
			x->m_BasePinNumber = 0;
			x->m_PinCount = 0;
		}
	}

	// ------------------------------------------------------------------------- calc the byte aligned Base address
	x->m_BaseAddr = 4 * x->m_BasePinNumber;


	// ------------------------------------------------------------------------- set = Inlets = MAX to Theremino
	if (isSet)
	{
		for (__int32 i = x->m_PinCount - 1; i >= 1; i--)
		{
			floatin(x, i);
		}
	}
	else 
	// ------------------------------------------------------------------------- get = Outlets = Theremino to MAX
	{
		for (__int32 i = x->m_PinCount - 1; i >= 0; i--)
		{
			x->m_out[i] = floatout(x);
		}
	}

	return x;
}


void theremino_free(t_theremino *x)
{
}









