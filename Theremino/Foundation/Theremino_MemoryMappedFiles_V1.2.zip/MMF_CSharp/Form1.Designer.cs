﻿namespace MMF_CSHARP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Offset = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.lbl_Time = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.txt_DoubleArray2 = new System.Windows.Forms.TextBox();
            this.txt_SingleArray2 = new System.Windows.Forms.TextBox();
            this.txt_IntArray2 = new System.Windows.Forms.TextBox();
            this.txt_DoubleArray1 = new System.Windows.Forms.TextBox();
            this.txt_SingleArray1 = new System.Windows.Forms.TextBox();
            this.txt_IntArray1 = new System.Windows.Forms.TextBox();
            this.txt_DoubleArray0 = new System.Windows.Forms.TextBox();
            this.GetDoubleArray = new System.Windows.Forms.Button();
            this.SetDoubleArray = new System.Windows.Forms.Button();
            this.txt_SingleArray0 = new System.Windows.Forms.TextBox();
            this.GetSingleArray = new System.Windows.Forms.Button();
            this.SetSingleArray = new System.Windows.Forms.Button();
            this.txt_IntArray0 = new System.Windows.Forms.TextBox();
            this.GetInt32Array = new System.Windows.Forms.Button();
            this.SetInt32Array = new System.Windows.Forms.Button();
            this.Label6 = new System.Windows.Forms.Label();
            this.txt_double = new System.Windows.Forms.TextBox();
            this.GetDouble = new System.Windows.Forms.Button();
            this.SetDouble = new System.Windows.Forms.Button();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.txt_single = new System.Windows.Forms.TextBox();
            this.GetSingle = new System.Windows.Forms.Button();
            this.SetSingle = new System.Windows.Forms.Button();
            this.Label3 = new System.Windows.Forms.Label();
            this.txt_int32 = new System.Windows.Forms.TextBox();
            this.GetInt32 = new System.Windows.Forms.Button();
            this.SetInt32 = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txt_string = new System.Windows.Forms.TextBox();
            this.txt_Filename = new System.Windows.Forms.TextBox();
            this.GetString = new System.Windows.Forms.Button();
            this.SetString = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Offset
            // 
            this.txt_Offset.Location = new System.Drawing.Point(212, 14);
            this.txt_Offset.Name = "txt_Offset";
            this.txt_Offset.Size = new System.Drawing.Size(50, 20);
            this.txt_Offset.TabIndex = 103;
            this.txt_Offset.Text = "0";
            this.txt_Offset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(173, 18);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(35, 13);
            this.Label7.TabIndex = 102;
            this.Label7.Text = "Offset";
            // 
            // lbl_Time
            // 
            this.lbl_Time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time.Location = new System.Drawing.Point(326, 15);
            this.lbl_Time.Name = "lbl_Time";
            this.lbl_Time.Size = new System.Drawing.Size(37, 18);
            this.lbl_Time.TabIndex = 101;
            this.lbl_Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(269, 18);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(58, 13);
            this.Label5.TabIndex = 100;
            this.Label5.Text = "Time ( uS )";
            // 
            // txt_DoubleArray2
            // 
            this.txt_DoubleArray2.Location = new System.Drawing.Point(164, 236);
            this.txt_DoubleArray2.Name = "txt_DoubleArray2";
            this.txt_DoubleArray2.Size = new System.Drawing.Size(46, 20);
            this.txt_DoubleArray2.TabIndex = 99;
            // 
            // txt_SingleArray2
            // 
            this.txt_SingleArray2.Location = new System.Drawing.Point(164, 209);
            this.txt_SingleArray2.Name = "txt_SingleArray2";
            this.txt_SingleArray2.Size = new System.Drawing.Size(46, 20);
            this.txt_SingleArray2.TabIndex = 98;
            // 
            // txt_IntArray2
            // 
            this.txt_IntArray2.Location = new System.Drawing.Point(164, 182);
            this.txt_IntArray2.Name = "txt_IntArray2";
            this.txt_IntArray2.Size = new System.Drawing.Size(46, 20);
            this.txt_IntArray2.TabIndex = 97;
            // 
            // txt_DoubleArray1
            // 
            this.txt_DoubleArray1.Location = new System.Drawing.Point(115, 236);
            this.txt_DoubleArray1.Name = "txt_DoubleArray1";
            this.txt_DoubleArray1.Size = new System.Drawing.Size(46, 20);
            this.txt_DoubleArray1.TabIndex = 96;
            // 
            // txt_SingleArray1
            // 
            this.txt_SingleArray1.Location = new System.Drawing.Point(115, 209);
            this.txt_SingleArray1.Name = "txt_SingleArray1";
            this.txt_SingleArray1.Size = new System.Drawing.Size(46, 20);
            this.txt_SingleArray1.TabIndex = 95;
            // 
            // txt_IntArray1
            // 
            this.txt_IntArray1.Location = new System.Drawing.Point(115, 182);
            this.txt_IntArray1.Name = "txt_IntArray1";
            this.txt_IntArray1.Size = new System.Drawing.Size(46, 20);
            this.txt_IntArray1.TabIndex = 94;
            // 
            // txt_DoubleArray0
            // 
            this.txt_DoubleArray0.Location = new System.Drawing.Point(65, 236);
            this.txt_DoubleArray0.Name = "txt_DoubleArray0";
            this.txt_DoubleArray0.Size = new System.Drawing.Size(46, 20);
            this.txt_DoubleArray0.TabIndex = 92;
            // 
            // GetDoubleArray
            // 
            this.GetDoubleArray.Location = new System.Drawing.Point(292, 234);
            this.GetDoubleArray.Name = "GetDoubleArray";
            this.GetDoubleArray.Size = new System.Drawing.Size(70, 23);
            this.GetDoubleArray.TabIndex = 90;
            this.GetDoubleArray.Text = "Get";
            this.GetDoubleArray.UseVisualStyleBackColor = true;
            this.GetDoubleArray.Click += new System.EventHandler(this.GetDoubleArray_Click);
            // 
            // SetDoubleArray
            // 
            this.SetDoubleArray.Location = new System.Drawing.Point(219, 234);
            this.SetDoubleArray.Name = "SetDoubleArray";
            this.SetDoubleArray.Size = new System.Drawing.Size(70, 23);
            this.SetDoubleArray.TabIndex = 91;
            this.SetDoubleArray.Text = "Set";
            this.SetDoubleArray.UseVisualStyleBackColor = true;
            this.SetDoubleArray.Click += new System.EventHandler(this.SetDoubleArray_Click);
            // 
            // txt_SingleArray0
            // 
            this.txt_SingleArray0.Location = new System.Drawing.Point(65, 209);
            this.txt_SingleArray0.Name = "txt_SingleArray0";
            this.txt_SingleArray0.Size = new System.Drawing.Size(46, 20);
            this.txt_SingleArray0.TabIndex = 88;
            // 
            // GetSingleArray
            // 
            this.GetSingleArray.Location = new System.Drawing.Point(292, 207);
            this.GetSingleArray.Name = "GetSingleArray";
            this.GetSingleArray.Size = new System.Drawing.Size(70, 23);
            this.GetSingleArray.TabIndex = 86;
            this.GetSingleArray.Text = "Get";
            this.GetSingleArray.UseVisualStyleBackColor = true;
            this.GetSingleArray.Click += new System.EventHandler(this.GetSingleArray_Click);
            // 
            // SetSingleArray
            // 
            this.SetSingleArray.Location = new System.Drawing.Point(219, 207);
            this.SetSingleArray.Name = "SetSingleArray";
            this.SetSingleArray.Size = new System.Drawing.Size(70, 23);
            this.SetSingleArray.TabIndex = 87;
            this.SetSingleArray.Text = "Set";
            this.SetSingleArray.UseVisualStyleBackColor = true;
            this.SetSingleArray.Click += new System.EventHandler(this.SetSingleArray_Click);
            // 
            // txt_IntArray0
            // 
            this.txt_IntArray0.Location = new System.Drawing.Point(65, 182);
            this.txt_IntArray0.Name = "txt_IntArray0";
            this.txt_IntArray0.Size = new System.Drawing.Size(46, 20);
            this.txt_IntArray0.TabIndex = 84;
            // 
            // GetInt32Array
            // 
            this.GetInt32Array.Location = new System.Drawing.Point(292, 180);
            this.GetInt32Array.Name = "GetInt32Array";
            this.GetInt32Array.Size = new System.Drawing.Size(70, 23);
            this.GetInt32Array.TabIndex = 82;
            this.GetInt32Array.Text = "Get";
            this.GetInt32Array.UseVisualStyleBackColor = true;
            this.GetInt32Array.Click += new System.EventHandler(this.GetInt32Array_Click);
            // 
            // SetInt32Array
            // 
            this.SetInt32Array.Location = new System.Drawing.Point(219, 180);
            this.SetInt32Array.Name = "SetInt32Array";
            this.SetInt32Array.Size = new System.Drawing.Size(70, 23);
            this.SetInt32Array.TabIndex = 83;
            this.SetInt32Array.Text = "Set";
            this.SetInt32Array.UseVisualStyleBackColor = true;
            this.SetInt32Array.Click += new System.EventHandler(this.SetInt32Array_Click);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(8, 147);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(41, 13);
            this.Label6.TabIndex = 81;
            this.Label6.Text = "Double";
            // 
            // txt_double
            // 
            this.txt_double.Location = new System.Drawing.Point(59, 144);
            this.txt_double.Name = "txt_double";
            this.txt_double.Size = new System.Drawing.Size(153, 20);
            this.txt_double.TabIndex = 80;
            // 
            // GetDouble
            // 
            this.GetDouble.Location = new System.Drawing.Point(292, 142);
            this.GetDouble.Name = "GetDouble";
            this.GetDouble.Size = new System.Drawing.Size(70, 23);
            this.GetDouble.TabIndex = 78;
            this.GetDouble.Text = "Get";
            this.GetDouble.UseVisualStyleBackColor = true;
            this.GetDouble.Click += new System.EventHandler(this.GetDouble_Click);
            // 
            // SetDouble
            // 
            this.SetDouble.Location = new System.Drawing.Point(219, 142);
            this.SetDouble.Name = "SetDouble";
            this.SetDouble.Size = new System.Drawing.Size(70, 23);
            this.SetDouble.TabIndex = 79;
            this.SetDouble.Text = "Set";
            this.SetDouble.UseVisualStyleBackColor = true;
            this.SetDouble.Click += new System.EventHandler(this.SetDouble_Click);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(8, 239);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(53, 13);
            this.Label8.TabIndex = 93;
            this.Label8.Text = "Double ( )";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(8, 212);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(48, 13);
            this.Label9.TabIndex = 89;
            this.Label9.Text = "Single ( )";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(8, 185);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(43, 13);
            this.Label10.TabIndex = 85;
            this.Label10.Text = "Int32 ( )";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(7, 118);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(36, 13);
            this.Label4.TabIndex = 77;
            this.Label4.Text = "Single";
            // 
            // txt_single
            // 
            this.txt_single.Location = new System.Drawing.Point(59, 115);
            this.txt_single.Name = "txt_single";
            this.txt_single.Size = new System.Drawing.Size(153, 20);
            this.txt_single.TabIndex = 76;
            // 
            // GetSingle
            // 
            this.GetSingle.Location = new System.Drawing.Point(293, 115);
            this.GetSingle.Name = "GetSingle";
            this.GetSingle.Size = new System.Drawing.Size(70, 23);
            this.GetSingle.TabIndex = 74;
            this.GetSingle.Text = "Get";
            this.GetSingle.UseVisualStyleBackColor = true;
            this.GetSingle.Click += new System.EventHandler(this.GetSingle_Click);
            // 
            // SetSingle
            // 
            this.SetSingle.Location = new System.Drawing.Point(219, 115);
            this.SetSingle.Name = "SetSingle";
            this.SetSingle.Size = new System.Drawing.Size(70, 23);
            this.SetSingle.TabIndex = 75;
            this.SetSingle.Text = "Set";
            this.SetSingle.UseVisualStyleBackColor = true;
            this.SetSingle.Click += new System.EventHandler(this.SetSingle_Click);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(8, 90);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(31, 13);
            this.Label3.TabIndex = 73;
            this.Label3.Text = "Int32";
            // 
            // txt_int32
            // 
            this.txt_int32.Location = new System.Drawing.Point(59, 87);
            this.txt_int32.Name = "txt_int32";
            this.txt_int32.Size = new System.Drawing.Size(153, 20);
            this.txt_int32.TabIndex = 72;
            // 
            // GetInt32
            // 
            this.GetInt32.Location = new System.Drawing.Point(293, 87);
            this.GetInt32.Name = "GetInt32";
            this.GetInt32.Size = new System.Drawing.Size(70, 23);
            this.GetInt32.TabIndex = 70;
            this.GetInt32.Text = "Get";
            this.GetInt32.UseVisualStyleBackColor = true;
            this.GetInt32.Click += new System.EventHandler(this.GetInt32_Click);
            // 
            // SetInt32
            // 
            this.SetInt32.Location = new System.Drawing.Point(219, 87);
            this.SetInt32.Name = "SetInt32";
            this.SetInt32.Size = new System.Drawing.Size(70, 23);
            this.SetInt32.TabIndex = 71;
            this.SetInt32.Text = "Set";
            this.SetInt32.UseVisualStyleBackColor = true;
            this.SetInt32.Click += new System.EventHandler(this.SetInt32_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(7, 54);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(34, 13);
            this.Label2.TabIndex = 69;
            this.Label2.Text = "String";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(8, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(23, 13);
            this.Label1.TabIndex = 68;
            this.Label1.Text = "File";
            // 
            // txt_string
            // 
            this.txt_string.Location = new System.Drawing.Point(59, 51);
            this.txt_string.Name = "txt_string";
            this.txt_string.Size = new System.Drawing.Size(153, 20);
            this.txt_string.TabIndex = 66;
            // 
            // txt_Filename
            // 
            this.txt_Filename.Location = new System.Drawing.Point(39, 14);
            this.txt_Filename.Name = "txt_Filename";
            this.txt_Filename.Size = new System.Drawing.Size(124, 20);
            this.txt_Filename.TabIndex = 67;
            this.txt_Filename.Text = "Theremino1";
            this.txt_Filename.TextChanged += new System.EventHandler(this.txt_Filename_TextChanged);
            // 
            // GetString
            // 
            this.GetString.Location = new System.Drawing.Point(293, 50);
            this.GetString.Name = "GetString";
            this.GetString.Size = new System.Drawing.Size(70, 23);
            this.GetString.TabIndex = 64;
            this.GetString.Text = "Get";
            this.GetString.UseVisualStyleBackColor = true;
            this.GetString.Click += new System.EventHandler(this.GetString_Click);
            // 
            // SetString
            // 
            this.SetString.Location = new System.Drawing.Point(219, 50);
            this.SetString.Name = "SetString";
            this.SetString.Size = new System.Drawing.Size(70, 23);
            this.SetString.TabIndex = 65;
            this.SetString.Text = "Set";
            this.SetString.UseVisualStyleBackColor = true;
            this.SetString.Click += new System.EventHandler(this.SetString_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.ClientSize = new System.Drawing.Size(370, 264);
            this.Controls.Add(this.txt_Offset);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.lbl_Time);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txt_DoubleArray2);
            this.Controls.Add(this.txt_SingleArray2);
            this.Controls.Add(this.txt_IntArray2);
            this.Controls.Add(this.txt_DoubleArray1);
            this.Controls.Add(this.txt_SingleArray1);
            this.Controls.Add(this.txt_IntArray1);
            this.Controls.Add(this.txt_DoubleArray0);
            this.Controls.Add(this.GetDoubleArray);
            this.Controls.Add(this.SetDoubleArray);
            this.Controls.Add(this.txt_SingleArray0);
            this.Controls.Add(this.GetSingleArray);
            this.Controls.Add(this.SetSingleArray);
            this.Controls.Add(this.txt_IntArray0);
            this.Controls.Add(this.GetInt32Array);
            this.Controls.Add(this.SetInt32Array);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.txt_double);
            this.Controls.Add(this.GetDouble);
            this.Controls.Add(this.SetDouble);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txt_single);
            this.Controls.Add(this.GetSingle);
            this.Controls.Add(this.SetSingle);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txt_int32);
            this.Controls.Add(this.GetInt32);
            this.Controls.Add(this.SetInt32);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txt_string);
            this.Controls.Add(this.txt_Filename);
            this.Controls.Add(this.GetString);
            this.Controls.Add(this.SetString);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Memory Mapped Files - CSHARP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txt_Offset;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label lbl_Time;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txt_DoubleArray2;
        internal System.Windows.Forms.TextBox txt_SingleArray2;
        internal System.Windows.Forms.TextBox txt_IntArray2;
        internal System.Windows.Forms.TextBox txt_DoubleArray1;
        internal System.Windows.Forms.TextBox txt_SingleArray1;
        internal System.Windows.Forms.TextBox txt_IntArray1;
        internal System.Windows.Forms.TextBox txt_DoubleArray0;
        internal System.Windows.Forms.Button GetDoubleArray;
        internal System.Windows.Forms.Button SetDoubleArray;
        internal System.Windows.Forms.TextBox txt_SingleArray0;
        internal System.Windows.Forms.Button GetSingleArray;
        internal System.Windows.Forms.Button SetSingleArray;
        internal System.Windows.Forms.TextBox txt_IntArray0;
        internal System.Windows.Forms.Button GetInt32Array;
        internal System.Windows.Forms.Button SetInt32Array;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox txt_double;
        internal System.Windows.Forms.Button GetDouble;
        internal System.Windows.Forms.Button SetDouble;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txt_single;
        internal System.Windows.Forms.Button GetSingle;
        internal System.Windows.Forms.Button SetSingle;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txt_int32;
        internal System.Windows.Forms.Button GetInt32;
        internal System.Windows.Forms.Button SetInt32;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txt_string;
        internal System.Windows.Forms.TextBox txt_Filename;
        internal System.Windows.Forms.Button GetString;
        internal System.Windows.Forms.Button SetString;
    }
}

