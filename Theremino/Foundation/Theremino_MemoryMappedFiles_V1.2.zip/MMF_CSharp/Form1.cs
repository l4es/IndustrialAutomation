﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Diagnostics;

namespace MMF_CSHARP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            MMF1 = new MemoryMappedFile(txt_Filename.Text, 4080);

            Left = 120;
            Top = 40;
        }



        // Timings
        // ------------------------------------------------------------------------------------
        //  "Write" or "Read" the first time:        100 uS  to 500 uS
        //  "Write" or "Read" after a "file change"   15 uS  to  20 uS
        //  "ReadString"  ( len = 100 )               25 uS  to  30 uS
        //  "WriteString" ( len = 100 )                8 uS  to  10 uS 
        //  "ReadSingle" and "ReadDouble"             10 uS  to  15 uS
        //  Normal "Write" or "Read"                   5 uS  to  10 uS
        // ------------------------------------------------------------------------------------


        private MemoryMappedFile MMF1;

        //private Formatprovider fp;


 


        private void txt_Filename_TextChanged(object sender, EventArgs e)
        {
            MMF1 = new MemoryMappedFile(txt_Filename.Text, 4080);
        }

   
        private void SetString_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteString(offset, txt_string.Text);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
        private void GetString_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            string s = MMF1.ReadString(offset);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
            txt_string.Text = s;
        }

        private void SetInt32_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteInt32(offset, Utils.StringToInt32(txt_int32.Text));
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
        private void GetInt32_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            string s = MMF1.ReadInt32(offset).ToString();
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
            txt_int32.Text = s;
        }

        private void SetSingle_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteSingle(offset, Utils.StringToSingle(txt_single.Text));
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
        private void GetSingle_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            string s = MMF1.ReadSingle(offset).ToString(CultureInfo.InvariantCulture);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
            txt_single.Text = s;
        }

        private void SetDouble_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteDouble(offset, Utils.StringToDouble(txt_double.Text));
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
        private void GetDouble_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            string s = MMF1.ReadDouble(offset).ToString(CultureInfo.InvariantCulture);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
            txt_double.Text = s;
        }


        private void SetInt32Array_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteInt32Array(offset, new Int32[3] { Utils.StringToInt32(txt_IntArray0.Text), 
                                                        Utils.StringToInt32(txt_IntArray1.Text), 
                                                        Utils.StringToInt32(txt_IntArray2.Text) });
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }

 
        private void GetInt32Array_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            Int32[] intarray = new Int32[3];
            MMF1.ReadInt32Array(offset, intarray);
            txt_IntArray0.Text = intarray[0].ToString();
            txt_IntArray1.Text = intarray[1].ToString();
            txt_IntArray2.Text = intarray[2].ToString();
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }

        private void SetSingleArray_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteSingleArray(offset, new float[3] { Utils.StringToSingle(txt_SingleArray0.Text), 
                                                         Utils.StringToSingle(txt_SingleArray1.Text), 
                                                         Utils.StringToSingle(txt_SingleArray2.Text) });
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
         private void GetSingleArray_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            float[] singlearray = new float[3];
            MMF1.ReadSingleArray(offset, singlearray);
            txt_SingleArray0.Text = singlearray[0].ToString(CultureInfo.InvariantCulture);
            txt_SingleArray1.Text = singlearray[1].ToString(CultureInfo.InvariantCulture);
            txt_SingleArray2.Text = singlearray[2].ToString(CultureInfo.InvariantCulture);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }

        private void SetDoubleArray_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            MMF1.WriteDoubleArray(offset, new double[3] { Utils.StringToDouble(txt_DoubleArray0.Text), 
                                                          Utils.StringToDouble(txt_DoubleArray1.Text), 
                                                          Utils.StringToDouble(txt_DoubleArray2.Text) });
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }
        private void GetDoubleArray_Click(object sender, EventArgs e)
        {
            Int32 offset = Utils.StringToInt32(txt_Offset.Text);
            Stopwatch sw1 = new Stopwatch(); sw1.Start();
            double[] doublearray = new double[3];
            MMF1.ReadDoubleArray(offset, doublearray);
            txt_DoubleArray0.Text = doublearray[0].ToString(CultureInfo.InvariantCulture);
            txt_DoubleArray1.Text = doublearray[1].ToString(CultureInfo.InvariantCulture);
            txt_DoubleArray2.Text = doublearray[2].ToString(CultureInfo.InvariantCulture);
            lbl_Time.Text = ((sw1.Elapsed.TotalMilliseconds * 1000)).ToString("0");
        }


    }
}
