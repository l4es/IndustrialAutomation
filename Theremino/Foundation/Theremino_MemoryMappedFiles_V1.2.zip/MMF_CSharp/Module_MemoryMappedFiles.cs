using Microsoft.VisualBasic;
using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Data;
//using System.Drawing;
//using System.Diagnostics;
using System.Windows.Forms;
//using System.Linq;
//using System.Xml.Linq;
using System.Runtime.InteropServices;
//using System.Text;

namespace MMF_CSHARP
{



	// ======================================================================================
	//   CLASS MemoryMappedFile
	// ======================================================================================
	public class MemoryMappedFile
	{

		private struct SECURITY_ATTRIBUTES
		{
			public const Int32 nLength = 12;
			public Int32 lpSecurityDescriptor;
			public Int32 bInheritHandle;
		}

		// ---------------------------------------------------------------- private declararations
		[DllImport("Kernel32")]
		private static extern bool CloseHandle(Int32 intPtrFileHandle);

		[DllImport("Kernel32", EntryPoint = "CreateFileMappingA")]
		private static extern Int32 CreateFileMapping(Int32 hFile, ref SECURITY_ATTRIBUTES lpFileMappigAttributes, Int32 flProtect, Int32 dwMaximumSizeHigh, Int32 dwMaximumSizeLow, string lpname);

		[DllImport("Kernel32")]
		private static extern IntPtr MapViewOfFile(Int32 hFileMappingObject, Int32 dwDesiredAccess, Int32 dwFileOffsetHigh, Int32 dwFileOffsetLow, Int32 dwNumberOfBytesToMap);

		[DllImport("Kernel32")]
		private static extern Int32 UnmapViewOfFile(IntPtr lpBaseAddress);

		private const Int32 PAGE_READWRITE = 4;

		private const Int32 FILE_MAP_ALL_ACCESS = 0x1 | 0x2 | 0x4 | 0x8 | 0x10 | 0xf0000;

		private const Int32 INVALID_HANDLE_VALUE = -1;
		// ---------------------------------------------------------------- private members

		private Int32 FileHandle = 0;
		private IntPtr MappingAddress;

		private Int32 FileLength = 0;
		// ---------------------------------------------------------------- construction / destruction


		internal MemoryMappedFile(string Filename, Int32 Length)
		{
            SECURITY_ATTRIBUTES sa = new SECURITY_ATTRIBUTES();
			FileHandle = CreateFileMapping(INVALID_HANDLE_VALUE, ref sa, PAGE_READWRITE, 0, Length, Filename);

			if (FileHandle == 0) {
				MessageBox.Show("Unable to create the MemoryMappedFile: " + Filename, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				Destroy();
				return;
			}

			MappingAddress = MapViewOfFile(FileHandle, FILE_MAP_ALL_ACCESS, 0, 0, 0);

			if (MappingAddress == IntPtr.Zero) {
				MessageBox.Show("Unable to map the MemoryMappedFile: " + Filename, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				Destroy();
				return;
			}

			FileLength = Length;
		}

        ~MemoryMappedFile()
        {
			Destroy();
		}

		internal void Destroy()
		{
			if (MappingAddress != IntPtr.Zero) 
            {
				UnmapViewOfFile(MappingAddress);
			}
			if (FileHandle != 0) 
            {
				CloseHandle(FileHandle);
				FileHandle = 0;
			}
		}


		// ======================================================================================
		//  PUBLIC FUNCTIONS
		// ======================================================================================

		// ---------------------------------------------------------------------------- String
		internal void WriteString(Int32 Offset, string Text)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + Text.Length >= FileLength) return; 
			for (Int32 i = 0; i <= Text.Length - 1; i++) 
            {
                Marshal.WriteByte(MappingAddress, i + Offset, Convert.ToByte(Text[i]));
			}
            Marshal.WriteByte(MappingAddress, Text.Length + Offset, 0);
		}
		internal string ReadString(Int32 Offset)
		{
			string functionReturnValue = null;
			if (MappingAddress == IntPtr.Zero) return ""; 
			if (Offset < 0 || Offset >= FileLength) return ""; 
			functionReturnValue = "";
			byte b = 0;
			for (Int32 i = Offset; i <= Offset + FileLength - 1; i++) 
            {
				b = Marshal.ReadByte(MappingAddress, i);
				if (b == 0) break; // TODO: might not be correct. Was : Exit For

                functionReturnValue += Char.ConvertFromUtf32(b); //Strings.Chr(b);
			}
			return functionReturnValue;
		}

		// ---------------------------------------------------------------------------- Int32
		internal void WriteInt32(Int32 Offset, Int32 Value)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset >= FileLength) return; 
			Marshal.WriteInt32(MappingAddress, Offset, Value);
		}
		internal Int32 ReadInt32(Int32 Offset)
		{
			if (MappingAddress == IntPtr.Zero) return 0; 
			if (Offset < 0 || Offset >= FileLength) return 0; 
			return Marshal.ReadInt32(MappingAddress, Offset);
		}

		// ---------------------------------------------------------------------------- Single
		internal void WriteSingle(Int32 Offset, float Value)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset >= FileLength) return; 
			Int32 i = BitConverter.ToInt32(BitConverter.GetBytes(Value), 0);
			Marshal.WriteInt32(MappingAddress, Offset, i);
		}
		internal float ReadSingle(Int32 Offset)
		{
			if (MappingAddress == IntPtr.Zero) return 0; 
			if (Offset < 0 || Offset >= FileLength) return 0; 
			Int32 i = Marshal.ReadInt32(MappingAddress, Offset);
			return BitConverter.ToSingle(BitConverter.GetBytes(i), 0);
		}

		// ---------------------------------------------------------------------------- Double
		internal void WriteDouble(Int32 Offset, double Value)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset >= FileLength) return; 
			Int64 i = BitConverter.DoubleToInt64Bits(Value);
			Marshal.WriteInt64(MappingAddress, Offset, i);
		}
		internal double ReadDouble(Int32 Offset)
		{
			if (MappingAddress == IntPtr.Zero) return 0; 
			if (Offset < 0 || Offset >= FileLength) return 0; 
			Int64 i = Marshal.ReadInt64(MappingAddress, Offset);
			return BitConverter.Int64BitsToDouble(i);
		}


		// ---------------------------------------------------------------------------- Int32 ARRAY
		internal void WriteInt32Array(Int32 Offset, Int32[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 4 * Array.Length >= FileLength) return; 
			Marshal.Copy(Array, 0, new IntPtr(MappingAddress.ToInt32() + Offset), Array.Length);
		}
		internal void ReadInt32Array(Int32 Offset,  Int32[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 4 * Array.Length >= FileLength) return; 
			Marshal.Copy(new IntPtr(MappingAddress.ToInt32() + Offset), Array, 0, Array.Length);
		}

		// ---------------------------------------------------------------------------- Single ARRAY
		internal void WriteSingleArray(Int32 Offset, float[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 4 * Array.Length >= FileLength) return; 
			Marshal.Copy(Array, 0, new IntPtr(MappingAddress.ToInt32() + Offset), Array.Length);
		}
		internal void ReadSingleArray(Int32 Offset, float[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 4 * Array.Length >= FileLength) return; 
			Marshal.Copy(new IntPtr(MappingAddress.ToInt32() + Offset), Array, 0, Array.Length);
		}

		// ---------------------------------------------------------------------------- Double ARRAY
		internal void WriteDoubleArray(Int32 Offset, double[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 8 * Array.Length >= FileLength) return; 
			Marshal.Copy(Array, 0, new IntPtr(MappingAddress.ToInt32() + Offset), Array.Length);
		}
		internal void ReadDoubleArray(Int32 Offset, double[] Array)
		{
			if (MappingAddress == IntPtr.Zero) return; 
			if (Offset < 0 || Offset + 8 * Array.Length >= FileLength) return; 
			Marshal.Copy(new IntPtr(MappingAddress.ToInt32() + Offset), Array, 0, Array.Length);
		}

	}

}
