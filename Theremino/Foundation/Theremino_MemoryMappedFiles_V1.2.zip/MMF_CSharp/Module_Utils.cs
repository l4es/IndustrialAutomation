﻿
using System.Globalization;

namespace MMF_CSHARP
{

    public class Utils
    {

        public static int StringToInt32(string s)
        {
            try
            {
                return int.Parse(s);
            }
            catch { return 0; }
        }

        public static float StringToSingle(string s)
        {
            try
            {
                return float.Parse(s, CultureInfo.InvariantCulture);
            }
            catch { return 0; }
        }

        public static double StringToDouble(string s)
        {
            try
            {
                return double.Parse(s, CultureInfo.InvariantCulture);
            }
            catch { return 0; }
        }

    }
}