//
#include "stdafx.h"
//#include <iostream>
//
//double Atod(char *s)
//{
//	int sign = 1; // Sign of the number (+/-)
//	double integral_part = 0; // Integral part of the number (everything before the decimal point)
//	double f_part = 0; // Fractional part (everything after the decimal point)
//	double pfd = 1; // The ponder of fractional digit
//
//	// Evaluate the sign of the number. If it is -, then sign is -1
//	if (*s == '-')
//		sign = -1;
//	// Skip over the - or + from the beginning of s
//	if (*s == '-' || *s == '+')
//		s++;
//
//	// Evaluate integral part of the number. We loop until the decimal point
//	// is found, or until the end of the string is encountered.
//	for (; *s != '.' && *s != '\0'; s++)
//		// If the letter is digit, then append it to integral_part:
//		if (isdigit(*s))
//			integral_part = 10 * integral_part + *s - '0'; // -'0' is there so *s is converted to int
//		else
//			// An exception is thrown when a non-digit was found:
//			throw ((char const *)"Non-digit character found!\n");
//
//	// We have a decimal point if this if executes.
//	if (*s == '.')
//	{
//		s++; // Skip over the decimal point.
//		// Loop until the end of string is encountered:
//		while (*s != '\0')
//		{
//			// Check for digit:
//			if (isdigit(*s))
//			{
//				pfd *= 0.1; // Actualize the ponder of fractional digit.
//				f_part += (*s - '0') * pfd; // Append it to fractional part.
//			}
//			else
//				// An exception is thrown when a non-digit was found:
//				throw ((char const *)"Non-digit character found!\n");
//			s++; // Increase the pointer.
//		}
//	}
//
//	// This is the result, which can be either negative/positive (based on
//	// sign we evaluated at the beginning).
//	return (integral_part + f_part) * sign;
//}
//
