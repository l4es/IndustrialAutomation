
	//double Atod(char *s);

