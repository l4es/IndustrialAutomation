#pragma once

#include "MemoryMappedFiles.h"
#include <stdlib.h>
#include <stdio.h>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Runtime::InteropServices;
using namespace System::Diagnostics;

namespace MMF_Cpp {

	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			
			void *theremino_class = NULL;

			wchar_t* s = (wchar_t*)(void*)Marshal::StringToHGlobalUni(txt_Filename->Text);

			if (MMF1) delete MMF1;
			MMF1 = new MemoryMappedFile(s , 4080);

			Left = 238;
			Top = 78;

			nanosecPerTick = (1000L * 1000L * 1000L) / Stopwatch::Frequency;
		}

	protected:
		~Form1()
		{
			// -------------------------------------------------- Clean up any resources being used.
			if (MMF1) delete MMF1;

			// --------------------------------------------------
			if (components)
			{
				delete components;
			}
		}

	internal: System::Windows::Forms::Label^  Label4;
	protected: 
	internal: System::Windows::Forms::TextBox^  txt_single;
	internal: System::Windows::Forms::Button^  GetSingle;
	internal: System::Windows::Forms::Button^  SetSingle;
	internal: System::Windows::Forms::Label^  Label3;
	internal: System::Windows::Forms::TextBox^  txt_int32;
	internal: System::Windows::Forms::Button^  GetInt32;
	internal: System::Windows::Forms::Button^  SetInt32;
	internal: System::Windows::Forms::Label^  Label2;
	internal: System::Windows::Forms::Label^  Label1;
	internal: System::Windows::Forms::TextBox^  txt_string;
	internal: System::Windows::Forms::TextBox^  txt_Filename;
	internal: System::Windows::Forms::Button^  GetString;
	internal: System::Windows::Forms::Button^  SetString;

	private:
		MemoryMappedFile *MMF1;
		Int64 nanosecPerTick;
		Stopwatch ^ timePerOperation;


	internal: System::Windows::Forms::TextBox^  txt_DoubleArray2;
	private: 
	internal: System::Windows::Forms::TextBox^  txt_SingleArray2;
	internal: System::Windows::Forms::TextBox^  txt_IntArray2;
	internal: System::Windows::Forms::TextBox^  txt_DoubleArray1;
	internal: System::Windows::Forms::TextBox^  txt_SingleArray1;
	internal: System::Windows::Forms::TextBox^  txt_IntArray1;
	internal: System::Windows::Forms::TextBox^  txt_DoubleArray0;
	internal: System::Windows::Forms::Button^  GetDoubleArray;
	internal: System::Windows::Forms::Button^  SetDoubleArray;
	internal: System::Windows::Forms::TextBox^  txt_SingleArray0;
	internal: System::Windows::Forms::Button^  GetSingleArray;
	internal: System::Windows::Forms::Button^  SetSingleArray;
	internal: System::Windows::Forms::TextBox^  txt_IntArray0;
	internal: System::Windows::Forms::Button^  GetInt32Array;
	internal: System::Windows::Forms::Button^  SetInt32Array;
	internal: System::Windows::Forms::Label^  Label6;
	internal: System::Windows::Forms::TextBox^  txt_double;
	internal: System::Windows::Forms::Button^  GetDouble;
	internal: System::Windows::Forms::Button^  SetDouble;
	internal: System::Windows::Forms::Label^  Label8;
	internal: System::Windows::Forms::Label^  Label9;
	internal: System::Windows::Forms::Label^  Label10;
	internal: System::Windows::Forms::TextBox^  txt_Offset;
	internal: System::Windows::Forms::Label^  Label7;
	internal: System::Windows::Forms::Label^  lbl_Time;
	internal: System::Windows::Forms::Label^  Label5;
			  /// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Label4 = (gcnew System::Windows::Forms::Label());
			this->txt_single = (gcnew System::Windows::Forms::TextBox());
			this->GetSingle = (gcnew System::Windows::Forms::Button());
			this->SetSingle = (gcnew System::Windows::Forms::Button());
			this->Label3 = (gcnew System::Windows::Forms::Label());
			this->txt_int32 = (gcnew System::Windows::Forms::TextBox());
			this->GetInt32 = (gcnew System::Windows::Forms::Button());
			this->SetInt32 = (gcnew System::Windows::Forms::Button());
			this->Label2 = (gcnew System::Windows::Forms::Label());
			this->Label1 = (gcnew System::Windows::Forms::Label());
			this->txt_string = (gcnew System::Windows::Forms::TextBox());
			this->txt_Filename = (gcnew System::Windows::Forms::TextBox());
			this->GetString = (gcnew System::Windows::Forms::Button());
			this->SetString = (gcnew System::Windows::Forms::Button());
			this->txt_DoubleArray2 = (gcnew System::Windows::Forms::TextBox());
			this->txt_SingleArray2 = (gcnew System::Windows::Forms::TextBox());
			this->txt_IntArray2 = (gcnew System::Windows::Forms::TextBox());
			this->txt_DoubleArray1 = (gcnew System::Windows::Forms::TextBox());
			this->txt_SingleArray1 = (gcnew System::Windows::Forms::TextBox());
			this->txt_IntArray1 = (gcnew System::Windows::Forms::TextBox());
			this->txt_DoubleArray0 = (gcnew System::Windows::Forms::TextBox());
			this->GetDoubleArray = (gcnew System::Windows::Forms::Button());
			this->SetDoubleArray = (gcnew System::Windows::Forms::Button());
			this->txt_SingleArray0 = (gcnew System::Windows::Forms::TextBox());
			this->GetSingleArray = (gcnew System::Windows::Forms::Button());
			this->SetSingleArray = (gcnew System::Windows::Forms::Button());
			this->txt_IntArray0 = (gcnew System::Windows::Forms::TextBox());
			this->GetInt32Array = (gcnew System::Windows::Forms::Button());
			this->SetInt32Array = (gcnew System::Windows::Forms::Button());
			this->Label6 = (gcnew System::Windows::Forms::Label());
			this->txt_double = (gcnew System::Windows::Forms::TextBox());
			this->GetDouble = (gcnew System::Windows::Forms::Button());
			this->SetDouble = (gcnew System::Windows::Forms::Button());
			this->Label8 = (gcnew System::Windows::Forms::Label());
			this->Label9 = (gcnew System::Windows::Forms::Label());
			this->Label10 = (gcnew System::Windows::Forms::Label());
			this->txt_Offset = (gcnew System::Windows::Forms::TextBox());
			this->Label7 = (gcnew System::Windows::Forms::Label());
			this->lbl_Time = (gcnew System::Windows::Forms::Label());
			this->Label5 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// Label4
			// 
			this->Label4->AutoSize = true;
			this->Label4->Location = System::Drawing::Point(8, 118);
			this->Label4->Name = L"Label4";
			this->Label4->Size = System::Drawing::Size(36, 13);
			this->Label4->TabIndex = 25;
			this->Label4->Text = L"Single";
			// 
			// txt_single
			// 
			this->txt_single->Location = System::Drawing::Point(61, 115);
			this->txt_single->Name = L"txt_single";
			this->txt_single->Size = System::Drawing::Size(150, 20);
			this->txt_single->TabIndex = 24;
			// 
			// GetSingle
			// 
			this->GetSingle->Location = System::Drawing::Point(295, 115);
			this->GetSingle->Name = L"GetSingle";
			this->GetSingle->Size = System::Drawing::Size(70, 23);
			this->GetSingle->TabIndex = 22;
			this->GetSingle->Text = L"Get";
			this->GetSingle->UseVisualStyleBackColor = true;
			this->GetSingle->Click += gcnew System::EventHandler(this, &Form1::GetSingle_Click);
			// 
			// SetSingle
			// 
			this->SetSingle->Location = System::Drawing::Point(220, 115);
			this->SetSingle->Name = L"SetSingle";
			this->SetSingle->Size = System::Drawing::Size(70, 23);
			this->SetSingle->TabIndex = 23;
			this->SetSingle->Text = L"Set";
			this->SetSingle->UseVisualStyleBackColor = true;
			this->SetSingle->Click += gcnew System::EventHandler(this, &Form1::SetSingle_Click);
			// 
			// Label3
			// 
			this->Label3->AutoSize = true;
			this->Label3->Location = System::Drawing::Point(8, 90);
			this->Label3->Name = L"Label3";
			this->Label3->Size = System::Drawing::Size(31, 13);
			this->Label3->TabIndex = 21;
			this->Label3->Text = L"Int32";
			// 
			// txt_int32
			// 
			this->txt_int32->Location = System::Drawing::Point(61, 87);
			this->txt_int32->Name = L"txt_int32";
			this->txt_int32->Size = System::Drawing::Size(150, 20);
			this->txt_int32->TabIndex = 20;
			// 
			// GetInt32
			// 
			this->GetInt32->Location = System::Drawing::Point(295, 87);
			this->GetInt32->Name = L"GetInt32";
			this->GetInt32->Size = System::Drawing::Size(70, 23);
			this->GetInt32->TabIndex = 18;
			this->GetInt32->Text = L"Get";
			this->GetInt32->UseVisualStyleBackColor = true;
			this->GetInt32->Click += gcnew System::EventHandler(this, &Form1::GetInt32_Click);
			// 
			// SetInt32
			// 
			this->SetInt32->Location = System::Drawing::Point(220, 87);
			this->SetInt32->Name = L"SetInt32";
			this->SetInt32->Size = System::Drawing::Size(70, 23);
			this->SetInt32->TabIndex = 19;
			this->SetInt32->Text = L"Set";
			this->SetInt32->UseVisualStyleBackColor = true;
			this->SetInt32->Click += gcnew System::EventHandler(this, &Form1::SetInt32_Click);
			// 
			// Label2
			// 
			this->Label2->AutoSize = true;
			this->Label2->Location = System::Drawing::Point(8, 54);
			this->Label2->Name = L"Label2";
			this->Label2->Size = System::Drawing::Size(34, 13);
			this->Label2->TabIndex = 17;
			this->Label2->Text = L"String";
			// 
			// Label1
			// 
			this->Label1->AutoSize = true;
			this->Label1->Location = System::Drawing::Point(7, 17);
			this->Label1->Name = L"Label1";
			this->Label1->Size = System::Drawing::Size(23, 13);
			this->Label1->TabIndex = 16;
			this->Label1->Text = L"File";
			// 
			// txt_string
			// 
			this->txt_string->Location = System::Drawing::Point(61, 51);
			this->txt_string->Name = L"txt_string";
			this->txt_string->Size = System::Drawing::Size(150, 20);
			this->txt_string->TabIndex = 14;
			// 
			// txt_Filename
			// 
			this->txt_Filename->Location = System::Drawing::Point(36, 14);
			this->txt_Filename->Name = L"txt_Filename";
			this->txt_Filename->Size = System::Drawing::Size(124, 20);
			this->txt_Filename->TabIndex = 15;
			this->txt_Filename->Text = L"Theremino1";
			this->txt_Filename->TextChanged += gcnew System::EventHandler(this, &Form1::txt_Filename_TextChanged);
			// 
			// GetString
			// 
			this->GetString->Location = System::Drawing::Point(295, 50);
			this->GetString->Name = L"GetString";
			this->GetString->Size = System::Drawing::Size(70, 23);
			this->GetString->TabIndex = 12;
			this->GetString->Text = L"Get";
			this->GetString->UseVisualStyleBackColor = true;
			this->GetString->Click += gcnew System::EventHandler(this, &Form1::GetString_Click);
			// 
			// SetString
			// 
			this->SetString->Location = System::Drawing::Point(220, 50);
			this->SetString->Name = L"SetString";
			this->SetString->Size = System::Drawing::Size(70, 23);
			this->SetString->TabIndex = 13;
			this->SetString->Text = L"Set";
			this->SetString->UseVisualStyleBackColor = true;
			this->SetString->Click += gcnew System::EventHandler(this, &Form1::SetString_Click);
			// 
			// txt_DoubleArray2
			// 
			this->txt_DoubleArray2->Location = System::Drawing::Point(165, 236);
			this->txt_DoubleArray2->Name = L"txt_DoubleArray2";
			this->txt_DoubleArray2->Size = System::Drawing::Size(46, 20);
			this->txt_DoubleArray2->TabIndex = 59;
			// 
			// txt_SingleArray2
			// 
			this->txt_SingleArray2->Location = System::Drawing::Point(165, 209);
			this->txt_SingleArray2->Name = L"txt_SingleArray2";
			this->txt_SingleArray2->Size = System::Drawing::Size(46, 20);
			this->txt_SingleArray2->TabIndex = 58;
			// 
			// txt_IntArray2
			// 
			this->txt_IntArray2->Location = System::Drawing::Point(165, 182);
			this->txt_IntArray2->Name = L"txt_IntArray2";
			this->txt_IntArray2->Size = System::Drawing::Size(46, 20);
			this->txt_IntArray2->TabIndex = 57;
			// 
			// txt_DoubleArray1
			// 
			this->txt_DoubleArray1->Location = System::Drawing::Point(116, 236);
			this->txt_DoubleArray1->Name = L"txt_DoubleArray1";
			this->txt_DoubleArray1->Size = System::Drawing::Size(46, 20);
			this->txt_DoubleArray1->TabIndex = 56;
			// 
			// txt_SingleArray1
			// 
			this->txt_SingleArray1->Location = System::Drawing::Point(116, 209);
			this->txt_SingleArray1->Name = L"txt_SingleArray1";
			this->txt_SingleArray1->Size = System::Drawing::Size(46, 20);
			this->txt_SingleArray1->TabIndex = 55;
			// 
			// txt_IntArray1
			// 
			this->txt_IntArray1->Location = System::Drawing::Point(116, 182);
			this->txt_IntArray1->Name = L"txt_IntArray1";
			this->txt_IntArray1->Size = System::Drawing::Size(46, 20);
			this->txt_IntArray1->TabIndex = 54;
			// 
			// txt_DoubleArray0
			// 
			this->txt_DoubleArray0->Location = System::Drawing::Point(66, 236);
			this->txt_DoubleArray0->Name = L"txt_DoubleArray0";
			this->txt_DoubleArray0->Size = System::Drawing::Size(46, 20);
			this->txt_DoubleArray0->TabIndex = 52;
			// 
			// GetDoubleArray
			// 
			this->GetDoubleArray->Location = System::Drawing::Point(294, 234);
			this->GetDoubleArray->Name = L"GetDoubleArray";
			this->GetDoubleArray->Size = System::Drawing::Size(70, 23);
			this->GetDoubleArray->TabIndex = 50;
			this->GetDoubleArray->Text = L"Get";
			this->GetDoubleArray->UseVisualStyleBackColor = true;
			this->GetDoubleArray->Click += gcnew System::EventHandler(this, &Form1::GetDoubleArray_Click);
			// 
			// SetDoubleArray
			// 
			this->SetDoubleArray->Location = System::Drawing::Point(220, 234);
			this->SetDoubleArray->Name = L"SetDoubleArray";
			this->SetDoubleArray->Size = System::Drawing::Size(70, 23);
			this->SetDoubleArray->TabIndex = 51;
			this->SetDoubleArray->Text = L"Set";
			this->SetDoubleArray->UseVisualStyleBackColor = true;
			this->SetDoubleArray->Click += gcnew System::EventHandler(this, &Form1::SetDoubleArray_Click);
			// 
			// txt_SingleArray0
			// 
			this->txt_SingleArray0->Location = System::Drawing::Point(66, 209);
			this->txt_SingleArray0->Name = L"txt_SingleArray0";
			this->txt_SingleArray0->Size = System::Drawing::Size(46, 20);
			this->txt_SingleArray0->TabIndex = 48;
			// 
			// GetSingleArray
			// 
			this->GetSingleArray->Location = System::Drawing::Point(294, 207);
			this->GetSingleArray->Name = L"GetSingleArray";
			this->GetSingleArray->Size = System::Drawing::Size(70, 23);
			this->GetSingleArray->TabIndex = 46;
			this->GetSingleArray->Text = L"Get";
			this->GetSingleArray->UseVisualStyleBackColor = true;
			this->GetSingleArray->Click += gcnew System::EventHandler(this, &Form1::GetSingleArray_Click);
			// 
			// SetSingleArray
			// 
			this->SetSingleArray->Location = System::Drawing::Point(220, 207);
			this->SetSingleArray->Name = L"SetSingleArray";
			this->SetSingleArray->Size = System::Drawing::Size(70, 23);
			this->SetSingleArray->TabIndex = 47;
			this->SetSingleArray->Text = L"Set";
			this->SetSingleArray->UseVisualStyleBackColor = true;
			this->SetSingleArray->Click += gcnew System::EventHandler(this, &Form1::SetSingleArray_Click);
			// 
			// txt_IntArray0
			// 
			this->txt_IntArray0->Location = System::Drawing::Point(66, 182);
			this->txt_IntArray0->Name = L"txt_IntArray0";
			this->txt_IntArray0->Size = System::Drawing::Size(46, 20);
			this->txt_IntArray0->TabIndex = 44;
			// 
			// GetInt32Array
			// 
			this->GetInt32Array->Location = System::Drawing::Point(294, 180);
			this->GetInt32Array->Name = L"GetInt32Array";
			this->GetInt32Array->Size = System::Drawing::Size(70, 23);
			this->GetInt32Array->TabIndex = 42;
			this->GetInt32Array->Text = L"Get";
			this->GetInt32Array->UseVisualStyleBackColor = true;
			this->GetInt32Array->Click += gcnew System::EventHandler(this, &Form1::GetInt32Array_Click);
			// 
			// SetInt32Array
			// 
			this->SetInt32Array->Location = System::Drawing::Point(220, 180);
			this->SetInt32Array->Name = L"SetInt32Array";
			this->SetInt32Array->Size = System::Drawing::Size(70, 23);
			this->SetInt32Array->TabIndex = 43;
			this->SetInt32Array->Text = L"Set";
			this->SetInt32Array->UseVisualStyleBackColor = true;
			this->SetInt32Array->Click += gcnew System::EventHandler(this, &Form1::SetInt32Array_Click);
			// 
			// Label6
			// 
			this->Label6->AutoSize = true;
			this->Label6->Location = System::Drawing::Point(9, 147);
			this->Label6->Name = L"Label6";
			this->Label6->Size = System::Drawing::Size(41, 13);
			this->Label6->TabIndex = 41;
			this->Label6->Text = L"Double";
			// 
			// txt_double
			// 
			this->txt_double->Location = System::Drawing::Point(61, 144);
			this->txt_double->Name = L"txt_double";
			this->txt_double->Size = System::Drawing::Size(150, 20);
			this->txt_double->TabIndex = 40;
			// 
			// GetDouble
			// 
			this->GetDouble->Location = System::Drawing::Point(294, 142);
			this->GetDouble->Name = L"GetDouble";
			this->GetDouble->Size = System::Drawing::Size(70, 23);
			this->GetDouble->TabIndex = 38;
			this->GetDouble->Text = L"Get";
			this->GetDouble->UseVisualStyleBackColor = true;
			this->GetDouble->Click += gcnew System::EventHandler(this, &Form1::GetDouble_Click);
			// 
			// SetDouble
			// 
			this->SetDouble->Location = System::Drawing::Point(220, 142);
			this->SetDouble->Name = L"SetDouble";
			this->SetDouble->Size = System::Drawing::Size(70, 23);
			this->SetDouble->TabIndex = 39;
			this->SetDouble->Text = L"Set";
			this->SetDouble->UseVisualStyleBackColor = true;
			this->SetDouble->Click += gcnew System::EventHandler(this, &Form1::SetDouble_Click);
			// 
			// Label8
			// 
			this->Label8->AutoSize = true;
			this->Label8->Location = System::Drawing::Point(9, 239);
			this->Label8->Name = L"Label8";
			this->Label8->Size = System::Drawing::Size(53, 13);
			this->Label8->TabIndex = 53;
			this->Label8->Text = L"Double ( )";
			// 
			// Label9
			// 
			this->Label9->AutoSize = true;
			this->Label9->Location = System::Drawing::Point(9, 212);
			this->Label9->Name = L"Label9";
			this->Label9->Size = System::Drawing::Size(48, 13);
			this->Label9->TabIndex = 49;
			this->Label9->Text = L"Single ( )";
			// 
			// Label10
			// 
			this->Label10->AutoSize = true;
			this->Label10->Location = System::Drawing::Point(9, 185);
			this->Label10->Name = L"Label10";
			this->Label10->Size = System::Drawing::Size(43, 13);
			this->Label10->TabIndex = 45;
			this->Label10->Text = L"Int32 ( )";
			// 
			// txt_Offset
			// 
			this->txt_Offset->Location = System::Drawing::Point(209, 14);
			this->txt_Offset->Name = L"txt_Offset";
			this->txt_Offset->Size = System::Drawing::Size(50, 20);
			this->txt_Offset->TabIndex = 63;
			this->txt_Offset->Text = L"0";
			this->txt_Offset->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// Label7
			// 
			this->Label7->AutoSize = true;
			this->Label7->Location = System::Drawing::Point(170, 18);
			this->Label7->Name = L"Label7";
			this->Label7->Size = System::Drawing::Size(35, 13);
			this->Label7->TabIndex = 62;
			this->Label7->Text = L"Offset";
			// 
			// lbl_Time
			// 
			this->lbl_Time->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->lbl_Time->Location = System::Drawing::Point(325, 15);
			this->lbl_Time->Name = L"lbl_Time";
			this->lbl_Time->Size = System::Drawing::Size(37, 18);
			this->lbl_Time->TabIndex = 61;
			this->lbl_Time->Text = L"- - -";
			this->lbl_Time->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// Label5
			// 
			this->Label5->AutoSize = true;
			this->Label5->Location = System::Drawing::Point(268, 18);
			this->Label5->Name = L"Label5";
			this->Label5->Size = System::Drawing::Size(58, 13);
			this->Label5->TabIndex = 60;
			this->Label5->Text = L"Time ( uS )";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Moccasin;
			this->ClientSize = System::Drawing::Size(370, 264);
			this->Controls->Add(this->txt_Offset);
			this->Controls->Add(this->Label7);
			this->Controls->Add(this->lbl_Time);
			this->Controls->Add(this->Label5);
			this->Controls->Add(this->txt_DoubleArray2);
			this->Controls->Add(this->txt_SingleArray2);
			this->Controls->Add(this->txt_IntArray2);
			this->Controls->Add(this->txt_DoubleArray1);
			this->Controls->Add(this->txt_SingleArray1);
			this->Controls->Add(this->txt_IntArray1);
			this->Controls->Add(this->txt_DoubleArray0);
			this->Controls->Add(this->GetDoubleArray);
			this->Controls->Add(this->SetDoubleArray);
			this->Controls->Add(this->txt_SingleArray0);
			this->Controls->Add(this->GetSingleArray);
			this->Controls->Add(this->SetSingleArray);
			this->Controls->Add(this->txt_IntArray0);
			this->Controls->Add(this->GetInt32Array);
			this->Controls->Add(this->SetInt32Array);
			this->Controls->Add(this->Label6);
			this->Controls->Add(this->txt_double);
			this->Controls->Add(this->GetDouble);
			this->Controls->Add(this->SetDouble);
			this->Controls->Add(this->Label8);
			this->Controls->Add(this->Label9);
			this->Controls->Add(this->Label10);
			this->Controls->Add(this->Label4);
			this->Controls->Add(this->txt_single);
			this->Controls->Add(this->GetSingle);
			this->Controls->Add(this->SetSingle);
			this->Controls->Add(this->Label3);
			this->Controls->Add(this->txt_int32);
			this->Controls->Add(this->GetInt32);
			this->Controls->Add(this->SetInt32);
			this->Controls->Add(this->Label2);
			this->Controls->Add(this->Label1);
			this->Controls->Add(this->txt_string);
			this->Controls->Add(this->txt_Filename);
			this->Controls->Add(this->GetString);
			this->Controls->Add(this->SetString);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::Manual;
			this->Text = L"Memory Mapped Files - CPP";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void txt_Filename_TextChanged(System::Object^  sender, System::EventArgs^  e) 
	{
		wchar_t* s = (wchar_t*)(void*)Marshal::StringToHGlobalUni(txt_Filename->Text);
		if (MMF1) delete MMF1;
		MMF1 = new MemoryMappedFile(s , 4080);
	}

	private: __int32 GetOffset()
	{
		char* s = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_Offset->Text);
		return atoi(s);
	}

	private: inline void TimerStart()
	{
		timePerOperation = Stopwatch::StartNew();
	}

	private: inline void TimerStop()
	{
		timePerOperation->Stop();
		char cs[1020];
		_itoa_s(timePerOperation->ElapsedTicks * nanosecPerTick / 1000L, cs, 10);
		lbl_Time->Text = gcnew String(cs);
	}


	private: System::Void SetString_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		char* s = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_string->Text);
		MMF1->WriteString(offset, s);
		TimerStop();
	}
	private: System::Void GetString_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		char* cs = MMF1->ReadString(offset);
		String ^ s = gcnew String(cs);
		TimerStop();
		txt_string->Text = s;
	}

	private: System::Void SetInt32_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		char* s = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_int32->Text);
		__int32 n = atoi(s);
		MMF1->WriteInt32(offset, n);
		TimerStop();
	}
	private: System::Void GetInt32_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		__int32 n = MMF1->ReadInt32(offset);
		char cs[1020];
		_itoa_s(n, cs, 10);
		String ^ s = gcnew String(cs);
		TimerStop();
		txt_int32->Text = s;
	}

	private: System::Void SetSingle_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		char* s = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_single->Text);
		float f = (float)atof(s);
		MMF1->WriteSingle(offset, f);
		TimerStop();
	}
	private: System::Void GetSingle_Click(System::Object^  sender, System::EventArgs^  e)
	{
		__int32 offset = GetOffset();
		TimerStart();
		float f = MMF1->ReadSingle(offset);
		char cs[1020];
		sprintf_s(cs, "%.7G", f);
		String ^ s = gcnew String(cs);
		TimerStop();
		txt_single->Text = s;
	}


	private: System::Void SetDouble_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		char* s = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_double->Text);
		double d = atof(s);
		MMF1->WriteDouble(offset, d);
		TimerStop();
	}
	private: System::Void GetDouble_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		double d = MMF1->ReadDouble(offset);
		char cs[1020];
		sprintf_s(cs, "%.15G", d);
		String ^ s = gcnew String(cs);
		TimerStop();
		txt_double->Text = s;
	}


	private: System::Void SetInt32Array_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		__int32 intarray[3];
		char* s0 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_IntArray0->Text);
		intarray[0]= atoi(s0);
		char* s1 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_IntArray1->Text);
		intarray[1]= atoi(s1);
		char* s2 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_IntArray2->Text);
		intarray[2]= atoi(s2);
		MMF1->WriteInt32Array(offset, 3, intarray);
		TimerStop();
	}
	private: System::Void GetInt32Array_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		__int32 intarray[3];
		char s[1020];
		MMF1->ReadInt32Array(offset, 3, intarray);
		_itoa_s(intarray[0], s, 10);
		txt_IntArray0->Text = gcnew String(s);
		_itoa_s(intarray[1], s, 10);
		txt_IntArray1->Text = gcnew String(s);
		_itoa_s(intarray[2], s, 10);
		txt_IntArray2->Text = gcnew String(s);
		TimerStop();
	}


	private: System::Void SetSingleArray_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		float floatarray[3];
		char* s0 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_SingleArray0->Text);
		floatarray[0]= (float)atof(s0);
		char* s1 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_SingleArray1->Text);
		floatarray[1]= (float)atof(s1);
		char* s2 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_SingleArray2->Text);
		floatarray[2]= (float)atof(s2);
		MMF1->WriteSingleArray(offset, 3, floatarray);
		TimerStop();
	}
	private: System::Void GetSingleArray_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		float floatarray[3];
		char s[1020];
		MMF1->ReadSingleArray(offset, 3, floatarray);
		sprintf_s(s, "%.7G", floatarray[0]);
		txt_SingleArray0->Text = gcnew String(s);
		sprintf_s(s, "%.7G", floatarray[1]);
		txt_SingleArray1->Text = gcnew String(s);
		sprintf_s(s, "%.7G", floatarray[2]);
		txt_SingleArray2->Text = gcnew String(s);
		TimerStop();
	}


	private: System::Void SetDoubleArray_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		double doublearray[3];
		char* s0 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_DoubleArray0->Text);
		doublearray[0]= atof(s0);
		char* s1 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_DoubleArray1->Text);
		doublearray[1]= atof(s1);
		char* s2 = (char*)(void*)Marshal::StringToHGlobalAnsi(txt_DoubleArray2->Text);
		doublearray[2]= atof(s2);
		MMF1->WriteDoubleArray(offset, 3, doublearray);
		TimerStop();
	}
	private: System::Void GetDoubleArray_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		__int32 offset = GetOffset();
		TimerStart();
		double doublearray[3];
		char s[1020];
		MMF1->ReadDoubleArray(offset, 3, doublearray);
		sprintf_s(s, "%.15G", doublearray[0]);
		txt_DoubleArray0->Text = gcnew String(s);
		sprintf_s(s, "%.15G", doublearray[1]);
		txt_DoubleArray1->Text = gcnew String(s);
		sprintf_s(s, "%.15G", doublearray[2]);
		txt_DoubleArray2->Text = gcnew String(s);
		TimerStop();
	}


};
}

