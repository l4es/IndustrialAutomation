// ======================================================================================
//   CLASS MemoryMappedFile
// ======================================================================================
class MemoryMappedFile
{
	private:
		HANDLE		FileHandle;
		void*		MappingAddress;
		__int32		FileLength;
		char*		functionReturnValue;

	// ---------------------------------------------------------------- construction / destruction

	public:
		MemoryMappedFile(LPCWSTR Filename, __int32 Length);
		~MemoryMappedFile();

	private:
		void Destroy();

	// ======================================================================================
	//  PUBLIC FUNCTIONS
	// ======================================================================================
	public:

		// ---------------------------------------------------------------- String
		void WriteString(__int32 Offset, LPSTR Text);
		LPSTR ReadString(__int32 Offset);

		// ---------------------------------------------------------------- Int32
		void WriteInt32(__int32 Offset, __int32 Value);
		__int32 ReadInt32(__int32 Offset);

		// ---------------------------------------------------------------- Single
		void WriteSingle(__int32 Offset, float Value);
		float ReadSingle(__int32 Offset);

		// ---------------------------------------------------------------- Double
		void WriteDouble(__int32 Offset, double Value);
		double ReadDouble(__int32 Offset);

		// ------------------------------------------------------------------------------------------- Int32 Array
		void MemoryMappedFile::WriteInt32Array(__int32 Offset, __int32 nValues, __int32 Values[]);
		void MemoryMappedFile::ReadInt32Array(__int32 Offset, __int32 nValues, __int32 Values[]);

		// ------------------------------------------------------------------------------------------- Single Array
		void MemoryMappedFile::WriteSingleArray(__int32 Offset, __int32 nValues, float Values[]);
		void MemoryMappedFile::ReadSingleArray(__int32 Offset, __int32 nValues, float Values[]);

		// ------------------------------------------------------------------------------------------- Double Array
		void MemoryMappedFile::WriteDoubleArray(__int32 Offset, __int32 nValues, double Values[]);
		void MemoryMappedFile::ReadDoubleArray(__int32 Offset, __int32 nValues, double Values[]);

};

