﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SetString = New System.Windows.Forms.Button
        Me.txt_Filename = New System.Windows.Forms.TextBox
        Me.txt_string = New System.Windows.Forms.TextBox
        Me.GetString = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_int32 = New System.Windows.Forms.TextBox
        Me.GetInt32 = New System.Windows.Forms.Button
        Me.SetInt32 = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_single = New System.Windows.Forms.TextBox
        Me.GetSingle = New System.Windows.Forms.Button
        Me.SetSingle = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.lbl_Time = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txt_double = New System.Windows.Forms.TextBox
        Me.GetDouble = New System.Windows.Forms.Button
        Me.SetDouble = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.txt_Offset = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txt_DoubleArray0 = New System.Windows.Forms.TextBox
        Me.GetDoubleArray = New System.Windows.Forms.Button
        Me.SetDoubleArray = New System.Windows.Forms.Button
        Me.Label9 = New System.Windows.Forms.Label
        Me.txt_SingleArray0 = New System.Windows.Forms.TextBox
        Me.GetSingleArray = New System.Windows.Forms.Button
        Me.SetSingleArray = New System.Windows.Forms.Button
        Me.Label10 = New System.Windows.Forms.Label
        Me.txt_IntArray0 = New System.Windows.Forms.TextBox
        Me.GetInt32Array = New System.Windows.Forms.Button
        Me.SetInt32Array = New System.Windows.Forms.Button
        Me.txt_DoubleArray1 = New System.Windows.Forms.TextBox
        Me.txt_SingleArray1 = New System.Windows.Forms.TextBox
        Me.txt_IntArray1 = New System.Windows.Forms.TextBox
        Me.txt_DoubleArray2 = New System.Windows.Forms.TextBox
        Me.txt_SingleArray2 = New System.Windows.Forms.TextBox
        Me.txt_IntArray2 = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'SetString
        '
        Me.SetString.Location = New System.Drawing.Point(219, 52)
        Me.SetString.Name = "SetString"
        Me.SetString.Size = New System.Drawing.Size(70, 23)
        Me.SetString.TabIndex = 0
        Me.SetString.Text = "Set"
        Me.SetString.UseVisualStyleBackColor = True
        '
        'txt_Filename
        '
        Me.txt_Filename.Location = New System.Drawing.Point(36, 16)
        Me.txt_Filename.Name = "txt_Filename"
        Me.txt_Filename.Size = New System.Drawing.Size(122, 20)
        Me.txt_Filename.TabIndex = 1
        Me.txt_Filename.Text = "Theremino1"
        '
        'txt_string
        '
        Me.txt_string.Location = New System.Drawing.Point(59, 54)
        Me.txt_string.Name = "txt_string"
        Me.txt_string.Size = New System.Drawing.Size(153, 20)
        Me.txt_string.TabIndex = 1
        '
        'GetString
        '
        Me.GetString.Location = New System.Drawing.Point(293, 52)
        Me.GetString.Name = "GetString"
        Me.GetString.Size = New System.Drawing.Size(70, 23)
        Me.GetString.TabIndex = 0
        Me.GetString.Text = "Get"
        Me.GetString.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "File"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "String"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Int32"
        '
        'txt_int32
        '
        Me.txt_int32.Location = New System.Drawing.Point(59, 89)
        Me.txt_int32.Name = "txt_int32"
        Me.txt_int32.Size = New System.Drawing.Size(153, 20)
        Me.txt_int32.TabIndex = 6
        '
        'GetInt32
        '
        Me.GetInt32.Location = New System.Drawing.Point(293, 87)
        Me.GetInt32.Name = "GetInt32"
        Me.GetInt32.Size = New System.Drawing.Size(70, 23)
        Me.GetInt32.TabIndex = 4
        Me.GetInt32.Text = "Get"
        Me.GetInt32.UseVisualStyleBackColor = True
        '
        'SetInt32
        '
        Me.SetInt32.Location = New System.Drawing.Point(219, 87)
        Me.SetInt32.Name = "SetInt32"
        Me.SetInt32.Size = New System.Drawing.Size(70, 23)
        Me.SetInt32.TabIndex = 5
        Me.SetInt32.Text = "Set"
        Me.SetInt32.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Single"
        '
        'txt_single
        '
        Me.txt_single.Location = New System.Drawing.Point(59, 116)
        Me.txt_single.Name = "txt_single"
        Me.txt_single.Size = New System.Drawing.Size(153, 20)
        Me.txt_single.TabIndex = 10
        '
        'GetSingle
        '
        Me.GetSingle.Location = New System.Drawing.Point(293, 114)
        Me.GetSingle.Name = "GetSingle"
        Me.GetSingle.Size = New System.Drawing.Size(70, 23)
        Me.GetSingle.TabIndex = 8
        Me.GetSingle.Text = "Get"
        Me.GetSingle.UseVisualStyleBackColor = True
        '
        'SetSingle
        '
        Me.SetSingle.Location = New System.Drawing.Point(219, 114)
        Me.SetSingle.Name = "SetSingle"
        Me.SetSingle.Size = New System.Drawing.Size(70, 23)
        Me.SetSingle.TabIndex = 9
        Me.SetSingle.Text = "Set"
        Me.SetSingle.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(263, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Time ( uS )"
        '
        'lbl_Time
        '
        Me.lbl_Time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Time.Location = New System.Drawing.Point(320, 17)
        Me.lbl_Time.Name = "lbl_Time"
        Me.lbl_Time.Size = New System.Drawing.Size(37, 18)
        Me.lbl_Time.TabIndex = 13
        Me.lbl_Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 146)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Double"
        '
        'txt_double
        '
        Me.txt_double.Location = New System.Drawing.Point(59, 143)
        Me.txt_double.Name = "txt_double"
        Me.txt_double.Size = New System.Drawing.Size(153, 20)
        Me.txt_double.TabIndex = 16
        '
        'GetDouble
        '
        Me.GetDouble.Location = New System.Drawing.Point(293, 141)
        Me.GetDouble.Name = "GetDouble"
        Me.GetDouble.Size = New System.Drawing.Size(70, 23)
        Me.GetDouble.TabIndex = 14
        Me.GetDouble.Text = "Get"
        Me.GetDouble.UseVisualStyleBackColor = True
        '
        'SetDouble
        '
        Me.SetDouble.Location = New System.Drawing.Point(219, 141)
        Me.SetDouble.Name = "SetDouble"
        Me.SetDouble.Size = New System.Drawing.Size(70, 23)
        Me.SetDouble.TabIndex = 15
        Me.SetDouble.Text = "Set"
        Me.SetDouble.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(165, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Offset"
        '
        'txt_Offset
        '
        Me.txt_Offset.Location = New System.Drawing.Point(204, 16)
        Me.txt_Offset.Name = "txt_Offset"
        Me.txt_Offset.Size = New System.Drawing.Size(50, 20)
        Me.txt_Offset.TabIndex = 19
        Me.txt_Offset.Text = "0"
        Me.txt_Offset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 238)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Double ( )"
        '
        'txt_DoubleArray0
        '
        Me.txt_DoubleArray0.Location = New System.Drawing.Point(65, 235)
        Me.txt_DoubleArray0.Name = "txt_DoubleArray0"
        Me.txt_DoubleArray0.Size = New System.Drawing.Size(46, 20)
        Me.txt_DoubleArray0.TabIndex = 30
        '
        'GetDoubleArray
        '
        Me.GetDoubleArray.Location = New System.Drawing.Point(293, 233)
        Me.GetDoubleArray.Name = "GetDoubleArray"
        Me.GetDoubleArray.Size = New System.Drawing.Size(70, 23)
        Me.GetDoubleArray.TabIndex = 28
        Me.GetDoubleArray.Text = "Get"
        Me.GetDoubleArray.UseVisualStyleBackColor = True
        '
        'SetDoubleArray
        '
        Me.SetDoubleArray.Location = New System.Drawing.Point(219, 233)
        Me.SetDoubleArray.Name = "SetDoubleArray"
        Me.SetDoubleArray.Size = New System.Drawing.Size(70, 23)
        Me.SetDoubleArray.TabIndex = 29
        Me.SetDoubleArray.Text = "Set"
        Me.SetDoubleArray.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(8, 211)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "Single ( )"
        '
        'txt_SingleArray0
        '
        Me.txt_SingleArray0.Location = New System.Drawing.Point(65, 208)
        Me.txt_SingleArray0.Name = "txt_SingleArray0"
        Me.txt_SingleArray0.Size = New System.Drawing.Size(46, 20)
        Me.txt_SingleArray0.TabIndex = 26
        '
        'GetSingleArray
        '
        Me.GetSingleArray.Location = New System.Drawing.Point(293, 206)
        Me.GetSingleArray.Name = "GetSingleArray"
        Me.GetSingleArray.Size = New System.Drawing.Size(70, 23)
        Me.GetSingleArray.TabIndex = 24
        Me.GetSingleArray.Text = "Get"
        Me.GetSingleArray.UseVisualStyleBackColor = True
        '
        'SetSingleArray
        '
        Me.SetSingleArray.Location = New System.Drawing.Point(219, 206)
        Me.SetSingleArray.Name = "SetSingleArray"
        Me.SetSingleArray.Size = New System.Drawing.Size(70, 23)
        Me.SetSingleArray.TabIndex = 25
        Me.SetSingleArray.Text = "Set"
        Me.SetSingleArray.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(8, 184)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(43, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Int32 ( )"
        '
        'txt_IntArray0
        '
        Me.txt_IntArray0.Location = New System.Drawing.Point(65, 181)
        Me.txt_IntArray0.Name = "txt_IntArray0"
        Me.txt_IntArray0.Size = New System.Drawing.Size(46, 20)
        Me.txt_IntArray0.TabIndex = 22
        '
        'GetInt32Array
        '
        Me.GetInt32Array.Location = New System.Drawing.Point(293, 179)
        Me.GetInt32Array.Name = "GetInt32Array"
        Me.GetInt32Array.Size = New System.Drawing.Size(70, 23)
        Me.GetInt32Array.TabIndex = 20
        Me.GetInt32Array.Text = "Get"
        Me.GetInt32Array.UseVisualStyleBackColor = True
        '
        'SetInt32Array
        '
        Me.SetInt32Array.Location = New System.Drawing.Point(219, 179)
        Me.SetInt32Array.Name = "SetInt32Array"
        Me.SetInt32Array.Size = New System.Drawing.Size(70, 23)
        Me.SetInt32Array.TabIndex = 21
        Me.SetInt32Array.Text = "Set"
        Me.SetInt32Array.UseVisualStyleBackColor = True
        '
        'txt_DoubleArray1
        '
        Me.txt_DoubleArray1.Location = New System.Drawing.Point(115, 235)
        Me.txt_DoubleArray1.Name = "txt_DoubleArray1"
        Me.txt_DoubleArray1.Size = New System.Drawing.Size(46, 20)
        Me.txt_DoubleArray1.TabIndex = 34
        '
        'txt_SingleArray1
        '
        Me.txt_SingleArray1.Location = New System.Drawing.Point(115, 208)
        Me.txt_SingleArray1.Name = "txt_SingleArray1"
        Me.txt_SingleArray1.Size = New System.Drawing.Size(46, 20)
        Me.txt_SingleArray1.TabIndex = 33
        '
        'txt_IntArray1
        '
        Me.txt_IntArray1.Location = New System.Drawing.Point(115, 181)
        Me.txt_IntArray1.Name = "txt_IntArray1"
        Me.txt_IntArray1.Size = New System.Drawing.Size(46, 20)
        Me.txt_IntArray1.TabIndex = 32
        '
        'txt_DoubleArray2
        '
        Me.txt_DoubleArray2.Location = New System.Drawing.Point(164, 235)
        Me.txt_DoubleArray2.Name = "txt_DoubleArray2"
        Me.txt_DoubleArray2.Size = New System.Drawing.Size(46, 20)
        Me.txt_DoubleArray2.TabIndex = 37
        '
        'txt_SingleArray2
        '
        Me.txt_SingleArray2.Location = New System.Drawing.Point(164, 208)
        Me.txt_SingleArray2.Name = "txt_SingleArray2"
        Me.txt_SingleArray2.Size = New System.Drawing.Size(46, 20)
        Me.txt_SingleArray2.TabIndex = 36
        '
        'txt_IntArray2
        '
        Me.txt_IntArray2.Location = New System.Drawing.Point(164, 181)
        Me.txt_IntArray2.Name = "txt_IntArray2"
        Me.txt_IntArray2.Size = New System.Drawing.Size(46, 20)
        Me.txt_IntArray2.TabIndex = 35
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.ClientSize = New System.Drawing.Size(370, 264)
        Me.Controls.Add(Me.txt_DoubleArray2)
        Me.Controls.Add(Me.txt_SingleArray2)
        Me.Controls.Add(Me.txt_IntArray2)
        Me.Controls.Add(Me.txt_DoubleArray1)
        Me.Controls.Add(Me.txt_SingleArray1)
        Me.Controls.Add(Me.txt_IntArray1)
        Me.Controls.Add(Me.txt_DoubleArray0)
        Me.Controls.Add(Me.GetDoubleArray)
        Me.Controls.Add(Me.SetDoubleArray)
        Me.Controls.Add(Me.txt_SingleArray0)
        Me.Controls.Add(Me.GetSingleArray)
        Me.Controls.Add(Me.SetSingleArray)
        Me.Controls.Add(Me.txt_IntArray0)
        Me.Controls.Add(Me.GetInt32Array)
        Me.Controls.Add(Me.SetInt32Array)
        Me.Controls.Add(Me.txt_Offset)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_double)
        Me.Controls.Add(Me.GetDouble)
        Me.Controls.Add(Me.SetDouble)
        Me.Controls.Add(Me.lbl_Time)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_single)
        Me.Controls.Add(Me.GetSingle)
        Me.Controls.Add(Me.SetSingle)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_int32)
        Me.Controls.Add(Me.GetInt32)
        Me.Controls.Add(Me.SetInt32)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_string)
        Me.Controls.Add(Me.txt_Filename)
        Me.Controls.Add(Me.GetString)
        Me.Controls.Add(Me.SetString)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Memory Mapped Files - VBNET"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SetString As System.Windows.Forms.Button
    Friend WithEvents txt_Filename As System.Windows.Forms.TextBox
    Friend WithEvents txt_string As System.Windows.Forms.TextBox
    Friend WithEvents GetString As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_int32 As System.Windows.Forms.TextBox
    Friend WithEvents GetInt32 As System.Windows.Forms.Button
    Friend WithEvents SetInt32 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_single As System.Windows.Forms.TextBox
    Friend WithEvents GetSingle As System.Windows.Forms.Button
    Friend WithEvents SetSingle As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lbl_Time As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_double As System.Windows.Forms.TextBox
    Friend WithEvents GetDouble As System.Windows.Forms.Button
    Friend WithEvents SetDouble As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_Offset As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_DoubleArray0 As System.Windows.Forms.TextBox
    Friend WithEvents GetDoubleArray As System.Windows.Forms.Button
    Friend WithEvents SetDoubleArray As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_SingleArray0 As System.Windows.Forms.TextBox
    Friend WithEvents GetSingleArray As System.Windows.Forms.Button
    Friend WithEvents SetSingleArray As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_IntArray0 As System.Windows.Forms.TextBox
    Friend WithEvents GetInt32Array As System.Windows.Forms.Button
    Friend WithEvents SetInt32Array As System.Windows.Forms.Button
    Friend WithEvents txt_DoubleArray1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_SingleArray1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_IntArray1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_DoubleArray2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_SingleArray2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_IntArray2 As System.Windows.Forms.TextBox

End Class
