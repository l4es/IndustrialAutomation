﻿Imports System.Diagnostics


Public Class Form1

    ' Timings
    ' ------------------------------------------------------------------------------------
    '  "Write" or "Read" the first time:        100 uS  to 500 uS
    '  "Write" or "Read" after a "file change"   15 uS  to  20 uS
    '  "ReadString"  ( len = 100 )               25 uS  to  30 uS
    '  "WriteString" ( len = 100 )                8 uS  to  10 uS 
    '  "ReadSingle" and "ReadDouble"             10 uS  to  15 uS
    '  Normal "Write" or "Read"                   5 uS  to  10 uS
    ' ------------------------------------------------------------------------------------

    Private MMF1 As MemoryMappedFile
    Private EventsAreEnabled As Boolean = False

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MMF1 = New MemoryMappedFile(txt_Filename.Text)
        Left = 2
        Top = 2
        EventsAreEnabled = True
    End Sub

    Private Sub txt_Filename_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Filename.TextChanged
        If Not EventsAreEnabled Then Return
        MMF1 = New MemoryMappedFile(txt_Filename.Text)
    End Sub


    Private Sub SetString_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetString.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteString(offset, txt_string.Text)
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetString_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetString.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim s As String = MMF1.ReadString(offset)
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
        txt_string.Text = s
    End Sub

    Private Sub SetInt32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetInt32.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteInt32(offset, CInt(Val(txt_int32.Text)))
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetInt32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetInt32.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim s As String = MMF1.ReadInt32(offset).ToString
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
        txt_int32.Text = s
    End Sub

    Private Sub SetSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetSingle.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteSingle(offset, CSng(Val(txt_single.Text)))
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSingle.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim s As String = Replace(MMF1.ReadSingle(offset).ToString, ",", ".")
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
        txt_single.Text = s
    End Sub

    Private Sub SetDouble_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetDouble.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteDouble(offset, Val(txt_double.Text))
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetDouble_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetDouble.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim s As String = Replace(MMF1.ReadDouble(offset).ToString, ",", ".")
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
        txt_double.Text = s
    End Sub


    Private Sub SetInt32Array_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetInt32Array.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteInt32Array(offset, New Int32(2) {CInt(Val(txt_IntArray0.Text)), CInt(Val(txt_IntArray1.Text)), CInt(Val(txt_IntArray2.Text))})
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetInt32Array_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetInt32Array.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim intarray(2) As Int32
        MMF1.ReadInt32Array(offset, intarray)
        txt_IntArray0.Text = intarray(0).ToString
        txt_IntArray1.Text = intarray(1).ToString
        txt_IntArray2.Text = intarray(2).ToString
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub

    Private Sub SetSingleArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetSingleArray.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        MMF1.WriteSingleArray(offset, New Single(2) {CSng(Val(txt_SingleArray0.Text)), CSng(Val(txt_SingleArray1.Text)), CSng(Val(txt_SingleArray2.Text))})
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetSingleArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSingleArray.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim singlearray(2) As Single
        MMF1.ReadSingleArray(offset, singlearray)
        txt_SingleArray0.Text = Replace(singlearray(0).ToString, ",", ".")
        txt_SingleArray1.Text = Replace(singlearray(1).ToString, ",", ".")
        txt_SingleArray2.Text = Replace(singlearray(2).ToString, ",", ".")
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub

    Private Sub SetDoubleArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetDoubleArray.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim dArray As Double() = New Double(2) {Val(txt_DoubleArray0.Text), Val(txt_DoubleArray1.Text), Val(txt_DoubleArray2.Text)}
        ' ----------------------------------------------------------------------- using WriteDoubleArray
        MMF1.WriteDoubleArray(offset, dArray)
        ' ----------------------------------------------------------------------- using WriteMemoryArea
        'MMF1.WriteMemoryArea(VarPtr(dArray(0)).ToInt32, dArray.Length, offset)
        ' ----------------------------------------------------------------------- 
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub
    Private Sub GetDoubleArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetDoubleArray.Click
        Dim offset As Int32 = CInt(Val(txt_Offset.Text))
        Dim sw1 As Stopwatch = New Stopwatch : sw1.Start()
        Dim dArray(2) As Double
        ' ----------------------------------------------------------------------- using ReadDoubleArray
        MMF1.ReadDoubleArray(offset, dArray)
        ' ----------------------------------------------------------------------- using ReadMemoryArea
        'MMF1.ReadMemoryArea(VarPtr(dArray(0)).ToInt32, dArray.Length, offset)
        ' ----------------------------------------------------------------------- 
        txt_DoubleArray0.Text = Replace(dArray(0).ToString, ",", ".")
        txt_DoubleArray1.Text = Replace(dArray(1).ToString, ",", ".")
        txt_DoubleArray2.Text = Replace(dArray(2).ToString, ",", ".")
        lbl_Time.Text = (sw1.Elapsed.TotalMilliseconds * 1000.0F).ToString("0")
    End Sub

End Class
