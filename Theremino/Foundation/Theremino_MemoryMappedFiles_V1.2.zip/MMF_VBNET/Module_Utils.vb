﻿Module Module_Utils

    Public Function VarPtr(ByVal e As Object) As IntPtr
        Dim GC As System.Runtime.InteropServices.GCHandle = _
        System.Runtime.InteropServices.GCHandle.Alloc(e, System.Runtime.InteropServices.GCHandleType.Pinned)
        Dim GC2 As Int32 = GC.AddrOfPinnedObject.ToInt32
        GC.Free()
        Return CType(GC2, IntPtr)
    End Function

    Public Function VarPtr_Int(ByVal e As Object) As Int32
        Dim GC As System.Runtime.InteropServices.GCHandle = _
        System.Runtime.InteropServices.GCHandle.Alloc(e, System.Runtime.InteropServices.GCHandleType.Pinned)
        Dim GC2 As Int32 = GC.AddrOfPinnedObject.ToInt32
        GC.Free()
        Return GC2
    End Function

End Module
