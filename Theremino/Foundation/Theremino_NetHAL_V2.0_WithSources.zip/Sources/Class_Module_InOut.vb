﻿
' ==================================================================================================
'   CLASS Module_InOut
' ==================================================================================================

Partial Friend Class Module_InOut

    Private Const MaxPinCount As Int32 = 99
    Friend OutputDataBuffer(MaxPinCount) As UInt32
    Friend InputDataBuffer(MaxPinCount) As UInt32

    Friend ProgModuleCompleted As Boolean = False
    Friend DataExchangeCompleted As Boolean = True
    Friend MyDeviceIsActive As Boolean

    Private mActionLock As Object = New Object
    Private mMaxFps As Int32

    Friend ConfigId As Int32
    Friend ConfigValid As Boolean

    Friend ModuleId As Int32
    Friend ModuleVersion As String
    Private ModuleName As String

    Friend CommSpeed As Int32
    Friend CommMillisec As Single
    Friend CommFps As Single
    Friend ErrorRate As Single

    Friend IpAddr As String
    Friend ProgStatus As String

    Private PinsPropsProgrammedByNetHAL() As NetHALRPC.PropsStr
    Private PinsCapsFromNetModule() As NetHALRPC.ScanPropsStr


    ' ==========================================================================================
    '   PUBLIC COMMANDS - COMMUNICATION 
    ' ==========================================================================================
    Friend Function OpenCommunication() As Boolean
        ' ready to open serial ports or similar
        Return True
    End Function

    Friend Sub CloseCommunication()
        ' ready to close serial ports or similar
    End Sub

    Friend Sub SetCommSpeed(ByVal _speed As Int32)
        CommSpeed = _speed
        Select Case CommSpeed
            Case 1 : mMaxFps = 10
            Case 2 : mMaxFps = 20
            Case 3 : mMaxFps = 30
            Case 4 : mMaxFps = 50
            Case 5 : mMaxFps = 60
            Case 6 : mMaxFps = 100
            Case 7 : mMaxFps = 150
            Case 8 : mMaxFps = 200
            Case 9 : mMaxFps = 300
            Case 10 : mMaxFps = 400
            Case 11 : mMaxFps = 500
            Case Else : mMaxFps = 9999
        End Select
    End Sub

    Friend Sub SetName(ByVal _name As String)
        ModuleName = _name
    End Sub

    Friend Function GetName() As String
        Return ModuleName
    End Function

    Friend Sub New(ByVal _moduleid As Int32)
        ModuleName = ""
        ModuleId = _moduleid
        ModuleVersion = "NoVersion"
        SetCommSpeed(7)
        CommFps = 100
    End Sub

    Friend Sub SetPinCaps(ByVal PinsCaps() As NetHALRPC.ScanPropsStr)
        PinsCapsFromNetModule = PinsCaps
        InitDefaultPins()
    End Sub


    ' ==========================================================================================
    '   PUBLIC COMMANDS
    ' ==========================================================================================
    Friend Sub CalibrateZero()
        For Each p As Pin In Pins
            p.CalibrateZero()
        Next
    End Sub

    Friend Sub SetSpeed(ByVal _Speed As Int32)
        StopTimedOperations()
        SyncLock mActionLock
            SetCommSpeed(_Speed)
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Sub SetOutputPinsToParkingPosition()
        StopTimedOperations()
        SyncLock mActionLock
            For Each p As Pin In Pins
                If p.Direction = Pin.Directions.HostToModule Then
                    ' -------------------------------------------
                    p.Value = p.Value_Parking
                    If Single.IsNaN(p.Value) Then
                        Slots.WriteSlot(p.Slot, p.Value)
                    Else
                        p.ConvertValueToHardwareFormat()
                        Slots.WriteSlot(p.Slot, p.Value_RawUinteger)
                    End If
                End If
            Next
            ' --------------------------------------------------- update phisical module immediately
            DataExchange()
            System.Threading.Thread.Sleep(32)
        End SyncLock
        StartTimedOperations()
    End Sub


    ' ==========================================================================================
    '   PINS
    ' ==========================================================================================
    Friend Pins As List(Of Pin)

    Private Sub InitDefaultPins()
        Pins = New List(Of Pin)
        For i As Int32 = 0 To PinsCapsFromNetModule.Length - 1
            Pins.Add(New Pin(Pin.PinTypes.UNUSED, ModuleId, PinsCapsFromNetModule(i).PinName))
        Next
    End Sub

    Friend Sub FillTypeCombo(ByVal cmb As ComboBox, ByRef p As Pin)
        cmb.Items.Clear()
        cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.UNUSED))
        For i As Int32 = 0 To PinsCapsFromNetModule.Length - 1
            If PinsCapsFromNetModule(i).PinName = p.PinName Then
                Dim caps() As String = PinsCapsFromNetModule(i).Prop.Split("-"c)
                For j As Int32 = 0 To caps.Length - 1
                    Select Case caps(j)
                        Case "DGOU" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_OUT))
                        Case "PWMO" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PWM_16))
                        Case "SERV" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.SERVO_16))
                        Case "DGIN" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN))
                        Case "DGIP" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.DIG_IN_PU))
                        Case "ADCI" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ADC_16))
                        Case "COUN" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER))
                        Case "COUP" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.COUNTER_PU))
                        Case "PERI" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD))
                        Case "PERP" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.PERIOD_PU))
                        Case "ENCA" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_A))
                        Case "ENCB" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_B))
                        Case "ENAP" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_A_PU))
                        Case "ENBP" : cmb.Items.Add(Pin.PinTypeToString(Pin.PinTypes.ENCODER_B_PU))
                    End Select
                Next
            End If
        Next
    End Sub


    ' ##########################################################################################
    ' ******************************************************************************************
    '   COMMUNICATION WITH THE HARDWARE MODULES
    ' ******************************************************************************************
    ' ##########################################################################################

    Private Sub Execution_Error(ByVal ErrorString As String)
        ErrorRate += 0.01F
        Debug.Print("ERROR - " & ErrorString)
    End Sub

    Private Sub Execution_OK()
        ErrorRate *= 0.95F
    End Sub

    ' ==========================================================================================
    '   LOOPS AND COMMUNICATIONS
    ' ==========================================================================================
    Private sw1 As Diagnostics.Stopwatch = New Diagnostics.Stopwatch
    Private rawFps As Single
    Private delayMs As Int32
    Private Sub DataExchange()
        ' ------------------------------------------------------------- if disconnected return
        If Not MyDeviceIsActive Then
            CommFps = 0
            ErrorRate = 100
            Threading.Thread.Sleep(10)
            Return
        End If
        ' ------------------------------------------------------------- ExecuteDataExchange
        ExecuteDataExchange()
        ' ------------------------------------------------------------- CommMillisec
        'CommMillisec = CSng(sw1.Elapsed.TotalMilliseconds)
        CommMillisec = CSng(sw1.ElapsedMilliseconds)
        rawFps = 1000.0F / CommMillisec
        sw1.Reset()
        sw1.Start()
        If CommMillisec >= 1 Then
            SmoothValue(CommFps, rawFps, 1, False, CommFps)
        End If
        ' ------------------------------------------------------------- adaptive FPS
        If mMaxFps < 9999 Then
            delayMs += Math.Sign(rawFps - mMaxFps)
            If delayMs > 100 Then delayMs = 100
            If delayMs <= 0 Then
                delayMs = 0
            Else
                System.Threading.Thread.Sleep(delayMs)
            End If
        End If
    End Sub

    Private Sub ExecuteDataExchange()
        If Not DataExchangeCompleted Then Return
        If PinsPropsProgrammedByNetHAL Is Nothing Then Return

        ' ----------------------------------------------------------- SLOTS to COM-BUFFER
        Dim i As Int32 = 0
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.HostToModule Then
                p.ReadValueFromSlot()
                p.ConvertValueToHardwareFormat()
                OutputDataBuffer(i) = p.Value_RawUinteger
                i += 1
            End If
        Next

        ' ------------------------------------------------- Send output pin values to module
        ' ------------------------------------------------- every single pin may be paired with a slot
        Dim PinsOut(-1) As NetHALRPC.IntValueStr
        Dim PinCount As Int32 = 0
        Dim PinValue As UInt32
        i = 0
        For Each PinProps As NetHALRPC.PropsStr In PinsPropsProgrammedByNetHAL
            If PinProps.Prop = "DGOU" Or _
               PinProps.Prop = "PWMO" Or _
               PinProps.Prop = "SERV" Then
                PinValue = OutputDataBuffer(i)
                i += 1
                ReDim Preserve PinsOut(PinCount)
                PinsOut(PinCount).Index = PinProps.Index
                PinsOut(PinCount).Value = PinValue
                PinCount = PinCount + 1
            End If
        Next

        ' ----------------------------------------------------------- Exchange Request
        DataExchangeCompleted = False
        ' the request is always executed also if there are no output to transfer, 
        ' to force the retrivement of the inputs from the module, if any
        ' XchgModuleReplay event will be fired automatically 
        Dim ModuleProps As NetHALRPC.RequestModulePropsStr
        ModuleProps.IPAddr = IpAddr
        _NetHALRPC.XchgIntModuleRequest(ModuleProps, PinsOut)

        ' ----------------------------------------------------------- Wait response or 100 mS timeout
        Static timeout As Stopwatch = New Stopwatch
        Static errorCounter As Int32
        While Not DataExchangeCompleted
            timeout.Start()
            SleepMyThread(1)
            If timeout.ElapsedMilliseconds > 100 Then
                timeout.Reset()
                DataExchangeCompleted = True
                Execution_Error("FastDataExchange timeout")
                errorCounter += 1
                If errorCounter > 20 Then
                    MyDeviceIsActive = False
                End If
                Return
            End If
        End While
        errorCounter = 0
        timeout.Reset()
        Execution_OK()
        ' ----------------------------------------------------------- COM-BUFFER to SLOTS
        i = 0
        For Each p As Pin In Pins
            If p.Direction = Pin.Directions.ModuleToHost Then
                p.Value_RawUinteger = InputDataBuffer(i)
                i += 1
                p.ConvertValueFromHardwareFormat()
                p.WriteValueToSlot()
            End If
        Next
    End Sub

    Friend Sub SetupModulePins()
        StopTimedOperations()
        SyncLock mActionLock
            ' -------------------------------------------------------- retry 10 times
            For retry As Int32 = 1 To 10
                ' ---------------------------------------------------- send pin types
                Dim ModuleProps As NetHALRPC.RequestModulePropsStr
                ModuleProps.IPAddr = IpAddr
                Dim PinsProps(Pins.Count - 1) As NetHALRPC.PropsStr
                For i As Int32 = 0 To Pins.Count - 1
                    PinsProps(i).Index = i
                    PinsProps(i).Prop = TranslatePinTypeToHardware(Pins(i).GetPinType)
                Next
                PinsPropsProgrammedByNetHAL = PinsProps
                ' ---------------------------------------------------- ProgModuleRequest
                ProgModuleCompleted = False
                _NetHALRPC.ProgModuleRequest(ModuleProps, PinsProps)
                ' ---------------------------------------------------- wait ProgModuleCompleted
                For i As Int32 = 0 To 100
                    SleepMyThread(1)
                    If ProgModuleCompleted Then
                        retry = 9999
                        Exit For
                    End If
                Next
            Next
        End SyncLock
        StartTimedOperations()
    End Sub

    Friend Function TranslatePinTypeToHardware(ByVal pt As Pin.PinTypes) As String
        Select Case pt
            Case Pin.PinTypes.DIG_OUT : Return "DGOU"
            Case Pin.PinTypes.PWM_8, Pin.PinTypes.PWM_16 : Return "PWMO"
            Case Pin.PinTypes.SERVO_8, Pin.PinTypes.SERVO_16 : Return "SERV"
            Case Pin.PinTypes.DIG_IN : Return "DGIN"
            Case Pin.PinTypes.DIG_IN_PU : Return "DGIP"
            Case Pin.PinTypes.COUNTER : Return "COUN"
            Case Pin.PinTypes.COUNTER_PU : Return "COUP"
            Case Pin.PinTypes.PERIOD : Return "PERI"
            Case Pin.PinTypes.PERIOD_PU : Return "PERP"
            Case Pin.PinTypes.ADC_8, Pin.PinTypes.ADC_16 : Return "ADCI"
            Case Pin.PinTypes.ENCODER_A : Return "ENCA"
            Case Pin.PinTypes.ENCODER_B : Return "ENCB"
            Case Pin.PinTypes.ENCODER_A_PU : Return "ENAP"
            Case Pin.PinTypes.ENCODER_B_PU : Return "ENBP"
            Case Else : Return "UNUS"
        End Select
    End Function

    Friend Sub WriteNameToHardware()
        StopTimedOperations()
        SyncLock mActionLock
            ' -----------------------------------------------------------------
            ' Retry is in the calling function "Change_SelectedModule_Name" 
            ' -----------------------------------------------------------------
            Dim NameModuleProps As NetHALRPC.NameModulePropsStr
            NameModuleProps.IPAddr = IpAddr
            NameModuleProps.Name = ModuleName.Replace(" ", "").Trim()
            _NetHALRPC.NameModuleRequest(NameModuleProps)
        End SyncLock
        StartTimedOperations()
    End Sub

End Class

