﻿' ==================================================================================================
'   CLASS Module_Timers
' ==================================================================================================

Partial Friend Class Module_InOut ' TIMERS

    Private TimerEnabled As Boolean = False
    Private ThreadStop As Boolean = False
    Private objThread As Threading.Thread

    Private Sub DataExchangeThread()
        Do
            If Not TimerEnabled Then Exit Do
            If ThreadStop Then Exit Do
            DataExchange()
        Loop
    End Sub

    Private Sub DataExchangeThread_Start()
        If Not TimerEnabled Then Return
        If objThread Is Nothing Then
            objThread = New Threading.Thread(AddressOf DataExchangeThread)
            ' --------------------------------------------------------- a Background Thread closes automatically with the application
            objThread.IsBackground = True
            ' --------------------------------------------------------- set the Priority of the thread.
            objThread.Priority = Threading.ThreadPriority.Highest
            ' --------------------------------------------------------- start the thread.
            ThreadStop = False
            objThread.Start()
        End If
        System.Threading.Thread.Sleep(0)
    End Sub

    Private Sub DataExchangeThread_Stop()
        If objThread IsNot Nothing Then
            ' --------------------------------------- stop the thread
            ThreadStop = True
            ' --------------------------------------- wait the thread to stop
            If objThread IsNot Nothing Then
                objThread.Join(2000)
            End If
            objThread = Nothing

            ' test with multiple change name
            ' --------------------------------------- wait data exchange completed
            While Not DataExchangeCompleted
                SleepMyThread(1)
            End While
            ' --------------------------------------- wait data exchange completed with timeout
            'Static timeout As Stopwatch = New Stopwatch
            'While Not DataExchangeCompleted
            '    timeout.Start()
            '    SleepMyThread(1)
            '    If timeout.ElapsedMilliseconds > 200 Then
            '        DataExchangeCompleted = True
            '        Execution_Error("FastDataExchange")
            '        Return
            '    End If
            'End While
            'timeout.Reset()
        End If
    End Sub

    Friend Sub StartTimedOperations()
        If Not Me.ConfigValid Then Return
        SyncLock mActionLock
            If Not TimerEnabled Then
                TimerEnabled = True
                DataExchangeThread_Start()
            End If
        End SyncLock
    End Sub

    Friend Sub StopTimedOperations()
        SyncLock mActionLock
            If TimerEnabled Then
                TimerEnabled = False
                DataExchangeThread_Stop()
            End If
        End SyncLock
    End Sub

End Class
