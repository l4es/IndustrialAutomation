﻿Imports System.Net
Imports System.Net.NetworkInformation

Public Class NetHALRPC

    Friend Structure ScanReplayModulePropsStr
        Dim IPAddr As String
        Dim FWVer As String
        Dim Name As String
        Dim MAC As String
        Dim ProgStatus As String
    End Structure
    Friend Structure PropsStr
        Dim Index As Int32
        Dim Prop As String
    End Structure
    Friend Structure ScanPropsStr
        Dim PinName As String
        Dim Prop As String
    End Structure
    Friend Structure IntValueStr
        Dim Index As Int32
        Dim Value As UInt32
    End Structure
    Friend Structure SingleValueStr
        Dim Index As Int32
        Dim Value As Single
    End Structure
    Friend Structure RequestModulePropsStr
        Dim IPAddr As String
    End Structure
    Friend Structure ScanRemoteModuleRequestStr
        Dim IPAddr As String
        Dim Port As Int32
    End Structure
    Friend Structure XchgModuleReplayStr
        Dim IPAddr As String
        Dim ProgStatus As String
    End Structure
    Friend Structure ProgModuleReplayPropsStr
        Dim IPAddr As String
        Dim ProgStatus As String
    End Structure
    Friend Structure NameModulePropsStr
        Dim IPAddr As String
        Dim Name As String
    End Structure
    Friend Structure FuotaModulePropsStr
        Dim IPAddr As String
        Dim ServerPort As String
        Dim FileName1 As String
        Dim FileName2 As String
    End Structure

    Private WithEvents _NetCom As NetCom = New NetCom

    Friend Function ScanAdapters(ByVal LocalPort As Int32) As Int32
        Return _NetCom.ScanAdapters(LocalPort)
    End Function

    Friend Sub GetConnectionStats(ByVal SourceIP As String, ByRef RequestCounter As Int32, ByRef ReplayCounter As Int32)
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(SourceIP, ipa) = True Then
            _NetCom.GetConnectionStats(ipa, RequestCounter, ReplayCounter)
        End If
    End Sub

    Friend Sub GetTotalConnectionsStats(ByRef RequestCounter As Int32, ByRef ReplayCounter As Int32)
        _NetCom.GetTotalConnectionsStats(RequestCounter, ReplayCounter)
    End Sub

    Friend Sub ResetConnectionStats()
        _NetCom.ResetConnectionsStats()
    End Sub

    Friend Sub CloseAdapters()
        _NetCom.CloseAdapters()
    End Sub

    Friend Sub ScanLocalModuleRequest()
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " SCAN"
        _NetCom.FirstTXToLAN(Data)
    End Sub
    Friend Sub ScanRemoteModuleRequest(ByVal ModuleProps As NetHALRPC.ScanRemoteModuleRequestStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " SCAN"
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleProps.IPAddr, ipa) = True Then
            _NetCom.FirstTXToWAN(ipa, ModuleProps.Port, Data)
        End If
    End Sub
    Friend Event ScanModuleReplay As ScanModuleReplayHandler
    Friend Delegate Sub ScanModuleReplayHandler(ByVal ModuleProps As NetHALRPC.ScanReplayModulePropsStr, ByVal PinsProps() As NetHALRPC.ScanPropsStr)

    Friend Sub ProgModuleRequest(ByVal ModuleProps As NetHALRPC.RequestModulePropsStr, ByVal PinsProps() As NetHALRPC.PropsStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " PROG "
        For Each PinProps As NetHALRPC.PropsStr In PinsProps
            Data = Data + PinProps.Index.ToString("X2") + "=" + PinProps.Prop + ":"
        Next
        Data = Data.Remove(Data.Length - 1)
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleProps.IPAddr, ipa) = True Then
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event ProgModuleReplay As ProgModuleReplayHandler
    Friend Delegate Sub ProgModuleReplayHandler(ByVal ModuleProps As NetHALRPC.ProgModuleReplayPropsStr)

    Friend Sub XchgIntModuleRequest(ByVal ModuleProps As NetHALRPC.RequestModulePropsStr, ByVal PinsOutValue() As NetHALRPC.IntValueStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " XCGI "
        For Each PinOutValue As NetHALRPC.IntValueStr In PinsOutValue
            Data = Data + PinOutValue.Index.ToString("X2") + "=" + CInt(Val(PinOutValue.Value Mod 65536)).ToString("X4") + ":"
        Next
        Data = Data.Remove(Data.Length - 1)
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleProps.IPAddr, ipa) = True Then
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event XchgIntModuleReplay As XchgIntModuleReplayHandler
    Friend Delegate Sub XchgIntModuleReplayHandler(ByVal ModuleProps As NetHALRPC.XchgModuleReplayStr, ByVal PinsIn() As NetHALRPC.IntValueStr)

    Friend Sub XchgSingleModuleRequest(ByVal ModuleProps As NetHALRPC.RequestModulePropsStr, ByVal SlotsOutValue() As NetHALRPC.SingleValueStr)
        Dim Data As String
        Dim ba(4) As Byte
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " XCGS "
        For Each SlotOutValue As NetHALRPC.SingleValueStr In SlotsOutValue
            ba = BitConverter.GetBytes(SlotOutValue.Value)
            Data = Data + SlotOutValue.Index.ToString("X2") + "=" + ba(0).ToString("X2") + ba(1).ToString("X2") + ba(2).ToString("X2") + ba(3).ToString("X2") + ":"
        Next
        Data = Data.Remove(Data.Length - 1)
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleProps.IPAddr, ipa) = True Then
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event XchgSingleModuleReplay As XchgSingleModuleReplayHandler
    Friend Delegate Sub XchgSingleModuleReplayHandler(ByVal ModuleProps As NetHALRPC.XchgModuleReplayStr, ByVal SlotsIn() As NetHALRPC.SingleValueStr)

    Friend Sub NameModuleRequest(ByVal ModuleName As NetHALRPC.NameModulePropsStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " NAME"
        Data = Data + " " + ModuleName.Name
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleName.IPAddr, ipa) = True Then
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event NameModuleReplay As NameModuleReplayHandler
    Friend Delegate Sub NameModuleReplayHandler(ByVal ModuleName As NetHALRPC.NameModulePropsStr)

    Friend Sub ConfModuleRequest(ByVal ModuleName As NetHALRPC.NameModulePropsStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " CONF"
        Data = Data + " " + ModuleName.Name
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(ModuleName.IPAddr, ipa) = True Then
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event ConfModuleReplay As ConfModuleReplayHandler
    Friend Delegate Sub ConfModuleReplayHandler(ByVal ModuleName As NetHALRPC.NameModulePropsStr)

    Friend Sub FuotaModuleRequest(ByVal FuotaModule As NetHALRPC.FuotaModulePropsStr)
        Dim Data As String
        Data = _NetCom._ComProtVer
        Data = Data + " H"
        Data = Data + " FUOTA"
        Dim ipa As IPAddress = Nothing
        If IPAddress.TryParse(FuotaModule.IPAddr, ipa) = True Then
            Data = Data + " " + _NetCom.GetAdapterFromIP(ipa).ToString
            Data = Data + " " + FuotaModule.ServerPort
            Data = Data + " " + FuotaModule.FileName1
            Data = Data + " " + FuotaModule.FileName2
            Data = Data + " "
            _NetCom.TX(ipa, Data)
        End If
    End Sub
    Friend Event FuotaModuleReplay As FuotaModuleReplayHandler
    Friend Delegate Sub FuotaModuleReplayHandler(ByVal ModuleName As NetHALRPC.NameModulePropsStr)

    Private Sub RXEventHandler(ByVal IP As IPAddress, ByVal Data As String) Handles _NetCom.RXEvent
        Dim Pars() As String = Split(Data)
        If Pars(0) = _NetCom._ComProtVer Then
            If Mid(Pars(1), 1, 1) = "M" Or Mid(Pars(1), 1, 1) = "S" Then
                Select Case Pars(2)
                    Case "SCAN"
                        If Pars.Length = 7 Then
                            Dim ModuleProps As NetHALRPC.ScanReplayModulePropsStr
                            ModuleProps.IPAddr = IP.ToString
                            ModuleProps.FWVer = Pars(1)
                            ModuleProps.Name = Pars(3)
                            ModuleProps.MAC = Pars(4)
                            ModuleProps.ProgStatus = Pars(5)
                            Dim Pairs() As String = Split(Pars(6), ":")
                            Dim PinsProps(Pairs.Length - 1) As NetHALRPC.ScanPropsStr
                            For PinIndex As Int32 = 0 To Pairs.Length - 1
                                'For Each Pair As String In Pairs
                                Dim Singles() As String = Split(Pairs(PinIndex), "=")
                                PinsProps(PinIndex).PinName = Singles(0)
                                PinsProps(PinIndex).Prop = Singles(1)
                            Next
                            RaiseEvent ScanModuleReplay(ModuleProps, PinsProps)
                        End If
                    Case "PROG"
                        If Pars.Length = 4 Then
                            Dim ModuleProps As NetHALRPC.ProgModuleReplayPropsStr
                            ModuleProps.IPAddr = IP.ToString
                            ModuleProps.ProgStatus = Pars(3)
                            RaiseEvent ProgModuleReplay(ModuleProps)
                            _NetCom.ReplayTrans(IP)
                        End If
                    Case "XCGI"
                        'if lenght = 4 no inputs values present
                        If Pars.Length = 4 Or Pars.Length = 5 Then
                            Dim ModuleProps As NetHALRPC.XchgModuleReplayStr
                            Dim PinsInValue(-1) As NetHALRPC.IntValueStr
                            ModuleProps.IPAddr = IP.ToString
                            ModuleProps.ProgStatus = Pars(3)
                            If Pars.Length = 5 Then
                                Dim Pairs() As String = Split(Pars(4), ":")
                                ReDim PinsInValue(Pairs.Length - 1)
                                For PinIndex As Int32 = 0 To Pairs.Length - 1
                                    'For Each Pair As String In Pairs
                                    Dim Singles() As String = Split(Pairs(PinIndex), "=")
                                    PinsInValue(PinIndex).Index = Convert.ToInt32(Singles(0), 16)
                                    PinsInValue(PinIndex).Value = Convert.ToUInt32(Singles(1), 16)
                                Next
                            End If
                            RaiseEvent XchgIntModuleReplay(ModuleProps, PinsInValue)
                            _NetCom.ReplayTrans(IP)
                        End If
                    Case "XCGS"
                        'if lenght = 3 no inputs values present
                        If Pars.Length = 4 Or Pars.Length = 5 Then
                            Dim ModuleProps As NetHALRPC.XchgModuleReplayStr
                            Dim SlotsInValue(-1) As NetHALRPC.SingleValueStr
                            ModuleProps.IPAddr = IP.ToString
                            ModuleProps.ProgStatus = Pars(3)
                            If Pars.Length = 5 Then
                                Dim Pairs() As String = Split(Pars(4), ":")
                                ReDim SlotsInValue(Pairs.Length - 1)
                                For PinIndex As Int32 = 0 To Pairs.Length - 1
                                    'For Each Pair As String In Pairs
                                    Dim Singles() As String = Split(Pairs(PinIndex), "=")
                                    Dim ba(4) As Byte
                                    SlotsInValue(PinIndex).Index = Convert.ToInt32(Singles(0), 16)
                                    ba(0) = Convert.ToByte(Mid(Singles(1), 1, 2), 16)
                                    ba(1) = Convert.ToByte(Mid(Singles(1), 3, 2), 16)
                                    ba(2) = Convert.ToByte(Mid(Singles(1), 5, 2), 16)
                                    ba(3) = Convert.ToByte(Mid(Singles(1), 7, 2), 16)
                                    SlotsInValue(PinIndex).Value = BitConverter.ToSingle(ba, 0)
                                Next
                            End If
                            RaiseEvent XchgSingleModuleReplay(ModuleProps, SlotsInValue)
                            _NetCom.ReplayTrans(IP)
                        End If
                    Case "NAME"
                        If Pars.Length = 4 Then
                            Dim ModuleName As NetHALRPC.NameModulePropsStr
                            ModuleName.IPAddr = IP.ToString
                            ModuleName.Name = Pars(3)
                            RaiseEvent NameModuleReplay(ModuleName)
                            _NetCom.ReplayTrans(IP)
                        End If
                    Case "CONF"
                        If Pars.Length = 4 Then
                            Dim ModuleName As NetHALRPC.NameModulePropsStr
                            ModuleName.IPAddr = IP.ToString
                            ModuleName.Name = Pars(3)
                            RaiseEvent ConfModuleReplay(ModuleName)
                            _NetCom.ReplayTrans(IP)
                        End If
                    Case "FUOTA"
                        If Pars.Length = 4 Then
                            Dim ModuleName As NetHALRPC.NameModulePropsStr
                            ModuleName.IPAddr = IP.ToString
                            ModuleName.Name = Pars(3)
                            RaiseEvent FuotaModuleReplay(ModuleName)
                            _NetCom.ReplayTrans(IP)
                        End If
                End Select
            End If
        End If
    End Sub

End Class
