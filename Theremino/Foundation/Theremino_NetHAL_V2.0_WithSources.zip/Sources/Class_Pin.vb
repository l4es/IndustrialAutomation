﻿
' ==================================================================================================
'   CLASS PIN
' ==================================================================================================
Class Pin

    Friend Enum Directions As Int32
        Unused = 0
        HostToModule = 1
        ModuleToHost = 2
    End Enum

    Friend Enum PinTypes As Int32
        UNUSED = 0
        ' -------------------- OUT
        DIG_OUT = 1
        PWM_8 = 2
        PWM_16 = 3
        SERVO_8 = 4
        SERVO_16 = 5
        'STEPPER = 6

        'GEN_OUT_8 = 90
        'GEN_OUT_16 = 91
        'GEN_OUT_24 = 92
        'GEN_OUT_32 = 93
        ' -------------------- IN
        DIG_IN = 129
        DIG_IN_PU = 130

        ADC_8 = 131
        ADC_16 = 132

        COUNTER = 140
        COUNTER_PU = 141
        PERIOD = 144
        PERIOD_PU = 145

        ENCODER_A = 180
        ENCODER_A_PU = 181
        ENCODER_B = 182
        ENCODER_B_PU = 183

        'GEN_IN_8 = 190
        'GEN_IN_16 = 191
        'GEN_IN_24 = 192
        'GEN_IN_32 = 193
    End Enum


    Friend Shared Function StringToPinType(ByVal PinTypeString As String) As PinTypes
        Select Case UCase(PinTypeString.Trim)
            Case "UNUSED" : Return PinTypes.UNUSED
                ' ------------------------------------------------- OUT
            Case "DIG_OUT" : Return PinTypes.DIG_OUT
            Case "PWM_8" : Return PinTypes.PWM_8
            Case "PWM_16" : Return PinTypes.PWM_16
            Case "SERVO_8" : Return PinTypes.SERVO_8
            Case "SERVO_16" : Return PinTypes.SERVO_16
                'Case "STEPPER" : Return PinTypes.STEPPER

                'Case "GEN_OUT_8" : Return PinTypes.GEN_OUT_8
                'Case "GEN_OUT_16" : Return PinTypes.GEN_OUT_16
                'Case "GEN_OUT_24" : Return PinTypes.GEN_OUT_24
                'Case "GEN_OUT_32" : Return PinTypes.GEN_OUT_32

                ' ------------------------------------------------- IN
            Case "DIG_IN" : Return PinTypes.DIG_IN
            Case "DIG_IN_PU" : Return PinTypes.DIG_IN_PU

            Case "ADC_8" : Return PinTypes.ADC_8
            Case "ADC_16" : Return PinTypes.ADC_16

            Case "COUNTER" : Return PinTypes.COUNTER
            Case "COUNTER_PU" : Return PinTypes.COUNTER_PU
            Case "PERIOD" : Return PinTypes.PERIOD
            Case "PERIOD_PU" : Return PinTypes.PERIOD_PU

                'Case "GEN_IN_8" : Return PinTypes.GEN_IN_8
                'Case "GEN_IN_16" : Return PinTypes.GEN_IN_16
                'Case "GEN_IN_24" : Return PinTypes.GEN_IN_24
                'Case "GEN_IN_32" : Return PinTypes.GEN_IN_32

            Case "ENCODER_A" : Return PinTypes.ENCODER_A
            Case "ENCODER_A_PU" : Return PinTypes.ENCODER_A_PU
            Case "ENCODER_B" : Return PinTypes.ENCODER_B
            Case "ENCODER_B_PU" : Return PinTypes.ENCODER_B_PU
        End Select
        Return Nothing
    End Function

    Friend Shared Function PinTypeToString(ByVal pintype As PinTypes) As String
        Dim s As String = ""
        Select Case pintype
            Case PinTypes.UNUSED : s = "UNUSED"
                ' ------------------------------------------------- OUT
            Case PinTypes.DIG_OUT : s = "DIG_OUT"
            Case PinTypes.PWM_8 : s = "PWM_8"
            Case PinTypes.PWM_16 : s = "PWM_16"
            Case PinTypes.SERVO_8 : s = "SERVO_8"
            Case PinTypes.SERVO_16 : s = "SERVO_16"
                'Case PinTypes.STEPPER : s = "STEPPER"

                'Case PinTypes.GEN_OUT_8 : Return "GEN_OUT_8"
                'Case PinTypes.GEN_OUT_16 : Return "GEN_OUT_16"
                'Case PinTypes.GEN_OUT_24 : Return "GEN_OUT_24"
                'Case PinTypes.GEN_OUT_32 : Return "GEN_OUT_32"

                ' ------------------------------------------------- IN
            Case PinTypes.DIG_IN : s = "DIG_IN"
            Case PinTypes.DIG_IN_PU : s = "DIG_IN_PU"

            Case PinTypes.ADC_8 : s = "ADC_8"
            Case PinTypes.ADC_16 : s = "ADC_16"

            Case PinTypes.COUNTER : s = "COUNTER"
            Case PinTypes.COUNTER_PU : s = "COUNTER_PU"
            Case PinTypes.PERIOD : s = "PERIOD"
            Case PinTypes.PERIOD_PU : s = "PERIOD_PU"

                'Case PinTypes.GEN_IN_8 : Return "GEN_IN_8"
                'Case PinTypes.GEN_IN_16 : Return "GEN_IN_16"
                'Case PinTypes.GEN_IN_24 : Return "GEN_IN_24"
                'Case PinTypes.GEN_IN_32 : Return "GEN_IN_32"

            Case PinTypes.ENCODER_A : s = "ENCODER_A"
            Case PinTypes.ENCODER_A_PU : s = "ENCODER_A_PU"
            Case PinTypes.ENCODER_B : s = "ENCODER_B"
            Case PinTypes.ENCODER_B_PU : s = "ENCODER_B_PU"
        End Select

        Return CamelCaseString(s)
    End Function



    Friend ModuleId As Int32
    Friend PinName As String
    Private PinType As PinTypes
    Friend Direction As Directions
    ' ------------------------------------------- slot 0 to 999 starting from the pin near to module
    Friend Slot As Int32
    ' ------------------------------------------- byte index in the buffer ( HostToModule or ModuleToHost )
    'Friend CommByteIndex As Int32

    ' ------------------------------------------- all pins
    Friend Value_RawInteger As Int32
    Friend Value_RawUinteger As UInt32
    Friend Value_RawUinteger_Old As UInt32
    Friend Value_RawUinteger_Zero As UInt32
    Friend Value_RawSmoothed As Single
    Friend Value_Uinteger_Max As UInt32
    Friend Value_Uinteger_Min As UInt32
    Friend Value As Single
    Friend Value_Max As Single
    Friend Value_Min As Single
    Friend Value_Parking As Single
    Friend Value_Normalized As Single = 0
    Friend Value_Normalized_New As Single
    Friend Value_Zero As Single
    Friend AdaptiveSpeed As Boolean
    Friend ResponseSpeed As Int32
    Private OldTimeMilliseconds As Double
    Private NewTimeMilliseconds As Double
    ' ------------------------------------------ Servo and Pwm specific
    Friend MaxTime As Single
    Friend MinTime As Single
    Friend LogResponse As Boolean
    ' ------------------------------------------ Counter and Period specific
    Friend ConvertToFreq As Boolean
    Friend MaxFreq As Single
    Friend MinFreq As Single
    '
    Friend Freq As Single
    '
    Friend Sub New(ByVal _pintype As PinTypes, _
                   ByVal _moduleid As Int32, _
                   ByVal _pinname As String)

        ModuleId = _moduleid
        PinName = _pinname
        SetPinType(_pintype)
    End Sub

    Friend Function GetPinType() As PinTypes
        Return PinType
    End Function


    ' ==================================================================================================
    '   DEFAULTS
    ' ==================================================================================================
    Friend Sub SetPinType(ByVal _pintype As PinTypes)
        If PinType = _pintype Then Return
        PinType = _pintype
        '
        Value_Parking = 0
        Value_Max = 1000
        Value_Min = 0
        MaxFreq = 1000
        MinFreq = 0
        AdaptiveSpeed = False
        ResponseSpeed = 100
        LogResponse = False
        ' --------------------------------------------------------- defaults
        Select Case PinType

            ' ----------------------------------------------------- outputs
            Case PinTypes.DIG_OUT

            Case PinTypes.PWM_8
                MaxTime = 4000
                MinTime = 0

            Case PinTypes.PWM_16
                MaxTime = 4000
                MinTime = 0

            Case PinTypes.SERVO_8
                Value_Parking = NAN_Sleep
                MaxTime = 2500
                MinTime = 500

            Case PinTypes.SERVO_16
                Value_Parking = NAN_Sleep
                MaxTime = 2500
                MinTime = 500

                'Case PinTypes.GEN_OUT_8
                'Case PinTypes.GEN_OUT_16
                'Case PinTypes.GEN_OUT_24
                'Case PinTypes.GEN_OUT_32

                ' ------------------------------------------------- inputs
            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                Value_Parking = 0

            Case PinTypes.ADC_8
                ResponseSpeed = 30

            Case PinTypes.ADC_16
                ResponseSpeed = 30

            Case PinTypes.COUNTER, PinTypes.COUNTER_PU

            Case PinTypes.PERIOD, PinTypes.PERIOD_PU
                ResponseSpeed = 30

                'Case PinTypes.GEN_IN_8
                'Case PinTypes.GEN_IN_16
                'Case PinTypes.GEN_IN_24
                'Case PinTypes.GEN_IN_32

            Case PinTypes.ENCODER_A, PinTypes.ENCODER_A_PU, _
                 PinTypes.ENCODER_B, PinTypes.ENCODER_B_PU

            Case PinTypes.UNUSED
                MaxTime = 1
                MinTime = 0
                Value_Parking = 0

            Case Else
                PinType = PinTypes.UNUSED
                MaxTime = 1
                MinTime = 0
                Value_Parking = 0
        End Select

        ' --------------------------------------------------------- direction
        If PinType = PinTypes.UNUSED Then
            Direction = Directions.Unused
        ElseIf PinType < 128 Then
            Direction = Directions.HostToModule
        Else
            Direction = Directions.ModuleToHost
        End If

    End Sub


    ' ==================================================================================================
    '  OUTPUTS  ( from SLOT to HARDWARE )
    ' ==================================================================================================
    Friend Sub ReadValueFromSlot()
        Value = Slots.ReadSlot(Slot)
    End Sub

    Friend Sub ConvertValueToHardwareFormat()
        Select Case PinType
            Case PinTypes.DIG_OUT, PinTypes.PWM_8, PinTypes.PWM_16, PinTypes.SERVO_8, PinTypes.SERVO_16
                'PinTypes.GEN_OUT_8, PinTypes.GEN_OUT_16, PinTypes.GEN_OUT_24, PinTypes.GEN_OUT_32
                ' -------------------------------------------------------------- min and max
                If Value_Max <> Value_Min Then
                    Value_Normalized_New = (Value - Value_Min) / (Value_Max - Value_Min)
                Else
                    Value_Normalized_New = Value
                End If
                ' -------------------------------------------------------------- limit to 0..1
                If Value_Normalized_New < 0 Then Value_Normalized_New = 0
                If Value_Normalized_New > 1 Then Value_Normalized_New = 1
                ' -------------------------------------------------------------- exponential passing by 0 and 1
                '                                                                a little less that the log base ( 2.7182 ) 
                If LogResponse AndAlso _
                   (PinType = PinTypes.PWM_8 Or PinType = PinTypes.PWM_16) Then
                    Value_Normalized_New = CSng(Value_Normalized_New ^ 2)
                End If
                ' -------------------------------------------------------------- speed 
                SmoothValue(Value_Normalized, _
                            Value_Normalized_New, _
                            ResponseSpeed, _
                            AdaptiveSpeed, _
                            InOutModules(ModuleId).CommFps)
        End Select

        Select Case PinType
            Case PinTypes.DIG_OUT
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = 0
                End If
                If Value_Normalized > 0.5 Then
                    Value_RawUinteger = 1
                Else
                    Value_RawUinteger = 0
                End If

            Case PinTypes.PWM_8, PinTypes.PWM_16
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = If(Value_Max > Value_Min, 0, 1)
                    Value_RawUinteger = 0
                Else
                    Value_RawUinteger = CUInt(16.384F * (Value_Normalized * (MaxTime - MinTime) + MinTime))
                End If
                If Value_RawUinteger < 0 Then Value_RawUinteger = 0
                If Value_RawUinteger > 65535 Then Value_RawUinteger = 65535

            Case PinTypes.SERVO_8, PinTypes.SERVO_16
                If Single.IsNaN(Value_Normalized) Then
                    Value_Normalized = If(Value_Max > Value_Min, 0, 1)
                    Value_RawUinteger = 0
                Else
                    Value_RawUinteger = CUInt(16.384F * (Value_Normalized * (MaxTime - MinTime) + MinTime))
                End If
                If Value_RawUinteger < 0 Then Value_RawUinteger = 0
                If Value_RawUinteger > 65535 Then Value_RawUinteger = 65535

                'Case GEN_OUT_8 GEN_OUT_16 GEN_OUT_24 GEN_OUT_32 ' <-- Nothing to do
        End Select
    End Sub


    ' ==================================================================================================
    '  INPUTS  ( from HARDWARE to SLOT )
    ' ==================================================================================================
    Friend Sub ConvertValueFromHardwareFormat()

        Select Case PinType
            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                Value_RawUinteger = If(Value_RawUinteger <> 0, 1UI, 0UI)
                Value_Normalized_New = Value_RawUinteger

            Case PinTypes.ADC_8
                Value_Normalized_New = Value_RawUinteger / 255.0F

            Case PinTypes.ADC_16
                Value_Normalized_New = Value_RawUinteger / 65535.0F

                'Case PinTypes.COUNTER, PinTypes.COUNTER_PU  ' <-- Nothing to do
                'Case PinTypes.PERIOD, PinTypes.PERIOD_PU    ' <-- Nothing to do
                'Case PinTypes.GEN_IN_8, PinTypes.GEN_IN_16  ' <-- Nothing to do
                'Case PinTypes.GEN_IN_24, PinTypes.GEN_IN_32 ' <-- Nothing to do

                'Case PinTypes.ENCODER_A, PinTypes.ENCODER_A_PU ' <-- Nothing to do
                'Case PinTypes.ENCODER_B, PinTypes.ENCODER_B_PU ' <-- Nothing to do
        End Select


        Select Case PinType

            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU, PinTypes.ADC_8, PinTypes.ADC_16
                ' ------------------------------------------------------------------ limit to 0..1
                If Value_Normalized_New < 0 Then Value_Normalized_New = 0
                If Value_Normalized_New > 1 Then Value_Normalized_New = 1
                ' -------------------------------------------------------------- speed 
                SmoothValue(Value_Normalized, _
                            Value_Normalized_New, _
                            ResponseSpeed, _
                            AdaptiveSpeed, _
                            InOutModules(ModuleId).CommFps)
                ' ------------------------------------------------------------------ min and max
                Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min


            Case PinTypes.COUNTER, PinTypes.COUNTER_PU
                If ConvertToFreq Then
                    ' ------------------------------------------------------------------ delta time
                    NewTimeMilliseconds = FreeRunningTimer.Elapsed.TotalMilliseconds
                    Dim dt As Double = NewTimeMilliseconds - OldTimeMilliseconds
                    ' ------------------------------------------------------------------ update every 100 mS
                    Dim SamplingTimeMs As Double = 100000 / MaxFreq
                    If SamplingTimeMs > 1000 Then SamplingTimeMs = 1000
                    If SamplingTimeMs < 10 Then SamplingTimeMs = 10
                    If dt >= SamplingTimeMs Then
                        ' -------------------------------------------------------------- delta counts
                        Dim diff As UInt32
                        If Value_RawUinteger >= Value_RawUinteger_Old Then
                            diff = Value_RawUinteger - Value_RawUinteger_Old
                        Else
                            diff = (&HFFFFUI - Value_RawUinteger_Old) + Value_RawUinteger + 1UI
                        End If
                        Value_RawUinteger_Old = Value_RawUinteger
                        ' -------------------------------------------------------------- frequency
                        If Value_RawUinteger > 0 AndAlso dt > 0 Then
                            Freq = CSng(1000 * diff / dt)
                        Else
                            Freq = 0
                        End If
                        OldTimeMilliseconds = NewTimeMilliseconds
                    End If
                    ' ------------------------------------------------------------------ range
                    Dim range As Double = MaxFreq - MinFreq
                    If range < 0.1 Then range = 0.1
                    Value_Normalized_New = CSng((Freq - MinFreq) / range)
                    ' ------------------------------------------------------------------ speed
                    SmoothValue(Value_Normalized, _
                                Value_Normalized_New, _
                                ResponseSpeed, _
                                AdaptiveSpeed, _
                                InOutModules(ModuleId).CommFps)
                    ' ------------------------------------------------------------------ min and max
                    Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                Else
                    Value_Normalized_New = Value_RawUinteger / 65535.0F
                    Value_Normalized = Value_Normalized_New
                    Value = Value_RawUinteger
                End If

            Case PinTypes.PERIOD, PinTypes.PERIOD_PU
                If ConvertToFreq Then
                    ' -------------------------------------------------------------- range
                    If Value_RawUinteger > 0 Then
                        Freq = 312500.0F / Value_RawUinteger
                    Else
                        Freq = 0
                    End If
                    Dim range As Double = MaxFreq - MinFreq
                    If range < 0.1 Then range = 0.1
                    Value_Normalized_New = CSng((Freq - MinFreq) / range)
                    ' -------------------------------------------------------------- speed 
                    SmoothValue(Value_Normalized, _
                                Value_Normalized_New, _
                                ResponseSpeed, _
                                AdaptiveSpeed, _
                                InOutModules(ModuleId).CommFps)
                    ' -------------------------------------------------------------- min and max
                    Value = Value_Normalized * (Value_Max - Value_Min) + Value_Min
                Else
                    Value_Normalized_New = Value_RawUinteger / 16777215.0F / 2.0F
                    Value_Normalized = Value_Normalized_New
                    Value = Value_RawUinteger
                End If

                'Case PinTypes.GEN_IN_8
                '    Value_Normalized_New = Value_RawUinteger / 255.0F
                '    Value_Normalized = Value_Normalized_New
                '    Value = Value_RawUinteger
                'Case PinTypes.GEN_IN_16
                '    Value_Normalized_New = Value_RawUinteger / 65535.0F
                '    Value_Normalized = Value_Normalized_New
                '    Value = Value_RawUinteger
                'Case PinTypes.GEN_IN_24
                '    Value_Normalized_New = Value_RawUinteger / 15777216.0F
                '    Value_Normalized = Value_Normalized_New
                '    Value = Value_RawUinteger
                'Case PinTypes.GEN_IN_32
                '    Value_Normalized_New = Value_RawUinteger / 4.2949673E+9F
                '    Value_Normalized = Value_Normalized_New
                '    Value = Value_RawUinteger

            Case PinTypes.ENCODER_A, PinTypes.ENCODER_A_PU
                Value_Normalized_New = Value_RawUinteger / 65535.0F
                Value_Normalized = Value_Normalized_New
                Value = Value_RawUinteger

            Case PinTypes.ENCODER_B, PinTypes.ENCODER_B_PU
                Value_Normalized_New = Value_RawUinteger / 65535.0F
                Value_Normalized = Value_Normalized_New
                Value = Value_RawUinteger
        End Select
    End Sub

    Friend Sub WriteValueToSlot()
        Slots.WriteSlot(Slot, CSng(Value))
    End Sub


    ' ==================================================================================================
    '   HELPER FUNCTIONS
    ' ==================================================================================================
    Friend Sub CalibrateZero()
        Value_RawUinteger_Zero = Value_RawUinteger
        Value_Zero = Value
    End Sub

    Friend Function GetValueString() As String
        Dim ci As Globalization.CultureInfo = New Globalization.CultureInfo("en-GB")
        Select Case PinType

            ' ------------------------------------------------------------------------- OUTPUTS
            Case PinTypes.DIG_OUT
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value.ToString("0") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("0")

            Case PinTypes.SERVO_8, PinTypes.SERVO_16
                If Single.IsNaN(Value) Then
                    Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & "Sleep" & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("0")
                Else
                    Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value.ToString("0") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("0")
                End If

            Case PinTypes.PWM_8, PinTypes.PWM_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        " Slot: " & Value.ToString("0") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("0")

                'Case PinTypes.GEN_OUT_8, PinTypes.GEN_OUT_16, PinTypes.GEN_OUT_24, PinTypes.GEN_OUT_32
                '    Return PinTypeToString(PinType) & vbCrLf & _
                '            "--------------" & vbCrLf & _
                '            " Slot: " & Value.ToString("0") & vbCrLf & _
                '            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                '            "  Raw: " & Value_RawUinteger.ToString("0")

                ' --------------------------------------------------------------------- INPUTS 
            Case PinTypes.DIG_IN, PinTypes.DIG_IN_PU
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("0") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.ADC_8, PinTypes.ADC_16
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("0.00", ci)

            Case PinTypes.COUNTER, PinTypes.COUNTER_PU, _
                 PinTypes.PERIOD, PinTypes.PERIOD_PU
                If ConvertToFreq Then
                    Return PinTypeToString(PinType) & vbCrLf & _
                            "--------------" & vbCrLf & _
                            "  Raw: " & Value_RawUinteger.ToString("00000") & vbCrLf & _
                            " Freq: " & Freq.ToString("00000") & vbCrLf & _
                            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                            " Slot: " & Value.ToString("0.00", ci)
                Else
                    Return PinTypeToString(PinType) & vbCrLf & _
                            "--------------" & vbCrLf & _
                            "  Raw: " & Value_RawUinteger.ToString("00000") & vbCrLf & _
                            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                            " Slot: " & Value.ToString("00000")
                End If

                'Case PinTypes.GEN_IN_8, PinTypes.GEN_IN_16, PinTypes.GEN_IN_24, PinTypes.GEN_IN_32
                '    Return PinTypeToString(PinType) & vbCrLf & _
                '            "--------------" & vbCrLf & _
                '            "  Raw: " & Value_RawUinteger.ToString("00000") & vbCrLf & _
                '            " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                '            " Slot: " & Value.ToString("00000")


            Case PinTypes.ENCODER_A, PinTypes.ENCODER_A_PU
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("00000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("00000")

            Case PinTypes.ENCODER_B, PinTypes.ENCODER_B_PU
                Return PinTypeToString(PinType) & vbCrLf & _
                        "--------------" & vbCrLf & _
                        "  Raw: " & Value_RawUinteger.ToString("00000") & vbCrLf & _
                        " Norm: " & Value_Normalized.ToString("0.00", ci) & vbCrLf & _
                        " Slot: " & Value.ToString("00000")

                ' --------------------------------------------------------------------- 
            Case Else
                Return PinTypeToString(PinType)

        End Select
        Return ""
    End Function

End Class


