﻿Imports System.Drawing.Drawing2D

Friend Class VuMeter
    Private w As Int32
    Private h As Int32
    Private b1 As Drawing2D.LinearGradientBrush
    Private b2 As Brush
    Private g As Graphics

    Friend Sub Draw(ByVal pbox As PictureBox, _
                    ByVal value As Double, _
                    Optional ByVal MarkPoint1 As Double = 0, _
                    Optional ByVal MarkPoint2 As Double = 0)

        ' ----------------------------------------------------------- 
        If Not pbox.Visible Then Exit Sub
        ' ----------------------------------------------------------- 
        If pbox.Image Is Nothing OrElse pbox.ClientSize.Width <> w OrElse pbox.ClientSize.Height <> h Then
            w = pbox.ClientSize.Width
            h = pbox.ClientSize.Height
            pbox.Image = New Bitmap(w, h)
            g = Graphics.FromImage(pbox.Image)
            b1 = CreateFillBrush(pbox, If(w > h, LinearGradientMode.Horizontal, LinearGradientMode.Vertical))
            b2 = New SolidBrush(pbox.BackColor)
        End If
        ' ----------------------------------------------------------- 
        If value < 0 Then value = 0
        If value > 1 Then value = 1

        ' ----------------------------------------------------------- 
        If w > h Then
            Dim v As Int32 = CInt(value * w)
            g.FillRectangle(b1, 0, 0, v, h)
            g.FillRectangle(b2, v, 0, w, h)
            ' ----------------------------------------------------------- mark line
            If MarkPoint1 > 0 Then
                v = CInt(MarkPoint1 * pbox.Width)
                g.DrawLine(Pens.Black, v, 0, v, h)
            End If
            If MarkPoint2 > 0 Then
                v = CInt(MarkPoint2 * pbox.Width)
                g.DrawLine(Pens.Black, v, 0, v, h)
            End If
        Else
            Dim v As Int32 = CInt(value * h)
            g.FillRectangle(b1, 0, h - v, w, h)
            g.FillRectangle(b2, 0, 0, w, h - v)
            ' ----------------------------------------------------------- mark line
            If MarkPoint1 > 0 Then
                v = CInt(MarkPoint1 * pbox.Height)
                g.DrawLine(Pens.Black, 0, h - v, w, h - v)
            End If
            If MarkPoint2 > 0 Then
                v = CInt(MarkPoint2 * pbox.Height)
                g.DrawLine(Pens.Black, 0, h - v, w, h - v)
            End If
        End If
        ' --------------------------------------------------------------- text init
        Dim rec As Rectangle
        Dim s As String = ""
        Dim f As Font
        'Dim fontsize As Single = pbox.ClientSize.Height - 2
        Dim fontsize As Single = 12
        f = New Font("Tahoma", fontsize, FontStyle.Regular, GraphicsUnit.Pixel)
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAliasGridFit
        Dim stringFormat As New StringFormat()
        stringFormat.Alignment = StringAlignment.Far
        stringFormat.LineAlignment = StringAlignment.Center
        ' --------------------------------------------------------------- text
        If value < MarkPoint1 Then
            rec = New Rectangle(0, 0, CInt(pbox.Width * 0.35), pbox.Height - 3)
            g.DrawString("Signal is low", f, Brushes.Red, rec, stringFormat)
        ElseIf value > MarkPoint2 Then
            rec = New Rectangle(0, 0, CInt(pbox.Width * 0.96), pbox.Height - 3)
            g.DrawString("Too high", f, Brushes.Black, rec, stringFormat)
        Else
            rec = New Rectangle(0, 0, CInt(pbox.Width * 0.7), pbox.Height - 3)
            g.DrawString("Signal OK", f, Brushes.Black, rec, stringFormat)
        End If
        ' ---------------------------------------------------------------- final refresh - no flickering
        pbox.Refresh()
    End Sub

    Private Function CreateFillBrush(ByVal pbox As PictureBox, _
                             ByVal direction As LinearGradientMode) As LinearGradientBrush
        CreateFillBrush = New LinearGradientBrush(pbox.ClientRectangle, _
                                                  Color.Black, _
                                                  Color.Black, _
                                                  direction)
        Dim myBlend As ColorBlend = New ColorBlend()
        If direction = LinearGradientMode.Vertical Then
            myBlend.Colors = New Color() {Color.FromArgb(255, 0, 0), _
                                          Color.FromArgb(255, 200, 0), _
                                          Color.FromArgb(100, 255, 0)}
        Else
            myBlend.Colors = New Color() {Color.FromArgb(100, 255, 0), _
                                          Color.FromArgb(255, 200, 0), _
                                          Color.FromArgb(255, 0, 0)}
        End If
        myBlend.Positions = New Single() {0.0F, 0.5F, 1.0F}
        CreateFillBrush.InterpolationColors = myBlend
    End Function

    Private Function VoltToDecibel(ByRef v As Double) As Double
        VoltToDecibel = 20 * Math.Log(v, 10)
    End Function


End Class
