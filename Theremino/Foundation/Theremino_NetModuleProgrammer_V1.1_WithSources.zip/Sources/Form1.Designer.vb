﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ListBox_Modules = New System.Windows.Forms.ListBox
        Me.btn_Execute = New System.Windows.Forms.Button
        Me.txt_ApplicationUdpPort = New System.Windows.Forms.TextBox
        Me.lbl_ApplicationUdpPort = New System.Windows.Forms.Label
        Me.btn_Scan = New System.Windows.Forms.Button
        Me.ListBox_Replay = New System.Windows.Forms.ListBox
        Me.TabControl1 = New Theremino_NetModuleProgrammer.MyTabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.lbl_WiFiNetworkMode = New System.Windows.Forms.Label
        Me.chk_AdvancedMode = New System.Windows.Forms.CheckBox
        Me.cmb_WiFiNetworkMode = New System.Windows.Forms.ComboBox
        Me.lbl_WifiNetworkName = New System.Windows.Forms.Label
        Me.txt_WiFiNetworkName = New System.Windows.Forms.TextBox
        Me.lbl_CommFaultDelay = New System.Windows.Forms.Label
        Me.txt_CommFaultDelay = New System.Windows.Forms.TextBox
        Me.txt_CPUFreq = New System.Windows.Forms.TextBox
        Me.lbl_WiFiNetworkPassword = New System.Windows.Forms.Label
        Me.txt_StaticDNS1 = New System.Windows.Forms.TextBox
        Me.lbl_CPUFreq = New System.Windows.Forms.Label
        Me.lbl_StaticDNS1 = New System.Windows.Forms.Label
        Me.txt_WiFiNetworkPassword = New System.Windows.Forms.TextBox
        Me.txt_StaticDNS0 = New System.Windows.Forms.TextBox
        Me.lbl_UdpPort = New System.Windows.Forms.Label
        Me.lbl_StaticDNS0 = New System.Windows.Forms.Label
        Me.txt_UdpPort = New System.Windows.Forms.TextBox
        Me.txt_StaticGateway = New System.Windows.Forms.TextBox
        Me.lbl_WiFiChannel = New System.Windows.Forms.Label
        Me.lbl_StaticGateway = New System.Windows.Forms.Label
        Me.txt_WiFiChannel = New System.Windows.Forms.TextBox
        Me.txt_StaticNetworkMask = New System.Windows.Forms.TextBox
        Me.txt_CommFaultUseD0 = New System.Windows.Forms.TextBox
        Me.lbl_StaticNetworkMask = New System.Windows.Forms.Label
        Me.txt_StaticNetworkIP = New System.Windows.Forms.TextBox
        Me.lbl_CommFaultUseD0 = New System.Windows.Forms.Label
        Me.lbl_StaticNetworkIP = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btn_OpenFirmwareFolder = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txt_HttpServerPort = New System.Windows.Forms.TextBox
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.btn_OpenUsbFirmwareFolder = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Timer1Hz = New System.Windows.Forms.Timer(Me.components)
        Me.Timer10Hz = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox_Modules
        '
        Me.ListBox_Modules.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ListBox_Modules.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ListBox_Modules.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox_Modules.ForeColor = System.Drawing.Color.Black
        Me.ListBox_Modules.ItemHeight = 16
        Me.ListBox_Modules.Location = New System.Drawing.Point(8, 316)
        Me.ListBox_Modules.Name = "ListBox_Modules"
        Me.ListBox_Modules.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox_Modules.Size = New System.Drawing.Size(395, 148)
        Me.ListBox_Modules.TabIndex = 150
        '
        'btn_Execute
        '
        Me.btn_Execute.BackColor = System.Drawing.Color.LightYellow
        Me.btn_Execute.FlatAppearance.MouseOverBackColor = System.Drawing.Color.GreenYellow
        Me.btn_Execute.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Execute.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Execute.ForeColor = System.Drawing.Color.Black
        Me.btn_Execute.Location = New System.Drawing.Point(488, 384)
        Me.btn_Execute.Name = "btn_Execute"
        Me.btn_Execute.Size = New System.Drawing.Size(175, 80)
        Me.btn_Execute.TabIndex = 190
        Me.btn_Execute.Text = "EXECUTE"
        Me.btn_Execute.UseVisualStyleBackColor = False
        '
        'txt_ApplicationUdpPort
        '
        Me.txt_ApplicationUdpPort.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ApplicationUdpPort.Location = New System.Drawing.Point(539, 345)
        Me.txt_ApplicationUdpPort.MaxLength = 5
        Me.txt_ApplicationUdpPort.Name = "txt_ApplicationUdpPort"
        Me.txt_ApplicationUdpPort.Size = New System.Drawing.Size(72, 26)
        Me.txt_ApplicationUdpPort.TabIndex = 180
        Me.txt_ApplicationUdpPort.Text = "49152"
        Me.txt_ApplicationUdpPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_ApplicationUdpPort
        '
        Me.lbl_ApplicationUdpPort.AutoSize = True
        Me.lbl_ApplicationUdpPort.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ApplicationUdpPort.Location = New System.Drawing.Point(499, 321)
        Me.lbl_ApplicationUdpPort.Name = "lbl_ApplicationUdpPort"
        Me.lbl_ApplicationUdpPort.Size = New System.Drawing.Size(150, 18)
        Me.lbl_ApplicationUdpPort.TabIndex = 999
        Me.lbl_ApplicationUdpPort.Text = "Communication Port"
        '
        'btn_Scan
        '
        Me.btn_Scan.BackColor = System.Drawing.Color.LightYellow
        Me.btn_Scan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btn_Scan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Scan.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Scan.Location = New System.Drawing.Point(409, 316)
        Me.btn_Scan.Name = "btn_Scan"
        Me.btn_Scan.Size = New System.Drawing.Size(73, 148)
        Me.btn_Scan.TabIndex = 160
        Me.btn_Scan.Text = "Scan"
        Me.btn_Scan.UseVisualStyleBackColor = False
        '
        'ListBox_Replay
        '
        Me.ListBox_Replay.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ListBox_Replay.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox_Replay.HorizontalScrollbar = True
        Me.ListBox_Replay.IntegralHeight = False
        Me.ListBox_Replay.ItemHeight = 22
        Me.ListBox_Replay.Location = New System.Drawing.Point(381, 313)
        Me.ListBox_Replay.Name = "ListBox_Replay"
        Me.ListBox_Replay.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox_Replay.Size = New System.Drawing.Size(113, 38)
        Me.ListBox_Replay.TabIndex = 1012
        Me.ListBox_Replay.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.BackColor_Selected1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabControl1.BackColor_Selected2 = System.Drawing.Color.DarkKhaki
        Me.TabControl1.BackColor_UnSelected = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabControl1.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ForeColor_Selected = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabControl1.ForeColor_Unselected = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.ItemSize = New System.Drawing.Size(200, 28)
        Me.TabControl1.Location = New System.Drawing.Point(3, 5)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShadowColor_Selected = System.Drawing.Color.Transparent
        Me.TabControl1.ShadowColor_Unselected = System.Drawing.Color.Transparent
        Me.TabControl1.Size = New System.Drawing.Size(665, 302)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.lbl_WiFiNetworkMode)
        Me.TabPage1.Controls.Add(Me.chk_AdvancedMode)
        Me.TabPage1.Controls.Add(Me.cmb_WiFiNetworkMode)
        Me.TabPage1.Controls.Add(Me.lbl_WifiNetworkName)
        Me.TabPage1.Controls.Add(Me.txt_WiFiNetworkName)
        Me.TabPage1.Controls.Add(Me.lbl_CommFaultDelay)
        Me.TabPage1.Controls.Add(Me.txt_CommFaultDelay)
        Me.TabPage1.Controls.Add(Me.txt_CPUFreq)
        Me.TabPage1.Controls.Add(Me.lbl_WiFiNetworkPassword)
        Me.TabPage1.Controls.Add(Me.txt_StaticDNS1)
        Me.TabPage1.Controls.Add(Me.lbl_CPUFreq)
        Me.TabPage1.Controls.Add(Me.lbl_StaticDNS1)
        Me.TabPage1.Controls.Add(Me.txt_WiFiNetworkPassword)
        Me.TabPage1.Controls.Add(Me.txt_StaticDNS0)
        Me.TabPage1.Controls.Add(Me.lbl_UdpPort)
        Me.TabPage1.Controls.Add(Me.lbl_StaticDNS0)
        Me.TabPage1.Controls.Add(Me.txt_UdpPort)
        Me.TabPage1.Controls.Add(Me.txt_StaticGateway)
        Me.TabPage1.Controls.Add(Me.lbl_WiFiChannel)
        Me.TabPage1.Controls.Add(Me.lbl_StaticGateway)
        Me.TabPage1.Controls.Add(Me.txt_WiFiChannel)
        Me.TabPage1.Controls.Add(Me.txt_StaticNetworkMask)
        Me.TabPage1.Controls.Add(Me.txt_CommFaultUseD0)
        Me.TabPage1.Controls.Add(Me.lbl_StaticNetworkMask)
        Me.TabPage1.Controls.Add(Me.txt_StaticNetworkIP)
        Me.TabPage1.Controls.Add(Me.lbl_CommFaultUseD0)
        Me.TabPage1.Controls.Add(Me.lbl_StaticNetworkIP)
        Me.TabPage1.Location = New System.Drawing.Point(4, 32)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(657, 266)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Send Options"
        '
        'lbl_WiFiNetworkMode
        '
        Me.lbl_WiFiNetworkMode.AutoSize = True
        Me.lbl_WiFiNetworkMode.BackColor = System.Drawing.Color.Transparent
        Me.lbl_WiFiNetworkMode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_WiFiNetworkMode.ForeColor = System.Drawing.Color.Black
        Me.lbl_WiFiNetworkMode.Location = New System.Drawing.Point(86, 12)
        Me.lbl_WiFiNetworkMode.Name = "lbl_WiFiNetworkMode"
        Me.lbl_WiFiNetworkMode.Size = New System.Drawing.Size(146, 18)
        Me.lbl_WiFiNetworkMode.TabIndex = 999
        Me.lbl_WiFiNetworkMode.Text = "WiFi Network Mode"
        '
        'chk_AdvancedMode
        '
        Me.chk_AdvancedMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_AdvancedMode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_AdvancedMode.Location = New System.Drawing.Point(392, 10)
        Me.chk_AdvancedMode.Name = "chk_AdvancedMode"
        Me.chk_AdvancedMode.Size = New System.Drawing.Size(143, 22)
        Me.chk_AdvancedMode.TabIndex = 170
        Me.chk_AdvancedMode.Text = "Advanced Mode"
        Me.chk_AdvancedMode.UseVisualStyleBackColor = True
        '
        'cmb_WiFiNetworkMode
        '
        Me.cmb_WiFiNetworkMode.BackColor = System.Drawing.Color.White
        Me.cmb_WiFiNetworkMode.DropDownHeight = 500
        Me.cmb_WiFiNetworkMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_WiFiNetworkMode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_WiFiNetworkMode.ForeColor = System.Drawing.Color.Black
        Me.cmb_WiFiNetworkMode.FormattingEnabled = True
        Me.cmb_WiFiNetworkMode.IntegralHeight = False
        Me.cmb_WiFiNetworkMode.Items.AddRange(New Object() {"SoftAP", "Station DHCP", "Station Static"})
        Me.cmb_WiFiNetworkMode.Location = New System.Drawing.Point(242, 8)
        Me.cmb_WiFiNetworkMode.Name = "cmb_WiFiNetworkMode"
        Me.cmb_WiFiNetworkMode.Size = New System.Drawing.Size(132, 26)
        Me.cmb_WiFiNetworkMode.TabIndex = 10
        '
        'lbl_WifiNetworkName
        '
        Me.lbl_WifiNetworkName.AutoSize = True
        Me.lbl_WifiNetworkName.BackColor = System.Drawing.Color.Transparent
        Me.lbl_WifiNetworkName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_WifiNetworkName.ForeColor = System.Drawing.Color.Black
        Me.lbl_WifiNetworkName.Location = New System.Drawing.Point(14, 47)
        Me.lbl_WifiNetworkName.Name = "lbl_WifiNetworkName"
        Me.lbl_WifiNetworkName.Size = New System.Drawing.Size(148, 18)
        Me.lbl_WifiNetworkName.TabIndex = 999
        Me.lbl_WifiNetworkName.Text = "WiFi Network Name"
        '
        'txt_WiFiNetworkName
        '
        Me.txt_WiFiNetworkName.BackColor = System.Drawing.Color.White
        Me.txt_WiFiNetworkName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_WiFiNetworkName.ForeColor = System.Drawing.Color.Black
        Me.txt_WiFiNetworkName.Location = New System.Drawing.Point(209, 43)
        Me.txt_WiFiNetworkName.MaxLength = 31
        Me.txt_WiFiNetworkName.Name = "txt_WiFiNetworkName"
        Me.txt_WiFiNetworkName.Size = New System.Drawing.Size(432, 26)
        Me.txt_WiFiNetworkName.TabIndex = 20
        Me.txt_WiFiNetworkName.Text = "name"
        '
        'lbl_CommFaultDelay
        '
        Me.lbl_CommFaultDelay.AutoSize = True
        Me.lbl_CommFaultDelay.BackColor = System.Drawing.Color.Transparent
        Me.lbl_CommFaultDelay.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CommFaultDelay.ForeColor = System.Drawing.Color.Black
        Me.lbl_CommFaultDelay.Location = New System.Drawing.Point(14, 201)
        Me.lbl_CommFaultDelay.Name = "lbl_CommFaultDelay"
        Me.lbl_CommFaultDelay.Size = New System.Drawing.Size(175, 18)
        Me.lbl_CommFaultDelay.TabIndex = 999
        Me.lbl_CommFaultDelay.Text = "Comm Fault Delay (mS)"
        '
        'txt_CommFaultDelay
        '
        Me.txt_CommFaultDelay.BackColor = System.Drawing.Color.White
        Me.txt_CommFaultDelay.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CommFaultDelay.ForeColor = System.Drawing.Color.Black
        Me.txt_CommFaultDelay.Location = New System.Drawing.Point(209, 197)
        Me.txt_CommFaultDelay.MaxLength = 5
        Me.txt_CommFaultDelay.Name = "txt_CommFaultDelay"
        Me.txt_CommFaultDelay.Size = New System.Drawing.Size(82, 26)
        Me.txt_CommFaultDelay.TabIndex = 70
        Me.txt_CommFaultDelay.Text = "200"
        Me.txt_CommFaultDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_CPUFreq
        '
        Me.txt_CPUFreq.BackColor = System.Drawing.Color.White
        Me.txt_CPUFreq.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CPUFreq.ForeColor = System.Drawing.Color.Black
        Me.txt_CPUFreq.Location = New System.Drawing.Point(209, 227)
        Me.txt_CPUFreq.MaxLength = 3
        Me.txt_CPUFreq.Name = "txt_CPUFreq"
        Me.txt_CPUFreq.Size = New System.Drawing.Size(82, 26)
        Me.txt_CPUFreq.TabIndex = 75
        Me.txt_CPUFreq.Text = "160"
        Me.txt_CPUFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_WiFiNetworkPassword
        '
        Me.lbl_WiFiNetworkPassword.AutoSize = True
        Me.lbl_WiFiNetworkPassword.BackColor = System.Drawing.Color.Transparent
        Me.lbl_WiFiNetworkPassword.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_WiFiNetworkPassword.ForeColor = System.Drawing.Color.Black
        Me.lbl_WiFiNetworkPassword.Location = New System.Drawing.Point(14, 77)
        Me.lbl_WiFiNetworkPassword.Name = "lbl_WiFiNetworkPassword"
        Me.lbl_WiFiNetworkPassword.Size = New System.Drawing.Size(176, 18)
        Me.lbl_WiFiNetworkPassword.TabIndex = 999
        Me.lbl_WiFiNetworkPassword.Text = "WiFi Network Password"
        '
        'txt_StaticDNS1
        '
        Me.txt_StaticDNS1.BackColor = System.Drawing.Color.White
        Me.txt_StaticDNS1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StaticDNS1.ForeColor = System.Drawing.Color.Black
        Me.txt_StaticDNS1.Location = New System.Drawing.Point(512, 227)
        Me.txt_StaticDNS1.MaxLength = 15
        Me.txt_StaticDNS1.Name = "txt_StaticDNS1"
        Me.txt_StaticDNS1.Size = New System.Drawing.Size(129, 26)
        Me.txt_StaticDNS1.TabIndex = 120
        Me.txt_StaticDNS1.Text = "208.67.220.220"
        Me.txt_StaticDNS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_CPUFreq
        '
        Me.lbl_CPUFreq.AutoSize = True
        Me.lbl_CPUFreq.BackColor = System.Drawing.Color.Transparent
        Me.lbl_CPUFreq.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CPUFreq.ForeColor = System.Drawing.Color.Black
        Me.lbl_CPUFreq.Location = New System.Drawing.Point(14, 231)
        Me.lbl_CPUFreq.Name = "lbl_CPUFreq"
        Me.lbl_CPUFreq.Size = New System.Drawing.Size(182, 18)
        Me.lbl_CPUFreq.TabIndex = 1011
        Me.lbl_CPUFreq.Text = "CPU Frequency (80/160)"
        '
        'lbl_StaticDNS1
        '
        Me.lbl_StaticDNS1.AutoSize = True
        Me.lbl_StaticDNS1.BackColor = System.Drawing.Color.Transparent
        Me.lbl_StaticDNS1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaticDNS1.ForeColor = System.Drawing.Color.Black
        Me.lbl_StaticDNS1.Location = New System.Drawing.Point(358, 231)
        Me.lbl_StaticDNS1.Name = "lbl_StaticDNS1"
        Me.lbl_StaticDNS1.Size = New System.Drawing.Size(99, 18)
        Me.lbl_StaticDNS1.TabIndex = 999
        Me.lbl_StaticDNS1.Text = "Static DNS 1"
        '
        'txt_WiFiNetworkPassword
        '
        Me.txt_WiFiNetworkPassword.BackColor = System.Drawing.Color.White
        Me.txt_WiFiNetworkPassword.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_WiFiNetworkPassword.ForeColor = System.Drawing.Color.Black
        Me.txt_WiFiNetworkPassword.Location = New System.Drawing.Point(209, 73)
        Me.txt_WiFiNetworkPassword.MaxLength = 31
        Me.txt_WiFiNetworkPassword.Name = "txt_WiFiNetworkPassword"
        Me.txt_WiFiNetworkPassword.Size = New System.Drawing.Size(432, 26)
        Me.txt_WiFiNetworkPassword.TabIndex = 30
        Me.txt_WiFiNetworkPassword.Text = "password"
        '
        'txt_StaticDNS0
        '
        Me.txt_StaticDNS0.BackColor = System.Drawing.Color.White
        Me.txt_StaticDNS0.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StaticDNS0.ForeColor = System.Drawing.Color.Black
        Me.txt_StaticDNS0.Location = New System.Drawing.Point(512, 197)
        Me.txt_StaticDNS0.MaxLength = 15
        Me.txt_StaticDNS0.Name = "txt_StaticDNS0"
        Me.txt_StaticDNS0.Size = New System.Drawing.Size(129, 26)
        Me.txt_StaticDNS0.TabIndex = 110
        Me.txt_StaticDNS0.Text = "208.67.222.222"
        Me.txt_StaticDNS0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_UdpPort
        '
        Me.lbl_UdpPort.AutoSize = True
        Me.lbl_UdpPort.BackColor = System.Drawing.Color.Transparent
        Me.lbl_UdpPort.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_UdpPort.ForeColor = System.Drawing.Color.Black
        Me.lbl_UdpPort.Location = New System.Drawing.Point(14, 111)
        Me.lbl_UdpPort.Name = "lbl_UdpPort"
        Me.lbl_UdpPort.Size = New System.Drawing.Size(75, 18)
        Me.lbl_UdpPort.TabIndex = 999
        Me.lbl_UdpPort.Text = "UDP Port"
        '
        'lbl_StaticDNS0
        '
        Me.lbl_StaticDNS0.AutoSize = True
        Me.lbl_StaticDNS0.BackColor = System.Drawing.Color.Transparent
        Me.lbl_StaticDNS0.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaticDNS0.ForeColor = System.Drawing.Color.Black
        Me.lbl_StaticDNS0.Location = New System.Drawing.Point(358, 201)
        Me.lbl_StaticDNS0.Name = "lbl_StaticDNS0"
        Me.lbl_StaticDNS0.Size = New System.Drawing.Size(99, 18)
        Me.lbl_StaticDNS0.TabIndex = 999
        Me.lbl_StaticDNS0.Text = "Static DNS 0"
        '
        'txt_UdpPort
        '
        Me.txt_UdpPort.BackColor = System.Drawing.Color.White
        Me.txt_UdpPort.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_UdpPort.ForeColor = System.Drawing.Color.Black
        Me.txt_UdpPort.Location = New System.Drawing.Point(209, 107)
        Me.txt_UdpPort.MaxLength = 5
        Me.txt_UdpPort.Name = "txt_UdpPort"
        Me.txt_UdpPort.Size = New System.Drawing.Size(82, 26)
        Me.txt_UdpPort.TabIndex = 40
        Me.txt_UdpPort.Text = "49152"
        Me.txt_UdpPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_StaticGateway
        '
        Me.txt_StaticGateway.BackColor = System.Drawing.Color.White
        Me.txt_StaticGateway.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StaticGateway.ForeColor = System.Drawing.Color.Black
        Me.txt_StaticGateway.Location = New System.Drawing.Point(512, 167)
        Me.txt_StaticGateway.MaxLength = 15
        Me.txt_StaticGateway.Name = "txt_StaticGateway"
        Me.txt_StaticGateway.Size = New System.Drawing.Size(129, 26)
        Me.txt_StaticGateway.TabIndex = 100
        Me.txt_StaticGateway.Text = "192.168.0.254"
        Me.txt_StaticGateway.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_WiFiChannel
        '
        Me.lbl_WiFiChannel.AutoSize = True
        Me.lbl_WiFiChannel.BackColor = System.Drawing.Color.Transparent
        Me.lbl_WiFiChannel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_WiFiChannel.ForeColor = System.Drawing.Color.Black
        Me.lbl_WiFiChannel.Location = New System.Drawing.Point(14, 141)
        Me.lbl_WiFiChannel.Name = "lbl_WiFiChannel"
        Me.lbl_WiFiChannel.Size = New System.Drawing.Size(151, 18)
        Me.lbl_WiFiChannel.TabIndex = 999
        Me.lbl_WiFiChannel.Text = "WiFi Channel (1..13)"
        '
        'lbl_StaticGateway
        '
        Me.lbl_StaticGateway.AutoSize = True
        Me.lbl_StaticGateway.BackColor = System.Drawing.Color.Transparent
        Me.lbl_StaticGateway.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaticGateway.ForeColor = System.Drawing.Color.Black
        Me.lbl_StaticGateway.Location = New System.Drawing.Point(358, 171)
        Me.lbl_StaticGateway.Name = "lbl_StaticGateway"
        Me.lbl_StaticGateway.Size = New System.Drawing.Size(113, 18)
        Me.lbl_StaticGateway.TabIndex = 999
        Me.lbl_StaticGateway.Text = "Static Gateway"
        '
        'txt_WiFiChannel
        '
        Me.txt_WiFiChannel.BackColor = System.Drawing.Color.White
        Me.txt_WiFiChannel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_WiFiChannel.ForeColor = System.Drawing.Color.Black
        Me.txt_WiFiChannel.Location = New System.Drawing.Point(209, 137)
        Me.txt_WiFiChannel.MaxLength = 2
        Me.txt_WiFiChannel.Name = "txt_WiFiChannel"
        Me.txt_WiFiChannel.Size = New System.Drawing.Size(82, 26)
        Me.txt_WiFiChannel.TabIndex = 50
        Me.txt_WiFiChannel.Text = "1"
        Me.txt_WiFiChannel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_StaticNetworkMask
        '
        Me.txt_StaticNetworkMask.BackColor = System.Drawing.Color.White
        Me.txt_StaticNetworkMask.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StaticNetworkMask.ForeColor = System.Drawing.Color.Black
        Me.txt_StaticNetworkMask.Location = New System.Drawing.Point(512, 137)
        Me.txt_StaticNetworkMask.MaxLength = 15
        Me.txt_StaticNetworkMask.Name = "txt_StaticNetworkMask"
        Me.txt_StaticNetworkMask.Size = New System.Drawing.Size(129, 26)
        Me.txt_StaticNetworkMask.TabIndex = 90
        Me.txt_StaticNetworkMask.Text = "255.255.255.0"
        Me.txt_StaticNetworkMask.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_CommFaultUseD0
        '
        Me.txt_CommFaultUseD0.BackColor = System.Drawing.Color.White
        Me.txt_CommFaultUseD0.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_CommFaultUseD0.ForeColor = System.Drawing.Color.Black
        Me.txt_CommFaultUseD0.Location = New System.Drawing.Point(209, 167)
        Me.txt_CommFaultUseD0.MaxLength = 1
        Me.txt_CommFaultUseD0.Name = "txt_CommFaultUseD0"
        Me.txt_CommFaultUseD0.Size = New System.Drawing.Size(82, 26)
        Me.txt_CommFaultUseD0.TabIndex = 60
        Me.txt_CommFaultUseD0.Text = "0"
        Me.txt_CommFaultUseD0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_StaticNetworkMask
        '
        Me.lbl_StaticNetworkMask.AutoSize = True
        Me.lbl_StaticNetworkMask.BackColor = System.Drawing.Color.Transparent
        Me.lbl_StaticNetworkMask.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaticNetworkMask.ForeColor = System.Drawing.Color.Black
        Me.lbl_StaticNetworkMask.Location = New System.Drawing.Point(358, 141)
        Me.lbl_StaticNetworkMask.Name = "lbl_StaticNetworkMask"
        Me.lbl_StaticNetworkMask.Size = New System.Drawing.Size(151, 18)
        Me.lbl_StaticNetworkMask.TabIndex = 999
        Me.lbl_StaticNetworkMask.Text = "Static Network Mask"
        '
        'txt_StaticNetworkIP
        '
        Me.txt_StaticNetworkIP.BackColor = System.Drawing.Color.White
        Me.txt_StaticNetworkIP.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StaticNetworkIP.ForeColor = System.Drawing.Color.Black
        Me.txt_StaticNetworkIP.Location = New System.Drawing.Point(512, 107)
        Me.txt_StaticNetworkIP.MaxLength = 15
        Me.txt_StaticNetworkIP.Name = "txt_StaticNetworkIP"
        Me.txt_StaticNetworkIP.Size = New System.Drawing.Size(129, 26)
        Me.txt_StaticNetworkIP.TabIndex = 80
        Me.txt_StaticNetworkIP.Text = "192.168.0.1"
        Me.txt_StaticNetworkIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_CommFaultUseD0
        '
        Me.lbl_CommFaultUseD0.AutoSize = True
        Me.lbl_CommFaultUseD0.BackColor = System.Drawing.Color.Transparent
        Me.lbl_CommFaultUseD0.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CommFaultUseD0.ForeColor = System.Drawing.Color.Black
        Me.lbl_CommFaultUseD0.Location = New System.Drawing.Point(14, 171)
        Me.lbl_CommFaultUseD0.Name = "lbl_CommFaultUseD0"
        Me.lbl_CommFaultUseD0.Size = New System.Drawing.Size(186, 18)
        Me.lbl_CommFaultUseD0.TabIndex = 999
        Me.lbl_CommFaultUseD0.Text = "Comm Fault Use D0 (0/1)"
        '
        'lbl_StaticNetworkIP
        '
        Me.lbl_StaticNetworkIP.AutoSize = True
        Me.lbl_StaticNetworkIP.BackColor = System.Drawing.Color.Transparent
        Me.lbl_StaticNetworkIP.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaticNetworkIP.ForeColor = System.Drawing.Color.Black
        Me.lbl_StaticNetworkIP.Location = New System.Drawing.Point(358, 111)
        Me.lbl_StaticNetworkIP.Name = "lbl_StaticNetworkIP"
        Me.lbl_StaticNetworkIP.Size = New System.Drawing.Size(127, 18)
        Me.lbl_StaticNetworkIP.TabIndex = 999
        Me.lbl_StaticNetworkIP.Text = "Static Network IP"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.btn_OpenFirmwareFolder)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.txt_HttpServerPort)
        Me.TabPage2.ForeColor = System.Drawing.Color.Black
        Me.TabPage2.Location = New System.Drawing.Point(4, 32)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(657, 266)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Send Firmware"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Cornsilk
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(14, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(435, 101)
        Me.Label4.TabIndex = 105
        Me.Label4.Text = "Press ""Send firmware button"" to send the firmware " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to the selected NetModules." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & _
            "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "After the file names you can write the version, or annotations." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(for example:" & _
            " ""Firmware1_V4.bin"")"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Cornsilk
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(200, 151)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(273, 99)
        Me.Label5.TabIndex = 104
        Me.Label5.Text = "The firmware folder must contain " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  at least the following two files" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- Firmware" & _
            "1.bin" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- Firmware2.bin"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btn_OpenFirmwareFolder
        '
        Me.btn_OpenFirmwareFolder.BackColor = System.Drawing.Color.LightYellow
        Me.btn_OpenFirmwareFolder.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btn_OpenFirmwareFolder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btn_OpenFirmwareFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_OpenFirmwareFolder.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_OpenFirmwareFolder.Location = New System.Drawing.Point(479, 151)
        Me.btn_OpenFirmwareFolder.Name = "btn_OpenFirmwareFolder"
        Me.btn_OpenFirmwareFolder.Size = New System.Drawing.Size(168, 99)
        Me.btn_OpenFirmwareFolder.TabIndex = 100
        Me.btn_OpenFirmwareFolder.Text = "Open" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Firmware Folder"
        Me.btn_OpenFirmwareFolder.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(499, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 18)
        Me.Label1.TabIndex = 60
        Me.Label1.Text = "HTTP Server Port"
        '
        'txt_HttpServerPort
        '
        Me.txt_HttpServerPort.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_HttpServerPort.Location = New System.Drawing.Point(530, 109)
        Me.txt_HttpServerPort.MaxLength = 5
        Me.txt_HttpServerPort.Name = "txt_HttpServerPort"
        Me.txt_HttpServerPort.Size = New System.Drawing.Size(72, 26)
        Me.txt_HttpServerPort.TabIndex = 70
        Me.txt_HttpServerPort.Text = "8080"
        Me.txt_HttpServerPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage3.Controls.Add(Me.btn_OpenUsbFirmwareFolder)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.Label2)
        Me.TabPage3.ForeColor = System.Drawing.Color.Black
        Me.TabPage3.Location = New System.Drawing.Point(4, 32)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(657, 266)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "USB Programmer"
        '
        'btn_OpenUsbFirmwareFolder
        '
        Me.btn_OpenUsbFirmwareFolder.BackColor = System.Drawing.Color.LightYellow
        Me.btn_OpenUsbFirmwareFolder.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btn_OpenUsbFirmwareFolder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btn_OpenUsbFirmwareFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_OpenUsbFirmwareFolder.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_OpenUsbFirmwareFolder.Location = New System.Drawing.Point(479, 151)
        Me.btn_OpenUsbFirmwareFolder.Name = "btn_OpenUsbFirmwareFolder"
        Me.btn_OpenUsbFirmwareFolder.Size = New System.Drawing.Size(168, 99)
        Me.btn_OpenUsbFirmwareFolder.TabIndex = 104
        Me.btn_OpenUsbFirmwareFolder.Text = "Open" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Firmware Folder"
        Me.btn_OpenUsbFirmwareFolder.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Cornsilk
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(14, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(435, 101)
        Me.Label3.TabIndex = 103
        Me.Label3.Text = resources.GetString("Label3.Text")
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Cornsilk
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(173, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(300, 97)
        Me.Label2.TabIndex = 102
        Me.Label2.Text = "The firmware folder must contain four files" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- BootLoader.bin" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- Params.bin" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- Fi" & _
            "rmware1.bin" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- Firmware2.bin"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Timer1Hz
        '
        '
        'Timer20Hz
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(671, 472)
        Me.Controls.Add(Me.ListBox_Replay)
        Me.Controls.Add(Me.txt_ApplicationUdpPort)
        Me.Controls.Add(Me.lbl_ApplicationUdpPort)
        Me.Controls.Add(Me.btn_Scan)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.btn_Execute)
        Me.Controls.Add(Me.ListBox_Modules)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino NetModule Programmer"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt_WiFiNetworkName As System.Windows.Forms.TextBox
    Friend WithEvents lbl_WifiNetworkName As System.Windows.Forms.Label
    Friend WithEvents txt_WiFiNetworkPassword As System.Windows.Forms.TextBox
    Friend WithEvents lbl_WiFiNetworkPassword As System.Windows.Forms.Label
    Friend WithEvents txt_UdpPort As System.Windows.Forms.TextBox
    Friend WithEvents lbl_UdpPort As System.Windows.Forms.Label
    Friend WithEvents txt_StaticNetworkIP As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaticNetworkIP As System.Windows.Forms.Label
    Friend WithEvents txt_StaticNetworkMask As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaticNetworkMask As System.Windows.Forms.Label
    Friend WithEvents txt_StaticGateway As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaticGateway As System.Windows.Forms.Label
    Friend WithEvents txt_StaticDNS0 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaticDNS0 As System.Windows.Forms.Label
    Friend WithEvents txt_StaticDNS1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaticDNS1 As System.Windows.Forms.Label
    Friend WithEvents lbl_WiFiNetworkMode As System.Windows.Forms.Label
    Friend WithEvents cmb_WiFiNetworkMode As System.Windows.Forms.ComboBox
    Friend WithEvents txt_WiFiChannel As System.Windows.Forms.TextBox
    Friend WithEvents lbl_WiFiChannel As System.Windows.Forms.Label
    Friend WithEvents txt_CommFaultDelay As System.Windows.Forms.TextBox
    Friend WithEvents lbl_CommFaultDelay As System.Windows.Forms.Label
    Friend WithEvents txt_CommFaultUseD0 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_CommFaultUseD0 As System.Windows.Forms.Label
    Friend WithEvents txt_CPUFreq As System.Windows.Forms.TextBox
    Friend WithEvents lbl_CPUFreq As System.Windows.Forms.Label
    Friend WithEvents btn_Execute As System.Windows.Forms.Button
    Friend WithEvents chk_AdvancedMode As System.Windows.Forms.CheckBox
    Friend WithEvents ListBox_Modules As System.Windows.Forms.ListBox
    Friend WithEvents TabControl1 As MyTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents btn_OpenFirmwareFolder As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_HttpServerPort As System.Windows.Forms.TextBox
    Friend WithEvents txt_ApplicationUdpPort As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ApplicationUdpPort As System.Windows.Forms.Label
    Friend WithEvents btn_Scan As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btn_OpenUsbFirmwareFolder As System.Windows.Forms.Button
    Friend WithEvents ListBox_Replay As System.Windows.Forms.ListBox
    Friend WithEvents Timer1Hz As System.Windows.Forms.Timer
    Friend WithEvents Timer10Hz As System.Windows.Forms.Timer
End Class
