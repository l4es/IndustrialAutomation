﻿Imports System.IO
Imports System.Text

' TODO - Main List
' ------------------------------------------------------------------
' Vedere il ritorno di ModuleReplay e scrivere Progragramming ERROR


Public Class Form1

    Private WithEvents _NetHALRPC As NetHALRPC = New NetHALRPC

    Friend TabSelectedIndex As Int32 = 0
    Private WiFiNetworkMode As String = "Station DHCP"     '(caps: SoftAP / Station DHCP / Station Static)"

    Private WiFiNetworkName As String = "network"          '(caps: string maxlen =  31)
    Private WiFiNetworkPassword As String = "password"     '(caps: string maxlen =  31)
    Private NetHalUdpPort As String = "49152"              '(caps: 0 to 65535)

    Private WiFiChannel As String = "1"                    '(caps: 1 to 13)
    Private CommFaultUseD0 As String = "0"                 '(caps: 0 / 1)
    Private CommFaultDelay As String = "200"               '(caps: 100 to 10000)
    Private CpuFreq As String = "160"                      '(caps: 80 / 160)

    Private StaticNetworkIP As String = "192.168.0.99"     '(caps:  xxx.xxx.xxx.xxx)
    Private StaticNetworkMask As String = "255.255.255.0"  '(caps:  xxx.xxx.xxx.xxx)
    Private StaticGateway As String = "192.168.0.1"        '(caps:  xxx.xxx.xxx.xxx)
    Private StaticDNS0 As String = "208.67.222.222"        '(caps:  xxx.xxx.xxx.xxx)
    Private StaticDNS1 As String = "208.67.220.220"        '(caps:  xxx.xxx.xxx.xxx)

    Private HttpServerPort As String = "8080"              '(caps: 0 to 65535)
    Private FirmwareFilesPath As String = Application.StartupPath + "\Firmware"

    Private AdvancedMode As Boolean = False
    Private ApplicationUdpPort As Int32 = 49152            '(caps: 0 to 65535)

    ' ---------------------------------------

    Private _PinsPropsFromNetModule() As NetHALRPC.ScanPropsStr
    Private _PropsProgrammedByNetHAL() As NetHALRPC.PropsStr

    Private mHTTPFileServer As HTTPFileServer = Nothing

    ' ================================================================================================
    '  Open, Close and Move the main form
    ' ================================================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ' --------------------------------------- Form title
        Me.Text = AppTitleAndVersion("Net Module programmer")
        ' --------------------------------------- 
        Combo_SetIndex(cmb_WiFiNetworkMode, 0)
        Load_INI()
        SetParams()
        ' --------------------------------------- StartTimers when all is ready
        Timer1Hz.Interval = 1000
        Timer1Hz.Start()
        Timer10Hz.Interval = 100
        Timer10Hz.Start()
        ' --------------------------------------- Enable events
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
        txt_HttpServerPort.SelectionStart = 999
        txt_HttpServerPort.SelectionLength = 0
        EnableDisableButtonExecute()
        btn_Execute.Select()
        StartAll()

        'ListBox_Modules_InitializeOwnerDrawnListBox()
    End Sub
    Private Sub Form_Main_FormClosing(ByVal sender As Object, _
                                      ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Timer10Hz.Stop()
        _NetHALRPC.CloseAdapters()
        If mHTTPFileServer IsNot Nothing Then
            mHTTPFileServer.TerminateThread()
        End If
        Save_INI()
    End Sub
    Private Sub StartAll()
        _NetHALRPC.CloseAdapters()
        Threading.Thread.Sleep(50)
        ' ------------------------------------------------ ScanAdapters
        _NetHALRPC.ScanAdapters(ApplicationUdpPort)
        Threading.Thread.Sleep(50)
        For i As Int32 = 1 To 5
            _NetHALRPC.ScanLocalModuleRequest()
            Threading.Thread.Sleep(10)
        Next
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    Private Sub SetAllControls()
        If AdvancedMode Then
            TabControl1.TabPages(2).Text = "USB Programmer"
            TabControl1.TabPages(2).Show()
        Else
            TabControl1.TabPages(2).Text = ""
            TabControl1.TabPages(2).Hide()
        End If

        TabControl1.SelectedIndex = TabSelectedIndex
        Select Case TabControl1.SelectedIndex
            Case 0
                btn_Execute.Text = "Send Options" + vbCrLf + "to NetModules"
                ListBox_Modules.Visible = True
                btn_Scan.Visible = True
                chk_AdvancedMode.Visible = True
                lbl_ApplicationUdpPort.Visible = True
                txt_ApplicationUdpPort.Visible = True
            Case 1
                btn_Execute.Text = "Send Firmware" + vbCrLf + "to NetModules"
                ListBox_Modules.Visible = True
                btn_Scan.Visible = True
                chk_AdvancedMode.Visible = True
                lbl_ApplicationUdpPort.Visible = True
                txt_ApplicationUdpPort.Visible = True
            Case 2
                btn_Execute.Text = "Build files" + vbCrLf + "for the" + vbCrLf + "USB programmer"
                ListBox_Modules.Visible = False
                btn_Scan.Visible = False
                chk_AdvancedMode.Visible = False
                lbl_ApplicationUdpPort.Visible = False
                txt_ApplicationUdpPort.Visible = False
        End Select

        Select Case WiFiNetworkMode
            Case "SoftAP"
                lbl_WifiNetworkName.Visible = AdvancedMode
                txt_WiFiNetworkName.Visible = AdvancedMode
                lbl_WiFiNetworkPassword.Visible = AdvancedMode
                txt_WiFiNetworkPassword.Visible = AdvancedMode
                lbl_UdpPort.Visible = AdvancedMode
                txt_UdpPort.Visible = AdvancedMode
                lbl_WiFiChannel.Visible = AdvancedMode
                txt_WiFiChannel.Visible = AdvancedMode
                lbl_CommFaultUseD0.Visible = AdvancedMode
                txt_CommFaultUseD0.Visible = AdvancedMode
                lbl_CommFaultDelay.Visible = AdvancedMode
                txt_CommFaultDelay.Visible = AdvancedMode
                lbl_CPUFreq.Visible = AdvancedMode
                txt_CPUFreq.Visible = AdvancedMode
                lbl_StaticNetworkIP.Visible = False
                txt_StaticNetworkIP.Visible = False
                lbl_StaticNetworkMask.Visible = False
                txt_StaticNetworkMask.Visible = False
                lbl_StaticGateway.Visible = False
                txt_StaticGateway.Visible = False
                lbl_StaticDNS0.Visible = False
                txt_StaticDNS0.Visible = False
                lbl_StaticDNS1.Visible = False
                txt_StaticDNS1.Visible = False

            Case "Station DHCP"
                lbl_WifiNetworkName.Visible = True
                txt_WiFiNetworkName.Visible = True
                lbl_WiFiNetworkPassword.Visible = True
                txt_WiFiNetworkPassword.Visible = True
                lbl_UdpPort.Visible = AdvancedMode
                txt_UdpPort.Visible = AdvancedMode
                lbl_WiFiChannel.Visible = False
                txt_WiFiChannel.Visible = False
                lbl_CommFaultUseD0.Visible = AdvancedMode
                txt_CommFaultUseD0.Visible = AdvancedMode
                lbl_CommFaultDelay.Visible = AdvancedMode
                txt_CommFaultDelay.Visible = AdvancedMode
                lbl_CPUFreq.Visible = AdvancedMode
                txt_CPUFreq.Visible = AdvancedMode
                lbl_StaticNetworkIP.Visible = False
                txt_StaticNetworkIP.Visible = False
                lbl_StaticNetworkMask.Visible = False
                txt_StaticNetworkMask.Visible = False
                lbl_StaticGateway.Visible = False
                txt_StaticGateway.Visible = False
                lbl_StaticDNS0.Visible = False
                txt_StaticDNS0.Visible = False
                lbl_StaticDNS1.Visible = False
                txt_StaticDNS1.Visible = False

            Case "Station Static"
                lbl_WifiNetworkName.Visible = True
                txt_WiFiNetworkName.Visible = True
                lbl_WiFiNetworkPassword.Visible = True
                txt_WiFiNetworkPassword.Visible = True
                lbl_UdpPort.Visible = AdvancedMode
                txt_UdpPort.Visible = AdvancedMode
                lbl_WiFiChannel.Visible = False
                txt_WiFiChannel.Visible = False
                lbl_CommFaultUseD0.Visible = AdvancedMode
                txt_CommFaultUseD0.Visible = AdvancedMode
                lbl_CommFaultDelay.Visible = AdvancedMode
                txt_CommFaultDelay.Visible = AdvancedMode
                lbl_CPUFreq.Visible = AdvancedMode
                txt_CPUFreq.Visible = AdvancedMode
                lbl_StaticNetworkIP.Visible = True
                txt_StaticNetworkIP.Visible = True
                lbl_StaticNetworkMask.Visible = True
                txt_StaticNetworkMask.Visible = True
                lbl_StaticGateway.Visible = True
                txt_StaticGateway.Visible = True
                lbl_StaticDNS0.Visible = AdvancedMode
                txt_StaticDNS0.Visible = AdvancedMode
                lbl_StaticDNS1.Visible = AdvancedMode
                txt_StaticDNS1.Visible = AdvancedMode
        End Select
    End Sub

    Private Sub btn_Execute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Execute.Click
        Select Case TabControl1.SelectedIndex
            Case 0 : SendOptionsToNetModules()
            Case 1 : SendFirmwareToNetModules()
            Case 2 : BuildFilesForTheUsbProgrammer()
        End Select
    End Sub


    ' ================================================================================================
    '  LIST BOX DRAW OVERRIDE  (The ListBox DrawMode must be OwnerDrawFixed)
    ' ================================================================================================
    Private Sub ListBox_Modules_DrawItem(ByVal sender As Object, _
                                         ByVal e As System.Windows.Forms.DrawItemEventArgs) _
                                         Handles ListBox_Modules.DrawItem
        e.DrawBackground()

        If e.Index < 0 Then Return
        Dim s As String = ListBox_Modules.GetItemText(ListBox_Modules.Items(e.Index))

        ' Horizontal scroll bar disabled because not working OK
        'Dim sz As SizeF = e.Graphics.MeasureString(s, e.Font, 0)
        'ListBox_Modules.HorizontalExtent = CInt(sz.Width)

        If (e.State And DrawItemState.Selected) = DrawItemState.Selected Then
            e.Graphics.FillRectangle(Brushes.CornflowerBlue, e.Bounds)
            e.Graphics.DrawRectangle(Pens.Gold, e.Bounds)
            e.Graphics.DrawString(s, e.Font, Brushes.White, e.Bounds.X, e.Bounds.Y)
        Else
            e.Graphics.FillRectangle(Brushes.Beige, e.Bounds)
            e.Graphics.DrawRectangle(Pens.Gold, e.Bounds)
            e.Graphics.DrawString(s, e.Font, Brushes.Black, e.Bounds.X, e.Bounds.Y)
        End If

        e.DrawFocusRectangle()
    End Sub


    ' ================================================================================================
    '  Special TXT edit - Numeric or IP
    ' ================================================================================================
    Private Sub txt_UnsignedInt_KeyDown(ByVal sender As Object, _
                                        ByVal e As System.Windows.Forms.KeyEventArgs) _
                                        Handles txt_WiFiChannel.KeyDown, _
                                                txt_CommFaultUseD0.KeyDown, _
                                                txt_CommFaultDelay.KeyDown, _
                                                txt_CPUFreq.KeyDown, _
                                                txt_UdpPort.KeyDown, _
                                                txt_ApplicationUdpPort.KeyDown, _
                                                txt_HttpServerPort.KeyDown
        OnlyUnsignedIntegerTextBox(sender, e)
    End Sub

    Private Sub txt_Ports_TextChanged(ByVal sender As Object, _
                                      ByVal e As System.EventArgs) _
                                      Handles txt_UdpPort.TextChanged, _
                                              txt_ApplicationUdpPort.TextChanged, _
                                              txt_HttpServerPort.TextChanged
        MinMaxTextBox_OrangeColor(sender, 0, 65535)
    End Sub

    Private Sub txt_WiFiChannel_TextChanged(ByVal sender As Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles txt_WiFiChannel.TextChanged
        MinMaxTextBox_OrangeColor(sender, 1, 13)
    End Sub
    Private Sub txt_CommFaultUseD0_TextChanged(ByVal sender As Object, _
                                    ByVal e As System.EventArgs) _
                                    Handles txt_CommFaultUseD0.TextChanged
        MinMaxTextBox_OrangeColor(sender, 0, 1)
    End Sub
    Private Sub txt_CommFaultDelay_TextChanged(ByVal sender As Object, _
                                        ByVal e As System.EventArgs) _
                                        Handles txt_CommFaultDelay.TextChanged
        MinMaxTextBox_OrangeColor(sender, 100, 10000)
    End Sub
    Private Sub MinMaxTextBox_OrangeColor(ByVal obj As Object, ByVal min As Int32, ByVal max As Int32)
        Dim tbox As TextBox = CType(obj, TextBox)
        Dim n As Int32 = CInt(Val(tbox.Text))
        If n < min Or n > max Or tbox.Text = "" Then
            tbox.BackColor = Color.Orange
        Else
            tbox.BackColor = Color.White
        End If
        EnableDisableButtonExecute()
    End Sub

    Private Sub txt_CPUFreq_TextChanged(ByVal sender As Object, _
                                        ByVal e As System.EventArgs) _
                                        Handles txt_CPUFreq.TextChanged
        Dim tbox As TextBox = CType(sender, TextBox)
        Dim n As Int32 = CInt(Val(tbox.Text))
        If n <> 80 And n <> 160 Or tbox.Text = "" Then
            tbox.BackColor = Color.Orange
        Else
            tbox.BackColor = Color.White
        End If
        EnableDisableButtonExecute()
    End Sub

    Private Sub txt_IP_TextChanged(ByVal sender As Object, _
                                     ByVal e As System.EventArgs) _
                                     Handles txt_StaticNetworkIP.TextChanged, _
                                             txt_StaticNetworkMask.TextChanged, _
                                             txt_StaticGateway.TextChanged, _
                                             txt_StaticDNS0.TextChanged, _
                                             txt_StaticDNS1.TextChanged

        Dim tbox As TextBox = CType(sender, TextBox)
        If Not IsIP(tbox.Text) Then
            tbox.BackColor = Color.Orange
        Else
            tbox.BackColor = Color.White
        End If
        EnableDisableButtonExecute()
    End Sub


    ' ================================================================================================
    '  Set Params
    ' ================================================================================================
    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        If Not AdvancedMode And TabControl1.SelectedIndex = 2 Then
            TabControl1.SelectedIndex = TabSelectedIndex
        End If
        TabSelectedIndex = TabControl1.SelectedIndex
        SetAllControls()
        EnableDisableButtonExecute()
        Save_INI()
    End Sub

    Private Sub txtboxes_TextChanged(ByVal sender As Object, _
                                     ByVal e As System.EventArgs) _
                                     Handles txt_WiFiNetworkName.TextChanged, _
                                             txt_WiFiNetworkPassword.TextChanged, _
                                             txt_UdpPort.TextChanged, _
                                             txt_WiFiChannel.TextChanged, _
                                             txt_CommFaultUseD0.TextChanged, _
                                             txt_CommFaultDelay.TextChanged, _
                                             txt_CPUFreq.TextChanged, _
                                             txt_StaticNetworkIP.TextChanged, _
                                             txt_StaticNetworkMask.TextChanged, _
                                             txt_StaticGateway.TextChanged, _
                                             txt_StaticDNS0.TextChanged, _
                                             txt_StaticDNS1.TextChanged, _
                                             chk_AdvancedMode.CheckedChanged, _
                                             txt_HttpServerPort.TextChanged, _
                                             txt_ApplicationUdpPort.TextChanged
        If Not EventsAreEnabled Then Return
        SetParams()
        Save_INI()
    End Sub

    Private Sub SetParams()
        AdvancedMode = chk_AdvancedMode.Checked
        WiFiNetworkMode = cmb_WiFiNetworkMode.Text
        WiFiNetworkName = txt_WiFiNetworkName.Text
        WiFiNetworkPassword = txt_WiFiNetworkPassword.Text
        NetHalUdpPort = txt_UdpPort.Text

        WiFiChannel = txt_WiFiChannel.Text
        CommFaultUseD0 = txt_CommFaultUseD0.Text
        CommFaultDelay = txt_CommFaultDelay.Text
        CpuFreq = txt_CPUFreq.Text

        StaticNetworkIP = txt_StaticNetworkIP.Text
        StaticNetworkMask = txt_StaticNetworkMask.Text
        StaticGateway = txt_StaticGateway.Text
        StaticDNS0 = txt_StaticDNS0.Text
        StaticDNS1 = txt_StaticDNS1.Text

        HttpServerPort = txt_HttpServerPort.Text
        ApplicationUdpPort = CInt(Val(txt_ApplicationUdpPort.Text))
        If ApplicationUdpPort < 0 Then ApplicationUdpPort = 0
        If ApplicationUdpPort > 65535 Then ApplicationUdpPort = 65535

        SetAllControls()
    End Sub


    ' ==============================================================
    '   COMBO NETWORK MODE
    ' ==============================================================
    Private Sub cmb_WiFiNetworkMode_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_WiFiNetworkMode.DropDown
        cmb_WiFiNetworkMode.ItemHeight = 16
    End Sub
    Private Sub cmb_WiFiNetworkMode_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_WiFiNetworkMode.DropDownClosed
        cmb_WiFiNetworkMode.ItemHeight = 12
    End Sub
    Private Sub cmb_WiFiNetworkMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_WiFiNetworkMode.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        SetParams()
        Save_INI()
    End Sub

    ' ==================================================================================
    '  COMMANDS
    ' ==================================================================================
    Private Sub txt_ApplicationUdpPort_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_ApplicationUdpPort.TextChanged
        If Not EventsAreEnabled Then Return
        ReDim NetModulesArray(-1)
        NetModulesChanged = True
        SetParams()
        StartAll() ' StartAll must be after SetParams and NetModulesChanged = True
        btn_Execute.Enabled = False
    End Sub

    Private Sub btn_Scan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Scan.Click
        ReDim NetModulesArray(-1)
        NetModulesChanged = True
        StartAll() ' StartAll must be after SetParams and NetModulesChanged = True
        btn_Execute.Enabled = False
    End Sub


    ' ======================================================================
    '  NET MODULES
    ' ======================================================================
    Private Structure NetModule
        Dim Name As String
        Dim MAC As String
        Dim IpAddr As String
        Dim ProgStatus As String
        Dim FWVer As String
    End Structure
    Private NetModulesArray(-1) As NetModule
    Private NetModulesChanged As Boolean

    Private Sub ListBoxModules_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox_Modules.SelectedIndexChanged
        EnableDisableButtonExecute()
    End Sub

    Private Sub EnableDisableButtonExecute()
        If (ListBox_Modules.SelectedIndices.Count > 0 And TestAllFields()) Or Not ListBox_Modules.Visible Then
            btn_Execute.Enabled = True
        Else
            btn_Execute.Enabled = False
        End If
    End Sub

    Private Function TestAllFields() As Boolean
        If txt_UdpPort.BackColor <> Color.White Then Return False

        If txt_WiFiChannel.BackColor <> Color.White Then Return False
        If txt_CommFaultUseD0.BackColor <> Color.White Then Return False
        If txt_CommFaultDelay.BackColor <> Color.White Then Return False
        If txt_CPUFreq.BackColor <> Color.White Then Return False

        If txt_StaticNetworkIP.BackColor <> Color.White Then Return False
        If txt_StaticNetworkMask.BackColor <> Color.White Then Return False
        If txt_StaticGateway.BackColor <> Color.White Then Return False
        If txt_StaticDNS0.BackColor <> Color.White Then Return False
        If txt_StaticDNS1.BackColor <> Color.White Then Return False

        If txt_HttpServerPort.BackColor <> Color.White Then Return False
        If txt_ApplicationUdpPort.BackColor <> Color.White Then Return False

        Return True
    End Function

    Private Sub ConfModuleReplay(ByVal ModuleProps As NetHALRPC.ScanReplayModulePropsStr, ByVal PinsProps() As NetHALRPC.ScanPropsStr) Handles _NetHALRPC.ScanModuleReplay
        Dim dfdf As Int32 = 0
    End Sub
    Private Sub XchgIntModuleReplay(ByVal ModuleProps As NetHALRPC.XchgModuleReplayStr, ByVal PinsIn() As NetHALRPC.IntValueStr) Handles _NetHALRPC.XchgIntModuleReplay
        Dim dfdf As Int32 = 0
    End Sub
    Private Sub XchgSingleModuleReplay(ByVal ModuleProps As NetHALRPC.XchgModuleReplayStr, ByVal SlotsIn() As NetHALRPC.SingleValueStr) Handles _NetHALRPC.XchgSingleModuleReplay
        Dim dfdf As Int32 = 0
    End Sub
    Private Sub ScanModuleReplay(ByVal ModuleProps As NetHALRPC.ScanReplayModulePropsStr, ByVal PinsProps() As NetHALRPC.ScanPropsStr) Handles _NetHALRPC.ScanModuleReplay
        ' ----------------------------------------------------------- Update the PinProps
        _PinsPropsFromNetModule = PinsProps
        ' ----------------------------------------------------------- Add a new IpAddr to NetModules Array
        NetModulesArray_NewIpAddr(ModuleProps.IPAddr)
        ' ----------------------------------------------------------- Update the NetModules Array
        NetModulesArray_UpdateData(ModuleProps.IPAddr, _
                                   ModuleProps.Name, _
                                   ModuleProps.MAC, _
                                   ModuleProps.ProgStatus, _
                                   ModuleProps.FWVer)
    End Sub

    Private Sub NetModulesArray_NewIpAddr(ByVal ip As String)
        ' ------------------------------------------------------ if IP already exists then exit
        For i As Int32 = 0 To NetModulesArray.Length - 1
            If NetModulesArray(i).IpAddr = ip Then Return
        Next
        ' ------------------------------------------------------ Increase NetModules Array and add new IP
        Dim len As Int32 = NetModulesArray.Length
        ReDim Preserve NetModulesArray(len)
        NetModulesArray(len).IpAddr = ip
    End Sub

    Private Sub NetModulesArray_UpdateData(ByVal IPAddr As String, _
                                           ByVal Name As String, _
                                           ByVal MAC As String, _
                                           ByVal ProgStatus As String, _
                                           ByVal FWVer As String)
        For i As Int32 = 0 To NetModulesArray.Length - 1
            With NetModulesArray(i)
                If IPAddr = .IpAddr Then
                    If Name <> "" Then .Name = Name
                    If MAC <> "" Then .MAC = MAC
                    If ProgStatus <> "" Then .ProgStatus = ProgStatus
                    If FWVer <> "" Then .FWVer = FWVer
                    NetModulesChanged = True
                    Exit For
                End If
            End With
        Next
    End Sub

    Private Sub Timer10Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer10Hz.Tick
        '
        ' ----------------------------------------------------------- Show NetModulesArray in the ModuleList
        If NetModulesChanged Then
            NetModulesChanged = False
            ' ------------------------------------------------------- prepare a string array
            Dim strArray(NetModulesArray.Length - 1) As String
            For i As Int32 = 0 To NetModulesArray.Length - 1
                With NetModulesArray(i)
                    'strArray(i) = .Name + "  " + _
                    '              .MAC + "  " + _
                    '              .IpAddr + "  " + _
                    '              .ProgStatus + "  " + _
                    '              .FWVer

                    strArray(i) = .IpAddr + "  " + _
                                  .FWVer + "  " + _
                                  .Name
                End With
            Next
            ' ------------------------------------------------------- sort 
            Array.Sort(strArray)
            ' ------------------------------------------------------- write ListBox lines
            ListBox_Modules.Items.Clear()
            For Each s As String In strArray
                ListBox_Modules.Items.Add(s)
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
                'ListBox_Modules.Items.Add("192.168.0.6  M0.6 1234567890123456789012345678901")
            Next

        End If
    End Sub

    ' ==================================================================================
    '  PROGRAMMING TIMER
    ' ==================================================================================
    Private Programming As Boolean = False
    Private ProgrammingSeconds As Int32

    Private Sub Timer1Hz_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1Hz.Tick

        If ProgrammingSeconds > -999 Then

            ProgrammingSeconds -= 1

            If ProgrammingSeconds > 0 Then
                AddReplayItem("Please wait " + ProgrammingSeconds.ToString, 0)
            End If

            If ProgrammingSeconds = 0 Then
                ProgrammingSeconds = -1

                AddReplayItem("", 0)
                AddReplayItem("                   CLICK ON THIS WINDOW TO CLOSE", 0)
                AddReplayItem("", 0)
            End If

            If ProgrammingSeconds < 0 Then
                AddReplayItem("Please wait reconnection " + (ProgrammingSeconds + 10).ToString, 0)
            End If

            If ProgrammingSeconds < -10 Then
                btn_Scan_Click(Nothing, Nothing)
                ProgrammingSeconds = -999
                ListReplayHide()
            End If

        End If
    End Sub


    ' ==================================================================================
    '  SEND OPTIONS
    ' ==================================================================================
    Private Sub SendOptionsToNetModules()
        ' ---------------------------------------------------------------- prepare ConfData
        Dim ConfData As String = "BOF" + vbCrLf
        Select Case WiFiNetworkMode
            Case "SoftAP" : AddParam(ConfData, cmb_WiFiNetworkMode, "WiFiNetworkMode", "SoftAP")
            Case "Station DHCP" : AddParam(ConfData, cmb_WiFiNetworkMode, "WiFiNetworkMode", "StationDHCP")
            Case "Station Static" : AddParam(ConfData, cmb_WiFiNetworkMode, "WiFiNetworkMode", "StationStatic")
        End Select
        '
        AddParam(ConfData, txt_WiFiNetworkName, "WiFiNetworkName", WiFiNetworkName)
        AddParam(ConfData, txt_WiFiNetworkPassword, "WiFiNetworkPassword", WiFiNetworkPassword)
        AddParam(ConfData, txt_UdpPort, "NetHALUDPPort", NetHalUdpPort)
        AddParam(ConfData, txt_WiFiChannel, "WiFiChannel", WiFiChannel)
        AddParam(ConfData, txt_CommFaultUseD0, "CommFaultUseD0", CommFaultUseD0)
        AddParam(ConfData, txt_CommFaultDelay, "CommFaultDelay", CommFaultDelay)
        AddParam(ConfData, txt_CPUFreq, "CPUFreq", CpuFreq)
        AddParam(ConfData, txt_StaticNetworkIP, "StaticNetworkIP", StaticNetworkIP)
        AddParam(ConfData, txt_StaticNetworkMask, "StaticNetworkMask", StaticNetworkMask)
        AddParam(ConfData, txt_StaticGateway, "StaticGateway", StaticGateway)
        AddParam(ConfData, txt_StaticDNS0, "StaticDNS0", StaticDNS0)
        AddParam(ConfData, txt_StaticDNS1, "StaticDNS1", StaticDNS1)
        '
        ConfData += "EOF" + vbCrLf
        ' ---------------------------------------------------------------- show the REPLAY list
        ListReplayShow()
        AddReplayItem("", 0)
        AddReplayItem("                   CLICK ON THIS WINDOW TO CLOSE", 0)
        AddReplayItem("", 0)
        ' ---------------------------------------------------------------- send options to selected modules
        For i As Int32 = 0 To ListBox_Modules.Items.Count - 1
            If ListBox_Modules.GetSelected(i) Then
                Dim s As String = ListBox_Modules.Items(i).ToString
                s = ReplaceMultipleSpacesAndTrim(s)
                Dim props() As String = s.Split(" "c)
                For Each s In props
                    If IsIP(s) Then
                        Dim ModuleProps As NetHALRPC.NameModulePropsStr
                        ModuleProps.IPAddr = s
                        ModuleProps.Name = ConfData
                        _NetHALRPC.ConfModuleRequest(ModuleProps)
                        Exit For
                    End If
                Next
            End If
        Next
    End Sub

    Private Sub AddParam(ByRef confdata As String, _
                         ByVal ctrl As Control, _
                         ByVal fieldName As String, _
                         ByVal field As String)
        '
        If ctrl.BackColor <> Color.White Then Return
        If Not ctrl.Visible Then Return
        confdata += fieldName + " " + field + vbCrLf
    End Sub

    Private Sub ConfModuleReplay(ByVal response As NetHALRPC.NameModulePropsStr) Handles _NetHALRPC.ConfModuleReplay
        If response.Name = "Y" Then
            AddReplayItem("    " + response.IPAddr + " - Options programmed OK", 0)
        Else
            AddReplayItem("    " + response.IPAddr + " - ERROR", 0)
        End If
    End Sub

    Private Function AddReplayItem(ByVal text As String, ByVal number As Integer) As Int32
        If Me.InvokeRequired Then
            Me.Invoke(CType(Function() AddReplayItem(text, number), MethodInvoker))
        Else
            ListBox_Replay.Items.Add(text)
            ListBox_Replay.TopIndex = ListBox_Replay.Items.Count - 1
        End If
    End Function

    Private Sub ListReplayShow()
        With ListBox_Replay
            .Items.Clear()
            .Bounds = TabControl1.TabPages(0).Bounds
            .Top += TabControl1.Top
            .Left += TabControl1.Left
            .Visible = True
        End With
        TabControl1.Enabled = False
        ListBox_Modules.Enabled = False
        ListBoxModulesOldBackColor = ListBox_Modules.BackColor
        ListBox_Modules.BackColor = Color.Gainsboro
        btn_Scan.Enabled = False
        btn_Execute.Enabled = False
        lbl_ApplicationUdpPort.Enabled = False
        txt_ApplicationUdpPort.Enabled = False
    End Sub

    Private ListBoxModulesOldBackColor As Color

    Private Sub ListReplayHide()
        With ListBox_Replay
            .Visible = False
        End With
        TabControl1.Enabled = True
        ListBox_Modules.BackColor = ListBoxModulesOldBackColor
        ListBox_Modules.Enabled = True
        btn_Scan.Enabled = True
        EnableDisableButtonExecute()
        lbl_ApplicationUdpPort.Enabled = True
        txt_ApplicationUdpPort.Enabled = True
    End Sub

    Private Sub ListBox_Replay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox_Replay.Click
        ListReplayHide()
    End Sub

    ' ==================================================================================
    '  SEND FIRMWARE
    ' ==================================================================================
    Private Sub btn_OpenFirmwareFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_OpenFirmwareFolder.Click
        CreateDir(FirmwareFilesPath)
        System.Diagnostics.Process.Start(FirmwareFilesPath)
    End Sub

    Private Sub SendFirmwareToNetModules()

        If Not TestFirmwareFiles(False) Then Return

        ' ---------------------------------------------------------------- show the REPLAY list
        ListReplayShow()

        ' ---------------------------------------------------------------- try to open the HTTPFileServer
        If mHTTPFileServer IsNot Nothing Then
            mHTTPFileServer.TerminateThread()
        End If

        mHTTPFileServer = New HTTPFileServer(FirmwareFilesPath, _
                                             IO.Path.GetFileName(FirmwareFileName1), _
                                             IO.Path.GetFileName(FirmwareFileName2), _
                                             CInt(Val(HttpServerPort)))

        If mHTTPFileServer.HttpPortIsOK Then
            ' ------------------------------------------------------------ send firmware to selected modules
            For i As Int32 = 0 To ListBox_Modules.Items.Count - 1
                If ListBox_Modules.GetSelected(i) Then
                    Dim s As String = ListBox_Modules.Items(i).ToString
                    s = ReplaceMultipleSpacesAndTrim(s)
                    Dim props() As String = s.Split(" "c)
                    For Each s In props
                        If IsIP(s) Then
                            Dim FuotaModule As NetHALRPC.FuotaModulePropsStr = Nothing
                            FuotaModule.IPAddr = s
                            FuotaModule.ServerPort = HttpServerPort
                            FuotaModule.FileName1 = IO.Path.GetFileName(FirmwareFileName1)
                            FuotaModule.FileName2 = IO.Path.GetFileName(FirmwareFileName2)
                            _NetHALRPC.FuotaModuleRequest(FuotaModule)
                            ProgrammingSeconds = 10
                            Exit For
                        End If
                    Next
                End If
            Next
        Else
            AddReplayItem("--- ERROR ---", 0)
            AddReplayItem("The HTTP file server is not opened.", 0)
            AddReplayItem("Probably some application is using the port " + HttpServerPort, 0)
        End If

    End Sub

    Function GetIPAddress(ByVal hostname As String) As String
        Dim host As System.Net.IPHostEntry
        host = System.Net.Dns.GetHostEntry(hostname)
        For Each ip As System.Net.IPAddress In host.AddressList
            If ip.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                Diagnostics.Debug.Print("LocalIPadress: " + ip.ToString)
                Return ip.ToString
            End If
        Next
        Return Nothing
    End Function

    Private Sub FuotaModuleReplay(ByVal response As NetHALRPC.NameModulePropsStr) Handles _NetHALRPC.FuotaModuleReplay
        If response.Name = "Y" Then
            AddReplayItem("    " + response.IPAddr + " - Firmware update is started", 0)
        Else
            AddReplayItem("    " + response.IPAddr + " - ERROR", 0)
        End If
    End Sub


    ' ==================================================================================
    '  BUILD USB FIRMWARE
    ' ==================================================================================
    Private Sub btn_OpenUsbFirmwareFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_OpenUsbFirmwareFolder.Click
        CreateDir(FirmwareFilesPath)
        System.Diagnostics.Process.Start(FirmwareFilesPath)
    End Sub

    Private Sub BuildFilesForTheUsbProgrammer()

        ' To avoid the following two phase programming of netmodules
        '  1) erase, we use a fill with 0xff, ALL 4 MB of flash (to erase every possible sign of past use) 
        '  2) program the necessary files at certain offsets
        ' Instead we prepare 4 flashsegment.bin files that are programmed once to rearch the same goal.
        ' The 4 files will be programmed using offset 0x000000, 0x100000, 0x200000, 0x300000

        ' --------------------------------------------------- initial test
        If Not TestFirmwareFiles(True) Then Return
        ' --------------------------------------------------- 
        Dim FlashSize As Int32 = 4194304
        Dim buffer(FlashSize - 1) As Byte
        Dim FileBytes() As Byte
        ' --------------------------------------------------- prepare a buffer filled with FF
        For i As Int32 = 0 To FlashSize - 1
            buffer(i) = &HFF
        Next
        ' --------------------------------------------------- overwrite buffer with data
        FileBytes = File.ReadAllBytes(BootFileName)
        Array.Copy(FileBytes, 0, buffer, 0, FileBytes.Length)
        '
        FileBytes = File.ReadAllBytes(FirmwareFileName1)
        Array.Copy(FileBytes, 0, buffer, &H1000, FileBytes.Length)
        '
        FileBytes = File.ReadAllBytes(FirmwareFileName2)
        Array.Copy(FileBytes, 0, buffer, &H101000, FileBytes.Length)
        '
        FileBytes = File.ReadAllBytes(ParamsFileName)
        Array.Copy(FileBytes, 0, buffer, &H3FC000, FileBytes.Length)
        '
        ' --------------------------------------------------- write the buffer as a single file
        CreateDir(FirmwareFilesPath + "\UsbFirmwareFiles")
        File.WriteAllBytes(FirmwareFilesPath + "\UsbFirmwareFiles\FlashComplete.bin", buffer)
        '
        ' --------------------------------------------------- split buffer and save four files
        For j As Int32 = 0 To 3
            ReDim FileBytes(1048576 - 1)
            Array.Copy(buffer, 1048576 * j, FileBytes, 0, FileBytes.Length)
            File.WriteAllBytes(FirmwareFilesPath + "\UsbFirmwareFiles\FlashAtOffset0x" & j.ToString & "00000.bin", FileBytes)
        Next
    End Sub


    ' ==================================================================================
    '  TEST FIRMWARE FILES
    ' ==================================================================================
    Private BootFileName As String      ' Boot.bin       or boot_v1.7.bin
    Private ParamsFileName As String    ' Params.bin     or esp_init_data_setting.bin
    Private FirmwareFileName1 As String ' firmware1.bin  or user1.4096.new.6.bin
    Private FirmwareFileName2 As String ' firmware2.bin  or user2.4096.new.6.bin

    Friend FileNames As Collections.ObjectModel.ReadOnlyCollection(Of String)
    Friend Sub ReadFileNames(ByVal path As String)
        Dim wildcards() As String = {"*.bin"}
        FileNames = My.Computer.FileSystem.GetFiles(path, _
                                                    FileIO.SearchOption.SearchTopLevelOnly, _
                                                    wildcards)
    End Sub

    Private Function TestFirmwareFiles(ByVal TestBootAndParams As Boolean) As Boolean
        CreateDir(FirmwareFilesPath)
        ReadFileNames(FirmwareFilesPath)
        BootFileName = ""
        ParamsFileName = ""
        FirmwareFileName1 = ""
        FirmwareFileName2 = ""
        For Each fpath As String In FileNames
            Dim fname As String = IO.Path.GetFileNameWithoutExtension(fpath).ToLower
            If TestBootAndParams Then
                If fname.Contains("boot") Then
                    If BootFileName = "" Then
                        BootFileName = fpath
                    Else
                        FirmwareFileError("There are more ""Boot"" files")
                        Return False
                    End If
                End If
                If fname.Contains("param") Or fname.Contains("setting") Then
                    If ParamsFileName = "" Then
                        ParamsFileName = fpath
                    Else
                        FirmwareFileError("There are more ""Params"" files")
                        Return False
                    End If
                End If
            End If
            If fname.Contains("firmware1") Or fname.Contains("user1") Then
                If FirmwareFileName1 = "" Then
                    FirmwareFileName1 = fpath
                Else
                    FirmwareFileError("There are more ""Firmware1"" files")
                    Return False
                End If
            End If
            If fname.Contains("firmware2") Or fname.Contains("user2") Then
                If FirmwareFileName2 = "" Then
                    FirmwareFileName2 = fpath
                Else
                    FirmwareFileError("There are more ""Firmware2"" files")
                    Return False
                End If
            End If
        Next
        '
        If TestBootAndParams Then
            If BootFileName = "" Then FirmwareFileError("Can not find the ""Boot"" file") : Return False
            If ParamsFileName = "" Then FirmwareFileError("Can not find the ""Params"" file") : Return False
        End If
        If FirmwareFileName1 = "" Then FirmwareFileError("Can not find the ""Firmware1"" file") : Return False
        If FirmwareFileName2 = "" Then FirmwareFileError("Can not find the ""Firmware2"" file") : Return False
        '
        Return True
    End Function

    Private Sub FirmwareFileError(ByVal err As String)
        MessageBox.Show(err, _
                        "Message from Theremino NetModuleProgrammer", _
                        MessageBoxButtons.OK, _
                        MessageBoxIcon.Warning)
    End Sub

End Class