﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Threading
Imports System.Text
Imports System.IO

Module Module_HTTPFileServer

    Public Class HTTPFileServer

        Dim mListenThread As Thread
        Dim mTcpListener As TcpListener
        Dim mRootPath As String
        Dim mFileName1 As String
        Dim mFileName2 As String
        Dim mPort As Integer
        Friend Sub New(ByVal RootPath As String, ByVal FileName1 As String, ByVal FileName2 As String, ByVal Port As Integer)
            Try
                mRootPath = RootPath
                mFileName1 = FileName1
                mFileName2 = FileName2
                mPort = Port
                mListenThread = New Thread(AddressOf ListenThread)
                mListenThread.Start()
                Threading.Thread.Sleep(100)
            Catch ex As Exception
                Debug.Print(ex.StackTrace.ToString())
            End Try
        End Sub

        Friend Function HttpPortIsOK() As Boolean
            Return mTcpListener IsNot Nothing
        End Function

        Private Sub ListenThread()
            Try
                Dim ServerIP As IPAddress = IPAddress.Parse("0.0.0.0")
                mTcpListener = New TcpListener(ServerIP, mPort)
                mTcpListener.Start()
                While True
                    Dim TCPClient As TcpClient = mTcpListener.AcceptTcpClient()
                    Dim HTTPFileServerIstance As New HTTPFileServerIstance(TCPClient, mFileName1, mFileName2, mRootPath)
                End While
            Catch ex As Exception
                mTcpListener = Nothing
                Debug.Print(ex.StackTrace.ToString())
            End Try
        End Sub

        Friend Sub TerminateThread()
            If mTcpListener IsNot Nothing Then mTcpListener.Stop()
        End Sub

    End Class

    Public Class HTTPFileServerIstance
        Dim mIstanceThread As Thread
        Dim mTCPClient As TcpClient
        Dim mRootPath As String
        Dim mFileName1 As String
        Dim mFileName2 As String
        Dim recvBytes(1024) As Byte
        Dim htmlReq As String = Nothing
        Dim bytes As Int32

        Friend Sub New(ByVal TCPClient As TcpClient, ByVal FileName1 As String, ByVal FileName2 As String, ByVal RootPath As String)
            Try
                mTCPClient = TCPClient
                mRootPath = RootPath
                mFileName1 = FileName1
                mFileName2 = FileName2
                mIstanceThread = New Thread(AddressOf HandleRequest)
                mIstanceThread.Start()
            Catch ex As Exception
                Debug.Print(ex.StackTrace.ToString())
            End Try
        End Sub

        Sub HandleRequest()
            Try
                Dim htmlPageText As String = ""
                Dim htmlContentBin() As Byte = Nothing
                Dim htmlHeaderBin() As Byte = Nothing
                Dim htmlContentType As String = ""
                Dim htmlHeader As String = ""

                mTCPClient.Client.Receive(recvBytes, 0, recvBytes.Length, SocketFlags.None)
                htmlReq = System.Text.Encoding.Default.GetString(recvBytes)

                Dim htmlReqArray() As String = htmlReq.Trim.Split(" "c)

                Select Case htmlReqArray(0).Trim().ToUpperInvariant
                    Case "HEAD"
                        Select Case htmlReqArray(1).Trim().ToUpperInvariant
                            Case "/" & mFileName1.ToUpperInvariant
                                htmlContentType = "application/octet-stream"
                                htmlContentBin = File.ReadAllBytes(mRootPath & "\" & mFileName1)
                            Case "/" & mFileName2.ToUpperInvariant
                                htmlContentType = "application/octet-stream"
                                htmlContentBin = File.ReadAllBytes(mRootPath & "\" & mFileName2)
                        End Select
                    Case "GET"
                        Select Case htmlReqArray(1).Trim().ToUpperInvariant
                            Case "/"
                                htmlPageText = "<html><body><table><tbody><tr><td><a href=""http://www.theremino.com/""><img src=""data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAvhSURBVGhD7Vh5cJTlHf723iQkmxCO5oaEhIRwK0dMsiEQjGINYO3YYezQwdYpVpgRp9KpRseZKlcwMOLQOli0XpCQbC6o2DrqGECcUttxitoiImMVcrK59shunj6/d7NJSD5Aq3/mGX7Zb799eb/f87vfTxvHOMYxjnGMYxyj0NbW9r3JZx//B1FR0dAMZmy8fxP01nwfogu9hd9Wbl64CDERJizVNFQvLcL+9Gys1wzIoZg1C4lp4KOUmEwmVFVVfSeSutBbeCPJyZ2Ftq9bYaJi0yj32yPQPHMhLiZm4uuEDFyiXE5MxxNpGZhkj4TH40F/fz+CwSAEZrMZERERsNls/xchXegtvJ4YjUZERtoViaLp07FnUQGO5uXjk3mz8GlWHr6YkY1/p8xAd1IW7qE3Go82AB6gr68D3h5g6xNbYNCMiI6OVkSowrcmpAu9hdcSq9WKvXv3Kuueu3gRD23dismTHIgwRiBSs2IClZpOyac4KfEUDPAfZXvldoaZhphJsejsdCvPuN1u9Pb2KjIHDhz4xmR0obdwtOTn56vYFgKBQIDiB4IDCHp57Q8iAC96BvoAXtup1IXacvztlYeQbNcwwaQh06rhV3fm4vzx3XDYLIrEgLAjZE8BVaGnI78RGV3oLRwpQoDL1MOEhMQ5KVB5EcWH2pCDpwsmSxwqNsxH7/FidLlK0dXwE7QdKgWaSuCuXwxf/Wok20J7hfNFIKTEM4mJiTAYDDckowu9hSLZmfNhtJvx2NZH0e8LwOProeoSJ0r9kAaD6BSrBgOIo/U7XcUYcN2KgboVGKgv5GcJgrUr4XU5gfqVePLehUhNSKHysk8IYe/I35dffQWSh3o6hUUXegttlkgUzo5BHOP+wS2b0dP1ldJdHq4MGXqusqryEO9bSeLLhk3An0vhr18OP4kESSJQQ3GtUN/RuALnatYzn7RB5bnZ1TYZ8hRVQ3l5uS4hXegtdHCTtjfvwaVDP8PCOA3RRivmzslFV58HgQGfPA5+P/OEkM/smfOQ46ByTWvha1gGHHUqD/hcy4FjK+A5mg9/00oEapfjUs1KyP5iDH9A9gJ8fmaZ16tIbH5wk/KIxWJReVlTUzOGjC5GL4pmYm4ocKD7CJUQix5fg5a/bEIaHx5D4X9hH7Di3LlzSgmBhfc+qStHy/F70dr0c/y3qgzuhrXoO3Y3ul2rEDxWRmK3cz/myxu347frbkJcVBQN48PqtWUMYSs0elQaZ1FR4eCuUOT0wkwXIxd097awhJrRcuTHTMx89LuK4Ksrhr8mH72NK/G563FER9gxd+5cZS2pMvJpNJsQOyGahAyI0EywMWGtRk1ZXsjH83qyWUNKlIZJ/H73qnmqD2kTKFP522wjfvlkKTSuCfpY/ehxKSwCaZ4jdRTRxcgFB148iGn0iMd1J0kUo5+hIOHRX+OEn+FyvnoLjFRWSqbP5xtK0jD8fi//Uok+r7q22qLgyNBQtnke9jZuxLOND+Cldx/Bms1ZuPeRJdj3znrsal6BPe8W49nmEmiRDLnhGqBw8OBBNQWM1FMXIxeY6I0LrvsQqHcyUZ3qUzyiro+uwOvld2LR4lsGHzEMISQJH6pEHEUCHnj9PlgjJmLn4Z/imRMrUXHSiV2nirH9VD52nnKisnkZKk7l8Tofz5wsxY73VsEQr8HnleIRMpB8imdGe0UXIxck0rUelsqAKx+BumUkUsBrxiyrjtd1G8pyLXAd+ysfMarUjPoeCHqZy/0oLCzFph1O7G5eHiLSXIxdJ1di58nlJOJU90R2NC9G5QdOaLHhSeBqT0ueVFRUDJHRRfjHSKMDZ+qfQC/zwlvHRK9mblQvQneDk31hKQJNZUhiXIeKVagbXwsD8EuAoaCgAA/uDJGooOV3ncjndYHyiJKT9MqJZdj9Xin28vvEbA0ffXSalpC+RDJSnaW8ewZgMQ8nvS7kh0/OfQaNCRlnisX6gim4Ur8KvqYiVft9dUXw1Behr24tpjJ/3Ff6wm3k2hjwk+oAidwyTIQEwrL7hAjvNRcq2U1v7Dq9GBvKb0Pp7SVqfw5DLPUSprQcb2hGAzZveViR0YX8cFvpD7H/98/DSwWEeSxJ1T3zayyIZpN741GOGms5ctzN4VBDT0fXDfxBDBIpLMzHxm1Fyuq7ThQqEVK7Txare9sZXtuZKzvfL8L295ZjT83DqgRzZFM539PnRo+vG1NiJ8IYEceqGJqSdSE/mKm8JGo/xwypNl3eDsTwHLE2NQOzGE5ZFg058RaYbROke8Hr6VX6hjv7GAQltAbgdBbg/qdJoJlkBvNBEXq/kKFVwCQnoXeKse2tm1Dx9q3Yz8nAJFWT49CP7ipjb4mAljAbyfdVYskf32Z5nnx9IkRYA/VXOq7NYsWxOYtwITUHp7Pn46mpU5DNdXZ2eVsUCYUq7ehqqRDq/kBeXh4e2FmMPadLsO2dIjx3qgzPn7wH+95ajxfefhi/eJy9gxOBxulBeohmM2OCgWcUw2RoC9cg++UP4ai6iOjX2xF5uIU9J/f6RKQqjISfyRZhNuAUiXQkZ6I1NRM9KZloS87BP+fMxe/ip2IRSU1gGMgZw2xkU+Qed9xxB88anejqcbOM9sBV24j0BYlseDzisvFJn7DHxMBgZSO1RcJZVIyGepeUORitNix/bB/mv/g+Il87C0v11zDU8KxS0wXtUDsstW7E3LURmRnZMl2MhRCR0XkkfP1exFoM+EfmXLQlTENb4kxFoi11FtpTZqmjbFvKTDw3fylPe1TSYlYdntspiYxyqPsiGnuT2WQPOVsqkeo1DD32GoHc6mWDPVR/BFpKPrSqThhrO2CqvwKtth2G2ksk44ZW14EZ+96ElfspxUfjzJkzyMjIGBoJBAPBfsRSifMZs+mRNCqdgfbk6SSVhstJabjIo2wHR/EHYmMRHx+vLBpuXmofKtfH7u719qkcMhjkUDacS+E2EWQIDsCncsLb2cPQisWU2k5oRzpgOOKmF7phO9wF4yF6xdWKmBc+hRbNsNPDmjVrsH//fvWCYBhBNSR+mZaF1uQZFPnMQnsSCSSloz1xOlqnZWAVx5Wnt+0Y/D/DCHV47jJYDPgY9X00hhofOXYxnC0WBzJf+himI+0w13TAXE1SDCmtoQdRrj5Yq3g9ZYY+EWLM3CQxnm8y43LqDLQkZysCQkgRScxCW9J0fJWWrvLE6xtpaRlVQhJGyCNXh+4YcLnH2wWr2YKk8j9Ba2yD+UgrSVDoichqN2yNbiRt+A00e5w+kXDVimWYCOR88dRT27CO1aM1OR2XU3IYVvSCkGDityfRMyT41fRszBNLD+s8hNFEZP+RoTsaqsaxZJ8/9zm09FsQW9UCcx3Diflio2S8dh5aZh4PZPbrVy0Ru92uKo880BE9EQem5eIKLd+alMtwEm+EQkukhTnyRfosZFBBP4e8a0H2EiKy9/UgLzO8Eo7stJojHlGvX4B2uAORTW4seKGZ434WHLFRisQNiYhUVlaq6mNiAzw2axE6E1PpEYZWwkxc+UEmOukRSfzLKdPwae4cJIulB3uPYKQnwpCRX0JL77cw2IZDLzG4lcbwSv7DacTUXUHixj30ZgQuXPxiiISILkYuCIuNCr66wInP2D8up4WqVkcKw4zXkvTuhCx8lLuUBycjurrbx4TXSKXlmo8Zc08QLgacKdQeXk83ouInI+G+7aoUm+z6LyF0obfQTqvIyW4xFX00dgo+vGkZzqcy1EioJSEVV2Zk4sTNS3gStKieI1YXEaVGW17CSzwSPuOHlQ8XGDnO9vV2o6q6BvZImwrvCHs0kpMSdEmI6EJv4UiZOTMHMVFW9Y53A2efU3OW4F9JOXDdnKfCQJ09GN7hfBDllJUHk1sIhCcHUV5w9uxZ9Q5LepD8ZrXbsG7duiHFPzj992uSENGF3sJrSUlJiXqTmEKRs4l4zmQyqGTmVli9evXQm3bpS0JIIL+JV8LrRJqamq6r7PVEF3oLv4nse3YvLn55dRIKidzcXMg7YrE0t4fD4Rhz5v6uMo5xjGMc4xjHd4em/Q/ILcrY6ILmPgAAAABJRU5ErkJggg=="" alt=""Theremino logo"" border=""0""></a></td><td>FUOTA Web Server</td></tr></tbody></table></body></html>"
                                htmlContentBin = Encoding.ASCII.GetBytes(htmlPageText)
                                htmlContentType = "text/html"
                            Case "/" & mFileName1.ToUpperInvariant
                                htmlContentType = "application/octet-stream"
                                htmlContentBin = File.ReadAllBytes(mRootPath & "\" & mFileName1)
                            Case "/" & mFileName2.ToUpperInvariant
                                htmlContentType = "application/octet-stream"
                                htmlContentBin = File.ReadAllBytes(mRootPath & "\" & mFileName2)
                        End Select
                End Select

                If htmlContentType <> "" Then
                    htmlHeader = _
                        "HTTP/1.1 200 OK" & ControlChars.CrLf & _
                        "Content-Type: " & htmlContentType & ControlChars.CrLf & _
                        "Content-Length: " & htmlContentBin.Length & ControlChars.CrLf & _
                        "Server: Fuota Web Server 1.0" & _
                        ControlChars.CrLf & ControlChars.CrLf
                    htmlHeaderBin = Encoding.ASCII.GetBytes(htmlHeader)
                Else
                    htmlHeader = _
                        "HTTP/1.1 404 Not found" & ControlChars.CrLf & _
                        "Content-Type: text/html" & ControlChars.CrLf & _
                        "Content-Length: 0" & ControlChars.CrLf & _
                        "Server: Fuota Web Server 1.0" & _
                        ControlChars.CrLf & ControlChars.CrLf
                    htmlHeaderBin = Encoding.ASCII.GetBytes(htmlHeader)

                End If

                mTCPClient.Client.Send(htmlHeaderBin, 0, htmlHeaderBin.Length, SocketFlags.None)
                If Not htmlContentBin Is Nothing And htmlReqArray(0).Trim().ToUpper.Equals("GET") Then
                    mTCPClient.Client.Send(htmlContentBin, 0, htmlContentBin.Length, SocketFlags.None)
                End If

                mTCPClient.Client.Shutdown(SocketShutdown.Both)
                mTCPClient.Client.Close()

            Catch ex As Exception
                Debug.Print(ex.StackTrace.ToString())
            End Try
        End Sub

        ' Send HTTP Response

    End Class

End Module