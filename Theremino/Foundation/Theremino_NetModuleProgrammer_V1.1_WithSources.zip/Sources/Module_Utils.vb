﻿Module Module_Utils


    ' ======================================================================
    '   MIXED FUNCTIONS
    ' ======================================================================
    Friend Sub CreateDir(ByVal DirPath As String)
        My.Computer.FileSystem.CreateDirectory(DirPath)
    End Sub

    ' ======================================================================
    '   COMBO FUNCTIONS
    ' ======================================================================
    Friend Sub Combo_InitFromEnum(ByVal combo As ComboBox, ByVal enumType As Type)  ' use GeType(enum)
        For Each s As String In [Enum].GetNames(enumType)
            combo.Items.Add(s)
        Next
    End Sub

    Friend Sub Combo_SetIndex_FromString(ByVal combo As ComboBox, ByVal str As String)
        Dim old As Boolean = EventsAreEnabled
        EventsAreEnabled = False
        If str = Nothing Then str = ""
        With combo
            For i As Int32 = 0 To .Items.Count - 1
                If .Items(i).ToString.Trim = str Then
                    .SelectedIndex = i
                    Exit For
                End If
            Next
        End With
        EventsAreEnabled = old
    End Sub

    Friend Sub Combo_SetIndex(ByVal combo As ComboBox, ByRef index As Int32)
        Dim n As Int32 = combo.Items.Count
        If n = 0 Then Return
        If index < 0 Then index = 0
        If index > n - 1 Then index = n - 1
        combo.SelectedIndex = index
    End Sub

    Friend Function GetEnumValue(ByVal enumType As Type, ByVal key As String) As Int16 ' use GeType(enum)
        Return CShort([Enum].Parse(enumType, key))
    End Function


    ' ==============================================================
    '  REPLACE MULTIPLE SPACES and TABS and TRIM
    ' ============================================================== 
    Friend Function ReplaceMultipleSpacesAndTrim(ByVal s As String) As String
        s = s.Replace(vbTab, " ")
        While s.Contains("  ")
            s = s.Replace("  ", " ")
        End While
        Return s.Trim
    End Function

    Friend Function RemoveComments(ByVal s As String) As String
        Dim i As Int32 = s.IndexOf("'")
        If i > 0 Then s = s.Remove(i).TrimEnd
        If i = 0 Then s = ""
        Return s
    End Function

    'Private Function Normalize(ByVal s As String) As String
    '    s = s.ToLower
    '    s = ReplaceMultipleSpacesAndTrim(s)
    '    s = RemoveComments(s)
    '    Return s
    'End Function


    ' =======================================================================================================
    '  ONLY UINT NUMERIC TEXT BOX
    ' -------------------------------------------------------------------------------------------------------
    '  Call from KeyDown event with: OnlyUnsignedIntegerTextBox(sender, e)
    ' =======================================================================================================
    Friend Sub OnlyUnsignedIntegerTextBox(ByVal sender As Object, ByVal e As KeyEventArgs)
        ' ------------------------------------------------------ Allow navigation keyboard arrows
        Select Case e.KeyCode
            Case Keys.Up, Keys.Down, Keys.Left, Keys.Right, Keys.PageUp, Keys.PageDown, Keys.Delete
                e.SuppressKeyPress = False
                Return
        End Select
        ' ------------------------------------------------------ Block non-number characters
        Dim currentKey As Char = Chr(e.KeyCode)
        If Not My.Computer.Keyboard.CtrlKeyDown And _
           Not Char.IsControl(currentKey) And _
           Not Char.IsDigit(currentKey) And _
           Not e.KeyCode = Keys.OemMinus And _
           Not e.KeyCode = Keys.OemPeriod Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no decimal point
        If e.KeyCode = Keys.OemPeriod Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no minus sign
        If e.KeyCode = Keys.OemMinus Then
            e.SuppressKeyPress = True
        End If
        ' ------------------------------------------------------- Handle pasted Text
        If e.Control AndAlso e.KeyCode = Keys.V Then
            ' --------------------------------------------------- Preview paste data (removing non-number characters)
            Dim pasteText As String = Clipboard.GetText
            Dim strippedText As String = ""
            Dim i As Integer = 0
            Do While i < pasteText.Length
                If Char.IsDigit(pasteText(i)) Then
                    strippedText = strippedText + pasteText(i).ToString
                End If
                i = (i + 1)
            Loop
            ' --------------------------------------------------- If there were non-numbers in the pasted text
            If strippedText <> pasteText Then

                e.SuppressKeyPress = True
                ' ----------------------------------------------- OPTIONAL: Manually insert text stripped of non-numbers
                Dim tbox As TextBox = CType(sender, TextBox)
                Dim start As Integer = tbox.SelectionStart
                Dim newTxt As String = tbox.Text
                newTxt = newTxt.Remove(tbox.SelectionStart, tbox.SelectionLength)
                ' ----------------------------------------------- remove highlighted text
                newTxt = newTxt.Insert(tbox.SelectionStart, strippedText)
                ' ----------------------------------------------- paste
                tbox.Text = newTxt
                tbox.SelectionStart = start + strippedText.Length
            Else
                e.SuppressKeyPress = False
            End If
        End If
    End Sub

    Friend Function IsIP(ByVal IP As String) As Boolean
        IsIP = (IP Like "*#.*#.*#.#*") And _
               (Not IP Like "*[!0-9.]*") And _
               (Not IP Like "*25[6-9]*") And _
               (Not IP Like "*2[6-9]#*") And _
               (Not IP Like "*[3-9]##*")
        If Not IsIP Then Return False
        Dim iparray() As String
        iparray = IP.Split("."c)
        If iparray.Length <> 4 Then Return False
        For i As Int32 = 0 To 3
            If iparray(i) = "" Then Return False
            Dim n As Int32 = CInt(Val(iparray(i)))
            If n < 0 Or n > 255 Then Return False
        Next
    End Function

End Module
