<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_ReceivePort = New MyTextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_SendPort = New MyTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_SendIp = New MyTextBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txt_ReceivePort)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txt_SendPort)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txt_SendIp)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(208, 92)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "UDP Params"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 69)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 135
        Me.Label4.Text = "Receive PORT"
        '
        'txt_ReceivePort
        '
        Me.txt_ReceivePort.ArrowsIncrement = 1
        Me.txt_ReceivePort.BackColor = System.Drawing.Color.MintCream
        Me.txt_ReceivePort.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ReceivePort.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ReceivePort.DimFactorGray = -65
        Me.txt_ReceivePort.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ReceivePort.ForeColor = System.Drawing.Color.Black
        Me.txt_ReceivePort.Increment = 0.2
        Me.txt_ReceivePort.Location = New System.Drawing.Point(112, 66)
        Me.txt_ReceivePort.MaxLength = 5
        Me.txt_ReceivePort.MaxValue = 65535
        Me.txt_ReceivePort.MinValue = 0
        Me.txt_ReceivePort.Name = "txt_ReceivePort"
        Me.txt_ReceivePort.NumericValue = 7401
        Me.txt_ReceivePort.NumericValueInteger = 7401
        Me.txt_ReceivePort.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ReceivePort.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ReceivePort.RoundingStep = 0
        Me.txt_ReceivePort.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ReceivePort.Size = New System.Drawing.Size(84, 16)
        Me.txt_ReceivePort.TabIndex = 30
        Me.txt_ReceivePort.Text = "7401"
        Me.txt_ReceivePort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 133
        Me.Label3.Text = "Send to PORT"
        '
        'txt_SendPort
        '
        Me.txt_SendPort.ArrowsIncrement = 1
        Me.txt_SendPort.BackColor = System.Drawing.Color.MintCream
        Me.txt_SendPort.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SendPort.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SendPort.DimFactorGray = -65
        Me.txt_SendPort.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SendPort.ForeColor = System.Drawing.Color.Black
        Me.txt_SendPort.Increment = 0.2
        Me.txt_SendPort.Location = New System.Drawing.Point(112, 44)
        Me.txt_SendPort.MaxLength = 5
        Me.txt_SendPort.MaxValue = 65535
        Me.txt_SendPort.MinValue = 0
        Me.txt_SendPort.Name = "txt_SendPort"
        Me.txt_SendPort.NumericValue = 7400
        Me.txt_SendPort.NumericValueInteger = 7400
        Me.txt_SendPort.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SendPort.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SendPort.RoundingStep = 0
        Me.txt_SendPort.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SendPort.Size = New System.Drawing.Size(84, 16)
        Me.txt_SendPort.TabIndex = 20
        Me.txt_SendPort.Text = "7400"
        Me.txt_SendPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(15, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 131
        Me.Label2.Text = "Send to IP"
        '
        'txt_SendIp
        '
        Me.txt_SendIp.ArrowsIncrement = 0
        Me.txt_SendIp.BackColor = System.Drawing.Color.MintCream
        Me.txt_SendIp.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SendIp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SendIp.DimFactorGray = -65
        Me.txt_SendIp.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SendIp.ForeColor = System.Drawing.Color.Black
        Me.txt_SendIp.Increment = 0
        Me.txt_SendIp.Location = New System.Drawing.Point(86, 22)
        Me.txt_SendIp.MaxLength = 15
        Me.txt_SendIp.MaxValue = 0
        Me.txt_SendIp.MinValue = 0
        Me.txt_SendIp.Name = "txt_SendIp"
        Me.txt_SendIp.NumericValue = 0
        Me.txt_SendIp.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SendIp.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SendIp.RoundingStep = 0
        Me.txt_SendIp.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SendIp.Size = New System.Drawing.Size(110, 16)
        Me.txt_SendIp.TabIndex = 10
        Me.txt_SendIp.Text = "127.0.0.1"
        Me.txt_SendIp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(223, 104)
        Me.Controls.Add(Me.GroupBox1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(17, 22)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino OSC"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_ReceivePort As MyTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_SendPort As MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_SendIp As MyTextBox
#End Region
End Class