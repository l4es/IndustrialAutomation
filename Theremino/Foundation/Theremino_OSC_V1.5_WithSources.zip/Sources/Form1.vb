
Friend Class Form1
    Inherits System.Windows.Forms.Form

    Private Sub Form_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        EventsAreEnabled = False
        ' ----------------------------------------------------------------
        Load_INI()
        ' ----------------------------------------------------------------
        UDP_Init()
        ' ----------------------------------------------------------------
        txt_SendIp.SelectionStart = 999
        txt_SendPort.SelectionStart = 999
        txt_ReceivePort.SelectionStart = 999
        txt_ReceivePort.Focus()
        ' ----------------------------------------------------------------
        Me.Text = AppTitleAndVersion("OSC")
        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        CloseProgram()
    End Sub

    Private Sub CloseProgram()
        UDP_Close()
        Save_INI()
        End
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Exit Sub
        LimitFormPosition(Me)
    End Sub


    ' ==============================================================================================================
    '   IP and PORTS
    ' ==============================================================================================================
    Private Sub txt_SendIp_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_SendIp.KeyPress
        If e.KeyChar = Chr(13) Then txt_SendPort.Focus()
        If e.KeyChar >= "0" And e.KeyChar <= "9" Then Return
        If e.KeyChar < " " Then Return
        e.KeyChar = CChar(".")
    End Sub
    Private Sub txt_SendPort_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_SendPort.KeyPress
        If e.KeyChar = Chr(13) Then txt_ReceivePort.Focus()
        If e.KeyChar >= "0" And e.KeyChar <= "9" Then Return
        If e.KeyChar < " " Then Return
        e.KeyChar = CChar("")
    End Sub
    Private Sub txt_ReceivePort_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_ReceivePort.KeyPress
        If e.KeyChar = Chr(13) Then txt_SendIp.Focus()
        If e.KeyChar >= "0" And e.KeyChar <= "9" Then Return
        If e.KeyChar < " " Then Return
        e.KeyChar = CChar("")
    End Sub
    Private Sub txt_SendIp_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_SendIp.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        UDP_Init()
    End Sub
    Private Sub txt_SendPort_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_SendPort.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        UDP_Init()
    End Sub
    Private Sub txt_ReceivePort_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_ReceivePort.TextChanged
        If Not EventsAreEnabled Then Exit Sub
        UDP_Init()
    End Sub
    Private Sub IpParamsLostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_SendIp.LostFocus, _
                                                                                                txt_SendPort.LostFocus, _
                                                                                                txt_ReceivePort.LostFocus
        Save_INI()
    End Sub

End Class