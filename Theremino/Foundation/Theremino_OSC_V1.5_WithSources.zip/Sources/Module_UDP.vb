﻿
Imports System.Text
Imports System.Net
Imports System.Net.Sockets

Module Module_UDP
    ' --------------------------------------------------------------------- receive
    Private UdpReceiveClient As UdpClient
    Private RemoteIpEndPoint As IPEndPoint
    Private UdpReceivePort As Integer
    Private ThreadReceive As System.Threading.Thread
    Private ThreadReceiveStopFlag As Boolean
    ' ---------------------------------------------------------------------- send
    Private UdpSendClient As UdpClient
    Private UdpSendAddr As IPAddress
    Private UdpSendPort As Integer

    ' ----------------------------------------------------------------------------------- UDP_INIT
    Friend Sub UDP_Init()
        UDP_Close()
        Try
            ' ------------------------------------------------------------------ send
            UdpSendAddr = IPAddress.Parse(Form1.txt_SendIp.Text)
            UdpSendPort = Form1.txt_SendPort.NumericValueInteger
            UdpSendClient = New UdpClient
            UdpSendClient.Connect(UdpSendAddr, UdpSendPort)
            ' ------------------------------------------------------------------ receive
            UdpReceivePort = Form1.txt_ReceivePort.NumericValueInteger
            RemoteIpEndPoint = New IPEndPoint(IPAddress.Any, 0)
            UdpReceiveClient = New Sockets.UdpClient(UdpReceivePort)
            ThreadReceiveStopFlag = False
            ThreadReceive = New System.Threading.Thread(AddressOf UDP_Receive)
            ThreadReceive.Start()

            Form1.txt_SendIp.BackColor = Color.MintCream
            Form1.txt_SendIp.BackColor_Over = Color.Moccasin
        Catch
            Form1.txt_SendIp.BackColor = Color.Coral
            Form1.txt_SendIp.BackColor_Over = Color.LightSalmon
            UDP_Close()
        End Try
    End Sub

    Friend Sub UDP_Close()
        If UdpReceiveClient IsNot Nothing Then
            UdpReceiveClient.Close()
        End If
        If UdpSendClient IsNot Nothing Then
            UdpSendClient.Close()
        End If
        If ThreadReceive IsNot Nothing Then
            ThreadReceiveStopFlag = True
            ThreadReceive.Join()
        End If
    End Sub

    ' ----------------------------------------------------------------------------------- UDP_RECEIVE
    Friend Sub UDP_Receive()
        Do
            Try
                Dim receiveBytes As Byte()
                receiveBytes = UdpReceiveClient.Receive(RemoteIpEndPoint)
                '
                ' /theremino/56 \0\0\0 ,\0\0\0        ' 20 bytes
                ' /theremino/56 \0\0\0 ,f\0\0 nnnn    ' 24 bytes
                '
                Dim s As String = Encoding.ASCII.GetChars(receiveBytes)
                If s.StartsWith("/theremino/") Then
                    Select Case s.Length
                        Case 20
                            ' --------------------------------------- get value from slot ( 18uS )
                            Dim slot As Int32 = CInt(Val(s.Substring(11)))
                            If s.Substring(16, 1) = "," Then
                                Dim f As Single

                                f = slots.ReadSlot(slot)
                                UDP_Send(slot, f)
                            End If
                        Case 24
                            ' --------------------------------------- write value to slot ( 8uS )
                            Dim slot As Int32 = CInt(Val(s.Substring(11)))
                            Dim ar(3) As Byte
                            Select Case s.Substring(17, 1)
                                Case "f"
                                    ar(0) = receiveBytes(23)
                                    ar(1) = receiveBytes(22)
                                    ar(2) = receiveBytes(21)
                                    ar(3) = receiveBytes(20)
                                    Dim f As Single = BitConverter.ToSingle(ar, 0)
                                    Slots.WriteSlot(slot, f)
                                Case "i"
                                    ar(0) = receiveBytes(23)
                                    ar(1) = receiveBytes(22)
                                    ar(2) = receiveBytes(21)
                                    ar(3) = receiveBytes(20)
                                    Dim f As Single = BitConverter.ToInt32(ar, 0)
                                    Slots.WriteSlot(slot, f)
                            End Select
                    End Select
                End If
                '
            Catch
                Exit Do
            End Try
        Loop Until ThreadReceiveStopFlag
    End Sub

    ' ----------------------------------------------------------------------------------- UDP_SEND ( 17 uS )
    Friend Sub UDP_Send(ByVal slot As Int32, ByVal value As Single)
        If slot < 0 Or slot > 999 Then Return
        ' --------------------------------------------------------- theremino and Slot
        Dim cmd As String = ""
        cmd &= "/theremino/" & slot.ToString

        'cmd &= StrDup(16 - cmd.Length, Chr(0))
        Dim TrailingNulls As Int32 = 16 - cmd.Length
        While TrailingNulls > 0
            cmd &= vbNullChar
            TrailingNulls -= 1
        End While

        cmd &= ",f" & vbNullChar & vbNullChar
        Dim cmdArray() As Byte = Encoding.ASCII.GetBytes(cmd)
        ' --------------------------------------------------------- add the float value
        ReDim Preserve cmdArray(23)
        Dim b() As Byte = BitConverter.GetBytes(value)
        cmdArray(20) = b(3)
        cmdArray(21) = b(2)
        cmdArray(22) = b(1)
        cmdArray(23) = b(0)
        ' --------------------------------------------------------- send ( 12 uS )
        Try
            If UdpSendClient.Client.Connected Then
                UdpSendClient.Send(cmdArray, cmdArray.Length)
            End If
        Catch
        End Try
    End Sub

End Module
