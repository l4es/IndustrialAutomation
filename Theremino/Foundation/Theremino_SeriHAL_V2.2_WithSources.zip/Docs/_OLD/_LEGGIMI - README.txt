Nella cartella OLD la documentazione � relativa alla precedente versione di SeriHAL (v.1) ed � mantenuta solo per conoscenza della storia dell'applicazione. Riferirsi alla nuova documentazione per conoscere il funzionamento della versione 2.1 che ora � BI-direzionale (da RS232 a SLOT e, attivabile su opzione,  da SLOT a RS232). La trasmissione pu� essere, a scelta, sincrona o asincrona.

The DOCS inside "OLD" folder concern the old SeriHAL version (v.1) and they're only intended as "Version History".
Please refer to these new docs to know about SeriHAL v.2.12 which now offers bi-directional communication (RS232 to SLOT and, optionally, SLOT to RS232). The ability to SEND data from SLOTS to Serial has both Sync or Async options.
Please translate the DOCS from ITALIAN to ENGLISH with G00GLE Translate or equivalent.

Grazie a Claudio S. per la revisione/ampliamento della documentazione, inclusi gli esempi, e per il debug della nuova versione
Thanks to Claudio S. for review and for adding new explanations and examples and for debugging the new version

Ciao 

Marco R.