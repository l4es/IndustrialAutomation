﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Me.cmd_Disconnect = New System.Windows.Forms.Button
        Me.cmd_Connect = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chk_LimitValues = New System.Windows.Forms.CheckBox
        Me.chk_EnableSend = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.chk_OnlyOnDemand = New System.Windows.Forms.CheckBox
        Me.txt_Delta = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut10 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut9 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut8 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut7 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut6 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut5 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut4 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut3 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut2 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotOut1 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN10 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN9 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN8 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN7 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN6 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN5 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN4 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN3 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN2 = New Theremino_SeriHAL.MyTextBox
        Me.txt_SlotN1 = New Theremino_SeriHAL.MyTextBox
        Me.txt_COMPort = New Theremino_SeriHAL.MyTextBox
        Me.cmb_COMSpeed = New Theremino_SeriHAL.MyComboBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmd_Disconnect
        '
        Me.cmd_Disconnect.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Disconnect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Disconnect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Disconnect.Location = New System.Drawing.Point(91, 12)
        Me.cmd_Disconnect.Name = "cmd_Disconnect"
        Me.cmd_Disconnect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Disconnect.Size = New System.Drawing.Size(76, 26)
        Me.cmd_Disconnect.TabIndex = 20
        Me.cmd_Disconnect.Text = "Disconnect"
        Me.cmd_Disconnect.UseVisualStyleBackColor = False
        '
        'cmd_Connect
        '
        Me.cmd_Connect.BackColor = System.Drawing.SystemColors.Control
        Me.cmd_Connect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd_Connect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd_Connect.Location = New System.Drawing.Point(12, 12)
        Me.cmd_Connect.Name = "cmd_Connect"
        Me.cmd_Connect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd_Connect.Size = New System.Drawing.Size(73, 26)
        Me.cmd_Connect.TabIndex = 19
        Me.cmd_Connect.Text = "Connect"
        Me.cmd_Connect.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "COM Port"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "Com Speed"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "SLOT N."
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txt_SlotN10)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN9)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN8)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN7)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN6)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN5)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN4)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN3)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txt_SlotN1)
        Me.GroupBox1.Location = New System.Drawing.Point(179, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(564, 72)
        Me.GroupBox1.TabIndex = 43
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Serial Data to Theremino Slots"
        '
        'chk_LimitValues
        '
        Me.chk_LimitValues.AutoSize = True
        Me.chk_LimitValues.Location = New System.Drawing.Point(584, 89)
        Me.chk_LimitValues.Name = "chk_LimitValues"
        Me.chk_LimitValues.Size = New System.Drawing.Size(159, 17)
        Me.chk_LimitValues.TabIndex = 45
        Me.chk_LimitValues.Text = "Limit values to 0-1000 range"
        Me.chk_LimitValues.UseVisualStyleBackColor = True
        '
        'chk_EnableSend
        '
        Me.chk_EnableSend.AutoSize = True
        Me.chk_EnableSend.Location = New System.Drawing.Point(12, 129)
        Me.chk_EnableSend.Name = "chk_EnableSend"
        Me.chk_EnableSend.Size = New System.Drawing.Size(136, 17)
        Me.chk_EnableSend.TabIndex = 46
        Me.chk_EnableSend.Text = "Transmit  Slots to Serial"
        Me.chk_EnableSend.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut10)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut9)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut8)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut7)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut6)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut5)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut4)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut3)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut2)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txt_SlotOut1)
        Me.GroupBox2.Location = New System.Drawing.Point(179, 129)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(564, 74)
        Me.GroupBox2.TabIndex = 47
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Theremino Slots to Serial (COMn)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "SLOT N."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(88, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "Delta (mSec)"
        '
        'chk_OnlyOnDemand
        '
        Me.chk_OnlyOnDemand.AutoSize = True
        Me.chk_OnlyOnDemand.Location = New System.Drawing.Point(41, 152)
        Me.chk_OnlyOnDemand.Name = "chk_OnlyOnDemand"
        Me.chk_OnlyOnDemand.Size = New System.Drawing.Size(107, 17)
        Me.chk_OnlyOnDemand.TabIndex = 50
        Me.chk_OnlyOnDemand.Text = "Only On Demand"
        Me.chk_OnlyOnDemand.UseVisualStyleBackColor = True
        '
        'txt_Delta
        '
        Me.txt_Delta.ArrowsIncrement = 1
        Me.txt_Delta.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_Delta.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Delta.Increment = 1
        Me.txt_Delta.Location = New System.Drawing.Point(10, 187)
        Me.txt_Delta.MaxValue = 10000
        Me.txt_Delta.MinValue = 2
        Me.txt_Delta.Name = "txt_Delta"
        Me.txt_Delta.NumericValue = 20
        Me.txt_Delta.NumericValueInteger = 20
        Me.txt_Delta.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_Delta.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_Delta.RoundingStep = 0
        Me.txt_Delta.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_Delta.Size = New System.Drawing.Size(72, 20)
        Me.txt_Delta.TabIndex = 48
        Me.txt_Delta.Text = "20"
        Me.txt_Delta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotOut10
        '
        Me.txt_SlotOut10.ArrowsIncrement = 1
        Me.txt_SlotOut10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut10.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut10.Increment = 0
        Me.txt_SlotOut10.Location = New System.Drawing.Point(507, 37)
        Me.txt_SlotOut10.MaxValue = 9999
        Me.txt_SlotOut10.MinValue = 0
        Me.txt_SlotOut10.Name = "txt_SlotOut10"
        Me.txt_SlotOut10.NumericValue = 20
        Me.txt_SlotOut10.NumericValueInteger = 20
        Me.txt_SlotOut10.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut10.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut10.RoundingStep = 0
        Me.txt_SlotOut10.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut10.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut10.TabIndex = 52
        Me.txt_SlotOut10.Text = "20"
        '
        'txt_SlotOut9
        '
        Me.txt_SlotOut9.ArrowsIncrement = 1
        Me.txt_SlotOut9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut9.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut9.Increment = 0
        Me.txt_SlotOut9.Location = New System.Drawing.Point(458, 37)
        Me.txt_SlotOut9.MaxValue = 9999
        Me.txt_SlotOut9.MinValue = 0
        Me.txt_SlotOut9.Name = "txt_SlotOut9"
        Me.txt_SlotOut9.NumericValue = 19
        Me.txt_SlotOut9.NumericValueInteger = 19
        Me.txt_SlotOut9.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut9.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut9.RoundingStep = 0
        Me.txt_SlotOut9.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut9.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut9.TabIndex = 51
        Me.txt_SlotOut9.Text = "19"
        '
        'txt_SlotOut8
        '
        Me.txt_SlotOut8.ArrowsIncrement = 1
        Me.txt_SlotOut8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut8.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut8.Increment = 0
        Me.txt_SlotOut8.Location = New System.Drawing.Point(409, 37)
        Me.txt_SlotOut8.MaxValue = 9999
        Me.txt_SlotOut8.MinValue = 0
        Me.txt_SlotOut8.Name = "txt_SlotOut8"
        Me.txt_SlotOut8.NumericValue = 18
        Me.txt_SlotOut8.NumericValueInteger = 18
        Me.txt_SlotOut8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut8.RoundingStep = 0
        Me.txt_SlotOut8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut8.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut8.TabIndex = 50
        Me.txt_SlotOut8.Text = "18"
        '
        'txt_SlotOut7
        '
        Me.txt_SlotOut7.ArrowsIncrement = 1
        Me.txt_SlotOut7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut7.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut7.Increment = 0
        Me.txt_SlotOut7.Location = New System.Drawing.Point(360, 37)
        Me.txt_SlotOut7.MaxValue = 9999
        Me.txt_SlotOut7.MinValue = 0
        Me.txt_SlotOut7.Name = "txt_SlotOut7"
        Me.txt_SlotOut7.NumericValue = 17
        Me.txt_SlotOut7.NumericValueInteger = 17
        Me.txt_SlotOut7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut7.RoundingStep = 0
        Me.txt_SlotOut7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut7.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut7.TabIndex = 49
        Me.txt_SlotOut7.Text = "17"
        '
        'txt_SlotOut6
        '
        Me.txt_SlotOut6.ArrowsIncrement = 1
        Me.txt_SlotOut6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut6.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut6.Increment = 0
        Me.txt_SlotOut6.Location = New System.Drawing.Point(311, 37)
        Me.txt_SlotOut6.MaxValue = 9999
        Me.txt_SlotOut6.MinValue = 0
        Me.txt_SlotOut6.Name = "txt_SlotOut6"
        Me.txt_SlotOut6.NumericValue = 16
        Me.txt_SlotOut6.NumericValueInteger = 16
        Me.txt_SlotOut6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut6.RoundingStep = 0
        Me.txt_SlotOut6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut6.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut6.TabIndex = 48
        Me.txt_SlotOut6.Text = "16"
        '
        'txt_SlotOut5
        '
        Me.txt_SlotOut5.ArrowsIncrement = 1
        Me.txt_SlotOut5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut5.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut5.Increment = 0
        Me.txt_SlotOut5.Location = New System.Drawing.Point(262, 37)
        Me.txt_SlotOut5.MaxValue = 9999
        Me.txt_SlotOut5.MinValue = 0
        Me.txt_SlotOut5.Name = "txt_SlotOut5"
        Me.txt_SlotOut5.NumericValue = 15
        Me.txt_SlotOut5.NumericValueInteger = 15
        Me.txt_SlotOut5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut5.RoundingStep = 0
        Me.txt_SlotOut5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut5.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut5.TabIndex = 47
        Me.txt_SlotOut5.Text = "15"
        '
        'txt_SlotOut4
        '
        Me.txt_SlotOut4.ArrowsIncrement = 1
        Me.txt_SlotOut4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut4.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut4.Increment = 0
        Me.txt_SlotOut4.Location = New System.Drawing.Point(213, 37)
        Me.txt_SlotOut4.MaxValue = 9999
        Me.txt_SlotOut4.MinValue = 0
        Me.txt_SlotOut4.Name = "txt_SlotOut4"
        Me.txt_SlotOut4.NumericValue = 14
        Me.txt_SlotOut4.NumericValueInteger = 14
        Me.txt_SlotOut4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut4.RoundingStep = 0
        Me.txt_SlotOut4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut4.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut4.TabIndex = 46
        Me.txt_SlotOut4.Text = "14"
        '
        'txt_SlotOut3
        '
        Me.txt_SlotOut3.ArrowsIncrement = 1
        Me.txt_SlotOut3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut3.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut3.Increment = 0
        Me.txt_SlotOut3.Location = New System.Drawing.Point(164, 37)
        Me.txt_SlotOut3.MaxValue = 9999
        Me.txt_SlotOut3.MinValue = 0
        Me.txt_SlotOut3.Name = "txt_SlotOut3"
        Me.txt_SlotOut3.NumericValue = 13
        Me.txt_SlotOut3.NumericValueInteger = 13
        Me.txt_SlotOut3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut3.RoundingStep = 0
        Me.txt_SlotOut3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut3.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut3.TabIndex = 45
        Me.txt_SlotOut3.Text = "13"
        '
        'txt_SlotOut2
        '
        Me.txt_SlotOut2.ArrowsIncrement = 1
        Me.txt_SlotOut2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut2.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut2.Increment = 0
        Me.txt_SlotOut2.Location = New System.Drawing.Point(115, 37)
        Me.txt_SlotOut2.MaxValue = 9999
        Me.txt_SlotOut2.MinValue = 0
        Me.txt_SlotOut2.Name = "txt_SlotOut2"
        Me.txt_SlotOut2.NumericValue = 12
        Me.txt_SlotOut2.NumericValueInteger = 12
        Me.txt_SlotOut2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut2.RoundingStep = 0
        Me.txt_SlotOut2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut2.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut2.TabIndex = 44
        Me.txt_SlotOut2.Text = "12"
        '
        'txt_SlotOut1
        '
        Me.txt_SlotOut1.ArrowsIncrement = 1
        Me.txt_SlotOut1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotOut1.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotOut1.Increment = 0
        Me.txt_SlotOut1.Location = New System.Drawing.Point(66, 37)
        Me.txt_SlotOut1.MaxValue = 9999
        Me.txt_SlotOut1.MinValue = 0
        Me.txt_SlotOut1.Name = "txt_SlotOut1"
        Me.txt_SlotOut1.NumericValue = 11
        Me.txt_SlotOut1.NumericValueInteger = 11
        Me.txt_SlotOut1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotOut1.RoundingStep = 0
        Me.txt_SlotOut1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotOut1.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotOut1.TabIndex = 41
        Me.txt_SlotOut1.Text = "11"
        '
        'txt_SlotN10
        '
        Me.txt_SlotN10.ArrowsIncrement = 1
        Me.txt_SlotN10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN10.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN10.Increment = 0
        Me.txt_SlotN10.Location = New System.Drawing.Point(507, 37)
        Me.txt_SlotN10.MaxValue = 9999
        Me.txt_SlotN10.MinValue = 0
        Me.txt_SlotN10.Name = "txt_SlotN10"
        Me.txt_SlotN10.NumericValue = 10
        Me.txt_SlotN10.NumericValueInteger = 10
        Me.txt_SlotN10.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN10.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN10.RoundingStep = 0
        Me.txt_SlotN10.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN10.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN10.TabIndex = 52
        Me.txt_SlotN10.Text = "10"
        '
        'txt_SlotN9
        '
        Me.txt_SlotN9.ArrowsIncrement = 1
        Me.txt_SlotN9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN9.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN9.Increment = 0
        Me.txt_SlotN9.Location = New System.Drawing.Point(458, 37)
        Me.txt_SlotN9.MaxValue = 9999
        Me.txt_SlotN9.MinValue = 0
        Me.txt_SlotN9.Name = "txt_SlotN9"
        Me.txt_SlotN9.NumericValue = 9
        Me.txt_SlotN9.NumericValueInteger = 9
        Me.txt_SlotN9.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN9.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN9.RoundingStep = 0
        Me.txt_SlotN9.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN9.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN9.TabIndex = 51
        Me.txt_SlotN9.Text = "9"
        '
        'txt_SlotN8
        '
        Me.txt_SlotN8.ArrowsIncrement = 1
        Me.txt_SlotN8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN8.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN8.Increment = 0
        Me.txt_SlotN8.Location = New System.Drawing.Point(409, 37)
        Me.txt_SlotN8.MaxValue = 9999
        Me.txt_SlotN8.MinValue = 0
        Me.txt_SlotN8.Name = "txt_SlotN8"
        Me.txt_SlotN8.NumericValue = 8
        Me.txt_SlotN8.NumericValueInteger = 8
        Me.txt_SlotN8.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN8.RoundingStep = 0
        Me.txt_SlotN8.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN8.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN8.TabIndex = 50
        Me.txt_SlotN8.Text = "8"
        '
        'txt_SlotN7
        '
        Me.txt_SlotN7.ArrowsIncrement = 1
        Me.txt_SlotN7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN7.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN7.Increment = 0
        Me.txt_SlotN7.Location = New System.Drawing.Point(360, 37)
        Me.txt_SlotN7.MaxValue = 9999
        Me.txt_SlotN7.MinValue = 0
        Me.txt_SlotN7.Name = "txt_SlotN7"
        Me.txt_SlotN7.NumericValue = 7
        Me.txt_SlotN7.NumericValueInteger = 7
        Me.txt_SlotN7.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN7.RoundingStep = 0
        Me.txt_SlotN7.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN7.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN7.TabIndex = 49
        Me.txt_SlotN7.Text = "7"
        '
        'txt_SlotN6
        '
        Me.txt_SlotN6.ArrowsIncrement = 1
        Me.txt_SlotN6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN6.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN6.Increment = 0
        Me.txt_SlotN6.Location = New System.Drawing.Point(311, 37)
        Me.txt_SlotN6.MaxValue = 9999
        Me.txt_SlotN6.MinValue = 0
        Me.txt_SlotN6.Name = "txt_SlotN6"
        Me.txt_SlotN6.NumericValue = 6
        Me.txt_SlotN6.NumericValueInteger = 6
        Me.txt_SlotN6.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN6.RoundingStep = 0
        Me.txt_SlotN6.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN6.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN6.TabIndex = 48
        Me.txt_SlotN6.Text = "6"
        '
        'txt_SlotN5
        '
        Me.txt_SlotN5.ArrowsIncrement = 1
        Me.txt_SlotN5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN5.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN5.Increment = 0
        Me.txt_SlotN5.Location = New System.Drawing.Point(262, 37)
        Me.txt_SlotN5.MaxValue = 9999
        Me.txt_SlotN5.MinValue = 0
        Me.txt_SlotN5.Name = "txt_SlotN5"
        Me.txt_SlotN5.NumericValue = 5
        Me.txt_SlotN5.NumericValueInteger = 5
        Me.txt_SlotN5.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN5.RoundingStep = 0
        Me.txt_SlotN5.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN5.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN5.TabIndex = 47
        Me.txt_SlotN5.Text = "5"
        '
        'txt_SlotN4
        '
        Me.txt_SlotN4.ArrowsIncrement = 1
        Me.txt_SlotN4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN4.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN4.Increment = 0
        Me.txt_SlotN4.Location = New System.Drawing.Point(213, 37)
        Me.txt_SlotN4.MaxValue = 9999
        Me.txt_SlotN4.MinValue = 0
        Me.txt_SlotN4.Name = "txt_SlotN4"
        Me.txt_SlotN4.NumericValue = 4
        Me.txt_SlotN4.NumericValueInteger = 4
        Me.txt_SlotN4.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN4.RoundingStep = 0
        Me.txt_SlotN4.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN4.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN4.TabIndex = 46
        Me.txt_SlotN4.Text = "4"
        '
        'txt_SlotN3
        '
        Me.txt_SlotN3.ArrowsIncrement = 1
        Me.txt_SlotN3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN3.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN3.Increment = 0
        Me.txt_SlotN3.Location = New System.Drawing.Point(164, 37)
        Me.txt_SlotN3.MaxValue = 9999
        Me.txt_SlotN3.MinValue = 0
        Me.txt_SlotN3.Name = "txt_SlotN3"
        Me.txt_SlotN3.NumericValue = 3
        Me.txt_SlotN3.NumericValueInteger = 3
        Me.txt_SlotN3.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN3.RoundingStep = 0
        Me.txt_SlotN3.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN3.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN3.TabIndex = 45
        Me.txt_SlotN3.Text = "3"
        '
        'txt_SlotN2
        '
        Me.txt_SlotN2.ArrowsIncrement = 1
        Me.txt_SlotN2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN2.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN2.Increment = 0
        Me.txt_SlotN2.Location = New System.Drawing.Point(115, 37)
        Me.txt_SlotN2.MaxValue = 9999
        Me.txt_SlotN2.MinValue = 0
        Me.txt_SlotN2.Name = "txt_SlotN2"
        Me.txt_SlotN2.NumericValue = 2
        Me.txt_SlotN2.NumericValueInteger = 2
        Me.txt_SlotN2.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN2.RoundingStep = 0
        Me.txt_SlotN2.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN2.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN2.TabIndex = 44
        Me.txt_SlotN2.Text = "2"
        '
        'txt_SlotN1
        '
        Me.txt_SlotN1.ArrowsIncrement = 1
        Me.txt_SlotN1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_SlotN1.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_SlotN1.Increment = 0
        Me.txt_SlotN1.Location = New System.Drawing.Point(66, 37)
        Me.txt_SlotN1.MaxValue = 9999
        Me.txt_SlotN1.MinValue = 0
        Me.txt_SlotN1.Name = "txt_SlotN1"
        Me.txt_SlotN1.NumericValue = 1
        Me.txt_SlotN1.NumericValueInteger = 1
        Me.txt_SlotN1.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_SlotN1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_SlotN1.RoundingStep = 0
        Me.txt_SlotN1.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_SlotN1.Size = New System.Drawing.Size(43, 20)
        Me.txt_SlotN1.TabIndex = 41
        Me.txt_SlotN1.Text = "1"
        '
        'txt_COMPort
        '
        Me.txt_COMPort.ArrowsIncrement = 0
        Me.txt_COMPort.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_COMPort.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_COMPort.Increment = 0
        Me.txt_COMPort.Location = New System.Drawing.Point(86, 51)
        Me.txt_COMPort.MaxValue = 99
        Me.txt_COMPort.MinValue = 1
        Me.txt_COMPort.Name = "txt_COMPort"
        Me.txt_COMPort.NumericValue = 4
        Me.txt_COMPort.NumericValueInteger = 4
        Me.txt_COMPort.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_COMPort.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_COMPort.RoundingStep = 0
        Me.txt_COMPort.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_COMPort.Size = New System.Drawing.Size(35, 21)
        Me.txt_COMPort.TabIndex = 40
        Me.txt_COMPort.Text = "4"
        '
        'cmb_COMSpeed
        '
        Me.cmb_COMSpeed.ArrowButtonColor = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.ArrowColor = System.Drawing.SystemColors.WindowText
        Me.cmb_COMSpeed.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.BackColor_Over = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.BorderColor = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.BorderSize = 2
        Me.cmb_COMSpeed.DisplayMember = "9600"
        Me.cmb_COMSpeed.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_COMSpeed.DropDown_BackColor = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.DropDown_BackSelected = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.DropDown_BorderColor = System.Drawing.SystemColors.Window
        Me.cmb_COMSpeed.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmb_COMSpeed.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.cmb_COMSpeed.DropDownHeight = 999
        Me.cmb_COMSpeed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_COMSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmb_COMSpeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_COMSpeed.FormattingEnabled = True
        Me.cmb_COMSpeed.IntegralHeight = False
        Me.cmb_COMSpeed.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200", "250000", "500000"})
        Me.cmb_COMSpeed.Location = New System.Drawing.Point(81, 85)
        Me.cmb_COMSpeed.MaxDropDownItems = 4
        Me.cmb_COMSpeed.Name = "cmb_COMSpeed"
        Me.cmb_COMSpeed.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_COMSpeed.Size = New System.Drawing.Size(84, 22)
        Me.cmb_COMSpeed.TabIndex = 37
        Me.cmb_COMSpeed.TextPosition = 4
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(753, 244)
        Me.Controls.Add(Me.chk_OnlyOnDemand)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txt_Delta)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.chk_EnableSend)
        Me.Controls.Add(Me.chk_LimitValues)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txt_COMPort)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmb_COMSpeed)
        Me.Controls.Add(Me.cmd_Disconnect)
        Me.Controls.Add(Me.cmd_Connect)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(68, 32)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Serial to HAL"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents cmd_Disconnect As System.Windows.Forms.Button
    Public WithEvents cmd_Connect As System.Windows.Forms.Button
    Friend WithEvents cmb_COMSpeed As MyComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_COMPort As MyTextBox
    Friend WithEvents txt_SlotN1 As MyTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chk_LimitValues As System.Windows.Forms.CheckBox
    Friend WithEvents txt_SlotN2 As MyTextBox
    Friend WithEvents txt_SlotN10 As MyTextBox
    Friend WithEvents txt_SlotN9 As MyTextBox
    Friend WithEvents txt_SlotN8 As MyTextBox
    Friend WithEvents txt_SlotN7 As MyTextBox
    Friend WithEvents txt_SlotN6 As MyTextBox
    Friend WithEvents txt_SlotN5 As MyTextBox
    Friend WithEvents txt_SlotN4 As MyTextBox
    Friend WithEvents txt_SlotN3 As MyTextBox
    Friend WithEvents chk_EnableSend As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_SlotOut10 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut9 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut8 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut7 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut6 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut5 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut4 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut3 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_SlotOut2 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_SlotOut1 As Theremino_SeriHAL.MyTextBox
    Friend WithEvents txt_Delta As Theremino_SeriHAL.MyTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chk_OnlyOnDemand As System.Windows.Forms.CheckBox
End Class
