﻿
Imports System.IO.Ports


Public Class Form_Main

    ' ================================================================================================
    '  Open and Close
    ' ================================================================================================
    Friend MySlots(21) As Int32
    Friend FieldSeparator As String = ";"
    ' ================================================================================
    '  Aquisition with the AccurateTimer
    ' ================================================================================
    Friend WithEvents m_Timer As AccurateTimer = New AccurateTimer
    Friend m_SampleMillisec As Int32 = 20
    '------------------------------------------- keep track of Slots Data changes
    Friend SlotIn_DataChange As Boolean = False
  

    
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        EventsAreEnabled = False
        ' --------------------------------------- Form title
        Me.Text = AppTitleAndVersion("Theremino_SeriHAL")
        ' --------------------------------------- Form position and saved parameters
        Load_INI()
        SetMySlots()
        SetMySlotsOut()
        If chk_EnableSend.Checked = False Then
            chk_OnlyOnDemand.Enabled = False
        End If

        ' --------------------------------------- Auto-connect at start
        Connect_ThisComPort()

        EventsAreEnabled = True
        Refresh()
        Opacity = 1
    End Sub

    Private Sub Form_Main_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        StartStopTX(False)
        Disconnect_ThisComPort()
        Save_INI()
    End Sub

    Private Sub Form_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Not EventsAreEnabled Then Return
        LimitFormPosition(Me)
    End Sub

    ' ================================================================================================
    '  User interface Controls and Subs
    ' ================================================================================================
    Private Sub cmd_Connect_Click(ByVal eventSender As System.Object, _
                                  ByVal eventArgs As System.EventArgs) Handles cmd_Connect.Click
        Connect_ThisComPort()
        If chk_EnableSend.Checked = True Then StartStopTX(True)
    End Sub
    Private Sub cmd_Disconnect_Click(ByVal eventSender As System.Object, _
                                     ByVal eventArgs As System.EventArgs) Handles cmd_Disconnect.Click
        StartStopTX(False)
        chk_EnableSend.Enabled = True
        Disconnect_ThisComPort()

    End Sub

    Private Sub txt_COMPort_TextChanged(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) Handles txt_COMPort.TextChanged
        If Not EventsAreEnabled Then Return
        StartStopTX(False)
        Connect_ThisComPort()
        If (chk_EnableSend.Enabled = True And chk_EnableSend.Checked = True) Then StartStopTX(True)
    End Sub

    Private Sub cmb_COMSpeed_SelectedIndexChanged(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) Handles cmb_COMSpeed.SelectedIndexChanged
        If Not EventsAreEnabled Then Return
        StartStopTX(False)
        Connect_ThisComPort()
        If (chk_EnableSend.Enabled = True And chk_EnableSend.Checked = True) Then StartStopTX(True)
    End Sub

    Private Sub txt_SlotXX_TextChanged(ByVal sender As System.Object, _
                                       ByVal e As System.EventArgs) Handles txt_SlotN1.TextChanged, _
                                                                            txt_SlotN2.TextChanged, _
                                                                            txt_SlotN3.TextChanged, _
                                                                            txt_SlotN4.TextChanged, _
                                                                            txt_SlotN5.TextChanged, _
                                                                            txt_SlotN6.TextChanged, _
                                                                            txt_SlotN7.TextChanged, _
                                                                            txt_SlotN8.TextChanged, _
                                                                            txt_SlotN9.TextChanged, _
                                                                            txt_SlotN10.TextChanged
        If Not EventsAreEnabled Then Return

        SetMySlots()
    End Sub
    Private Sub txt_SlotOutXX_TextChanged(ByVal sender As System.Object, _
                                       ByVal e As System.EventArgs) Handles txt_SlotOut1.TextChanged, _
                                                                            txt_SlotOut2.TextChanged, _
                                                                            txt_SlotOut3.TextChanged, _
                                                                            txt_SlotOut4.TextChanged, _
                                                                            txt_SlotOut5.TextChanged, _
                                                                            txt_SlotOut6.TextChanged, _
                                                                            txt_SlotOut7.TextChanged, _
                                                                            txt_SlotOut8.TextChanged, _
                                                                            txt_SlotOut9.TextChanged, _
                                                                            txt_SlotOut10.TextChanged
        If Not EventsAreEnabled Then Return
        SetMySlotsOut()
    End Sub


    ' ================================================================================================
    '  Utility functions
    ' ================================================================================================
    Private Sub SetMySlots()
        MySlots(0) = CInt(txt_SlotN1.NumericValue)
        MySlots(1) = CInt(txt_SlotN2.NumericValue)
        MySlots(2) = CInt(txt_SlotN3.NumericValue)
        MySlots(3) = CInt(txt_SlotN4.NumericValue)
        MySlots(4) = CInt(txt_SlotN5.NumericValue)
        MySlots(5) = CInt(txt_SlotN6.NumericValue)
        MySlots(6) = CInt(txt_SlotN7.NumericValue)
        MySlots(7) = CInt(txt_SlotN8.NumericValue)
        MySlots(8) = CInt(txt_SlotN9.NumericValue)
        MySlots(9) = CInt(txt_SlotN10.NumericValue)


    End Sub
    Private Sub SetMySlotsOut()
        MySlots(10) = CInt(txt_SlotOut1.NumericValue)
        MySlots(11) = CInt(txt_SlotOut2.NumericValue)
        MySlots(12) = CInt(txt_SlotOut3.NumericValue)
        MySlots(13) = CInt(txt_SlotOut4.NumericValue)
        MySlots(14) = CInt(txt_SlotOut5.NumericValue)
        MySlots(15) = CInt(txt_SlotOut6.NumericValue)
        MySlots(16) = CInt(txt_SlotOut7.NumericValue)
        MySlots(17) = CInt(txt_SlotOut8.NumericValue)
        MySlots(18) = CInt(txt_SlotOut9.NumericValue)
        MySlots(19) = CInt(txt_SlotOut10.NumericValue)
    End Sub

    Private Sub ResetSlotsToZero()
        For i As Int32 = 0 To 19
            Slots.WriteSlot(MySlots(i), 0)
        Next
    End Sub


    ' ================================================================================================
    '  Following functions are specialized to read RS232 packets 
    '  Protocol is self-explained in this software
    ' ================================================================================================

    ' ================================================================================================
    '  RS232 ComPort - Connect / Disconnect
    ' ================================================================================================
    Private WithEvents ThisComPort As New SerialPort()

    Private Sub Connect_ThisComPort()
        ' -------------------------------------------- If the port is Open then close it
        StartStopTX(False)
        Disconnect_ThisComPort()

        ' -------------------------------------------- Set PORT and SPEED
        ThisComPort.PortName = "COM" & CStr(CInt(Val(txt_COMPort.Text)))
        ThisComPort.BaudRate = CInt(Val(cmb_COMSpeed.Text))
        ThisComPort.Parity = Parity.None
        ThisComPort.DataBits = 8
        ThisComPort.StopBits = StopBits.One

        Try
            ThisComPort.Open()
        Catch
        End Try
        ' -------------------------------------------- Test if the port is really open
        If ThisComPort.IsOpen Then
            cmd_Disconnect.Enabled = True
            cmd_Connect.Enabled = False
        Else
            cmd_Disconnect.Enabled = False
            cmd_Connect.Enabled = True
        End If
    End Sub


    Private Sub Disconnect_ThisComPort()
        ResetSlotsToZero()
        Refresh()
        If ThisComPort.IsOpen Then
            ThisComPort.Close()
        End If
        cmd_Connect.Enabled = True
        cmd_Disconnect.Enabled = False
    End Sub




    ' ================================================================================================
    '  RS232 ComPort - Receive Data
    ' ================================================================================================
    Private Sub comPort_DataReceived(ByVal sender As Object, _
                                     ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
                                     Handles ThisComPort.DataReceived
        '
        'STOP TX----------------------------------
        StartStopTX(False)
        '-----------------------------------------
        Dim array() As String = Split(ThisComPort.ReadLine, FieldSeparator)
        Dim k As Integer = array.Length
        '
        If chk_LimitValues.Checked Then
            Dim n As Single
            For i As Int32 = 0 To k - 1
                n = CSng(Val(array(i)))
                n = Math.Min(n, 1000)
                n = Math.Max(n, 0)
                Slots.WriteSlot(MySlots(i), n)
            Next
        Else
            For i As Int32 = 0 To k - 1
                Slots.WriteSlot(MySlots(i), CSng(Val(array(i))))
            Next
        End If

        SlotIn_DataChange = True
        'RUN TX again -----------------------------
        StartStopTX(True)
        '-----------------------------------------
    End Sub
    ' ================================================================================================
    '  RS232 ComPort - Transmit Data 
    ' ================================================================================================

    Private Sub comPort_Data_Out()
        Dim SlotsDataOut As String
        SlotsDataOut = ""
        If (chk_EnableSend.Enabled = True And chk_EnableSend.Checked = True) Then
            For i As Int32 = 10 To 18
                SlotsDataOut = SlotsDataOut & CStr(Slots.ReadSlot(MySlots(i))) & FieldSeparator
            Next
            SlotsDataOut = SlotsDataOut & CStr(Slots.ReadSlot(MySlots(19)))

            ThisComPort.WriteLine(SlotsDataOut)
            'ThisComPort.Write(SlotsDataOut) 'NEWLINE will NOT be added if using this option
        End If

    End Sub

    '---------------------------------------------------------------------------
    'Management of the "Transmit Data to Serial" option
    '---------------------------------------------------------------------------
    Private Sub chk_EnableSend_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_EnableSend.CheckedChanged
        If cmd_Connect.Enabled = True Then
            Exit Sub
        End If
        If chk_EnableSend.Checked = False Then
            chk_OnlyOnDemand.Enabled = False
        Else
            chk_OnlyOnDemand.Enabled = True
        End If
        If (chk_EnableSend.Enabled = True And chk_EnableSend.Checked = True) Then
            StartStopTX(True)
        Else
            StartStopTX(False)
        End If
    End Sub
    Friend Sub StartStopTX(ByVal run As Boolean)
        If run Then
            m_Timer.Interval = m_SampleMillisec
            m_Timer.Start()
        Else
            m_Timer.Stop()
        End If
    End Sub
    Private Sub m_Timer_TimerTick(ByVal TotalMillisec As Double) Handles m_Timer.Tick
        '--------------------------------------------------------------------------
        '---- AccurateTimer Tick event manages Com Port Data Out  -----------------
        '--------------------------------------------------------------------------
        If (chk_EnableSend.Checked = True And chk_OnlyOnDemand.Checked = True) Then
            If SlotIn_DataChange = True Then
                '------------------
                comPort_Data_Out()
                '------------------
                SlotIn_DataChange = False
                Exit Sub
            Else
                Exit Sub
            End If
        Else
            '------------------
            comPort_Data_Out()
            '------------------
        End If

    End Sub

    Private Sub txt_Delta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Delta.TextChanged
        m_SampleMillisec = CInt(txt_Delta.Text)
        m_Timer.Interval = m_SampleMillisec
    End Sub

    Private Sub chk_OnlyOnDemand_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_OnlyOnDemand.CheckedChanged
        If chk_OnlyOnDemand.Checked = True Then
            txt_Delta.Enabled = False
            m_Timer.Interval = 3 'fast check but transmits only if Slot In data has changed
        Else
            txt_Delta.Enabled = True
            m_Timer.Interval = m_SampleMillisec
        End If
    End Sub
End Class