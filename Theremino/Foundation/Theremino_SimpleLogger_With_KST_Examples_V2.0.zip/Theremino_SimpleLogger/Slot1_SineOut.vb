
' ------------------------------------------------------------------------------------------------
' This function is executed in a separate Thread - Do here slow and paused operations
' Questa funzione e' eseguita in un thread separato - Far qui le operazioni lente o con pause
' ------------------------------------------------------------------------------------------------ 
Sub PausableExecution()
	do
		Static v as double
		v += Freq * 2 * math.pi / 500f
		if v >= 2 * math.pi then v -= 2 * math.pi
		WriteSlot(1, csng(500 + 400 * math.sin(v)))
		Threading.Thread.Sleep(1)
	loop
End Sub


' ------------------------------------------------------------------------------------------------
' This function is executed 20 times per second (no pauses here or the whole program is locked)
' Funzione eseguita 20 volte al sec. ( niente pause qui altrimenti tutto il programma si blocca)
' ------------------------------------------------------------------------------------------------
Sub FastExecution

End Sub


' ------------------------------------------------------------------------------------------------
'  Functions called from user controls events
'  Queste funzioni vengono chiamate dagli eventi causati dai controlli utente
' ------------------------------------------------------------------------------------------------
Sub TrackBar1_Scroll(value As Single)
	TrackBar1_Decode
End Sub

Private Freq as Single
Sub TrackBar1_Decode()
	select case TrackBar1.value
		case 1: Freq = 0.1
		case 2: Freq = 0.2
		case 3: Freq = 0.5
		case 4: Freq = 1
		case 5: Freq = 2
		case 6: Freq = 5
		case 7: Freq = 10
		case 8: Freq = 20
		case 9: Freq = 50
		case 10: Freq = 100
	end select
	Label2.Text = "Freq is: " & Freq.ToString("0.00") & " Hz"
End Sub




' ================================================================================================
'  - ENG - THE SIMPLIFIED MANAGEMENT ENDS HER - MODIFY THE FOLLOWING CAREFULLY
' ------------------------------------------------------------------------------------------------
'  - ITA - LA GESTIONE SEMPLIFICATA FINISCE QUI - MODIFICARE LA PARTE SEGUENTE CON ATTENZIONE
' ================================================================================================


Sub Main(ByVal s() As String)
	if Form1 IsNot Nothing then return
	Form1 = New form
	InitializeComponents
	MemoryMappedFile_Init
	StartThread
	TrackBar1_Decode
	While Form1.Visible
		Application.DoEvents
		Threading.Thread.Sleep(10)
	End While
End Sub

Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Form1.Closing
	Timer1.Stop
	objThread.Abort
End Sub

Sub StartThread()
	' --------------------------------------------------------- asynchronously start the Thread 
	objThread = New Threading.Thread(AddressOf ExecuteThread)
	' --------------------------------------------------------- make the thread as background thread.
	objThread.IsBackground = True
	' --------------------------------------------------------- set the Priority of the thread.
	objThread.Priority = Threading.ThreadPriority.AboveNormal
	' --------------------------------------------------------- start the thread.
	objThread.Start()
End Sub

Sub ExecuteThread
	Do
		PausableExecution
		PausaMS(1)
	loop until false
End Sub

Sub PausaMS(Byval mS As Int32)
	Threading.Thread.Sleep(mS)
End Sub

Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
	FastExecution
End Sub

Sub TrackBar1_Scroll(ByVal sender As Object, ByVal e As EventArgs) Handles TrackBar1.Scroll
	TrackBar1_Scroll(TrackBar1.Value)
End Sub

' ---------------------------------------------------------------------- User Interface Components
WithEvents Form1 As Form
WithEvents Timer1 As Timer = New Timer
Dim objThread As Threading.Thread
Dim Label1 As Label = new Label
Dim Label2 As Label = new Label
WithEvents TrackBar1 As TrackBar = new TrackBar

Sub InitializeComponents()
	Application.EnableVisualStyles
	form1.SuspendLayout
	' ------------------------------------------------------------------ Form
	Form1.Text = "Theremino Script - Sine to Slot1"
	Form1.ClientSize = New System.Drawing.Size(640, 240)
	Form1.MinimumSize = Form1.Size
	Form1.StartPosition = FormStartPosition.CenterScreen
	' ------------------------------------------------------------------ Label 1
	Label1.BorderStyle = BorderStyle.Fixed3D
	Label1.Location = New Point(10, 10)
	Label1.Font = New Font("Arial", 12 )
	Label1.Size = New Size(620, 21)
	Label1.Anchor = AnchorStyles.top or AnchorStyles.Left or AnchorStyles.right
	Form1.Controls.Add(Label1)
	' ------------------------------------------------------------------ Label 2
	Label2.BorderStyle = BorderStyle.Fixed3D
	Label2.Location = New Point(10, 40)
	Label2.Font = New Font("Arial", 12 )
	Label2.Size = New Size(620, 21)
	Label2.Anchor = AnchorStyles.top or AnchorStyles.Left or AnchorStyles.right
	Form1.Controls.Add(Label2)	
	' ------------------------------------------------------------------ TrackBar 1
	TrackBar1.Location = New Point(10, 80)
	TrackBar1.Size = New Size(45, 149)
	TrackBar1.Orientation = Orientation.Vertical
	TrackBar1.TickStyle = TickStyle.Both
	TrackBar1.Maximum = 10
	TrackBar1.Minimum = 1
	TrackBar1.TickFrequency = 1
	TrackBar1.LargeChange = 1
	TrackBar1.Value = 4
	Form1.Controls.Add(TrackBar1)
	' ------------------------------------------------------------------ Timer 1
	Timer1.Interval = 50
	Timer1.Start
	' ------------------------------------------------------------------ 
	Form1.ResumeLayout
	Form1.PerformLayout()
	Form1.show
End Sub

