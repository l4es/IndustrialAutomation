' -------------------------------------------------------------------------------------------
'  User options
' -------------------------------------------------------------------------------------------
Dim FileName as String = "LOG.csv"	' File Name (can be a txt or csv file)
Dim TimerSeconds as Single = 1.00	' Log interval (for example 0.1 means 10 times per second)
Dim FirstSlot as Int32 = 1			' First "Theremino Slot"
Dim NumSlots as Int32 = 1			' Number of consecutive "Slots"
Dim FieldSeparator as String = ","
Dim DecimalSeparator as String = "."
Dim TrimZero as Single = 0
Dim TrimSlope as Single = 15 / 1000


' -------------------------------------------------------------------------------------------
'  LOGGER
' -------------------------------------------------------------------------------------------
Dim ci as Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

Sub Initialize
	Timer1.Interval = CInt(TimerSeconds * 1000)
End Sub

Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
	Dim v as Single
	Dim file As System.IO.StreamWriter
	file = My.Computer.FileSystem.OpenTextFileWriter(FileName, True, new System.Text.ASCIIEncoding())
	dim s as string 
	s = Date.Now.tostring("yyyy/MM/dd HH:mm:ss.ff", Globalization.CultureInfo.InvariantCulture)
	For i as Int32 = 0 to NumSlots -1
		v = ReadSlot(FirstSlot + i)
		v = (v * TrimSlope) + TrimZero
		s &= FieldSeparator & _
		     v.ToString("0.000", ci).Replace(".", DecimalSeparator)
	Next
	Label1.Text = s
	file.WriteLine(s)
	file.Close()
End Sub

' ================================================================================================
'  - ENG - THE SIMPLIFIED MANAGEMENT ENDS HER - MODIFY THE FOLLOWING CAREFULLY
' ------------------------------------------------------------------------------------------------
'  - ITA - LA GESTIONE SEMPLIFICATA FINISCE QUI - MODIFICARE LA PARTE SEGUENTE CON ATTENZIONE
' ================================================================================================

Sub Main(ByVal s() As String)
	if Form1 IsNot Nothing then return
	Form1 = New Form
	InitializeComponents
	MemoryMappedFile_Init
	Initialize
	While Form1.Visible
		Application.DoEvents
		Threading.Thread.Sleep(10)
	End While
End Sub

Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Form1.Closing
	Timer1.Stop
End Sub

' ---------------------------------------------------------------------- User Interface Components
WithEvents Form1 As Form
WithEvents Timer1 As Timer = New Timer
Dim Label1 As Label = new Label

Sub InitializeComponents()
	Application.EnableVisualStyles
	form1.SuspendLayout
	' ------------------------------------------------------------------ Form
	Form1.Text = "Theremino Script - Data Logger"
	Form1.StartPosition = FormStartPosition.Manual
	Form1.ClientSize = New System.Drawing.Size(640, 40)
	Form1.MinimumSize = Form1.Size
	Form1.MaximizeBox = False
	Form1.FormBorderStyle = FormBorderStyle.Fixed3D
	' ------------------------------------------------------------------ Label 1
	Label1.BorderStyle = BorderStyle.Fixed3D
	Label1.Location = New Point(10, 10)
	Label1.Font = New Font("Arial", 12 )
	Label1.Size = New Size(620, 21)
	Label1.Anchor = AnchorStyles.top or AnchorStyles.Left or AnchorStyles.right
	Form1.Controls.Add(Label1)
	' ------------------------------------------------------------------ Timer 1
	Timer1.Interval = 100
	Timer1.Start
	' ------------------------------------------------------------------ 
	Form1.ResumeLayout
	Form1.PerformLayout()
	Form1.show
End Sub

