Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.



<Assembly: AssemblyTitle("Theremino SlotViewer")> 
<Assembly: AssemblyDescription("Little helper that shows slot values.")> 
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("Theremino  SlotViewer")> 
<Assembly: AssemblyCopyright("No Copyright - Theremino System")> 
<Assembly: AssemblyTrademark("Theremino")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("3.1")> 



<Assembly: ComVisibleAttribute(False)> 
<Assembly: AssemblyFileVersionAttribute("3.1")> 