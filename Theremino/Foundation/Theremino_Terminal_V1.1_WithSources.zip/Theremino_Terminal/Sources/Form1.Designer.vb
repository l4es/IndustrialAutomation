﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txt_SendString = New System.Windows.Forms.TextBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txt_ReceiveMonitor = New System.Windows.Forms.TextBox
        Me.lbl_Com = New System.Windows.Forms.Label
        Me.cmb_ComPort = New System.Windows.Forms.ComboBox
        Me.cmb_ComSpeed = New System.Windows.Forms.ComboBox
        Me.btn_Connect = New System.Windows.Forms.Button
        Me.lbl_Speed = New System.Windows.Forms.Label
        Me.btn_Send = New System.Windows.Forms.Button
        Me.grb_ReceiveMonitor = New System.Windows.Forms.GroupBox
        Me.btn_ClearText = New System.Windows.Forms.Button
        Me.grb_SendCharacters = New System.Windows.Forms.GroupBox
        Me.grb_SendMonitor = New System.Windows.Forms.GroupBox
        Me.txt_SendCharacters = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chk_TerminatorLF = New System.Windows.Forms.CheckBox
        Me.chk_TerminatorCR = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btn_Help = New System.Windows.Forms.Button
        Me.grb_ReceiveMonitor.SuspendLayout()
        Me.grb_SendCharacters.SuspendLayout()
        Me.grb_SendMonitor.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_SendString
        '
        Me.txt_SendString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SendString.Font = New System.Drawing.Font("Courier New", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SendString.HideSelection = False
        Me.txt_SendString.Location = New System.Drawing.Point(6, 17)
        Me.txt_SendString.Name = "txt_SendString"
        Me.txt_SendString.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txt_SendString.Size = New System.Drawing.Size(303, 24)
        Me.txt_SendString.TabIndex = 3
        Me.txt_SendString.WordWrap = False
        '
        'Timer1
        '
        '
        'txt_ReceiveMonitor
        '
        Me.txt_ReceiveMonitor.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_ReceiveMonitor.Font = New System.Drawing.Font("Courier New", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ReceiveMonitor.HideSelection = False
        Me.txt_ReceiveMonitor.Location = New System.Drawing.Point(7, 20)
        Me.txt_ReceiveMonitor.Multiline = True
        Me.txt_ReceiveMonitor.Name = "txt_ReceiveMonitor"
        Me.txt_ReceiveMonitor.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_ReceiveMonitor.Size = New System.Drawing.Size(303, 94)
        Me.txt_ReceiveMonitor.TabIndex = 51
        Me.txt_ReceiveMonitor.WordWrap = False
        '
        'lbl_Com
        '
        Me.lbl_Com.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_Com.AutoSize = True
        Me.lbl_Com.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Com.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.lbl_Com.Location = New System.Drawing.Point(10, 27)
        Me.lbl_Com.Name = "lbl_Com"
        Me.lbl_Com.Size = New System.Drawing.Size(32, 16)
        Me.lbl_Com.TabIndex = 53
        Me.lbl_Com.Text = "Port"
        '
        'cmb_ComPort
        '
        Me.cmb_ComPort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmb_ComPort.DropDownHeight = 450
        Me.cmb_ComPort.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ComPort.FormattingEnabled = True
        Me.cmb_ComPort.IntegralHeight = False
        Me.cmb_ComPort.Location = New System.Drawing.Point(53, 23)
        Me.cmb_ComPort.Name = "cmb_ComPort"
        Me.cmb_ComPort.Size = New System.Drawing.Size(71, 24)
        Me.cmb_ComPort.TabIndex = 54
        Me.cmb_ComPort.Text = "COM1"
        '
        'cmb_ComSpeed
        '
        Me.cmb_ComSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmb_ComSpeed.DropDownHeight = 450
        Me.cmb_ComSpeed.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ComSpeed.FormattingEnabled = True
        Me.cmb_ComSpeed.IntegralHeight = False
        Me.cmb_ComSpeed.Items.AddRange(New Object() {"600", "1200", "2400", "4800", "9600", "14400", "19200", "28800", "38400", "56000", "57600", "74880", "115000", "128000", "256000", "500000", "1000000"})
        Me.cmb_ComSpeed.Location = New System.Drawing.Point(53, 52)
        Me.cmb_ComSpeed.MaxLength = 7
        Me.cmb_ComSpeed.Name = "cmb_ComSpeed"
        Me.cmb_ComSpeed.Size = New System.Drawing.Size(71, 24)
        Me.cmb_ComSpeed.TabIndex = 55
        Me.cmb_ComSpeed.Text = "9600"
        '
        'btn_Connect
        '
        Me.btn_Connect.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Connect.BackColor = System.Drawing.Color.Gainsboro
        Me.btn_Connect.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Connect.Location = New System.Drawing.Point(8, 80)
        Me.btn_Connect.Name = "btn_Connect"
        Me.btn_Connect.Size = New System.Drawing.Size(118, 34)
        Me.btn_Connect.TabIndex = 56
        Me.btn_Connect.Text = "Connect"
        Me.btn_Connect.UseVisualStyleBackColor = False
        '
        'lbl_Speed
        '
        Me.lbl_Speed.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_Speed.AutoSize = True
        Me.lbl_Speed.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Speed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.lbl_Speed.Location = New System.Drawing.Point(8, 56)
        Me.lbl_Speed.Name = "lbl_Speed"
        Me.lbl_Speed.Size = New System.Drawing.Size(45, 16)
        Me.lbl_Speed.TabIndex = 57
        Me.lbl_Speed.Text = "Speed"
        '
        'btn_Send
        '
        Me.btn_Send.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_Send.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Send.Location = New System.Drawing.Point(8, 58)
        Me.btn_Send.Name = "btn_Send"
        Me.btn_Send.Size = New System.Drawing.Size(118, 34)
        Me.btn_Send.TabIndex = 58
        Me.btn_Send.Text = "Send string"
        Me.btn_Send.UseVisualStyleBackColor = True
        '
        'grb_ReceiveMonitor
        '
        Me.grb_ReceiveMonitor.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grb_ReceiveMonitor.Controls.Add(Me.btn_ClearText)
        Me.grb_ReceiveMonitor.Controls.Add(Me.txt_ReceiveMonitor)
        Me.grb_ReceiveMonitor.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_ReceiveMonitor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.grb_ReceiveMonitor.Location = New System.Drawing.Point(4, 8)
        Me.grb_ReceiveMonitor.Name = "grb_ReceiveMonitor"
        Me.grb_ReceiveMonitor.Size = New System.Drawing.Size(316, 120)
        Me.grb_ReceiveMonitor.TabIndex = 59
        Me.grb_ReceiveMonitor.TabStop = False
        Me.grb_ReceiveMonitor.Text = "Receive monitor"
        '
        'btn_ClearText
        '
        Me.btn_ClearText.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ClearText.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_ClearText.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ClearText.Location = New System.Drawing.Point(240, -1)
        Me.btn_ClearText.Name = "btn_ClearText"
        Me.btn_ClearText.Size = New System.Drawing.Size(68, 17)
        Me.btn_ClearText.TabIndex = 60
        Me.btn_ClearText.Text = "Clear text"
        Me.btn_ClearText.UseVisualStyleBackColor = True
        '
        'grb_SendCharacters
        '
        Me.grb_SendCharacters.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grb_SendCharacters.Controls.Add(Me.txt_SendString)
        Me.grb_SendCharacters.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_SendCharacters.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.grb_SendCharacters.Location = New System.Drawing.Point(5, 184)
        Me.grb_SendCharacters.Name = "grb_SendCharacters"
        Me.grb_SendCharacters.Size = New System.Drawing.Size(315, 46)
        Me.grb_SendCharacters.TabIndex = 60
        Me.grb_SendCharacters.TabStop = False
        Me.grb_SendCharacters.Text = "String to send"
        '
        'grb_SendMonitor
        '
        Me.grb_SendMonitor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grb_SendMonitor.Controls.Add(Me.txt_SendCharacters)
        Me.grb_SendMonitor.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_SendMonitor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.grb_SendMonitor.Location = New System.Drawing.Point(5, 132)
        Me.grb_SendMonitor.Name = "grb_SendMonitor"
        Me.grb_SendMonitor.Size = New System.Drawing.Size(315, 46)
        Me.grb_SendMonitor.TabIndex = 60
        Me.grb_SendMonitor.TabStop = False
        Me.grb_SendMonitor.Text = "Send characters"
        '
        'txt_SendCharacters
        '
        Me.txt_SendCharacters.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SendCharacters.Font = New System.Drawing.Font("Courier New", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SendCharacters.HideSelection = False
        Me.txt_SendCharacters.Location = New System.Drawing.Point(7, 17)
        Me.txt_SendCharacters.Multiline = True
        Me.txt_SendCharacters.Name = "txt_SendCharacters"
        Me.txt_SendCharacters.Size = New System.Drawing.Size(302, 24)
        Me.txt_SendCharacters.TabIndex = 51
        Me.txt_SendCharacters.WordWrap = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.chk_TerminatorLF)
        Me.GroupBox1.Controls.Add(Me.chk_TerminatorCR)
        Me.GroupBox1.Controls.Add(Me.btn_Send)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(328, 132)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(132, 98)
        Me.GroupBox1.TabIndex = 66
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Send string"
        '
        'chk_TerminatorLF
        '
        Me.chk_TerminatorLF.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chk_TerminatorLF.Checked = True
        Me.chk_TerminatorLF.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_TerminatorLF.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.chk_TerminatorLF.Location = New System.Drawing.Point(18, 37)
        Me.chk_TerminatorLF.Name = "chk_TerminatorLF"
        Me.chk_TerminatorLF.Size = New System.Drawing.Size(106, 17)
        Me.chk_TerminatorLF.TabIndex = 60
        Me.chk_TerminatorLF.Text = "Terminator  LF"
        Me.chk_TerminatorLF.UseVisualStyleBackColor = True
        '
        'chk_TerminatorCR
        '
        Me.chk_TerminatorCR.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.chk_TerminatorCR.Checked = True
        Me.chk_TerminatorCR.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_TerminatorCR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.chk_TerminatorCR.Location = New System.Drawing.Point(18, 19)
        Me.chk_TerminatorCR.Name = "chk_TerminatorCR"
        Me.chk_TerminatorCR.Size = New System.Drawing.Size(106, 17)
        Me.chk_TerminatorCR.TabIndex = 59
        Me.chk_TerminatorCR.Text = "Terminator CR"
        Me.chk_TerminatorCR.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.btn_Help)
        Me.GroupBox2.Controls.Add(Me.btn_Connect)
        Me.GroupBox2.Controls.Add(Me.cmb_ComSpeed)
        Me.GroupBox2.Controls.Add(Me.lbl_Speed)
        Me.GroupBox2.Controls.Add(Me.cmb_ComPort)
        Me.GroupBox2.Controls.Add(Me.lbl_Com)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(328, 8)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(132, 120)
        Me.GroupBox2.TabIndex = 67
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Serial port"
        '
        'btn_Help
        '
        Me.btn_Help.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Help.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_Help.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Help.Location = New System.Drawing.Point(86, -1)
        Me.btn_Help.Name = "btn_Help"
        Me.btn_Help.Size = New System.Drawing.Size(39, 17)
        Me.btn_Help.TabIndex = 59
        Me.btn_Help.Text = "Help"
        Me.btn_Help.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(464, 233)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grb_SendMonitor)
        Me.Controls.Add(Me.grb_SendCharacters)
        Me.Controls.Add(Me.grb_ReceiveMonitor)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(480, 272)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Terminal"
        Me.grb_ReceiveMonitor.ResumeLayout(False)
        Me.grb_ReceiveMonitor.PerformLayout()
        Me.grb_SendCharacters.ResumeLayout(False)
        Me.grb_SendCharacters.PerformLayout()
        Me.grb_SendMonitor.ResumeLayout(False)
        Me.grb_SendMonitor.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txt_SendString As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txt_ReceiveMonitor As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Com As System.Windows.Forms.Label
    Friend WithEvents cmb_ComPort As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_ComSpeed As System.Windows.Forms.ComboBox
    Friend WithEvents btn_Connect As System.Windows.Forms.Button
    Friend WithEvents lbl_Speed As System.Windows.Forms.Label
    Friend WithEvents btn_Send As System.Windows.Forms.Button
    Friend WithEvents grb_ReceiveMonitor As System.Windows.Forms.GroupBox
    Friend WithEvents grb_SendCharacters As System.Windows.Forms.GroupBox
    Friend WithEvents grb_SendMonitor As System.Windows.Forms.GroupBox
    Friend WithEvents txt_SendCharacters As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_Help As System.Windows.Forms.Button
    Friend WithEvents btn_ClearText As System.Windows.Forms.Button
    Friend WithEvents chk_TerminatorLF As System.Windows.Forms.CheckBox
    Friend WithEvents chk_TerminatorCR As System.Windows.Forms.CheckBox

End Class
