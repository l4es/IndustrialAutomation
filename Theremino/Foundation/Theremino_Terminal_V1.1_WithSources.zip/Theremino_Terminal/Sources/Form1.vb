﻿Public Class Form1

    ' ===================================================================
    '  OPEN CLOSE FORM AND SERIAL PORT
    ' ===================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Text = AppTitleAndVersion()
        Load_INI()
        OpenComm()
        Timer1.Start()
        EventsAreEnabled = True
        txt_SendCharacters.Focus()
        txt_ReceiveMonitor.Cursor = Cursors.Default
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
        COM_Close()
    End Sub

    Private Sub btn_Help_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Help.Click
        Form2.Hide()
        Form2.Show(Me)
    End Sub

    Private Sub OpenComm()
        Dim baudrate As Int32 = CInt(Val(cmb_ComSpeed.Text))
        COM_Open(cmb_ComPort.Text, baudrate)
        UpdateComButton()
    End Sub

    Private Sub UpdateComButton()
        If COM_IsOpen() Then
            btn_Connect.Text = "Disconnect"
            btn_Connect.BackColor = Color.FromArgb(255, 150, 100)
        Else
            btn_Connect.Text = "Connect"
            btn_Connect.BackColor = Color.FromArgb(240, 240, 240)
        End If
    End Sub

    Private Sub btn_Connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Connect.Click
        If COM_IsOpen() Then
            COM_Close()
            UpdateComButton()
        Else
            OpenComm()
        End If
    End Sub

    Private Sub cmb_ComSelection_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComPort.DropDown
        cmb_ComPort.Items.Clear()
        For Each s As String In COM_GetPortNames()
            cmb_ComPort.Items.Add(s)
        Next
    End Sub

    Private Sub cmb_ComPort_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComPort.TextChanged
        If Not EventsAreEnabled Then Return
        OpenComm()
    End Sub

    Private Sub cmb_ComSpeed_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cmb_ComSpeed.KeyDown
        OnlyNumericComboBox(sender, e)
    End Sub

    Private Sub cmb_ComSpeed_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComSpeed.TextChanged
        If Not EventsAreEnabled Then Return
        OpenComm()
    End Sub

    Private Sub txt_ReceiveMonitor_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_ReceiveMonitor.KeyPress
        Select Case e.KeyChar
            Case Chr(1)
                ' -------------------------------------- CTRL-A
                txt_ReceiveMonitor.SelectAll()
                e.Handled = True
                ' -------------------------------------- CTRL-C
            Case Chr(3)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub btn_ClearText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ClearText.Click
        COM_ReceivedText = ""
        txt_ReceiveMonitor.Text = ""
    End Sub

    ' ===================================================================
    '  RECEIVE TIMER
    ' ===================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If CursorInsideControl(grb_ReceiveMonitor) Then
            If grb_ReceiveMonitor.BackColor <> Color.Yellow Then
                grb_ReceiveMonitor.BackColor = Color.FromArgb(255, 255, 130)
                txt_ReceiveMonitor.BackColor = Color.FromArgb(255, 255, 220)
                grb_ReceiveMonitor.Text = "Receive monitor (updates are disabled)"
            End If
        Else
            If grb_ReceiveMonitor.BackColor <> Me.BackColor Then
                grb_ReceiveMonitor.BackColor = Me.BackColor
                txt_ReceiveMonitor.BackColor = Color.White
                grb_ReceiveMonitor.Text = "Receive monitor"
            End If
            If COM_ReceivedText <> txt_ReceiveMonitor.Text Then
                txt_ReceiveMonitor.Text = COM_ReceivedText
                txt_ReceiveMonitor.SelectionStart = txt_ReceiveMonitor.TextLength
                txt_ReceiveMonitor.ScrollToCaret()
            End If
        End If
    End Sub

    Private Sub txt_CommunicationMonitor_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_SendString.MouseDoubleClick
        COM_ReceivedText = ""
    End Sub

    ' ===================================================================
    '  SEND Characters and Strings
    ' ===================================================================
    Private Sub txt_SendCharacters_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_SendCharacters.KeyPress
        COM_SendString(e.KeyChar)
    End Sub

    Private Sub btn_Send_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Send.Click
        Dim s As String
        s = txt_SendString.Text
        If chk_TerminatorCR.Checked Then s += vbCr
        If chk_TerminatorLF.Checked Then s += vbLf
        COM_SendString(s)
    End Sub

End Class
