﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rtb_Help = New System.Windows.Forms.RichTextBox
        Me.SuspendLayout()
        '
        'rtb_Help
        '
        Me.rtb_Help.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtb_Help.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb_Help.Location = New System.Drawing.Point(4, 4)
        Me.rtb_Help.Name = "rtb_Help"
        Me.rtb_Help.Size = New System.Drawing.Size(475, 292)
        Me.rtb_Help.TabIndex = 0
        Me.rtb_Help.Text = ""
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 302)
        Me.Controls.Add(Me.rtb_Help)
        Me.Name = "Form2"
        Me.Text = "Theremino Terminal Help"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents rtb_Help As System.Windows.Forms.RichTextBox
End Class
