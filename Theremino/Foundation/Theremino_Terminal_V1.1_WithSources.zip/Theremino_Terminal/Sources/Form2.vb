﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        rtb_Help.Rtf = My.Resources.Theremino_Terminal_Help
        rtb_Help.ReadOnly = True
        rtb_Help.BackColor = Me.BackColor
        Me.CenterToParent()
    End Sub

End Class