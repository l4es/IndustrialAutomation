﻿
Imports System.IO.Ports

Module Module_COM

    Private WithEvents ComPort As New SerialPort()

    Friend Sub COM_Open(ByVal PortName As String, ByVal BaudRate As Int32)
        If PortName = "" Then PortName = "COM1"
        If BaudRate < 600 Then BaudRate = 600
        ' -------------------------------------------- If the port is Open then close it
        COM_Close()
        ComPort.PortName = PortName
        ComPort.BaudRate = BaudRate
        ComPort.Parity = Parity.None
        ComPort.DataBits = 8
        ComPort.StopBits = StopBits.One
        ' -------------------------------------------- Set params
        ComPort.ReceivedBytesThreshold = 1
        ComPort.ReadBufferSize = 5000
        ' -------------------------------------------- Disable DTR
        ComPort.DtrEnable = False
        ' -------------------------------------------- 
        Try
            ComPort.Open()
        Catch
        End Try
    End Sub

    Friend Sub COM_Close()
        If ComPort.IsOpen Then
            ComPort.Close()
        End If
    End Sub

    Friend Function COM_GetPortNames() As String()
        Return SerialPort.GetPortNames()
    End Function

    ' ==============================================================================
    '   DATA RECEIVED EVENT
    ' ==============================================================================
    Friend COM_ReceivedText As String

    Private Sub comPort_DataReceived(ByVal sender As Object, _
                                     ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
                                     Handles ComPort.DataReceived

        While ComPort.BytesToRead > 0
            Dim c As Char = Chr(ComPort.ReadByte)
            If (c >= Chr(32) And c <= Chr(127)) Or c = vbCr Or c = vbLf Then
                COM_ReceivedText += c
            Else
                COM_ReceivedText += "."
            End If
        End While
    End Sub

    ' ==============================================================================
    '   SEND / RECEIVE
    ' ==============================================================================
    Friend Sub COM_SendText(ByVal text As String)
        If Not ComPort.IsOpen Then Return
        ComPort.WriteLine(text)
    End Sub

    Friend Sub COM_SendString(ByVal text As String, _
                              Optional ByVal terminator As Int32 = 0)
        If Not ComPort.IsOpen Then Return
        If terminator = 1 Then text += vbCr
        If terminator = 2 Then text += vbLf
        If terminator = 3 Then text += vbCrLf
        ComPort.Write(text)
    End Sub

    Friend Function COM_WaitText(ByVal text As String) As Boolean
        If Not ComPort.IsOpen Then Return False
        Dim sw As Stopwatch = New Stopwatch
        sw.Start()
        Do
            If COM_ReceivedText.Contains(text) Then
                Return True
            End If
        Loop Until sw.ElapsedMilliseconds > 200                ' delay for timeout in millisecond
        Return False
    End Function

    Friend Function COM_IsOpen() As Boolean
        Return ComPort.IsOpen
    End Function

End Module
