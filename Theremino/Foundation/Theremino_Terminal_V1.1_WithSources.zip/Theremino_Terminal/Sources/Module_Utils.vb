﻿Module Module_Utils

    ' =======================================================================================================
    '   APP TITLE AND VERSION
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal Title As String = "") As String
        If Title = "" Then Title = Replace(My.Application.Info.AssemblyName, "_", " ")
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        Return Title & " - V" & s(0) & "." & s(1)
    End Function

    ' =======================================================================================================
    '   CULTURE INFO FOR STRING CONVERSIONS
    ' =======================================================================================================
    Friend CultureInfo As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

    ' =======================================================================================================
    '   MIXED FUNCTIONS
    ' =======================================================================================================
    Friend Function ReplaceMultipleSpacesAndTrim(ByVal s As String) As String
        s = s.Replace(vbTab, " ")
        While s.Contains("  ")
            s = s.Replace("  ", " ")
        End While
        Return s.Trim
    End Function

    Friend Function CursorInsideControl(ByVal ctl As Control) As Boolean
        Return ctl.ClientRectangle.Contains(ctl.PointToClient(Cursor.Position))
    End Function


    ' =======================================================================================================
    '  ONLY Positive Integer NUMERIC COMBO BOX
    ' -------------------------------------------------------------------------------------------------------
    '  Call from KeyDown event with: OnlyNumericComboBox(sender, e)
    ' =======================================================================================================
    Friend Sub OnlyNumericComboBox(ByVal sender As Object, ByVal e As KeyEventArgs)
        ' ------------------------------------------------------ Allow navigation keyboard arrows
        Select Case e.KeyCode
            Case Keys.Up, Keys.Down, Keys.Left, Keys.Right, Keys.PageUp, Keys.PageDown, Keys.Delete
                e.SuppressKeyPress = False
                Return
        End Select
        ' ------------------------------------------------------ Block non-number characters
        Dim currentKey As Char = Chr(e.KeyCode)
        If Not My.Computer.Keyboard.CtrlKeyDown And _
           Not Char.IsControl(currentKey) And _
           Not Char.IsDigit(currentKey) And _
           Not e.KeyCode = Keys.OemMinus And _
           Not e.KeyCode = Keys.OemPeriod Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no decimal point
        If e.KeyCode = Keys.OemPeriod  Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no minus sign
        If e.KeyCode = Keys.OemMinus  Then
            e.SuppressKeyPress = True
        End If
        ' ------------------------------------------------------- Handle pasted Text
        If e.Control AndAlso e.KeyCode = Keys.V Then
            ' --------------------------------------------------- Preview paste data (removing non-number characters)
            Dim pasteText As String = Clipboard.GetText
            Dim strippedText As String = ""
            Dim i As Integer = 0
            Do While i < pasteText.Length
                If Char.IsDigit(pasteText(i)) Then
                    strippedText = strippedText + pasteText(i).ToString
                End If
                i = (i + 1)
            Loop
            ' --------------------------------------------------- If there were non-numbers in the pasted text
            If strippedText <> pasteText Then

                e.SuppressKeyPress = True
                ' ----------------------------------------------- OPTIONAL: Manually insert text stripped of non-numbers
                Dim tbox As ComboBox = CType(sender, ComboBox)
                Dim start As Integer = tbox.SelectionStart
                Dim newTxt As String = tbox.Text
                newTxt = newTxt.Remove(tbox.SelectionStart, tbox.SelectionLength)
                ' ----------------------------------------------- remove highlighted text
                newTxt = newTxt.Insert(tbox.SelectionStart, strippedText)
                ' ----------------------------------------------- paste
                tbox.Text = newTxt
                tbox.SelectionStart = start + strippedText.Length
            Else
                e.SuppressKeyPress = False
            End If
        End If
    End Sub

End Module
