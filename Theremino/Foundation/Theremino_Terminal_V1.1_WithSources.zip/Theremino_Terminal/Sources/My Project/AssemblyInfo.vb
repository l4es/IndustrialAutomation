﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Serial")> 
<Assembly: AssemblyDescription("General purpose serial terminal emulator.")> 
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("Serial emulator")> 
<Assembly: AssemblyCopyright("No Copyright")> 
<Assembly: AssemblyTrademark("Theremino System")> 

<Assembly: ComVisible(False)>


' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.1")> 
<Assembly: AssemblyFileVersion("1.1")> 
